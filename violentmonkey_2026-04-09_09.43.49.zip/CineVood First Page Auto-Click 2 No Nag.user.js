// ==UserScript==
// @name         CineVood First Page Auto-Click 2 No Nag
// @namespace    https://github.com/BlazeFTL
// @description  Bypasses popup blockers by direct location assignment
// @version      1.2
// @author       BlazeFTL
// @match        https://*.cinevood.*/*
// @match        https://*.1cinevood.*/*
// @license      MIT
// @icon         data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAS1BMVEVHcEzwrU7wrU7wrU7wrU7wrU7wrU7wrU7wrU7wrU7wrU7wrU7wrU7wrU5Ci8pCi8pCi8pCi8pCi8pCi8pCi8pCi8pCi8pCi8pCi8oErOx9AAAAGXRSTlMAQYO06fXKDZn/125ZSg6i/3TyW9JAv92H+QjCaQAAAPxJREFUeAFskccBwzAIAHHvNuraf9IIpUCw78vRQdC0XT8M/dg28MA0DwszT6BoF0X7n74uN9ZSpPvGubpgmNZVxYdu2/etY32EyvoJ7/Dh6Fng+WYQzEKYeGrBxsIs8pmVhaH2V1f7DEFbNAvxme/8CM3+5qARZYELDWg6ErqfgNYpoSdhYwHRB5CMhfVggYgnPMHCVYWQfEEJMt9gwd6EFP5tLYgdLAmZermKCXQoxiFB9TxWLEe5AEIhIpEeF7pYUDc2WDlZIFnnYwYW5BecxYoHKRDRlG0iheXYPp0WNXKti1eV+FNNrcigyVZUzyKdCTkma1PMryGnGABR6RrBZ8MijAAAAABJRU5ErkJggg==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const redirectBtn = document.querySelector('a.redirect-btn');

    if (redirectBtn) {
        let targetUrl = redirectBtn.href;

        // Append ?s= if not present
        if (!targetUrl.includes('?s=')) {
            const separator = targetUrl.includes('?') ? '&' : '?';
            targetUrl += separator + 's=';
        }

        // Use replace to prevent the "Back" button loop and bypass popup detection
        window.location.replace(targetUrl);
    }
})();
