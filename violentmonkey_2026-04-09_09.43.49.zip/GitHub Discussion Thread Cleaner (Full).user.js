// ==UserScript==
// @name         GitHub Discussion Thread Cleaner (Full)
// @namespace    https://github.com/BlazeFTL
// @version      1.6
// @description  Deletes all replies AND the parent post in a discussion thread.
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    async function deleteFullThread(parentBlock) {
        // 1. Find all nested replies first
        const replyContainer = parentBlock.querySelector('[id^="child-comments-"]');
        let targets = [];

        if (replyContainer) {
            const replyBtns = replyContainer.querySelectorAll('.gh-standalone-delete-btn');
            targets = Array.from(replyBtns);
        }

        // 2. Add the Parent's own delete button to the end of the list
        const parentDeleteBtn = parentBlock.querySelector(':scope > div .gh-standalone-delete-btn');
        if (parentDeleteBtn) {
            targets.push(parentDeleteBtn);
        }

        if (targets.length === 0) {
            alert("No delete buttons found.");
            return;
        }

        if (!confirm(`Delete this thread (${targets.length} total comments)?`)) return;

        for (const btn of targets) {
            btn.scrollIntoView({ behavior: 'smooth', block: 'center' });
            btn.click();

            // Wait for GitHub modal
            await new Promise(r => setTimeout(r, 400));

            const confirmBtn = document.querySelector('button[type="submit"].Button--danger');
            if (confirmBtn) {
                confirmBtn.click();
                // Wait for DOM to clear and avoid rate-limiting
                await new Promise(r => setTimeout(r, 800));
            }
        }
    }

    function addThreadDeleteButton() {
        const blocks = document.querySelectorAll('.js-timeline-discussion-comment:not([data-thread-init])');

        blocks.forEach(block => {
            // Ensure we don't add "Delete All" to nested replies, only top-level posts
            if (block.closest('[id^="child-comments-"]')) return;

            block.setAttribute('data-thread-init', 'true');

            const menu = block.querySelector('button[id^="Comment-actions"]');
            if (!menu) return;

            const bulkBtn = document.createElement('button');
            bulkBtn.innerHTML = '🗑️ Delete Full Thread';
            bulkBtn.style.cssText = 'margin-left: 8px; cursor: pointer; color: white; background: #cf222e; border: none; border-radius: 6px; padding: 4px 8px; font-size: 11px; vertical-align: middle; font-weight: bold;';

            bulkBtn.onclick = (e) => {
                e.preventDefault();
                deleteFullThread(block);
            };

            menu.parentNode.insertBefore(bulkBtn, menu.nextSibling);
        });
    }

    let debounce;
    const observer = new MutationObserver(() => {
        clearTimeout(debounce);
        debounce = setTimeout(addThreadDeleteButton, 200);
    });

    observer.observe(document.body, { childList: true, subtree: true });
    addThreadDeleteButton();
})();
