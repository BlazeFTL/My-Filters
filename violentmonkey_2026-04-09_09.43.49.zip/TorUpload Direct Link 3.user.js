// ==UserScript==
// @name         TorUpload Direct Link 3
// @namespace    https://github.com/BlazeFTL
// @description  Fetches Gofile links directly from TorUpload API to bypass ads
// @version      1.0
// @author       BlazeFTL
// @match        https://torupload.com/file/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The fileId is the last part of the URL (e.g., mzsowrlcdxmw)
    const fileId = window.location.pathname.split('/').pop();

    if (!fileId) return;

    const apiUrl = `/token/json.php?fileid=${fileId}`;

    console.log('[BlazeFTL] Fetching links for:', fileId);

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            if (data && data.ppd) {
                // Create a container for our clean buttons
                const container = document.createElement('div');
                container.style = "position: fixed; top: 10px; left: 50%; transform: translateX(-50%); z-index: 999999; background: #1a1a1a; padding: 15px; border: 2px solid #3b82f6; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); display: flex; gap: 10px; flex-direction: column; align-items: center;";

                const title = document.createElement('div');
                title.innerText = "Direct Download Links Found:";
                title.style = "color: white; font-weight: bold; margin-bottom: 5px; font-family: sans-serif;";
                container.appendChild(title);

                let linkFound = false;

                Object.entries(data.ppd).forEach(([provider, details]) => {
                    if (details.link) {
                        linkFound = true;
                        const btn = document.createElement('a');
                        btn.href = details.link;
                        btn.target = "_blank";
                        btn.innerText = `Download from ${provider.toUpperCase()}`;
                        btn.style = "display: block; padding: 8px 20px; background: #3b82f6; color: white; border-radius: 4px; text-decoration: none; font-weight: bold; width: 200px; text-align: center; transition: 0.2s;";

                        btn.onmouseover = () => btn.style.background = "#2563eb";
                        btn.onmouseout = () => btn.style.background = "#3b82f6";

                        container.appendChild(btn);
                    }
                });

                if (linkFound) {
                    document.body.appendChild(container);
                }
            }
        })
        .catch(err => console.error("[BlazeFTL] Error fetching API:", err));
})();
