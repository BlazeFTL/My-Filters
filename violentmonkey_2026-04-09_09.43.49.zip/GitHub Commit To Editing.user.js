// ==UserScript==
// @name         GitHub Commit To Editing
// @namespace    https://github.com/BlazeFTL
// @description  Automate direct edit URL from GitHub Diff line rows
// @version      1.0
// @author       BlazeFTL
// @match        https://github.com/*/*/commit/*
// @match        https://github.com/*/*/pull/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const createEditButtons = () => {
        // Find the diff rows
        const rows = document.querySelectorAll('tr.diff-line-row');

        rows.forEach(row => {
            // Check if we already added the button to this row
            if (row.querySelector('.direct-edit-btn')) return;

            // Get the line number from the 5th child (td > code) as per your screenshot
            const lineCell = row.querySelector('td:nth-child(2) code'); // Adjusting based on standard diff layout vs your 5th child logic
            const lineNum = lineCell ? lineCell.innerText.trim() : null;

            if (!lineNum || isNaN(lineNum)) return;

            // Find the closest file container to get the filename
            const container = row.closest('[id^="diff-"]');
            if (!container) return;

            // Get filename from the selector you provided
            const fileCodeElem = container.querySelector('.Link--primary.prc-Link-Link-9ZwDx code');
            const filePath = fileCodeElem ? fileCodeElem.innerText.replace(/[\u200B-\u200D\uFEFF]/g, '').trim() : null;

            if (filePath) {
                const repoPath = window.location.pathname.split('/').slice(1, 3).join('/');
                const editUrl = `https://github.com/${repoPath}/edit/master/${filePath}#L${lineNum}`;

                // Create small action button
                const btn = document.createElement('a');
                btn.className = 'direct-edit-btn';
                btn.href = editUrl;
                btn.innerText = '📝';
                btn.title = `Edit line ${lineNum} on master`;
                btn.style.cssText = 'text-decoration:none; margin-left:5px; cursor:pointer; font-size:12px;';

                // Append to the line number cell
                lineCell.parentElement.appendChild(btn);
            }
        });
    };

    // GitHub loads content dynamically
    const observer = new MutationObserver(() => createEditButtons());
    observer.observe(document.body, { childList: true, subtree: true });

    createEditButtons();
})();
