// ==UserScript==
// @name         Sulasokvids Auto-Clicker 1.6
// @namespace    https://github.com/BlazeFTL
// @description  Aggressive Preroll handling with ID tracking
// @version      1.6
// @author       BlazeFTL
// @match        https://sulasokvids.net/*
// @match        https://rubyvidhub.com/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const getPageId = () => {
        const params = new URLSearchParams(window.location.search);
        return params.get('id') || window.location.pathname;
    };

    const isVisible = (el) => {
        if (!el) return false;
        const style = window.getClientRects().length > 0;
        const computedStyle = window.getComputedStyle(el);
        return style && computedStyle.display !== 'none' && computedStyle.visibility !== 'hidden';
    };

    const processClick = () => {
        const pageId = getPageId();

        // 1. Player 3 Button (Kept as one-time click per ID to avoid refresh loops)
        const player3 = document.querySelector('a.btn-dark[href*="oodstream"]');
        if (isVisible(player3) && !sessionStorage.getItem(`p3_${pageId}`)) {
            sessionStorage.setItem(`p3_${pageId}`, 'true');
            player3.click();
            return;
        }

        // 2. Preroll Overlay - Aggressive Mode
        // We click this as long as it is visible. Once clicked successfully,
        // the site usually removes the #preroll-overlay div.
        const prerollPlay = document.querySelector('#preroll-overlay button.play-button');
        if (isVisible(prerollPlay)) {
            prerollPlay.click();
        }

        // 3. Iframe/Internal Play Button
        const vidPlay = document.querySelector('button#vid_play');
        if (isVisible(vidPlay)) {
            vidPlay.click();
        }
    };

    // MutationObserver for speed
    const observer = new MutationObserver(() => processClick());
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true
    });

    // Frequent interval to catch the preroll as soon as it's clickable
    setInterval(processClick, 500);

    processClick();
})();
