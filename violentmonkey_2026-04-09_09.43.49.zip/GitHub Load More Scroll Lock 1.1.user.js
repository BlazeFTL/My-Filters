// ==UserScript==
// @name         GitHub Load More Scroll Lock 1.1
// @namespace    https://github.com/BlazeFTL
// @description  Hard-locks scroll position using requestAnimationFrame and CSS suppression.
// @version      1.1
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let lockedPosition = 0;
    let animationFrameId = null;

    const hardLock = () => {
        if (window.scrollY !== lockedPosition) {
            window.scrollTo(0, lockedPosition);
        }
        animationFrameId = requestAnimationFrame(hardLock);
    };

    const releaseLock = () => {
        cancelAnimationFrame(animationFrameId);
        document.documentElement.style.overflow = '';
        document.body.style.overflow = '';
        animationFrameId = null;
    };

    document.addEventListener('click', (e) => {
        const btn = e.target.closest('.ajax-pagination-btn, .custom-mirror-btn, .custom-mobile-mirror-btn');

        if (btn) {
            lockedPosition = window.scrollY;

            // 1. Force CSS Lock (Prevents user input scrolling)
            document.documentElement.style.overflow = 'hidden';
            document.body.style.overflow = 'hidden';

            // 2. Force Script Lock (Prevents programmatic/loading jumps)
            if (!animationFrameId) {
                hardLock();
            }

            // 3. Safety Release
            setTimeout(releaseLock, 4000);
        }
    }, true);
})();
