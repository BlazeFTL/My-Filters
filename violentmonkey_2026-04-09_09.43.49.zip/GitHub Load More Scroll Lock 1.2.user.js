// ==UserScript==
// @name         GitHub Load More Scroll Lock 1.2
// @namespace    https://github.com/BlazeFTL
// @description  Anchors view to the current element so layout shifts don't move your position.
// @version      1.2
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let anchorElement = null;
    let offsetFromTop = 0;
    let animationFrameId = null;

    const maintainAnchor = () => {
        if (anchorElement) {
            const currentRect = anchorElement.getBoundingClientRect();
            // Calculate where we should be to keep the element at the same visual offset
            const desiredScrollY = window.scrollY + (currentRect.top - offsetFromTop);

            if (Math.abs(window.scrollY - desiredScrollY) > 0.5) {
                window.scrollTo(0, desiredScrollY);
            }
        }
        animationFrameId = requestAnimationFrame(maintainAnchor);
    };

    const releaseLock = () => {
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
        anchorElement = null;
    };

    document.addEventListener('click', (e) => {
        const btn = e.target.closest('.ajax-pagination-btn, .custom-mirror-btn, .custom-mobile-mirror-btn');

        if (btn) {
            // Find the element currently at the top of the viewport to use as an anchor
            // We offset by 100px to avoid picking up fixed headers
            anchorElement = document.elementFromPoint(window.innerWidth / 2, 100) || document.body;
            offsetFromTop = anchorElement.getBoundingClientRect().top;

            if (!animationFrameId) {
                maintainAnchor();
            }

            // Extended to 6 seconds to account for slow comment loading/rendering
            setTimeout(releaseLock, 6000);
        }
    }, true);
})();
