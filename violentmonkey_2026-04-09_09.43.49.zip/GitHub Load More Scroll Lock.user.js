// ==UserScript==
// @name         GitHub Load More Scroll Lock
// @namespace    https://github.com/BlazeFTL
// @description  Hard-locks scroll position (Supports PC & Mobile Mirror).
// @version      1.0
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let isLocked = false;
    let lockedPosition = 0;

    const lockHandler = () => {
        if (isLocked) {
            window.scrollTo(0, lockedPosition);
        }
    };

    document.addEventListener('click', (e) => {
        // Added .custom-mobile-mirror-btn to the selector
        const btn = e.target.closest('.ajax-pagination-btn, .custom-mirror-btn, .custom-mobile-mirror-btn');

        if (btn) {
            lockedPosition = window.scrollY;
            isLocked = true;

            window.addEventListener('scroll', lockHandler, { passive: false });

            setTimeout(() => {
                isLocked = false;
                window.removeEventListener('scroll', lockHandler);
            }, 4000);
        }
    }, true);
})();
