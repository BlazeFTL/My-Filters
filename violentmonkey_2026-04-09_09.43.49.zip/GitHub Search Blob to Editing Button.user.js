// ==UserScript==
// @name         GitHub Search Blob to Editing Button
// @namespace    https://github.com/BlazeFTL
// @description  Correctly builds folder path and adds Edit Master links to line numbers
// @version      1.0
// @author       BlazeFTL
// @match        https://github.com/*/*/blob/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const getFullFilePath = () => {
        // Find all links within the breadcrumb navigation area
        const breadcrumbLinks = Array.from(document.querySelectorAll('nav[aria-label="Breadcrumbs"] a, [class*="Breadcrumb"] a'));

        if (breadcrumbLinks.length < 2) return null;

        // Get the link that represents the parent folder (usually the one before the filename)
        // We look for the one containing "/tree/" in the URL
        const folderLink = breadcrumbLinks.reverse().find(a => a.href.includes('/tree/'));

        if (!folderLink) return null;

        // Extract the path after the branch/commit hash
        const urlParts = folderLink.href.split('/');
        const treeIndex = urlParts.indexOf('tree');
        const folderPath = urlParts.slice(treeIndex + 2).join('/');

        // Get the filename from the H1
        const fileNameElem = document.querySelector('h1[id="file-name-id"], [class*="filename"] h1');
        const fileName = fileNameElem ? fileNameElem.innerText.trim() : '';

        return folderPath ? `${folderPath}/${fileName}` : fileName;
    };

    const addEditLinks = () => {
        const filePath = getFullFilePath();
        const repoPath = window.location.pathname.split('/').slice(1, 3).join('/');

        // Target the line number divs - checking for multiple possible GitHub classes
        const lineNumbers = document.querySelectorAll('div[data-line-number]');

        lineNumbers.forEach(div => {
            // Ensure we are in the line number gutter and not the code area
            if (div.querySelector('.direct-edit-link') || !div.classList.contains('react-line-number')) return;

            const lineNum = div.getAttribute('data-line-number');

            const editLink = document.createElement('a');
            editLink.className = 'direct-edit-link';
            editLink.href = `https://github.com/${repoPath}/edit/master/${filePath}#L${lineNum}`;
            editLink.innerText = '📝';
            editLink.style.cssText = 'font-size: 12px; margin-left: 2px; text-decoration: none; display: inline-block; z-index: 10; position: relative;';

            div.appendChild(editLink);
        });
    };

    // Use a high-frequency observer because mobile GitHub is very "jumpy" with virtual lists
    const observer = new MutationObserver(addEditLinks);
    observer.observe(document.body, { childList: true, subtree: true });

    addEditLinks();
})();
