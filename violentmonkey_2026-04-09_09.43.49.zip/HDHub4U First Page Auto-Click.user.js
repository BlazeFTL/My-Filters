// ==UserScript==
// @name         HDHub4U First Page Auto-Click
// @namespace    https://github.com/BlazeFTL
// @description  Auto click "View Full Site" button on hdhub4u
// @version      1.0
// @author       BlazeFTL
// @match        https://hdhub4u.*/*
// @license      MIT
// @icon         data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAMAAABF0y+mAAAAdVBMVEVHcEz8lkH9kEH2eDfyczPxeTbCiDTmEhzcNSHShnrTDhbvKSTiFR7FAQ/HAhD6HCXEBA/XDBfFAw/TERbFBQ/sGCDDAw/NBxK/Bw7FBBDpKCPkGB3ZDhjUDxfFBhDhqALRBxPJBhDDBQ/DAxDXmQblrQO5egBsU9utAAAAJ3RSTlMAMFThtoAKYxEBU0If//8uxam1+uQqY/897mOTesWKtuqXp2hXyiliZMLxAAAAwUlEQVR4AZ3JBQLDMAwEwSsapbjMDP9/Yp0UlFJozR40r9V+1frCTvdV7xshfWMfSikNY5VyQNzTU9ATJ4AJNACGlDZyL8SYJwCmGXIazdxvtN7PxzTKoRdMYIAFLQVX6/V6+MSYpY0gxTiHoJngNhbyOJ5pADq7ITbNY2CPrIjmB/Z3/5Bm+IsT2v/HwIe/eGT2P9FvRjPmLX7iZErMB7xwkeGJtjDr4DE8JBDcasTmc0iCf/rC80X6RNO/Sn007gaY6hUNygsV4wAAAABJRU5ErkJggg==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Target the specific anchor inside the action-button div
    const actionBtn = document.querySelector('#action-button a.new-tab');

    if (actionBtn) {
        const targetUrl = actionBtn.href;

        if (targetUrl && targetUrl !== '#' && targetUrl !== 'javascript:void(0)') {
            // Using location.replace avoids the "allow popup" nag in Firefox
            // and prevents the back-button loop.
            window.location.replace(targetUrl);
        } else {
            // Fallback to a trusted click event if the href is handled by JS listeners
            const clickEvent = new MouseEvent('click', {
                view: window,
                bubbles: true,
                cancelable: true
            });
            actionBtn.dispatchEvent(clickEvent);
        }
    }
})();
