// ==UserScript==
// @name         Sulasokvids URL Modifier 1.0
// @namespace    https://github.com/BlazeFTL
// @description  Appends &s=doodstream to video URLs if missing
// @version      1.0
// @author       BlazeFTL
// @match        https://sulasokvids.net/video.php?id=*
// @run-at       document-start
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const currentUrl = new URL(window.location.href);
    const params = new URLSearchParams(currentUrl.search);

    // Check if 'id' exists and 's' is NOT set to 'doodstream'
    if (params.has('id') && params.get('s') !== 'doodstream') {
        params.set('s', 'doodstream');

        // Construct the new URL and redirect immediately
        const newUrl = `${currentUrl.origin}${currentUrl.pathname}?${params.toString()}`;
        window.location.replace(newUrl);
    }
})();
