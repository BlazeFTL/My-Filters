// ==UserScript==
// @name         Dead Domain Checker 1.6
// @namespace    https://github.com/BlazeFTL
// @version      1.6
// @description  DNS checker with expanding UI, Wildcard status updates, and A-Z sorting toggle
// @match        *://example.com/*
// @author       BlazeFTL
// @license      MIT
// @grant        GM_addStyle
// ==/UserScript==

(function () {
  'use strict';

  GM_addStyle(`
    #vmBox {
      position: fixed;
      top: 15px;
      right: 15px;
      width: 95%;
      max-width: 450px;
      background: #1a1a1a;
      color: #ffffff;
      border-radius: 12px;
      padding: 15px;
      z-index: 999999;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      box-shadow: 0 8px 24px rgba(0,0,0,0.8);
      border: 1px solid #444;
    }
    #vmBox b {
      display: block;
      margin-bottom: 5px;
      font-size: 16px;
      color: #ddd;
    }
    #vmBox textarea {
      width: 100%;
      background: #000;
      color: #00ff00;
      border: 1px solid #555;
      resize: vertical;
      margin-top: 5px;
      margin-bottom: 10px;
      font-size: 15px;
      padding: 8px;
      box-sizing: border-box;
      border-radius: 4px;
      font-family: 'Consolas', 'Monaco', monospace;
    }
    #vmBox button {
      margin-top: 5px;
      margin-right: 6px;
      padding: 10px 16px;
      background: #333;
      color: #fff;
      border: 1px solid #666;
      cursor: pointer;
      border-radius: 6px;
      font-size: 14px;
      font-weight: bold;
      transition: background 0.2s;
    }
    #vmBox button:hover:not(:disabled) {
      background: #444;
    }
    #vmBox button:disabled {
      opacity: 0.3;
      cursor: not-allowed;
    }
    #vmBox .btn-paste {
      background: #663300;
      border-color: #884400;
    }
    #vmBox .btn-toggle {
      background: #222;
      border: 1px dashed #777;
    }
    #vmBox .btn-toggle.active {
      background: #004d40;
      border: 1px solid #00bfa5;
      color: #00ffcc;
    }
    #vmOut {
      margin: 10px 0;
      min-height: 80px;
      max-height: 250px;
      overflow: auto;
      white-space: pre-wrap;
      font-size: 14px;
      padding: 10px;
      background: #0a0a0a;
      border-radius: 4px;
      border-left: 4px solid #444;
    }
    .dead { color: #ff5555; font-weight: bold; }
    .live { color: #55ff55; font-weight: bold; }
    .skip { color: #ffcc00; font-weight: bold; }
    .note { color: #bbb; }

    .output-section {
      margin-top: 15px;
      padding-top: 10px;
      border-top: 1px solid #333;
    }
  `);

  const box = document.createElement('div');
  box.id = 'vmBox';
  box.innerHTML = `
    <b>Domain Checker</b>
    <textarea id="vmInput" rows="4" placeholder="Paste Domains Here..."></textarea>
    <div>
      <button id="vmPaste" class="btn-paste">Paste Content</button>
      <button id="vmCheck">Check Domains</button>
      <button id="vmClear">Clear All</button>
    </div>

    <div id="vmOut" class="note">Idle.</div>
<div>
  <button id="vmSortToggle" class="btn-toggle">Sort A-Z: OFF</button>
</div>
    <div class="output-section">
        <b>Working Domains (Comma):</b>
        <textarea id="vmComma" rows="2" readonly placeholder="Results Will Appear Here..."></textarea>
        <button id="copyComma" disabled>Copy Comma</button>
    </div>

    <div class="output-section">
        <b>Working Domains (Pipe):</b>
        <textarea id="vmPipe" rows="2" readonly placeholder="Results Will Appear Here..."></textarea>
        <button id="copyPipe" disabled>Copy Pipe</button>
    </div>
  `;
  document.body.appendChild(box);

  const input = box.querySelector('#vmInput');
  const out = box.querySelector('#vmOut');
  const commaBox = box.querySelector('#vmComma');
  const pipeBox = box.querySelector('#vmPipe');
  const copyComma = box.querySelector('#copyComma');
  const copyPipe = box.querySelector('#copyPipe');
  const checkBtn = box.querySelector('#vmCheck');
  const clearBtn = box.querySelector('#vmClear');
  const pasteBtn = box.querySelector('#vmPaste');
  const sortToggle = box.querySelector('#vmSortToggle');

  let isSortEnabled = false;
  let lastWorkingDomains = [];

  const updateOutputBoxes = () => {
    let list = [...lastWorkingDomains];
    if (isSortEnabled) {
      list.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
    }
    commaBox.value = list.join(',');
    pipeBox.value = list.join('|');
    const hasData = list.length > 0;
    copyComma.disabled = !hasData;
    copyPipe.disabled = !hasData;
  };

  sortToggle.onclick = () => {
    isSortEnabled = !isSortEnabled;
    sortToggle.textContent = `Sort A-Z: ${isSortEnabled ? 'ON' : 'OFF'}`;
    sortToggle.classList.toggle('active', isSortEnabled);
    updateOutputBoxes();
  };

  const copyToClipboard = (text, btn) => {
    const originalText = btn.textContent;
    const textArea = document.createElement("textarea");
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    try {
      document.execCommand('copy');
      btn.textContent = 'Copied!';
      setTimeout(() => btn.textContent = originalText, 1500);
    } catch (err) { console.error(err); }
    document.body.removeChild(textArea);
  };

  pasteBtn.onclick = async () => {
    try {
      const text = await navigator.clipboard.readText();
      input.value = text;
      out.textContent = 'Pasted Successfully.';
    } catch (err) {
      input.focus();
      const success = document.execCommand('paste');
      if (success) {
        out.textContent = 'Pasted (Fallback Mode)';
      } else {
        out.textContent = 'Manual Paste Required: Long-Press The Input Box.';
      }
    }
  };

  clearBtn.onclick = () => {
    input.value = '';
    out.textContent = 'Idle.';
    commaBox.value = '';
    pipeBox.value = '';
    lastWorkingDomains = [];
    copyComma.disabled = true;
    copyPipe.disabled = true;
  };

  checkBtn.onclick = async () => {
    const original = input.value.split(/[,\|\s\n]+/).map(d => d.trim()).filter(Boolean);
    if (!original.length) {
      out.innerHTML = `<span class="note">No Domains Detected.</span>`;
      return;
    }

    out.textContent = 'Checking...';
    checkBtn.disabled = true;

    const dnsMap = new Map();
    const checks = original.filter(d => !d.includes('.*')).map(d =>
      fetch(`https://dns.google/resolve?name=${d}&type=A`)
        .then(r => r.json())
        .then(j => dnsMap.set(d, !!j.Answer))
        .catch(() => dnsMap.set(d, false))
    );

    await Promise.all(checks);
    lastWorkingDomains = [];
    out.innerHTML = '';

    for (const d of original) {
      if (d.includes('.*')) {
        out.innerHTML += `<span class="skip">⏭ ${d} (Skipped Due To Wildcard .*)</span>\n`;
        lastWorkingDomains.push(d);
      } else if (dnsMap.get(d)) {
        out.innerHTML += `<span class="live">✅ ${d} (Live)</span>\n`;
        lastWorkingDomains.push(d);
      } else {
        out.innerHTML += `<span class="dead">❌ ${d} (Dead)</span>\n`;
      }
    }

    updateOutputBoxes();
    checkBtn.disabled = false;
  };

  copyComma.onclick = () => copyToClipboard(commaBox.value, copyComma);
  copyPipe.onclick = () => copyToClipboard(pipeBox.value, copyPipe);
})();
