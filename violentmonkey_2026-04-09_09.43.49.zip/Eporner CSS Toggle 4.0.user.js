// ==UserScript==
// @name         Eporner CSS Toggle 4.0
// @namespace    https://github.com/BlazeFTL
// @version      4.0
// @author       BlazeFTL
// @description  Toggle v1.3 CSS fix via a floating button
// @match        https://*.eporner.com/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let cssEnabled = false;

    // The CSS Fix (v1.3 logic)
    const styleContent = `
        .vjs-fullscreen #EPvideo_html5_api,
        .vjs-fullscreen .vjs-tech,
        video:-webkit-full-screen {
            width: 100% !important;
            height: 100% !important;
            object-fit: cover !important;
            top: 0 !important;
            left: 0 !important;
        }
        .video-js.vjs-fullscreen {
            width: 100vw !important;
            height: 100vh !important;
            background: #000 !important;
        }
    `;

    const styleTag = document.createElement('style');
    styleTag.id = 'blaze-toggle-css';

    // Create the Floating Button
    const btn = document.createElement('button');
    btn.innerHTML = 'FIX OFF';
    btn.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 999999;
        padding: 12px;
        background: #333;
        color: #fff;
        border: 2px solid #fff;
        border-radius: 8px;
        font-weight: bold;
        font-family: sans-serif;
        box-shadow: 0 4px 10px rgba(0,0,0,0.5);
    `;

    btn.onclick = () => {
        cssEnabled = !cssEnabled;
        if (cssEnabled) {
            styleTag.innerHTML = styleContent;
            document.head.appendChild(styleTag);
            btn.innerHTML = 'FIX ON';
            btn.style.background = '#e60000'; // Red when active
        } else {
            if (document.getElementById('blaze-toggle-css')) {
                styleTag.remove();
            }
            btn.innerHTML = 'FIX OFF';
            btn.style.background = '#333';
        }
    };

    document.body.appendChild(btn);
})();
