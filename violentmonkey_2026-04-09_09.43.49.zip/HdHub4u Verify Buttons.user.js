// ==UserScript==
// @name         HdHub4u Verify Buttons
// @namespace    https://github.com/BlazeFTL
// @description  Auto Click #verify_btn with specific text on selected domains
// @version      1.1
// @author       BlazeFTL
// @match        https://cryptonewz.one/*
// @match        https://inventoryidea.com/*
// @match        https://cryptoinsights.site/*
// @match        https://gadgetsweb.xyz/*
// @icon data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAMAAABF0y+mAAAAdVBMVEVHcEz8lkH9kEH2eDfyczPxeTbCiDTmEhzcNSHShnrTDhbvKSTiFR7FAQ/HAhD6HCXEBA/XDBfFAw/TERbFBQ/sGCDDAw/NBxK/Bw7FBBDpKCPkGB3ZDhjUDxfFBhDhqALRBxPJBhDDBQ/DAxDXmQblrQO5egBsU9utAAAAJ3RSTlMAMFThtoAKYxEBU0If//8uxam1+uQqY/897mOTesWKtuqXp2hXyiliZMLxAAAAwUlEQVR4AZ3JBQLDMAwEwSsapbjMDP9/Yp0UlFJozR40r9V+1frCTvdV7xshfWMfSikNY5VyQNzTU9ATJ4AJNACGlDZyL8SYJwCmGXIazdxvtN7PxzTKoRdMYIAFLQVX6/V6+MSYpY0gxTiHoJngNhbyOJ5pADq7ITbNY2CPrIjmB/Z3/5Bm+IsT2v/HwIe/eGT2P9FvRjPmLX7iZErMB7xwkeGJtjDr4DE8JBDcasTmc0iCf/rC80X6RNO/Sn007gaY6hUNygsV4wAAAABJRU5ErkJggg==
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const observer = new MutationObserver(() => {
        const btn = document.querySelector("#verify_btn");

        if (btn && btn.offsetParent !== null) {
            const btnText = btn.innerText.toLowerCase();
            const targetTexts = ["click to continue", "get links"];

            if (targetTexts.some(t => btnText.includes(t))) {
                btn.click();
            }
        }
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true
    });
})();
