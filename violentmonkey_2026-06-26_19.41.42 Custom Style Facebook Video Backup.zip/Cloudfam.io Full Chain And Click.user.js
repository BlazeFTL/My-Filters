// ==UserScript==
// @name         Cloudfam.io Full Chain And Click
// @namespace    https://github.com/BlazeFTL
// @description  Automates cloudfam redirection chain and clicks final download button
// @version      1.7
// @author       BlazeFTL
// @match        https://cloudfam.io/redirection*
// @match        https://cloudfam.io/*?*step=2*
// @match        https://cloudfam.io/*?slug=*
// @license      MIT
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const url = window.location.href;
    const urlParams = new URLSearchParams(window.location.search);
    const slug = urlParams.get('slug') || url.split('/').pop().split('?')[0];
    const token = urlParams.get('token');

    // --- STEP 1: Handle the Redirection Chain ---
    if (slug && token) {
        let nextUrl = '';

        if (url.includes('redirection0.php')) {
            nextUrl = `https://cloudfam.io/redirection.php?slug=${slug}&token=${token}`;
        }
        else if (url.includes('redirection.php') && !url.includes('redirection2') && !url.includes('redirection3')) {
            nextUrl = `https://cloudfam.io/redirection2.php?slug=${slug}&token=${token}`;
        }
        else if (url.includes('redirection2.php')) {
            nextUrl = `https://cloudfam.io/redirection3.php?slug=${slug}&token=${token}`;
        }
        else if (url.includes('redirection3.php')) {
            nextUrl = `https://cloudfam.io/${slug}?step=2&token=${token}`;
        }

        if (nextUrl) {
            window.location.replace(nextUrl);
            return; // Exit script to prevent further execution on this hop
        }
    }

    // --- STEP 2: Handle the Final Button Click ---
    if (url.includes('step=2')) {
        // We need the DOM for this, so we use an interval or wait for load
        const clickButton = () => {
            const btn = document.querySelector('#final-download-btn');
            if (btn) {
                btn.click();
                console.log('Final Download Button Clicked!');
                clearInterval(checkExist);
            }
        };

        const checkExist = setInterval(clickButton, 100);

        // Safety timeout to stop looking after 10 seconds
        setTimeout(() => clearInterval(checkExist), 10000);
    }
})();

