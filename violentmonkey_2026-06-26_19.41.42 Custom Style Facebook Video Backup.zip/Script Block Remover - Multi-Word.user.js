// ==UserScript==
// @name         Script Block Remover - Multi-Word
// @namespace    https://github.com/BlazeFTL
// @version      1.2
// @author       BlazeFTL
// @match        *://*/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // List all words you want to target here
    const poisonWords = [
        "adsUrl",
        "gateHtml",
        "elements.length",
        "baitAlt"
    ];

    // Create a combined Regex: (word1|word2|word3)
    const pattern = poisonWords.map(w => w.replace('.', '\\.')).join('|');

    /**
     * This improved Regex finds function blocks or logical blocks
     * containing ANY of your poison words.
     */
    const blockRegex = new RegExp(`function[^({]*?\\([^)]*?\\)\\s*{[^]*?\\b(${pattern})\\b[^]*?}(?=\\s*\\)|\\s*$)`, 'g');

    const cleanScript = (scriptSource) => {
        let modified = false;

        // Check if the script contains ANY of our words
        if (new RegExp(`\\b(${pattern})\\b`).test(scriptSource)) {
            console.log(`[BlazeFTL] Found target keywords. Neutralizing blocks...`);
            scriptSource = scriptSource.replace(blockRegex, (match) => {
                modified = true;
                return `function() { /* Block Purged */ }`;
            });
        }
        return scriptSource;
    };

    // --- DOM Observation Logic ---
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.tagName === 'SCRIPT' && node.textContent) {
                    const original = node.textContent;
                    const cleaned = cleanScript(original);
                    if (original !== cleaned) node.textContent = cleaned;
                }
            });
        });
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });

    // Initial check for existing scripts
    document.querySelectorAll('script').forEach(s => {
        const cleaned = cleanScript(s.textContent);
        if (s.textContent !== cleaned) s.textContent = cleaned;
    });
})();
