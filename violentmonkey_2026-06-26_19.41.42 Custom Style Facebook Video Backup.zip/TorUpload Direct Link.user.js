// ==UserScript==
// @name         TorUpload Direct Link
// @namespace    https://github.com/BlazeFTL
// @description  Fetches Gofile links directly from TorUpload API with modern UI
// @version      1.1
// @author       BlazeFTL
// @match        https://torupload.com/file/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const fileId = window.location.pathname.split('/').pop();
    if (!fileId) return;

    const createUI = (links) => {
        const container = document.createElement('div');
        container.style = `
            position: fixed;
            top: 15px;
            right: 15px;
            width: 300px;
            height: 150px;
            z-index: 999999;
            background: #ffffff;
            font-family: 'Segoe UI', Roboto, sans-serif;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(0,0,0,0.1);
        `;

        const header = document.createElement('div');
        header.style = `
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            padding: 10px 15px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12px;
            font-weight: 600;
        `;
        header.innerHTML = `<span>DIRECT LINKS FOUND</span>`;

        const listArea = document.createElement('div');
        listArea.style = `
            flex: 1;
            padding: 12px;
            background: #f8f9fa;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 8px;
        `;

        links.forEach(([provider, details]) => {
            if (!details.link) return;

            const row = document.createElement('div');
            row.style = `
                display: flex;
                align-items: center;
                gap: 8px;
                background: white;
                padding: 8px;
                border-radius: 8px;
                border: 1px solid #eee;
            `;

            const linkBtn = document.createElement('a');
            linkBtn.href = details.link;
            linkBtn.target = "_blank";
            linkBtn.innerText = provider.toUpperCase();
            linkBtn.style = `
                flex: 1;
                background: #2575fc;
                color: white;
                text-decoration: none;
                text-align: center;
                padding: 6px;
                border-radius: 5px;
                font-size: 11px;
                font-weight: bold;
                transition: opacity 0.2s;
            `;
            linkBtn.onmouseover = () => linkBtn.style.opacity = "0.8";
            linkBtn.onmouseout = () => linkBtn.style.opacity = "1";

            const copyBtn = document.createElement('button');
            copyBtn.innerText = 'COPY';
            copyBtn.style = `
                background: #f1f3f4;
                border: 1px solid #ddd;
                color: #555;
                padding: 5px 10px;
                border-radius: 5px;
                cursor: pointer;
                font-size: 10px;
                font-weight: bold;
            `;

            copyBtn.onclick = () => {
                navigator.clipboard.writeText(details.link);
                const old = copyBtn.innerText;
                copyBtn.innerText = 'DONE';
                copyBtn.style.background = '#4cd137';
                copyBtn.style.color = 'white';
                setTimeout(() => {
                    copyBtn.innerText = old;
                    copyBtn.style.background = '#f1f3f4';
                    copyBtn.style.color = '#555';
                }, 1500);
            };

            row.appendChild(linkBtn);
            row.appendChild(copyBtn);
            listArea.appendChild(row);
        });

        container.appendChild(header);
        container.appendChild(listArea);
        document.body.appendChild(container);
    };

    fetch(`/token/json.php?fileid=${fileId}`)
        .then(res => res.json())
        .then(data => {
            if (data && data.ppd) {
                const links = Object.entries(data.ppd).filter(([_, d]) => d.link);
                if (links.length > 0) createUI(links);
            }
        })
        .catch(err => console.error("[BlazeFTL] API Error:", err));

})();
