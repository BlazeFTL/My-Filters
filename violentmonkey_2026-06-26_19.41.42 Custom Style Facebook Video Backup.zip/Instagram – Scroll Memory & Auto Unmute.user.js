// ==UserScript==
// @name         Instagram – Scroll Memory & Auto Unmute
// @namespace    https://github.com/local/userscripts
// @version      4.4.0
// @match        https://www.instagram.com/*
// @grant        none
// @icon         https://www.google.com/s2/favicons?domain=www.instagram.com&sz=32
// @run-at       document-start
// ==/UserScript==

(function () {
  'use strict';

  // HIDE AUDIO TOGGLE BUTTON
  document.addEventListener('DOMContentLoaded', () => {
    const s = document.createElement('style');
    s.textContent = 'button[aria-label="Toggle audio"]{display:none!important}';
    document.head.appendChild(s);
  }, { once: true });

  // UNMUTE
  const nativeDesc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'muted');
  Object.defineProperty(HTMLMediaElement.prototype, 'muted', {
    get() { return nativeDesc.get.call(this); },
    set(val) {
      nativeDesc.set.call(this, val);
      if (val === true) {
        const el = this;
        setTimeout(() => { try { nativeDesc.set.call(el, false); } catch(_){} }, 80);
      }
    },
    configurable: true,
  });

  // SCROLL
  const REEL_RE  = /^\/[^/]+\/reel\/([^/]+)/;
  const REELS_RE = /^\/[^/]+\/reels\/?$/;
  const KEY_ID = 'ig_last_reel_id';
  const KEY_Y  = 'ig_last_scroll_y';

  let _y = 0;
  window.addEventListener('scroll', () => { _y = window.scrollY; }, { passive: true });

  function findReel(id) {
    return (
      document.querySelector(`a[href*="/reel/${id}/"]`) ||
      document.querySelector(`a[href*="/reel/${id}"]`) ||
      [...document.querySelectorAll('a[href*="/reel/"]')].find(a => a.href.includes(id))
    );
  }

  function restoreScroll(id, savedY) {
    if (!id && !savedY) return;

    let tries = 0;
    let restored = false;

    const t = setInterval(() => {
      tries++;

      // Try anchor
      const el = id && findReel(id);
      if (el) {
        clearInterval(t);
        el.scrollIntoView({ block: 'center', behavior: 'instant' });
        return;
      }

      // Fall back to Y — but keep re-applying every tick until scroll sticks
      // (Instagram may reset to 0 multiple times during hydration)
      if (savedY && window.scrollY < savedY - 50) {
        window.scrollTo({ top: savedY, behavior: 'instant' });
      }

      if (tries > 40) clearInterval(t); // stop after 8s
    }, 200);
  }

  function onNavigate(path) {
    const reelMatch = path.match(REEL_RE);

    if (reelMatch) {
      sessionStorage.setItem(KEY_ID, reelMatch[1]);
      sessionStorage.setItem(KEY_Y, String(_y));

    } else if (REELS_RE.test(path)) {
      const id     = sessionStorage.getItem(KEY_ID);
      const savedY = parseInt(sessionStorage.getItem(KEY_Y) || '0', 10);
      sessionStorage.removeItem(KEY_ID);
      sessionStorage.removeItem(KEY_Y);
      restoreScroll(id, savedY);
    }
  }

  ['pushState','replaceState'].forEach(m => {
    const orig = history[m].bind(history);
    history[m] = function(...a) {
      const r = orig(...a);
      try { onNavigate(new URL(a[2]||'', location.href).pathname); } catch(_){}
      return r;
    };
  });
  window.addEventListener('popstate', () => onNavigate(location.pathname));
  onNavigate(location.pathname);
})();
