// ==UserScript==
// @name         Ublock dupload.net Cookie Redirector If Element
// @namespace    https://github.com/BlazeFTL
// @description  Checks for the landing element before reading the videoLink cookie and redirecting.
// @version      1.1
// @author       BlazeFTL
// @match        *://health.bestwebhostingsites.biz/*
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    // Target landing container element from your cosmetic filters
    const TARGET_SELECTOR = '#wpsafelink-landing';

    function getCookie(name) {
        let nameEQ = name + "=";
        let ca = document.cookie.split(';');
        for(let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return decodeURIComponent(c.substring(nameEQ.length, c.length));
        }
        return null;
    }

    function tryRedirect() {
        if (document.querySelector(TARGET_SELECTOR)) {
            const videoLink = getCookie('videoLink');
            if (videoLink && videoLink.startsWith('http')) {
                window.location.href = videoLink;
            }
        }
    }

    // Run immediately
    tryRedirect();

    // Also watch for the element if it loads dynamically via AJAX/scripts
    const observer = new MutationObserver(() => {
        if (document.querySelector(TARGET_SELECTOR)) {
            tryRedirect();
            observer.disconnect();
        }
    });

    observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true
    });
})();
