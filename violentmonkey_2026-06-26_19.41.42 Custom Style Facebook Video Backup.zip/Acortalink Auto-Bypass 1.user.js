// ==UserScript==
// @name         Acortalink Auto-Bypass 1
// @namespace    https://github.com/BlazeFTL
// @description  Auto bypass acortalink.me
// @version      1.0
// @author       BlazeFTL
// @match        *://acortalink.*/*
// @match        *://*.acortalink.me/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    window.addEventListener("message", (e => {
        if (e?.data?.includes("__done__") && e?.data?.length < 9) {
            Object.defineProperty(e, "source", { value: "" });
        }
    }), true);

    const observer = new MutationObserver(() => {
        if (document.querySelector("a.button#contador")) {
            observer.disconnect();
            setTimeout(() => {
                window.postMessage("__done__", "*");
            }, 100);
        }
    });

    observer.observe(document, { childList: true, subtree: true });
})();
