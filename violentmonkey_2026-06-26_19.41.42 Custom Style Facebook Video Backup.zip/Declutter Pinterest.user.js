// ==UserScript==
// @name         Declutter Pinterest
// @namespace    August4067
// @version      1.6.1
// @description  Removes intrusive Pinterest shopping promotions, ads, and clutter, and makes the website more user-friendly
// @license      MIT
// @match        https://www.pinterest.com/*
// @match        https://*.pinterest.com/*
// @match        https://*.pinterest.co.uk/*
// @match        https://*.pinterest.fr/*
// @match        https://*.pinterest.de/*
// @match        https://*.pinterest.ca/*
// @match        https://*.pinterest.jp/*
// @match        https://*.pinterest.it/*
// @match        https://*.pinterest.au/*
// @icon         https://www.pinterest.com/favicon.ico
// @require      https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js
// @grant        GM_setValue
// @grant        GM_getValue
// @sandbox      Javascript
// @downloadURL https://update.greasyfork.org/scripts/512469/Declutter%20Pinterest.user.js
// @updateURL https://update.greasyfork.org/scripts/512469/Declutter%20Pinterest.meta.js
// ==/UserScript==

/*--- waitForKeyElements():  A utility function, for Greasemonkey scripts,
    that detects and handles AJAXed content.

    Usage example:

        waitForKeyElements (
            "div.comments"
            , commentCallbackFunction
        );

        //--- Page-specific function to do what we want when the node is found.
        function commentCallbackFunction (jNode) {
            jNode.text ("This comment changed by waitForKeyElements().");
        }

    IMPORTANT: This function requires your script to have loaded jQuery.
*/

// Pulled from: https://gist.github.com/raw/2625891/waitForKeyElements.js
function waitForKeyElements(
  selectorTxt /* Required: The jQuery selector string that
                        specifies the desired element(s).
                    */,
  actionFunction /* Required: The code to run when elements are
                        found. It is passed a jNode to the matched
                        element.
                    */,
  bWaitOnce /* Optional: If false, will continue to scan for
                        new elements even after the first match is
                        found.
                    */,
  iframeSelector /* Optional: If set, identifies the iframe to
                        search.
                    */,
) {
  var targetNodes, btargetsFound;

  if (typeof iframeSelector == "undefined") targetNodes = $(selectorTxt);
  else targetNodes = $(iframeSelector).contents().find(selectorTxt);

  if (targetNodes && targetNodes.length > 0) {
    btargetsFound = true;
    /*--- Found target node(s).  Go through each and act if they
            are new.
        */
    targetNodes.each(function () {
      var jThis = $(this);
      var alreadyFound = jThis.data("alreadyFound") || false;

      if (!alreadyFound) {
        //--- Call the payload function.
        var cancelFound = actionFunction(jThis);
        if (cancelFound) btargetsFound = false;
        else jThis.data("alreadyFound", true);
      }
    });
  } else {
    btargetsFound = false;
  }

  //--- Get the timer-control variable for this selector.
  var controlObj = waitForKeyElements.controlObj || {};
  var controlKey = selectorTxt.replace(/[^\w]/g, "_");
  var timeControl = controlObj[controlKey];

  //--- Now set or clear the timer as appropriate.
  if (btargetsFound && bWaitOnce && timeControl) {
    //--- The only condition where we need to clear the timer.
    clearInterval(timeControl);
    delete controlObj[controlKey];
  } else {
    //--- Set a timer, if needed.
    if (!timeControl) {
      timeControl = setInterval(function () {
        waitForKeyElements(
          selectorTxt,
          actionFunction,
          bWaitOnce,
          iframeSelector,
        );
      }, 300);
      controlObj[controlKey] = timeControl;
    }
  }
  waitForKeyElements.controlObj = controlObj;
}

// Inject CSS early to instantly hide elements before they render
(function injectEarlyCSS() {
  var style = document.createElement("style");
  style.textContent = `
    div[aria-label="Ad blocker modal"] { display: none !important; }

    /* Hide nav bar icons via body class toggles */
    body.dp-hide-updates #VerticalNavContent div:has(> [data-test-id="bell-icon"]) {
      display: none !important;
    }
    body.dp-hide-explore #VerticalNavContent div:has(> [data-test-id="vertical-nav-icon"] div[aria-label="Explore"]) {
      display: none !important;
    }
    body.dp-hide-messages #VerticalNavContent div:has(> div > [data-test-id="vertical-nav-icon"] div[aria-label="Messages"]) {
      display: none !important;
    }

    /* Hide comments on pin closeup */
    body.dp-hide-comments [data-test-id="canonical-card"],
    body.dp-hide-comments [data-test-id="inline-comment-composer-container"],
    body.dp-hide-comments div[aria-label="Comments"] {
      display: none !important;
    }
  `;
  document.documentElement.appendChild(style);
})();

// We will set the Pinterest page title to this, to remove
// the flashing title notifications like Pinterest (2)
const ORIGINAL_TITLE = "Pinterest";

const UI_TEXT = {
  settings_tooltip: "Declutter Pinterest settings have moved here!",
};

const SETTINGS_CONFIG = {
  removeShoppablePins: {
    displayName: "Hide shoppable Pins",
    default: true,
  },
  hideComments: {
    displayName: "Hide Pin comments",
    default: false,
  },
  hideMessages: {
    displayName: "Hide Messages icon",
    default: false,
  },
  hideUpdates: {
    displayName: "Hide Updates icon",
    default: true,
  },
  hideExplore: {
    displayName: "Hide Explore icon",
    default: true,
  }
};

class Setting {
  constructor(name, config) {
    this.name = name;
    this.displayName = config.displayName;
    this.default = config.default;
  }

  currentValue() {
    return GM_getValue(this.name, this.default);
  }

  toggleSetting() {
    GM_setValue(this.name, !this.currentValue());
  }
}

// Create settings object by mapping config to Setting instances
const SETTINGS = Object.fromEntries(
  Object.entries(SETTINGS_CONFIG).map(([name, config]) => [
    name,
    new Setting(name, config),
  ]),
);



// NAV BAR TOGGLE
function applyNavToggles() {
  if (!document.body) return;
  document.body.classList.toggle("dp-hide-messages", SETTINGS.hideMessages.currentValue());
  document.body.classList.toggle("dp-hide-updates", SETTINGS.hideUpdates.currentValue());
  document.body.classList.toggle("dp-hide-explore", SETTINGS.hideExplore.currentValue());
  document.body.classList.toggle("dp-hide-comments", SETTINGS.hideComments.currentValue());
}

// SETTINGS PANEL UI — injected into Pinterest's Settings & Support sidebar panel
function createSettingsPanel() {
  var style = document.createElement("style");
  style.textContent = `
    .dp-row {
      display: flex; align-items: center; justify-content: space-between;
      padding: 8px 16px; gap: 12px;
    }
    .dp-row:hover { background: var(--sema-color-hover-background-elevation, rgba(0,0,0,.03)); }
    .dp-info { flex: 1; min-width: 0; }
    .dp-name {
      display: block; font-weight: 600; color: #111;
      font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
    }
    .dp-switch { position: relative; display: inline-block; width: 36px; height: 20px; flex-shrink: 0; }
    .dp-switch input { opacity: 0; width: 0; height: 0; position: absolute; }
    .dp-knob {
      position: absolute; inset: 0; background: #d1d1d1;
      border-radius: 20px; cursor: pointer;
      transition: background .2s;
    }
    .dp-knob::before {
      content: ''; position: absolute;
      width: 14px; height: 14px; left: 3px; bottom: 3px;
      background: #fff; border-radius: 50%;
      transition: transform .2s;
      box-shadow: 0 1px 3px rgba(0,0,0,.22);
    }
    .dp-switch input:checked ~ .dp-knob { background: #e60023; }
    .dp-switch input:checked ~ .dp-knob::before { transform: translateX(16px); }
    .dp-switch input:focus-visible ~ .dp-knob { outline: 2px solid #e60023; outline-offset: 2px; }
    .dp-section { border-top: 1px solid var(--sema-color-border-default, #cdcdcd); border-bottom: 1px solid var(--sema-color-border-default, #cdcdcd); padding: 8px 0; margin: 8px 0; }
    .dp-section-heading {
      padding: 8px 16px; font-weight: 600; font-size: 14px;
      color: var(--sema-color-text-subtle, #767676);
    }
  `;
  document.documentElement.appendChild(style);

  var navSettings = new Set(["hideMessages", "hideUpdates", "hideExplore", "hideComments"]);

  function injectIntoPanel(panel) {
    // Don't inject twice
    if (panel.querySelector("#dp-settings-section")) return;

    var section = document.createElement("div");
    section.id = "dp-settings-section";
    section.setAttribute("aria-label", "Declutter Pinterest");
    section.className = "dp-section";

    var settingRows = Object.entries(SETTINGS)
      .map(function ([name, setting]) {
        return `
          <div class="dp-row">
            <div class="dp-info">
              <span class="dp-name">${setting.displayName}</span>
            </div>
            <label class="dp-switch">
              <input type="checkbox" data-setting="${name}" ${setting.currentValue() ? "checked" : ""}>
              <span class="dp-knob"></span>
            </label>
          </div>`;
      })
      .join("");

    section.innerHTML = `
      <div class="dp-section-heading">Declutter Pinterest</div>
      ${settingRows}
    `;

    // Insert after "Refine your recommendations" (#homefeed-tuner's parent wrapper)
    var refineItem = panel.querySelector("#homefeed-tuner");
    var refineLink = refineItem?.closest("a");
    var refineWrapper = refineLink?.parentElement;
    if (refineWrapper) {
      refineWrapper.after(section);
    } else {
      // Fallback: insert before the "Support" section (found via stable data-test-id)
      var helpLink = panel.querySelector('[data-test-id="header-menu-options-help"]');
      var supportSection = helpLink?.closest('#side-bar-settings-panel > div');
      if (supportSection) {
        supportSection.before(section);
      } else {
        panel.appendChild(section);
      }
    }

    section.querySelectorAll('input[type="checkbox"]').forEach(function (cb) {
      cb.addEventListener("change", function (e) {
        e.stopPropagation();
        var settingName = cb.dataset.setting;
        var setting = SETTINGS[settingName];
        setting.toggleSetting();
        console.debug(
          `Setting ${settingName} set to: ${setting.currentValue()}`,
        );
        if (navSettings.has(settingName)) {
          applyNavToggles();
        } else {
          location.reload();
        }
      });
    });
  }

  // Show a one-time tooltip on the settings gear so users know where settings moved
  function showSettingsTooltip() {
    if (GM_getValue("dp_tooltip_shown", false)) return;

    var settingsBtn = document.querySelector('[data-test-id="vertical-nav-settings-button"]');
    if (!settingsBtn) return;

    GM_setValue("dp_tooltip_shown", true);

    var tooltip = document.createElement("div");
    tooltip.id = "dp-settings-tooltip";
    tooltip.innerHTML = `
      <span>${UI_TEXT.settings_tooltip}</span>
      <button aria-label="Dismiss">&times;</button>
    `;

    // Position relative to the button on the screen to avoid sidebar clipping
    var rect = settingsBtn.getBoundingClientRect();
    tooltip.style.top = (rect.top + rect.height / 2) + "px";
    tooltip.style.left = (rect.right + 12) + "px";

    document.body.appendChild(tooltip);

    var dismiss = function () {
      tooltip.remove();
    };
    tooltip.querySelector("button").addEventListener("click", dismiss);
    setTimeout(dismiss, 8000);
  }

  var tooltipStyle = document.createElement("style");
  tooltipStyle.textContent = `
    #dp-settings-tooltip {
      position: fixed;
      background: #e60023; color: #fff;
      padding: 8px 12px;
      border-radius: 8px;
      font-size: 13px; font-weight: 600;
      white-space: nowrap;
      display: flex; align-items: center; gap: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,.2);
      z-index: 10001; /* High z-index to stay above main content */
      transform: translateY(-50%);
      animation: dp-tooltip-in .3s ease-out;
    }
    #dp-settings-tooltip::before {
      content: '';
      position: absolute; left: -6px; top: 50%;
      transform: translateY(-50%);
      border: 6px solid transparent;
      border-right-color: #e60023;
      border-left: none;
    }
    #dp-settings-tooltip button {
      background: none; border: none; color: #fff;
      font-size: 16px; cursor: pointer; padding: 0; line-height: 1;
    }
    @keyframes dp-tooltip-in {
      from { opacity: 0; transform: translateY(-50%) translateX(-8px); }
      to   { opacity: 1; transform: translateY(-50%) translateX(0); }
    }
  `;
  document.documentElement.appendChild(tooltipStyle);

  // Watch for the settings sidebar panel to appear
  var observer = new MutationObserver(function () {
    var panel = document.getElementById("side-bar-settings-panel");
    if (panel) {
      injectIntoPanel(panel);
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  // Show tooltip once nav is loaded
  var navObserver = new MutationObserver(function () {
    if (document.querySelector('[data-test-id="vertical-nav-settings-button"]')) {
      showSettingsTooltip();
      navObserver.disconnect();
    }
  });
  navObserver.observe(document.documentElement, { childList: true, subtree: true });
}

// HELPER FUNCTIONS
function waitAndRemove(selector, removeFunction) {
  if (removeFunction == undefined) {
    removeFunction = (elem) => collapseElement(elem);
  }

  waitForKeyElements(selector, function (node) {
    if (node && node.length > 0) {
      removeFunction(node[0]);
    }
  });
}

/**
 * Collapse an element to zero dimensions while keeping it in the DOM
 * This prevents layout gaps while preserving DOM structure for JavaScript
 * Also configures parent grid container to automatically fill gaps
 * @param {HTMLElement} element - The DOM element to collapse
 */
function collapseElement(element) {
  if (element) {
    element.style.setProperty("height", "0", "important");
    element.style.setProperty("width", "0", "important");
    element.style.setProperty("margin", "0", "important");
    element.style.setProperty("padding", "0", "important");
    element.style.setProperty("border", "none", "important");
    element.style.setProperty("overflow", "hidden", "important");
    element.style.setProperty("opacity", "0", "important");
    element.style.setProperty("min-height", "0", "important");
    element.style.setProperty("min-width", "0", "important");

    // Configure parent grid container to auto-fill gaps left by collapsed elements
    const listContainer = element.closest('div[role="list"]');
    if (listContainer && !listContainer.dataset.gridFixed) {
      // Only apply once per container
      listContainer.style.setProperty("grid-auto-flow", "dense", "important");
      listContainer.dataset.gridFixed = "true";
    }
  }
}

function isFeaturedBoard(pin) {
  if (
    pin.textContent.trim().toLowerCase().startsWith("explore featured boards")
  ) {
    return true;
  } else if (
    pin.textContent.trim().toLowerCase().startsWith("still window shopping")
  ) {
    return true;
  }
  return false;
}

function isShoppingCard(pin) {
  if (
    pin
      .querySelector("h2#comments-heading")
      ?.textContent.toLowerCase()
      .startsWith("shop")
  ) {
    return true;
  } else if (
    pin
      .querySelector("a")
      ?.getAttribute("aria-label")
      ?.toLowerCase()
      .startsWith("shop")
  ) {
    return true;
  } else if (
    // TODO - refine this condition
    pin.querySelector("h2")?.textContent.trim().toLowerCase().startsWith("shop")
  ) {
    return true;
  }
  return false;
}

function isShoppablePin(pin) {
  return pin.querySelector('[aria-label="Shoppable Pin indicator"]') != null;
}

function isSponsoredPin(pin) {
  return pin.querySelector('div[title="Sponsored"]') != null;
}

// FUNCTIONS THAT REMOVE
function removeClutterPins(pins) {
  const filters = [isShoppingCard, isFeaturedBoard, isSponsoredPin];

  // Only add the shoppable pins filter if the setting is enabled
  if (SETTINGS.removeShoppablePins.currentValue()) {
    filters.push(isShoppablePin);
  }

  pins.forEach((pin) => {
    if (filters.some((test) => test(pin))) {
      collapseElement(pin);
    }
  });
}

// In the #SuggestionsMenu
function removePopularOnPinterestSearchSuggestions() {
  waitAndRemove('div[data-test-id="search-story-suggestions-container"]');
}

function removeBrandedSearchSuggestions() {
  waitAndRemove('div[data-test-id="enriched-search-suggestion"]', (node) => {
    // Collapse the entire suggestion option containing the branded result
    var suggestionOption = node.closest('[data-test-id="search-suggestion"]');
    if (suggestionOption) {
      collapseElement(suggestionOption);
    }
  });
}

function setupSearchSuggestionsRemoval() {
  waitAndRemove("#searchBoxContainer", (node) => {
    const observer = new MutationObserver(() => {
      removePopularOnPinterestSearchSuggestions();
      removeBrandedSearchSuggestions();
    });
    observer.observe(node, { childList: true, subtree: true });
  });
}

// FUNCTION THAT SETUP OBSERVERS
function setupPinFiltering() {
  waitAndRemove('div[role="list"]', (node) => {
    var pinListMutationObserver = new MutationObserver(
      (mutations, observer) => {
        removeClutterPins(node.querySelectorAll('div[role="listitem"]'));
      },
    );
    pinListMutationObserver.observe(node, {
      childList: true,
      subtree: true,
    });
  });
}

function setupShopButtonRemovalFromBoardTools() {
  waitAndRemove('div[data-test-id="board-tools"] div[data-test-id="Shop"]');
}

function removeDownloadUpsellPopover() {
  waitAndRemove('div[data-test-id="post-download-upsell-popover"]');
}

function removeAdBlockerModal() {
  waitAndRemove('div[aria-label="Ad blocker modal"]', (node) => {
    // Remove the modal and its backdrop
    collapseElement(node);
    // Restore body scrolling that Pinterest disables when the modal is shown
    document.body.style.removeProperty("overflow");
  });
}

function removeExploreTabNotificationsIcon() {
  // --- Remove notification icon from Explore tab in the top nav (old behavior)
  var exploreTab = document.querySelector('div[data-test-id="today-tab"]');
  if (exploreTab) {
    var notificationsIcon = exploreTab.querySelector(
      'div[aria-label="Notifications"]',
    );
    collapseElement(notificationsIcon);
  }

  // --- Remove notification badge from Explore tab in the sidebar (new behavior)
  // Find the Explore tab link in the sidebar
  var exploreTabLink = document.querySelector('a[data-test-id="today-tab"]');
  if (exploreTabLink) {
    // The parent of the link is the icon container, its parent is the sidebar item
    var iconContainer = exploreTabLink.closest('div[class*="XiG"]');
    var sidebarItem = iconContainer?.parentElement?.parentElement;
    if (sidebarItem) {
      // The notification badge is a sibling div with class "MIw" and pointer-events: none
      var notificationBadge = sidebarItem.parentElement?.querySelector(
        '.MIw[style*="pointer-events: none"]',
      );
      if (notificationBadge) {
        collapseElement(notificationBadge);
      }
    }
  }
}

function setupSidebarObserverForExploreNotifications() {
  // Find the sidebar navigation container (adjust selector if needed)
  const sidebarNav =
    document.querySelector('nav[id="VerticalNavContent"]') ||
    document.querySelector('div[role="navigation"]');
  if (!sidebarNav) {
    // Try again later if sidebar not yet loaded
    setTimeout(setupSidebarObserverForExploreNotifications, 500);
    return;
  }
  // Remove any existing badge immediately
  removeExploreTabNotificationsIcon();

  // Set up observer
  const observer = new MutationObserver(() => {
    removeExploreTabNotificationsIcon();
  });
  observer.observe(sidebarNav, { childList: true, subtree: true });
}

function removeProductCloseupContent() {
  waitForKeyElements(
    'div[data-test-id="description-content-container"]',
    function (node) {
      var container = node[0];
      // Detect product pins by the presence of product-specific elements
      if (
        container.querySelector('[data-test-id="product-price"]') ||
        container.querySelector('[data-test-id="product-title"]') ||
        container.querySelector('[data-test-id="product-shop-button"]')
      ) {
        // Collapse product content but keep the sticky action bar (save, react, share, etc.)
        Array.from(container.children).forEach(function (child) {
          if (child.dataset.testId !== "closeup-body-sticky-content") {
            collapseElement(child);
          }
        });
      }
    },
  );
}

function removeShopTheLookSections() {
  if (!SETTINGS.removeShoppablePins.currentValue()) return;
  waitForKeyElements('div[title="Shop the look"]', function (node) {
    var shopTheLookText = node[0];
    // Walk up from the text element to the "Shop the look" container
    // Structure: div.container > div[role="button"] > ... > div[title="Shop the look"]
    var buttonWrapper = shopTheLookText.closest('[role="button"]');
    if (buttonWrapper && buttonWrapper.parentElement) {
      collapseElement(buttonWrapper.parentElement);
    }
  });
}

function removeShopByBanners() {
  waitForKeyElements('div[data-test-id="sf-header-heading"]', function (node) {
    var shopByBannerAtTopOfBoard = node[0].closest(
      'div[class="PKX zI7 iyn Hsu"]',
    );
    collapseElement(shopByBannerAtTopOfBoard);

    var baseBoardPinGrid = node[0].closest(
      'div[data-test-id="base-board-pin-grid"]',
    );
    if (baseBoardPinGrid) {
      var shopByBannerAtBottomOfBoard = node[0].closest(
        'div[class="gcw zI7 iyn Hsu"]',
      );
      collapseElement(shopByBannerAtBottomOfBoard);

      // Handle "More products" banner (text-based detection for resilience)
      var moreProductsBannerAtBottomOfBoard = node[0].querySelector("h2");
      if (
        moreProductsBannerAtBottomOfBoard &&
        moreProductsBannerAtBottomOfBoard.innerText
          ?.trim()
          .toLowerCase()
          .startsWith("more products")
      ) {
        // Traverse up from the h2 to find the direct child of base-board-pin-grid
        // This ensures we hide only the "More products inspired by this board" section
        var moreProductsContainer = node[0];
        var maxIterations = 20; // Safety limit to prevent infinite loops
        var iterations = 0;

        while (
          moreProductsContainer &&
          moreProductsContainer.parentElement !== baseBoardPinGrid &&
          iterations < maxIterations
        ) {
          moreProductsContainer = moreProductsContainer.parentElement;
          iterations++;
        }

        // Only collapse if we successfully found the container
        if (
          moreProductsContainer &&
          moreProductsContainer.parentElement === baseBoardPinGrid
        ) {
          collapseElement(moreProductsContainer);
        }
      }
    }

    if (node[0]?.innerText.trim().toLowerCase().startsWith("shop products")) {
      var shopProductsBanner = node[0].closest('div[class*="gcw zI7"]');
      collapseElement(shopProductsBanner);
    }
    var shopByBannerAtTopOfSearch = node[0].closest('div[role="listitem"]');
    collapseElement(shopByBannerAtTopOfSearch);
  });
}

function main() {
  "use strict";

  createSettingsPanel();
  applyNavToggles();

  setupPinFiltering();
  setupShopButtonRemovalFromBoardTools();
  setupSidebarObserverForExploreNotifications();
  setupSearchSuggestionsRemoval();

  removeShopByBanners();
  removeShopTheLookSections();
  removeProductCloseupContent();
  removeDownloadUpsellPopover();
  removeAdBlockerModal();
}

main();

let lastUrl = window.location.href;
setInterval(() => {
  const currentUrl = window.location.href;
  if (currentUrl !== lastUrl) {
    console.debug(
      `Detected new page, currentURL=${currentUrl}, previousURL=${lastUrl}`,
    );
    lastUrl = currentUrl;
    main();
  }
}, 750);
