// ==UserScript==
// @name         TorUpload Resource Spoof 3.5
// @namespace    https://github.com/BlazeFTL
// @description  Spoof perf entries from live DOM scan + self-cleanup
// @version      3.4
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const nativeToString = Function.prototype.toString;

    function makeNative(fn, original) {
        const name = original.name || '';
        fn.toString = function() {
            return `function ${name}() { [native code] }`;
        };
        return fn;
    }

    const _e = [];
    const _seen = new Set();

    function addEntry(url, type) {
        if (!url || _seen.has(url)) return;
        try { new URL(url); } catch { return; }
        _seen.add(url);
        _e.push({ url, type: type || 'script', d: Math.floor(Math.random() * 900) + 30 });
    }

    // Scan existing nodes (may exist at document-start if script injected late)
    function scanNode(node) {
        if (!node || !node.tagName) return;
        const tag = node.tagName.toUpperCase();
        if (tag === 'SCRIPT' && node.src) addEntry(node.src, 'script');
        else if (tag === 'LINK' && node.rel === 'stylesheet' && node.href) addEntry(node.href, 'css');
        else if (tag === 'IMG' && node.src) addEntry(node.src, 'img');
    }

    // Hook createElement to intercept src before element appended
    const _origCreate = Document.prototype.createElement;
    Document.prototype.createElement = makeNative(function createElement(tag) {
        const el = _origCreate.apply(this, arguments);
        if (typeof tag === 'string' && tag.toLowerCase() === 'script') {
            const proto = HTMLScriptElement.prototype;
            const srcDesc = Object.getOwnPropertyDescriptor(proto, 'src');
            Object.defineProperty(el, 'src', {
                set(val) {
                    addEntry(val, 'script');
                    srcDesc.set.call(this, val);
                },
                get() { return srcDesc.get.call(this); },
                configurable: true
            });
        }
        return el;
    }, _origCreate);

    // MutationObserver for dynamically injected nodes
    const observer = new MutationObserver(mutations => {
        for (const m of mutations) {
            for (const node of m.addedNodes) scanNode(node);
        }
    });
    observer.observe(document.documentElement || document, { childList: true, subtree: true });

    const generateEntry = (item) => ({
        name: item.url,
        initiatorType: item.type,
        duration: item.d,
        startTime: Math.random() * 100,
        entryType: 'resource',
        nextHopProtocol: 'h2',
        renderBlockingStatus: 'non-blocking',
        workerStart: 0, redirectStart: 0, redirectEnd: 0,
        fetchStart: 10, domainLookupStart: 10, domainLookupEnd: 12,
        connectStart: 12, connectEnd: 15, secureConnectionStart: 13,
        requestStart: 16, responseStart: 20, responseEnd: item.d + 20,
        transferSize: Math.floor(Math.random() * 5000) + 1000,
        encodedBodySize: 1000, decodedBodySize: 3000, serverTiming: []
    });

    const _p = Performance.prototype;
    const _getEntries       = _p.getEntries;
    const _getEntriesByType = _p.getEntriesByType;
    const _getEntriesByName = _p.getEntriesByName;

    _p.getEntries = makeNative(function() {
        return [..._getEntries.apply(this, arguments), ..._e.map(generateEntry)];
    }, _getEntries);

    _p.getEntriesByType = makeNative(function(type) {
        const real = _getEntriesByType.apply(this, arguments);
        return type === 'resource' ? [...real, ..._e.map(generateEntry)] : real;
    }, _getEntriesByType);

    _p.getEntriesByName = makeNative(function(name) {
        const item = _e.find(x => x.url === name);
        return item ? [generateEntry(item)] : _getEntriesByName.apply(this, arguments);
    }, _getEntriesByName);

    const _fnToString = Function.prototype.toString;
    Object.defineProperty(Function.prototype, 'toString', {
        value: makeNative(function toString() {
            if (this === Function.prototype.toString) return 'function toString() { [native code] }';
            return nativeToString.call(this);
        }, _fnToString),
        writable: true,
        configurable: true
    });

    // Cleanup: remove injected <script> tag from DOM, restore createElement, disconnect observer
    const _selfScript = document.currentScript;
    window.addEventListener('load', () => {
        observer.disconnect();
        Document.prototype.createElement = _origCreate;
        if (_selfScript && _selfScript.parentNode) _selfScript.remove();
    }, { once: true });

    // Also try immediate removal (works if TM injected synchronously)
    if (_selfScript && _selfScript.parentNode) _selfScript.remove();

})();
