// ==UserScript==
// @name         AroLinks 1 Page Match Url
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Zero-Config: Logic is pulled directly from @match lines
// @author       BlazeFTL
// @match        https://newsfront.xyz/eduuniversty/?smartstudy=*
// @match        https://newsfront.xyz/*
// @match        https://naukaritimes24.in/studyabroad/?abroad=*
// @match        https://naukaritimes24.in/*
// @match        https://dharona.in/studyscholarship/?scholrshipstudy=*
// @match        https://dharona.in/*
// @run-at       document-start
// @grant        none
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    const url = window.location.href;
    const params = new URLSearchParams(window.location.search);

    // 1. DYNAMIC CONFIG FROM METADATA
    // Pulls all @match lines. We filter for lines that look like triggers (contain '?')
    const matches = (typeof GM_info !== 'undefined' ? GM_info.script.matches : []) || [];
    const triggerConfigs = matches
        .filter(m => m.includes('?'))
        .map(m => {
            const clean = m.replace(/\*/g, '');
            const paramName = clean.split('?')[1]?.split('=')[0];
            const domain = clean.split('//')[1]?.split('/')[0];
            return { domain, paramName };
        });

    // 2. QUICK CAPTURE
    // Check if current URL matches any of our @match trigger domains/params
    triggerConfigs.forEach(conf => {
        if (url.includes(conf.domain) && params.has(conf.paramName)) {
            const targetId = params.get(conf.paramName);
            if (targetId) {
                localStorage.setItem("blaze_id", targetId);
                console.log("ID Saved from " + conf.domain + ": " + targetId);
            }
        }
    });

    // 3. UI LOGIC
    const savedId = localStorage.getItem("blaze_id");

    // Safety check: Don't show UI if we are currently on a capture/trigger URL
    const isTriggerPage = triggerConfigs.some(conf => params.has(conf.paramName));

    if (savedId && !isTriggerPage) {
        const injectUI = () => {
            if (document.getElementById('blaze-timer-overlay')) return;

            const overlay = document.createElement('div');
            overlay.id = 'blaze-timer-overlay';
            overlay.style.cssText = `
                position: fixed !important; top: 0; left: 0; width: 100%; height: 100%;
                background: #111 !important; z-index: 2147483647 !important;
                display: flex; align-items: center; justify-content: center;
                flex-direction: column; color: white; font-family: sans-serif;
            `;

            overlay.innerHTML = `
                <div style="padding: 40px; border-radius: 20px; background: #222; border: 1px solid #444; text-align: center;">
                    <h2 style="margin: 0; color: #00d4ff;">Link Processing</h2>
                    <div id="blaze-num" style="font-size: 80px; font-weight: bold; margin: 20px 0;">20</div>
                    <p style="color: #aaa;">Redirecting to Arolinks in <span id="sec">20</span>s</p>
                </div>
            `;

            (document.body || document.documentElement).appendChild(overlay);

            let seconds = 20;
            const timerInterval = setInterval(() => {
                seconds--;
                const numEl = document.getElementById('blaze-num');
                const secEl = document.getElementById('sec');
                if(numEl) numEl.innerText = seconds;
                if(secEl) secEl.innerText = seconds;

                if (seconds <= 0) {
                    clearInterval(timerInterval);
                    localStorage.removeItem("blaze_id");
                    window.location.replace("https://arolinks.com/" + savedId);
                }
            }, 1000);
        };

        // Aggressive Persistence
        const observer = new MutationObserver(() => {
            if (!document.getElementById('blaze-timer-overlay')) injectUI();
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', injectUI);
        } else {
            injectUI();
        }
    }
})();

