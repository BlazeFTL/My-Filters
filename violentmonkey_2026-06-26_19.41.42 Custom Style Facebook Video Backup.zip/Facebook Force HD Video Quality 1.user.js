// ==UserScript==
// @name         Facebook Force HD Video Quality 1
// @namespace    https://github.com/BlazeFTL
// @description  Forces Facebook to play videos in high quality by spoofing high network speeds and HD preferences.
// @version      1.0
// @author       BlazeFTL
// @match        *://*.facebook.com/*
// @run-at       document-start
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    // Spoof Network Information API to trick Facebook's Adaptive Bitrate (ABR) system
    const networkProps = {
        effectiveType: '4g',
        downlink: 100,
        rtt: 5,
        saveData: false
    };

    if (navigator.connection) {
        for (const prop in networkProps) {
            try {
                Object.defineProperty(navigator.connection, prop, {
                    get: () => networkProps[prop],
                    configurable: true,
                    enumerable: true
                });
            } catch (e) {}
        }
    }

    if (window.NetworkInformation && window.NetworkInformation.prototype) {
        for (const prop in networkProps) {
            try {
                Object.defineProperty(window.NetworkInformation.prototype, prop, {
                    get: () => networkProps[prop],
                    configurable: true,
                    enumerable: true
                });
            } catch (e) {}
        }
    }

    // Force HD markers inside LocalStorage configurations
    const forceHDPrefs = () => {
        try {
            localStorage.setItem('video_quality_setting', 'hd');
            localStorage.setItem('hb_video_quality', 'hd');
            localStorage.setItem('video_bandwidth_estimate', '50000000');
        } catch (e) {}
    };
    forceHDPrefs();

    // Intercept script-level modifications to tracking metrics
    const rawSetItem = Storage.prototype.setItem;
    Storage.prototype.setItem = function(key, value) {
        if (key.includes('video_quality') || key.includes('bandwidth')) {
            if (key.includes('estimate')) {
                value = '50000000';
            } else {
                value = 'hd';
            }
        }
        rawSetItem.apply(this, [key, value]);
    };
})();
