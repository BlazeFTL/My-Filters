// ==UserScript==
// @name         TorUpload Resource Spoof 3.8 No Remove At End
// @namespace    https://github.com/BlazeFTL
// @description  Spoof perf entries from live DOM scan + self-cleanup
// @version      3.6
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1. Capture genuine native states immediately
    const nativeToString = Function.prototype.toString;
    const _origCreate = Document.prototype.createElement;

    function makeNative(fn, original) {
        const name = original ? (original.name || '') : '';
        fn.toString = function() { return `function ${name}() { [native code] }`; };
        return fn;
    }

    const _e = [];
    const _seen = new Set();

    function addEntry(url, type) {
        if (!url || _seen.has(url)) return;
        try { new URL(url); } catch { return; }
        _seen.add(url);
        _e.push({ url, type: type || 'script', d: Math.floor(Math.random() * 900) + 30 });
    }

    function findDescriptor(obj, prop) {
        let proto = obj;
        while (proto) {
            const d = Object.getOwnPropertyDescriptor(proto, prop);
            if (d) return d;
            proto = Object.getPrototypeOf(proto);
        }
    }

    function scanNode(node) {
        if (!node || !node.tagName) return;
        const tag = node.tagName.toUpperCase();
        if (tag === 'SCRIPT' && node.src) addEntry(node.src, 'script');
        else if (tag === 'LINK' && node.rel === 'stylesheet' && node.href) addEntry(node.href, 'css');
        else if (tag === 'IMG' && node.src) addEntry(node.src, 'img');
    }

    // Hook createElement safely
    Document.prototype.createElement = makeNative(function createElement(tag) {
        const el = _origCreate.apply(this, arguments);
        if (typeof tag === 'string' && tag.toLowerCase() === 'script') {
            const srcDesc = findDescriptor(HTMLScriptElement.prototype, 'src');
            if (srcDesc && srcDesc.set) {
                Object.defineProperty(el, 'src', {
                    set(val) { addEntry(val, 'script'); srcDesc.set.call(this, val); },
                    get() { return srcDesc.get.call(this); },
                    configurable: true
                });
            }
        }
        return el;
    }, _origCreate);

    // Track dynamic DOM modifications
    const observer = new MutationObserver(mutations => {
        for (const m of mutations) {
            if (m.addedNodes) {
                for (let i = 0; i < m.addedNodes.length; i++) scanNode(m.addedNodes[i]);
            }
        }
    });
    observer.observe(document.documentElement || document, { childList: true, subtree: true });

    const generateEntry = (item) => ({
        name: item.url,
        initiatorType: item.type,
        duration: item.d,
        startTime: Math.random() * 100,
        entryType: 'resource',
        nextHopProtocol: 'h2',
        renderBlockingStatus: 'non-blocking',
        workerStart: 0, redirectStart: 0, redirectEnd: 0,
        fetchStart: 10, domainLookupStart: 10, domainLookupEnd: 12,
        connectStart: 12, connectEnd: 15, secureConnectionStart: 13,
        requestStart: 16, responseStart: 20, responseEnd: item.d + 20,
        transferSize: Math.floor(Math.random() * 5000) + 1000,
        encodedBodySize: 1000, decodedBodySize: 3000, serverTiming: []
    });

    // Prototype adjustments
    const _p = Performance.prototype;
    const _getEntries       = _p.getEntries;
    const _getEntriesByType = _p.getEntriesByType;
    const _getEntriesByName = _p.getEntriesByName;

    _p.getEntries = makeNative(function() {
        return [..._getEntries.apply(this, arguments), ..._e.map(generateEntry)];
    }, _getEntries);

    _p.getEntriesByType = makeNative(function(type) {
        const real = _getEntriesByType.apply(this, arguments);
        return type === 'resource' ? [...real, ..._e.map(generateEntry)] : real;
    }, _getEntriesByType);

    _p.getEntriesByName = makeNative(function(name) {
        const item = _e.find(x => x.url === name);
        return item ? [generateEntry(item)] : _getEntriesByName.apply(this, arguments);
    }, _getEntriesByName);

    // Global toString masquerade
    Object.defineProperty(Function.prototype, 'toString', {
        value: makeNative(function toString() {
            if (this === Function.prototype.toString) return 'function toString() { [native code] }';
            return nativeToString.call(this);
        }, nativeToString),
        writable: true,
        configurable: true
    });

    // Removed restoration cleanup on load so definitions stick permanently throughout native execution
})();
