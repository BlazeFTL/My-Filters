// ==UserScript==
// @name         Background Timer + Audio (Non-Invasive Heartbeat)
// @namespace    http://tampermonkey.net/
// @version      4.0
// @description  Bypasses Cloudflare by NOT overriding timers. Uses Worker-Pulse + Audio to keep the tab awake.
// @author       BlazeFTL
// @match        *://*/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=firefox.com
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    // --- PART 1: THE WORKER "CPU PUMP" ---
    // This worker sends a message to the main thread every 250ms.
    // Handling a 'message' event forces Firefox to keep the event loop active.
    const workerCode = `
        setInterval(() => {
            self.postMessage('PULSE');
        }, 250);
    `;

    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const worker = new Worker(URL.createObjectURL(blob));

    // When the main thread receives the pulse, it "wakes up"
    // and processes any pending native setTimeout/setIntervals.
    worker.onmessage = function() {
        // We do nothing here, the act of receiving the message is what keeps the tab alive.
    };

    // --- PART 2: THE SILENT AUDIO WAKELOCK ---
    // Android treats tabs playing audio as "High Priority," preventing them from being frozen.
    function startAudioWakelock() {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) return;

        const ctx = new AudioContext();

        const run = () => {
            // Create a silent buffer
            const buffer = ctx.createBuffer(1, 1, 22050);
            const source = ctx.createBufferSource();
            source.buffer = buffer;
            source.loop = true;

            // Connect but keep volume at essentially 0
            const gain = ctx.createGain();
            gain.gain.value = 0.001;

            source.connect(gain);
            gain.connect(ctx.destination);

            ctx.resume().then(() => {
                source.start();
                console.log('[BG-FIX] Audio Wakelock Active (Tab Priority: High)');
            });

            window.removeEventListener('click', run);
            window.removeEventListener('touchstart', run);
        };

        window.addEventListener('click', run);
        window.addEventListener('touchstart', run);
    }

    // --- PART 3: THE VISIBILITY SPOOFER (OPTIONAL) ---
    // Some sites stop timers if they see document.hidden is true.
    Object.defineProperty(document, 'hidden', { value: false, writable: false });
    Object.defineProperty(document, 'visibilityState', { value: 'visible', writable: false });

    // Initialize
    startAudioWakelock();
    console.log('[BG-FIX] Heartbeat Fix Active. Timers are NATIVE (Cloudflare Safe).');

})();

