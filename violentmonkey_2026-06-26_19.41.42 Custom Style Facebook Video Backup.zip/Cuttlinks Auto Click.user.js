// ==UserScript==
// @name         Cuttlinks Auto Click
// @namespace    https://github.com/BlazeFTL
// @description  Auto click Continue on Cuttlinks and monitor for disabled attribute removal
// @version      1.1
// @author       BlazeFTL
// @match        https://cuttlinks.com/*
// @license      MIT
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    function submitForm() {
        const btn = document.querySelector("#submit-button");
        // Check if button exists and is NOT disabled
        if (btn && !btn.disabled && !btn.hasAttribute('disabled')) {
            btn.click();
        }
    }

    // Run immediately on load
    submitForm();

    // Set up observer to watch for both new elements and attribute changes (like removing 'disabled')
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            // If the disabled attribute was changed or a new element appeared, try to click
            if (mutation.type === 'attributes' && mutation.attributeName === 'disabled') {
                submitForm();
            } else if (mutation.type === 'childList') {
                submitForm();
            }
        }
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['disabled'] // Only care about the disabled attribute
    });
})();

