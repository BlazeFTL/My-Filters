// ==UserScript==
// @name         TorUpload Final Page Download 1DM
// @namespace    https://github.com/BlazeFTL
// @description  Custom UI for 1DM Android Intent
// @version      1.1
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function init() {
        if (typeof fileUrl === 'undefined') {
            setTimeout(init, 500);
            return;
        }
        createMiniUI(fileUrl);
    }

    function createMiniUI(url) {
        const container = document.createElement('div');
        container.id = 'custom-dl-ui';

        Object.assign(container.style, {
            position: 'fixed',
            bottom: '15px',
            right: '15px',
            zIndex: '10000',
            backgroundColor: '#000',
            padding: '10px',
            borderRadius: '10px',
            border: '1px solid #444',
            display: 'flex',
            flexDirection: 'column',
            gap: '8px'
        });

        // 1DM Android Intent Button
        const oneDmBtn = document.createElement('button');
        oneDmBtn.innerText = 'Download with 1DM';
        oneDmBtn.onclick = () => {
            // Using the intent scheme specifically for 1DM/IDM+ on Android
            // This helps pass the URL to the app effectively
            const intentUrl = "intent:" + url + "#Intent;package=idm.internet.download.manager.plut;end";
            window.location.href = intentUrl;
        };

        Object.assign(oneDmBtn.style, {
            backgroundColor: '#e91e63',
            color: 'white',
            border: 'none',
            padding: '10px 15px',
            borderRadius: '5px',
            fontSize: '12px',
            fontWeight: 'bold',
            cursor: 'pointer'
        });

        // Fallback for Firefox Inbuilt
        const browserBtn = document.createElement('a');
        browserBtn.href = url;
        browserBtn.innerText = 'Firefox Download';
        browserBtn.download = '';
        Object.assign(browserBtn.style, {
            backgroundColor: '#333',
            color: 'white',
            padding: '10px 15px',
            borderRadius: '5px',
            fontSize: '12px',
            textDecoration: 'none',
            textAlign: 'center',
            fontWeight: 'bold'
        });

        container.appendChild(oneDmBtn);
        container.appendChild(browserBtn);
        document.body.appendChild(container);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
