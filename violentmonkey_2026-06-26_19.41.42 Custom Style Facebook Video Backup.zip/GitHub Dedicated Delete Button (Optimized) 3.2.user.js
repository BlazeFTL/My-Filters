// ==UserScript==
// @name         GitHub Dedicated Delete Button (Optimized) 3.2
// @namespace    https://github.com/BlazeFTL
// @version      3.2
// @author       BlazeFTL
// @description  Auto Click mega4upload.net
// @match        https://github.com/*
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const style = document.createElement('style');
    style.innerHTML = `
        .gh-standalone-delete-btn {
            background: none; border: none; cursor: pointer; padding: 4px;
            margin-left: 4px; color: #cf222e; display: inline-flex;
            align-items: center; justify-content: center; border-radius: 6px;
            transition: background-color 0.2s ease;
        }
        .gh-standalone-delete-btn:hover { background-color: #ffebe9; color: #a40e26; }
        .gh-standalone-delete-btn:active { background-color: #ff818266; }
    `;
    document.head.appendChild(style);

    const trashIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`;

    function injectButton(toggleBtn) {
        const path = window.location.pathname.split('/');
        const idMatch = toggleBtn.id.match(/Comment-actions-(\d+)-text/);
        if (!idMatch || toggleBtn.hasAttribute('data-has-delete')) return;

        toggleBtn.setAttribute('data-has-delete', 'true');
        const commentId = idMatch[1];
        const deleteUrl = `/${path[1]}/${path[2]}/${path[3]}/${path[4]}/comments/${commentId}/delete_content_modal`;

        const newBtn = document.createElement('button');
        newBtn.className = 'gh-standalone-delete-btn';
        newBtn.innerHTML = trashIcon;
        newBtn.title = 'Delete comment';
        newBtn.setAttribute('data-action', 'click:comment-actions-container#displayDialog');
        newBtn.setAttribute('data-dialog-id', `dialog-delete-comment-${commentId}`);
        newBtn.setAttribute('data-src', deleteUrl);

        toggleBtn.parentNode.insertBefore(newBtn, toggleBtn.nextSibling);
    }

    // Intersection Observer logic: only process elements near the viewport
    const viewObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                injectButton(entry.target);
                // Once injected, we can stop observing this specific element
                viewObserver.unobserve(entry.target);
            }
        });
    }, {
        rootMargin: '500px 0px' // "Buffer" of 500px (roughly 5-10 comments) above/below view
    });

    // Watch for new comments being loaded/added to the DOM
    const domObserver = new MutationObserver(() => {
        const buttons = document.querySelectorAll('button[id^="Comment-actions"]:not([data-has-delete])');
        buttons.forEach(btn => viewObserver.observe(btn));
    });

    domObserver.observe(document.body, { childList: true, subtree: true });

    // Initial run
    document.querySelectorAll('button[id^="Comment-actions"]').forEach(btn => viewObserver.observe(btn));
})();
