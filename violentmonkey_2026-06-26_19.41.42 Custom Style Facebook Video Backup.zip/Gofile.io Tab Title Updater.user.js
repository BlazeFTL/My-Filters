// ==UserScript==
// @name         Gofile.io Tab Title Updater
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Updates the tab title using file/folder name from gofile.io file page
// @author       You
// @match        https://gofile.io/d/*
// @icon https://www.google.com/s2/favicons?sz=64&domain=gofile.io
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function updateTitle() {
        const target = document.querySelector('.hover\\:underline.text-white.text-sm.font-semibold.item_open');
        if (target && target.textContent.trim()) {
            document.title = target.textContent.trim();
        }
    }

    // Try immediately
    updateTitle();

    // Observe dynamic loading if needed
    const observer = new MutationObserver(() => updateTitle());
    observer.observe(document.body, { childList: true, subtree: true });
})();
