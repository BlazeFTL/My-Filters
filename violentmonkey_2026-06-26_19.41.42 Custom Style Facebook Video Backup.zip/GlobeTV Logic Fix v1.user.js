// ==UserScript==
// @name         GlobeTV Logic Fix v1
// @namespace    https://github.com/BlazeFTL
// @description  Neutralize anti-adblock detection and force ad-free status
// @version      1.0
// @author       BlazeFTL
// @match        https://globetv.app/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1. Force the Ad-Free status in LocalStorage before the site reads it
    const adFreeData = JSON.stringify({
        active: true,
        checkedAt: Date.now(),
        expiresAt: Date.now() + 31536000000 // 1 year from now
    });

    try {
        localStorage.setItem('gtv_adfree_status_v1', adFreeData);
        // Also clear the "last shown" timer to reset the site's memory
        localStorage.removeItem('gtv_ads_block_notice_last_v1');
    } catch (e) {}

    // 2. Hijack JSON.parse to ensure the logic ALWAYS sees "active: true"
    const nativeParse = JSON.parse;
    JSON.parse = function() {
        const result = nativeParse.apply(this, arguments);
        if (result && typeof result === 'object' && result.hasOwnProperty('active')) {
            result.active = true;
            result.expiresAt = Date.now() + 31536000000;
        }
        return result;
    };

    // 3. Sabotage the "Bait" height checks
    const nativeGetComputed = window.getComputedStyle;
    window.getComputedStyle = function(el) {
        const style = nativeGetComputed.apply(this, arguments);
        if (el && (el.id === 'ad-banner' || el.className.includes('ads-container'))) {
            // Create a proxy to return fake dimensions
            return new Proxy(style, {
                get(target, prop) {
                    if (prop === 'display') return 'block';
                    if (prop === 'height' || prop === 'minHeight') return '100px';
                    if (prop === 'visibility') return 'visible';
                    return target[prop];
                }
            });
        }
        return style;
    };

    // 4. Kill the UI-locking class toggle
    const nativeToggle = Element.prototype.classList.toggle;
    Element.prototype.classList.toggle = function(cls, force) {
        if (cls === 'adblock-active') return false; // Never allow the dimming class
        return nativeToggle.apply(this, arguments);
    };

    // 5. Block the Error Listener that catches uBlock
    const nativeAddEventListener = window.addEventListener;
    window.addEventListener = function(type, listener, options) {
        if (type === 'error' && listener && listener.toString().includes('ads')) {
            return; // Ignore the ad-specific error watcher
        }
        return nativeAddEventListener.apply(this, arguments);
    };

})();
// ==/UserScript==
