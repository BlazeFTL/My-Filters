// ==UserScript==
// @name         Eporner Custom Rotation 2.4
// @namespace    https://github.com/BlazeFTL
// @version      2.4
// @author       BlazeFTL
// @match        https://*.eporner.com/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const style = document.createElement('style');
    style.innerHTML = `
        /* v1.3 CSS Fixes - Applies when the player is in fullscreen */
        .vjs-fullscreen #EPvideo_html5_api,
        .vjs-fullscreen .vjs-tech,
        video:-webkit-full-screen {
            width: 100% !important;
            height: 100% !important;
            object-fit: cover !important;
            top: 0 !important;
            left: 0 !important;
        }
        .video-js.vjs-fullscreen {
            width: 100vw !important;
            height: 100vh !important;
        }

        #blaze-rotate-btn {
            position: absolute;
            right: 15px;
            top: 20px;
            z-index: 99999;
            background: rgba(0, 0, 0, 0.7);
            color: #fff;
            border: 2px solid #fff;
            border-radius: 50%;
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.5);
        }
    `;
    document.head.appendChild(style);

    const rotateBtn = document.createElement('div');
    rotateBtn.id = 'blaze-rotate-btn';
    rotateBtn.innerHTML = '🔄';

    let isLocked = false;

    rotateBtn.onclick = async (e) => {
        e.preventDefault();
        e.stopPropagation();

        const player = document.querySelector('.video-js');

        try {
            // 1. Ensure we are in Fullscreen first (Required for Orientation Lock)
            if (!document.fullscreenElement) {
                if (player.requestFullscreen) await player.requestFullscreen();
                else if (player.webkitRequestFullscreen) await player.webkitRequestFullscreen();
            }

            // 2. Toggle the Orientation Lock
            if (!isLocked) {
                if (screen.orientation && screen.orientation.lock) {
                    await screen.orientation.lock('landscape');
                    isLocked = true;
                    rotateBtn.style.borderColor = '#ff0000';
                }
            } else {
                screen.orientation.unlock();
                isLocked = false;
                rotateBtn.style.borderColor = '#ffffff';
            }
        } catch (err) {
            console.error("Rotation/Fullscreen failed:", err);
        }
    };

    const observer = new MutationObserver(() => {
        const player = document.querySelector('.video-js');
        if (player && !document.getElementById('blaze-rotate-btn')) {
            player.appendChild(rotateBtn);
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    document.addEventListener('fullscreenchange', () => {
        if (!document.fullscreenElement) {
            if (screen.orientation && screen.orientation.unlock) {
                screen.orientation.unlock();
            }
            isLocked = false;
            rotateBtn.style.borderColor = '#ffffff';
        }
    });
})();
