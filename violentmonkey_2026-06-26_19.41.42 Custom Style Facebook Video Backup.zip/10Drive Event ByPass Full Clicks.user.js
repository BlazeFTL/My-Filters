// ==UserScript==
// @name         10Drive Event ByPass Full Clicks
// @namespace    BlazeFTL
// @match        *://gamesmain.xyz/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    "use strict";

    function triggerSecureClick() {
        window.postMessage("secure-click", "*");
        console.log("Sent secure-click");
    }

    // Step 1 trigger
    window.addEventListener("load", () => {
        setTimeout(triggerSecureClick, 800);
    });

    // Watch for iframe injection
    const observer = new MutationObserver((mutations) => {
        for (const m of mutations) {
            for (const node of m.addedNodes) {

                if (node.tagName === "IFRAME" && node.srcdoc && node.srcdoc.includes("safe-download-now")) {

                    node.srcdoc = node.srcdoc.replace(
                        "</script>",
                        `
                        setTimeout(()=>{
                            parent.postMessage({type:"third-safe-start"},"*");
                            setTimeout(()=>{
                                parent.postMessage({type:"third-safe-download"},"*");
                            },200);
                        },500);
                        </script>`
                    );

                    console.log("Injected safe-download trigger");
                }

            }
        }
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });

})();
