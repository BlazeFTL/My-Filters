// ==UserScript==
// @name         JW Player Side-Zone Seek (Invisible Click Areas)
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Invisible left/right side zones seek ±10s. Keeps control bar buttons and top-right fullscreen button. Avoids control bar and top area.
// @match        https://*.mat6tube.com/*
// @match        https://*.noodlemagazine.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function addStyle(css) {
        const style = document.createElement('style');
        style.type = 'text/css';
        style.appendChild(document.createTextNode(css));
        document.head.appendChild(style);
    }

    addStyle(`
        .jwplayer {
            position: relative;
        }

        /* --- Invisible side click zones --- */
        .jw-side-zone {
            position: absolute;
            top: 68px;              /* clear top area / fullscreen button */
            bottom: 68px;           /* clear control bar */
            width: 30%;             /* generous side target in portrait */
            z-index: 5;             /* above video, below JW Player controls */
            cursor: pointer;
            pointer-events: auto;
            background: transparent;
            border: none;
            outline: none;
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
            transition: background-color 0.15s ease;
        }

        .jw-side-zone-left {
            left: 0;
        }

        .jw-side-zone-right {
            right: 0;
        }

        /* Subtle white flash on touch so user knows it registered */
        .jw-side-zone:active {
            background-color: rgba(255,255,255,0.07);
        }

        /* Landscape: narrower zones since the video is much wider */
        @media (orientation: landscape) {
            .jw-side-zone {
                width: 28%;
            }
        }

        /* --- Top-right fullscreen button (stock) --- */
        .jw-top-right-controls {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 20;
            display: flex;
            gap: 8px;
            pointer-events: auto;
            transition: opacity 0.3s ease;
        }

        .jw-top-right-controls button {
            background: rgba(0,0,0,0.5);
            border: none;
            color: white;
            padding: 4px 8px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
            line-height: 1;
            transition: background-color 0.2s ease;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            min-width: 36px;
            min-height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .jw-top-right-controls button:hover {
            background-color: rgba(0,0,0,0.7);
        }

        /* --- Control bar buttons (stock) --- */
        .jw-controlbar .jw-button-container {
            display: flex;
            align-items: center;
        }

        .jw-controlbar .custom-control-button {
            background: none;
            border: none;
            color: white;
            padding: 0 4px;
            cursor: pointer;
            font-size: 12px;
            line-height: 1;
            margin-right: 8px;
            display: flex;
            align-items: center;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            transition: color 0.2s ease;
            min-height: 36px;
        }

        .jw-controlbar .custom-control-button:hover {
            color: #aaaaaa;
        }

        .jw-controlbar .jw-icon-playback {
            margin-right: 8px;
        }

        /* Sync hide/show with JW Player controls */
        .jwplayer.jw-flag-user-inactive .jw-top-right-controls {
            opacity: 0;
            pointer-events: none !important;
        }

        /* Hide custom controls during ads */
        .jwplayer.jw-flag-ads .custom-control-button,
        .jwplayer.jw-flag-ads .jw-top-right-controls,
        .jwplayer.jw-flag-ads .jw-side-zone {
            display: none !important;
        }
    `);

    function init() {
        const check = setInterval(() => {
            if (typeof jwplayer !== 'function') return;

            const playerElements = document.querySelectorAll('.jwplayer:not([data-custom-controls="true"])');
            playerElements.forEach(el => {
                if (!el.id) return;
                try {
                    const instance = jwplayer(el.id);
                    if (instance && typeof instance.getState === 'function') {
                        el.setAttribute('data-custom-controls', 'true');
                        enhanceJWPlayer(instance, el);
                    }
                } catch (e) {
                    console.warn('JW enhancement skipped:', el.id, e);
                }
            });

            try {
                const defaultInstance = jwplayer();
                const defaultContainer = defaultInstance && defaultInstance.getContainer ? defaultInstance.getContainer() : null;
                if (defaultContainer && !defaultContainer.hasAttribute('data-custom-controls')) {
                    defaultContainer.setAttribute('data-custom-controls', 'true');
                    enhanceJWPlayer(defaultInstance, defaultContainer);
                }
            } catch (e) {}
        }, 800);
    }

    function enhanceJWPlayer(player, playerContainer) {
        if (!playerContainer) return;
        if (playerContainer.querySelector('.jw-custom-controls-wrapper')) return;

        const observer = new MutationObserver((mutations, obs) => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');

            if (controlBar && playButtonContainer) {
                if (!playerContainer.querySelector('.jw-custom-controls-wrapper')) {
                    obs.disconnect();
                    addButtons(player, playButtonContainer, playerContainer);
                }
            }
        });

        observer.observe(playerContainer, { childList: true, subtree: true });

        const fallback = setInterval(() => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');

            if (controlBar && playButtonContainer) {
                if (!playerContainer.querySelector('.jw-custom-controls-wrapper')) {
                    clearInterval(fallback);
                    observer.disconnect();
                    addButtons(player, playButtonContainer, playerContainer);
                }
            }
        }, 1200);
    }

    function addButtons(player, playButtonContainer, playerContainer) {
        const marker = document.createElement('div');
        marker.className = 'jw-custom-controls-wrapper';
        marker.style.display = 'none';
        playerContainer.appendChild(marker);

        const safeSeek = (offset) => {
            try {
                const pos = player.getPosition() || 0;
                const dur = player.getDuration() || 0;
                player.seek(Math.max(0, Math.min(pos + offset, dur)));
            } catch (e) {
                console.warn('Seek failed:', e);
            }
        };

        /* --- Invisible side zones --- */
        const createZone = (className, title, offset) => {
            const zone = document.createElement('div');
            zone.className = 'jw-side-zone ' + className;
            zone.title = title;
            zone.addEventListener('click', (e) => {
                e.stopPropagation();
                safeSeek(offset);
            });
            return zone;
        };

        const leftZone = createZone('jw-side-zone-left', 'Seek backward 10 seconds', -10);
        const rightZone = createZone('jw-side-zone-right', 'Seek forward 10 seconds', 10);

        playerContainer.appendChild(leftZone);
        playerContainer.appendChild(rightZone);

        /* --- Control Bar Buttons --- */
        const createControlBtn = (label, onClick) => {
            const btn = document.createElement('button');
            btn.textContent = label;
            btn.className = 'custom-control-button';
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                onClick();
            });
            return btn;
        };

        const rewindBar = createControlBtn('« 10s', () => safeSeek(-10));
        const forwardBar = createControlBtn('10s »', () => safeSeek(10));

        const playPause = playButtonContainer.querySelector('.jw-icon-playback');
        if (playPause) {
            playPause.parentNode.insertBefore(rewindBar, playPause.nextSibling);
            playPause.parentNode.insertBefore(forwardBar, rewindBar.nextSibling);
        } else {
            playButtonContainer.prepend(forwardBar);
            playButtonContainer.prepend(rewindBar);
        }

        /* --- Top-Right Fullscreen --- */
        const topRight = document.createElement('div');
        topRight.className = 'jw-top-right-controls';

        const fsBtn = document.createElement('button');
        fsBtn.innerHTML = '⛶';
        fsBtn.title = 'Toggle Fullscreen';
        fsBtn.setAttribute('aria-label', 'Toggle Fullscreen');

        fsBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            try {
                player.setFullscreen(!player.getFullscreen());
            } catch (err) {}
        });

        player.on('fullscreen', (event) => {
            fsBtn.innerHTML = event.fullscreen ? '⛶̽' : '⛶';
            fsBtn.title = event.fullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen';
        });

        try {
            if (player.getFullscreen()) {
                fsBtn.innerHTML = '⛶̽';
                fsBtn.title = 'Exit Fullscreen';
            }
        } catch (e) {}

        topRight.appendChild(fsBtn);
        playerContainer.appendChild(topRight);

        /* --- Keyboard Shortcuts --- */
        const keyHandler = (e) => {
            if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
            const isPlayerFocused = playerContainer.contains(document.activeElement);
            let isFullscreen = false;
            try { isFullscreen = player.getFullscreen(); } catch (e) {}
            if (!isPlayerFocused && !isFullscreen) return;

            e.preventDefault();
            e.stopPropagation();
            safeSeek(e.key === 'ArrowLeft' ? -10 : 10);
        };
        document.addEventListener('keydown', keyHandler);

        /* Cleanup */
        const cleanup = new MutationObserver(() => {
            if (!document.body.contains(playerContainer)) {
                document.removeEventListener('keydown', keyHandler);
                cleanup.disconnect();
            }
        });
        cleanup.observe(document.body, { childList: true, subtree: true });

        console.log('JW Player side zones added.');
    }

    init();
})();
