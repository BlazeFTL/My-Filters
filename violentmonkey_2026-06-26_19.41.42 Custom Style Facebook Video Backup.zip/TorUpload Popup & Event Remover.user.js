// ==UserScript==
// @name         TorUpload Popup & Event Remover
// @namespace    https://github.com/BlazeFTL
// @description  Blocks specific ad-listeners while keeping download logic active.
// @version      1.4
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // List of script identifiers to block based on your screenshots
    const blockedPatterns = [
        'wbbcd',          // Targeted listeners below DomContentLoaded
        '2507871',        // First click listener
        'v8c78df7',       // Second click listener
        'xhumane.min.js', // Third click listener
        'event-handler.js' // 5th click listener (document)
    ];

    // 1. OVERRIDE EVENT LISTENERS (The "Shield")
    const originalAddEventListener = EventTarget.prototype.addEventListener;

    EventTarget.prototype.addEventListener = function(type, listener, options) {
        // We only care about window/document click/mousedown listeners from ad scripts
        if (type === 'click' || type === 'mousedown' || type === 'DOMContentLoaded' || type.includes('JkPe1')) {
            const stack = new Error().stack || '';

            // Check if the script trying to add the listener matches our blocked patterns
            const shouldBlock = blockedPatterns.some(pattern => stack.includes(pattern));

            if (shouldBlock) {
                console.log(`[Shield] Blocked listener type "${type}" from:`, pattern);
                return;
            }
        }
        return originalAddEventListener.apply(this, arguments);
    };

    // 2. PATH CLEARER (Ensures button is always interactable)
    const clearPath = () => {
        const dlBtn = document.querySelector('#downloadbtn');
        if (dlBtn) {
            dlBtn.style.setProperty('display', 'inline-flex', 'important');
            dlBtn.style.setProperty('pointer-events', 'auto', 'important');
            dlBtn.style.setProperty('visibility', 'visible', 'important');
            dlBtn.style.setProperty('z-index', '9999', 'important');
        }

        const overlays = document.querySelectorAll('div, object, embed, iframe');
        overlays.forEach(el => {
            if (el.id === 'telemetry-viewer') return;

            const style = window.getComputedStyle(el);
            const z = parseInt(style.zIndex);

            if (z > 100 && !el.closest('#downloadbtn, #normalDownloadForm')) {
                el.style.setProperty('pointer-events', 'none', 'important');
                if (z > 500) el.style.setProperty('display', 'none', 'important');
            }
        });
    };

    // 3. RUNTIME
    setInterval(clearPath, 250);
})();
