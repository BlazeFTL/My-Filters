// ==UserScript==
// @name         MP4 to 1dm Direct Downloader 1.1
// @namespace    https://github.com/BlazeFTL
// @description  Adds a floating download button to trigger external downloaders
// @version      1.1
// @author       BlazeFTL
// @match        https://*/*
// @icon         https://play-lh.googleusercontent.com/29qcP_4LslshvRC0-aac4Kn8U8EDv7PqCjEcXRRYbAIRdyiEZFvM_3vQK_P1LFg8Q5Hm=w480-h960
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Create the Button
    const btn = document.createElement('a');
    btn.innerHTML = '⬇️ Download Video';
    btn.href = window.location.href;

    // Suggest a filename to force the "Save As" / Downloader intent
    btn.setAttribute('download', 'video.mp4');

    // Style the Button
    Object.assign(btn.style, {
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        zIndex: '9999',
        padding: '12px 20px',
        backgroundColor: '#007bff',
        color: 'white',
        borderRadius: '50px',
        textDecoration: 'none',
        fontWeight: 'bold',
        boxShadow: '0px 4px 10px rgba(0,0,0,0.3)',
        fontSize: '14px',
        fontFamily: 'sans-serif'
    });

    // Add to body
    document.body.appendChild(btn);

    // If 1DM doesn't catch it automatically, clicking this link
    // usually forces the "Open With" menu in Firefox Mobile.
})();
