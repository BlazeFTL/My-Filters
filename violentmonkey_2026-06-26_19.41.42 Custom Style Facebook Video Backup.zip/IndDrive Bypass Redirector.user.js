// ==UserScript==
// @name         IndDrive Bypass Redirector
// @namespace    https://github.com/BlazeFTL
// @description  Redirects inddrive.in to advupdates while preventing loops
// @version      1.0
// @author       BlazeFTL
// @match        https://inddrive.*/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const currentUrl = window.location.href;
    const pathPattern = /\/([a-zA-Z0-9]+)$/;
    const match = currentUrl.match(pathPattern);

    // Only redirect if there is an ID and we aren't being referred back by the target site
    if (match && !document.referrer.includes('indian.advupdates.com')) {
        const id = match[1];
        const targetUrl = `https://indian.advupdates.com/?adlinkfly=inddrive.in/${id}`;

        console.log('Redirecting to:', targetUrl);
        window.location.replace(targetUrl);
    } else {
        console.log('Loop prevented or final page reached.');
    }
})();

