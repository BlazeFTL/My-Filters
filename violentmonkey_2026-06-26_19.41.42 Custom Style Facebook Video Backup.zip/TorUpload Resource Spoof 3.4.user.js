// ==UserScript==
// @name         TorUpload Resource Spoof 3.4
// @namespace    https://github.com/BlazeFTL
// @description  Spoof perf entries + hide replacements from toString() inspection
// @version      3.3
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const nativeToString = Function.prototype.toString;

    function makeNative(fn, original) {
        const name = original.name || '';
        fn.toString = function() {
            return `function ${name}() { [native code] }`;
        };
        return fn;
    }

    const _e = [
        {url: "https://s0-greate.net/p/2507871", type: "script", d: 1058},
        {url: "https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516", type: "script", d: 36},
        {url: "https://cdn.jsdelivr.net/npm/disable-devtool", type: "script", d: 47}
    ];

    const generateEntry = (item) => ({
        name: item.url,
        initiatorType: item.type,
        duration: item.d,
        startTime: Math.random() * 100,
        entryType: "resource",
        nextHopProtocol: "h2",
        renderBlockingStatus: "non-blocking",
        workerStart: 0,
        redirectStart: 0,
        redirectEnd: 0,
        fetchStart: 10,
        domainLookupStart: 10,
        domainLookupEnd: 12,
        connectStart: 12,
        connectEnd: 15,
        secureConnectionStart: 13,
        requestStart: 16,
        responseStart: 20,
        responseEnd: item.d + 20,
        transferSize: Math.floor(Math.random() * 5000) + 1000,
        encodedBodySize: 1000,
        decodedBodySize: 3000,
        serverTiming: []
    });

    const _p = Performance.prototype;
    const _getEntries       = _p.getEntries;
    const _getEntriesByType = _p.getEntriesByType;
    const _getEntriesByName = _p.getEntriesByName;

    _p.getEntries = makeNative(function() {
        const real = _getEntries.apply(this, arguments);
        const fakes = _e.map(generateEntry);
        return [...real, ...fakes];
    }, _getEntries);

    _p.getEntriesByType = makeNative(function(type) {
        const real = _getEntriesByType.apply(this, arguments);
        if (type === 'resource') return [...real, ..._e.map(generateEntry)];
        return real;
    }, _getEntriesByType);

    _p.getEntriesByName = makeNative(function(name) {
        const item = _e.find(x => x.url === name);
        if (item) return [generateEntry(item)];
        return _getEntriesByName.apply(this, arguments);
    }, _getEntriesByName);

    // Also hide Function.prototype.toString itself so it can't detect spoofed .toString()
    const _fnToString = Function.prototype.toString;
    Object.defineProperty(Function.prototype, 'toString', {
        value: makeNative(function toString() {
            if (this === Function.prototype.toString) return 'function toString() { [native code] }';
            return nativeToString.call(this);
        }, _fnToString),
        writable: true,
        configurable: true
    });

})();
