// ==UserScript==
// @name         Decompiler.com Probe Spoofer
// @namespace    blazeftl
// @version      0.1
// @match        https://decompiler.com/*
// @match        https://*.decompiler.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==
(function(){
  var RE = /ethicalads\.io\/images\//;
  var NativeImage = window.Image;
  var BLANK = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBTAA7";
  function FakeImage(w, h){
    var img = new NativeImage(w, h);
    var desc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, "src");
    Object.defineProperty(img, "src", {
      configurable: true,
      get: function(){ return desc.get.call(img); },
      set: function(v){
        if (RE.test(v)) {
          Object.defineProperty(img, "naturalWidth", {value: 240, configurable: true});
          desc.set.call(img, BLANK);
        } else {
          desc.set.call(img, v);
        }
      }
    });
    return img;
  }
  window.Image = FakeImage;
})();
