// ==UserScript==
// @name         TorUpload Resource Spoof 4.0 Improved Manus
// @namespace    https://github.com/BlazeFTL
// @description  Robust perf entries spoofing with toString protection and PerformanceObserver support
// @version      4.0
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const nativeToString = Function.prototype.toString;
    const _e = [];
    const _seen = new Set();

    // Helper to make functions look native
    function makeNative(fn, originalName) {
        const name = originalName || fn.name || '';
        Object.defineProperty(fn, 'toString', {
            value: function() { return `function ${name}() { [native code] }`; },
            writable: true,
            configurable: true
        });
        return fn;
    }

    // Global toString protector
    const _fnToString = Function.prototype.toString;
    Object.defineProperty(Function.prototype, 'toString', {
        value: makeNative(function toString() {
            if (this === Function.prototype.toString) return 'function toString() { [native code] }';
            if (this.hasOwnProperty('toString') && typeof this.toString === 'function') {
                const val = this.toString();
                if (val.includes('[native code]')) return val;
            }
            return nativeToString.call(this);
        }, 'toString'),
        writable: true,
        configurable: true
    });

    function addEntry(url, type) {
        if (!url || _seen.has(url)) return;
        try { new URL(url, window.location.origin); } catch { return; }
        _seen.add(url);
        _e.push({
            url,
            type: type || 'script',
            d: Math.floor(Math.random() * 900) + 30,
            start: Math.random() * 100
        });
    }

    const generateEntry = (item) => ({
        name: item.url,
        initiatorType: item.type,
        duration: item.d,
        startTime: item.start,
        entryType: 'resource',
        nextHopProtocol: 'h2',
        renderBlockingStatus: 'non-blocking',
        workerStart: 0, redirectStart: 0, redirectEnd: 0,
        fetchStart: item.start + 1, domainLookupStart: item.start + 1, domainLookupEnd: item.start + 3,
        connectStart: item.start + 3, connectEnd: item.start + 6, secureConnectionStart: item.start + 4,
        requestStart: item.start + 7, responseStart: item.start + 10, responseEnd: item.start + 10 + item.d,
        transferSize: Math.floor(Math.random() * 5000) + 1000,
        encodedBodySize: 1000, decodedBodySize: 3000, serverTiming: [],
        toJSON: function() { return this; }
    });

    // Hook Performance API
    const _p = Performance.prototype;
    const _getEntries = _p.getEntries;
    const _getEntriesByType = _p.getEntriesByType;
    const _getEntriesByName = _p.getEntriesByName;

    _p.getEntries = makeNative(function getEntries() {
        const real = _getEntries.apply(this, arguments);
        return [...real, ..._e.map(generateEntry)];
    }, 'getEntries');

    _p.getEntriesByType = makeNative(function getEntriesByType(type) {
        const real = _getEntriesByType.apply(this, arguments);
        return type === 'resource' ? [...real, ..._e.map(generateEntry)] : real;
    }, 'getEntriesByType');

    _p.getEntriesByName = makeNative(function getEntriesByName(name) {
        const item = _e.find(x => x.url === name);
        const real = _getEntriesByName.apply(this, arguments);
        return item ? [...real, generateEntry(item)] : real;
    }, 'getEntriesByName');

    // Hook PerformanceObserver
    const _origObserver = window.PerformanceObserver;
    if (_origObserver) {
        window.PerformanceObserver = makeNative(function PerformanceObserver(callback) {
            const wrappedCallback = makeNative(function(list, observer) {
                const _getEntriesObs = list.getEntries;
                const _getEntriesByTypeObs = list.getEntriesByType;
                const _getEntriesByNameObs = list.getEntriesByName;

                list.getEntries = makeNative(function() {
                    return [..._getEntriesObs.apply(list, arguments), ..._e.map(generateEntry)];
                }, 'getEntries');

                list.getEntriesByType = makeNative(function(type) {
                    const real = _getEntriesByTypeObs.apply(list, arguments);
                    return type === 'resource' ? [...real, ..._e.map(generateEntry)] : real;
                }, 'getEntriesByType');

                list.getEntriesByName = makeNative(function(name) {
                    const item = _e.find(x => x.url === name);
                    const real = _getEntriesByNameObs.apply(list, arguments);
                    return item ? [...real, generateEntry(item)] : real;
                }, 'getEntriesByName');

                return callback(list, observer);
            }, '');

            return new _origObserver(wrappedCallback);
        }, 'PerformanceObserver');
        window.PerformanceObserver.prototype = _origObserver.prototype;
        window.PerformanceObserver.supportedEntryTypes = _origObserver.supportedEntryTypes;
    }

    // Scan DOM for existing resources
    const scanNode = (node) => {
        if (!node || !node.tagName) return;
        const tag = node.tagName.toUpperCase();
        if (tag === 'SCRIPT' && node.src) addEntry(node.src, 'script');
        else if (tag === 'LINK' && (node.rel === 'stylesheet' || node.as === 'style') && node.href) addEntry(node.href, 'css');
        else if (tag === 'IMG' && node.src) addEntry(node.src, 'img');
    };

    // Hook createElement to catch dynamic resources
    const _origCreate = Document.prototype.createElement;
    Document.prototype.createElement = makeNative(function createElement(tag) {
        const el = _origCreate.apply(this, arguments);
        if (typeof tag === 'string') {
            const t = tag.toLowerCase();
            if (t === 'script' || t === 'img' || t === 'link') {
                const attr = t === 'link' ? 'href' : 'src';
                const proto = t === 'script' ? HTMLScriptElement.prototype : (t === 'img' ? HTMLImageElement.prototype : HTMLLinkElement.prototype);
                const desc = Object.getOwnPropertyDescriptor(proto, attr) || Object.getOwnPropertyDescriptor(Element.prototype, attr);

                if (desc && desc.set) {
                    Object.defineProperty(el, attr, {
                        set(val) {
                            addEntry(val, t === 'link' ? 'css' : t);
                            desc.set.call(this, val);
                        },
                        get() { return desc.get.call(this); },
                        configurable: true
                    });
                }
            }
        }
        return el;
    }, 'createElement');

    // Initial scan and observer
    const observer = new MutationObserver(mutations => {
        for (const m of mutations) {
            for (const node of m.addedNodes) {
                scanNode(node);
                if (node.querySelectorAll) {
                    node.querySelectorAll('script, link[rel="stylesheet"], img').forEach(scanNode);
                }
            }
        }
    });

    if (document.documentElement) {
        observer.observe(document.documentElement, { childList: true, subtree: true });
        document.querySelectorAll('script, link[rel="stylesheet"], img').forEach(scanNode);
    } else {
        const docObserver = new MutationObserver(() => {
            if (document.documentElement) {
                docObserver.disconnect();
                observer.observe(document.documentElement, { childList: true, subtree: true });
            }
        });
        docObserver.observe(document, { childList: true, subtree: true });
    }

    // Keep hooks active but stop observer on load to save resources
    window.addEventListener('load', () => {
        observer.disconnect();
    }, { once: true });

})();
