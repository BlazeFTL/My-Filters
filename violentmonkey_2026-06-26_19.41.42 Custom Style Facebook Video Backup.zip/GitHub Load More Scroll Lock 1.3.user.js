// ==UserScript==
// @name         GitHub Load More Scroll Lock 1.3
// @namespace    https://github.com/BlazeFTL
// @description  Anchors view to the current element so layout shifts don't move your position.
// @version      1.3
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let anchorElement = null;
    let offsetFromTop = 0;
    let animationFrameId = null;

    const maintainAnchor = () => {
        if (anchorElement) {
            const currentRect = anchorElement.getBoundingClientRect();
            const desiredScrollY = window.scrollY + (currentRect.top - offsetFromTop);

            if (Math.abs(window.scrollY - desiredScrollY) > 0.5) {
                window.scrollTo(0, desiredScrollY);
            }
        }
        animationFrameId = requestAnimationFrame(maintainAnchor);
    };

    const releaseLock = () => {
        if (animationFrameId) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
        }
        anchorElement = null;
    };

    document.addEventListener('click', (e) => {
        // Updated selector to match the specific classes in your screenshot
        const btn = e.target.closest('.ajax-pagination-btn, .custom-mirror-btn, .custom-mobile-mirror-btn, .btn-link.custom-mobile-mirror-btn');

        if (btn) {
            // Pick an element slightly below any potential sticky headers
            const x = window.innerWidth / 2;
            const y = 150;

            anchorElement = document.elementFromPoint(x, y);

            // If the anchor is the button itself or inside the pagination area,
            // try to find a stable parent or sibling instead.
            if (!anchorElement || anchorElement.closest('.ajax-pagination-form')) {
                anchorElement = document.querySelector('.js-discussion-timeline-bookmark') || document.body;
            }

            offsetFromTop = anchorElement.getBoundingClientRect().top;

            if (!animationFrameId) {
                maintainAnchor();
            }

            // Keep the lock active for 6 seconds to handle heavy content loading
            setTimeout(releaseLock, 6000);
        }
    }, true);
})();
