// ==UserScript==
// @name         SetTimeout and Interval Logger 3
// @namespace    https://github.com/BlazeFTL
// @description  Logs calls to setTimeout and setInterval upon button click
// @version      1.2
// @author       BlazeFTL
// @match        *://*/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let isLogging = false;
    const originalSetTimeout = window.setTimeout;
    const originalSetInterval = window.setInterval;

    // Create UI Button
    const btn = document.createElement('button');
    btn.textContent = 'Start Timer Logging';
    btn.style.cssText = 'position:fixed;top:10px;right:10px;z-index:9999;padding:10px;background:#000;color:#fff;border:1px solid #fff;cursor:pointer;font-family:sans-serif;';
    document.body.appendChild(btn);

    // Override setTimeout
    window.setTimeout = function(callback, delay, ...args) {
        if (isLogging) {
            console.log(`[setTimeout] Delay: ${delay}ms`, {
                callback: callback.toString(),
                arguments: args,
                stack: new Error().stack
            });
        }
        return originalSetTimeout.call(this, callback, delay, ...args);
    };

    // Override setInterval
    window.setInterval = function(callback, delay, ...args) {
        if (isLogging) {
            console.log(`[setInterval] Interval: ${delay}ms`, {
                callback: callback.toString(),
                arguments: args,
                stack: new Error().stack
            });
        }
        return originalSetInterval.call(this, callback, delay, ...args);
    };

    btn.addEventListener('click', () => {
        isLogging = !isLogging;
        btn.textContent = isLogging ? 'Stop Timer Logging' : 'Start Timer Logging';
        btn.style.backgroundColor = isLogging ? '#d00' : '#000';
        console.log(`[Logger] Logging is now ${isLogging ? 'ENABLED' : 'DISABLED'}`);
    });
})();
