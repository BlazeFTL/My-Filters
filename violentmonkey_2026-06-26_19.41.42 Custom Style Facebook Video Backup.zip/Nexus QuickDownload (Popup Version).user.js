// ==UserScript==
// @name         Nexus QuickDownload (Popup Version)
// @namespace    Nexus QuickDownload
// @version      2.5.7p
// @description  No redirect/extra pages for free users-direct download nexus mods
// @match        https://www.nexusmods.com/*
// @author       Accro
// @license      MIT
// @icon         https://www.google.com/s2/favicons?sz=128&domain=nexusmods.com
// @run-at       document-idle
// @downloadURL https://update.greasyfork.org/scripts/566174/Nexus%20QuickDownload%20%28Popup%20Version%29.user.js
// @updateURL https://update.greasyfork.org/scripts/566174/Nexus%20QuickDownload%20%28Popup%20Version%29.meta.js
// ==/UserScript==

(function () {
  'use strict';

  // ======= vibe knobs =======
  const STALKING_TIMEOUT_MS = 20000;     // "how long do we keep looking before giving up and touching grass"
  const POKE_INTERVAL_MS    = 150;       // "how often do we poke Nexus and ask politely"
  const POPUP_GO_BYEBYE_MS  = 3000;      // "after success, let the popup live a lil then die"

  // ======= per-mod identity (so pages don't fight each other) =======
  const MOD_DOX = location.pathname; // ex: /skyrimspecialedition/mods/12345
  const LS_BTN_MOOD   = 'nexus_manual_btn_state:' + MOD_DOX;
  const LS_SCROLL_SAUCE = 'nexus_scroll_y:' + MOD_DOX;

  // OPTIONAL: if you hate seeing "Downloaded" forever
  const AUTO_UNDOWNLOAD_MY_FEELINGS_MS = 10000;

  // in case we ever care about CDN links (we kinda don't rn, but it's here chillin)
  const CDN_GOBLIN_RE = /https?:\/\/[^\/]*nexus-cdn\.com\/.+/i;

  // ======= state (aka: brain cells) =======
  let cdnCrumbs = '';                   // first CDN url we notice (if any)
  let watcherIsAlreadyYapping = false;  // avoid starting multiple intervals

  let slowBtnAlreadySmacked = false;    // so we don't click slow download 500 times
  let lastClickBonkAt = 0;              // anti spam
  let slowSmackMoment = 0;              // timestamp when slow was clicked (close guard)

  // -------------------- tiny helpers (no cap) --------------------
  function existsAndIsNotInvisible(thingy) {
    if (!thingy) return false;
    if (thingy.offsetParent === null && thingy.getClientRects().length === 0) return false;
    const css = window.getComputedStyle(thingy);
    if (!css) return true;
    return css.visibility !== 'hidden' && css.display !== 'none' && css.opacity !== '0';
  }

  function attemptToParseJsonOrJustGiveUp(str) {
    try { return JSON.parse(str); } catch (_) { return null; }
  }

  function renameButtonTo(btn, newNameBecauseWeFeelLikeIt) {
    if (!btn) return;
    const label = btn.querySelector('span.flex-label');
    if (!label) return;

    label.textContent = newNameBecauseWeFeelLikeIt;

    // accessibility: "yo I'm busy"
    if (String(newNameBecauseWeFeelLikeIt).toLowerCase().includes('downloading')) {
      btn.setAttribute('aria-busy', 'true');
    } else {
      btn.removeAttribute('aria-busy');
    }
  }

  function locateTheExactSameManualDownloadButton(savedHref) {
    if (!savedHref) return null;

    // exact match first (nice & clean)
    const exact = document.querySelector(
      `a.btn.inline-flex.popup-btn-ajax[href="${CSS.escape(savedHref)}"]`
    );
    if (exact) return exact;

    // fallback: okay fine we'll be forgiving
    const all = document.querySelectorAll('a.btn.inline-flex.popup-btn-ajax');
    for (const a of all) {
      const href = a.getAttribute('href') || '';
      if (!href) continue;
      if (href === savedHref || href.endsWith(savedHref) || savedHref.endsWith(href)) return a;
    }
    return null;
  }

  function returnMeToMyScrollThrone() {
    const saved = localStorage.getItem(LS_SCROLL_SAUCE);
    if (!saved) return;

    const y = parseInt(saved, 10);
    if (!Number.isFinite(y) || y < 0) return;

    // Nexus likes shifting layout like it's a dance battle.
    // So we retry a bit.
    let tries = 0;
    const maxTries = 30;

    const doTheNudge = () => {
      tries++;
      const maxY = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
      const target = Math.min(y, maxY);

      window.scrollTo(0, target);

      if (Math.abs(window.scrollY - target) <= 2 || tries >= maxTries) return;
      setTimeout(doTheNudge, 100);
    };

    setTimeout(doTheNudge, 0);
  }

  // -------------------- worker tab detection (hash params) --------------------
  function sniffHashLikeATracersDog() {
    const raw = (location.hash || '').replace(/^#/, '');
    return raw ? new URLSearchParams(raw) : new URLSearchParams();
  }

  const hashGremlin = sniffHashLikeATracersDog();
  const THIS_IS_THE_POPUP_MINION = hashGremlin.get('nexus_autotab') === '1';
  const PARENT_MOD_DOX   = hashGremlin.get('modkey') || '';
  const PARENT_BTN_HREF  = hashGremlin.get('btnhref') || '';

  // -------------------- network sniffing (kept, not needed) --------------------
  function saveCdnCrumbsIfWeCatchEm(urlMaybe) {
    if (THIS_IS_THE_POPUP_MINION && !slowSmackMoment) return;
    if (!urlMaybe) return;

    let abs = '';
    try { abs = new URL(urlMaybe, location.href).toString(); }
    catch (_) { abs = String(urlMaybe); }

    if (!CDN_GOBLIN_RE.test(abs)) return;
    if (!cdnCrumbs) cdnCrumbs = abs;
  }

  (function installSneakyNetworkEarplugs() {
    const oldFetch = window.fetch;
    window.fetch = function (...args) {
      try { saveCdnCrumbsIfWeCatchEm(args && args[0]); } catch (_) {}
      return oldFetch.apply(this, args);
    };

    const oldXHROpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
      try { saveCdnCrumbsIfWeCatchEm(url); } catch (_) {}
      return oldXHROpen.call(this, method, url, ...rest);
    };

    const oldOpen = window.open;
    window.open = function (url, ...rest) {
      try { saveCdnCrumbsIfWeCatchEm(url); } catch (_) {}
      return oldOpen.apply(this, [url, ...rest]);
    };
  })();

  // -------------------- deep DOM spelunking (shadow DOM included) --------------------
  function vacuumUpAllElementsEvenFromShadowDimension(rootNode) {
    const lootPile = [];
    const stack = [rootNode];

    while (stack.length) {
      const node = stack.pop();
      if (!node) continue;

      const kids = node.querySelectorAll ? node.querySelectorAll('*') : [];
      for (const el of kids) {
        lootPile.push(el);
        if (el.shadowRoot) stack.push(el.shadowRoot);
      }
    }

    return lootPile;
  }

  function looksLikeAButtonOrAtLeastActsLikeOne(el) {
    if (!el || el.disabled) return false;
    if (!existsAndIsNotInvisible(el)) return false;

    const tag = el.tagName;
    if (tag === 'BUTTON' || tag === 'A') return true;

    const role = (el.getAttribute && el.getAttribute('role')) || '';
    if (role.toLowerCase() === 'button') return true;

    return typeof el.click === 'function';
  }

  function getReadableText(el) {
    return ((el && (el.innerText || el.textContent)) || '').trim().toLowerCase();
  }

  function bonkSlowDownloadIfItExists() {
    if (slowBtnAlreadySmacked) return false;

    const everything = vacuumUpAllElementsEvenFromShadowDimension(document);

    for (const el of everything) {
      if (!looksLikeAButtonOrAtLeastActsLikeOne(el)) continue;

      if (getReadableText(el) === 'slow download') {
        const now = Date.now();

        // no turbo-clicking like a gremlin
        if (now - lastClickBonkAt < 1200) return false;

        el.click();

        slowBtnAlreadySmacked = true;
        lastClickBonkAt = now;
        slowSmackMoment = Date.now();

        return true;
      }
    }

    return false;
  }

  function beginTheSlowDownloadHunt() {
    if (watcherIsAlreadyYapping) return;
    watcherIsAlreadyYapping = true;

    const start = Date.now();
    const timer = setInterval(() => {
      bonkSlowDownloadIfItExists();

      if (Date.now() - start > STALKING_TIMEOUT_MS) {
        clearInterval(timer);
        watcherIsAlreadyYapping = false;
      }
    }, POKE_INTERVAL_MS);
  }

  // -------------------- MAIN TAB: restore UI + scroll --------------------
  if (!THIS_IS_THE_POPUP_MINION) {
    (function rehydrateFromLocalStorageLikeAWizard() {
      const saved = attemptToParseJsonOrJustGiveUp(localStorage.getItem(LS_BTN_MOOD) || '');
      if (saved && saved.href && saved.label) {
        const btn = locateTheExactSameManualDownloadButton(saved.href);
        if (btn) renameButtonTo(btn, saved.label);
      }
      returnMeToMyScrollThrone();
    })();

    window.addEventListener('storage', (e) => {
      if (!e || e.key !== LS_BTN_MOOD) return;

      const saved = attemptToParseJsonOrJustGiveUp(localStorage.getItem(LS_BTN_MOOD) || '');
      if (!saved || !saved.href || !saved.label) return;

      const btn = locateTheExactSameManualDownloadButton(saved.href);
      if (btn) renameButtonTo(btn, saved.label);

      // optional: "Downloaded" -> back to "Manual download" later
      if (saved.label === 'Downloaded') {
        setTimeout(() => {
          const cur = attemptToParseJsonOrJustGiveUp(localStorage.getItem(LS_BTN_MOOD) || '');
          if (!cur || cur.href !== saved.href) return;
          if (cur.label === 'Downloaded') {
            cur.label = 'Manual download';
            localStorage.setItem(LS_BTN_MOOD, JSON.stringify(cur));
          }
        }, AUTO_UNDOWNLOAD_MY_FEELINGS_MS);
      }
    });
  }

  // -------------------- WORKER TAB: "did it start?" check --------------------
  function pageIsDoingTheDownloadStartedSpeech() {
    const txt = (document.body && (document.body.innerText || document.body.textContent)) || '';
    const t = txt.toLowerCase();
    return t.includes('your download has started') && t.includes('click here to download manually');
  }

  // -------------------- WORKER TAB: mark done + close popup --------------------
  function popupMinionChecksIfMissionComplete() {
    if (!THIS_IS_THE_POPUP_MINION) return;
    if (!PARENT_MOD_DOX || !PARENT_BTN_HREF) return;

    // must click slow first
    if (!slowSmackMoment) return;

    // don't close instantly (avoid early bail)
    if (Date.now() - slowSmackMoment < 2500) return;

    // only close when the page literally says it started
    if (!pageIsDoingTheDownloadStartedSpeech()) return;

    const parentKey = 'nexus_manual_btn_state:' + PARENT_MOD_DOX;
    localStorage.setItem(parentKey, JSON.stringify({ href: PARENT_BTN_HREF, label: 'Downloaded' }));

    if (window.opener) setTimeout(() => window.close(), POPUP_GO_BYEBYE_MS);
  }

  if (THIS_IS_THE_POPUP_MINION) {
    slowBtnAlreadySmacked = false;
    lastClickBonkAt = 0;

    beginTheSlowDownloadHunt();

    setInterval(() => popupMinionChecksIfMissionComplete(), 200);

    const omgEverythingChangedObserver = new MutationObserver(() => popupMinionChecksIfMissionComplete());
    omgEverythingChangedObserver.observe(document.documentElement, { childList: true, subtree: true });
  }

  // -------------------- MAIN TAB: intercept manual download click -> spawn popup minion --------------------
  if (!THIS_IS_THE_POPUP_MINION) {
    document.addEventListener('click', (event) => {
      const btn = event.target.closest('a.btn.inline-flex.popup-btn-ajax');
      if (!btn) return;

      // stop Nexus from doing its usual thing, we got this
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();

      // save scroll so we can pretend nothing happened
      localStorage.setItem(LS_SCROLL_SAUCE, String(window.scrollY || 0));

      renameButtonTo(btn, 'Downloading');

      const href = btn.getAttribute('href') || '';
      localStorage.setItem(LS_BTN_MOOD, JSON.stringify({ href, label: 'Downloading' }));

      const u = new URL(href, location.href);
      const p = new URLSearchParams();
      p.set('nexus_autotab', '1');
      p.set('modkey', MOD_DOX);
      p.set('btnhref', href);
      u.hash = p.toString();

      // open popup near cursor like a lil gremlin helper
      const px = (event && typeof event.screenX === 'number') ? event.screenX : window.screenX;
      const py = (event && typeof event.screenY === 'number') ? event.screenY : window.screenY;

      const CURSOR_BUBBLE = 12;
      const BABY_POPUP_W = 140, BABY_POPUP_H = 90;

      const features =
        `popup=yes,width=${BABY_POPUP_W},height=${BABY_POPUP_H},left=${px + CURSOR_BUBBLE},top=${py + CURSOR_BUBBLE},` +
        `resizable=no,scrollbars=no,toolbar=no,location=no,menubar=no,status=no`;

      const minion = window.open(u.toString(), 'nexus_worker', features);

      try {
        if (minion) {
          minion.blur();
          // Chrome sometimes steals focus after opening, so bonk focus back
          setTimeout(() => { try { window.focus(); } catch (_) {} }, 0);
        } else {
          window.focus();
        }
      } catch (_) {}

    }, true);
  }

  // -------------------- auto-run if slow download appears anywhere --------------------
  const slowDownloadSummoner = new MutationObserver(() => {
    const els = vacuumUpAllElementsEvenFromShadowDimension(document);
    for (const el of els) {
      if (!looksLikeAButtonOrAtLeastActsLikeOne(el)) continue;

      if (getReadableText(el) === 'slow download') {
        slowBtnAlreadySmacked = false;
        lastClickBonkAt = 0;
        beginTheSlowDownloadHunt();
        break;
      }
    }
  });

  slowDownloadSummoner.observe(document.documentElement, { childList: true, subtree: true });

})();


