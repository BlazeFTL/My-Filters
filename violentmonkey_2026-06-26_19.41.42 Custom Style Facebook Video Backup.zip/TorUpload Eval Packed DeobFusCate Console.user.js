// ==UserScript==
// @name         TorUpload Eval Packed DeobFusCate Console
// @namespace    https://github.com/BlazeFTL
// @description  Finds eval(function(p,a,c,k,e,d)) blocks and logs deobfuscated code to console.
// @version      1.1
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The logic to unpack p,a,c,k,e,d
    function unpack(p, a, c, k, e, d) {
        e = function(c) {
            return (c < a ? '' : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36));
        };
        if (!''.replace(/^/, String)) {
            while (c--) d[e(c)] = k[c] || e(c);
            k = [function(e) { return d[e]; }];
            e = function() { return '\\w+'; };
            c = 1;
        }
        while (c--) {
            if (k[c]) p = p.replace(new RegExp('\\b' + e(c) + '\\b', 'g'), k[c]);
        }
        return p;
    }

    const scripts = document.querySelectorAll('script:not([src])');
    const packerRegex = /eval\(function\(p,a,c,k,e,d\)\{.*return p\}\('(.*)',(\d+),(\d+),'(.*)'\.split\('\|'\),(\d+),\{(.*)\}\)\)/;

    scripts.forEach((script, index) => {
        const content = script.textContent;
        if (content.includes('function(p,a,c,k,e,d)')) {
            try {
                // We strip the 'eval' and execute the inner function to get the string
                // or use a regex to pull the arguments. A safer way is to replace 'eval' with a return.
                const deobfuscated = content.replace(/\beval\s*\(/, '(function(){return (') + ')})()';

                // Using Function constructor to safely evaluate the unpacking logic without executing the result
                const result = new Function(`return ${content.replace(/\beval\s*\(/, '(')}`)();

                console.group(`%c[Deobfuscator] Unpacked Script #${index + 1}`, "color: #00ffff; font-weight: bold;");
                console.log(result);
                console.groupEnd();
            } catch (err) {
                console.error(`[Deobfuscator] Failed to unpack script #${index + 1}:`, err);
            }
        }
    });
})();
// ==/UserScript==