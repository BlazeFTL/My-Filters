// ==UserScript==
// @name         GitHub Dedicated Delete Button Text
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Constructs a Delete button next to the 3-dot menu without needing to open the menu first.
// @author       BlazeFTL
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @match        https://github.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function createDeleteButton() {
        // 1. Get Repo Info from URL to construct the delete API link
        const pathParts = window.location.pathname.split('/').filter(p => p);
        // pathParts example: ['uBlockOrigin', 'uAssets', 'discussions', '27472']
        const owner = pathParts[0];
        const repo = pathParts[1];
        const type = pathParts[2]; // discussions, issues, or pull
        const typeId = pathParts[3]; // The number (e.g., 27472)

        if (!owner || !repo || !type || !typeId) return;

        // 2. Find all 3-dot menu toggle buttons
        // These buttons always exist, even if the menu is closed
        const menuToggles = document.querySelectorAll('button[aria-haspopup="true"][id^="Comment-actions"]');

        menuToggles.forEach(toggleBtn => {
            // Check if we already added our button next to this one
            if (toggleBtn.parentElement.querySelector('.gh-standalone-delete')) return;

            // 3. Extract the Comment ID from the button's ID
            // ID format: "Comment-actions-15945845-text"
            const idMatch = toggleBtn.id.match(/Comment-actions-(\d+)-text/);
            if (!idMatch) return;

            const commentId = idMatch[1];

            // 4. Construct the data-src URL dynamically
            // Pattern: /owner/repo/type/typeId/comments/commentId/delete_content_modal
            const deleteUrl = `/${owner}/${repo}/${type}/${typeId}/comments/${commentId}/delete_content_modal`;

            // 5. Create the new Button
            const newBtn = document.createElement('button');
            newBtn.type = 'button';
            newBtn.classList.add('gh-standalone-delete', 'btn-link');
            newBtn.textContent = 'Delete';

            // 6. Set the critical GitHub Catalyst attributes            // These tell GitHub what to do when clicked
            newBtn.setAttribute('data-action', 'click:comment-actions-container#displayDialog');
            newBtn.setAttribute('data-dialog-id', `dialog-delete-comment-${commentId}`);
            newBtn.setAttribute('data-title', 'Delete comment');
            newBtn.setAttribute('data-src', deleteUrl);
            newBtn.setAttribute('data-size', 'small');
            newBtn.setAttribute('role', 'menuitem'); // Helps styling

            // 7. Style it to look like the native Delete link (Red)
            Object.assign(newBtn.style, {
                color: '#cf222e',       // GitHub Danger Red
                fontSize: '12px',
                marginLeft: '8px',      // Space between 3-dots and Delete
                padding: '0',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                fontWeight: '500',
                textDecoration: 'none',
                display: 'inline-block'
            });

            // Hover effect
            newBtn.addEventListener('mouseenter', () => {
                newBtn.style.textDecoration = 'underline';
                newBtn.style.backgroundColor = '#ffebe9'; // Light red bg
                newBtn.style.borderRadius = '6px';
            });
            newBtn.addEventListener('mouseleave', () => {
                newBtn.style.textDecoration = 'none';
                newBtn.style.backgroundColor = 'transparent';
            });

            // 8. Insert it right after the 3-dot button
            // We insert into the parent to ensure it stays inside the
            // <comment-actions-container> which is required for the click to work.
            toggleBtn.parentNode.insertBefore(newBtn, toggleBtn.nextSibling);
        });
    }

    // Run immediately
    createDeleteButton();

    // Watch for new comments (e.g. if you click "Load more" or reply)
    const observer = new MutationObserver(() => {
        createDeleteButton();
    });

    observer.observe(document.body, {
        childList: true,        subtree: true
    });
})();