// ==UserScript==
// @name         10Drive Remove D-None From Class
// @namespace    https://github.com/BlazeFTL
// @description  Forcefully removes d-none from all elements and within srcdoc iframes
// @version      1.3
// @author       BlazeFTL
// @match        *://gamesmain.xyz/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to strip d-none from elements and iframe content
    const revealElements = (root) => {
        // Remove from standard elements
        const hiddenElements = root.querySelectorAll('.d-none');
        hiddenElements.forEach(el => el.classList.remove('d-none'));

        // Target iframes with srcdoc (common on this site)
        const iframes = root.querySelectorAll('iframe[srcdoc]');
        iframes.forEach(iframe => {
            if (iframe.srcdoc.includes('d-none')) {
                // Clean the srcdoc string and re-inject it
                iframe.srcdoc = iframe.srcdoc.replace(/d-none/g, '');
            }
        });
    };

    // Initial execution
    revealElements(document);

    // Watch for the site trying to re-hide elements (like after the 10s timer)
    const observer = new MutationObserver((mutations) => {
        mutations.forEach(() => revealElements(document));
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['class', 'srcdoc']
    });
})();

