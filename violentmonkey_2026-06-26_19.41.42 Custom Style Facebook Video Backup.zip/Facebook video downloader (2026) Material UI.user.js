// ==UserScript==
// @name        Facebook video downloader (2026) Material UI
// @icon        https://www.facebook.com/favicon.ico
// @namespace   Violentmonkey Scripts
// @match       https://www.facebook.com/*
// @match       https://web.facebook.com/*
// @match       https://m.facebook.com/*
// @grant       GM_registerMenuCommand
// @grant       GM_setValue
// @grant       GM_getValue
// @grant       unsafeWindow
// @run-at      document-start
// @version     3.0
// @author      https://github.com/HoangTran0410
// @description Download any video on Facebook (post/chat/comment)
// @license MIT
// ==/UserScript==

(() => {
  const pageWindow = typeof unsafeWindow !== "undefined" ? unsafeWindow : window;

  function ensureReactDevToolsHook() {
    if (pageWindow.__REACT_DEVTOOLS_GLOBAL_HOOK__) return;

    let nextRendererId = 0;
    const renderers = new Map();
    const fiberRoots = new Map();

    pageWindow.__REACT_DEVTOOLS_GLOBAL_HOOK__ = {
      supportsFiber: true,
      renderers,
      inject(renderer) {
        const rendererId = ++nextRendererId;
        renderers.set(rendererId, renderer);
        fiberRoots.set(rendererId, new Set());
        return rendererId;
      },
      onCommitFiberRoot(rendererId, root) {
        let roots = fiberRoots.get(rendererId);
        if (!roots) {
          roots = new Set();
          fiberRoots.set(rendererId, roots);
        }

        const current = root?.current;
        const isUnmounting =
          current?.memoizedState == null ||
          current?.memoizedState?.element == null;
        if (isUnmounting) {
          roots.delete(root);
          return;
        }

        roots.add(root);
      },
      onCommitFiberUnmount() {},
      getFiberRoots(rendererId) {
        return fiberRoots.get(rendererId) || new Set();
      },
      sub() {
        return function unsubscribe() {};
      },
      checkDCE() {},
    };
  }

  ensureReactDevToolsHook();

  let capturedDtsg = "";
  let capturedJazoest = null;

  async function getJazoest() {
    if (capturedJazoest) return capturedJazoest;
    let j = getJazoestFromHtml(document.documentElement.innerHTML);
    if (j) {
      capturedJazoest = j;
      return j;
    }
    return null;
  }
  let recentRequests = [];

  function recordRequest(url, body) {
    try {
      let bodyStr =
        typeof body === "string"
          ? body
          : body && typeof body.toString === "function"
          ? body.toString()
          : "";
      recentRequests.push({ url: String(url || "").slice(0, 120), body: bodyStr.slice(0, 300) });
      if (recentRequests.length > 8) recentRequests.shift();
    } catch (e) {}
  }

  function scanStringForDtsgToken(str) {
    if (!str || typeof str !== "string") return "";
    let m =
      str.match(/"dtsg":"([^"]+)"/) ||
      str.match(/fb_dtsg=([^&"'\s]+)/) ||
      str.match(/fb_dtsg["']?\s*[:=]\s*["']([^"'&\s]+)["']/i) ||
      str.match(/x-fb-dtsg["']?\s*[:=]\s*["']?([A-Za-z0-9_\-:]{10,80})/i);
    if (!m) return "";
    try {
      return decodeURIComponent(m[1]);
    } catch (e) {
      return m[1];
    }
  }

  function extractDtsgFromBody(body) {
    if (!body) return "";
    try {
      if (typeof body === "string") return scanStringForDtsgToken(body);
      if (typeof URLSearchParams !== "undefined" && body instanceof URLSearchParams) {
        return body.get("fb_dtsg") || "";
      }
      if (typeof FormData !== "undefined" && body instanceof FormData) {
        return body.get("fb_dtsg") || "";
      }
    } catch (e) {}
    return "";
  }

  function extractDtsgFromHeaders(headers) {
    if (!headers) return "";
    try {
      let entries =
        typeof headers.entries === "function"
          ? Array.from(headers.entries())
          : Object.entries(headers);
      for (let [k, v] of entries) {
        if (/dtsg/i.test(k)) return v;
        let found = scanStringForDtsgToken(k + ":" + v);
        if (found) return found;
      }
    } catch (e) {}
    return "";
  }

  function installDtsgSniffer() {
    const origFetch = pageWindow.fetch;
    if (origFetch && !origFetch.__dtsgPatched) {
      const patchedFetch = function (...args) {
        try {
          let url = typeof args[0] === "string" ? args[0] : args[0]?.url || "";
          recordRequest(url, args[1]?.body || "");

          let token = scanStringForDtsgToken(url);
          if (token) capturedDtsg = token;

          let headers = args[1]?.headers;
          token = extractDtsgFromHeaders(headers);
          if (token) capturedDtsg = token;

          let body = args[1]?.body;
          token = extractDtsgFromBody(body);
          if (token) capturedDtsg = token;

          if (typeof Request !== "undefined" && args[0] instanceof Request) {
            token = extractDtsgFromHeaders(args[0].headers);
            if (token) capturedDtsg = token;

            args[0]
              .clone()
              .text()
              .then((text) => {
                let t = extractDtsgFromBody(text);
                if (t) capturedDtsg = t;
              })
              .catch(() => {});
          }
        } catch (e) {}
        return origFetch.apply(this, args);
      };
      patchedFetch.__dtsgPatched = true;
      pageWindow.fetch = patchedFetch;
    }

    const origSend = pageWindow.XMLHttpRequest?.prototype?.send;
    if (origSend && !origSend.__dtsgPatched) {
      const patchedSend = function (body) {
        try {
          recordRequest(this.__lastUrl || "", body);
          let token = extractDtsgFromBody(body);
          if (token) capturedDtsg = token;
          if (this.__dtsgHeaderToken) capturedDtsg = this.__dtsgHeaderToken;
        } catch (e) {}
        return origSend.call(this, body);
      };
      patchedSend.__dtsgPatched = true;
      pageWindow.XMLHttpRequest.prototype.send = patchedSend;
    }

    const origSetHeader = pageWindow.XMLHttpRequest?.prototype?.setRequestHeader;
    if (origSetHeader && !origSetHeader.__dtsgPatched) {
      const patchedSetHeader = function (name, value) {
        try {
          if (/dtsg/i.test(name)) {
            capturedDtsg = value;
            this.__dtsgHeaderToken = value;
          }
        } catch (e) {}
        return origSetHeader.call(this, name, value);
      };
      patchedSetHeader.__dtsgPatched = true;
      pageWindow.XMLHttpRequest.prototype.setRequestHeader = patchedSetHeader;
    }

    const origOpen = pageWindow.XMLHttpRequest?.prototype?.open;
    if (origOpen && !origOpen.__dtsgPatched) {
      const patchedOpen = function (method, url, ...rest) {
        try {
          this.__lastUrl = url;
          let token = scanStringForDtsgToken(url);
          if (token) capturedDtsg = token;
        } catch (e) {}
        return origOpen.call(this, method, url, ...rest);
      };
      patchedOpen.__dtsgPatched = true;
      pageWindow.XMLHttpRequest.prototype.open = patchedOpen;
    }
  }

  installDtsgSniffer();

  function getOverlapScore(el) {
    var rect = el.getBoundingClientRect();
    return (
      Math.min(
        rect.bottom,
        window.innerHeight || document.documentElement.clientHeight
      ) - Math.max(0, rect.top)
    );
  }

  const videoContainerSelector = [
    "[data-video-id]",
    "[data-instancekey]",
    '[data-visualcompletion="ignore"]',
  ].join(",");

  function closestAncestor(element, selector, boundary = null) {
    let el = element;
    while (el && el.nodeType === Node.ELEMENT_NODE) {
      if (el.matches?.(selector)) return el;
      if (boundary && el === boundary) break;
      el = el.parentElement;
    }
    return null;
  }

  function getVideoScope(videoEle) {
    if (!videoEle) return null;
    return (
      closestAncestor(videoEle, videoContainerSelector) ||
      videoEle.parentElement
    );
  }

  const facebookVideoLinkSelector = [
    "a[href*='/reel/']",
    "a[href*='/watch/?v=']",
    "a[href*='/watch?v=']",
    "a[href*='/videos/']",
    "a[href*='video_id=']",
    "a[href*='videoid=']",
  ].join(",");

  function isNumericString(str) {
    return typeof str === "string" && /^[0-9]+$/.test(str);
  }

  function cleanNumericId(value) {
    if (!value) return "";
    const id = String(value).split("?")[0].split("&")[0];
    return isNumericString(id) && id !== "ifu" ? id : "";
  }

  function getVideoIdFromUrl(url) {
    if (!url) return "";

    const href = String(url);
    const parts = href.split("/");
    let idpost = "";

    if (href.includes("/reel/")) {
      idpost = cleanNumericId(parts[4]);
      if (idpost) return idpost;
    }

    if (href.includes("/videos/")) {
      const videoIndex = parts.indexOf("videos");
      idpost = cleanNumericId(parts[videoIndex + 1]);
      if (idpost) return idpost;
    }

    if (href.includes("pagechienca/")) {
      idpost = cleanNumericId(parts[5]);
      if (idpost) return idpost;
    }

    if (href.includes("=")) {
      idpost = cleanNumericId(href.split("=")[1]);
      if (idpost) return idpost;
    }

    idpost = cleanNumericId(parts[5]);
    if (idpost) return idpost;

    idpost = cleanNumericId(parts[6]);
    if (idpost) return idpost;

    return "";
  }

  function getVideoIdFromPageUrl() {
    const reelpost = location.pathname.includes("/reel/");
    const videourl = location.pathname.includes("/videos/");
    const watchurl = location.pathname.startsWith("/watch");

    if (!reelpost && !videourl && !watchurl) return "";

    return getVideoIdFromUrl(location.href);
  }

  function getClosestInstanceKeyElement(videoEle, container) {
    return (
      closestAncestor(videoEle, 'div[data-instancekey^="id-vpuid"]') ||
      closestAncestor(container, 'div[data-instancekey^="id-vpuid"]') ||
      Array.from(
        document.querySelectorAll('div[data-instancekey^="id-vpuid"]')
      ).find((element) => element.contains(videoEle)) ||
      null
    );
  }

  function getVideoIdFromStorySaverDom(videoEle, container) {
    const pageVideoId = getVideoIdFromPageUrl();
    if (pageVideoId) return pageVideoId;

    let max =
      getClosestInstanceKeyElement(videoEle, container) ||
      videoEle?.parentElement ||
      container;
    let maxadd = 0;

    while (max && max !== document.body) {
      const query = max.querySelectorAll?.(facebookVideoLinkSelector);

      if (query?.length) {
        for (let item of query) {
          const idpost = getVideoIdFromUrl(item.href);
          if (idpost) return idpost;
        }
      }

      maxadd += 1;
      if (maxadd > 100) break;
      max = max.parentElement;
    }

    return "";
  }

  function getFiberName(fiber) {
    const type = fiber?.elementType || fiber?.type;
    return (
      type?.displayName ||
      type?.name ||
      fiber?._debugOwner?.elementType?.displayName ||
      fiber?._debugOwner?.elementType?.name ||
      fiber?._debugOwner?.type?.displayName ||
      fiber?._debugOwner?.type?.name ||
      ""
    );
  }

  function getVideoIdFromProps(props) {
    const id = props?.video?.id;
    return cleanNumericId(id);
  }

  function getVideoIdFromFiberProps(fiber) {
    return (
      getVideoIdFromProps(fiber?.memoizedProps) ||
      getVideoIdFromProps(fiber?.pendingProps)
    );
  }

  function isVideoControlsFiber(fiber) {
    const componentName = getFiberName(fiber);
    return componentName.includes(
      "FBUnifiedLightweightVideoAttachmentMediaControls"
    );
  }

  function getDevToolsHook() {
    return pageWindow.__REACT_DEVTOOLS_GLOBAL_HOOK__ || null;
  }

  function getVideoBoundary(videoEle, container) {
    return (
      closestAncestor(
        videoEle,
        '[role="article"],[data-pagelet^="FeedUnit_"]'
      ) ||
      closestAncestor(
        container,
        '[role="article"],[data-pagelet^="FeedUnit_"]'
      ) ||
      container ||
      videoEle?.parentElement ||
      null
    );
  }

  function getDescendantHostElement(fiber) {
    const stack = [fiber?.child];
    const visited = new Set();
    let count = 0;

    while (stack.length && count < 300) {
      const current = stack.pop();
      if (!current || visited.has(current)) continue;

      visited.add(current);
      count++;

      if (current.stateNode?.nodeType === Node.ELEMENT_NODE) {
        return current.stateNode;
      }

      if (current.sibling) stack.push(current.sibling);
      if (current.child) stack.push(current.child);
    }

    return null;
  }

  function getAncestorHostElement(fiber) {
    let current = fiber;
    let level = 0;

    while (current && level < 80) {
      if (current.stateNode?.nodeType === Node.ELEMENT_NODE) {
        return current.stateNode;
      }

      current = current.return;
      level++;
    }

    return null;
  }

  function getFiberHostElement(fiber) {
    return getDescendantHostElement(fiber) || getAncestorHostElement(fiber);
  }

  function getRectDistance(a, b) {
    if (!a || !b || !a.width || !a.height || !b.width || !b.height) {
      return Number.POSITIVE_INFINITY;
    }

    const ax = a.left + a.width / 2;
    const ay = a.top + a.height / 2;
    const bx = b.left + b.width / 2;
    const by = b.top + b.height / 2;

    return Math.hypot(ax - bx, ay - by);
  }

  function getRectIntersectionRatio(a, b) {
    if (!a || !b || !a.width || !a.height || !b.width || !b.height) return 0;

    const left = Math.max(a.left, b.left);
    const top = Math.max(a.top, b.top);
    const right = Math.min(a.right, b.right);
    const bottom = Math.min(a.bottom, b.bottom);
    const width = Math.max(0, right - left);
    const height = Math.max(0, bottom - top);
    const intersection = width * height;
    const smallerArea = Math.min(a.width * a.height, b.width * b.height);

    return smallerArea ? intersection / smallerArea : 0;
  }

  function isHostElementRelatedToVideo(hostElement, videoEle, container) {
    if (!hostElement) return false;
    if (hostElement === videoEle) return true;
    if (hostElement.contains?.(videoEle) || videoEle?.contains?.(hostElement)) {
      return true;
    }
    if (
      container?.contains?.(hostElement) ||
      hostElement.contains?.(container)
    ) {
      return true;
    }

    const boundary = getVideoBoundary(videoEle, container);
    if (boundary?.contains?.(hostElement)) return true;

    const hostRect = hostElement.getBoundingClientRect?.();
    const videoRect = videoEle?.getBoundingClientRect?.();
    return getRectDistance(hostRect, videoRect) < 700;
  }

  function collectVideoIdCandidatesFromFiberSubtree(
    rootFiber,
    videoEle,
    container,
    limit = 60000
  ) {
    const stack = [rootFiber];
    const visited = new Set();
    const candidates = [];
    let count = 0;

    while (stack.length && count < limit) {
      const fiber = stack.pop();
      if (!fiber || visited.has(fiber)) continue;

      visited.add(fiber);
      count++;

      const videoId = getVideoIdFromFiberProps(fiber);
      if (videoId) {
        const hostElement = getFiberHostElement(fiber);
        const hostRect = hostElement?.getBoundingClientRect?.();
        const videoRect = videoEle?.getBoundingClientRect?.();
        const isRelated = isHostElementRelatedToVideo(
          hostElement,
          videoEle,
          container
        );
        const overlap = getRectIntersectionRatio(hostRect, videoRect);
        const distance = getRectDistance(hostRect, videoRect);

        candidates.push({
          id: videoId,
          isVideoControls: isVideoControlsFiber(fiber),
          isRelated,
          score:
            (isRelated ? 1000 : 0) +
            (isVideoControlsFiber(fiber) ? 500 : 0) +
            Math.round(overlap * 300) -
            (Number.isFinite(distance) ? Math.round(distance) : 10000),
        });
      }

      if (fiber.sibling) stack.push(fiber.sibling);
      if (fiber.child) stack.push(fiber.child);
    }

    return candidates;
  }

  function pickNearestVideoIdCandidate(candidates) {
    return candidates
      .filter((item) => item.isRelated)
      .sort((a, b) => b.score - a.score)[0];
  }

  function getVideoIdFromDevToolsRoots(videoEle, container) {
    const hook = getDevToolsHook();
    if (!hook?.renderers || !hook?.getFiberRoots) return "";

    const candidates = [];

    for (let rendererId of hook.renderers.keys()) {
      let roots = null;

      try {
        roots = hook.getFiberRoots(rendererId);
      } catch (e) {
        console.log("FB video downloader: React root lookup failed", e);
      }

      if (!roots) continue;

      for (let root of roots) {
        const rootFiber = root?.current || root;
        candidates.push(
          ...collectVideoIdCandidatesFromFiberSubtree(
            rootFiber,
            videoEle,
            container,
            60000
          )
        );
      }
    }

    return pickNearestVideoIdCandidate(candidates)?.id || "";
  }

  function getVideoIdFromReactProps(videoEle) {
    try {
      let key = "";
      for (let k in videoEle.parentElement) {
        if (k.startsWith("__reactProps")) {
          key = k;
          break;
        }
      }
      const props = videoEle.parentElement[key].children.props;
      return props.videoFBID || props.coreVideoPlayerMetaData?.videoFBID;
    } catch (e) {
      console.log("ERROR on get videoFBID: ", e);
      return null;
    }
  }

  function getVideoIdFromVideoElement(videoEle) {
    const container = getVideoScope(videoEle);
    const videoId =
      getVideoIdFromDevToolsRoots(videoEle, container) ||
      getVideoIdFromStorySaverDom(videoEle, container) ||
      getVideoIdFromReactProps(videoEle);

    if (!videoId) {
      const hook = getDevToolsHook();
      console.log("FB video downloader: video id resolver failed", {
        href: location.href,
        hasVideo: !!videoEle,
        hasContainer: !!container,
        hasDevToolsHook: !!hook,
        rendererCount: hook?.renderers?.size || 0,
        instanceKey: getClosestInstanceKeyElement(
          videoEle,
          container
        )?.getAttribute?.("data-instancekey"),
      });
    }

    return videoId;
  }

  async function getWatchingVideoId() {
    let allVideos = Array.from(document.querySelectorAll("video"));
    let result = [];

    for (let video of allVideos) {
      let videoId = getVideoIdFromVideoElement(video);
      if (videoId) {
        result.push({
          videoId,
          overlapScore: getOverlapScore(video),
          playing: !!(
            video.currentTime > 0 &&
            !video.paused &&
            !video.ended &&
            video.readyState > 2
          ),
        });
      }
    }

    let playingVideo = result.find((_) => _.playing);
    if (playingVideo) return [playingVideo.videoId];

    return result
      .filter((_) => _.videoId && (_.overlapScore > 0 || _.playing))
      .sort((a, b) => b.overlapScore - a.overlapScore)
      .map((_) => _.videoId);
  }

  async function getVideoUrlFromVideoId(videoId) {
    let dtsg = await getDtsg();
    try {
      return await getLinkFbVideo2(videoId, dtsg);
    } catch (e) {
      return await getLinkFbVideo1(videoId, dtsg);
    }
  }

  async function getLinkFbVideo2(videoId, dtsg) {
    let jazoest = await getJazoest();
    let bodyObj = { __a: "1", fb_dtsg: dtsg };
    if (jazoest) bodyObj[jazoest.name] = jazoest.value;

    let res = await fetch(
      "https://www.facebook.com/video/video_data_async/?video_id=" + videoId,
      {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: stringifyVariables(bodyObj),
      }
    );

    let text = await res.text();
    text = text.replace("for (;;);", "");
    let json = JSON.parse(text);

    const { hd_src, hd_src_no_ratelimit, sd_src, sd_src_no_ratelimit } =
      json?.payload || {};

    return hd_src_no_ratelimit || hd_src || sd_src_no_ratelimit || sd_src;
  }

  async function getLinkFbVideo1(videoId, dtsg) {
    let res = await fetchGraphQl("5279476072161634", {
      UFI2CommentsProvider_commentsKey: "CometTahoeSidePaneQuery",
      caller: "CHANNEL_VIEW_FROM_PAGE_TIMELINE",
      displayCommentsContextEnableComment: null,
      displayCommentsContextIsAdPreview: null,
      displayCommentsContextIsAggregatedShare: null,
      displayCommentsContextIsStorySet: null,
      displayCommentsFeedbackContext: null,
      feedbackSource: 41,
      feedLocation: "TAHOE",
      focusCommentID: null,
      privacySelectorRenderLocation: "COMET_STREAM",
      renderLocation: "video_channel",
      scale: 1,
      streamChainingSection: !1,
      useDefaultActor: !1,
      videoChainingContext: null,
      videoID: videoId,
    }, dtsg);
    let text = await res.text();

    let a = JSON.parse(text.split("\n")[0]),
      link = a.data.video.playable_url_quality_hd || a.data.video.playable_url;

    return link;
  }

  async function fetchGraphQl(doc_id, variables, dtsg) {
    let jazoest = await getJazoest();
    let bodyObj = {
      doc_id: doc_id,
      variables: JSON.stringify(variables),
      fb_dtsg: dtsg,
      server_timestamps: !0,
    };
    if (jazoest) bodyObj[jazoest.name] = jazoest.value;

    return fetch("https://www.facebook.com/api/graphql/", {
      method: "POST",
      headers: {
        "content-type": "application/x-www-form-urlencoded",
      },
      body: stringifyVariables(bodyObj),
    });
  }

  function stringifyVariables(d, e) {
    let f = [],
      a;
    for (a in d)
      if (d.hasOwnProperty(a)) {
        let g = e ? e + "[" + a + "]" : a,
          b = d[a];
        f.push(
          null !== b && "object" == typeof b
            ? stringifyVariables(b, g)
            : encodeURIComponent(g) + "=" + encodeURIComponent(b)
        );
      }
    return f.join("&");
  }

  function getDtsgFromHtml(html) {
    html = html.replace(/\\u0022/g, '"').replace(/\\"/g, '"');

    let m =
      html.match(/"dtsg":"([^"]+)"/) ||
      html.match(/"token":"([^"]+)","async_get_token"/) ||
      html.match(/"dtsg":\{"token":"([^"]+)"/) ||
      html.match(/DTSGInitialData[^{]*\{"token":"([^"]+)"/) ||
      html.match(/DTSGInitData[^{]*\{"token":"([^"]+)"/) ||
      html.match(/name="fb_dtsg"\s+value="([^"]+)"/) ||
      html.match(/fb_dtsg["']?\s*[:=]\s*["']([^"'\\]+)["']/);
    return m ? m[1] : "";
  }

  function getJazoestFromHtml(html) {
    html = html.replace(/\\u0022/g, '"').replace(/\\"/g, '"');
    let name = html.match(/"sprinkleParamName":"([^"]+)"/);
    let value = html.match(/"sprinkleValue":"([^"]+)"/);
    if (name && value) return { name: name[1], value: value[1] };
    return null;
  }

  function getDtsgFromScripts() {
    let scripts = document.querySelectorAll("script");
    for (let s of scripts) {
      let token = getDtsgFromHtml(s.textContent || "");
      if (token) return token;
    }
    return "";
  }

  function getDtsgFromAnyTokenNearDtsgMention(html) {
    html = html.replace(/\\u0022/g, '"').replace(/\\"/g, '"');

    let idx = html.indexOf("DTSGInit");
    if (idx === -1) idx = html.indexOf("fb_dtsg");
    if (idx === -1) return "";

    let window_ = html.slice(idx, idx + 800);
    let m = window_.match(/"token":"([^"]+)"/);
    return m ? m[1] : "";
  }

  function getDtsgFromAnyScriptNearMention() {
    let scripts = document.querySelectorAll("script");
    for (let s of scripts) {
      let text = s.textContent || "";
      let token = getDtsgFromAnyTokenNearDtsgMention(text);
      if (token) return token;
    }
    return "";
  }

  function getDtsgFromCookie() {
    let m = document.cookie.match(/fb_dtsg=([^;]+)/);
    return m ? decodeURIComponent(m[1]) : "";
  }

  async function getDtsg() {
    if (capturedDtsg) return capturedDtsg;

    try {
      return require("DTSGInitialData").token;
    } catch (e) {}

    let token = getDtsgFromHtml(document.documentElement.innerHTML);
    if (token) return token;

    token = getDtsgFromScripts();
    if (token) return token;

    token = getDtsgFromAnyScriptNearMention();
    if (token) return token;

    try {
      let res = await fetch(location.href, { credentials: "include" });
      let html = await res.text();
      token = getDtsgFromHtml(html) || getDtsgFromAnyTokenNearDtsgMention(html);
      if (token) return token;
    } catch (e) {}

    try {
      let res = await fetch(location.origin + "/", { credentials: "include" });
      let html = await res.text();
      token = getDtsgFromHtml(html) || getDtsgFromAnyTokenNearDtsgMention(html);
      if (token) return token;
    } catch (e) {}

    token = getDtsgFromCookie();
    if (token) return token;

    for (let i = 0; i < 10; i++) {
      if (capturedDtsg) return capturedDtsg;
      await new Promise((r) => setTimeout(r, 200));
    }

    throw new Error("Could not resolve fb_dtsg token");
  }

  // ---- filename logic (ported from FB Media Sniffer) ----

  const NAME_BLOCKLIST = /^(open app|search|notifications?|messenger|marketplace|reels?|follow|following|like|likes|comment|comments|share|shares|more|tap to unmute|tap to mute|verified|public|friends|profile picture|settings|menu|options|home|watch|groups?|gaming|video call|mute|unmute|facebook)$/i;

  function isNameLike(txt) {
    if (!txt) return false;
    txt = txt.trim();
    if (txt.length < 2 || txt.length > 50) return false;
    if (NAME_BLOCKLIST.test(txt)) return false;
    if (/^[\d\s+.,KkMm]+$/.test(txt)) return false;
    return true;
  }

  function sanitize(name) {
    return name.replace(/[^a-z0-9]+/gi, "_").replace(/^_+|_+$/g, "") || "facebook";
  }

  function pad(n) {
    return n < 10 ? "0" + n : "" + n;
  }

  function dateStamp() {
    const d = new Date();
    return (
      d.getFullYear() +
      pad(d.getMonth() + 1) +
      pad(d.getDate()) +
      "-" +
      pad(d.getHours()) +
      pad(d.getMinutes()) +
      pad(d.getSeconds())
    );
  }

  function findAvatar() {
    const els = document.querySelectorAll('img, [role="img"]');
    for (const el of els) {
      const r = el.getBoundingClientRect();
      if (r.width < 28 || r.width > 60) continue;
      if (Math.abs(r.width - r.height) > 6) continue;
      if (r.bottom < window.innerHeight * 0.55) continue;
      if (r.left > window.innerWidth * 0.3) continue;
      return el;
    }
    return null;
  }

  function getProfileNameByAvatar() {
    const avatar = findAvatar();
    if (!avatar) return null;
    const ar = avatar.getBoundingClientRect();
    const all = document.querySelectorAll("body *");
    let bestEl = null, bestDist = Infinity;
    for (const el of all) {
      if (el.children.length > 2) continue;
      const txt = (el.textContent || "").trim();
      if (!isNameLike(txt)) continue;
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      if (r.left < ar.right - 4) continue;
      if (Math.abs((r.top + r.bottom) / 2 - (ar.top + ar.bottom) / 2) > 24) continue;
      const dist = r.left - ar.right;
      if (dist < bestDist) {
        bestDist = dist;
        bestEl = el;
      }
    }
    return bestEl ? bestEl.textContent.trim() : null;
  }

  function getProfileNameDom() {
    const anchors = document.querySelectorAll('a[aria-label^="See owner pro"]');
    for (const a of anchors) {
      const r = a.getBoundingClientRect();
      if (r.width > 0 && r.height > 0 && r.top < window.innerHeight && r.bottom > 0) {
        const txt = a.textContent.trim();
        if (isNameLike(txt)) return txt;
      }
    }
    return getProfileNameByAvatar();
  }

  function currentName() {
    return getProfileNameDom() || "facebook";
  }

  function buildFilename(suffix) {
    const base = sanitize(currentName()) + "_" + dateStamp();
    return suffix ? base + "_" + suffix + ".mp4" : base + ".mp4";
  }

  // ---- download methods ----

  function openInApp(url, filename) {
    let link = document.createElement("a");
    link.href = url;
    link.target = "_blank";
    if (filename) link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  async function downloadAsBlob(url, filename, onProgress) {
    try {
      let res = await fetch(url);
      if (!res.ok) throw new Error("fetch failed: " + res.status);

      const contentLength = res.headers.get('content-length');
      const total = contentLength ? parseInt(contentLength, 10) : 0;

      if (!total || !res.body) {
        let blob = await res.blob();
        let blobUrl = URL.createObjectURL(blob);
        let link = document.createElement("a");
        link.href = blobUrl;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
        return;
      }

      const reader = res.body.getReader();
      const chunks = [];
      let received = 0;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
        received += value.length;
        if (onProgress) {
          onProgress(Math.round((received / total) * 100));
        }
      }

      const blob = new Blob(chunks);
      let blobUrl = URL.createObjectURL(blob);
      let link = document.createElement("a");
      link.href = blobUrl;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    } catch (e) {
      console.log("FB video downloader: blob download failed, falling back to direct link", e);
      openInApp(url, filename);
    }
  }

  async function downloadWatchingVideo() {
    try {
      let listVideoId = await getWatchingVideoId();
      if (!listVideoId?.length > 0) throw Error("No video found in the page");

      console.log(listVideoId);

      for (let videoId of listVideoId) {
        let videoUrl = await getVideoUrlFromVideoId(videoId);
        if (videoUrl) await downloadAsBlob(videoUrl, buildFilename());
      }
    } catch (e) {
      alert("ERROR: " + e + "\n\nTry scrolling/liking/playing a video first, then retry.");
    }
  }

  let defaultMethod = GM_getValue("fbvd_default_method", "blob");

  function methodLabel() {
    return defaultMethod === "app" ? "External Downloader ▾" : "Download ▾";
  }

  function setDefaultMethod(method) {
    defaultMethod = method;
    GM_setValue("fbvd_default_method", method);
    if (typeof label !== "undefined" && label) label.textContent = methodLabel();
  }

  function resisterMenuCommand() {
    GM_registerMenuCommand("Download watching video", downloadWatchingVideo);
    GM_registerMenuCommand(
      "Set default: Download" + (defaultMethod === "blob" ? " ✓" : ""),
      () => setDefaultMethod("blob")
    );
    GM_registerMenuCommand(
      "Set default: External Downloader" + (defaultMethod === "app" ? " ✓" : ""),
      () => setDefaultMethod("app")
    );
  }

  resisterMenuCommand();

  // ---- Material Design UI ----

  const ICONS = {
    download: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
    external: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`,
    star: `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>`,
    starEmpty: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>`,
    more: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`
  };

  let currentVideo = null;
  let wrap = null, btn = null, label = null, popup = null, backdrop = null, progressRing = null;
  let busy = false;

  function createRipple(e, container) {
    const circle = document.createElement("span");
    const diameter = Math.max(container.clientWidth, container.clientHeight);
    const radius = diameter / 2;
    const rect = container.getBoundingClientRect();
    circle.style.cssText = `
      position:absolute;
      border-radius:50%;
      transform:scale(0);
      animation:fbvd-ripple 600ms linear;
      background-color:rgba(255,255,255,0.3);
      width:${diameter}px;height:${diameter}px;
      left:${e.clientX - rect.left - radius}px;
      top:${e.clientY - rect.top - radius}px;
      pointer-events:none;
    `;
    container.appendChild(circle);
    setTimeout(() => circle.remove(), 600);
  }

  function injectStyles() {
    if (document.getElementById("fbvd-material-styles")) return;
    const style = document.createElement("style");
    style.id = "fbvd-material-styles";
    style.textContent = `
      @keyframes fbvd-ripple {
        to { transform: scale(4); opacity: 0; }
      }
      @keyframes fbvd-fade-in {
        from { opacity: 0; transform: translateY(8px) scale(0.96); }
        to { opacity: 1; transform: translateY(0) scale(1); }
      }
      @keyframes fbvd-spin {
        to { transform: rotate(360deg); }
      }
      .fbvd-fab {
        width: 56px; height: 56px; border-radius: 16px;
        background: linear-gradient(135deg, #6366f1 0%, #4f46e5 100%);
        color: #fff; display: flex; align-items: center; justify-content: center;
        font-size: 18px; text-decoration: none; cursor: pointer;
        box-shadow: 0 4px 20px rgba(79, 70, 229, 0.4), 0 1px 3px rgba(0,0,0,0.15);
        border: none; outline: none; position: relative; overflow: hidden;
        transition: transform 0.2s cubic-bezier(0.4,0,0.2,1), box-shadow 0.2s;
        user-select: none; -webkit-tap-highlight-color: transparent;
      }
      .fbvd-fab:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 28px rgba(79, 70, 229, 0.5), 0 2px 6px rgba(0,0,0,0.2);
      }
      .fbvd-fab:active { transform: translateY(0) scale(0.96); }
      .fbvd-fab svg { pointer-events: none; }
      .fbvd-fab-progress {
        position: absolute; top: -4px; left: -4px; width: 64px; height: 64px;
        pointer-events: none; transform: rotate(-90deg);
      }
      .fbvd-fab-progress circle {
        fill: none; stroke: rgba(255,255,255,0.25); stroke-width: 3;
      }
      .fbvd-fab-progress .fbvd-progress-bar {
        stroke: #fff; stroke-dasharray: 188.5; stroke-dashoffset: 188.5;
        stroke-linecap: round; transition: stroke-dashoffset 0.3s;
      }
      .fbvd-label {
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
        font-size: 11px; font-weight: 600; color: #fff;
        background: rgba(15, 23, 42, 0.85); padding: 4px 10px;
        border-radius: 20px; cursor: pointer; backdrop-filter: blur(8px);
        box-shadow: 0 2px 8px rgba(0,0,0,0.15); border: 1px solid rgba(255,255,255,0.08);
        transition: background 0.2s; letter-spacing: 0.2px; display: flex; align-items: center; gap: 4px;
        user-select: none;
      }
      .fbvd-label:hover { background: rgba(15, 23, 42, 0.95); }
      .fbvd-backdrop {
        position: fixed; inset: 0; z-index: 999998; background: rgba(0,0,0,0.2);
        opacity: 0; transition: opacity 0.2s; pointer-events: none;
      }
      .fbvd-backdrop.show { opacity: 1; pointer-events: auto; }
      .fbvd-popup {
        position: fixed; top: 370px; right: 18px; z-index: 999999;
        background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(20px) saturate(1.8);
        border-radius: 16px; padding: 6px; display: none; flex-direction: column; gap: 2px;
        min-width: 200px; box-shadow: 0 20px 40px rgba(0,0,0,0.2), 0 0 0 1px rgba(0,0,0,0.05);
        animation: fbvd-fade-in 0.25s cubic-bezier(0.4,0,0.2,1);
        font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
      }
      .fbvd-popup-row {
        display: flex; align-items: center; justify-content: space-between; gap: 10px;
        color: #1e293b; font-size: 13px; padding: 10px 12px; border-radius: 12px;
        cursor: pointer; transition: background 0.15s; font-weight: 500;
      }
      .fbvd-popup-row:hover { background: rgba(99, 102, 241, 0.08); }
      .fbvd-popup-row:active { background: rgba(99, 102, 241, 0.14); }
      .fbvd-popup-row .fbvd-row-left { display: flex; align-items: center; gap: 10px; flex: 1; }
      .fbvd-popup-row .fbvd-row-icon { color: #4f46e5; display: flex; align-items: center; }
      .fbvd-popup-row .fbvd-star { color: #f59e0b; display: flex; align-items: center; padding: 2px; border-radius: 6px; transition: background 0.15s; }
      .fbvd-popup-row .fbvd-star:hover { background: rgba(245, 158, 11, 0.12); }
      .fbvd-popup-row .fbvd-star svg { display: block; }
    `;
    document.head.appendChild(style);
  }

  function closePopup() {
    if (popup) {
      popup.style.display = "none";
      popup = null;
    }
    if (backdrop) {
      backdrop.classList.remove("show");
      setTimeout(() => {
        if (backdrop && !backdrop.classList.contains("show")) {
          backdrop.remove();
          backdrop = null;
        }
      }, 200);
    }
  }

  function openPopup() {
    closePopup();
    injectStyles();

    backdrop = document.createElement("div");
    backdrop.className = "fbvd-backdrop";
    backdrop.onclick = closePopup;
    document.body.appendChild(backdrop);
    requestAnimationFrame(() => backdrop.classList.add("show"));

    popup = document.createElement("div");
    popup.className = "fbvd-popup";

    const options = [
      { label: "Download", method: "blob", icon: ICONS.download },
      { label: "External Downloader", method: "app", icon: ICONS.external },
    ];

    options.forEach((opt) => {
      const row = document.createElement("div");
      row.className = "fbvd-popup-row";

      const left = document.createElement("div");
      left.className = "fbvd-row-left";

      const iconWrap = document.createElement("span");
      iconWrap.className = "fbvd-row-icon";
      iconWrap.innerHTML = opt.icon;

      const text = document.createElement("span");
      text.textContent = opt.label;

      left.appendChild(iconWrap);
      left.appendChild(text);
      left.onclick = () => {
        closePopup();
        runDownload(opt.method);
      };

      const star = document.createElement("span");
      star.className = "fbvd-star";
      star.title = "Set as default";
      star.innerHTML = defaultMethod === opt.method ? ICONS.star : ICONS.starEmpty;
      star.onclick = (ev) => {
        ev.stopPropagation();
        setDefaultMethod(opt.method);
        openPopup();
      };

      row.appendChild(left);
      row.appendChild(star);
      popup.appendChild(row);
    });

    document.body.appendChild(popup);
    popup.style.display = "flex";
  }

  function ensureUI() {
    if (wrap) return;
    injectStyles();

    wrap = document.createElement("div");
    wrap.style.cssText =
      "position:fixed;top:310px;right:18px;z-index:999999;display:none;flex-direction:column;align-items:center;gap:6px;";

    btn = document.createElement("button");
    btn.className = "fbvd-fab";
    btn.innerHTML = ICONS.download;

    // Progress ring SVG
    const svgNS = "http://www.w3.org/2000/svg";
    progressRing = document.createElementNS(svgNS, "svg");
    progressRing.setAttribute("class", "fbvd-fab-progress");
    progressRing.setAttribute("viewBox", "0 0 64 64");
    const track = document.createElementNS(svgNS, "circle");
    track.setAttribute("cx", "32");
    track.setAttribute("cy", "32");
    track.setAttribute("r", "30");
    const bar = document.createElementNS(svgNS, "circle");
    bar.setAttribute("class", "fbvd-progress-bar");
    bar.setAttribute("cx", "32");
    bar.setAttribute("cy", "32");
    bar.setAttribute("r", "30");
    progressRing.appendChild(track);
    progressRing.appendChild(bar);
    btn.appendChild(progressRing);

    label = document.createElement("span");
    label.className = "fbvd-label";
    label.innerHTML = methodLabel() + ICONS.more;

    wrap.appendChild(btn);
    wrap.appendChild(label);
    document.body.appendChild(wrap);

    btn.addEventListener("click", function (ev) {
      createRipple(ev, btn);
      closePopup();
      runDownload(defaultMethod);
    });

    label.addEventListener("click", function (ev) {
      ev.preventDefault();
      if (popup && popup.style.display === "flex") closePopup();
      else openPopup();
    });
  }

  function setProgress(pct) {
    if (!progressRing) return;
    const bar = progressRing.querySelector(".fbvd-progress-bar");
    const circumference = 2 * Math.PI * 30; // ~188.5
    const offset = circumference - (pct / 100) * circumference;
    bar.style.strokeDashoffset = offset;
  }

  function findFallbackVideo() {
    let best = null, bestScore = -1;
    document.querySelectorAll("video[data-fms-watched]").forEach(v => {
      const score = getOverlapScore(v);
      if (score > bestScore) {
        bestScore = score;
        best = v;
      }
    });
    return bestScore > 0 ? best : null;
  }

  async function runDownload(method) {
    if (busy) return;
    const targetVideo = currentVideo || findFallbackVideo();
    if (!targetVideo) {
      alert("No video in view");
      return;
    }
    busy = true;
    const prevLabel = label.innerHTML;
    label.innerHTML = "Downloading...";
    setProgress(0);
    try {
      const videoId = getVideoIdFromVideoElement(targetVideo);
      if (!videoId) throw new Error("Could not find video id");
      const videoUrl = await getVideoUrlFromVideoId(videoId);
      if (!videoUrl) throw new Error("Could not resolve video URL");
      const filename = buildFilename();
      if (method === "app") {
        openInApp(videoUrl, filename);
      } else {
        await downloadAsBlob(videoUrl, filename, (pct) => {
          label.innerHTML = pct + "%";
          setProgress(pct);
        });
      }
    } catch (e) {
      alert("ERROR: " + e + "\n\nTry scrolling/liking/playing a video first, then retry.");
    } finally {
      busy = false;
      label.innerHTML = prevLabel;
      setProgress(0);
    }
  }

  function updateButtonVisibility() {
    ensureUI();
    const activeVideo = currentVideo || findFallbackVideo();
    if (activeVideo) {
      wrap.style.display = "flex";
      wrap.style.opacity = "1";
      wrap.style.transform = "translateY(0)";
    } else {
      wrap.style.display = "none";
      closePopup();
    }
  }

  const io = new IntersectionObserver(
    (entries) => {
      let best = null, bestRatio = 0;
      for (const en of entries) {
        if (en.isIntersecting && en.intersectionRatio > bestRatio) {
          bestRatio = en.intersectionRatio;
          best = en.target;
        }
      }
      if (best !== currentVideo) {
        currentVideo = best;
        closePopup();
        updateButtonVisibility();
      }
    },
    { threshold: [0.6] }
  );

  function watchVideo(v) {
    if (v.dataset.fmsWatched) return;
    v.dataset.fmsWatched = "1";
    io.observe(v);
  }

  function scanVideos() {
    document.querySelectorAll("video").forEach(watchVideo);
  }

  const mo = new MutationObserver(scanVideos);
  mo.observe(document.documentElement, { childList: true, subtree: true });

  scanVideos();
  setInterval(updateButtonVisibility, 1200);
})();
