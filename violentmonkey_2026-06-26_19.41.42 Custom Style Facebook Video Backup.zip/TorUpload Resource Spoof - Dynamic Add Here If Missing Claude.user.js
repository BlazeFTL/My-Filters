// ==UserScript==
// @name         TorUpload Resource Spoof - Dynamic Add Here If Missing Claude
// @namespace    https://github.com/BlazeFTL
// @version      3.0
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    if (window.__spoofLoaded) return;
    window.__spoofLoaded = true;

    // Master set — add new URLs here as the site rotates them.
    // Only entries MISSING from real performance will be injected.
    const KNOWN = [
        {url: "https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516", type: "script", d: 160},
        {url: "https://dcbbwymp1bhlf.cloudfront.net/?wbbcd=1243778", type: "script", d: 172},
        {url: "https://s0-greate.net/p/2507871", type: "script", d: 901},
        {url: "https://accounts.google.com/ServiceLogin?passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Ffavicon.ico&uilel=3&hl=en&service=youtube", type: "img", d: 380},
        {url: "https://www.facebook.com/login.php?next=https%3A%2F%2Fwww.facebook.com%2Ffavicon.ico%3F_rdr%3Dp", type: "img", d: 398},
        {url: "https://www.cdn4ads.com/T/myaUVE/xhumane.min.js", type: "script", d: 108},
        {url: "https://accounts.google.com/ServiceLogin?passive=true&continue=https%3A%2F%2Fwww.google.com%2Ffavicon.ico&uilel=3&hl=en&service=mail", type: "img", d: 514},
        {url: "https://cdn.jsdelivr.net/npm/disable-devtool", type: "script", d: 102},
        {url: "https://c.adsco.re/", type: "script", d: 77},
        {url: "https://ryvxc6rsgejw.l4.adsco.re/", type: "other", d: 0},
        {url: "https://ryvxc6rsgejw.n4.adsco.re/", type: "other", d: 0},
        {url: "https://ryvxc6rsgejw.s4.adsco.re/", type: "other", d: 0},
        {url: "https://adsco.re/p?", type: "script", d: 257},
        {url: "https://dash.ezmob.com/ss/js/ads.js", type: "script", d: 200},
        {url: "https://securepubads.g.doubleclick.net/tag/js/gpt.js", type: "script", d: 150},
    ];

    const makeEntry = (item) => ({
        name: item.url,
        initiatorType: item.type,
        duration: item.d,
        startTime: Math.random() * 50 + 5,
        entryType: "resource",
        nextHopProtocol: "h2",
        renderBlockingStatus: "non-blocking",
        workerStart: 0,
        redirectStart: 0,
        redirectEnd: 0,
        fetchStart: 5,
        domainLookupStart: 5,
        domainLookupEnd: 5,
        connectStart: 5,
        connectEnd: 5,
        secureConnectionStart: 0,
        requestStart: 10,
        responseStart: 15,
        responseEnd: item.d + 15,
        transferSize: Math.floor(Math.random() * 2000) + 500,
        encodedBodySize: 1000,
        decodedBodySize: 2500,
        serverTiming: []
    });

    // Returns only KNOWN entries absent from the real list
    const getMissing = (realEntries) => {
        const realUrls = new Set(realEntries.map(e => e.name));
        return KNOWN
            .filter(item => !realUrls.has(item.url))
            .map(makeEntry);
    };

    const _p = Performance.prototype;
    const _getEntries        = _p.getEntries;
    const _getEntriesByType  = _p.getEntriesByType;
    const _getEntriesByName  = _p.getEntriesByName;

    _p.getEntries = function() {
        const real = _getEntries.apply(this, arguments);
        return [...real, ...getMissing(real)];
    };

    _p.getEntriesByType = function(type) {
        const real = _getEntriesByType.apply(this, arguments);
        if (type === 'resource') {
            return [...real, ...getMissing(real)];
        }
        return real;
    };

    _p.getEntriesByName = function(name) {
        const real = _getEntriesByName.apply(this, arguments);
        if (real.length > 0) return real; // Already present, don't double-inject
        const item = KNOWN.find(x => x.url === name);
        return item ? [makeEntry(item)] : real;
    };

})();