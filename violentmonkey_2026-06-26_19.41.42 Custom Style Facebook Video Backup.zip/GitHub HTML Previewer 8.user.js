// ==UserScript==
// @name         GitHub HTML Previewer 8
// @namespace    https://github.com/BlazeFTL
// @description  Targets the specific React directory row for .html previews.
// @version      2.0
// @author       BlazeFTL
// @match        https://github.com/BlazeFTL/My-Filters*
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const ROOT = document.querySelector('div.repository-content') || document.body;
    const OBS_OPTS = { childList: true, subtree: true };

    function injectLinks() {
        document.querySelectorAll('.gh-preview-link').forEach(el => el.remove());
        document.querySelectorAll('div.react-directory-filename-column a[href$=".html"]').forEach(link => {
            const btn = document.createElement('a');
            btn.href = `https://blazeftl.github.io/My-Filters/${link.textContent.trim()}`;
            btn.target = '_blank';
            btn.textContent = ' [Preview]';
            btn.className = 'gh-preview-link';
            btn.style.cssText = 'color:#0969da;font-size:12px;margin-left:8px;text-decoration:none;font-weight:bold';
            link.after(btn);
        });
    }

    const observer = new MutationObserver(() => {
        observer.disconnect();
        injectLinks();
        observer.observe(ROOT, OBS_OPTS);
    });

    injectLinks();
    observer.observe(ROOT, OBS_OPTS);
})();
