// ==UserScript==
// @name         Dead Domain Checker 2.8
// @namespace    https://github.com/BlazeFTL
// @version      2.8
// @description  HTTP-first liveness check via GM_xmlhttpRequest, DNS as fallback only.
// @match        *://example.com/*
// @author       BlazeFTL
// @license      MIT
// @grant        GM_addStyle
// @grant        GM_xmlhttpRequest
// @connect      *
// ==/UserScript==

(function () {
  'use strict';

  GM_addStyle(`
    #vmBox { position: fixed; top: 15px; right: 15px; width: 95%; max-width: 450px; background: #1a1a1a; color: #ffffff; border-radius: 12px; padding: 15px; z-index: 999999; font-family: 'Segoe UI', sans-serif; box-shadow: 0 8px 24px rgba(0,0,0,0.8); border: 1px solid #444; }
    #vmBox b { display: block; margin-bottom: 5px; font-size: 16px; color: #ddd; }
    #vmBox textarea { width: 100%; background: #000; color: #00ff00; border: 1px solid #555; resize: vertical; margin-top: 5px; margin-bottom: 10px; font-size: 15px; padding: 8px; box-sizing: border-box; border-radius: 4px; font-family: monospace; }
    #vmBox button { margin-top: 5px; margin-right: 6px; padding: 10px 16px; background: #333; color: #fff; border: 1px solid #666; cursor: pointer; border-radius: 6px; font-size: 14px; font-weight: bold; }
    #vmBox button:disabled { opacity: 0.3; cursor: not-allowed; }
    #vmBox .btn-paste { background: #663300; border-color: #884400; }
    #vmBox .btn-toggle { background: #222; border: 1px dashed #777; }
    #vmBox .btn-toggle.active { background: #004d40; border: 1px solid #00bfa5; color: #00ffcc; }
    #vmOut { margin: 10px 0; min-height: 80px; max-height: 250px; overflow: auto; white-space: pre-wrap; font-size: 14px; padding: 10px; background: #0a0a0a; border-radius: 4px; border-left: 4px solid #444; }
    #vmProgressWrap { margin: 8px 0; background: #000; border-radius: 4px; overflow: hidden; height: 22px; position: relative; border: 1px solid #555; }
    #vmProgressBar { height: 100%; width: 0%; background: #00ff00; transition: width 0.15s ease; }
    #vmProgressText { position: absolute; top: 0; left: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: bold; text-shadow: 0 1px 2px #000; }
    .dead { color: #ff5555; font-weight: bold; }
    .live { color: #55ff55; font-weight: bold; }
    .skip { color: #ffcc00; font-weight: bold; }
    .note { color: #bbb; }
    .output-section { margin-top: 15px; padding-top: 10px; border-top: 1px solid #333; }
  `);

  const box = document.createElement('div');
  box.id = 'vmBox';
  box.innerHTML = `
    <b>Domain Checker</b>
    <textarea id="vmInput" rows="4" placeholder="Paste Domains Here..."></textarea>
    <div>
      <button id="vmPaste" class="btn-paste">Paste Content</button>
      <button id="vmCheck">Check Domains</button>
      <button id="vmClear">Clear All</button>
    </div>
    <div id="vmProgressWrap" style="display:none;">
      <div id="vmProgressBar"></div>
      <div id="vmProgressText">0 / 0 (0%)</div>
    </div>
    <div id="vmOut" class="note">Idle.</div>
    <div><button id="vmSortToggle" class="btn-toggle">Sort A-Z: OFF</button></div>
    <div class="output-section">
        <b>Working Domains (Comma):</b>
        <textarea id="vmComma" rows="2" readonly></textarea>
        <button id="copyComma" disabled>Copy Comma</button>
    </div>
    <div class="output-section">
        <b>Working Domains (Pipe):</b>
        <textarea id="vmPipe" rows="2" readonly></textarea>
        <button id="copyPipe" disabled>Copy Pipe</button>
    </div>
  `;
  document.body.appendChild(box);

  const input = box.querySelector('#vmInput'), out = box.querySelector('#vmOut'), commaBox = box.querySelector('#vmComma'), pipeBox = box.querySelector('#vmPipe'), copyComma = box.querySelector('#copyComma'), copyPipe = box.querySelector('#copyPipe'), checkBtn = box.querySelector('#vmCheck'), clearBtn = box.querySelector('#vmClear'), pasteBtn = box.querySelector('#vmPaste'), sortToggle = box.querySelector('#vmSortToggle');
  const progressWrap = box.querySelector('#vmProgressWrap'), progressBar = box.querySelector('#vmProgressBar'), progressText = box.querySelector('#vmProgressText');

  let isSortEnabled = false, lastWorkingDomains = [];

  const updateOutputBoxes = () => {
    let list = [...lastWorkingDomains];
    if (isSortEnabled) list.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
    commaBox.value = list.join(',');
    pipeBox.value = list.join('|');
    copyComma.disabled = copyPipe.disabled = list.length === 0;
  };

  const setProgress = (done, total) => {
    const pct = total ? Math.round((done / total) * 100) : 0;
    progressBar.style.width = pct + '%';
    progressText.textContent = `${done} / ${total} (${pct}%)`;
  };

  // GM_xmlhttpRequest bypasses CORS and mixed-content restrictions and reports
  // real network-level outcomes (connection refused, NXDOMAIN, timeout) via onerror.
  // Any response (even 4xx/5xx/redirect) means the host is reachable -> live.
  const gmCheck = (url, timeout = 6000) => new Promise((resolve) => {
    GM_xmlhttpRequest({
      method: 'GET',
      url,
      timeout,
      onload: () => resolve(true),
      onerror: () => resolve(false),
      ontimeout: () => resolve(false),
    });
  });

  const httpAlive = async (domain) => {
    if (await gmCheck(`https://${domain}`)) return true;
    if (await gmCheck(`http://${domain}`)) return true;
    return false;
  };

  const dnsResolves = async (domain) => {
    try {
      const res = await fetch(`https://dns.google/resolve?name=${domain}&type=A`).then(r => r.json());
      return res.Status === 0 && !!res.Answer;
    } catch { return false; }
  };

  const validateDomain = async (domain) => {
    // 1. HTTP-level reachability is the source of truth.
    if (await httpAlive(domain)) return true;

    // 2. HTTP failed everywhere - confirm via DNS before calling it dead.
    //    (DoH outages/blocks shouldn't matter here since HTTP already failed,
    //    this is just a sanity check / informational fallback)
    return await dnsResolves(domain);
  };

  checkBtn.onclick = async () => {
    const original = input.value.split(/[,\|\s\n]+/).map(d => d.trim()).filter(Boolean);
    if (!original.length) return;
    out.innerHTML = '';
    checkBtn.disabled = true;

    const total = original.length;
    let done = 0;
    progressWrap.style.display = 'block';
    setProgress(0, total);
    lastWorkingDomains = [];

    // create placeholder lines in original order
    const lines = original.map((d) => {
      const span = document.createElement('div');
      span.className = 'note';
      span.textContent = `⏳ ${d}`;
      out.appendChild(span);
      return span;
    });

    await Promise.all(original.map(async (d, i) => {
      let status;
      if (d.includes('.*')) {
        status = 'skip';
      } else {
        status = (await validateDomain(d)) ? 'live' : 'dead';
      }

      const span = lines[i];
      if (status === 'skip') {
        span.className = 'skip';
        span.textContent = `⏭ ${d}`;
        lastWorkingDomains.push(d);
      } else if (status === 'live') {
        span.className = 'live';
        span.textContent = `✅ ${d}`;
        lastWorkingDomains.push(d);
      } else {
        span.className = 'dead';
        span.textContent = `❌ ${d}`;
      }

      done++;
      setProgress(done, total);
      updateOutputBoxes();
    }));

    checkBtn.disabled = false;
  };

  sortToggle.onclick = () => { isSortEnabled = !isSortEnabled; sortToggle.textContent = `Sort A-Z: ${isSortEnabled ? 'ON' : 'OFF'}`; sortToggle.classList.toggle('active', isSortEnabled); updateOutputBoxes(); };
  pasteBtn.onclick = async () => { input.value = await navigator.clipboard.readText(); };
  clearBtn.onclick = () => { input.value = ''; out.textContent = 'Idle.'; commaBox.value = pipeBox.value = ''; lastWorkingDomains = []; progressWrap.style.display = 'none'; setProgress(0,0); };
  copyComma.onclick = () => navigator.clipboard.writeText(commaBox.value);
  copyPipe.onclick = () => navigator.clipboard.writeText(pipeBox.value);
})();
