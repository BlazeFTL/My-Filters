// ==UserScript==
// @name         GitHub Discussion Thread Cleaner Delete All Slow And Stable 2.0
// @namespace    https://github.com/BlazeFTL
// @version      2.0
// @description  Deletes all replies AND the parent post without jumping or freezing.
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    async function waitForElement(selector, timeout = 4000) {
        const start = Date.now();
        while (Date.now() - start < timeout) {
            const el = document.querySelector(selector);
            // Ensure element is visible and not just in the DOM
            if (el && el.getBoundingClientRect().width > 0) return el;
            await new Promise(r => setTimeout(r, 200));
        }
        return null;
    }

    async function deleteFullThread(parentBlock) {
        const replyContainer = parentBlock.querySelector('[id^="child-comments-"]');
        let targets = [];

        if (replyContainer) {
            const replyBtns = replyContainer.querySelectorAll('.gh-standalone-delete-btn');
            targets = Array.from(replyBtns);
        }

        const parentDeleteBtn = parentBlock.querySelector(':scope > div .gh-standalone-delete-btn');
        if (parentDeleteBtn) {
            targets.push(parentDeleteBtn);
        }

        if (targets.length === 0) return;
        if (!confirm(`Delete this thread (${targets.length} total comments)?`)) return;

        for (const btn of targets) {
            // Check if the button still exists in the document
            if (!document.body.contains(btn)) continue;

            // Trigger click without scrolling to prevent the "jump to bottom"
            btn.click();

            const confirmBtn = await waitForElement('button[type="submit"].Button--danger');

            if (confirmBtn) {
                confirmBtn.click();

                // Wait for the modal to fully disappear before moving to the next
                let attempts = 0;
                while (document.querySelector('button[type="submit"].Button--danger') && attempts < 20) {
                    await new Promise(r => setTimeout(r, 200));
                    attempts++;
                }
                // Short cooldown to let GitHub's UI refresh
                await new Promise(r => setTimeout(r, 500));
            }
        }
    }

    function addThreadDeleteButton() {
        const blocks = document.querySelectorAll('.js-timeline-discussion-comment:not([data-thread-init])');

        blocks.forEach(block => {
            if (block.closest('[id^="child-comments-"]')) return;
            block.setAttribute('data-thread-init', 'true');

            const menu = block.querySelector('button[id^="Comment-actions"]');
            if (!menu) return;

            const bulkBtn = document.createElement('button');
            bulkBtn.innerHTML = '🗑️ Delete Full Thread';
            bulkBtn.style.cssText = 'margin-left: 8px; cursor: pointer; color: white; background: #cf222e; border: none; border-radius: 6px; padding: 4px 8px; font-size: 11px; vertical-align: middle; font-weight: bold;';

            bulkBtn.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                deleteFullThread(block);
            };

            menu.parentNode.insertBefore(bulkBtn, menu.nextSibling);
        });
    }

    let debounce;
    const observer = new MutationObserver(() => {
        clearTimeout(debounce);
        debounce = setTimeout(addThreadDeleteButton, 300);
    });

    observer.observe(document.body, { childList: true, subtree: true });
    addThreadDeleteButton();
})();
