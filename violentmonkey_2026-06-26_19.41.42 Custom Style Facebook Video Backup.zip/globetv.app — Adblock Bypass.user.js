// ==UserScript==
// @name         globetv.app — Adblock Bypass
// @namespace    BlazeFTL
// @version      1.1.0
// @match        https://globetv.app/*
// @match        https://*.globetv.app/*
// @run-at       document-start
// @grant        none
// ==/UserScript==
(function () {
    'use strict';

    const CACHE_KEY = 'gtv_adfree_status_v1';
    const fakeStatus = () => ({
        active: true,
        checkedAt: Date.now(),
        expiresAt: Date.now() + (365 * 24 * 60 * 60 * 1000)
    });

    // ── 1. localStorage — write cache before site reads it ───────────────────
    try {
        localStorage.setItem(CACHE_KEY, JSON.stringify(fakeStatus()));
        localStorage.removeItem('gtv_ads_block_notice_last_v1');
    } catch (_) {}

    // ── 2. Intercept fetch to paypal-status.php ───────────────────────────────
    // refreshAdFreeStatus() fetches server-side and would override our cache.
    const _fetch = window.fetch;
    window.fetch = function (input, init) {
        const url = String(typeof input === 'string' ? input : (input && input.url) || '');
        if (url.includes('paypal-status.php')) {
            return Promise.resolve(new Response(JSON.stringify({
                active: true,
                expires_at: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
                email_masked: null
            }), { status: 200, headers: { 'Content-Type': 'application/json' } }));
        }
        return _fetch.apply(this, arguments);
    };

    // ── 3. JSON.parse — narrowed to only the cache key object ────────────────
    // Gemini's version mutates ANY object with 'active' — too broad.
    const _parse = JSON.parse;
    JSON.parse = function (text) {
        const result = _parse.apply(this, arguments);
        if (result && typeof result === 'object' && 'active' in result && 'checkedAt' in result) {
            result.active = true;
            result.expiresAt = Date.now() + (365 * 24 * 60 * 60 * 1000);
        }
        return result;
    };

    // ── 4. Block classList.toggle for adblock state classes ──────────────────
    const _toggle = DOMTokenList.prototype.toggle;
    DOMTokenList.prototype.toggle = function (cls, force) {
        if (cls === 'adblock-active' || cls === 'ads-suppressed') return false;
        return _toggle.apply(this, arguments);
    };

    // ── 5. Kill the capturing error listener (installAdResourceBlockWatcher) ──
    const _addEL = EventTarget.prototype.addEventListener;
    EventTarget.prototype.addEventListener = function (type, listener, options) {
        if (type === 'error' && listener && listener.toString().includes('isKnownAdScriptUrl')) return;
        return _addEL.apply(this, arguments);
    };

})();