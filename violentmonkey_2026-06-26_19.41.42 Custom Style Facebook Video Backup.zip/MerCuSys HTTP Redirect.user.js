// ==UserScript==
// @name         MerCuSys HTTP Redirect
// @namespace    https://github.com/BlazeFTL
// @description  Wait for text and redirect to HTTP if HTTPS management is disabled
// @version      1.0
// @author       BlazeFTL
// @match        *://192.168.1.1/webpages/index.html
// @match        *://mwlogin.net/webpages/index.html
// @icon         https://www.google.com/s2/favicons?sz=64&domain=mercusys.com
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const checkText = "Local Management via HTTPS is disabled. Please access the device via HTTP";

    const redirectIfMatch = () => {
        if (document.body && document.body.innerText.includes(checkText)) {
            console.log("Found error message, redirecting to HTTP...");
            window.location.protocol = 'http:';
        }
    };

    // Run immediately
    redirectIfMatch();

    // Observe changes in case the text is loaded dynamically
    const observer = new MutationObserver(() => {
        redirectIfMatch();
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });
})();
