// ==UserScript==
// @name         YouTube Volume Booster Clean UI
// @namespace    https://github.com/BlazeFTL
// @description  Custom volume slider for YouTube videos with options to toggle visibility and remember volume settings across videos
// @version      1.5
// @author       BlazeFTL
// @match        *://*.youtube.com/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_registerMenuCommand
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    let audioContext = null;
    let gainNode = null;
    let videoSource = null;

    // Load configurations (Defaults: Button is Visible, Remember Volume is Disabled)
    let showButtonSetting = GM_getValue("showBoostButton", true);
    let rememberVolumeSetting = GM_getValue("rememberVolume", false);

    // Extension drop-down menu controls
    GM_registerMenuCommand(`Toggle Boost Button (Currently: ${showButtonSetting ? 'Visible' : 'Hidden'})`, () => {
        GM_setValue("showBoostButton", !showButtonSetting);
        location.reload();
    });

    GM_registerMenuCommand(`Remember Volume Across Videos (Currently: ${rememberVolumeSetting ? 'Enabled' : 'Disabled'})`, () => {
        GM_setValue("rememberVolume", !rememberVolumeSetting);
        location.reload();
    });

    function calculateVolume(position, sliderWidth) {
        return ((position / sliderWidth) * 1400).toFixed(1);
    }

    function initAudio(videoPlayer) {
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            gainNode = audioContext.createGain();
            gainNode.connect(audioContext.destination);
        }

        if (!videoPlayer.dataset.audioHooked) {
            try {
                videoSource = audioContext.createMediaElementSource(videoPlayer);
                videoSource.connect(gainNode);
                videoPlayer.dataset.audioHooked = 'true';
            } catch (e) {
                console.error("Audio initialization error:", e);
            }
        }
    }

    function injectControls() {
        const controls = document.querySelector('.ytp-left-controls');
        const videoPlayer = document.querySelector('.video-stream');

        if (!controls || !videoPlayer || document.getElementById('customVolumeSlider')) return;

        // Create custom volume slider (180px width)
        const customVolumeSlider = document.createElement('input');
        customVolumeSlider.type = 'range';
        customVolumeSlider.id = 'customVolumeSlider';
        customVolumeSlider.min = '0';
        customVolumeSlider.max = '1400';
        customVolumeSlider.step = '1';
        customVolumeSlider.style.width = '180px';
        customVolumeSlider.style.verticalAlign = 'middle';
        customVolumeSlider.style.marginRight = '8px';

        // Create live volume percentage text counter
        const volumeCounter = document.createElement('span');
        volumeCounter.id = 'volumeBoostCounter';
        volumeCounter.style.color = '#fff';
        volumeCounter.style.fontSize = '12px';
        volumeCounter.style.fontWeight = 'bold';
        volumeCounter.style.verticalAlign = 'middle';
        volumeCounter.style.marginRight = '10px';

        // Create custom button for volume boost
        const volumeBoostButton = document.createElement('button');
        volumeBoostButton.id = 'volumeBoostButton';
        volumeBoostButton.className = 'ytp-button';
        volumeBoostButton.style.background = 'none';
        volumeBoostButton.style.border = 'none';
        volumeBoostButton.style.cursor = 'pointer';
        volumeBoostButton.style.padding = '0 8px';
        volumeBoostButton.innerText = 'Boost';
        volumeBoostButton.style.color = '#fff';
        volumeBoostButton.style.fontWeight = 'bold';
        volumeBoostButton.style.verticalAlign = 'middle';

        // Fix: Cleanly hide all UI elements if the user disables the button layout
        if (showButtonSetting) {
            volumeBoostButton.style.display = 'inline-block';
            customVolumeSlider.style.display = 'none';
            volumeCounter.style.display = 'none';
        } else {
            volumeBoostButton.style.display = 'none';
            customVolumeSlider.style.display = 'none';
            volumeCounter.style.display = 'none';
        }

        function applyVolumeState() {
            let targetValue = '100';
            if (rememberVolumeSetting) {
                targetValue = GM_getValue("savedVolume", "100");
            }
            customVolumeSlider.value = targetValue;
            const volume = calculateVolume(targetValue, customVolumeSlider.max);

            if (gainNode) {
                gainNode.gain.value = volume / 100;
            }
            volumeCounter.innerText = `${Math.round(volume)}%`;
        }

        customVolumeSlider.addEventListener('input', function() {
            initAudio(videoPlayer);
            if (audioContext && audioContext.state === 'suspended') {
                audioContext.resume();
            }
            const volume = calculateVolume(this.value, this.max);
            if (gainNode) gainNode.gain.value = volume / 100;
            volumeCounter.innerText = `${Math.round(volume)}%`;

            if (rememberVolumeSetting) {
                GM_setValue("savedVolume", this.value);
            }
        });

        videoPlayer.addEventListener('timeupdate', function() {
            if (videoPlayer.currentTime === 0) {
                if (rememberVolumeSetting) {
                    initAudio(videoPlayer);
                }
                applyVolumeState();
            }
        });

        volumeBoostButton.addEventListener('click', function() {
            initAudio(videoPlayer);
            if (audioContext && audioContext.state === 'suspended') {
                audioContext.resume();
            }
            const isHidden = customVolumeSlider.style.display === 'none';
            customVolumeSlider.style.display = isHidden ? 'inline-block' : 'none';
            volumeCounter.style.display = isHidden ? 'inline-block' : 'none';
            applyVolumeState();
        });

        // Mount elements into control bar layout
        controls.appendChild(volumeBoostButton);
        controls.appendChild(customVolumeSlider);
        controls.appendChild(volumeCounter);

        if (rememberVolumeSetting && audioContext) {
            initAudio(videoPlayer);
        }
        applyVolumeState();
    }

    setInterval(injectControls, 1000);
})();