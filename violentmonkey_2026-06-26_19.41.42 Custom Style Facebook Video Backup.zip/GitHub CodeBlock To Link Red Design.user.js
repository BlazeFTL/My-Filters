// ==UserScript==
// @name         GitHub CodeBlock To Link Red Design
// @namespace    https://github.com/BlazeFTL
// @version      1.0
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const targetPath = "/uBlockOrigin/uAssets/";

    const style = document.createElement('style');
    style.textContent = `
        .custom-github-link {
            background-color: rgba(207, 34, 46, 0.1);
            color: #cf222e !important;
            padding: 1px 4px;
            margin: 0 1px;
            border-radius: 3px;
            font-weight: 560;
            text-decoration: none !important;
            transition: all 0.1s ease-in-out;
        }
        .custom-github-link:hover {
            background-color: #cf222e;
            color: #ffffff !important;
            box-shadow: 0 2px 4px rgba(207, 34, 46, 0.2);
        }
    `;
    document.head.appendChild(style);

    const urlRegex = /((https?:\/\/[^\s<]+)|([a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/[^\s<]*)?))/gi;

    function processElement(el) {
        if (el.hasAttribute('data-linked') || el.closest('pre') || el.closest('a')) return;

        const content = el.textContent.trim();

        if (el.tagName === 'CODE') {
            if (urlRegex.test(content) && (content.includes('.') || content.startsWith('http'))) {
                el.setAttribute('data-linked', 'true');
                const url = content.startsWith('http') ? content : `https://${content}`;
                el.innerHTML = `<a href="${url}" target="_blank" class="custom-github-link">${content}</a>`;
            }
        } else {
            // Process text nodes inside P or other containers to avoid overwriting existing HTML structures
            const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null, false);
            let node;
            const nodesToReplace = [];

            while (node = walker.nextNode()) {
                if (urlRegex.test(node.nodeValue)) {
                    nodesToReplace.push(node);
                }
            }

            nodesToReplace.forEach(textNode => {
                const parent = textNode.parentNode;
                if (parent.closest('a') || parent.closest('pre')) return;

                const fragment = document.createDocumentFragment();
                const parts = textNode.nodeValue.split(urlRegex);

                // Note: regex with groups in split() includes matches in the array
                // We'll use a simpler replacement for the fragment to ensure stability
                const newHTML = textNode.nodeValue.replace(urlRegex, (match) => {
                    if (!match.includes('.') && !match.startsWith('http')) return match;
                    const prefix = match.startsWith('http') ? '' : 'https://';
                    return `<a href="${prefix}${match}" target="_blank" class="custom-github-link">${match}</a>`;
                });

                const temp = document.createElement('span');
                temp.innerHTML = newHTML;
                while (temp.firstChild) {
                    fragment.appendChild(temp.firstChild);
                }
                parent.replaceChild(fragment, textNode);
            });
            el.setAttribute('data-linked', 'true');
        }
    }

    function linkify() {
        if (!window.location.pathname.includes(targetPath)) return;

        // Target only markdown bodies to save resources
        const containers = document.querySelectorAll('.markdown-body:not([data-processed])');
        containers.forEach(container => {
            const elements = container.querySelectorAll('p, :not(pre) > code.notranslate');
            elements.forEach(processElement);
            // Mark container as checked if it's a small one, or handle incrementally
        });
    }

    // Efficient observer: only triggers when new nodes are added
    const observer = new MutationObserver((mutations) => {
        let shouldRun = false;
        for (const mutation of mutations) {
            if (mutation.addedNodes.length > 0) {
                shouldRun = true;
                break;
            }
        }
        if (shouldRun) {
            requestAnimationFrame(linkify);
        }
    });

    // Run on start
    linkify();

    // Listen for SPA Navigation
    window.addEventListener('turbo:render', linkify);

    observer.observe(document.body, { childList: true, subtree: true });
})();