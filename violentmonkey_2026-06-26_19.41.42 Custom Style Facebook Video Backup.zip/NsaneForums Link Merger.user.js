 // ==UserScript==
// @name         NsaneForums Link Merger
// @namespace    https://github.com/BlazeFTL
// @description  Merges Site + Sharecode and removes slash separators
// @version      1.2
// @author       BlazeFTL
// @match        https://nsaneforums.com/topic/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=nsaneforums.com
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let timeout = null;

    function removeSlashLines(container) {
        const slashElements = container.querySelectorAll('p, span, strong');
        slashElements.forEach(el => {
            const text = el.textContent.trim();
            // Stricter check: only remove if it's purely slashes and not in a code/editor context
            if (/^\/+\/*$/.test(text) && !el.closest('pre, code, .ipsComposeArea, [role="textbox"]')) {
                el.remove();
            }
        });
    }

    function combineLinks() {
        // Target post content areas
        const containers = document.querySelectorAll('.ipsType_richText, .ipsSpoiler_contents');

        containers.forEach(container => {
            // GLOBAL EDITOR SHIELD: Skip if this container is inside the forum's reply/edit box
            if (container.closest('.ipsComposeArea, .cke, [role="textbox"], .ipsComposer')) return;

            removeSlashLines(container);

            const blocks = container.querySelectorAll('p, div');

            blocks.forEach(block => {
                // Skip already merged or code-related blocks
                if (block.dataset.linkMerged === 'true' ||
                    block.closest('pre, code, .ipsCode') ||
                    block.textContent.includes('==UserScript==')) return;

                const text = block.textContent;
                if (!text.includes('Site:') || !text.includes('Sharecode')) return;

                const siteAnchor = block.querySelector('a[href*="http"]:not([href*="how-to-work-with-sharecodes"])');
                const regex = /Sharecode.*?(?:[:\s])+\s*(\/[a-zA-Z0-9][^\s<]+)/i;
                const match = block.innerHTML.match(regex);

                if (siteAnchor && match && match[1]) {
                    const sharecode = match[1].trim();
                    const baseUrl = siteAnchor.href.replace(/\/$/, '');
                    const fullUrl = baseUrl + sharecode;

                    block.dataset.linkMerged = 'true';

                    const wrapper = document.createElement('div');
                    wrapper.style.marginTop = '10px';

                    const label = document.createElement('strong');
                    label.style.color = 'red';
                    label.textContent = 'Download Link (Merged) : ';

                    const link = document.createElement('a');
                    link.href = fullUrl;
                    link.target = '_blank';
                    link.rel = 'noopener noreferrer';
                    link.style.color = 'green';
                    link.style.textDecoration = 'underline';
                    link.style.fontWeight = 'bold';
                    link.textContent = fullUrl;

                    wrapper.appendChild(label);
                    wrapper.appendChild(link);

                    block.innerHTML = '';
                    block.appendChild(wrapper);
                }
            });
        });
    }

    const observer = new MutationObserver((mutations) => {
        if (timeout) clearTimeout(timeout);
        timeout = setTimeout(() => {
            observer.disconnect();
            combineLinks();
            startObserver();
        }, 500);
    });

    function startObserver() {
        const mainContent = document.querySelector('#ipsLayout_mainArea');
        if (mainContent) {
            observer.observe(mainContent, {
                childList: true,
                subtree: true,
                characterData: true
            });
        }
    }

    // Initial Run
    if (document.readyState === 'loading') {
        window.addEventListener('DOMContentLoaded', () => {
            setTimeout(combineLinks, 1000);
            startObserver();
        });
    } else {
        setTimeout(combineLinks, 1000);
        startObserver();
    }
})();
