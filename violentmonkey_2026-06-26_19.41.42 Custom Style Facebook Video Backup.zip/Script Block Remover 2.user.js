// ==UserScript==
// @name         Script Block Remover 2
// @namespace    https://github.com/BlazeFTL
// @description  Removes the entire v4 detection block using the keyword adsUrl
// @version      1.1
// @author       BlazeFTL
// @match        *://*/*
// @license      MIT
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The keyword found inside the target block
    const poisonWord = "adsUrl";

    /**
     * REGEX EXPLANATION:
     * [^}]*?           -> Look for content before the word
     * \\b${poisonWord}\\b -> Match the exact word "adsUrl"
     * [^]*?            -> Match everything (including newlines)
     * }                -> Until the closing brace of that block
     */
    const blockRegex = new RegExp(`function[^({]*?\\([^)]*?\\)\\s*{[^]*?\\b${poisonWord}\\b[^]*?}(?=\\s*\\)|\\s*$)`, 'g');

    const cleanScript = (scriptSource) => {
        if (scriptSource.includes(poisonWord)) {
            console.log(`[BlazeFTL] Targeted block containing "${poisonWord}" has been neutralized.`);
            // This replaces the function body with a harmless empty function
            return scriptSource.replace(blockRegex, `function() { console.log('Detector Defused'); }`);
        }
        return scriptSource;
    };

    // 1. Intercept scripts as they are added to the DOM
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.tagName === 'SCRIPT' && node.textContent.includes(poisonWord)) {
                    node.textContent = cleanScript(node.textContent);
                }
            });
        });
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });

    // 2. Immediate check for scripts already present
    document.querySelectorAll('script').forEach(script => {
        if (script.textContent.includes(poisonWord)) {
            script.textContent = cleanScript(script.textContent);
        }
    });

})();
