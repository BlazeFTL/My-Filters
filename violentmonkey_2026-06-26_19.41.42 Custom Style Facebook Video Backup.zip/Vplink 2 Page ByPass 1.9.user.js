// ==UserScript==
// @name         Vplink 2 Page ByPass 1.9
// @namespace    http://tampermonkey.net/
// @version      1.9
// @description  Zero-Config: Supports multiple Stage 1 domains via @match lines
// @author       BlazeFTL
// @match        https://dharona.in/educatedegree/studyuniversty/?studyuniversty=*
// @match        https://newsfront.xyz/studyhotels/?smartcation=*
// @match        https://sarkarijobcorner.com/educatestudy/estudypost/?eduonline=*
// @match        https://sarkarijobcorner.com/*
// @run-at       document-start
// @grant        none
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    const CONFIG = {
        finalDomain: 'vplink.in',
        timer: 20
    };

    const url = window.location.href;
    const params = new URLSearchParams(window.location.search);
    const matches = Array.isArray(typeof GM_info !== 'undefined' ? GM_info.script.matches : []) ? GM_info.script.matches : [];

    // Helper to parse patterns
    const parsePattern = (pattern) => {
        try {
            const clean = pattern.replace(/\*/g, '').replace('https://', '').replace('http://', '');
            const domain = clean.split('/')[0];
            const param = clean.split('?')[1]?.split('=')[0] || '';
            return { domain, param, fullPath: clean };
        } catch (e) { return null; }
    };

    // Separate matches: Stage 2 is always sarkarijobcorner, others are Stage 1
    const allConfigs = matches.map(parsePattern).filter(c => c !== null);
    const interConfig = allConfigs.find(c => c.domain.includes('sarkarijobcorner.com') && c.param !== '');
    const sourceConfigs = allConfigs.filter(c => c !== interConfig && c.param !== '');

    // --- STAGE 1: MULTIPLE SOURCE REDIRECTS ---
    const activeSource = sourceConfigs.find(conf => url.includes(conf.domain) && params.has(conf.param));

    if (activeSource && interConfig) {
        const id = params.get(activeSource.param);
        window.stop();
        window.location.replace(`https://${interConfig.fullPath}${id}`);
        return;
    }

    // --- STAGE 2: INTERMEDIATE CAPTURE & UI (Sarkarijobcorner) ---
    if (interConfig && url.includes(interConfig.domain)) {

        if (params.has(interConfig.param)) {
            localStorage.setItem("blaze_final_id", params.get(interConfig.param));
            return;
        }

        const savedId = localStorage.getItem("blaze_final_id");

        if (savedId && !params.has(interConfig.param)) {
            const startUI = () => {
                if (document.getElementById('blaze-guard')) return;
                const shield = document.createElement('div');
                shield.id = 'blaze-guard';
                shield.style.cssText = `position:fixed!important;top:0;left:0;width:100%;height:100%;background:#000!important;z-index:2147483647!important;display:flex;align-items:center;justify-content:center;font-family:sans-serif;color:white;text-align:center;`;
                shield.innerHTML = `
                    <div style="border:2px solid #e74c3c;padding:40px;border-radius:20px;background:#111;">
                        <h2 style="color:#e74c3c;margin:0;">LINK VERIFICATION</h2>
                        <div id="big-timer" style="font-size:100px;font-weight:bold;margin:10px 0;">${CONFIG.timer}</div>
                        <p style="color:#666;">Redirecting to ${CONFIG.finalDomain} in ${CONFIG.timer}s</p>
                    </div>`;
                (document.body || document.documentElement).appendChild(shield);

                let timeLeft = CONFIG.timer;
                const ticker = setInterval(() => {
                    timeLeft--;
                    const display = document.getElementById('big-timer');
                    if (display) display.innerText = timeLeft;
                    if (timeLeft <= 0) {
                        clearInterval(ticker);
                        localStorage.removeItem("blaze_final_id");
                        window.location.href = `https://${CONFIG.finalDomain}/` + savedId;
                    }
                }, 1000);
            };

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', startUI);
            } else {
                startUI();
            }
            new MutationObserver(() => {
                if (!document.getElementById('blaze-guard')) startUI();
            }).observe(document.documentElement, { childList: true, subtree: true });
        }
    }
})();

