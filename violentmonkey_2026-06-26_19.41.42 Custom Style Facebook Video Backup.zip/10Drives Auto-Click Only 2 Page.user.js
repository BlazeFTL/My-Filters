// ==UserScript==
// @name         10Drives Auto-Click Only 2 Page
// @namespace    https://github.com/BlazeFTL
// @description  Bypasses Secure Click and nested srcdoc iframes
// @version      3.0
// @author       BlazeFTL
// @match        *://gamesmain.xyz/*
// @license      MIT
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const state = {
        secureSent: false,
        clicked: new Set()
    };

    const forceClick = (el) => {
        if (!el) return;
        const opts = { bubbles: true, cancelable: true, view: window };
        el.dispatchEvent(new MouseEvent('mousedown', opts));
        el.dispatchEvent(new MouseEvent('mouseup', opts));
        el.click();
    };

    const handleLogic = () => {
        // 1. Handle the "Secure Click" PostMessage requirement
        // Your screenshot shows: parent.postMessage("secure-click", "*")
        if (!state.secureSent) {
            const secureFrame = document.querySelector('iframe[srcdoc*="secure-click"]');
            if (secureFrame) {
                window.postMessage("secure-click", "*");
                state.secureSent = true;
                console.log("Sent secure-click message");
            }
        }

        // 2. Scan all documents (Main + Iframes)
        const allDocs = [document];
        document.querySelectorAll('iframe').forEach(frame => {
            try {
                const d = frame.contentDocument || frame.contentWindow.document;
                if (d) allDocs.push(d);
            } catch (e) {}
        });

        const targetSelectors = [
            '#hss',
            '#create-link',
            '#link-ready',
            '#safe-download-now',
            '#safe-get-now',
            '#dwform > .btn-primary.btn'
        ];

        allDocs.forEach(doc => {
            targetSelectors.forEach(selector => {
                const btn = doc.querySelector(selector);

                if (btn && !btn.classList.contains('d-none') && !btn.hasAttribute('disabled')) {
                    // Check visibility
                    if (btn.offsetWidth > 0 || btn.offsetHeight > 0) {
                        if (!state.clicked.has(btn)) {
                            state.clicked.add(btn);
                            console.log(`Clicking: ${selector}`);
                            forceClick(btn);

                            // If it has a real download link, follow it immediately
                            if (btn.href && btn.href.includes('http') && !btn.href.includes('#')) {
                                window.location.href = btn.href;
                            }
                        }
                    }
                }
            });
        });
    };

    // Fast monitoring
    const observer = new MutationObserver(handleLogic);
    observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true
    });

    // Backup loops
    setInterval(handleLogic, 500);
})();
