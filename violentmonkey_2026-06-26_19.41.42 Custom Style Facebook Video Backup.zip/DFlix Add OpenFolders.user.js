// ==UserScript==
// @name         DFlix Add OpenFolders
// @namespace    https://github.com/BlazeFTL
// @description  Aggressive dynamic link scraper for dflix.live handles multiple button types
// @version      1.0
// @author       BlazeFTL
// @match        *://*.dflix.live/*
// @icon         data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAMAAABF0y+mAAAAS1BMVEVHcEwAHiQAHiQAHiQAHiQAHiQAHiQAHiQAFhoADREAT14AaHoAeI4AAgRyKB69MxeZLRkAQEwAnbkAiaLuOQgAzvMArs0ALzgAvuHoJbxIAAAACHRSTlMADo3b/P9m/TlQv8AAAADQSURBVHgBhZOFAYMwEAAh6ZdXnMD+i9ZwSw+JXFySD6nzD9jx8C5Nfjzhkue9G20Kt6SJu5cu8ffSJ9m9zJIxxAPwY5TEsoNplahMuIFYcZak9I2jmSHhN46kNEoUgLwoyqqua6mlUQMgEJwklm1ettyxVEG5kr5XW2WbQ/6RfQVB6kaGcCFDkK+0MBiemjWzoHXDQxAT3A+oISBllabq67kmjOMG/P7xNxm0eSoftNovQqX/ly+68NEti2529JhED1j0aMYP9Xgdsr3IxuvwBrboFerT2sQ5AAAAAElFTkSuQmCC
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function process() {
        // Selector 1: The red Netflix-style button container
        const redBtn = document.querySelector('.transition-all.font-semibold.bg-netflix-red.items-center.inline-flex');
        if (redBtn) {
            const container = redBtn.closest('.gap-2.flex-wrap.flex');
            injectFolderButton(container, redBtn, 'blaze-folder-red-v1-8');
        }

        // Selector 2: The primary button inside .gap-4.flex
        const primaryBtn = document.querySelector('div.gap-4.flex .gap-2.items-center.flex.btn-primary');
        if (primaryBtn) {
            const container = primaryBtn.closest('.gap-2.items-center.flex.btn-primary').parentElement;
            // If the parent isn't the flex container you mentioned, we target it specifically
            const flexContainer = primaryBtn.closest('.gap-4.flex');
            injectFolderButton(flexContainer, primaryBtn, 'blaze-folder-primary-v1-8');
        }
    }

    function injectFolderButton(container, sourceBtn, id) {
        if (container && !document.getElementById(id)) {
            const rawUrl = sourceBtn.href;
            if (!rawUrl) return;

            const folderUrl = rawUrl.substring(0, rawUrl.lastIndexOf('/') + 1);

            const folderBtn = document.createElement('a');
            folderBtn.id = id;
            folderBtn.href = folderUrl;
            folderBtn.target = "_blank";
            folderBtn.innerText = "Open Folder";

            style(folderBtn, '#2563eb');

            // Insert inside the flex container
            container.appendChild(folderBtn);
        }
    }

    function style(el, bg) {
        el.style.cssText = `
            padding: 6px 12px;
            background: ${bg};
            color: #fff;
            border-radius: 4px;
            font-weight: 600;
            text-decoration: none;
            font-size: 13px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-left: 4px;
            transition: opacity 0.2s;
        `;
    }

    // High-frequency check for SPA transitions
    const observer = new MutationObserver(process);
    observer.observe(document.body, { childList: true, subtree: true });

    // Fallback interval
    setInterval(process, 300);
})();
