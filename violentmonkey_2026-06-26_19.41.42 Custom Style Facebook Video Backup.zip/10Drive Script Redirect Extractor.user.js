// ==UserScript==
// @name         10Drive Script Redirect Extractor
// @namespace    blazeftl
// @version      1.0
// @match        *://gamesmain.xyz/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
"use strict";

const patterns = [
/window\.open\s*\(\s*["']([^"']+)["']/,
/wd\s*=\s*window\.open\s*\(\s*["']([^"']+)["']/,
/safeDownloadLink\s*=\s*["']([^"']+)["']/,
/location\.href\s*=\s*["']([^"']+)["']/,
/location\.assign\s*\(\s*["']([^"']+)["']/
];

function findURL(text){
    if(!text) return null;

    for(const p of patterns){
        const m = text.match(p);
        if(m) return m[1];
    }

    return null;
}

function scan(){

    // scan inline scripts
    for(const s of document.scripts){
        const url = findURL(s.textContent);
        if(url) return url;
    }

    // scan iframe srcdoc
    for(const iframe of document.querySelectorAll("iframe[srcdoc]")){
        const html = iframe.getAttribute("srcdoc");
        const url = findURL(html);
        if(url) return url;
    }

    return null;
}

function run(){
    const url = scan();
    if(url){
        console.log("Redirect found:", url);
        location.href = url;
    }
}

new MutationObserver(run).observe(document,{
    childList:true,
    subtree:true
});

run();

})();
