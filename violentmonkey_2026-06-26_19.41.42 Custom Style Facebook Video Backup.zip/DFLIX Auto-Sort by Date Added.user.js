// ==UserScript==
// @name         DFLIX Auto-Sort by Date Added
// @namespace    https://github.com/BlazeFTL
// @description  Fast auto-sort for DFLIX with manual override support.
// @version      1.0
// @author       BlazeFTL
// @match        http://*.dflix.live/*
// @match        https://*.dflix.live/*
// @icon         data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAMAAABF0y+mAAAAS1BMVEVHcEwAHiQAHiQAHiQAHiQAHiQAHiQAHiQAFhoADREAT14AaHoAeI4AAgRyKB69MxeZLRkAQEwAnbkAiaLuOQgAzvMArs0ALzgAvuHoJbxIAAAACHRSTlMADo3b/P9m/TlQv8AAAADQSURBVHgBhZOFAYMwEAAh6ZdXnMD+i9ZwSw+JXFySD6nzD9jx8C5Nfjzhkue9G20Kt6SJu5cu8ffSJ9m9zJIxxAPwY5TEsoNplahMuIFYcZak9I2jmSHhN46kNEoUgLwoyqqua6mlUQMgEJwklm1ettyxVEG5kr5XW2WbQ/6RfQVB6kaGcCFDkK+0MBiemjWzoHXDQxAT3A+oISBllabq67kmjOMG/P7xNxm0eSoftNovQqX/ly+68NEti2529JhED1j0aMYP9Xgdsr3IxuvwBrboFerT2sQ5AAAAAElFTkSuQmCC
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const TARGET_LABEL = 'Date Added (Recent)';
    let userHasIntervened = false;

    const fastSort = () => {
        // If the user already clicked sort, stop fighting them
        if (userHasIntervened) return;

        const sortButton = Array.from(document.querySelectorAll('button')).find(btn =>
            btn.textContent.includes('Sort:')
        );

        if (!sortButton) return;

        // If the button is already set to our target, we don't need to do anything
        if (sortButton.textContent.includes(TARGET_LABEL)) return;

        // Add a click listener to the button so we know if YOU clicked it
        if (!sortButton.dataset.listenerAttached) {
            sortButton.addEventListener('click', () => {
                userHasIntervened = true;
            }, { once: true });
            sortButton.dataset.listenerAttached = "true";
        }

        // Immediate click to open dropdown
        sortButton.click();

        const dropdownObserver = new MutationObserver((_, observer) => {
            const options = document.querySelectorAll('button');
            const targetOption = Array.from(options).find(opt => opt.textContent.trim() === TARGET_LABEL);

            if (targetOption) {
                targetOption.click();
                observer.disconnect();
            }
        });

        dropdownObserver.observe(document.body, { childList: true, subtree: true });

        // Safety timeout
        setTimeout(() => dropdownObserver.disconnect(), 2000);
    };

    // Watch for page transitions
    const mainObserver = new MutationObserver(() => {
        // Reset intervention flag if we navigate to a new "page" (common in SPAs)
        // or just keep it active for the session.
        fastSort();
    });

    mainObserver.observe(document.body, { childList: true, subtree: true });

    // Initial check
    fastSort();
})();
