// ==UserScript==
// @name         D.TorUpload Auto-Click
// @namespace    https://github.com/BlazeFTL
// @description  Automates the download process by monitoring elements. Clicks hidden #method_free and ensures timer <= 1s.
// @version      1.0
// @author       BlazeFTL
// @match        https://nathanmichaelphoto.com/*
// @match        https://torupload.com/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const checkInterval = setInterval(() => {
        // --- 1. Immediate click for hidden method button ---
        const freeMethodBtn = document.querySelector('#method_free');
        if (freeMethodBtn) {
            freeMethodBtn.click();
        }

        // --- 2. Logic for download button with timer check ---
        const xdInput = document.getElementById('xd');
        const downloadBtn = document.getElementById('downloadbtn');
        const captchaInput = document.querySelector('.captcha_code');
        const secondsSpan = document.getElementById('seconds');

        const hasToken = xdInput && xdInput.value.trim() !== "";
        // Timer is ready if span is missing, empty, or <= 1
        const timerReady = !secondsSpan || secondsSpan.innerText === "" || parseInt(secondsSpan.innerText) <= 1;
        const captchaReady = captchaInput && captchaInput.value.length === 4;

        if (hasToken && timerReady && captchaReady && downloadBtn) {
            if (downloadBtn.disabled) {
                downloadBtn.disabled = false;
            }
            downloadBtn.click();
            clearInterval(checkInterval);
        }
    }, 500);
})();

