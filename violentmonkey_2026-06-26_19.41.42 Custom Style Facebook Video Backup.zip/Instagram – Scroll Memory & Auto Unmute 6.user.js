// ==UserScript==
// @name         Instagram – Scroll Memory & Auto Unmute 6
// @namespace    https://github.com/local/userscripts
// @version      5.0.0
// @match        https://www.instagram.com/*
// @grant        none
// @icon               https://www.google.com/s2/favicons?domain=www.instagram.com&sz=32
// @run-at       document-start
// ==/UserScript==

(function () {
  'use strict';

  // HIDE AUDIO TOGGLE BUTTON
  document.addEventListener('DOMContentLoaded', () => {
    const s = document.createElement('style');
    s.textContent = 'button[aria-label="Toggle audio"]{display:none!important}';
    document.head.appendChild(s);
  }, { once: true });

  // UNMUTE
  const nativeDesc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'muted');
  Object.defineProperty(HTMLMediaElement.prototype, 'muted', {
    get() { return nativeDesc.get.call(this); },
    set(val) {
      nativeDesc.set.call(this, val);
      if (val === true) {
        const el = this;
        setTimeout(() => { try { nativeDesc.set.call(el, false); } catch(_){} }, 80);
      }
    },
    configurable: true,
  });

  // UNIVERSAL SCROLL MEMORY
  const STORE = {};   // path → scrollY, in-memory (no sessionStorage limits)
  let currentPath = location.pathname;
  let _y = 0;

  window.addEventListener('scroll', () => { _y = window.scrollY; }, { passive: true });

  function saveCurrent() {
    if (_y > 0) STORE[currentPath] = _y;
  }

  function restoreScroll(savedY) {
    if (!savedY || savedY < 50) return;
    let tries = 0;
    const t = setInterval(() => {
      tries++;
      if (window.scrollY < savedY - 50) {
        window.scrollTo({ top: savedY, behavior: 'instant' });
      } else {
        clearInterval(t); // scroll stuck — done
      }
      if (tries > 40) clearInterval(t);
    }, 200);
  }

  function onNavigate(toPath) {
    saveCurrent();
    const savedY = STORE[toPath];
    currentPath = toPath;
    restoreScroll(savedY);
  }

  ['pushState', 'replaceState'].forEach(m => {
    const orig = history[m].bind(history);
    history[m] = function (...a) {
      const r = orig(...a);
      try { onNavigate(new URL(a[2] || '', location.href).pathname); } catch(_) {}
      return r;
    };
  });

  window.addEventListener('popstate', () => onNavigate(location.pathname));
})();
