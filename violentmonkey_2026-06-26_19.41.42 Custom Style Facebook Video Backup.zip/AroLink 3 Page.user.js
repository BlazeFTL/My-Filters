// ==UserScript==
// @name         AroLink 3 Page
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Multi-step redirect with a 15-second countdown UI
// @author       BlazeFTL
// @match        *://apnahirework.com/*universtyedu=*
// @match        *://apnahirework.com/*coursestudy=*

// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const p = new URLSearchParams(location.search);
    const university = p.get('universtyedu');
    const course = p.get('coursestudy');
    const edu = p.get('edustudy');

    // --- STEP 1: famemingles -> crimejasoos (coursestudy) ---
    //if (university) {
      //  location.replace('https://crimejasoos.in/educaevacancy/?coursestudy=' + university);
      //  return;  }

    // --- STEP 2: crimejasoos (coursestudy) -> crimejasoos (edustudy) ---
  //  if (course && !edu) {
     //   location.replace('https://crimejasoos.in/educaevacancy/?edustudy=' + course);
     //   return;
  //  }

    // --- STEP 3: Final Countdown to arolinks ---
    if (edu) {
        window.stop();
        let secondsLeft = 15;

        // Apply UI
        document.documentElement.innerHTML = `
            <body style="background:#000;color:#fff;text-align:center;padding-top:20%;font-family:sans-serif;margin:0;">
                <div style="border: 1px solid #444; display: inline-block; padding: 40px; border-radius: 15px; background: #111;">
                    <h1 style="font-size: 2.5rem; margin-bottom: 10px;">Redirecting</h1>
                    <p style="font-size: 1.2rem; color: #aaa;">Please wait <span id="timer" style="color: #00ff00; font-weight: bold;">15</span> seconds...</p>
                    <div style="margin-top: 20px;">
                        <button onclick="location.href='https://arolinks.com/${edu}'"
                                style="background: #fff; color: #000; border: none; padding: 10px 30px; font-weight: bold; cursor: pointer; border-radius: 5px;">
                            Skip to Link
                        </button>
                    </div>
                </div>
            </body>`;

        // Start Timer
        const countdown = setInterval(() => {
            secondsLeft--;
            const timerElement = document.getElementById('timer');

            if (timerElement) {
                timerElement.innerText = secondsLeft;
            }

            if (secondsLeft <= 0) {
                clearInterval(countdown);
                location.href = 'https://arolinks.com/' + edu;
            }
        }, 1000);
    }
})();

