// ==UserScript==
// @name         FB Media Sniffer 9
// @namespace    blazeftl
// @version      0.9
// @description  Extract all available video qualities + owner name from Facebook reel/video, pick best, allow manual quality select
// @match        *://*.facebook.com/*
// @run-at       document-start
// @grant        GM_xmlhttpRequest
// @connect      mbasic.facebook.com
// ==/UserScript==

(function(){
'use strict';

const FB_VIDEO_RE = /fbcdn\.net.*\/v\/t2\//i;
const MEDIA_RE = /\.(mp4|m4v|mov|webm|mp3|m4a)(\?|$)/i;
const QUALITY_RE = /"(playable_url_quality_hd|playable_url_quality_sd|playable_url|browser_native_hd_url|browser_native_sd_url|hd_src|sd_src)":"((?:[^"\\]|\\.)*)"/g;
const NAME_RE = /"name":"((?:[^"\\]|\\.)*)"/g;
const NAME_BLOCKLIST = /^(open app|search|notifications?|messenger|marketplace|reels?|follow|following|like|likes|comment|comments|share|shares|more|tap to unmute|tap to mute|verified|public|friends|profile picture|settings|menu|options|home|watch|groups?|gaming|video call|mute|unmute|facebook)$/i;

const mediaLog = [];
const seen = new Set();
const candidatesByVideo = new WeakMap();
const variantsByReelId = new Map();
const namesByReelId = new Map();
let currentVideo = null;
let wrap = null, btn = null, label = null, popup = null;

function isMedia(url){
  return MEDIA_RE.test(url) || FB_VIDEO_RE.test(url);
}

function isNameLike(txt){
  if(!txt) return false;
  txt = txt.trim();
  if(txt.length < 2 || txt.length > 50) return false;
  if(NAME_BLOCKLIST.test(txt)) return false;
  if(/^[\d\s+.,KkMm]+$/.test(txt)) return false;
  return true;
}

function sanitize(name){
  return name.replace(/[^a-z0-9]+/gi, '_').replace(/^_+|_+$/g, '') || 'facebook';
}

function addCandidate(video, url){
  if(!candidatesByVideo.has(video)) candidatesByVideo.set(video, new Set());
  candidatesByVideo.get(video).add(url);
}

function logUrl(url){
  if(!url || typeof url !== 'string' || seen.has(url) || !isMedia(url)) return;
  seen.add(url);
  const time = performance.now();
  mediaLog.push({url, time});
  if(currentVideo && FB_VIDEO_RE.test(url)) addCandidate(currentVideo, url);
}

function findNearby(re, text, pos, before, after){
  const start = Math.max(0, pos - before);
  const end = Math.min(text.length, pos + after);
  re.lastIndex = start;
  let best = null, bestDist = Infinity, mm;
  while((mm = re.exec(text)) && mm.index < end){
    const dist = Math.abs(mm.index - pos);
    if(dist < bestDist){ bestDist = dist; best = mm; }
  }
  return best;
}

function scanText(text){
  if(!text || text.length < 50) return;
  let m;
  QUALITY_RE.lastIndex = 0;
  while((m = QUALITY_RE.exec(text))){
    let url;
    try{ url = JSON.parse('"' + m[2] + '"'); }catch(e){ continue; }
    if(!isMedia(url)) continue;
    const idMatch = findNearby(/"id":"(\d{6,20})"/g, text, m.index, 4000, 1000);
    const id = idMatch ? idMatch[1] : null;
    if(id){
      if(!variantsByReelId.has(id)) variantsByReelId.set(id, new Set());
      variantsByReelId.get(id).add(url);
      if(!namesByReelId.has(id)){
        const nm = findNearby(NAME_RE, text, m.index, 4000, 1000);
        if(nm){
          let val;
          try{ val = JSON.parse('"' + nm[1] + '"'); }catch(e){ val = null; }
          if(val && isNameLike(val)) namesByReelId.set(id, val);
        }
      }
    } else {
      logUrl(url);
    }
  }
}

function hookFetch(){
  const orig = window.fetch;
  window.fetch = function(...args){
    const urlArg = typeof args[0] === 'string' ? args[0] : args[0]?.url;
    try{ logUrl(urlArg); }catch(e){}
    const p = orig.apply(this, args);
    p.then(resp=>{
      try{
        const ct = resp.headers.get('content-type') || '';
        const cl = parseInt(resp.headers.get('content-length') || '0', 10);
        if(/json|text/i.test(ct) && cl < 4000000){
          resp.clone().text().then(scanText).catch(()=>{});
        }
      }catch(e){}
    }).catch(()=>{});
    return p;
  };
}

function hookXHR(){
  const open = XMLHttpRequest.prototype.open;
  const send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url){
    try{ logUrl(url); }catch(e){}
    return open.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function(...args){
    this.addEventListener('load', function(){
      try{
        const ct = this.getResponseHeader('content-type') || '';
        if(/json|text/i.test(ct) && this.responseText && this.responseText.length < 4000000){
          scanText(this.responseText);
        }
      }catch(e){}
    });
    return send.apply(this, args);
  };
}

function hookPerf(){
  try{
    const po = new PerformanceObserver(list=>{
      for(const e of list.getEntries()) logUrl(e.name);
    });
    po.observe({type:'resource', buffered:true});
  }catch(e){}
}

function pad(n){ return n < 10 ? '0'+n : ''+n; }

function dateStamp(){
  const d = new Date();
  return d.getFullYear() + pad(d.getMonth()+1) + pad(d.getDate()) + '-' + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds());
}

function parseBitrate(url){
  const m = url.match(/bitrate=(\d+)/);
  return m ? parseInt(m[1], 10) : 0;
}

function parseRes(url){
  const m = url.match(/gen2_(\d+)p/);
  return m ? m[1] + 'p' : (parseBitrate(url) ? Math.round(parseBitrate(url)/1000)+'k' : '?');
}

function getCurrentReelId(){
  const m = location.pathname.match(/\/reel\/(\d+)/);
  return m ? m[1] : null;
}

function getProfileNameDom(){
  const anchors = document.querySelectorAll('a[aria-label^="See owner pro"]');
  for(const a of anchors){
    const r = a.getBoundingClientRect();
    if(r.width > 0 && r.height > 0 && r.top < window.innerHeight && r.bottom > 0){
      const txt = a.textContent.trim();
      if(isNameLike(txt)) return txt;
    }
  }
  return getProfileNameByAvatar();
}

function findAvatar(){
  const els = document.querySelectorAll('img, [role="img"]');
  for(const el of els){
    const r = el.getBoundingClientRect();
    if(r.width < 28 || r.width > 60) continue;
    if(Math.abs(r.width - r.height) > 6) continue;
    if(r.bottom < window.innerHeight * 0.55) continue;
    if(r.left > window.innerWidth * 0.3) continue;
    return el;
  }
  return null;
}

function getProfileNameByAvatar(){
  const avatar = findAvatar();
  if(!avatar) return null;
  const ar = avatar.getBoundingClientRect();
  const all = document.querySelectorAll('body *');
  let bestEl = null, bestDist = Infinity;
  for(const el of all){
    if(el.children.length > 2) continue;
    const txt = (el.textContent || '').trim();
    if(!isNameLike(txt)) continue;
    const r = el.getBoundingClientRect();
    if(r.width === 0 || r.height === 0) continue;
    if(r.left < ar.right - 4) continue;
    if(Math.abs((r.top + r.bottom) / 2 - (ar.top + ar.bottom) / 2) > 24) continue;
    const dist = r.left - ar.right;
    if(dist < bestDist){ bestDist = dist; bestEl = el; }
  }
  return bestEl ? bestEl.textContent.trim() : null;
}

function combinedSet(){
  const id = getCurrentReelId();
  const set = new Set();
  if(id && variantsByReelId.has(id)) for(const u of variantsByReelId.get(id)) set.add(u);
  if(currentVideo && candidatesByVideo.has(currentVideo)) for(const u of candidatesByVideo.get(currentVideo)) set.add(u);
  return set;
}

function bestUrlCurrent(){
  const set = combinedSet();
  if(!set.size) return null;
  let best = null, bestRate = -1;
  for(const u of set){ const r = parseBitrate(u); if(r > bestRate){ bestRate = r; best = u; } }
  return best;
}

function qualityList(){
  const set = combinedSet();
  const byRes = new Map();
  for(const u of set){
    const res = parseRes(u);
    const rate = parseBitrate(u);
    if(!byRes.has(res) || parseBitrate(byRes.get(res)) < rate) byRes.set(res, u);
  }
  return [...byRes.entries()].sort((a,b)=>parseBitrate(b[1]) - parseBitrate(a[1]));
}

function currentName(){
  const dom = getProfileNameDom();
  if(dom) return dom;
  const id = getCurrentReelId();
  const nm = id && namesByReelId.get(id);
  return nm || 'facebook';
}

function buildFilename(suffix){
  const base = sanitize(currentName()) + '_' + dateStamp();
  return suffix ? base + '_' + suffix + '.mp4' : base + '.mp4';
}

async function doDownload(url, filename){
  try{
    const resp = await fetch(url);
    const blob = await resp.blob();
    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(blobUrl), 30000);
  }catch(err){
    window.open(url, '_blank');
  }
}

function closePopup(){
  if(popup){ popup.remove(); popup = null; }
}

function openPopup(){
  closePopup();
  const list = qualityList();
  popup = document.createElement('div');
  popup.style.cssText = 'position:fixed;top:358px;right:14px;z-index:999999;background:rgba(20,20,20,.92);border-radius:8px;padding:6px;display:flex;flex-direction:column;gap:4px;min-width:90px';
  if(!list.length){
    const e = document.createElement('div');
    e.style.cssText = 'color:#fff;font-size:11px;padding:4px';
    e.textContent = 'No variants yet';
    popup.appendChild(e);
  }
  list.forEach(([res, url])=>{
    const row = document.createElement('div');
    row.textContent = res;
    row.style.cssText = 'color:#fff;font-size:12px;padding:5px 8px;border-radius:5px;background:rgba(255,255,255,.08);text-align:center;cursor:pointer';
    row.onclick = ()=>{ doDownload(url, buildFilename(res)); closePopup(); };
    popup.appendChild(row);
  });
  document.body.appendChild(popup);
}

function ensureUI(){
  if(wrap) return;
  wrap = document.createElement('div');
  wrap.style.cssText = 'position:fixed;top:310px;right:14px;z-index:999999;display:none;flex-direction:column;align-items:center;gap:4px';
  btn = document.createElement('a');
  btn.style.cssText = 'width:42px;height:42px;border-radius:50%;background:rgba(0,0,0,.6);color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;text-decoration:none;box-shadow:0 1px 4px rgba(0,0,0,.5)';
  btn.textContent = '⬇';
  btn.href = '#';
  label = document.createElement('span');
  label.style.cssText = 'font-size:10px;color:#fff;background:rgba(0,0,0,.6);padding:1px 5px;border-radius:6px;cursor:pointer';
  wrap.appendChild(btn);
  wrap.appendChild(label);
  document.body.appendChild(wrap);

  btn.addEventListener('click', function(ev){
    ev.preventDefault();
    const url = btn.dataset.url;
    if(!url) return;
    doDownload(url, buildFilename(parseRes(url)));
  });

  label.addEventListener('click', function(ev){
    ev.preventDefault();
    if(popup) closePopup();
    else openPopup();
  });
}

function updateButton(){
  ensureUI();
  const id = getCurrentReelId();
  if(!id){
    wrap.style.display = 'none';
    closePopup();
    return;
  }
  if(!currentVideo){
    wrap.style.display = 'none';
    return;
  }
  const url = bestUrlCurrent();
  if(!url){
    wrap.style.display = 'none';
    return;
  }
  btn.dataset.url = url;
  label.textContent = parseRes(url) + ' ▾';
  wrap.style.display = 'flex';
}

function onPlaying(e){
  if(e.target === currentVideo) updateButton();
}

const io = new IntersectionObserver(entries=>{
  let best = null, bestRatio = 0;
  for(const en of entries){
    if(en.isIntersecting && en.intersectionRatio > bestRatio){
      bestRatio = en.intersectionRatio;
      best = en.target;
    }
  }
  if(best && best !== currentVideo){
    currentVideo = best;
    closePopup();
    updateButton();
  }
}, {threshold: [0.6]});

function watchVideo(v){
  if(v.dataset.fmsWatched) return;
  v.dataset.fmsWatched = '1';
  v.addEventListener('playing', onPlaying);
  io.observe(v);
}

function scanVideos(){
  document.querySelectorAll('video').forEach(watchVideo);
}

const mo = new MutationObserver(scanVideos);
mo.observe(document.documentElement, {childList:true, subtree:true});

hookPerf();
hookFetch();
hookXHR();
scanVideos();
setInterval(updateButton, 1200);

})();
