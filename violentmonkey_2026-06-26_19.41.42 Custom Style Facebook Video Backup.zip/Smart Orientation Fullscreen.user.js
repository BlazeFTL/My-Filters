// ==UserScript==
// @name         Smart Orientation Fullscreen
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Detects video aspect ratio and locks orientation accordingly (Landscape for wide, Portrait for tall)
// @author       BlazeFTL
// @icon         https://img.icons8.com/?size=160&id=JFsBQ3XM1EAG&format=png
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.addEventListener('fullscreenchange', function() {
        const fullElem = document.fullscreenElement;

        if (fullElem) {
            // Find the video element inside the fullscreen container
            const video = fullElem.tagName === 'VIDEO' ? fullElem : fullElem.querySelector('video');

            if (video && screen.orientation && screen.orientation.lock) {
                // Check if the video is portrait (tall) or landscape (wide)
                // We use videoWidth/Height because that's the actual source resolution
                if (video.videoHeight > video.videoWidth) {
                    // It's a vertical video like in your screenshot
                    screen.orientation.lock('portrait').catch(err => console.log("Portrait lock failed: " + err));
                } else {
                    // It's a standard wide video
                    screen.orientation.lock('landscape').catch(err => console.log("Landscape lock failed: " + err));
                }
            }
        } else {
            // Unlock orientation when exiting fullscreen
            if (screen.orientation && screen.orientation.unlock) {
                screen.orientation.unlock();
            }
        }
    });
})();

