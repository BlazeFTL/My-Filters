// ==UserScript==
// @name         dropmms Gallery Style
// @namespace    BlazeFTL
// @version      1.5
// @match        https://dropmms.co/*
// @match        https://www.dropmms.co/*
// @grant        GM_addStyle
// @run-at       document-end
// ==/UserScript==

GM_addStyle(`
  .tthumbGridview .ipsGrid {
    column-count: 3 !important;
    column-gap: 6px !important;
    display: block !important;
    height: auto !important;
    padding: 0 4px !important;
  }
  .tthumbGridview .ipsGrid > [class*="ipsGrid_span"] {
    width: 100% !important;
    float: none !important;
    display: inline-block !important;
    break-inside: avoid;
    -webkit-column-break-inside: avoid;
    box-sizing: border-box;
    margin: 0 0 6px 0 !important;
    height: auto !important;
    min-height: 0 !important;
    padding: 0 !important;
    vertical-align: top;
  }
  .tthumbGridview_img,
  [id^="tthumb_"] {
    width: 100% !important;
    height: 356px !important;
    object-fit: cover !important;
    padding-bottom: 0 !important;
    display: block !important;
  }
  @media only screen and (max-width: 400px) {
    .tthumbGridview .ipsGrid { column-count: 2 !important; }
  }
`);
