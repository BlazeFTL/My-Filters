// ==UserScript==
// @name         TorUpload Debug Telemetry
// @namespace    https://github.com/BlazeFTL
// @description  Redirects telemetry to an on-screen text area to bypass console truncation.
// @version      1.3
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const createUI = () => {
        const container = document.createElement('div');
        container.id = 'telemetry-viewer';
        // Height and Width kept exactly at 400x200 as per previous version
        container.style = `
            position: fixed;
            top: 15px;
            right: 15px;
            width: 400px;
            height: 200px;
            z-index: 999999;
            background: #ffffff;
            color: #333;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(0,0,0,0.05);
        `;

        // Gradient Header similar to the reference image
        const header = document.createElement('div');
        header.style = `
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            padding: 8px 12px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 0.5px;
        `;

        const title = document.createElement('span');
        title.innerText = 'TELEMETRY CAPTURE';

        const copyBtn = document.createElement('button');
        copyBtn.innerText = 'COPY';
        copyBtn.style = `
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.4);
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 10px;
            font-weight: bold;
            transition: 0.2s;
        `;
        copyBtn.onmouseover = () => copyBtn.style.background = 'rgba(255,255,255,0.3)';
        copyBtn.onmouseout = () => copyBtn.style.background = 'rgba(255,255,255,0.2)';

        const textArea = document.createElement('textarea');
        textArea.id = 'telemetry-data-box';
        textArea.style = `
            flex: 1;
            background: #f8f9fa;
            color: #2c3e50;
            border: none;
            resize: none;
            outline: none;
            padding: 10px;
            font-family: 'Consolas', 'Monaco', monospace;
            font-size: 11px;
            line-height: 1.4;
        `;
        textArea.placeholder = 'Listening for incoming data...';

        copyBtn.onclick = () => {
            textArea.select();
            document.execCommand('copy');
            const originalText = copyBtn.innerText;
            copyBtn.innerText = 'COPIED!';
            setTimeout(() => copyBtn.innerText = originalText, 2000);
        };

        header.appendChild(title);
        header.appendChild(copyBtn);
        container.appendChild(header);
        container.appendChild(textArea);
        document.documentElement.appendChild(container);
        return textArea;
    };

    let logBox;

    const wait = setInterval(() => {
        if (typeof window.LALLJLutmoZpvvbikjaWM !== 'function') return;

        clearInterval(wait);
        if (!logBox) logBox = createUI();

        const original = window.LALLJLutmoZpvvbikjaWM;

        window.LALLJLutmoZpvvbikjaWM = function(str) {
            if (logBox) {
                const timestamp = new Date().toLocaleTimeString();
                logBox.value = `[${timestamp}] 📥 Received:\n${str}\n\n` + logBox.value;
            }
            console.log('[RAW TELEMETRY]', str);
            return original.apply(this, arguments);
        };

    }, 10);
})();
