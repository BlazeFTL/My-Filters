// ==UserScript==
// @name         NoodleMagazine Fullscreen Rotation Fix
// @namespace    BlazeFTL
// @version      1.0
// @match        *://*.noodlemagazine.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
  const origLock = screen.orientation && screen.orientation.lock
    ? screen.orientation.lock.bind(screen.orientation)
    : null;

  if (!origLock) return;

  screen.orientation.lock = function(orientation) {
    const video = document.querySelector('video');
    if (video && video.videoHeight > video.videoWidth) {
      return Promise.resolve();
    }
    return origLock(orientation);
  };

  document.addEventListener('fullscreenchange', () => {
    const video = document.querySelector('video');
    if (document.fullscreenElement && video && video.videoHeight > video.videoWidth) {
      try { screen.orientation.unlock(); } catch (e) {}
    }
  });
})();
