// ==UserScript==
// @name         JW Player Double-Tap Seek (Fixed Big Text)
// @namespace    http://tampermonkey.net/
// @version      4.1
// @description  Double-tap left/right sides to seek ±10s. Big fixed-position text, no round UI. Keeps control bar buttons and fullscreen.
// @match        https://*.mat6tube.com/*
// @match        https://*.noodlemagazine.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function addStyle(css) {
        const style = document.createElement('style');
        style.type = 'text/css';
        style.appendChild(document.createTextNode(css));
        document.head.appendChild(style);
    }

    addStyle(`
        .jwplayer {
            position: relative;
        }

        /* --- Fixed-position double-tap feedback (big text, no circle) --- */
        .jw-dt-feedback {
            position: absolute;
            top: 50%;
            pointer-events: none;
            z-index: 15;
            animation: dtFade 0.85s ease forwards;
        }

        .jw-dt-feedback-left {
            left: 16%;
            transform: translate(-50%, -50%);
        }

        .jw-dt-feedback-right {
            right: 16%;
            transform: translate(50%, -50%);
        }

        @media (orientation: landscape) {
            .jw-dt-feedback-left { left: 14%; }
            .jw-dt-feedback-right { right: 14%; }
        }

        .jw-dt-feedback .dt-text {
            color: #fff;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            font-size: 32px;
            font-weight: 800;
            letter-spacing: 0.8px;
            text-shadow: 0 2px 12px rgba(0,0,0,0.7);
            animation: dtPop 0.35s cubic-bezier(0.22, 1.4, 0.36, 1) forwards;
            white-space: nowrap;
        }

        @keyframes dtPop {
            0% { transform: scale(0.6); opacity: 0; }
            60% { transform: scale(1.08); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
        }

        @keyframes dtFade {
            0% { opacity: 1; }
            70% { opacity: 1; }
            100% { opacity: 0; }
        }

        /* --- Top-right fullscreen (stock) --- */
        .jw-top-right-controls {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 20;
            display: flex;
            gap: 8px;
            pointer-events: auto;
            transition: opacity 0.3s ease;
        }

        .jw-top-right-controls button {
            background: rgba(0,0,0,0.5);
            border: none;
            color: white;
            padding: 4px 8px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
            line-height: 1;
            transition: background-color 0.2s ease;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            min-width: 36px;
            min-height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .jw-top-right-controls button:hover {
            background-color: rgba(0,0,0,0.7);
        }

        /* --- Control bar buttons (stock) --- */
        .jw-controlbar .jw-button-container {
            display: flex;
            align-items: center;
        }

        .jw-controlbar .custom-control-button {
            background: none;
            border: none;
            color: white;
            padding: 0 4px;
            cursor: pointer;
            font-size: 12px;
            line-height: 1;
            margin-right: 8px;
            display: flex;
            align-items: center;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            transition: color 0.2s ease;
            min-height: 36px;
        }

        .jw-controlbar .custom-control-button:hover {
            color: #aaaaaa;
        }

        .jw-controlbar .jw-icon-playback {
            margin-right: 8px;
        }

        /* Sync hide/show with JW Player controls */
        .jwplayer.jw-flag-user-inactive .jw-top-right-controls {
            opacity: 0;
            pointer-events: none !important;
        }

        /* Hide custom controls during ads */
        .jwplayer.jw-flag-ads .custom-control-button,
        .jwplayer.jw-flag-ads .jw-top-right-controls {
            display: none !important;
        }
    `);

    function init() {
        const check = setInterval(() => {
            if (typeof jwplayer !== 'function') return;

            const playerElements = document.querySelectorAll('.jwplayer:not([data-custom-controls="true"])');
            playerElements.forEach(el => {
                if (!el.id) return;
                try {
                    const instance = jwplayer(el.id);
                    if (instance && typeof instance.getState === 'function') {
                        el.setAttribute('data-custom-controls', 'true');
                        enhanceJWPlayer(instance, el);
                    }
                } catch (e) {
                    console.warn('JW enhancement skipped:', el.id, e);
                }
            });

            try {
                const defaultInstance = jwplayer();
                const defaultContainer = defaultInstance && defaultInstance.getContainer ? defaultInstance.getContainer() : null;
                if (defaultContainer && !defaultContainer.hasAttribute('data-custom-controls')) {
                    defaultContainer.setAttribute('data-custom-controls', 'true');
                    enhanceJWPlayer(defaultInstance, defaultContainer);
                }
            } catch (e) {}
        }, 800);
    }

    function enhanceJWPlayer(player, playerContainer) {
        if (!playerContainer) return;
        if (playerContainer.querySelector('.jw-custom-controls-wrapper')) return;

        const observer = new MutationObserver((mutations, obs) => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');

            if (controlBar && playButtonContainer) {
                if (!playerContainer.querySelector('.jw-custom-controls-wrapper')) {
                    obs.disconnect();
                    addButtons(player, playButtonContainer, playerContainer);
                }
            }
        });

        observer.observe(playerContainer, { childList: true, subtree: true });

        const fallback = setInterval(() => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');

            if (controlBar && playButtonContainer) {
                if (!playerContainer.querySelector('.jw-custom-controls-wrapper')) {
                    clearInterval(fallback);
                    observer.disconnect();
                    addButtons(player, playButtonContainer, playerContainer);
                }
            }
        }, 1200);
    }

    function addButtons(player, playButtonContainer, playerContainer) {
        const marker = document.createElement('div');
        marker.className = 'jw-custom-controls-wrapper';
        marker.style.display = 'none';
        playerContainer.appendChild(marker);

        const safeSeek = (offset) => {
            try {
                const pos = player.getPosition() || 0;
                const dur = player.getDuration() || 0;
                player.seek(Math.max(0, Math.min(pos + offset, dur)));
            } catch (e) {
                console.warn('Seek failed:', e);
            }
        };

        /* --- Double-tap logic --- */
        const DT_TIMEOUT = 450;
        const SIDE_MARGIN = 0.35;

        let dtState = {
            side: null,
            lastTime: 0,
            timer: null
        };

        function resetDT() {
            if (dtState.timer) clearTimeout(dtState.timer);
            dtState = { side: null, lastTime: 0, timer: null };
        }

        function getTapSide(x, width) {
            if (x < width * SIDE_MARGIN) return 'left';
            if (x > width * (1 - SIDE_MARGIN)) return 'right';
            return 'center';
        }

        function showDTFeedback(side) {
            // Remove old feedback for this side to restart animation
            const old = playerContainer.querySelector('.jw-dt-feedback[data-side="' + side + '"]');
            if (old) old.remove();

            const feedback = document.createElement('div');
            feedback.className = 'jw-dt-feedback jw-dt-feedback-' + side;
            feedback.setAttribute('data-side', side);

            const text = document.createElement('div');
            text.className = 'dt-text';
            text.textContent = side === 'left' ? '-10 >' : '+10 >';

            feedback.appendChild(text);
            playerContainer.appendChild(feedback);

            setTimeout(() => feedback.remove(), 900);
        }

        playerContainer.addEventListener('click', (e) => {
            // Ignore clicks on control bar or top-right controls
            if (e.target.closest('.jw-controlbar') || e.target.closest('.jw-top-right-controls')) {
                resetDT();
                return;
            }

            const rect = playerContainer.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            // Ignore top/bottom safe zones
            if (y < 68 || y > rect.height - 68) {
                resetDT();
                return;
            }

            const side = getTapSide(x, rect.width);
            if (side === 'center') {
                resetDT();
                return;
            }

            const now = Date.now();

            if (dtState.side === side && (now - dtState.lastTime) < DT_TIMEOUT) {
                // Double-tap (or more) on same side → seek
                clearTimeout(dtState.timer);
                dtState.timer = setTimeout(resetDT, DT_TIMEOUT);
                dtState.lastTime = now;

                e.stopPropagation();
                e.preventDefault();

                const offset = side === 'left' ? -10 : 10;
                safeSeek(offset);
                showDTFeedback(side);
            } else {
                // First tap on this side
                resetDT();
                dtState.side = side;
                dtState.lastTime = now;
                dtState.timer = setTimeout(resetDT, DT_TIMEOUT);
            }
        }, true);

        /* --- Control Bar Buttons --- */
        const createControlBtn = (label, onClick) => {
            const btn = document.createElement('button');
            btn.textContent = label;
            btn.className = 'custom-control-button';
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                onClick();
            });
            return btn;
        };

        const rewindBar = createControlBtn('« 10s', () => safeSeek(-10));
        const forwardBar = createControlBtn('10s »', () => safeSeek(10));

        const playPause = playButtonContainer.querySelector('.jw-icon-playback');
        if (playPause) {
            playPause.parentNode.insertBefore(rewindBar, playPause.nextSibling);
            playPause.parentNode.insertBefore(forwardBar, rewindBar.nextSibling);
        } else {
            playButtonContainer.prepend(forwardBar);
            playButtonContainer.prepend(rewindBar);
        }

        /* --- Top-Right Fullscreen --- */
        const topRight = document.createElement('div');
        topRight.className = 'jw-top-right-controls';

        const fsBtn = document.createElement('button');
        fsBtn.innerHTML = '⛶';
        fsBtn.title = 'Toggle Fullscreen';
        fsBtn.setAttribute('aria-label', 'Toggle Fullscreen');

        fsBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            try {
                player.setFullscreen(!player.getFullscreen());
            } catch (err) {}
        });

        player.on('fullscreen', (event) => {
            fsBtn.innerHTML = event.fullscreen ? '⛶̽' : '⛶';
            fsBtn.title = event.fullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen';
        });

        try {
            if (player.getFullscreen()) {
                fsBtn.innerHTML = '⛶̽';
                fsBtn.title = 'Exit Fullscreen';
            }
        } catch (e) {}

        topRight.appendChild(fsBtn);
        playerContainer.appendChild(topRight);

        /* --- Keyboard Shortcuts --- */
        const keyHandler = (e) => {
            if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
            const isPlayerFocused = playerContainer.contains(document.activeElement);
            let isFullscreen = false;
            try { isFullscreen = player.getFullscreen(); } catch (e) {}
            if (!isPlayerFocused && !isFullscreen) return;

            e.preventDefault();
            e.stopPropagation();
            safeSeek(e.key === 'ArrowLeft' ? -10 : 10);
        };
        document.addEventListener('keydown', keyHandler);

        /* Cleanup */
        const cleanup = new MutationObserver(() => {
            if (!document.body.contains(playerContainer)) {
                document.removeEventListener('keydown', keyHandler);
                cleanup.disconnect();
            }
        });
        cleanup.observe(document.body, { childList: true, subtree: true });

        console.log('JW Player double-tap seek (fixed big text) added.');
    }

    init();
})();
