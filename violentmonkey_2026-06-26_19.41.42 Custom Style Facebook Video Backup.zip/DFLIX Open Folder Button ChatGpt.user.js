// ==UserScript==
// @name         DFLIX Open Folder Button ChatGpt
// @namespace    BlazeFTL
// @match        http://*.dflix.live/*
// @icon         data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAMAAABF0y+mAAAAS1BMVEVHcEwAHiQAHiQAHiQAHiQAHiQAHiQAHiQAFhoADREAT14AaHoAeI4AAgRyKB69MxeZLRkAQEwAnbkAiaLuOQgAzvMArs0ALzgAvuHoJbxIAAAACHRSTlMADo3b/P9m/TlQv8AAAADQSURBVHgBhZOFAYMwEAAh6ZdXnMD+i9ZwSw+JXFySD6nzD9jx8C5Nfjzhkue9G20Kt6SJu5cu8ffSJ9m9zJIxxAPwY5TEsoNplahMuIFYcZak9I2jmSHhN46kNEoUgLwoyqqua6mlUQMgEJwklm1ettyxVEG5kr5XW2WbQ/6RfQVB6kaGcCFDkK+0MBiemjWzoHXDQxAT3A+oISBllabq67kmjOMG/P7xNxm0eSoftNovQqX/ly+68NEti2529JhED1j0aMYP9Xgdsr3IxuvwBrboFerT2sQ5AAAAAElFTkSuQmCC
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
'use strict';

function injectButton(container){

    if (!container || container.querySelector('.openFolderBtn')) return;

    const download = container.querySelector('a[href*=":8088"]');
    if (!download) return;

    const fileURL = download.href;
    const folderURL = fileURL.substring(0, fileURL.lastIndexOf('/') + 1);

    const btn = document.createElement('button');
    btn.className = 'openFolderBtn';
    btn.textContent = 'Open Folder';

    btn.style.padding = '0.5rem 1rem';
    btn.style.borderRadius = '6px';
    btn.style.background = '#16a34a';
    btn.style.color = '#fff';
    btn.style.cursor = 'pointer';

    btn.onclick = () => window.open(folderURL, '_blank');

    container.appendChild(btn);
}

function scan(){

    document
        .querySelectorAll('.gap-2.flex-wrap.flex')
        .forEach(injectButton);

}

new MutationObserver(scan).observe(document.body,{
    childList:true,
    subtree:true
});

scan();

})();