// ==UserScript==
// @name         Video Src Catcher (StreamGrabber companion) 1.0.8
// @namespace    https://github.com/BlazeFTL
// @description  Catches video URLs with non-standard extensions that StreamGrabber misses. Shows FAB download button with live percentage track.
// @version      1.0.8
// @author       BlazeFTL
// @match        *://*/*
// @exclude      *://*.youtube.*/*
// @exclude      *://*.netflix.com/*
// @exclude      *://*.google.*/*
// @grant        GM_download
// @grant        GM_addStyle
// @grant        GM_getValue
// @grant        GM_setValue
// @license      MIT
// @run-at       document-start
// ==/UserScript==

(function () {
  'use strict';

  // Known-extension patterns — URLs matching these are handled by StreamGrabber already
  const SG_PATTERNS = /\.(m3u8|mp4|mkv|webm|avi|mov|m4v|flv|ogv|ogg|m4s|ts|m2ts)([?#]|$)/i;
  // Skip tracking/analytics noise
  const NOISE = /ping\.gif|jwpltx|doubleclick|analytics|\/stats\//i;

  const detected = new Map(); // url -> { url, title, ts }
  let fab = null;
  let panel = null;
  let fabVisible = false;

  // Detect Android/Firefox Mobile environments early
  const isAndroid = /Android/i.test(navigator.userAgent);

  // ── Hooks ──────────────────────────────────────────────────────────────────

  function onVideoSrc(url) {
    if (!url || typeof url !== 'string') return;
    if (!/^https?:\/\//i.test(url)) return;
    if (SG_PATTERNS.test(url)) return; // StreamGrabber handles these
    if (NOISE.test(url)) return;
    if (detected.has(url)) return;

    detected.set(url, { url, title: document.title || location.hostname, ts: Date.now() });
    renderFab();
  }

  function checkVideoElement(v) {
    if (!v) return;
    if (v.src) onVideoSrc(v.src);
    if (v.currentSrc) onVideoSrc(v.currentSrc);

    v.querySelectorAll('source').forEach(srcEl => {
      if (srcEl.src) onVideoSrc(srcEl.src);
    });
  }

  function hookMediaElement() {
    const proto = HTMLMediaElement.prototype;

    const srcDesc = Object.getOwnPropertyDescriptor(proto, 'src');
    if (srcDesc && srcDesc.set) {
      Object.defineProperty(proto, 'src', {
        get: srcDesc.get,
        set(val) {
          srcDesc.set.call(this, val);
          if (this instanceof HTMLVideoElement) {
            try { onVideoSrc(val); } catch (_) {}
          }
        },
        configurable: true,
      });
    }

    const origSetAttr = proto.setAttribute;
    proto.setAttribute = function (name, value) {
      if (this instanceof HTMLVideoElement && name === 'src') {
        try { onVideoSrc(value); } catch (_) {}
      }
      return origSetAttr.call(this, name, value);
    };
  }

  function hookCreateElement() {
    const orig = document.createElement.bind(document);
    document.createElement = function (tag, ...args) {
      const el = orig(tag, ...args);
      const lowerTag = tag.toLowerCase();
      if (lowerTag === 'video' || lowerTag === 'source') {
        ['loadstart', 'loadedmetadata', 'canplay'].forEach(ev => {
          el.addEventListener(ev, () => {
            try {
              if (lowerTag === 'video') {
                checkVideoElement(el);
              } else if (el.parentElement && el.parentElement.tagName === 'VIDEO') {
                checkVideoElement(el.parentElement);
              }
            } catch (_) {}
          });
        });
      }
      return el;
    };
  }

  function scanExisting() {
    document.querySelectorAll('video').forEach(v => {
      checkVideoElement(v);
      ['loadstart', 'loadedmetadata', 'canplay', 'play'].forEach(ev =>
        v.addEventListener(ev, () => checkVideoElement(v))
      );
    });
  }

  function startObserver() {
    new MutationObserver((mutations) => {
      mutations.forEach(mutation => {
        if (mutation.type === 'attributes' && mutation.attributeName === 'src') {
          if (mutation.target.tagName === 'VIDEO' || mutation.target.tagName === 'SOURCE') {
            onVideoSrc(mutation.target.src);
          }
        } else {
          scanExisting();
        }
      });
    }).observe(
      document.documentElement,
      { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] }
    );
  }

  // ── UI ─────────────────────────────────────────────────────────────────────

  GM_addStyle(`
    #vsc-fab {
      position: fixed;
      bottom: 72px;
      right: 14px;
      z-index: 2147483646;
      background: #0f62fe;
      color: #fff;
      border-radius: 28px;
      padding: 10px 14px;
      font: 600 13px/1 system-ui, sans-serif;
      cursor: pointer;
      box-shadow: 0 4px 16px rgba(0,0,0,.45);
      display: flex;
      align-items: center;
      gap: 7px;
      user-select: none;
      transition: opacity .2s, transform .2s;
    }
    #vsc-fab:hover { background: #0353e9; }
    #vsc-fab .vsc-count {
      background: #ff3e3e;
      border-radius: 50%;
      width: 18px; height: 18px;
      font-size: 11px;
      display: flex; align-items: center; justify-content: center;
    }
    #vsc-panel {
      position: fixed;
      bottom: 118px;
      right: 14px;
      z-index: 2147483647;
      background: #1e1e2e;
      color: #cdd6f4;
      border-radius: 12px;
      width: 320px;
      max-height: 380px;
      overflow-y: auto;
      box-shadow: 0 8px 32px rgba(0,0,0,.6);
      font: 13px/1.4 system-ui, sans-serif;
      display: none;
    }
    #vsc-panel.open { display: block; }
    #vsc-panel-header {
      padding: 10px 14px;
      font-weight: 700;
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: .06em;
      color: #89b4fa;
      border-bottom: 1px solid #313244;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    #vsc-panel-header button {
      background: none; border: none; color: #6c7086;
      cursor: pointer; font-size: 16px; padding: 0 2px;
    }
    #vsc-panel-header button:hover { color: #f38ba8; }
    .vsc-item {
      padding: 10px 14px;
      border-bottom: 1px solid #313244;
    }
    .vsc-item:last-child { border-bottom: none; }
    .vsc-item-title {
      font-size: 12px;
      color: #a6adc8;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-bottom: 6px;
    }
    .vsc-item-url {
      font-size: 11px;
      color: #585b70;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-bottom: 8px;
      font-family: monospace;
    }
    .vsc-item-actions { display: flex; gap: 6px; }
    .vsc-btn {
      flex: 1;
      padding: 5px 0;
      border-radius: 6px;
      border: none;
      cursor: pointer;
      font-size: 12px;
      font-weight: 600;
    }
    .vsc-btn-dl { background: #0f62fe; color: #fff; }
    .vsc-btn-dl:hover { background: #0353e9; }
    .vsc-btn-copy { background: #313244; color: #cdd6f4; }
    .vsc-btn-copy:hover { background: #45475a; }
    .vsc-btn-open { background: #313244; color: #cdd6f4; }
    .vsc-btn-open:hover { background: #45475a; }
  `);

  function renderFab() {
    const count = detected.size;
    if (!count) return;

    if (!fab) {
      fab = document.createElement('div');
      fab.id = 'vsc-fab';
      fab.innerHTML = `⬇ <span>Video</span><span class="vsc-count">0</span>`;
      fab.addEventListener('click', togglePanel);
      document.body.appendChild(fab);
      fabVisible = true;
    }

    fab.querySelector('.vsc-count').textContent = count;
  }

  function togglePanel() {
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'vsc-panel';
      document.body.appendChild(panel);
    }
    panel.classList.toggle('open');
    if (panel.classList.contains('open')) renderPanel();
  }

  // Network stream fetch pipeline that extracts progress chunks for real-time percentage values
  function blobStreamWithProgress(url, filename, btnEl) {
    fetch(url, {
      method: 'GET',
      mode: 'cors',
      credentials: 'omit'
    })
    .then(response => {
      if (!response.ok) throw new Error('Network file access error');

      const contentLength = response.headers.get('content-length');
      if (!contentLength) {
        // Fallback banner state if target resource hides file length headers
        btnEl.textContent = 'Streaming...';
        return response.blob();
      }

      const total = parseInt(contentLength, 10);
      let loaded = 0;

      const reader = response.body.getReader();
      return new Response(
        new ReadableStream({
          start(controller) {
            function read() {
              reader.read().then(({ done, value }) => {
                if (done) {
                  controller.close();
                  return;
                }
                loaded += value.byteLength;
                const percentage = Math.round((loaded / total) * 100);
                btnEl.textContent = `${percentage}%`;
                controller.enqueue(value);
                read();
              }).catch(error => {
                controller.error(error);
              });
            }
            read();
          }
        })
      ).blob();
    })
    .then(blob => {
      btnEl.textContent = 'Saving...';
      const blobUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = filename || 'video.mp4';
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();

      setTimeout(() => {
        a.remove();
        window.URL.revokeObjectURL(blobUrl);
        btnEl.textContent = '⬇ Download';
      }, 600);
    })
    .catch(err => {
      console.warn('Advanced tracking failed, hitting primary link window layer:', err);
      btnEl.textContent = 'Opening window...';
      const fallbackLink = document.createElement('a');
      fallbackLink.href = url;
      fallbackLink.target = '_blank';
      document.body.appendChild(fallbackLink);
      fallbackLink.click();
      fallbackLink.remove();
      setTimeout(() => { btnEl.textContent = '⬇ Download'; }, 1500);
    });
  }

  function renderPanel() {
    if (!panel) return;
    const items = [...detected.values()].reverse();

    panel.innerHTML = `
      <div id="vsc-panel-header">
        Video Src Catcher (${items.length})
        <button id="vsc-close" title="Close">✕</button>
      </div>
      ${items.map((item, i) => `
        <div class="vsc-item">
          <div class="vsc-item-title" title="${esc(item.title)}">${esc(item.title)}</div>
          <div class="vsc-item-url" title="${esc(item.url)}">${esc(item.url)}</div>
          <div class="vsc-item-actions">
            <button class="vsc-btn vsc-btn-dl" data-i="${i}">⬇ Download</button>
            <button class="vsc-btn vsc-btn-copy" data-i="${i}">Copy URL</button>
            <button class="vsc-btn vsc-btn-open" data-i="${i}">Open</button>
          </div>
        </div>
      `).join('')}
    `;

    panel.querySelector('#vsc-close').addEventListener('click', () => {
      panel.classList.remove('open');
    });

    panel.querySelectorAll('.vsc-btn-dl').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = items[+btn.dataset.i];
        const fname = (item.title || 'video').replace(/[\\/:*?"<>|]/g, '_').slice(0, 80) + '.mp4';

        btn.textContent = '0%';

        if (isAndroid || typeof GM_download !== 'function') {
          blobStreamWithProgress(item.url, fname, btn);
          return;
        }

        try {
          GM_download({
            url: item.url,
            name: fname,
            headers: {
              "Referer": location.origin,
              "Origin": location.origin
            },
            onprogress: (progress) => {
              if (progress.total) {
                const pct = Math.round((progress.done / progress.total) * 100);
                btn.textContent = `${pct}%`;
              } else {
                btn.textContent = 'Downloading...';
              }
            },
            onerror: () => {
              blobStreamWithProgress(item.url, fname, btn);
            },
            ontimeout: () => {
              blobStreamWithProgress(item.url, fname, btn);
            },
            onload: () => {
              btn.textContent = '⬇ Download';
            }
          });
        } catch (e) {
          blobStreamWithProgress(item.url, fname, btn);
        }
      });
    });

    panel.querySelectorAll('.vsc-btn-copy').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = items[+btn.dataset.i];
        navigator.clipboard.writeText(item.url).catch(() => {
          const ta = document.createElement('textarea');
          ta.value = item.url;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          ta.remove();
        });
        btn.textContent = 'Copied!';
        setTimeout(() => { btn.textContent = 'Copy URL'; }, 1500);
      });
    });

    panel.querySelectorAll('.vsc-btn-open').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = items[+btn.dataset.i];
        window.open(item.url, '_blank');
      });
    });
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ── Init ───────────────────────────────────────────────────────────────────

  hookMediaElement();
  hookCreateElement();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      scanExisting();
      startObserver();
    });
  } else {
    scanExisting();
    startObserver();
  }

})();
