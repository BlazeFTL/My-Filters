// ==UserScript==
// @name         InShortUrl Instant ByPass
// @namespace    https://github.com/BlazeFTL
// @description  Redirects from mahitimanch to inshorturl using link parameter
// @version      1.0
// @author       BlazeFTL
// @match        https://mahitimanch.in/folder.php?link=*
// @license      MIT
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // Stop the window from loading further resources
    window.stop();

    // Parse the 'link' parameter from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const linkParam = urlParams.get('link');

    if (linkParam) {
        // Construct the new URL and redirect
        const targetUrl = `https://inshorturl.com/${linkParam}`;
        window.location.replace(targetUrl);
    }
})();
