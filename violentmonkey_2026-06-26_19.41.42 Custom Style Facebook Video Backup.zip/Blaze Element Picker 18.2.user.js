// ==UserScript==
// @name         Blaze Element Picker 18.2
// @namespace    https://github.com/BlazeFTL
// @description  Pro Picker: Red High-Visibility Borders & Intelligent Parent Trail Logic.
// @version      18.2
// @author       BlazeFTL
// @match        *://*/*
// @grant        GM_registerMenuCommand
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==

(function(){
    'use strict';
    let active=false,previewMode=false,baseElement=null,currentTarget=null,currentDepth=5,proximityOffset=0,verticalOffset=0;

    const esc = (str) => str.replace(/([!"#$%&'()*+,.\/:;<=>?@\[\\\]^`{|}~])/g, "\\$1");

    const style=document.createElement('style');
    style.innerHTML=`
        .blaze-target{outline:12px solid #ff0000!important;outline-offset:-6px!important;background-color:rgba(255,0,0,.25)!important;z-index:2147483645!important;transition:all 0.15s ease-in-out}
        .blaze-auto-match{outline:4px dashed #ff0000!important;background-color:rgba(255,0,0,.1)!important}
        .blaze-preview-hidden{display:none!important}

        #blaze-launcher{
            position:fixed;bottom:20px;left:20px;z-index:2147483647;
            width:60px;height:60px;border-radius:20px;
            background:linear-gradient(135deg, #ef4444 0%, #991b1b 100%);
            color:#fff;border:2px solid rgba(255,255,255,0.3);
            cursor:move;box-shadow:0 10px 25px -5px rgba(0,0,0,0.4);
            display:flex;align-items:center;justify-content:center;
            font-weight:800;font-family: sans-serif;font-size:12px;
            user-select:none;transition:transform 0.2s ease;
        }
        #blaze-launcher:hover{transform:scale(1.1);}

        #blaze-ui-panel{
            position:fixed;bottom:95px;left:20px;width:360px;
            background:rgba(255,255,255,0.98);
            backdrop-filter:blur(12px);
            border:1px solid rgba(0,0,0,0.15);
            border-radius:20px;box-shadow:0 25px 50px -12px rgba(0,0,0,0.3);
            z-index:2147483646;font-family: system-ui, -apple-system, sans-serif;
            display:none;user-select:none;overflow:hidden;
        }

        #blaze-drag-handle{
            background:linear-gradient(90deg, #dc2626, #991b1b);
            color:#fff;padding:12px 16px;font-size:11px;letter-spacing:1px;
            font-weight:700;cursor:move;display:flex;justify-content:space-between;align-items:center;
        }

        .blaze-content-wrapper{padding:20px}

        .blaze-row{
            margin-bottom:12px;font-size:12px;font-weight:700;
            display:flex;align-items:center;justify-content:space-between;color:#111827!important;
        }

        #blaze-selector-output{
            width:100%;height:90px;margin:12px 0 8px;font-size:11px;
            border:2px solid #f3f4f6;border-radius:12px;padding:12px;
            background:#f9fafb;color:#000;font-family: monospace;
            box-sizing:border-box;display:block!important;resize:none;outline:none;
        }

        #blaze-suggestions{
            width:100%;max-height:160px;overflow-y:auto;
            border:1.5px solid #f3f4f6;margin-bottom:15px;background:#fff;border-radius:12px;
        }
        #blaze-suggestions div{padding:10px 14px;font-size:10px;cursor:pointer;border-bottom:1px solid #f3f4f6;color:#374151;word-break:break-all;}
        #blaze-suggestions div:hover{background:#fee2e2;color:#b91c1c}
        #blaze-suggestions .suggest-label{background:#f8fafc;font-weight:800;padding:5px 14px;font-size:9px;color:#64748b;cursor:default;border-bottom:1px solid #e2e8f0}

        .blaze-slider{
            -webkit-appearance:none;width:140px;height:6px;background:#e5e7eb;border-radius:5px;outline:none;
        }
        .blaze-slider::-webkit-slider-thumb{
            -webkit-appearance:none;width:18px;height:18px;background:#ef4444;border-radius:50%;cursor:pointer;border:2px solid #fff;box-shadow:0 0 5px rgba(0,0,0,0.2);
        }

        .blaze-status{font-size:10px;font-weight:800;padding:4px 10px;border-radius:9999px;text-transform:uppercase}
        .status-ok{background:#dcfce7;color:#15803d}
        .status-err{background:#fee2e2;color:#b91c1c}

        .blaze-btn-row{display:flex;gap:8px;margin-top:10px}
        .blaze-btn{
            flex:1;padding:12px;cursor:pointer;border:none;border-radius:12px;
            font-size:11px;font-weight:700;color:#fff;transition:all 0.2s;
        }
        .btn-copy{background:#059669;box-shadow:0 4px 6px -1px rgba(5,150,105,0.3)}
        .btn-preview{background:#4f46e5;box-shadow:0 4px 6px -1px rgba(79,70,229,0.3)}
        .btn-preview.active{background:#3730a3}
        .btn-stop{background:#dc2626;width:100%;margin-top:8px;box-shadow:0 4px 6px -1px rgba(220,38,38,0.3)}
    `;
    document.head.appendChild(style);

    const ui=document.createElement('div');
    ui.id='blaze-ui-panel';
    ui.innerHTML=`
        <div id="blaze-drag-handle"><span>BLAZE PICKER PRO</span><span style="font-size:9px;opacity:0.8;">V18.2</span></div>
        <div class="blaze-content-wrapper">
            <div class="blaze-row"><span>Selection Depth: <span id="depth-val">5</span></span><input type="range" min="1" max="15" value="5" class="blaze-slider" id="depth-slider"></div>
            <div class="blaze-row"><span>Child Shift: <span id="prox-val">0</span></span><input type="range" min="-5" max="5" value="0" class="blaze-slider" id="prox-slider"></div>
            <div class="blaze-row"><span>Parent Shift: <span id="vert-val">0</span></span><input type="range" min="-5" max="5" value="0" class="blaze-slider" id="vert-slider"></div>
            <div class="blaze-row" style="margin-top:15px; border-top: 1px solid #f3f4f6; padding-top:10px;">
                <span id="blaze-status-box" class="blaze-status status-ok">READY</span>
                <span style="font-size:11px; font-weight:800;">Matches: <span id="blaze-match-count" style="color:#dc2626">0</span></span>
            </div>
            <textarea id="blaze-selector-output" spellcheck="false" placeholder="Resulting filter..."></textarea>
            <div id="blaze-suggestions"></div>
            <div class="blaze-btn-row">
                <button class="blaze-btn btn-preview" id="blaze-preview">PREVIEW HIDE</button>
                <button class="blaze-btn btn-copy" id="blaze-copy">COPY FILTER</button>
            </div>
            <button class="blaze-btn btn-stop" id="blaze-close">STOP ENGINE</button>
        </div>`;
    document.body.appendChild(ui);

    const launcher=document.createElement('div');
    launcher.id='blaze-launcher';
    launcher.innerText='PICK';
    document.body.appendChild(launcher);

    let btnEnabled=GM_getValue('btnEnabled',true);
    if(!btnEnabled)launcher.style.display='none';

    const makeDraggable=(el,handle)=>{let isDragging=false,sx,sy,ix,iy;const start=(e)=>{if(['INPUT','TEXTAREA','BUTTON'].includes(e.target.tagName))return;isDragging=true;let t=e.touches?e.touches[0]:e;sx=t.clientX;sy=t.clientY;ix=el.offsetLeft;iy=el.offsetTop};const move=(e)=>{if(!isDragging)return;e.preventDefault();let t=e.touches?e.touches[0]:e;el.style.left=`${ix+(t.clientX-sx)}px`;el.style.top=`${iy+(t.clientY-sy)}px`;el.style.bottom='auto';el.style.right='auto'};const end=()=>isDragging=false;handle.addEventListener('touchstart',start,{passive:false});document.addEventListener('touchmove',move,{passive:false});document.addEventListener('touchend',end);handle.addEventListener('mousedown',start);document.addEventListener('mousemove',move);document.addEventListener('mouseup',end)};
    makeDraggable(ui,document.getElementById('blaze-drag-handle'));
    makeDraggable(launcher,launcher);

    const clearHighlights=()=>document.querySelectorAll('.blaze-target, .blaze-auto-match, .blaze-preview-hidden').forEach(el=>el.classList.remove('blaze-target','blaze-auto-match','blaze-preview-hidden'));

    const runLiveMatch=()=>{
        const val=document.getElementById('blaze-selector-output').value,status=document.getElementById('blaze-status-box'),count=document.getElementById('blaze-match-count');
        clearHighlights();
        if(!val.includes('##')&&!val.startsWith('||')){status.innerText="NO RULE";status.className="blaze-status status-err";count.innerText="0";return}
        try{
            const selector=val.includes('##')?val.split('##')[1].trim():null;
            if(!selector){
                if(val.startsWith('||')){status.innerText="NETWORK";count.innerText="-";return}
                else{status.innerText="EMPTY";count.innerText="0";return}
            }
            const matches=document.querySelectorAll(selector);
            count.innerText=matches.length;
            if(matches.length>0){
                status.innerText="MATCHING";status.className="blaze-status status-ok";
                matches.forEach(m=>{
                    if(ui.contains(m)||launcher.contains(m))return;
                    if(previewMode)m.classList.add('blaze-preview-hidden');
                    else m.classList.add('blaze-auto-match')
                });
                if(!previewMode&&currentTarget)currentTarget.classList.add('blaze-target')
            }else{status.innerText="NO MATCH";status.className="blaze-status status-err"}
        }catch(e){status.innerText="BAD SYNTAX";status.className="blaze-status status-err";count.innerText="0"}
    };

    const getSelector=(el,depth)=>{
        if(!el)return"";
        let path=[],curr=el;
        for(let i=0;i<depth;i++){
            if(!curr||curr===document.documentElement||curr===document.body)break;
            let segment=curr.tagName.toLowerCase();
            if(curr.id&&!/\d{5,}/.test(curr.id))segment+=`#${esc(curr.id)}`;
            let classes=Array.from(curr.classList).filter(c=>!c.startsWith('blaze-')).map(c => `.${esc(c)}`).join('');
            if(classes)segment+=classes;
            if(curr.hasAttribute('href'))segment+=`[href="${curr.getAttribute('href')}"]`;
            else if(curr.hasAttribute('src'))segment+=`[src="${curr.getAttribute('src')}"]`;
            path.unshift(segment);
            curr=curr.parentElement
        }
        return path.length>0?`##${path.join(' > ')}`:"";
    };

    const populateSuggestions=(el)=>{
        const box=document.getElementById('blaze-suggestions');
        box.innerHTML='';
        let items=[];
        const add=(lbl,s,targetEl)=>{if(s&&s!=="##"&&!items.find(i=>i.val===s)){if(lbl)items.push({label:lbl});items.push({val:s, el:targetEl})}};

        add("Current Selection",`##${el.tagName.toLowerCase()}${Array.from(el.classList).filter(c=>!c.startsWith('blaze-')).map(c=>`.${esc(c)}`).join('')}`, el);

        let p=el.parentElement;
        if(p&&p!==document.body){
            add("Parent Container", getSelector(p, 1), p);
            add(null, getSelector(p, 2), p);
        }

        let sibs=Array.from(el.parentElement?el.parentElement.children:[]).filter(s=>s!==el&&!['SCRIPT','STYLE'].includes(s.tagName)).slice(0,3);
        if(sibs.length)add("Siblings",null);
        sibs.forEach(s=>{let sSel=getSelector(s,1);if(sSel)add(null,sSel,s)});

        items.forEach(item=>{
            let d=document.createElement('div');
            if(item.label){d.className='suggest-label';d.innerText=item.label}
            else{
                d.innerText=item.val;
                d.onclick=()=>{
                    if(item.el){
                        currentTarget = item.el;
                        baseElement = item.el;
                        verticalOffset = 0;
                        proximityOffset = 0;
                        document.getElementById('prox-slider').value = 0;
                        document.getElementById('vert-slider').value = 0;
                        document.getElementById('prox-val').innerText = 0;
                        document.getElementById('vert-val').innerText = 0;
                    }
                    document.getElementById('blaze-selector-output').value=item.val;
                    runLiveMatch();
                    if(currentTarget)currentTarget.scrollIntoView({behavior:"smooth",block:"center"});
                }
            }
            box.appendChild(d)
        })
    };

    const refreshSelection=()=>{
        if(!baseElement)return;
        let el=baseElement;
        const valid=(n)=>n&&!['SCRIPT','STYLE','NOSCRIPT','IFRAME'].includes(n.tagName);
        let v=verticalOffset,p=proximityOffset;
        if(v>0)for(let i=0;i<v;i++)if(el.parentElement&&el.parentElement!==document.body)el=el.parentElement;
        if(v<0)for(let i=0;i>v;i--){let next=el.nextElementSibling;while(next&&!valid(next))next=next.nextElementSibling;if(next)el=next}
        if(p>0)for(let i=0;i<p;i++){let chi=el.firstElementChild;if(chi&&valid(chi))el=chi}
        if(p<0)for(let i=0;i>p;i--){let prev=el.previousElementSibling;while(prev&&!valid(prev))prev=prev.previousElementSibling;if(prev)el=prev}
        currentTarget=el;
        let mainSel=getSelector(currentTarget,currentDepth);
        document.getElementById('blaze-selector-output').value=mainSel||`##${currentTarget.tagName.toLowerCase()}`;
        populateSuggestions(currentTarget);
        runLiveMatch();
        currentTarget.scrollIntoView({behavior:"smooth",block:"center"})
    };

    document.getElementById('blaze-preview').onclick=function(){previewMode=!previewMode;this.innerText=previewMode?"SHOW ALL":"PREVIEW HIDE";this.classList.toggle('active',previewMode);runLiveMatch()};
    document.getElementById('depth-slider').oninput=(e)=>{currentDepth=e.target.value;document.getElementById('depth-val').innerText=currentDepth;refreshSelection()};
    document.getElementById('prox-slider').oninput=(e)=>{proximityOffset=parseInt(e.target.value);document.getElementById('prox-val').innerText=proximityOffset;refreshSelection()};
    document.getElementById('vert-slider').oninput=(e)=>{verticalOffset=parseInt(e.target.value);document.getElementById('vert-val').innerText=verticalOffset;refreshSelection()};

    const handleAction=(e)=>{
        if(!active||ui.contains(e.target)||launcher.contains(e.target))return;
        e.preventDefault();
        e.stopImmediatePropagation();
        let target=e.target;
        if(['SCRIPT','STYLE','NOSCRIPT'].includes(target.tagName))return;
        baseElement=target;currentTarget=target;proximityOffset=0;verticalOffset=0;
        ['prox-slider','vert-slider'].forEach(id=>document.getElementById(id).value=0);
        ['prox-val','vert-val'].forEach(id=>document.getElementById(id).innerText=0);
        refreshSelection()
    };

    document.getElementById('blaze-copy').onclick=()=>{const area=document.getElementById('blaze-selector-output');area.focus();area.select();document.execCommand('copy');launcher.innerText='COPIED';setTimeout(()=>launcher.innerText=active?'X':'PICK',1000)};
    document.getElementById('blaze-close').onclick=()=>{active=false;previewMode=false;ui.style.display='none';launcher.innerText='PICK';clearHighlights();window.removeEventListener('click',handleAction,true)};
    const togglePicker=()=>{active=!active;ui.style.display=active?'block':'none';launcher.innerText=active?'X':'PICK';if(active)window.addEventListener('click',handleAction,true);else document.getElementById('blaze-close').click()};
    launcher.onclick=togglePicker;
    GM_registerMenuCommand("Toggle Picker Mode",togglePicker);
    GM_registerMenuCommand("Enable/Disable Pick Button",()=>{btnEnabled=!btnEnabled;GM_setValue('btnEnabled',btnEnabled);launcher.style.display=btnEnabled?'flex':'none'})
})();
