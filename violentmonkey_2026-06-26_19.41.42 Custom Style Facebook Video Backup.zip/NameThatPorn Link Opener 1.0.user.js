// ==UserScript==
// @name         NameThatPorn Link Opener 1.0
// @namespace    https://github.com/BlazeFTL
// @description  Automatically opens input values in a new tab if they contain a URL
// @version      1.0
// @author       BlazeFTL
// @match        https://namethatporn.com/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const handleInputClick = (event) => {
        const target = event.target;
        if (target.tagName === 'INPUT' && target.value.startsWith('http')) {
            window.open(target.value, '_blank');
        }
    };

    document.addEventListener('click', handleInputClick);
})();
