// ==UserScript==
// @name         JW Player Custom Forward Backward Button (Stock + Side Hit)
// @namespace    http://tampermonkey.net/
// @version      2.1
// @description  Stock transparent buttons with extended side hit areas, orientation-aware positioning, keyboard shortcuts, and touch improvements
// @match        https://*.mat6tube.com/*
// @match        https://*.noodlemagazine.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function addStyle(css) {
        const style = document.createElement('style');
        style.type = 'text/css';
        style.appendChild(document.createTextNode(css));
        document.head.appendChild(style);
    }

    addStyle(`
        .jwplayer {
            position: relative;
        }

        /* Top-right fullscreen — stock rgba, no blur */
        .jw-top-right-controls {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 20;
            display: flex;
            gap: 8px;
            pointer-events: auto;
            transition: opacity 0.3s ease;
        }

        .jw-top-right-controls button {
            background: rgba(0,0,0,0.5);
            border: none;
            color: white;
            padding: 4px 8px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
            line-height: 1;
            transition: background-color 0.2s ease;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            min-width: 36px;
            min-height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .jw-top-right-controls button:hover {
            background-color: rgba(0,0,0,0.7);
        }

        /* Control bar — stock style */
        .jw-controlbar .jw-button-container {
            display: flex;
            align-items: center;
        }

        .jw-controlbar .custom-control-button {
            background: none;
            border: none;
            color: white;
            padding: 0 4px;
            cursor: pointer;
            font-size: 12px;
            line-height: 1;
            margin-right: 8px;
            display: flex;
            align-items: center;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            transition: color 0.2s ease;
            min-height: 36px;
        }

        .jw-controlbar .custom-control-button:hover {
            color: #aaaaaa;
        }

        .jw-controlbar .jw-icon-playback {
            margin-right: 8px;
        }

        /* Display buttons — STOCK transparent, no blur */
        .jw-display-controls {
            position: relative;
        }

        .jw-display-controls .custom-display-button {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: transparent;
            border: none;
            color: white;
            padding: 12px 24px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 30px;
            z-index: 10;
            transition: background-color 0.2s ease, color 0.2s ease;
            pointer-events: auto !important;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            display: flex;
            align-items: center;
            line-height: 1;
            min-height: 48px;
        }

        .jw-display-controls .custom-display-button:hover {
            background-color: rgba(255,255,255,0.1);
            color: #cccccc;
        }

        /* Portrait: buttons more inside */
        .jw-display-controls .custom-display-button-left {
            left: -60%;
        }

        .jw-display-controls .custom-display-button-right {
            right: -60%;
        }

        /* Invisible side hit areas — extend clickable region outward */
        .jw-display-controls .custom-display-button-left::after,
        .jw-display-controls .custom-display-button-right::after {
            content: '';
            position: absolute;
            top: -16px;
            width: 80px;
            height: calc(100% + 32px);
            background: transparent;
            pointer-events: auto;
            cursor: pointer;
        }

        .jw-display-controls .custom-display-button-left::after {
            left: -80px;
        }

        .jw-display-controls .custom-display-button-right::after {
            right: -80px;
        }

        /* Landscape: buttons more outside + bigger side hit areas */
        @media (orientation: landscape) {
            .jw-display-controls .custom-display-button-left {
                left: -180%;
            }
            .jw-display-controls .custom-display-button-right {
                right: -180%;
            }
            .jw-display-controls .custom-display-button-left::after {
                left: -120px;
                width: 120px;
            }
            .jw-display-controls .custom-display-button-right::after {
                right: -120px;
                width: 120px;
            }
        }

        /* Sync hide/show with JW Player controls */
        .jwplayer.jw-flag-user-inactive .custom-display-button,
        .jwplayer.jw-flag-user-inactive .jw-top-right-controls {
            opacity: 0;
            pointer-events: none !important;
        }

        /* Hide during ads */
        .jwplayer.jw-flag-ads .custom-display-button,
        .jwplayer.jw-flag-ads .custom-control-button,
        .jwplayer.jw-flag-ads .jw-top-right-controls {
            display: none !important;
        }
    `);

    function init() {
        const check = setInterval(() => {
            if (typeof jwplayer !== 'function') return;

            const playerElements = document.querySelectorAll('.jwplayer:not([data-custom-controls="true"])');
            playerElements.forEach(el => {
                if (!el.id) return;
                try {
                    const instance = jwplayer(el.id);
                    if (instance && typeof instance.getState === 'function') {
                        el.setAttribute('data-custom-controls', 'true');
                        enhanceJWPlayer(instance, el);
                    }
                } catch (e) {
                    console.warn('JW enhancement skipped:', el.id, e);
                }
            });

            try {
                const defaultInstance = jwplayer();
                const defaultContainer = defaultInstance && defaultInstance.getContainer ? defaultInstance.getContainer() : null;
                if (defaultContainer && !defaultContainer.hasAttribute('data-custom-controls')) {
                    defaultContainer.setAttribute('data-custom-controls', 'true');
                    enhanceJWPlayer(defaultInstance, defaultContainer);
                }
            } catch (e) {}
        }, 800);
    }

    function enhanceJWPlayer(player, playerContainer) {
        if (!playerContainer) return;
        if (playerContainer.querySelector('.jw-custom-controls-wrapper')) return;

        const observer = new MutationObserver((mutations, obs) => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const displayControls = playerContainer.querySelector('.jw-display-controls');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');

            if (controlBar && displayControls && playButtonContainer) {
                if (!playerContainer.querySelector('.jw-custom-controls-wrapper')) {
                    obs.disconnect();
                    addButtons(player, playButtonContainer, playerContainer, displayControls);
                }
            }
        });

        observer.observe(playerContainer, { childList: true, subtree: true });

        const fallback = setInterval(() => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const displayControls = playerContainer.querySelector('.jw-display-controls');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');

            if (controlBar && displayControls && playButtonContainer) {
                if (!playerContainer.querySelector('.jw-custom-controls-wrapper')) {
                    clearInterval(fallback);
                    observer.disconnect();
                    addButtons(player, playButtonContainer, playerContainer, displayControls);
                }
            }
        }, 1200);
    }

    function addButtons(player, playButtonContainer, playerContainer, displayControlsContainer) {
        const marker = document.createElement('div');
        marker.className = 'jw-custom-controls-wrapper';
        marker.style.display = 'none';
        playerContainer.appendChild(marker);

        const safeSeek = (offset) => {
            try {
                const pos = player.getPosition() || 0;
                const dur = player.getDuration() || 0;
                player.seek(Math.max(0, Math.min(pos + offset, dur)));
            } catch (e) {
                console.warn('Seek failed:', e);
            }
        };

        /* Control Bar Buttons */
        const createControlBtn = (label, onClick) => {
            const btn = document.createElement('button');
            btn.textContent = label;
            btn.className = 'custom-control-button';
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                onClick();
            });
            return btn;
        };

        const rewindBar = createControlBtn('« 10s', () => safeSeek(-10));
        const forwardBar = createControlBtn('10s »', () => safeSeek(10));

        const playPause = playButtonContainer.querySelector('.jw-icon-playback');
        if (playPause) {
            playPause.parentNode.insertBefore(rewindBar, playPause.nextSibling);
            playPause.parentNode.insertBefore(forwardBar, rewindBar.nextSibling);
        } else {
            playButtonContainer.prepend(forwardBar);
            playButtonContainer.prepend(rewindBar);
        }

        /* Display Buttons */
        const createDisplayBtn = (label, className, id) => {
            const btn = document.createElement('button');
            btn.textContent = label;
            btn.className = 'custom-display-button ' + className;
            btn.id = id;
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                safeSeek(className.includes('left') ? -10 : 10);
            });
            return btn;
        };

        const rewindDisplay = createDisplayBtn('« 10s', 'custom-display-button-left', 'jw-custom-display-left');
        const forwardDisplay = createDisplayBtn('10s »', 'custom-display-button-right', 'jw-custom-display-right');

        if (displayControlsContainer) {
            displayControlsContainer.appendChild(rewindDisplay);
            displayControlsContainer.appendChild(forwardDisplay);
        }

        /* Top-Right Fullscreen */
        const topRight = document.createElement('div');
        topRight.className = 'jw-top-right-controls';

        const fsBtn = document.createElement('button');
        fsBtn.innerHTML = '⛶';
        fsBtn.title = 'Toggle Fullscreen';
        fsBtn.setAttribute('aria-label', 'Toggle Fullscreen');

        fsBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            try {
                player.setFullscreen(!player.getFullscreen());
            } catch (err) {}
        });

        player.on('fullscreen', (event) => {
            fsBtn.innerHTML = event.fullscreen ? '⛶̽' : '⛶';
            fsBtn.title = event.fullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen';
        });

        try {
            if (player.getFullscreen()) {
                fsBtn.innerHTML = '⛶̽';
                fsBtn.title = 'Exit Fullscreen';
            }
        } catch (e) {}

        topRight.appendChild(fsBtn);
        playerContainer.appendChild(topRight);

        /* Keyboard Shortcuts */
        const keyHandler = (e) => {
            if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
            const isPlayerFocused = playerContainer.contains(document.activeElement);
            let isFullscreen = false;
            try { isFullscreen = player.getFullscreen(); } catch (e) {}
            if (!isPlayerFocused && !isFullscreen) return;

            e.preventDefault();
            e.stopPropagation();
            safeSeek(e.key === 'ArrowLeft' ? -10 : 10);
        };
        document.addEventListener('keydown', keyHandler);

        /* Cleanup if player removed */
        const cleanup = new MutationObserver(() => {
            if (!document.body.contains(playerContainer)) {
                document.removeEventListener('keydown', keyHandler);
                cleanup.disconnect();
            }
        });
        cleanup.observe(document.body, { childList: true, subtree: true });

        console.log('Custom JW Player controls added (stock look + side hits).');
    }

    init();
})();
