// ==UserScript==
// @name         Background Timer + Audio Keep-Alive (MANUAL / CF-PROOF)
// @namespace    http://tampermonkey.net/
// @version      4.0
// @description  Manual activation only. Absolutely safe with Cloudflare.
// @author       BlazeFTL
// @match        *://*/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=firefox.com
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    if (window.top !== window) return;

    let enabled = false;

    /*********************************************************
     * UI BUTTON
     *********************************************************/
    const btn = document.createElement('button');
    btn.textContent = '▶ BG Fix';
    Object.assign(btn.style, {
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        zIndex: 999999,
        padding: '8px 12px',
        background: '#111',
        color: '#fff',
        border: '1px solid #444',
        borderRadius: '6px',
        cursor: 'pointer',
        fontSize: '13px'
    });
    document.documentElement.appendChild(btn);

    btn.onclick = () => {
        if (enabled) return;
        enabled = true;
        btn.textContent = '✔ BG Active';
        startSilentAudio();
        installWorkerTimers();
        console.log('[BG-FIX] Manually activated');
    };

    /*********************************************************
     * SILENT AUDIO KEEP-ALIVE
     *********************************************************/
    function startSilentAudio() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const src = ctx.createBufferSource();
            src.buffer = ctx.createBuffer(1, 44100, 44100);
            src.loop = true;

            const gain = ctx.createGain();
            gain.gain.value = 0;

            src.connect(gain);
            gain.connect(ctx.destination);

            ctx.resume().then(() => src.start());
        } catch (e) {}
    }

    /*********************************************************
     * WORKER TIMER ENGINE
     *********************************************************/
    function installWorkerTimers() {
        const workerCode = `
            const timers = {};
            self.onmessage = e => {
                const { type, id, delay } = e.data;
                if (type === 'timeout') {
                    setTimeout(() => postMessage(id), delay);
                } else if (type === 'interval') {
                    timers[id] = setInterval(() => postMessage(id), delay);
                } else if (type === 'clear') {
                    clearInterval(timers[id]);
                    delete timers[id];
                }
            };
        `;

        const worker = new Worker(URL.createObjectURL(
            new Blob([workerCode], { type: 'application/javascript' })
        ));

        const callbacks = {};
        let uid = 0;

        worker.onmessage = e => callbacks[e.data]?.();

        window.setTimeout = function (fn, delay = 0) {
            const id = ++uid;
            callbacks[id] = () => {
                fn();
                delete callbacks[id];
            };
            worker.postMessage({ type: 'timeout', id, delay });
            return id;
        };

        window.setInterval = function (fn, delay = 0) {
            const id = ++uid;
            callbacks[id] = fn;
            worker.postMessage({ type: 'interval', id, delay });
            return id;
        };

        window.clearTimeout = window.clearInterval = function (id) {
            worker.postMessage({ type: 'clear', id });
            delete callbacks[id];
        };
    }

})();
