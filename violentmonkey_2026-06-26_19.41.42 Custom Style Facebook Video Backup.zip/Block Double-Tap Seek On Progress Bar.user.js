// ==UserScript==
// @name         Block Double-Tap Seek On Progress Bar
// @namespace    blazeftl
// @version      1.0
// @match        *://eporner.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
  const sel = '[class^="vjs-progress-"], [class*=" vjs-progress-"]';

  function block(e) {
    const t = e.target.closest(sel);
    if (t) {
      e.stopPropagation();
    }
  }

  ['touchstart', 'touchend', 'pointerdown', 'pointerup', 'click'].forEach(type => {
    document.addEventListener(type, block, true);
  });
})();
