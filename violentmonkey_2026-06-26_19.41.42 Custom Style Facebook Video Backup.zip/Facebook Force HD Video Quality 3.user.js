// ==UserScript==
// @name         Facebook Force HD Video Quality 3
// @namespace    https://github.com/BlazeFTL
// @description  Forces Facebook videos and reels to play in maximum quality on scroll by filtering out low-resolution streaming representations from DASH manifests dynamically.
// @version      1.2
// @author       BlazeFTL
// @match        *://*.facebook.com/*
// @run-at       document-start
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    // Helper to parse and filter out low quality streams from the dynamic DASH manifest
    function filterManifest(manifestStr) {
        try {
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(manifestStr, "text/xml");
            const reps = Array.from(xmlDoc.getElementsByTagName("Representation"));

            if (reps.length === 0) return manifestStr;

            // Isolate video streams that contain resolution parameters
            const videoReps = reps.filter(rep => rep.hasAttribute("height") || rep.hasAttribute("width"));
            if (videoReps.length === 0) return manifestStr;

            // Determine the maximum available height in the manifest payload
            const maxHeight = Math.max(...videoReps.map(rep => parseInt(rep.getAttribute("height") || "0", 10)));

            // Strip any representations that don't match the maximum detected resolution
            videoReps.forEach(rep => {
                const currentHeight = parseInt(rep.getAttribute("height") || "0", 10);
                if (currentHeight < maxHeight) {
                    rep.parentNode.removeChild(rep);
                }
            });

            const serializer = new XMLSerializer();
            return serializer.serializeToString(xmlDoc);
        } catch (e) {
            return manifestStr;
        }
    }

    // Traverse network objects to identify and overwrite manifest keys
    function traverseAndModify(obj) {
        if (!obj || typeof obj !== 'object') return;
        for (const key in obj) {
            if (key === 'dash_manifest' && typeof obj[key] === 'string') {
                obj[key] = filterManifest(obj[key]);
            } else if (typeof obj[key] === 'object') {
                traverseAndModify(obj[key]);
            }
        }
    }

    // Process GraphQL response strings and chunk streams
    function modifyPayload(text) {
        if (!text || !text.includes('dash_manifest')) return text;

        try {
            if (text.trim().startsWith('{')) {
                const obj = JSON.parse(text);
                traverseAndModify(obj);
                return JSON.stringify(obj);
            }
        } catch (e) {}

        // Fallback regex pattern processing for chunked/streamed JSON segments
        return text.replace(/"dash_manifest"\s*:\s*"([^"\\]*(?:\\.[^"\\]*)*)"/g, (match, p1) => {
            try {
                const unescaped = JSON.parse('"' + p1 + '"');
                const filtered = filterManifest(unescaped);
                const reEscaped = JSON.stringify(filtered).slice(1, -1);
                return `"dash_manifest":"${reEscaped}"`;
            } catch (e) {
                return match;
            }
        });
    }

    // Intercept native Fetch layer
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        const response = await originalFetch.apply(this, args);
        if (args[0] && (args[0].includes('/api/graphql/') || args[0].includes('graphql'))) {
            const cloned = response.clone();
            try {
                const text = await cloned.text();
                if (text.includes('dash_manifest')) {
                    const modifiedText = modifyPayload(text);
                    return new Response(modifiedText, {
                        status: response.status,
                        statusText: response.statusText,
                        headers: response.headers
                    });
                }
            } catch (e) {}
        }
        return response;
    };

    // Intercept standard XMLHttpRequest properties via dynamic getters
    const xhrTextDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'responseText');
    if (xhrTextDesc && xhrTextDesc.get) {
        Object.defineProperty(XMLHttpRequest.prototype, 'responseText', {
            get: function() {
                const text = xhrTextDesc.get.apply(this);
                if (text && text.includes('dash_manifest')) {
                    if (this._hdrModText) return this._hdrModText;
                    this._hdrModText = modifyPayload(text);
                    return this._hdrModText;
                }
                return text;
            },
            configurable: true
        });
    }

    const xhrRespDesc = Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype, 'response');
    if (xhrRespDesc && xhrRespDesc.get) {
        Object.defineProperty(XMLHttpRequest.prototype, 'response', {
            get: function() {
                const resp = xhrRespDesc.get.apply(this);
                if (typeof resp === 'string' && resp.includes('dash_manifest')) {
                    if (this._hdrModResp) return this._hdrModResp;
                    this._hdrModResp = modifyPayload(resp);
                    return this._hdrModResp;
                }
                return resp;
            },
            configurable: true
        });
    }

    // Network Information Configuration Spoofing
    const networkProps = { effectiveType: '4g', downlink: 100, rtt: 5, saveData: false };
    const spoofNetwork = (obj) => {
        if (!obj) return;
        for (const prop in networkProps) {
            try {
                Object.defineProperty(obj, prop, {
                    get: () => networkProps[prop],
                    configurable: true,
                    enumerable: true
                });
            } catch (e) {}
        }
    };
    if (navigator.connection) spoofNetwork(navigator.connection);
    if (window.NetworkInformation && window.NetworkInformation.prototype) spoofNetwork(window.NetworkInformation.prototype);

    // Global Key-Value Client Configuration Enforcement
    const enforceHDStorage = () => {
        try {
            localStorage.setItem('video_quality_setting', 'hd');
            localStorage.setItem('hb_video_quality', 'hd');
            localStorage.setItem('video_bandwidth_estimate', '50000000');
        } catch (e) {}
    };
    enforceHDStorage();

    try {
        const rawSetItem = Storage.prototype.setItem;
        Storage.prototype.setItem = function(key, value) {
            if (key.includes('video_quality') || key.includes('bandwidth')) {
                value = key.includes('estimate') ? '50000000' : 'hd';
            }
            rawSetItem.apply(this, [key, value]);
        };
    } catch (e) {}
})();
