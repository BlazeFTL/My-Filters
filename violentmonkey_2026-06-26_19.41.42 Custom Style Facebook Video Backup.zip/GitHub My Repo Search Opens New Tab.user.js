// ==UserScript==
// @name         GitHub My Repo Search Opens New Tab
// @namespace    https://github.com/BlazeFTL
// @description  Opens search in new tab and clicks the dark backdrop to close the overlay.
// @version      1.0
// @author       BlazeFTL
// @match        https://github.com/BlazeFTL/My-Filters*
// @icon         https://avatars.githubusercontent.com/u/139938337?v=4&size=64
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.addEventListener('keydown', function(e) {
        if (e.target.id === 'query-builder-test' && e.key === 'Enter') {
            const query = e.target.value.trim();

            if (query) {
                e.preventDefault();
                e.stopImmediatePropagation();

                // 1. Open search in new tab
                const searchUrl = `https://github.com/BlazeFTL/My-Filters/search?q=${encodeURIComponent(query)}`;
                window.open(searchUrl, '_blank');

                // 2. Click the backdrop to close the search UI
                // Targeted via the data-action attribute from your screenshot
                const backdrop = document.querySelector('div[data-action="click:qbsearch-input#retract"]');

                if (backdrop) {
                    backdrop.click();
                } else {
                    // Fallback to blur if backdrop isn't found
                    e.target.blur();
                }
            }
        }
    }, true);
})();
