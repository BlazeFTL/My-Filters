// ==UserScript==
// @name         GitHub Dedicated Delete Button (Icon)
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Adds a trash icon delete button next to the 3-dot menu
// @author       You
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @match        https://github.com/*

// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // GitHub's trash icon SVG
    // Custom trash icon SVG (similar to Flaticon style)
const trashIcon = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="16" height="16">
    <polyline points="3 6 5 6 21 6"></polyline>
    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
    <line x1="10" y1="11" x2="10" y2="17"></line>
    <line x1="14" y1="11" x2="14" y2="17"></line>
</svg>`;

    function createDeleteButton() {
        const pathParts = window.location.pathname.split('/').filter(p => p);
        const owner = pathParts[0];
        const repo = pathParts[1];
        const type = pathParts[2];
        const typeId = pathParts[3];

        if (!owner || !repo || !type || !typeId) return;

        const menuToggles = document.querySelectorAll('button[aria-haspopup="true"][id^="Comment-actions"]');

        menuToggles.forEach(toggleBtn => {
            if (toggleBtn.parentElement.querySelector('.gh-standalone-delete')) return;

            const idMatch = toggleBtn.id.match(/Comment-actions-(\d+)-text/);
            if (!idMatch) return;

            const commentId = idMatch[1];
            const deleteUrl = `/${owner}/${repo}/${type}/${typeId}/comments/${commentId}/delete_content_modal`;

            // Create a wrapper div for better alignment
            const wrapper = document.createElement('span');
            wrapper.className = 'gh-standalone-delete';

            const newBtn = document.createElement('button');
            newBtn.type = 'button';
            newBtn.classList.add('Button--secondary', 'Button--iconOnly', 'Button--medium');
            newBtn.innerHTML = trashIcon;
            newBtn.title = 'Delete comment';
                        newBtn.setAttribute('data-action', 'click:comment-actions-container#displayDialog');
            newBtn.setAttribute('data-dialog-id', `dialog-delete-comment-${commentId}`);
            newBtn.setAttribute('data-title', 'Delete comment');
            newBtn.setAttribute('data-src', deleteUrl);
            newBtn.setAttribute('data-size', 'small');

            // Match GitHub's button styling exactly
            Object.assign(newBtn.style, {
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: '4px',
                marginLeft: '4px',
                color: '#cf222e',
                display: 'inline-flex',
                alignItems: 'center',
                justifyContent: 'center',
                borderRadius: '6px',
                transition: 'background-color 0.2s ease'
            });

            // Hover effects
            newBtn.addEventListener('mouseenter', () => {
                newBtn.style.backgroundColor = '#ffebe9';
                newBtn.style.color = '#a40e26';
            });
            newBtn.addEventListener('mouseleave', () => {
                newBtn.style.backgroundColor = 'transparent';
                newBtn.style.color = '#cf222e';
            });

            // Active/click effect
            newBtn.addEventListener('mousedown', () => {
                newBtn.style.backgroundColor = '#ff818266';
            });
            newBtn.addEventListener('mouseup', () => {
                newBtn.style.backgroundColor = '#ffebe9';
            });

            wrapper.appendChild(newBtn);
            toggleBtn.parentNode.insertBefore(wrapper, toggleBtn.nextSibling);
        });
    }

    createDeleteButton();

    const observer = new MutationObserver(() => {
        createDeleteButton();
    });
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();