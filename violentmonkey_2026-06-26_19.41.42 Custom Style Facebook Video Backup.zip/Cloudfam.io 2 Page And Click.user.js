// ==UserScript==
// @name         Cloudfam.io 2 Page And Click
// @namespace    https://github.com/BlazeFTL
// @description  Direct jump from redirection0 to step=2 and auto-click download
// @version      1.8
// @author       BlazeFTL
// @match        https://cloudfam.io/redirection0.php?slug=*
// @match        https://cloudfam.io/*?*step=2*
// @license      MIT
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const url = window.location.href;
    const urlParams = new URLSearchParams(window.location.search);
    const slug = urlParams.get('slug') || url.split('/').pop().split('?')[0].split('&')[0];
    const token = urlParams.get('token');

    // --- THE JUMP: From redirection0 directly to step=2 ---
    if (url.includes('redirection0.php') && slug && token) {
        const finalUrl = `https://cloudfam.io/${slug}?step=2&token=${token}`;
        window.location.replace(finalUrl);
        return;
    }

    // --- THE CLICK: On the final page ---
    if (url.includes('step=2')) {
        const tryClick = () => {
            const btn = document.querySelector('#cf-dl-btn');
            if (btn) {
                btn.click();
                console.log('Jump successful! Download button clicked.');
                clearInterval(clicker);
            }
        };

        // Rapid check every 50ms since we want this fast
        const clicker = setInterval(tryClick, 50);

        // Stop checking after 8 seconds
        setTimeout(() => clearInterval(clicker), 8000);
    }
})();

