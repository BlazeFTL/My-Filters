// ==UserScript==
// @name         GitHub Load More Button In Mobile Header
// @namespace    https://github.com/BlazeFTL
// @description  Performance-optimized mobile mirror with throttled updates.
// @version      3.0
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let isUpdating = false;

    const getSyncIcon = () => `
        <svg aria-hidden="true" height="14" viewBox="0 0 16 16" width="14" class="octicon octicon-sync mr-1" style="fill: var(--color-accent-fg);">
            <path d="M1.705 8.005a.75.75 0 0 1 .834.656 5.5 5.5 0 0 0 9.592 2.97l-1.204-1.204a.25.25 0 0 1 .177-.427h3.646a.25.25 0 0 1 .25.25v3.646a.25.25 0 0 1-.427.177l-1.38-1.38A7.002 7.002 0 0 1 1.05 8.84a.75.75 0 0 1 .656-.834ZM8 2.5a5.487 5.487 0 0 0-4.131 1.869l1.204 1.204A.25.25 0 0 1 4.896 6H1.25A.25.25 0 0 1 1 5.75V2.104a.25.25 0 0 1 .427-.177l1.38 1.38A7.002 7.002 0 0 1 14.95 7.16a.75.75 0 0 1-1.49.178A5.5 5.5 0 0 0 8 2.5Z"></path>
        </svg>
    `;

    const updateMobileMirror = () => {
        if (isUpdating) return;
        isUpdating = true;

        const realBtn = document.querySelector('.ajax-pagination-btn');
        const targetHeader = document.querySelector('.sticky-header-container .min-width-0');

        if (!realBtn || !targetHeader) {
            const oldMirror = document.querySelector('.custom-mobile-mirror-btn');
            if (oldMirror) oldMirror.remove();
            isUpdating = false;
            return;
        }

        let mirrorBtn = document.querySelector('.custom-mobile-mirror-btn');

        if (!mirrorBtn) {
            mirrorBtn = document.createElement('button');
            mirrorBtn.type = 'button';
            mirrorBtn.className = 'custom-mobile-mirror-btn btn-link Link--primary no-underline text-bold';
            mirrorBtn.style.cssText = 'font-size: 11px; margin-left: 8px; display: inline-flex; align-items: center; border: 1px solid var(--color-border-muted); padding: 2px 6px; border-radius: 6px; background: var(--color-canvas-subtle); white-space: nowrap; transition: opacity 0.2s;';

            mirrorBtn.onclick = (e) => {
                e.preventDefault();
                e.stopPropagation();
                const freshBtn = document.querySelector('.ajax-pagination-btn');
                if (freshBtn && !freshBtn.disabled) {
                    // Directly submit the parent form - most reliable for mobile AJAX
                    const form = freshBtn.closest('form');
                    if (form) form.requestSubmit ? form.requestSubmit() : freshBtn.click();
                }
            };
            targetHeader.appendChild(mirrorBtn);
        }

        // Only update HTML if content actually changed to save performance
        const countEl = document.querySelector('.ajax-pagination-form .color-fg-muted, .ajax-pagination-form button:first-child');
        const countText = countEl ? countEl.innerText.trim().replace('hidden items', 'items') : "Load more";

        if (mirrorBtn.getAttribute('data-last-text') !== countText) {
            mirrorBtn.innerHTML = getSyncIcon() + `<span>${countText}</span>`;
            mirrorBtn.setAttribute('data-last-text', countText);
        }

        // Sync visual loading state
        if (realBtn.disabled || realBtn.innerText.includes('Loading')) {
            mirrorBtn.style.opacity = '0.4';
            mirrorBtn.querySelector('span').innerText = "Loading...";
        } else {
            mirrorBtn.style.opacity = '1';
        }

        isUpdating = false;
    };

    // PERFORMANCE FIX: Throttle the observer to run at most once every 500ms
    let throttleTimeout;
    const observer = new MutationObserver(() => {
        if (!throttleTimeout) {
            throttleTimeout = setTimeout(() => {
                updateMobileMirror();
                throttleTimeout = null;
            }, 500);
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
    updateMobileMirror();
})();
