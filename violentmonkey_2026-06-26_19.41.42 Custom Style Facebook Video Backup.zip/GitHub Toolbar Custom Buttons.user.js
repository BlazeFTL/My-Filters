// ==UserScript==
// @name         GitHub Toolbar Custom Buttons
// @namespace    github.com/BlazeFTL
// @version      1.1
// @description  Adds Details, Adblock & inline-code buttons above GitHub markdown editors
// @match        https://github.com/*
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const STYLE_ID = 'mb-style';
  function injectStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = `
      .mb-row {
        display: flex;
        justify-content: flex-end;
        gap: 5px;
        padding: 4px 8px;
        border-bottom: 1px solid var(--borderColor-default, #d0d7de);
      }
      .mb-btn {
        font: 11px/1.4 ui-monospace, "SFMono-Regular", "SF Mono", Menlo, monospace;
        padding: 3px 7px;
        border: 1px solid var(--borderColor-default, #d0d7de);
        border-radius: 6px;
        background: transparent;
        cursor: pointer;
        color: var(--fgColor-muted, #656d76);
        transition: background 80ms, color 80ms;
        user-select: none;
      }
      .mb-btn:hover {
        background: var(--bgColor-neutral-muted, rgba(175,184,193,0.2));
        color: var(--fgColor-default, #1f2328);
      }
      .mb-btn:active {
        background: var(--bgColor-neutral-muted, rgba(175,184,193,0.35));
      }
    `;
    document.head.appendChild(s);
  }

  function getTextarea(toolbar) {
    const id = toolbar.getAttribute('for');
    return (id && document.getElementById(id)) ||
      toolbar.closest('form,[class*="MarkdownEditor"],[class*="CommentBox"]')?.querySelector('textarea');
  }

  function insertSnippet(textarea, before, after) {
    if (!textarea) return;
    textarea.focus();
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const sel = textarea.value.substring(start, end);
    const full = before + sel + after;
    if (!document.execCommand('insertText', false, full)) {
      textarea.setRangeText(full, start, end, 'end');
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
    }
    if (start === end) {
      const pos = start + before.length;
      textarea.setSelectionRange(pos, pos);
    }
  }

  function makeBtn(label, title, before, after, textarea) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'mb-btn';
    btn.textContent = label;
    btn.title = title;
    btn.addEventListener('mousedown', e => e.preventDefault());
    btn.addEventListener('click', () => insertSnippet(textarea, before, after));
    return btn;
  }

  function addButtonsTo(toolbar) {
    if (toolbar.dataset.mbAdded) return;
    toolbar.dataset.mbAdded = '1';
    injectStyle();

    const textarea = getTextarea(toolbar);
    const header = toolbar.parentElement;
    const container = header?.parentElement;
    if (!container) return;

    const row = document.createElement('div');
    row.className = 'mb-row';

    row.append(
      makeBtn('📝Details',  'Wrap in <details> block',        '<details><summary>Details</summary>\n<p>\n\n', '\n\n</p>\n</details>', textarea),
      makeBtn('🛡️CodeBlock', 'Wrap in adblock-filter-list fence', '```adblock-filter-list\n',   '\n```',                     textarea),
      makeBtn('`Code`',        'Inline code',                   '`',                              '`',                         textarea),
    );

    container.insertBefore(row, header);
  }

  function scan(root) {
    (root || document).querySelectorAll('markdown-toolbar').forEach(addButtonsTo);
  }

  new MutationObserver(muts => {
    for (const { addedNodes } of muts)
      for (const n of addedNodes) {
        if (n.nodeType !== 1) continue;
        if (n.tagName === 'MARKDOWN-TOOLBAR') addButtonsTo(n);
        else n.querySelectorAll?.('markdown-toolbar').forEach(addButtonsTo);
      }
  }).observe(document.body, { childList: true, subtree: true });

  scan();
})();
