// ==UserScript==
// @name         ShrtsSlug.biz Auto Click
// @namespace    https://github.com/BlazeFTL
// @description  Immediate click for Start/Open, followed by Captcha and Delayed steps
// @version      5.0
// @author       BlazeFTL
// @match        ://stfly.me/
// @match        ://dailyjobposting.xyz/
// @match        ://biovetro.net/
// @match        ://yrtourguide.com/
// @match        ://technons.com/
// @match        ://tournguide.com/
// @match        ://digiztechno.com/
// @match        ://shrtslug.biz/
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1. Define the buttons that start the process (Immediate)
    const firstStepKeywords = ["start", "begin", "open", "click here to proceed"];
    // 2. Define the buttons that follow the captcha (Delayed)
    const followUpKeywords = ["click here", "get to next step", "scroll to continue", "continue"];

    function getElementByXpath(path) {
        return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    }

    function isVisible(el) {
        if (!el) return false;
        const style = window.getComputedStyle(el);
        return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length) &&
               style.display !== 'none' &&
               style.visibility !== 'hidden' &&
               style.opacity !== "0";
    }

    function isVerified() {
        // Your specific XPath for verified status
        const verifiedUI = getElementByXpath("//div[contains(@class, 'iconcaptcha-modal__body-title') and normalize-space(text())='Verification complete.'] | //*[@id='captcha-result' and normalize-space()='Verified!']");
        if (verifiedUI) return true;

        // Cloudflare / Turnstile Check
        try {
            const captcha = window.turnstile || window.hcaptcha || window.grecaptcha;
            if (captcha && typeof captcha.getResponse === 'function' && captcha.getResponse()) return true;
        } catch (e) {}

        // If no captcha exists on the page at all, we are "verified" to click
        const captchaBox = document.querySelector('.cf-turnstile, #captcha, .h-captcha, .g-recaptcha, iframe[src*="cloudflare"]');
        return !captchaBox;
    }

    const processPage = () => {
        const buttons = document.querySelectorAll('button, a.btn, input[type="submit"]');

        buttons.forEach(btn => {
            const text = (btn.innerText || btn.value || "").toLowerCase().trim();
            const id = (btn.id || "").toLowerCase();

            if (!isVisible(btn) || btn.disabled) return;

            // --- CATEGORY 1: THE START BUTTON (Immediate) ---
            // Matches text like "Start", "Open" OR IDs ending in "_start"
            if (firstStepKeywords.some(k => text === k) || id.endsWith('_start')) {
                if (btn.dataset.clicked !== "true") {
                    btn.click();
                    btn.dataset.clicked = "true";
                    console.log("Immediate click on Start/Open button");
                }
                return;
            }

            // --- CATEGORY 2: THE FOLLOW-UP BUTTONS (Delayed) ---
            // Only clicks if verification is done and uses 1-2s delay
            const isFollowUp = followUpKeywords.some(k => text.includes(k)) || /^[a-f0-9]{32}/.test(id);

            if (isFollowUp && isVerified()) {
                if (btn.dataset.clicked === "true") return;
                btn.dataset.clicked = "true";

                const randomDelay = Math.floor(Math.random() * 1000) + 1200; // 1.2 to 2.2 seconds
                console.log(`Verified. Clicking follow-up in ${randomDelay}ms`);

                setTimeout(() => {
                    if (!btn.disabled && isVisible(btn)) {
                        btn.click();
                    } else {
                        btn.dataset.clicked = "false";
                    }
                }, randomDelay);
            }
        });
    };

    // Rapid check for the "Start" button, then standard checks
    setInterval(processPage, 800);
    processPage();

})();
