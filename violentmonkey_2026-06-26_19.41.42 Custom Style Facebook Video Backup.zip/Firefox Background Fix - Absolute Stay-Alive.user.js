// ==UserScript==
// @name         Firefox Background Fix - Absolute Stay-Alive
// @namespace    http://tampermonkey.net/
// @version      4.0
// @description  Spoofs Visibility API + Heartbeat to prevent background throttling
// @author       BlazeFTL
// @match        *://*/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=firefox.com
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // --- 1. VISIBILITY SPOOFING ---
    // This stops the page from knowing you switched tabs
    const blockProperty = (obj, prop, value) => {
        Object.defineProperty(obj, prop, {
            get: () => value,
            set: () => {},
            configurable: true
        });
    };

    blockProperty(document, 'visibilityState', 'visible');
    blockProperty(document, 'hidden', false);

    // Stop visibility change events from reaching the site's listeners
    window.addEventListener('visibilitychange', (e) => e.stopImmediatePropagation(), true);
    window.addEventListener('webkitvisibilitychange', (e) => e.stopImmediatePropagation(), true);
    window.addEventListener('mozvisibilitychange', (e) => e.stopImmediatePropagation(), true);

    // --- 2. FOCUS SPOOFING ---
    // Some sites check 'hasFocus' before sending XHR
    blockProperty(document, 'hasFocus', () => true);

    // --- 3. AUDIO HEARTBEAT ---
    function startAudio() {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const init = () => {
            ctx.resume().then(() => {
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                gain.gain.value = 0.001;
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start();
                console.log("Audio Engine Locked On");
                window.removeEventListener('touchstart', init);
                window.removeEventListener('click', init);
            });
        };
        window.addEventListener('touchstart', init);
        window.addEventListener('click', init);
    }

    // --- 4. NON-INVASIVE WORKER PULSE ---
    const workerCode = `setInterval(() => self.postMessage('pulse'), 1000);`;
    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const worker = new Worker(URL.createObjectURL(blob));

    // This keeps the CPU priority for this tab higher
    worker.onmessage = () => {
        const dummy = document.getElementById('keep-alive-status');
        if(dummy) dummy.textContent = Date.now();
    };

    startAudio();
    console.log("Absolute Stay-Alive Active.");
})();

