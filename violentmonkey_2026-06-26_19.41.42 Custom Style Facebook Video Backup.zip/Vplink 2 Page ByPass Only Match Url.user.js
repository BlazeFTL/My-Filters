// ==UserScript==
// @name         Vplink 2 Page ByPass Only Match Url
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Zero-Config: Logic is pulled directly from @match lines
// @author       BlazeFTL
// @match        https://newsfront.xyz/studyhotels/?smartcation=*
// @match        https://sarkarijobcorner.com/educatestudy/estudypost/?eduonline=*
// @match        https://sarkarijobcorner.com/*
// @run-at       document-start
// @grant        none
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    // ================= CONFIGURATION AREA =================
    const CONFIG = {
        finalDomain: 'vplink.in',
        timer: 20
    };
    // ======================================================

    const url = window.location.href;
    const params = new URLSearchParams(window.location.search);

    // Pull the @match lines from the script's header
    const matches = Array.isArray(GM_info.script.matches) ? GM_info.script.matches : [];

    // Stage 1: The first @match line (Source)
    const sourcePattern = matches[0] || '';
    // Stage 2: The second @match line (Intermediate)
    const interPattern = matches[1] || '';

    // Helper to get domain and param from a match pattern
    const parsePattern = (pattern) => {
        try {
            const clean = pattern.replace(/\*/g, '').replace('https://', '');
            const domain = clean.split('/')[0];
            const param = clean.split('?')[1]?.replace('=', '') || '';
            const fullPath = clean;
            return { domain, param, fullPath };
        } catch (e) { return { domain: '', param: '', fullPath: '' }; }
    };

    const source = parsePattern(sourcePattern);
    const inter = parsePattern(interPattern);

    // --- STAGE 1: SOURCE REDIRECT ---
    if (url.includes(source.domain) && params.has(source.param)) {
        const id = params.get(source.param);
        window.stop();
        // Construct the next URL using the second match line's structure
        const nextUrl = `https://${inter.fullPath}${id}`;
        window.location.replace(nextUrl);
        return;
    }

    // --- STAGE 2: INTERMEDIATE CAPTURE & UI ---
    if (url.includes(inter.domain)) {

        // Capture logic
        if (params.has(inter.param)) {
            localStorage.setItem("blaze_final_id", params.get(inter.param));
            return;
        }

        const savedId = localStorage.getItem("blaze_final_id");

        // UI logic (Only if we aren't currently on the capture URL)
        if (savedId && !params.has(inter.param)) {
            const startUI = () => {
                if (document.getElementById('blaze-guard')) return;

                const shield = document.createElement('div');
                shield.id = 'blaze-guard';
                shield.style.cssText = `
                    position: fixed !important; top: 0; left: 0; width: 100%; height: 100%;
                    background: #000 !important; z-index: 2147483647 !important;
                    display: flex; align-items: center; justify-content: center;
                    font-family: sans-serif; color: white; text-align: center;
                `;

                shield.innerHTML = `
                    <div style="border: 2px solid #e74c3c; padding: 40px; border-radius: 20px; background: #111;">
                        <h2 style="color: #e74c3c; margin: 0;">LINK VERIFICATION</h2>
                        <div id="big-timer" style="font-size: 100px; font-weight: bold; margin: 10px 0;">${CONFIG.timer}</div>
                        <p style="color: #666;">You will be redirected to ${CONFIG.finalDomain} within ${CONFIG.timer} seconds</p>
                    </div>
                `;

                (document.body || document.documentElement).appendChild(shield);

                let timeLeft = CONFIG.timer;
                const ticker = setInterval(() => {
                    timeLeft--;
                    const display = document.getElementById('big-timer');
                    if (display) display.innerText = timeLeft;

                    if (timeLeft <= 0) {
                        clearInterval(ticker);
                        localStorage.removeItem("blaze_final_id");
                        window.location.href = `https://${CONFIG.finalDomain}/` + savedId;
                    }
                }, 1000);
            };

            if (document.documentElement) startUI();
            const obs = new MutationObserver(() => {
                if (!document.getElementById('blaze-guard')) startUI();
            });
            obs.observe(document.documentElement, { childList: true, subtree: true });
        }
    }
})();

