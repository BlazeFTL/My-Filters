// ==UserScript==
// @name         GitHub Load More Follower
// @namespace    https://github.com/BlazeFTL
// @description  Hard-follows the "Load more" button (Supports PC & Mobile Mirror).
// @version      1.0
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.addEventListener('click', (e) => {
        // Added .custom-mobile-mirror-btn to the selector
        const btn = e.target.closest('.ajax-pagination-btn, .custom-mirror-btn, .custom-mobile-mirror-btn');
        if (!btn) return;

        let checks = 0;
        const followInterval = setInterval(() => {
            const newBtn = document.querySelector('.ajax-pagination-btn');

            if (newBtn) {
                newBtn.scrollIntoView({ behavior: 'auto', block: 'center' });
            }

            checks++;
            if (checks > 60) clearInterval(followInterval);
        }, 50);

    }, true);
})();
