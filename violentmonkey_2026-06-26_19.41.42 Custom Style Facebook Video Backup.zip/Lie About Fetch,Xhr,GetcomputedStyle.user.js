// ==UserScript==
// @name         Lie About Fetch,Xhr,GetcomputedStyle
// @namespace    https://github.com/BlazeFTL
// @description  Lies about Fetch, XHR, ComputedStyles, and mutes detection promises.
// @version      1.2
// @author       BlazeFTL
// @match        *://*/*
// @license      MIT
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const t = { Reflect: Reflect, Proxy: Proxy, getPropertyValue: CSSStyleDeclaration.prototype.getPropertyValue };

    // 1. Universal Fetch/XHR Lie
    window.fetch = new t.Proxy(window.fetch, {
        apply: async (target, thisArg, args) => {
            try {
                const res = await t.Reflect.apply(target, thisArg, args);
                return new t.Proxy(res, {
                    get: (obj, prop) => (prop === 'status' ? 200 : prop === 'ok' ? true : t.Reflect.get(obj, prop))
                });
            } catch (e) {
                return new Response("", { status: 200, statusText: "OK" });
            }
        }
    });

    // 2. Style Lie (Anti-Hidden Detection)
    window.getComputedStyle = new t.Proxy(window.getComputedStyle, {
        apply: (target, thisArg, args) => {
            const style = t.Reflect.apply(target, thisArg, args);
            return new t.Proxy(style, {
                get: (obj, prop) => {
                    const val = t.Reflect.get(obj, prop);
                    if (prop === 'display' && val === 'none') return 'block';
                    if (prop === 'visibility' && val === 'hidden') return 'visible';
                    return val;
                }
            });
        }
    });

    // 3. Promise Callback Neutralizer
    const checkRegex = /adblock|detect|abnormality|check|blocker/i;
    window.Promise.prototype.then = new t.Proxy(window.Promise.prototype.then, {
        apply: (target, thisArg, args) => {
            if (typeof args[0] === 'function' && checkRegex.test(args[0].toString())) {
                args[0] = () => { console.log("BlazeFTL: Neutralized detection promise."); };
            }
            return t.Reflect.apply(target, thisArg, args);
        }
    });
})();

