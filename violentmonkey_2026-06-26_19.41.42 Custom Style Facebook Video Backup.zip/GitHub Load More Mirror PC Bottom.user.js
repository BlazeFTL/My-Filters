// ==UserScript==
// @name         GitHub Load More Mirror PC Bottom
// @namespace    https://github.com/BlazeFTL
// @description  Full sidebar mirror including the "hidden items" count and sync icon.
// @version      1.0
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const getSyncIcon = () => `
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-sync mr-2">
            <path d="M1.705 8.005a.75.75 0 0 1 .834.656 5.5 5.5 0 0 0 9.592 2.97l-1.204-1.204a.25.25 0 0 1 .177-.427h3.646a.25.25 0 0 1 .25.25v3.646a.25.25 0 0 1-.427.177l-1.38-1.38A7.002 7.002 0 0 1 1.05 8.84a.75.75 0 0 1 .656-.834ZM8 2.5a5.487 5.487 0 0 0-4.131 1.869l1.204 1.204A.25.25 0 0 1 4.896 6H1.25A.25.25 0 0 1 1 5.75V2.104a.25.25 0 0 1 .427-.177l1.38 1.38A7.002 7.002 0 0 1 14.95 7.16a.75.75 0 0 1-1.49.178A5.5 5.5 0 0 0 8 2.5Z"></path>
        </svg>
    `;

    const getHiddenCount = () => {
        // Looks for the "X hidden items" text usually found right above the Load More button
        const countEl = document.querySelector('.ajax-pagination-form .color-fg-muted, .ajax-pagination-form button:first-child');
        return countEl ? countEl.innerText.trim() : "";
    };

    const updateMirror = () => {
        const realBtn = document.querySelector('.ajax-pagination-btn');
        const targetAnchor = document.querySelector('#dialog-show-delete-discussion');

        if (!realBtn || !targetAnchor) return;

        let wrapper = document.querySelector('.custom-sidebar-mirror-item');

        if (!wrapper) {
            const parentLi = targetAnchor.closest('li');
            if (!parentLi) return;

            wrapper = document.createElement('li');
            wrapper.className = 'discussion-sidebar-item custom-sidebar-mirror-item';
            wrapper.style.cssText = 'border-top: 1px solid var(--color-border-muted); padding-top: 8px; margin-top: 8px; list-style: none;';

            const mirrorBtn = document.createElement('button');
            mirrorBtn.type = 'button';
            mirrorBtn.className = 'custom-mirror-btn btn-link Link--primary no-underline text-bold f6 d-flex flex-items-center width-full text-left py-1';
            mirrorBtn.style.cursor = 'pointer';

            mirrorBtn.onclick = () => {
                const freshRealBtn = document.querySelector('.ajax-pagination-btn');
                if (freshRealBtn) freshRealBtn.click();
            };

            wrapper.appendChild(mirrorBtn);
            parentLi.after(wrapper);
        }

        const mirrorBtn = wrapper.querySelector('.custom-mirror-btn');
        if (mirrorBtn && realBtn) {
            const countText = getHiddenCount();
            const actionText = realBtn.innerText.trim();

            // Combine them: e.g., "184 hidden items - Load more..."
            const fullText = countText ? `${countText} (${actionText})` : actionText;

            if (mirrorBtn.getAttribute('data-last-text') !== fullText) {
                mirrorBtn.innerHTML = getSyncIcon() + `<span>${fullText}</span>`;
                mirrorBtn.setAttribute('data-last-text', fullText);
            }

            // Handle loading state
            if (realBtn.disabled) {
                mirrorBtn.setAttribute('disabled', 'disabled');
                mirrorBtn.style.opacity = '0.6';
            } else {
                mirrorBtn.removeAttribute('disabled');
                mirrorBtn.style.opacity = '1';
            }
        }
    };

    const observer = new MutationObserver(() => {
        const realBtn = document.querySelector('.ajax-pagination-btn');
        const wrapper = document.querySelector('.custom-sidebar-mirror-item');
        if (realBtn) updateMirror();
        else if (wrapper) wrapper.remove();
    });

    observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    updateMirror();
})();
