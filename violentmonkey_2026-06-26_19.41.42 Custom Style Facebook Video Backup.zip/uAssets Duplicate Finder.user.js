// ==UserScript==
// @name         uAssets Duplicate Finder
// @namespace    https://github.com/BlazeFTL
// @description  Performance-optimized duplicate search button with Material UI icon
// @version      1.7
// @author       BlazeFTL
// @match        https://github.com/uBlockOrigin/uAssets/*
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Verify we are on the main issues list
    const isIssueList = () => {
        const path = window.location.pathname;
        return path === '/uBlockOrigin/uAssets/issues' || path === '/uBlockOrigin/uAssets/issues/';
    };

    // Material Search Icon SVG
    const searchIcon = `
        <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="display:inline-block;vertical-align:middle;">
            <path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"/>
        </svg>
    `;

    // Inject shared styles to reduce per-button overhead
    const style = document.createElement('style');
    style.textContent = `
        .blaze-dup-btn {
            display: inline-flex !important;
            align-items: center;
            justify-content: center;
            margin-left: 8px !important;
            padding: 0 !important;
            width: 22px !important;
            height: 20px !important;
            border: 1px solid var(--borderColor-default, #30363d) !important;
            border-radius: 6px !important;
            background: var(--button-default-bgColor-rest, #21262d) !important;
            color: var(--fgColor-muted, #8b949e) !important;
            cursor: pointer !important;
            vertical-align: middle !important;
            transition: 0.2s cubic-bezier(0.3, 0, 0.5, 1);
        }
        .blaze-dup-btn:hover {
            background: var(--button-default-bgColor-hover, #30363d) !important;
            border-color: var(--borderColor-muted, #8b949e) !important;
            color: var(--fgColor-default, #f0f6fc) !important;
        }
    `;
    document.head.appendChild(style);

    const createButton = (searchTerm) => {
        const btn = document.createElement('button');
        btn.innerHTML = searchIcon;
        btn.className = 'blaze-dup-btn';
        btn.type = 'button';
        btn.title = `Search for duplicates of: ${searchTerm}`;

        btn.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const query = encodeURIComponent(`is:issue sort:updated-desc "${searchTerm}" in:title`);
            window.open(`https://github.com/uBlockOrigin/uAssets/issues?q=${query}`, '_blank');
        };
        return btn;
    };

    const inject = () => {
        if (!isIssueList()) return;

        const selectors = [
            'a[data-testid="issue-pr-title-link"]',
            'a[id^="issue_"][id$="_link"]'
        ];

        const links = document.querySelectorAll(selectors.join(', '));

        for (const link of links) {
            const parent = link.parentElement;
            if (parent && !parent.querySelector('.blaze-dup-btn')) {
                const titleText = link.innerText.trim();
                if (!titleText) continue;

                // Logic: Grab text before the first colon (usually the domain)
                const searchTerm = titleText.split(':')[0].trim();
                const btn = createButton(searchTerm);
                link.after(btn);
            }
        }
    };

    // Use debounced observer for zero CPU lag during idle
    let timeout;
    const observer = new MutationObserver(() => {
        clearTimeout(timeout);
        timeout = setTimeout(inject, 150);
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Handle SPA navigation
    window.addEventListener('turbo:render', inject);

    // Initial run
    inject();
})();
