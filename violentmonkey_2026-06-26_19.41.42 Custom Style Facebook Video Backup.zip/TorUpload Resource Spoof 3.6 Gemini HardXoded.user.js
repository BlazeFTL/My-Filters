// ==UserScript==
// @name         TorUpload Resource Spoof 3.6 Gemini HardXoded
// @namespace    https://github.com/BlazeFTL
// @description  Comprehensive resource spoofing for scripts, XHR, fetch, and frames (Updated May 2026).
// @version      3.6
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const internalKey = Symbol.for('resource_integrity_v3.6');
    if (window[internalKey]) return;
    window[internalKey] = true;

    // Blacklisted tracking/ad domains to completely sanitize from real performance logs
    const structuralBlacklist = [
        'dcbbwymp1bhlf.cloudfront.net',
        's0-greate.net',
        'ltlonelyandbe.org',
        'youexpectation.org',
        'cdn4ads.com',
        'adsco.re',
        'doubleclick.net',
        'googlesyndication.com',
        'galaksion.com',
        'adgpt.js',
        'adsbylinks.php'
    ];

    const _e = [
        {url: "https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447", type: "script"},
        {url: "https://dcbbwymp1bhlf.cloudfront.net/?wbbcd=1243778", type: "script"},
        {url: "https://s0-greate.net/p/2507871", type: "script"},
        {url: "https://ukankingwithea.com/", type: "fetch"},
        {url: "https://ltlonelyandbe.org/YmNGY3YDASUOSQNeJEUDEA97RkQkRnQlEgEBJBQPDxN3AR4OBWgAGg0WIgUEDQ0yTRgHF2NRMC0AKCZDO1MDMT4OAAAFETs6HjVDFTIDNj00KxwoIFIIFCk0MC4QFD9TJC4hLiYKITExNAQBLycrORALFRc7BCkhJg4lOjcOOgguI1pbHzEdKiICKR4mMQgiIFJTHCkjWyYAUiwMKy4hLiArPjYwJAAHBTMsOxEiFQg3djYQJBkDBzEFMgMuJzshHgs/BSI+NSYwNxc3IiQyCywOEQcQMjwJMgIAOzY7ADsnFQ8KLR4RBR4yAVAiEDI6Nxp+JCAjTjI3FScpICAjOBoLJScuNjw6FCoUfzssJyY8KzAkGwUIFSwwKzE3MzUhNzswVxM3ETsJATEeLDEoLkYwIjY2FFIlDiswJBsRCwYwJT8UEzQiNQQsJyEENScNEgBSJy42PzouJw8PLhckBwIgJyMTByFDNyErMTcsFC47Eg4bBCVHLBUXDycuNjwqIiRSITE9JAcCBUc4GhQ1Tik1EQA+NiIhRRwRDCgTSy87PCUEITsoMUQ", type: "iframe"},
        {url: "https://youexpectation.org/N0ZrelMYeQgJblIBIS8eYQAqLT5UBAo/P2IcHDQ9ZhAxEhFgD00OOlN7WkhnBHFcQnVHLw9HYhE1HxsnQjVWS3VeKA0VbhEwVkt9BHJFSWsZcU0PbgZgHwoyUHtaXCNDMgdHYgBxU0JlBHBSSGoBdA", type: "img"},
        {url: "https://accounts.google.com/ServiceLogin?passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Ffavicon.ico&uilel=3&hl=en&service=youtube", type: "img"},
        {url: "https://www.facebook.com/login.php?next=https%3A%2F%2Fwww.facebook.com%2Ffavicon.ico%3F_rdr%3Dp", type: "img"},
        {url: "https://accounts.google.com/ServiceLogin?passive=true&continue=https%3A%2F%2Fwww.google.com%2Ffavicon.ico&uilel=3&hl=en&service=mail", type: "img"},
        {url: "https://www.cdn4ads.com/T/myaUVE/xhumane.min.js", type: "script"},
        {url: "https://nathanmichaelphoto.com/adgpt.js?v=1.732668", type: "script"},
        {url: "https://tpc.googlesyndication.com/simgad/10068427869371561798?w=300&h=300", type: "img"},
        {url: "https://nathanmichaelphoto.com/status.php", type: "xmlhttprequest"},
        {url: "https://prod-central-fileserver-storage3.oggydrive.link/cgi-bin/ipp.cgi", type: "xmlhttprequest"},
        {url: "https://undefined/RTFPUTQkUyw8CyQMLXdBN11ydAYDFH0XUHdVNygHfEI+PkYnWTl/VyleOjVSN14hJRorVDt0BgNTHAluEVAaMkUCZX8BUQEBKR8FFwMqYX4oZnxkTBByAjN9LAgDAWUiSwYDV3xzDGVFDVsGHH8/WioBdnVeFSlhfXMIFF4HZTgZenZgCQFnfUMIO3VwfiY9QgRYJB9RK0kWC199QwQTU3VnCBRHAnUNBFAoCRcfQzEHKQd1KHIHPl8CYiQQfzxkFzVYNnMpF1wvZQcHAR1YHhB/FgEVG3Y1WCphbXx5GBsDF1wFC1UdXRsIdzFYKmFtLnAMPRF3dx4/GR9QDQZMAGg3F0wjZ3ZjY3ZSIBNdCHcGOwARfB4YQRnATl4dnt5AGx0UCwGTABofxRHDGAGdAYHcxgbAwtpFTNQPGQpHnU9WCphbXV1DABdAmk/HFAdWhkeTDZeBRN6d2Y4FwAUXB0ZUHdVCDdiKVgqYW0icgwUWwd1PxxQFAgLCHJwQSo6dnR5ByEAY1s8Plo1DDw/ciliCTtnKw", type: "iframe"},
        {url: "https://youexpectation.org/d2lramxYVggZUSIsMl8jIQ0DCT0AJTEtNkUoOgYCLgcqJy9FJE0eBRNUWlhYQltSUkoHAA9XXU9PGB4NAxwYV11RAAUMA0pPHVddWVlFWEJCTx5XXVEdGwsLSlhNGhgDBVZbW0BRU1xfQVBYWV5B", type: "img"},
        {url: "https://googleads.g.doubleclick.net/favicon.ico", type: "img"},
        {url: "https://ltlonelyandbe.org/REdSQUIlJT81", type: "object"},
        {url: "https://youexpectation.org/TUhQWmZidzMpWwMjFg4HJgEXOVQfGzUtLH0RPDIeDBA8MTMjBXYuDyl1YWhSfn9nYkA9ITRnV2s7JDsSODttaUAkJjY1WyAnJSkDKScnNEA7dWF0VXlmY2JIem4lZ1d0eWljUHp4aWlWeXtlb1NrPCA7AXB5dioSOSRta1F6cGhsVXtxZGtVew", type: "img"},
        {url: "https://cdclub.net/go/2507871?subid1=&subid2=&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3Nzg4NjM2OTJ9.UfII2PzlZFQ5dXTHzxt-Ibjc_DynLmJDGsw3vhoGz5w", type: "object"},
        {url: "https://nathanmichaelphoto.com/adsbylinks.php?v=2026-05-15&file_code=qg2ht00xibrs", type: "xmlhttprequest"},
        {url: "https://youexpectation.org/popunder.gif", type: "img"},
        {url: "https://c.adsco.re/", type: "script"},
        {url: "https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202605120101/pubads_impl_page_level_ads.js", type: "script"},
        {url: "https://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery.min.js", type: "script"},
        {url: "/js/bootstrap.bundle.min.js", type: "script"},
        {url: "/js/app.js?12", type: "script"},
        {url: "/js/jquery.paging.js", type: "script"},
        {url: "/js/jquery.cookie.js", type: "script"},
        {url: "/js/paging.js?r=1", type: "script"},
        {url: "/js/bootstrap-confirm.js?5", type: "script"},
        {url: "/js/dialogs.js?5", type: "script"},
        {url: "https://securepubads.g.doubleclick.net/tag/js/gpt.js", type: "script"},
        {url: "https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/m202605120101/pubads_impl.js", type: "script"}
    ];

    const generateEntry = (item) => {
        const randDuration = Math.floor(Math.random() * 280) + 40; // Mimic realistic script loads
        const randStart = Math.random() * 150 + 10;
        return {
            name: item.url,
            initiatorType: item.type,
            duration: randDuration,
            startTime: randStart,
            entryType: "resource",
            nextHopProtocol: "h2",
            renderBlockingStatus: "non-blocking",
            workerStart: 0,
            redirectStart: 0,
            redirectEnd: 0,
            fetchStart: randStart + 1,
            domainLookupStart: randStart + 1,
            domainLookupEnd: randStart + 3,
            connectStart: randStart + 3,
            connectEnd: randStart + 6,
            secureConnectionStart: randStart + 4,
            requestStart: randStart + 7,
            responseStart: randStart + 12,
            responseEnd: randStart + 12 + randDuration,
            transferSize: Math.floor(Math.random() * 8000) + 300,
            encodedBodySize: Math.floor(Math.random() * 5000) + 150,
            decodedBodySize: Math.floor(Math.random() * 15000) + 400,
            serverTiming: []
        };
    };

    const _p = Performance.prototype;
    const _getEntries = _p.getEntries;
    const _getEntriesByType = _p.getEntriesByType;
    const _getEntriesByName = _p.getEntriesByName;

    // Helper to verify if an item is a tracked ad asset
    const isTrackedAd = (url) => {
        if (!url) return false;
        return structuralBlacklist.some(domain => url.includes(domain)) || url.includes('torupload.com');
    };

    const cleanAndMix = (originalEntries) => {
        const original = originalEntries || [];
        // Clean out real tracking scripts that fired to prevent duplicate entry detection
        const sanitized = original.filter(entry => entry && entry.name && !isTrackedAd(entry.name));
        const fakes = _e.map(generateEntry);
        return [...sanitized, ...fakes];
    };

    _p.getEntries = function() {
        return cleanAndMix(_getEntries.apply(this, arguments));
    };

    _p.getEntriesByType = function(type) {
        if (type === 'resource') {
            return cleanAndMix(_getEntriesByType.apply(this, arguments));
        }
        return _getEntriesByType.apply(this, arguments);
    };

    _p.getEntriesByName = function(name) {
        if (isTrackedAd(name)) {
            const item = _e.find(x => x.url === name);
            return item ? [generateEntry(item)] : [];
        }
        return _getEntriesByName.apply(this, arguments);
    };

    // --- Prototype Anti-Stringification Protection ---
    const originalToString = Function.prototype.toString;
    Function.prototype.toString = function() {
        if (this === _p.getEntries) return 'function getEntries() { [native code] }';
        if (this === _p.getEntriesByType) return 'function getEntriesByType() { [native code] }';
        if (this === _p.getEntriesByName) return 'function getEntriesByName() { [native code] }';
        return originalToString.apply(this, arguments);
    };

})();
