// ==UserScript==
// @name         FireFox Background Timer + Audio Keep-Alive Gemini's 2nd Attempt
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Combines Web Workers and Silent Audio to prevent background freezing on Firefox Android
// @author       YourName
// @match        *://*/*
// @exclude      *://*.cloudflare.*/*
// @exclude      *://*.recaptcha.*/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=firefox.com
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // --- PART 1: SILENT AUDIO HACK ---
    function startSilentAudio() {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const source = audioCtx.createBufferSource();
        const silentBuffer = audioCtx.createBuffer(1, 44100, 44100);

        source.buffer = silentBuffer;
        source.loop = true;

        // Connect to destination but keep volume at 0
        const gainNode = audioCtx.createGain();
        gainNode.gain.value = 0;

        source.connect(gainNode);
        gainNode.connect(audioCtx.destination);

        // Mobile browsers require a user interaction to start audio
        const startAudio = () => {
            audioCtx.resume().then(() => {
                source.start();
                console.log("Audio Heartbeat Started");
                window.removeEventListener('click', startAudio);
                window.removeEventListener('touchstart', startAudio);
            });
        };

        window.addEventListener('click', startAudio);
        window.addEventListener('touchstart', startAudio);
    }

    // --- PART 2: WEB WORKER TIMERS ---
    const workerCode = `
        const timers = {};
        self.onmessage = function(e) {
            const { type, id, delay } = e.data;
            if (type === 'setTimeout') {
                setTimeout(() => self.postMessage({ id }), delay);
            } else if (type === 'setInterval') {
                timers[id] = setInterval(() => self.postMessage({ id }), delay);
            } else if (type === 'clearInterval') {
                clearInterval(timers[id]);
                delete timers[id];
            }
        };
    `;

    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const worker = new Worker(URL.createObjectURL(blob));
    const callbacks = {};
    let timerIdCount = 0;

    worker.onmessage = function(e) {
        if (callbacks[e.data.id]) {
            callbacks[e.data.id]();
        }
    };

    // Override Global SetTimeout
    window.setTimeout = function(callback, delay) {
        const id = ++timerIdCount;
        callbacks[id] = () => {
            callback();
            delete callbacks[id];
        };
        worker.postMessage({ type: 'setTimeout', id, delay });
        return id;
    };

    // Override Global SetInterval
    window.setInterval = function(callback, delay) {
        const id = ++timerIdCount;
        callbacks[id] = callback;
        worker.postMessage({ type: 'setInterval', id, delay });
        return id;
    };

    window.clearInterval = window.clearTimeout = function(id) {
        worker.postMessage({ type: 'clearInterval', id });
        delete callbacks[id];
    };

    // Initialize
    startSilentAudio();
    console.log("Background Fix Active: Worker + Audio Loop.");
})();

