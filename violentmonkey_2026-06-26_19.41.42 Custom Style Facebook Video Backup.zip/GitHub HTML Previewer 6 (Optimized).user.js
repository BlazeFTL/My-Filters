// ==UserScript==
// @name         GitHub HTML Previewer 6 (Optimized)
// @namespace    https://github.com/BlazeFTL
// @description  Targets the specific React directory row for .html previews with improved performance and reliability.
// @version      1.6
// @author       BlazeFTL
// @match        https://github.com/BlazeFTL/My-Filters*
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Configuration
    const PREVIEW_TEXT = ' [Preview]';
    const PREVIEW_CLASS = 'gh-preview-link';
    const PREVIEW_STYLE = 'color: #0969da; font-size: 12px; margin-left: 8px; text-decoration: none; font-weight: bold;';

    /**
     * Injects preview links next to .html files in the directory listing.
     */
    const injectLinks = () => {
        // GitHub's React UI uses 'Link--primary' for the filename links.
        // We target links ending in .html that are inside the directory rows.
        const links = document.querySelectorAll(`a.Link--primary[href$=".html"]:not([data-gh-preview-processed])`);

        if (links.length === 0) return;

        links.forEach(link => {
            // Mark as processed immediately to avoid redundant processing
            link.setAttribute('data-gh-preview-processed', 'true');

            // Skip if already has a preview link (extra safety)
            if (link.nextElementSibling && link.nextElementSibling.classList.contains(PREVIEW_CLASS)) return;

            const href = link.getAttribute('href');
            // Extract filename from href or textContent
            // Example href: /BlazeFTL/My-Filters/blob/master/filename.html
            const parts = href.split('/');
            const fileName = parts[parts.length - 1];

            const pagesUrl = `https://blazeftl.github.io/My-Filters/${fileName}`;

            const previewBtn = document.createElement('a');
            previewBtn.href = pagesUrl;
            previewBtn.target = '_blank';
            previewBtn.rel = 'noopener noreferrer';
            previewBtn.innerText = PREVIEW_TEXT;
            previewBtn.className = PREVIEW_CLASS;
            previewBtn.style.cssText = PREVIEW_STYLE;

            // Append next to the link
            link.after(previewBtn);
        });
    };

    // Debounce function to limit execution frequency
    let timeout;
    const debouncedInject = () => {
        clearTimeout(timeout);
        timeout = setTimeout(injectLinks, 50);
    };

    /**
     * Initialize the observer with a more specific target to reduce memory/CPU usage.
     */
    let observer;
    const initObserver = () => {
        if (observer) observer.disconnect();

        // Target the specific turbo-frame that GitHub uses for repo content
        const targetNode = document.querySelector('#repo-content-turbo-frame') ||
                          document.querySelector('.repository-content') ||
                          document.body;

        observer = new MutationObserver((mutations) => {
            // Only trigger if nodes are added, which is when new file rows appear
            for (let i = 0; i < mutations.length; i++) {
                if (mutations[i].addedNodes.length > 0) {
                    debouncedInject();
                    break;
                }
            }
        });

        // Use a lighter observation strategy:
        // We only care about child additions in the file list area.
        observer.observe(targetNode, {
            childList: true,
            subtree: true
        });
    };

    // Run on initial load
    injectLinks();
    initObserver();

    // Handle GitHub's soft navigation (Turbo)
    // 'turbo:load' covers initial load and successful navigation
    document.addEventListener('turbo:load', () => {
        injectLinks();
        initObserver();
    });

    // Re-run on render just in case, but debounced
    document.addEventListener('turbo:render', debouncedInject);

})();
