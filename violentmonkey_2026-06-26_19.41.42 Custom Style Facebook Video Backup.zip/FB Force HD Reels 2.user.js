// ==UserScript==
// @name         FB Force HD Reels 2
// @namespace    BlazeFTL
// @version      1.0
// @match        *://*.facebook.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
  const origFetch = window.fetch;

  function swapHD(text) {
    text = text.replace(
      /"playable_url":"((?:[^"\\]|\\.)*)"([\s\S]{0,3000}?)"playable_url_quality_hd":"((?:[^"\\]|\\.)*)"/g,
      (m, sd, mid, hd) => `"playable_url":"${hd}"${mid}"playable_url_quality_hd":"${hd}"`
    );
    text = text.replace(
      /"playable_url_quality_hd":"((?:[^"\\]|\\.)*)"([\s\S]{0,3000}?)"playable_url":"((?:[^"\\]|\\.)*)"/g,
      (m, hd, mid, sd) => `"playable_url_quality_hd":"${hd}"${mid}"playable_url":"${hd}"`
    );
    text = text.replace(
      /"browser_native_sd_url":"((?:[^"\\]|\\.)*)"([\s\S]{0,3000}?)"browser_native_hd_url":"((?:[^"\\]|\\.)*)"/g,
      (m, sd, mid, hd) => `"browser_native_sd_url":"${hd}"${mid}"browser_native_hd_url":"${hd}"`
    );
    return text;
  }

  window.fetch = async function(...args) {
    const res = await origFetch.apply(this, args);
    const url = typeof args[0] === 'string' ? args[0] : (args[0]?.url || '');
    if (!url.includes('graphql')) return res;
    const text = await res.text();
    const patched = swapHD(text);
    return new Response(patched, {
      status: res.status,
      statusText: res.statusText,
      headers: res.headers
    });
  };

  const fakeConn = {
    effectiveType: '4g',
    downlink: 10,
    downlinkMax: 10,
    rtt: 50,
    saveData: false,
    type: 'wifi',
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => true,
    onchange: null
  };

  try {
    Object.defineProperty(navigator, 'connection', { get: () => fakeConn, configurable: true });
    Object.defineProperty(navigator, 'mozConnection', { get: () => fakeConn, configurable: true });
    Object.defineProperty(navigator, 'webkitConnection', { get: () => fakeConn, configurable: true });
  } catch (e) {}

  try {
    localStorage.setItem('data_saver_user_action', '0');
    localStorage.setItem('use_efficiency_mode', '0');
  } catch (e) {}
})();
