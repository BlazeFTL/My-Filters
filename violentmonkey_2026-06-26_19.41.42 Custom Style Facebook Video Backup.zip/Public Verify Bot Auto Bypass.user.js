// ==UserScript==
// @name         Public Verify Bot Auto Bypass
// @namespace    AutoBypass
// @version      0.0.2
// @description  Made By @Nickupdates (TG)
// @author       Nick
// @match        https://*/*
// @grant        none
// @run-at       document-start
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/576794/Public%20Verify%20Bot%20Auto%20Bypass.user.js
// @updateURL https://update.greasyfork.org/scripts/576794/Public%20Verify%20Bot%20Auto%20Bypass.meta.js
// ==/UserScript==

(function () {
    'use strict';

    const host = location.hostname;

    function clearPage() {
        try {
            window.stop();
            document.documentElement.innerHTML = "";
        } catch (e) {}
    }

    function redirectLKSFY() {
        try {
            const params = new URLSearchParams(location.search);
            const id = params.get("id");

            if (
                id &&
                (
                    host.includes("sharclub.in") ||
                    host.includes("sportswordz.com") ||
                    host.includes("wblaxmibhandar.com")
                )
            ) {
                const target = "https://lksfy.com/" + id;
                clearPage();
                location.replace(target);
            }
        } catch (e) {
            console.error("LKSFY redirect error:", e);
        }
    }

    redirectLKSFY();

    if (host.includes("lksfy.com")) {

        function forceCookie() {
            try {
                document.cookie = "ab=1; path=/; domain=.lksfy.com; SameSite=None; Secure";
                localStorage.setItem("ab", "1");
            } catch (e) {}
        }

        window.addEventListener("load", () => {
            forceCookie();

            setInterval(forceCookie, 1000);

            try {
                Object.defineProperty(document, 'cookie', {
                    get: () => "ab=1",
                    set: () => true
                });
            } catch (e) {}
        });
    }

    if (host.includes("https://mtc1.") || host.includes("mtc1.yolo-school.com")) {

        window.stop();

        const block = () => {

            document.addEventListener('submit', e => {
                e.preventDefault();
                e.stopImmediatePropagation();
                return false;
            }, true);

            HTMLFormElement.prototype.submit = function () {
                return false;
            };

            const open = XMLHttpRequest.prototype.open;

            XMLHttpRequest.prototype.open = function () {
                return;
            };

            window.fetch = () => new Promise(() => {});
        };

        block();

        function start() {

            const input = document.querySelector('input[name="go"]');

            if (!input) {
                requestAnimationFrame(start);
                return;
            }

            let url;

            try {
                url = atob(input.value.trim());
            } catch {
                return;
            }

            document.documentElement.innerHTML = `
            <html>
            <head>
                <title>Redirecting...</title>

                <style>
                    *{
                        margin:0;
                        padding:0;
                        box-sizing:border-box;
                    }

                    body{
                        width:100%;
                        height:100vh;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                        background:#000;
                        font-family:Arial,sans-serif;
                        overflow:hidden;
                    }

                    .box{
                        background:#111;
                        border:1px solid #222;
                        padding:50px;
                        border-radius:18px;
                        text-align:center;
                        min-width:280px;
                        box-shadow:0 0 30px rgba(255,255,255,.05);
                    }

                    .title{
                        color:#aaa;
                        font-size:20px;
                    }

                    .timer{
                        margin-top:15px;
                        font-size:80px;
                        font-weight:bold;
                        color:#00ff99;
                    }
                </style>
            </head>

            <body>
                <div class="box">
                    <div class="title">Redirecting in</div>
                    <div class="timer" id="timer">30</div>
                </div>
            </body>
            </html>
            `;

            let time = 30;

            const interval = setInterval(() => {

                time--;

                const t = document.getElementById("timer");

                if (t) {
                    t.textContent = time;
                }

                if (time <= 0) {
                    clearInterval(interval);
                    location.href = url;
                }

            }, 1000);
        }

        start();
    }

    if (
        host.includes("odiadance.com") ||
        host.includes("sayphotobooth.com")
    ) {

        function autoSubmitAndRedirect() {
            try {

                if (document.forms.length > 1 && document.forms[1]) {
                    document.forms[1].submit();
                }

                const btn = document.getElementById("btn6");

                if (btn && btn.href) {
                    location.href = btn.href;
                }

            } catch (e) {
                console.error("Auto submit error:", e);
            }
        }

        window.addEventListener("load", () => {
            setTimeout(autoSubmitAndRedirect, 1000);
        });
    }

    const observer = new MutationObserver(() => {
        redirectLKSFY();
    });

    observer.observe(document, {
        childList: true,
        subtree: true
    });

})();