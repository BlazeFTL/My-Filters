// ==UserScript==
// @name         ShortxLinks Auto Click
// @namespace    BlazeFTL
// @version      3.0
// @match        *://mtc1.nkrmusic.in.net/*
// @match        *://mtc1.awaskit.in/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const clicked = new Set();

    function isVisible(el) {
        if (!el) return false;
        const s = getComputedStyle(el);
        return s.display !== 'none' && el.offsetParent !== null;
    }

    function click(selector, label) {
        const el = document.querySelector(selector);
        if (!el || clicked.has(selector)) return;

        if (isVisible(el)) {
            console.log('[AutoClick]', label);
            el.dispatchEvent(new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                view: window
            }));
            clicked.add(selector);
        }
    }

    function run() {
        // Step 1
        click('#wpsafelinkhuman', 'Human');

        // Step 2 (FIXED → anchor)
        click('#wpsafe-generate a', 'Generate');

        // Step 3 (FIXED → anchor)
        click('#wpsafe-link a', 'Final Link');
    }

    setInterval(run, 700);

    new MutationObserver(run).observe(document, {
        childList: true,
        subtree: true,
        attributes: true
    });

})();