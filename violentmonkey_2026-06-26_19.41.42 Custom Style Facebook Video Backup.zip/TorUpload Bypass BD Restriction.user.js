// ==UserScript==
// @name         TorUpload Bypass BD Restriction
// @namespace    https://github.com/BlazeFTL
// @version      1.8
// @author       BlazeFTL
// @match        *://nathanmichaelphoto.com/*
// @match        *://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1. Fixed Patch for the 'tmz' collection logic
    // We add 4 dummy characters at the start so .substring(4) leaves "India"
    const originalLocaleDateString = Date.prototype.toLocaleDateString;
    Date.prototype.toLocaleDateString = function(locale, options) {
        if (options && options.timeZoneName === 'long') {
            // "xxxx" will be cut off by the site's .substring(4)
            return "xxxxIndia Standard Time";
        }
        return originalLocaleDateString.apply(this, arguments);
    };

    // 2. Keep the India Offset
    Date.prototype.getTimezoneOffset = function() {
        return -330;
    };

    // 3. Patch Intl (For the isIndia check)
    const OriginalDTF = Intl.DateTimeFormat;
    Intl.DateTimeFormat = function(locale, options) {
        let instance = new OriginalDTF('en-IN', options);
        instance.resolvedOptions = () => ({
            timeZone: "Asia/Kolkata",
            calendar: "gregory",
            numberingSystem: "latn",
            locale: "en-IN"
        });
        return instance;
    };

    console.log("Telemetry fix applied: 'ndia' corrected to 'India'");
})();
