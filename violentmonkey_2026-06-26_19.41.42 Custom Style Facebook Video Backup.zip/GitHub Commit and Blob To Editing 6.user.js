// ==UserScript==
// @name         GitHub Commit and Blob To Editing 6
// @namespace    https://github.com/BlazeFTL
// @description  Direct edit automation with fixed grid layout for line number visibility
// @version      1.5
// @author       BlazeFTL
// @match        https://github.com/*
// @icon         https://avatars.githubusercontent.com/u/18120975?s=200&v=4
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let timeout = null;
    const getRepoPath = () => window.location.pathname.split('/').slice(1, 3).join('/');

    const handleDiffRows = () => {
        const rows = document.querySelectorAll('tr.diff-line-row:not([data-edit-processed])');
        rows.forEach(row => {
            row.setAttribute('data-edit-processed', 'true');
            const lineCell = row.querySelector('td:nth-child(2) code');
            const lineNum = lineCell ? lineCell.innerText.trim() : null;
            if (!lineNum || isNaN(lineNum)) return;

            const container = row.closest('[id^="diff-"]');
            const fileCodeElem = container?.querySelector('.Link--primary.prc-Link-Link-9ZwDx code');
            const filePath = fileCodeElem?.innerText.replace(/[\u200B-\u200D\uFEFF]/g, '').trim();

            if (filePath) {
                const btn = document.createElement('a');
                btn.href = `https://github.com/${getRepoPath()}/edit/master/${filePath}#L${lineNum}`;
                btn.innerText = '📝';
                btn.style.cssText = 'text-decoration:none; margin-left:4px; cursor:pointer; font-size:10px; vertical-align:middle;';
                lineCell.parentElement.appendChild(btn);
            }
        });
    };

    const handleBlobLines = () => {
        const lineNumbers = document.querySelectorAll('div[data-line-number]:not([data-edit-processed])');
        if (!lineNumbers.length) return;

        const breadcrumbLinks = Array.from(document.querySelectorAll('nav[aria-label="Breadcrumbs"] a, [class*="Breadcrumb"] a'));
        const folderLink = breadcrumbLinks.reverse().find(a => a.href.includes('/tree/'));
        if (!folderLink) return;

        const urlParts = folderLink.href.split('/');
        const treeIndex = urlParts.indexOf('tree');
        const folderPath = urlParts.slice(treeIndex + 2).join('/');
        const fileNameElem = document.querySelector('h1[id="file-name-id"], [class*="filename"] h1');
        const fileName = fileNameElem ? fileNameElem.innerText.trim() : '';
        const filePath = folderPath ? `${folderPath}/${fileName}` : fileName;

        lineNumbers.forEach(div => {
            div.setAttribute('data-edit-processed', 'true');
            if (!div.classList.contains('react-line-number')) return;

            const lineNum = div.getAttribute('data-line-number');

            // Using Grid to keep the number left-aligned and icon right-aligned
            // This prevents the icon from 'hiding' the number on narrow screens
            div.style.display = 'grid';
            div.style.gridTemplateColumns = '1fr auto';
            div.style.alignItems = 'center';
            div.style.paddingLeft = '2px';
            div.style.paddingRight = '2px';
            div.style.overflow = 'visible';

            const editLink = document.createElement('a');
            editLink.href = `https://github.com/${getRepoPath()}/edit/master/${filePath}#L${lineNum}`;
            editLink.innerText = '📝';
            editLink.style.cssText = 'font-size: 10px; text-decoration: none; margin-left: 2px; line-height: 1;';

            div.appendChild(editLink);
        });
    };

    const init = () => {
        const path = window.location.pathname;
        if (path.includes('/commit/') || path.includes('/pull/')) {
            handleDiffRows();
        } else if (path.includes('/blob/')) {
            handleBlobLines();
        }
    };

    const observer = new MutationObserver(() => {
        clearTimeout(timeout);
        timeout = setTimeout(init, 150);
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
    init();
})();
