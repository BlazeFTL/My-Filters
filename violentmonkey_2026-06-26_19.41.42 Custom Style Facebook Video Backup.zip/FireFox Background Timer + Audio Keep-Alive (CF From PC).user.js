// ==UserScript==
// @name         FireFox Background Timer + Audio Keep-Alive (CF From PC)
// @namespace    http://tampermonkey.net/
// @version      2.2
// @description  Prevents background freezing on Firefox Android, auto-disables on Cloudflare verification
// @match        *://*/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=firefox.com
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    /* ---------- FAST CLOUDFLARE DETECTION (HARD STOP) ---------- */
    if (
        // DOM-level (fastest)
        document.documentElement.classList.contains('ray-id') ||
        document.documentElement.hasAttribute('data-cf') ||

        // JS globals (challenge-only)
        window._cf_chl_opt ||
        window.__CF$cv$params ||

        // Challenge URLs (always used)
        location.pathname.startsWith('/cdn-cgi/')
    ) {
        return;
    }

    /* ---------- Silent Audio ---------- */
    function startSilentAudio() {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const src = ctx.createBufferSource();
        src.buffer = ctx.createBuffer(1, 1, 22050);
        src.loop = true;

        const gain = ctx.createGain();
        gain.gain.value = 0;

        src.connect(gain);
        gain.connect(ctx.destination);

        const start = () => {
            ctx.resume().then(() => src.start());
            window.removeEventListener('click', start);
            window.removeEventListener('touchstart', start);
        };

        window.addEventListener('click', start, { once: true });
        window.addEventListener('touchstart', start, { once: true });
    }

    /* ---------- Worker Timers ---------- */
    const worker = new Worker(URL.createObjectURL(new Blob([`
        const timers = {};
        onmessage = e => {
            const { t, i, d } = e.data;
            if (t === 1) setTimeout(() => postMessage(i), d);
            if (t === 2) timers[i] = setInterval(() => postMessage(i), d);
            if (t === 3) clearInterval(timers[i]);
        };
    `], { type: 'application/javascript' })));

    const cb = {};
    let id = 0;

    worker.onmessage = e => cb[e.data]?.();

    window.setTimeout = (f, d) => {
        const i = ++id;
        cb[i] = () => { f(); delete cb[i]; };
        worker.postMessage({ t: 1, i, d });
        return i;
    };

    window.setInterval = (f, d) => {
        const i = ++id;
        cb[i] = f;
        worker.postMessage({ t: 2, i, d });
        return i;
    };

    window.clearTimeout =
    window.clearInterval = i => {
        worker.postMessage({ t: 3, i });
        delete cb[i];
    };

    startSilentAudio();
})();
