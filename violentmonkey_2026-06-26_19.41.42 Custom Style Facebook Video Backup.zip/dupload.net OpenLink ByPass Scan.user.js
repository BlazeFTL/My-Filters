// ==UserScript==
// @name         dupload.net OpenLink ByPass Scan
// @namespace    https://github.com/BlazeFTL
// @description  Bypasses multi-step countdown timers and redirects directly to the destination URL.
// @version      1.0
// @author       BlazeFTL
// @match        *://*/*
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    // Extract the target URL from the script tag content on the page
    const scripts = document.querySelectorAll('script');
    let targetUrl = '';

    for (const script of scripts) {
        if (script.textContent.includes('var tagrget_url =')) {
            const match = script.textContent.match(/var tagrget_url\s*=\s*["']([^"']+)["']/);
            if (match && match[1]) {
                targetUrl = match[1];
                break;
            }
        }
    }

    // If found, clear the bypass cookie and redirect immediately
    if (targetUrl) {
        document.cookie = "user_step=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        window.location.href = targetUrl;
    }
})();
