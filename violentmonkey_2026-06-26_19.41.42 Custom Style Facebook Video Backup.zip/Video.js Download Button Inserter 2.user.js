// ==UserScript==
// @name         Video.js Download Button Inserter 2
// @namespace    https://github.com/BlazeFTL
// @description  Forces Firefox Android to trigger the native download UI.
// @version      1.1
// @author       BlazeFTL
// @match        *://*/*
// @grant        none
// @run-at       document-idle
// @allFrames    true
// ==/UserScript==

(function() {
    'use strict';

    const downloadIconSVG = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white" width="24px" height="24px">
            <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>
        </svg>
    `;

    const triggerDownload = (url) => {
        // Create a temporary hidden link
        const anchor = document.createElement('a');
        anchor.href = url;

        // This attribute tells Firefox to download instead of play
        anchor.setAttribute('download', 'video.mp4');
        anchor.style.display = 'none';

        // We must append it to the body for it to work in some frames
        document.body.appendChild(anchor);
        anchor.click();

        // Cleanup
        setTimeout(() => document.body.removeChild(anchor), 100);
    };

    const insertButton = () => {
        const controlBar = document.querySelector('.vjs-control-bar');
        const video = document.querySelector('video');

        if (!controlBar || !video || document.querySelector('.vjs-dl-btn')) return;

        const btn = document.createElement('button');
        btn.className = 'vjs-dl-btn vjs-control vjs-button';
        btn.innerHTML = downloadIconSVG;
        btn.title = 'Download Now';
        btn.style.cursor = 'pointer';

        btn.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();

            // Get the raw source (the cloudatscdn.com link from your screenshot)
            const source = video.currentSrc || video.src;

            if (source) {
                console.log('Attempting download from:', source);
                triggerDownload(source);
            } else {
                alert('Source not found. Is the video playing?');
            }
        };

        // Put it next to the fullscreen/volume buttons
        controlBar.appendChild(btn);
    };

    // Keep checking if the player is added dynamically
    const observer = new MutationObserver(insertButton);
    observer.observe(document.body, { childList: true, subtree: true });
    insertButton();
})();
