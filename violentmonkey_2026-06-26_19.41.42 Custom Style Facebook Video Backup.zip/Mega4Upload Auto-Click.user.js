// ==UserScript==
// @name         Mega4Upload Auto-Click
// @namespace    http://tampermonkey.net/
// @version      1.1
// @author       BlazeFTL
// @match        https://mega4upload.net/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1st Page Action
    const infoBtn = document.querySelector('.btn-sm.btn-info.btn');
    if (infoBtn) infoBtn.click();

    // 2nd Page Action
    const downloadBtn = document.querySelector('.downloadbtn.btn-success.btn-icon-split.btn-sm.btn');

    if (downloadBtn) {
        // Create an observer to watch for the "disabled" attribute being removed
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'disabled') {
                    if (!downloadBtn.hasAttribute('disabled')) {
                        console.log('Disabled attribute removed! Clicking...');
                        downloadBtn.click();
                        observer.disconnect(); // Stop watching once clicked
                    }
                }
            });
        });

        // Start observing the button for attribute changes
        observer.observe(downloadBtn, { attributes: true });

        // Fallback: If Captcha is solved but observer missed the attribute change
        captchaSolved(() => {
            if (!downloadBtn.hasAttribute('disabled')) {
                downloadBtn.click();
            }
        });
    }

    // Your Captcha Detection Function
    function captchaSolved(callback) {
        let intervalId = setInterval(() => {
            try {
                const captcha = window.turnstile || window.hcaptcha || window.grecaptcha;
                if (captcha && typeof captcha.getResponse === 'function' && captcha.getResponse()) {
                    clearInterval(intervalId);
                    callback();
                }
                // Visual check for IconCaptcha
                if (document.querySelector('.iconcaptcha-modal__body-title')?.innerText.includes('complete')) {
                    clearInterval(intervalId);
                    callback();
                }
            } catch (e) {}
        }, 1000);
    }
})();

