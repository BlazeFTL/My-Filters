// ==UserScript==
// @name         GitHub HTML Previewer 6
// @namespace    https://github.com/BlazeFTL
// @description  Targets the specific React directory row for .html previews.
// @version      1.5
// @author       BlazeFTL
// @match        https://github.com/BlazeFTL/My-Filters*
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const injectLinks = () => {
        // Target specifically the filename links within the directory structure
        const rows = document.querySelectorAll('div.react-directory-filename-column a[href$=".html"]');

        rows.forEach(link => {
            // Check if we already added the preview link to avoid duplicates
            if (link.parentNode.querySelector('.gh-preview-link')) return;

            const fileName = link.textContent.trim();
            const pagesUrl = `https://blazeftl.github.io/My-Filters/${fileName}`;

            const previewBtn = document.createElement('a');
            previewBtn.href = pagesUrl;
            previewBtn.target = '_blank';
            previewBtn.innerText = ' [Preview]';
            previewBtn.className = 'gh-preview-link';
            previewBtn.style.cssText = 'color: #0969da; font-size: 12px; margin-left: 8px; text-decoration: none; font-weight: bold;';

            // Append next to the link
            link.after(previewBtn);
        });
    };

    // Run on initial load
    injectLinks();

    // Use a lighter observer that only watches the file list container if it exists
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.addedNodes.length) {
                injectLinks();
                break;
            }
        }
    });

    // Start observing the main content area specifically
    const targetNode = document.querySelector('div.repository-content') || document.body;
    observer.observe(targetNode, { childList: true, subtree: true });

    // Handle GitHub's soft navigation
    document.addEventListener('turbo:render', injectLinks);
})();
