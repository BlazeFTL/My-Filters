// ==UserScript==
// @name         Linksconsole Interaction
// @namespace    https://github.com/BlazeFTL
// @description  Automate interaction with the continue button
// @version      1.0
// @author       BlazeFTL
// @match        https://linksconsole.com/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // A common approach is to use an observer or a repetitive check
    // to see if a button's state has changed (e.g., hidden class removed)
    const monitorButton = setInterval(() => {
        const continueBtn = document.getElementById('continue-btn');

        // Check if the button exists and is no longer hidden by the site's script
        if (continueBtn && !continueBtn.classList.contains('hidden') && !continueBtn.disabled) {
            console.log("Button is ready, performing action...");
            continueBtn.click();
            clearInterval(monitorButton);
        }
    }, 1000); // Checks every second
})();

