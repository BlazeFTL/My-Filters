// ==UserScript==
// @name         SetTimeout and Interval Logger 4
// @namespace    https://github.com/BlazeFTL
// @description  Logs calls to setTimeout and setInterval upon button click
// @version      1.3
// @author       BlazeFTL
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let isLogging = false;
    const originalSetTimeout = window.setTimeout;
    const originalSetInterval = window.setInterval;

    const createUI = () => {
        const container = document.createElement('div');
        container.id = 'timer-logger-ui';
        // Maintaining the 400x200 footprint for consistency
        container.style = `
            position: fixed;
            top: 15px;
            right: 15px;
            width: 400px;
            height: 200px;
            z-index: 999999;
            background: #ffffff;
            color: #333;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(0,0,0,0.05);
        `;

        const header = document.createElement('div');
        header.style = `
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            padding: 10px 15px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 12px;
            font-weight: 600;
        `;

        const titleText = document.createElement('span');
        titleText.innerText = 'TIMER LOGGER';

        const toggleBtn = document.createElement('button');
        toggleBtn.innerText = 'START LOGGING';
        toggleBtn.style = `
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.4);
            color: white;
            padding: 4px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 10px;
            font-weight: bold;
            transition: all 0.3s ease;
            outline: none;
        `;

        const statusArea = document.createElement('div');
        statusArea.style = `
            flex: 1;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: #f8f9fa;
            text-align: center;
        `;

        const statusIndicator = document.createElement('div');
        statusIndicator.style = `
            width: 12px;
            height: 12px;
            background: #bbb;
            border-radius: 50%;
            margin-bottom: 10px;
            transition: background 0.3s;
        `;

        const statusText = document.createElement('div');
        statusText.innerText = 'Logging is currently inactive.\nOutputs will appear in the Console.';
        statusText.style = 'font-size: 11px; color: #666; line-height: 1.5;';

        toggleBtn.onclick = () => {
            isLogging = !isLogging;
            if (isLogging) {
                toggleBtn.innerText = 'STOP LOGGING';
                toggleBtn.style.background = '#ff4b2b';
                statusIndicator.style.background = '#4cd137';
                statusIndicator.style.boxShadow = '0 0 8px #4cd137';
                statusText.innerText = 'ACTIVE: Intercepting Timers...\nCheck browser console for logs.';
            } else {
                toggleBtn.innerText = 'START LOGGING';
                toggleBtn.style.background = 'rgba(255,255,255,0.2)';
                statusIndicator.style.background = '#bbb';
                statusIndicator.style.boxShadow = 'none';
                statusText.innerText = 'Logging is currently inactive.\nOutputs will appear in the Console.';
            }
            console.log(`[Logger] ${isLogging ? 'ENABLED' : 'DISABLED'}`);
        };

        header.appendChild(titleText);
        header.appendChild(toggleBtn);
        statusArea.appendChild(statusIndicator);
        statusArea.appendChild(statusText);
        container.appendChild(header);
        container.appendChild(statusArea);
        document.documentElement.appendChild(container);
    };

    // Initialize UI
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        createUI();
    } else {
        window.addEventListener('DOMContentLoaded', createUI);
    }

    // Override logic
    window.setTimeout = function(callback, delay, ...args) {
        if (isLogging) {
            console.groupCollapsed(`%c[setTimeout] ${delay}ms`, 'color: #2575fc; font-weight: bold;');
            console.log('Callback:', callback.toString());
            console.log('Args:', args);
            console.trace('Stack Trace');
            console.groupEnd();
        }
        return originalSetTimeout.call(this, callback, delay, ...args);
    };

    window.setInterval = function(callback, delay, ...args) {
        if (isLogging) {
            console.groupCollapsed(`%c[setInterval] ${delay}ms`, 'color: #6a11cb; font-weight: bold;');
            console.log('Callback:', callback.toString());
            console.log('Args:', args);
            console.trace('Stack Trace');
            console.groupEnd();
        }
        return originalSetInterval.call(this, callback, delay, ...args);
    };
})();
