// ==UserScript==
// @name         SetTimeout and Interval Logger 6
// @namespace    https://github.com/BlazeFTL
// @description  Logs calls to setTimeout and setInterval to both UI and Console.
// @version      1.5
// @author       BlazeFTL
// @match        *://*/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let isLogging = false;
    const originalSetTimeout = window.setTimeout;
    const originalSetInterval = window.setInterval;

    const createUI = () => {
        const container = document.createElement('div');
        container.id = 'timer-logger-ui';
        container.style = `
            position: fixed;
            top: 15px;
            right: 15px;
            width: 400px;
            height: 200px;
            z-index: 999999;
            background: #ffffff;
            color: #333;
            font-family: 'Segoe UI', Roboto, sans-serif;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.15);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(0,0,0,0.1);
        `;

        const header = document.createElement('div');
        header.style = `
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            padding: 8px 12px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 11px;
            font-weight: 600;
        `;

        const titleText = document.createElement('span');
        titleText.innerText = 'TIMER LOGS';

        const actionGroup = document.createElement('div');
        actionGroup.style = 'display: flex; gap: 5px;';

        const copyBtn = document.createElement('button');
        copyBtn.innerText = 'COPY';
        const btnStyle = `
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.4);
            color: white;
            padding: 2px 8px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 10px;
            font-weight: bold;
        `;
        copyBtn.style = btnStyle;

        const toggleBtn = document.createElement('button');
        toggleBtn.innerText = 'START';
        toggleBtn.style = btnStyle;

        const logArea = document.createElement('textarea');
        logArea.id = 'timer-log-box';
        logArea.readOnly = true;
        logArea.style = `
            flex: 1;
            background: #f8f9fa;
            color: #2c3e50;
            border: none;
            resize: none;
            outline: none;
            padding: 10px;
            font-family: 'Consolas', monospace;
            font-size: 10px;
            line-height: 1.4;
        `;
        logArea.placeholder = 'Logs will appear here and in Console...';

        copyBtn.onclick = () => {
            logArea.select();
            document.execCommand('copy');
            const old = copyBtn.innerText;
            copyBtn.innerText = 'DONE';
            setTimeout(() => copyBtn.innerText = old, 1500);
        };

        toggleBtn.onclick = () => {
            isLogging = !isLogging;
            toggleBtn.innerText = isLogging ? 'STOP' : 'START';
            toggleBtn.style.background = isLogging ? '#ff4b2b' : 'rgba(255,255,255,0.2)';
            if(isLogging) {
                logArea.value = `[${new Date().toLocaleTimeString()}] Logging Started...\n` + logArea.value;
                console.log('%c[Timer Logger] Enabled', 'color: #2575fc; font-weight: bold;');
            }
        };

        actionGroup.appendChild(copyBtn);
        actionGroup.appendChild(toggleBtn);
        header.appendChild(titleText);
        header.appendChild(actionGroup);
        container.appendChild(header);
        container.appendChild(logArea);
        document.documentElement.appendChild(container);
        return logArea;
    };

    let displayBox;

    const init = () => {
        if (!displayBox) displayBox = createUI();
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    const logData = (type, delay, callback, args) => {
        if (!isLogging) return;

        const time = new Date().toLocaleTimeString([], {hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit'});
        const funcStr = callback.toString();
        const shortFunc = funcStr.substring(0, 60).replace(/\n/g, ' ') + '...';

        // 1. Log to UI
        if (displayBox) {
            const entry = `[${time}] ${type} | ${delay}ms | fn: ${shortFunc}\n`;
            displayBox.value = entry + displayBox.value;
        }

        // 2. Log to Console (Grouped for readability)
        console.groupCollapsed(`%c[${type}] ${delay}ms`, 'color: #6a11cb;');
        console.log('Function:', funcStr);
        console.log('Arguments:', args);
        console.trace('Origin Trace');
        console.groupEnd();
    };

    window.setTimeout = function(callback, delay, ...args) {
        logData('TIMEOUT ', delay || 0, callback, args);
        return originalSetTimeout.call(this, callback, delay, ...args);
    };

    window.setInterval = function(callback, delay, ...args) {
        logData('INTERVAL', delay || 0, callback, args);
        return originalSetInterval.call(this, callback, delay, ...args);
    };
})();
