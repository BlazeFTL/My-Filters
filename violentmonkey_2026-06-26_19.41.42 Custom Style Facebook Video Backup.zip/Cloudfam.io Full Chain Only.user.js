// ==UserScript==
// @name         Cloudfam.io Full Chain Only
// @namespace    https://github.com/BlazeFTL
// @description  Automates the cloudfam redirection chain from 0 to step 2
// @version      1.6
// @author       BlazeFTL
// @match        https://cloudfam.io/redirection*
// @match        https://cloudfam.io/*?slug=*
// @license      MIT
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const url = window.location.href;
    const urlParams = new URLSearchParams(window.location.search);
    const slug = urlParams.get('slug');
    const token = urlParams.get('token');

    // If we don't have the necessary data, stop
    if (!slug || !token) return;

    let nextUrl = '';

    // Logic for the chain sequence
    if (url.includes('redirection0.php')) {
        nextUrl = `https://cloudfam.io/redirection.php?slug=${slug}&token=${token}`;
    }
    else if (url.includes('redirection.php') && !url.includes('redirection2') && !url.includes('redirection3')) {
        nextUrl = `https://cloudfam.io/redirection2.php?slug=${slug}&token=${token}`;
    }
    else if (url.includes('redirection2.php')) {
        nextUrl = `https://cloudfam.io/redirection3.php?slug=${slug}&token=${token}`;
    }
    else if (url.includes('redirection3.php')) {
        nextUrl = `https://cloudfam.io/${slug}?step=2&token=${token}`;
    }

    if (nextUrl) {
        // Use location.replace to keep the back-button clean
        window.location.replace(nextUrl);
    }
})();

