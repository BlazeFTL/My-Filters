// ==UserScript==
// @name         Ublock Droplink Window.Stop
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Redirects specific links and stops execution
// @author       BlazeFTL
// @match        https://tech8s.net/safe2.php?link=*
// @match        https://game5s.com/safe2.php?link=*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const currentUrl = window.location.href;
    const urlParams = new URLSearchParams(window.location.search);
    const linkValue = urlParams.get('link');

    if (linkValue) {
        // Stop the current page from loading further
        window.stop();

        if (currentUrl.includes('tech8s.net')) {
            // Step 1: Redirect from tech8s to game5s
            window.location.replace(`https://game5s.com/safe2.php?link=${linkValue}`);
        }
        else if (currentUrl.includes('game5s.com')) {
            // Step 2: Redirect from game5s to droplink
            window.location.replace(`https://droplink.co/${linkValue}`);
        }
    }
})();

