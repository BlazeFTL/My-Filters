// ==UserScript==
// @name         JW Player Side-Zone Seek (Flat Feedback + Visible Reveal)
// @namespace    http://tampermonkey.net/
// @version      3.4
// @description  Invisible left/right zones seek ±10s. Long-press reveals bright zone boundaries. Flat (non-round) feedback on tap. Avoids top and control bar.
// @match        https://*.mat6tube.com/*
// @match        https://*.noodlemagazine.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function addStyle(css) {
        const style = document.createElement('style');
        style.type = 'text/css';
        style.appendChild(document.createTextNode(css));
        document.head.appendChild(style);
    }

    addStyle(`
        .jwplayer {
            position: relative;
        }

        /* --- Invisible side zones --- */
        .jw-side-zone {
            position: absolute;
            top: 68px;
            bottom: 68px;
            width: 28%;
            z-index: 5;
            cursor: pointer;
            pointer-events: auto;
            background: transparent;
            border: none;
            outline: none;
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
            user-select: none;
            -webkit-user-select: none;
            -webkit-touch-callout: none;
        }

        .jw-side-zone-left {
            left: 0;
        }

        .jw-side-zone-right {
            right: 0;
        }

        @media (orientation: landscape) {
            .jw-side-zone {
                width: 24%;
            }
        }

        /* --- LONG-PRESS REVEAL (very visible) --- */
        .jw-side-zone::before {
            content: '';
            position: absolute;
            inset: 0;
            background: rgba(0,0,0,0.35);
            border: 2.5px solid rgba(255,255,255,0.85);
            box-shadow: inset 0 0 50px rgba(255,255,255,0.08), 0 0 20px rgba(0,0,0,0.2);
            opacity: 0;
            transition: opacity 0.1s ease;
            pointer-events: none;
            border-radius: 4px;
        }

        .jw-side-zone.jw-zone-revealed::before {
            opacity: 1;
        }

        .jw-side-zone .zone-label {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: #fff;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            font-size: 26px;
            font-weight: 700;
            letter-spacing: 1px;
            text-shadow: 0 2px 14px rgba(0,0,0,0.6);
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.1s ease;
            white-space: nowrap;
        }

        .jw-side-zone.jw-zone-revealed .zone-label {
            opacity: 1;
        }

        /* --- FLAT SEEK FEEDBACK (no round UI) --- */
        .jw-seek-feedback {
            position: absolute;
            top: 50%;
            pointer-events: none;
            z-index: 15;
            animation: seekFeedbackFade 0.85s ease forwards;
        }

        .jw-seek-feedback-left {
            left: 18%;
            transform: translate(-50%, -50%);
        }

        .jw-seek-feedback-right {
            right: 18%;
            transform: translate(50%, -50%);
        }

        @media (orientation: landscape) {
            .jw-seek-feedback-left { left: 16%; }
            .jw-seek-feedback-right { right: 16%; }
        }

        .jw-seek-feedback .seek-badge {
            padding: 10px 20px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: badgePop 0.5s cubic-bezier(0.22, 1.3, 0.36, 1) forwards;
            box-shadow: 0 4px 20px rgba(0,0,0,0.35);
        }

        .jw-seek-feedback .seek-text {
            color: #fff;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            font-size: 15px;
            font-weight: 700;
            letter-spacing: 0.6px;
            text-shadow: 0 1px 4px rgba(0,0,0,0.5);
            white-space: nowrap;
        }

        @keyframes badgePop {
            0% { transform: scale(0.85); opacity: 0; }
            40% { transform: scale(1.04); opacity: 1; }
            100% { transform: scale(1); opacity: 1; }
        }

        @keyframes seekFeedbackFade {
            0% { opacity: 1; }
            70% { opacity: 1; }
            100% { opacity: 0; }
        }

        /* --- Top-right fullscreen (stock) --- */
        .jw-top-right-controls {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 20;
            display: flex;
            gap: 8px;
            pointer-events: auto;
            transition: opacity 0.3s ease;
        }

        .jw-top-right-controls button {
            background: rgba(0,0,0,0.5);
            border: none;
            color: white;
            padding: 4px 8px;
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px;
            line-height: 1;
            transition: background-color 0.2s ease;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            min-width: 36px;
            min-height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .jw-top-right-controls button:hover {
            background-color: rgba(0,0,0,0.7);
        }

        /* --- Control bar buttons (stock) --- */
        .jw-controlbar .jw-button-container {
            display: flex;
            align-items: center;
        }

        .jw-controlbar .custom-control-button {
            background: none;
            border: none;
            color: white;
            padding: 0 4px;
            cursor: pointer;
            font-size: 12px;
            line-height: 1;
            margin-right: 8px;
            display: flex;
            align-items: center;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            transition: color 0.2s ease;
            min-height: 36px;
        }

        .jw-controlbar .custom-control-button:hover {
            color: #aaaaaa;
        }

        .jw-controlbar .jw-icon-playback {
            margin-right: 8px;
        }

        /* Sync hide/show with JW Player controls */
        .jwplayer.jw-flag-user-inactive .jw-top-right-controls {
            opacity: 0;
            pointer-events: none !important;
        }

        /* Hide custom controls during ads */
        .jwplayer.jw-flag-ads .custom-control-button,
        .jwplayer.jw-flag-ads .jw-top-right-controls,
        .jwplayer.jw-flag-ads .jw-side-zone {
            display: none !important;
        }
    `);

    function init() {
        const check = setInterval(() => {
            if (typeof jwplayer !== 'function') return;

            const playerElements = document.querySelectorAll('.jwplayer:not([data-custom-controls="true"])');
            playerElements.forEach(el => {
                if (!el.id) return;
                try {
                    const instance = jwplayer(el.id);
                    if (instance && typeof instance.getState === 'function') {
                        el.setAttribute('data-custom-controls', 'true');
                        enhanceJWPlayer(instance, el);
                    }
                } catch (e) {
                    console.warn('JW enhancement skipped:', el.id, e);
                }
            });

            try {
                const defaultInstance = jwplayer();
                const defaultContainer = defaultInstance && defaultInstance.getContainer ? defaultInstance.getContainer() : null;
                if (defaultContainer && !defaultContainer.hasAttribute('data-custom-controls')) {
                    defaultContainer.setAttribute('data-custom-controls', 'true');
                    enhanceJWPlayer(defaultInstance, defaultContainer);
                }
            } catch (e) {}
        }, 800);
    }

    function enhanceJWPlayer(player, playerContainer) {
        if (!playerContainer) return;
        if (playerContainer.querySelector('.jw-custom-controls-wrapper')) return;

        const observer = new MutationObserver((mutations, obs) => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');

            if (controlBar && playButtonContainer) {
                if (!playerContainer.querySelector('.jw-custom-controls-wrapper')) {
                    obs.disconnect();
                    addButtons(player, playButtonContainer, playerContainer);
                }
            }
        });

        observer.observe(playerContainer, { childList: true, subtree: true });

        const fallback = setInterval(() => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');

            if (controlBar && playButtonContainer) {
                if (!playerContainer.querySelector('.jw-custom-controls-wrapper')) {
                    clearInterval(fallback);
                    observer.disconnect();
                    addButtons(player, playButtonContainer, playerContainer);
                }
            }
        }, 1200);
    }

    function addButtons(player, playButtonContainer, playerContainer) {
        const marker = document.createElement('div');
        marker.className = 'jw-custom-controls-wrapper';
        marker.style.display = 'none';
        playerContainer.appendChild(marker);

        const safeSeek = (offset) => {
            try {
                const pos = player.getPosition() || 0;
                const dur = player.getDuration() || 0;
                player.seek(Math.max(0, Math.min(pos + offset, dur)));
            } catch (e) {
                console.warn('Seek failed:', e);
            }
        };

        /* --- Flat feedback badge --- */
        function showFixedFeedback(side) {
            const feedback = document.createElement('div');
            feedback.className = 'jw-seek-feedback jw-seek-feedback-' + side;

            const badge = document.createElement('div');
            badge.className = 'seek-badge';

            const text = document.createElement('div');
            text.className = 'seek-text';
            text.textContent = side === 'left' ? '« 10s' : '10s »';

            badge.appendChild(text);
            feedback.appendChild(badge);
            playerContainer.appendChild(feedback);

            setTimeout(() => feedback.remove(), 850);
        }

        /* --- Invisible side zones with long-press reveal --- */
        const createZone = (className, offset, side, labelText) => {
            const zone = document.createElement('div');
            zone.className = 'jw-side-zone ' + className;

            const label = document.createElement('div');
            label.className = 'zone-label';
            label.textContent = labelText;
            zone.appendChild(label);

            let pressTimer;

            const clearPress = () => {
                clearTimeout(pressTimer);
                zone.classList.remove('jw-zone-revealed');
                zone._isLongPress = false;
            };

            zone.addEventListener('pointerdown', (e) => {
                zone._isLongPress = false;
                pressTimer = setTimeout(() => {
                    zone._isLongPress = true;
                    zone.classList.add('jw-zone-revealed');
                }, 350);
            });

            zone.addEventListener('pointerup', (e) => {
                clearTimeout(pressTimer);
                const wasLongPress = zone._isLongPress;
                zone.classList.remove('jw-zone-revealed');
                zone._isLongPress = false;

                if (!wasLongPress) {
                    e.stopPropagation();
                    safeSeek(offset);
                    showFixedFeedback(side);
                }
            });

            zone.addEventListener('pointerleave', clearPress);
            zone.addEventListener('pointercancel', clearPress);
            zone.addEventListener('contextmenu', (e) => e.preventDefault());

            return zone;
        };

        const leftZone = createZone('jw-side-zone-left', -10, 'left', '« 10s');
        const rightZone = createZone('jw-side-zone-right', 10, 'right', '10s »');

        playerContainer.appendChild(leftZone);
        playerContainer.appendChild(rightZone);

        /* --- Control Bar Buttons --- */
        const createControlBtn = (label, onClick) => {
            const btn = document.createElement('button');
            btn.textContent = label;
            btn.className = 'custom-control-button';
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                onClick();
            });
            return btn;
        };

        const rewindBar = createControlBtn('« 10s', () => safeSeek(-10));
        const forwardBar = createControlBtn('10s »', () => safeSeek(10));

        const playPause = playButtonContainer.querySelector('.jw-icon-playback');
        if (playPause) {
            playPause.parentNode.insertBefore(rewindBar, playPause.nextSibling);
            playPause.parentNode.insertBefore(forwardBar, rewindBar.nextSibling);
        } else {
            playButtonContainer.prepend(forwardBar);
            playButtonContainer.prepend(rewindBar);
        }

        /* --- Top-Right Fullscreen --- */
        const topRight = document.createElement('div');
        topRight.className = 'jw-top-right-controls';

        const fsBtn = document.createElement('button');
        fsBtn.innerHTML = '⛶';
        fsBtn.title = 'Toggle Fullscreen';
        fsBtn.setAttribute('aria-label', 'Toggle Fullscreen');

        fsBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            try {
                player.setFullscreen(!player.getFullscreen());
            } catch (err) {}
        });

        player.on('fullscreen', (event) => {
            fsBtn.innerHTML = event.fullscreen ? '⛶̽' : '⛶';
            fsBtn.title = event.fullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen';
        });

        try {
            if (player.getFullscreen()) {
                fsBtn.innerHTML = '⛶̽';
                fsBtn.title = 'Exit Fullscreen';
            }
        } catch (e) {}

        topRight.appendChild(fsBtn);
        playerContainer.appendChild(topRight);

        /* --- Keyboard Shortcuts --- */
        const keyHandler = (e) => {
            if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
            const isPlayerFocused = playerContainer.contains(document.activeElement);
            let isFullscreen = false;
            try { isFullscreen = player.getFullscreen(); } catch (e) {}
            if (!isPlayerFocused && !isFullscreen) return;

            e.preventDefault();
            e.stopPropagation();
            const offset = e.key === 'ArrowLeft' ? -10 : 10;
            safeSeek(offset);
            showFixedFeedback(e.key === 'ArrowLeft' ? 'left' : 'right');
        };
        document.addEventListener('keydown', keyHandler);

        /* Cleanup */
        const cleanup = new MutationObserver(() => {
            if (!document.body.contains(playerContainer)) {
                document.removeEventListener('keydown', keyHandler);
                cleanup.disconnect();
            }
        });
        cleanup.observe(document.body, { childList: true, subtree: true });

        console.log('JW Player side zones + flat feedback + visible reveal added.');
    }

    init();
})();
