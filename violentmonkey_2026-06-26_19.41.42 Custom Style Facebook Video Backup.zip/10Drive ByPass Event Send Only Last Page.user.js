// ==UserScript==
// @name         10Drive ByPass Event Send Only Last Page
// @namespace    BlazeFTL
// @match        *://gamesmain.xyz/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    "use strict";

    const observer = new MutationObserver((mutations) => {

        for (const m of mutations) {
            for (const node of m.addedNodes) {

                if (node.tagName === "IFRAME" && node.srcdoc) {

                    if (node.srcdoc.includes("safe-download-now")) {

                        node.srcdoc = node.srcdoc.replace(
                            "</script>",
                            `
                            setTimeout(()=>{
                                parent.postMessage({type:"third-safe-start"},"*");
                                setTimeout(()=>{
                                    parent.postMessage({type:"third-safe-download"},"*");
                                },200);
                            },500);
                            </script>`
                        );

                    }

                }

            }
        }

    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });

})();