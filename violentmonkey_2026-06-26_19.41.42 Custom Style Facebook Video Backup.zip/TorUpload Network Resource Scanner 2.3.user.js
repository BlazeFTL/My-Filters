// ==UserScript==
// @name         TorUpload Network Resource Scanner 2.3
// @namespace    https://github.com/BlazeFTL
// @description  Mobile-optimized dragging with 1.5 UI and bold text visibility.
// @version      2.3
// @author       BlazeFTL
// @match        *://*/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const style = document.createElement('style');
    style.innerHTML = `
        #scanner-ui {
            position: fixed;
            top: 20px;
            right: 20px;
            width: 350px; /* Slightly narrower for mobile screens */
            max-height: 500px;
            background: #f8f9ff;
            color: #333;
            z-index: 9999999;
            font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
            font-size: 12px;
            display: flex;
            flex-direction: column;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid #e0e4f5;
            user-select: none;
            touch-action: none; /* Crucial for mobile dragging */
        }
        #scanner-header {
            padding: 15px;
            background: linear-gradient(135deg, #6a5af9 0%, #d66efd 100%);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            touch-action: none; /* Prevents page scroll when dragging */
        }
        #scanner-title {
            font-weight: 700;
            font-size: 14px;
            pointer-events: none;
        }
        #scanner-controls {
            display: flex;
            gap: 8px;
        }
        .ui-btn {
            cursor: pointer;
            background: rgba(255,255,255,0.2);
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 700;
            border: none;
            color: white;
        }
        #scanner-content {
            overflow-y: auto;
            padding: 12px;
            flex-grow: 1;
            background: #fdfdff;
            user-select: text;
            touch-action: pan-y; /* Allows scrolling the list on mobile */
        }
        .category-card {
            background: white;
            border-radius: 8px;
            border: 1px solid #ebeef5;
            margin-bottom: 12px;
            overflow: hidden;
        }
        .category-label {
            padding: 8px 12px;
            background: #f0f2f9;
            font-weight: 700;
            color: #5a67d8;
            font-size: 10px;
            text-transform: uppercase;
            border-bottom: 1px solid #ebeef5;
            display: flex;
            justify-content: space-between;
        }
        .resource-entry {
            padding: 10px 12px;
            word-break: break-all;
            font-family: 'Consolas', monospace;
            font-size: 11px;
            color: #000; /* Max contrast */
            font-weight: 800; /* Max visibility */
            border-bottom: 1px solid #f0f0f0;
        }
        .resource-entry:nth-child(even) { background: #fafaff; }
    `;
    document.head.appendChild(style);

    const container = document.createElement('div');
    container.id = 'scanner-ui';
    container.innerHTML = `
        <div id="scanner-header">
            <span id="scanner-title">Resource Scanner</span>
            <div id="scanner-controls">
                <button id="copy-resources" class="ui-btn">COPY</button>
                <button id="close-scanner" class="ui-btn">✕</button>
            </div>
        </div>
        <div id="scanner-content">Initializing...</div>
    `;
    document.body.appendChild(container);

    const content = container.querySelector('#scanner-content');
    const copyBtn = container.querySelector('#copy-resources');

    function isExcluded(urlStr) {
        try {
            const url = new URL(urlStr, window.location.origin);
            const host = url.hostname;
            const currentHost = window.location.hostname;
            return (host === currentHost || host.endsWith('.' + currentHost) || host.includes('google') || host.includes('gstatic'));
        } catch (e) { return true; }
    }

    function getSortedResources() {
        const categories = { script: new Set(), xmlhttprequest: new Set(), fetch: new Set(), img: new Set(), other: new Set() };
        document.querySelectorAll('script[src], img[src], link[href], iframe[src], object[data]').forEach(el => {
            const url = el.src || el.href || el.data;
            if (url && !isExcluded(url)) {
                const tag = el.tagName.toLowerCase();
                if (tag === 'script') categories.script.add(url);
                else if (tag === 'img') categories.img.add(url);
                else categories.other.add(`[${tag}] ${url}`);
            }
        });
        performance.getEntriesByType('resource').forEach(entry => {
            if (!isExcluded(entry.name)) {
                if (categories[entry.initiatorType]) categories[entry.initiatorType].add(entry.name);
                else categories.other.add(`[${entry.initiatorType}] ${entry.name}`);
            }
        });
        return categories;
    }

    function updateUI() {
        const data = getSortedResources();
        let html = '';
        const order = [{id:'script', l:'Scripts'}, {id:'xmlhttprequest', l:'XHR'}, {id:'fetch', l:'Fetch'}, {id:'img', l:'Images'}, {id:'other', l:'Other'}];
        order.forEach(cat => {
            if (data[cat.id].size > 0) {
                html += `<div class="category-card">
                    <div class="category-label"><span>${cat.l}</span><span>${data[cat.id].size}</span></div>
                    ${Array.from(data[cat.id]).map(url => `<div class="resource-entry">${url}</div>`).join('')}
                </div>`;
            }
        });
        content.innerHTML = html || 'Scanning...';
    }

    // Mobile & PC Drag Logic
    let isDragging = false;
    let offset = { x: 0, y: 0 };
    const header = container.querySelector('#scanner-header');

    const startDrag = (e) => {
        if (e.target.tagName === 'BUTTON') return;
        isDragging = true;
        const rect = container.getBoundingClientRect();
        const clientX = e.type === 'touchstart' ? e.touches[0].clientX : e.clientX;
        const clientY = e.type === 'touchstart' ? e.touches[0].clientY : e.clientY;

        offset.x = clientX - rect.left;
        offset.y = clientY - rect.top;
        container.style.right = 'auto';
    };

    const doDrag = (e) => {
        if (!isDragging) return;
        const clientX = e.type === 'touchmove' ? e.touches[0].clientX : e.clientX;
        const clientY = e.type === 'touchmove' ? e.touches[0].clientY : e.clientY;

        container.style.left = (clientX - offset.x) + 'px';
        container.style.top = (clientY - offset.y) + 'px';
        if (e.type === 'touchmove') e.preventDefault(); // Stop page scroll
    };

    const stopDrag = () => { isDragging = false; };

    header.addEventListener('mousedown', startDrag);
    header.addEventListener('touchstart', startDrag, { passive: false });
    window.addEventListener('mousemove', doDrag);
    window.addEventListener('touchmove', doDrag, { passive: false });
    window.addEventListener('mouseup', stopDrag);
    window.addEventListener('touchend', stopDrag);

    copyBtn.onclick = () => {
        const data = getSortedResources();
        let text = "";
        Object.entries(data).forEach(([key, set]) => {
            if(set.size > 0) text += `[${key.toUpperCase()}]\n${Array.from(set).join('\n')}\n\n`;
        });
        navigator.clipboard.writeText(text).then(() => {
            copyBtn.innerText = "DONE!";
            setTimeout(() => copyBtn.innerText = "COPY", 1000);
        });
    };

    setInterval(updateUI, 2000);
    container.querySelector('#close-scanner').onclick = () => container.remove();

})();
