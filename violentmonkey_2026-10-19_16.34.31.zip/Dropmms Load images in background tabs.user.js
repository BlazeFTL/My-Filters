// ==UserScript==
// @name     Dropmms Load images in background tabs
// @match    https://dropmms.co/*
// @match    https://*.dropmms.co/*
// @match    https://dropmms.com/*
// @match    https://*.dropmms.com/*
// @match    https://dropmms.net/*
// @match    https://*.dropmms.net/*
// @icon     data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%2064%2064%22%3E%3Crect%20width=%2264%22%20height=%2264%22%20rx=%2214%22%20fill=%22%231565a8%22/%3E%3Cpath%20d=%22M32%208C32%208%2014%2028%2014%2040a18%2018%200%200%200%2036%200C50%2028%2032%208%2032%208Z%22%20fill=%22%23e6208c%22/%3E%3Cpath%20d=%22M26%2033H31A7.5%207.5%200%200%201%2031%2048H26Z%22%20fill=%22none%22%20stroke=%22%23fff%22%20stroke-width=%224%22%20stroke-linejoin=%22round%22/%3E%3C/svg%3E
// @run-at   document-idle
// ==/UserScript==
const kick = img => {
  const src = img.dataset.src;
  if (src && img.src !== src) img.src = src;
  img.loading = 'eager';
};
const scan = () => document.querySelectorAll('img[data-src]').forEach(kick);
scan();
new MutationObserver(scan).observe(document.documentElement,
  { subtree: true, childList: true, attributes: true, attributeFilter: ['data-src'] });
