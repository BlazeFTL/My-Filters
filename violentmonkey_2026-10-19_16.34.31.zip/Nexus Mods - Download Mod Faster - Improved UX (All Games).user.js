// ==UserScript==
// @name         Nexus Mods - Download Mod Faster - Improved UX (All Games)
// @namespace    https://bitbucket.org/antonolsson91/nexus-mods-stardew-valley-improved-ux/
// @version      2.2
// @description  Adds instant-download buttons for each available file under the "files" tab for a mod on NexusMods
// @author       TetteDev
// @license      GPL version 3 or any later version; http://www.gnu.org/copyleft/gpl.html
// @require      https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js
// @match        https://www.nexusmods.com/*/mods/*?tab=files
// @grant        none
// @run-at       document-end
// @noframes
// @downloadURL https://update.greasyfork.org/scripts/498063/Nexus%20Mods%20-%20Download%20Mod%20Faster%20-%20Improved%20UX%20%28All%20Games%29.user.js
// @updateURL https://update.greasyfork.org/scripts/498063/Nexus%20Mods%20-%20Download%20Mod%20Faster%20-%20Improved%20UX%20%28All%20Games%29.meta.js
// ==/UserScript==

(($) => {
	window.Utils = {
		gameId: resolveGameId(),
		fastDownload: (file_id, game_id) => {
			if (file_id === undefined) throw new Error();
			if (game_id === undefined) throw new Error();

			$.ajax({
				type: "POST",
				url: "/Core/Libs/Common/Managers/Downloads?GenerateDownloadUrl",
				data: {
					fid: file_id,
					game_id: game_id,
				},
				success: function (data, error) {
					if (data && data.url) {
						console.log(data.url);
						window.open(data.url);
					} else {
						debugger;
						console.trace("Error posting:", error);
						alert("Something went wrong, inform TetteDev on Greasyfork!");
					}
				},
				error: function (e) {
					debugger;
					console.trace(e);
					alert("Something went wrong, inform TetteDev on Greasyfork!");
				}
			});
		},
		init: () => {
			const files = document.querySelectorAll('dl');
			files.forEach((dl, index) => {
				const dts = dl.querySelectorAll('dt');

				dts.forEach((dt, index) => {
					const file_id = dt.id.split('file-expander-header-')[1].trim();
					const game_id = window.Utils.gameId;

					waitForElement('.accordion-downloads', { root: dt.nextElementSibling, timeout: 5000 }).then(insert_element => {
						// assert tag type of insert_element is 'dd'
						const button_id = randomElementId();
						insert_element.insertAdjacentHTML('beforeend', `<div id="${button_id}" style="color:white;background-color:green;width:fit-content;" class="flex flex-wrap gap-x-5 gap-y-2.5"><button class="nxm-button nxm-button-secondary min-h-8.5" type="button"><svg viewBox="0 0 24 24" role="presentation" class="shrink-0 nxm-button-icon"><path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z" style="fill: currentcolor;"></path></svg><span>Direct Download</span></button></div>`);

						const download_button = insert_element.querySelector(`#${button_id}`);
						console.log(button_id);
						download_button.addEventListener('click', (e) => {
							e.stopImmediatePropagation();
							e.preventDefault();

							if (!(typeof window.USER_ID !== 'undefined')) { alert('Please login to your nexusmod account first!'); return; }

							window.Utils.fastDownload(file_id, game_id);
						}, { capture: true });
					}).catch(err => {
						console.error(err);
						alert("Something went wrong, inform TetteDev on Greasyfork!");
					});
				})
			});
		},
	};
	window.Utils.init();

	function resolveGameId() {
		try { return parseInt(Object.keys(window.GlobalModStats)[0]); }
		catch (err) {
			debugger;
			console.error(err);
			alert("Something went wrong, inform TetteDev on Greasyfork!");
			return -1;
		}
	}
	function waitForElement(selector, { root = document, timeout = 5000, signal } = {}) {
		const existing = root.querySelector(selector);
		if (existing) return Promise.resolve(existing);
		return new Promise((resolve, reject) => {
			if (signal?.aborted) return reject(signal.reason ?? new DOMException("Aborted", "AbortError"));

			const obs = new MutationObserver(() => {
				const el = root.querySelector(selector);
				if (el) {
					cleanup();
					resolve(el);
				}
			});

			let t = timeout != null ? setTimeout(() => { cleanup(); reject(new Error(`Timeout waiting for: ${selector}`)); }, timeout) : null;
			const onAbort = () => { cleanup(); reject(signal.reason ?? new DOMException("Aborted", "AbortError")); };
			if (signal) signal.addEventListener("abort", onAbort, { once: true });

			function cleanup() {
				obs.disconnect();
				if (t) clearTimeout(t);
				if (signal) signal.removeEventListener("abort", onAbort);
			}
			obs.observe(root === document ? document.documentElement : root, { childList: true, subtree: true });
		});
	}
	function randomElementId(prefix = "fast-download") {
		const a = new Uint32Array(2);
		crypto.getRandomValues(a);
		return `${prefix}-${a[0].toString(36)}${a[1].toString(36)}`;
	}
})(jQuery);