// ==UserScript==
// @name         vhit.io Mock & Bypass
// @namespace    vhit-mock
// @version      1.0
// @description  Blocks vhit tracking and mocks its API to satisfy anti-adblock checks
// @match        *://*.upfilesgo.com/*
// @match        *://*.upfion.com/*
// @match        *://*.upfiles.app/*
// @match        *://*.upfiles-urls.com/*
// @icon          data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAclBMVEVHcEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuN+QrNeUtN+QsNuU7Q+clMOUdKuTFx/f///+bnvF/hO7W1/r5+f8UI+SwsvRQWOkuOOX////p6vwtN+UtN+UtNuUtN+UwNePgPcbzAAAAJnRSTlMA4P+JYy3KQPKocOdQDENZwf/7/v7p8Obi6OD+5ez3/+x7tCXWEG4QoRIAAAEsSURBVHgBrM4HCoBADETRybY0vf91xcIaNCDFRx8+MDhQuVTkqPXTaMiwaLMdQ6vdGKfuRL6TguoTeVlwWBkXVURueFKhoBhelhaIzTnDoBkMT4zwYU2FQEdCQ2A1YSHI/RDIV8B9E4jk48cD+ABl0AWiwyAQBNAeIcsKzvCl979iN7XYRIGHOljIE9hfvL6ZWDiQ+K9neQFWi0KcLOUSam7Jiva6A6MgC0mDxVgKYPCoXIGx1AiPqpt8BcWHFRet1j5RxhUE/++At1RF5gtACZIM5i2iUNmDOapkwAGAVKVmpG0E9qYZJz4AGhtmpQ0kA1AM9gJraQ7aAElXTZxmYnZQgs52OElPrUw8hLgbioj/fcEPHbIeOPt3A7ffs5Ct8LuCv/+T2H6X++0BOtkvFeq3h8AAAAAASUVORK5CYII=
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // If something already defined it, don't overwrite
    if (window.vhit && window.vhit.__mocked) return;

    const noop = function() {};

    const mockVhit = {
        // Returns false = "no adblock detected"
        // If the site uses await/.then(), change the next line to:
        // detectAdblock: function() { return Promise.resolve(false); },
        detectAdblock: function() {
    var result = false;
    // Thenable wrapper in case they use .then()
    return {
        then: function(cb) { if (typeof cb === 'function') cb(result); return this; },
        catch: function() { return this; },
        valueOf: function() { return result; }
    };
},

        // No-op tracking functions
        report: noop,
        trackPage: noop,

        __mocked: true
    };

    // Lock it so the real script (if it somehow slips through) can't overwrite easily
    try {
        Object.defineProperty(window, 'vhit', {
            value: mockVhit,
            writable: false,
            configurable: false,
            enumerable: true
        });
    } catch (e) {
        window.vhit = mockVhit;
    }
})();
