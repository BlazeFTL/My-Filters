// ==UserScript==
// @name         Decompiler AdBlock Detection Bypass
// @namespace    BlazeFTL
// @match        *://decompiler.com/*
// @match        *://*.decompiler.com/*
// @grant        GM_xmlhttpRequest
// @connect      media.ethicalads.io
// @connect      server.ethicalads.io
// @connect      ethicalads.io
// @run-at       document-start
// ==/UserScript==
(function(){
  if (typeof GM_xmlhttpRequest === "undefined") return;
  var cache = {};
  function isAdUrl(u){
    return typeof u === "string" && /ethicalads\.io/.test(u);
  }
  function fetchBlob(url){
    if (cache[url]) return cache[url];
    cache[url] = new Promise(function(resolve, reject){
      GM_xmlhttpRequest({
        method: "GET",
        url: url,
        responseType: "blob",
        onload: function(r){
          if (r.status >= 200 && r.status < 300 && r.response) {
            resolve(URL.createObjectURL(r.response));
          } else {
            reject(new Error("status " + r.status));
          }
        },
        onerror: reject,
        ontimeout: reject
      });
    });
    return cache[url];
  }
  var desc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, "src")
    || Object.getOwnPropertyDescriptor(Object.getPrototypeOf(HTMLImageElement.prototype), "src");
  Object.defineProperty(HTMLImageElement.prototype, "src", {
    configurable: true,
    enumerable: true,
    get: desc.get,
    set: function(v){
      if (isAdUrl(v)) {
        var el = this;
        fetchBlob(v).then(function(blobUrl){
          desc.set.call(el, blobUrl);
        }).catch(function(){
          desc.set.call(el, v);
        });
        return;
      }
      desc.set.call(this, v);
    }
  });
})();
