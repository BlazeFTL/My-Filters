// ==UserScript==
// @name        HushFacebook Web
// @namespace   https://github.com/SysAdminDoc/HushFacebookWeb
// @version     0.0.2
// @description Takes ads, suggested posts and Meta AI out of Facebook on the web, and adds download, privacy and playback controls.
// @author      SysAdminDoc
// @license     MIT
// @icon        data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAHSElEQVR4nNRaCWxURRj+5r3dlhaWLWjpwRlAMMghhwoCIeEw0eARi1diAjGKSAIGE4khmoI2xBBjDUY80IgxliNqPIIgYCDRxirUcFqIKdgWWtpC2y3tdne7+8Z/Xnf3HbvvvV1sgX5Jd2bezD/z/zP//88/M5XQzyGhn8Pl2GIjdxV2dxWBYS5n0jhwnk15gNNfX6SAnzFWjYhSXu/O+gYbWRg2YHaVha93FVPP68CYN/6Rm6j6sMw493Gw0vqSrE1AGgLkbbg2WZLkHZSd2WcznV5aqSiRFY2bPacdBRDMy5J8gHMUMKrluo5uZplxNER45AGzEAk2IEHawTkvEB0I2p6fnvRmlsWECt4oO8vIrw6FG4TOk9rEF+YWSxmbmb+hsxg6aCpE3iY/2HmFcl7LNTWnN6Geg/saMwfeHvNOcRXKC3SQq5S82hoyLRstD86SMGKIC5kupq9Ae0BBdVM3jEikz/XIKr0ZzR0RXGwJO9JHf72C10Zgt0EAxqS5ccVj3Dgh0Z4EA0KIoqncNJiEyhoZv50nRlqt6VXh3SyBPqJIOFYj4evjEdvxtYURvJoEIIyL58z86TApD1g2LfH7smkulO5rxdYKjy29YD6RnuGp6W7U1jbgz6vDbOnNvMaNmCtKNldIw7juz1QW+mjXd3fdcfgrPrehhy0CZ/Yh+M9hS3qtrGTHaJxDiVsQjGs2aBQgrm8WXiFVWPaTCi135EPHf7IVcPLJqeJ66VPdG3oQF0Ah/XIaQnXJThOpmkoaq5VAzh3pma5aSsj0M2grwKP7HIyLZCw7z6zYPAe47Ogd1lldZW5J0aMEVkacpPt0Nd9DG930sQNhz2HqSMaPvgdNAK5EJePWzR3GfvrhmVgw5y54cq0b5g6CA/Q2YMWP9s1iH3AQxAKjCobSH7D+uxDCEWOdSwa2PJaB1JD6+HEBaAFIf2ONtDQWA6aK6isKdh5Nfox9cZ4L4253cBcGGzCPr4uJzAJY6Xq6NiAY/PuNLJg9oTBuz4B0e3MeX1sBOMcqqfj3mhYFi7cGEeg2th1AUeihtZkYPdR+BXgq4+iqez0WGp7DsHCiRCGy8bss9dT1NnReKJYIX2Q4AenKuoZWHUoMHz+TieuGKRay5scsQBTMlEtnzmobWlBX32bbZmRhjuqtnJF8fHNZswFuNcOp7wO7fqzElu2HbNusf2Ex1q9cYtvGaAPmvJEJm2jUqmwPKWc0MqY/m7Tunjs8GHsv0kQiP/ovmgDC6JhTLIQU9jNuE8uIuuQT4vNzNMtjyNeOQCTYTfcLxKhEli+xBH7A+zAWcuovGUp/9uPdfV2YNv4+LBnjpv0CdDnAcbgqhKZ2ksEtqQIl608XjSopnAdS2JHTPA+s+bIDJ+u6UbZ6MOZPcOPguQgYhSGrF0vIzhiEDw758db3fhJC1gmRJBaSEA1TOdeJmaScFsz0RoiZF8x/u9aLqkaOh7YF0OIHJuRLKP4piPvHuVCyNAsFOTJWf3ENcoYbPfcqWh/xbVHdd2K3DjFjV8tcp9bOM2tPr0HovFCbkmWDsL8qgncOhjB7DN053S3jtUUu5A2W4aHtpGh7AI/PysTyeQOgUIQoulGSnch0c2Yqa7rn67B9a3CkD4S07XnviSCmjZJVtfmKgr+J+TIqLiiqYHv+iqgCn6eLzuxMhs9+D5MAWeq1irl/TQDO/Ya7lyTp5ZYgztZ0wg6xWCYZ/bm6TlxqDqrtzlyMYCYZ7CV6wsgbxPDSfBcKKdR4fq4LK2bLeGSqjBkjGd5cmoG9J8OYNFzGkIGk/SJGIV5j4+m8ED3rpKAiR86GsG4XQ0F7eUKd2MSYd5QlrViBsooQLtQ149QFPx6cM0Kd8do2jm2/hlF1WVFTgXr61hkib0QCtnX18DWQVsMX4FFeTQIwrpRT1RqDzXGTDUbLu/8IIFLbBcVXZ3D0gnkpd7Km8Enoa6+GKeQIQ7nmw5Q7h2PMbQxeYuzVxW50hbiaCvxwKqKq35RCqN+F3je0kWpRXC4Rr3G+49ND1+tDGq+Q1nGvGrzHOFM56P2yUKthdLw8UTIUK8uCuNoBdXYLvUw9N5xuUKieoZ5WYPOjbnR2RvDcp+2QZMnXmpcbv17XbIA+UJ+lzveSvVMWgjQSc8LPv/9EBoXbHNNHSup54W06eo7IAYaSgE/OkLFgvIxtv/jVXZloS/UvlwkeOmdV0zGorzTRWq7XkV4ui6JCer/co7rK946EsedoSF2tfK+Mlxe6VeZfKevAzooACSBVtn04zPDElCDAkFWXJ3PODlC2oA81yFAWP8LPC1cpvI2A0Pn9J0PqzFf+GxabbJPE+KLWj/JP2woQFwLYQdU35pk1KonIClcpvI0wWPVUR9LSw3clg7LCzLylADHkrGws5uKhW303uwGIv4nFP5CVoLT9k7xNliRwAnknb0NjETWcy3teRrITJlDXWdIJTq/eT2k1peW+grz/968G/QH9/r9V/gMAAP//pYGH9gAAAAZJREFUAwAvw2lxTudtWwAAAABJRU5ErkJggg==
// @homepageURL https://github.com/SysAdminDoc/HushFacebookWeb
// @supportURL  https://github.com/SysAdminDoc/HushFacebookWeb/issues
// @updateURL   https://github.com/SysAdminDoc/HushFacebookWeb/releases/latest/download/hushfacebook-web.meta.js
// @downloadURL https://github.com/SysAdminDoc/HushFacebookWeb/releases/latest/download/hushfacebook-web.user.js
// @match       https://www.facebook.com/*
// @match       https://*.facebook.com/*
// @run-at      document-start
// @inject-into auto
// @sandbox     JavaScript
// @noframes
// @grant       GM_getValue
// @grant       GM_setValue
// @grant       GM_deleteValue
// @grant       GM_addValueChangeListener
// @grant       GM_registerMenuCommand
// @grant       GM_download
// @grant       GM_xmlhttpRequest
// @grant       unsafeWindow
// @connect     fbcdn.net
// @connect     facebook.com
// ==/UserScript==

(() => {
  // src/core/env.js
  var pageWindow = typeof unsafeWindow !== "undefined" ? unsafeWindow : globalThis;
  var version = true ? "0.0.2" : "dev";
  var info = typeof GM_info !== "undefined" ? GM_info : null;
  var pageAccess = info?.injectInto === "content" || info?.sandboxMode === "dom" ? "content" : "page";
  function managerInfo() {
    return {
      manager: info?.scriptHandler ?? "unknown",
      managerVersion: info?.version ?? "unknown",
      mode: info?.injectInto ?? info?.sandboxMode ?? "unknown",
      pageAccess
    };
  }
  function gmApi() {
    return {
      download: typeof GM_download === "function" ? GM_download : null,
      request: typeof GM_xmlhttpRequest === "function" ? GM_xmlhttpRequest : null
    };
  }
  function registerMenuCommand(label, handler) {
    if (typeof GM_registerMenuCommand === "function") GM_registerMenuCommand(label, handler);
  }
  function whenRootReady(fn, doc = globalThis.document) {
    if (!doc || doc.documentElement) return fn();
    const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
    const observer = new Observer(() => {
      if (!doc.documentElement) return;
      observer.disconnect();
      fn();
    });
    observer.observe(doc, { childList: true });
  }
  function whenBodyReady(fn, doc = globalThis.document) {
    if (doc.body) return fn();
    doc.addEventListener("DOMContentLoaded", () => fn(), { once: true });
  }

  // src/core/actions.js
  function createActions() {
    const byFeature = /* @__PURE__ */ new Map();
    return {
      // The handle a feature gets as ctx.actions.
      for(featureId) {
        return {
          add(label, run) {
            const list = byFeature.get(featureId) ?? [];
            list.push({ label, run });
            byFeature.set(featureId, list);
          }
        };
      },
      list(featureId) {
        return (byFeature.get(featureId) ?? []).map(({ label, run }) => ({ label: typeof label === "function" ? label() : label, run }));
      }
    };
  }

  // src/core/diagnostics.js
  var DECISIONS = 50;
  function postTag(id) {
    if (id === null || id === void 0 || id === "") return "no id yet";
    let hash = 2166136261;
    for (const char of String(id)) {
      hash ^= char.charCodeAt(0);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return `#${hash.toString(36).padStart(6, "0").slice(-6)}`;
  }
  function createDiagnostics({ now = () => Date.now() } = {}) {
    const rows = /* @__PURE__ */ new Map();
    const listeners = /* @__PURE__ */ new Set();
    const decisions = [];
    function changed() {
      for (const listener of listeners) {
        try {
          listener();
        } catch {
        }
      }
    }
    return {
      add(label, read) {
        rows.set(label, read);
        changed();
        return () => {
          rows.delete(label);
          changed();
        };
      },
      rows() {
        return [...rows].map(([label, read]) => {
          let value;
          try {
            value = String(read());
          } catch (error) {
            value = `unavailable (${error?.message ?? error})`;
          }
          return { label, value };
        });
      },
      // layer: 'data' when it came out of Facebook's data, 'page' when it was hidden on the page.
      decide({ post, rule, signal, layer }) {
        decisions.push({
          time: new Date(now()).toISOString().slice(11, 19),
          post: postTag(post),
          rule: String(rule),
          signal: signal === null || signal === void 0 ? "" : String(signal),
          layer: layer === "data" ? "data" : "page"
        });
        if (decisions.length > DECISIONS) decisions.splice(0, decisions.length - DECISIONS);
        changed();
      },
      // Oldest first.
      decisions: () => decisions.map((decision) => ({ ...decision })),
      changed,
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      }
    };
  }
  var decisionLine = ({ time, layer, post, rule, signal }) => `${time} ${layer.padEnd(4)} ${post} ${rule}${signal ? `: ${signal}` : ""}`;

  // src/core/dom/posts.js
  var CANDIDATE_SELECTOR = '[aria-posinset]:not([role]), [role="article"]';
  var ID_RUNGS = [
    { source: "permalink", re: /\/(?:posts|permalink)\/(pfbid0[A-Za-z0-9]+|\d+)/ },
    { source: "pfbid", re: /(pfbid0[A-Za-z0-9]+)/ },
    { source: "story_fbid", re: /[?&]story_fbid=(pfbid0[A-Za-z0-9]+|\d+)/ }
  ];
  var COMMENT_ID = /[?&](?:reply_comment_id|comment_id)=(\d+)/;
  var COMMENT_PARAM = /([?&])(?:reply_comment_id|comment_id)=\d+(&|$)/;
  var COMMENT_LABEL = /^(?:comment|reply) by /i;
  var FACEBOOK_LINK = /^(?:\/(?!\/)|\?|(?:https?:)?\/\/(?:(?:www|web|m|mbasic|[a-z]{2}-[a-z]{2})\.)?facebook\.com(?::443)?(?:\/|$))/i;
  var MESSAGE_REGION = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"]';
  var ownerOf = (node) => node.closest(CANDIDATE_SELECTOR);
  function ownLinks(element) {
    return [...element.querySelectorAll("a[href]")].filter((a) => ownerOf(a) === element);
  }
  function withoutCommentParams(href) {
    let previous;
    do {
      previous = href;
      href = href.replace(COMMENT_PARAM, (match, lead, tail) => tail ? lead : "");
    } while (href !== previous);
    return href;
  }
  function postIdFromHrefs(hrefs) {
    const links = hrefs.filter((href) => FACEBOOK_LINK.test(href));
    const withoutComments = links.map(withoutCommentParams);
    for (const { source, re } of ID_RUNGS) {
      for (const href of withoutComments) {
        const found = href.match(re);
        if (found) return { id: found[1], source };
      }
    }
    for (const href of links) {
      const found = href.match(COMMENT_ID);
      if (found) return { id: found[1], source: "comment_id" };
    }
    return { id: null, source: null };
  }
  function idHrefs(element) {
    return ownLinks(element).filter((a) => {
      const region = a.closest(MESSAGE_REGION);
      return !region || !element.contains(region);
    }).map((a) => a.getAttribute("href"));
  }
  function postIdOf(element) {
    return postIdFromHrefs(idHrefs(element));
  }
  function isComment(element) {
    if (element.getAttribute("role") !== "article") return false;
    if (COMMENT_LABEL.test(element.getAttribute("aria-label") ?? "")) return true;
    return ownLinks(element).some((a) => COMMENT_ID.test(a.getAttribute("href")));
  }
  function classifyCandidate(element) {
    if (!element.isConnected) return { ok: false, reason: "detached", retry: false };
    if (element.parentElement && ownerOf(element.parentElement)) return { ok: false, reason: "nested", retry: false };
    if (element.closest("form")) return { ok: false, reason: "form", retry: false };
    if (isComment(element)) return { ok: false, reason: "comment", retry: false };
    const hasLinks = element.querySelector("a[href]") !== null;
    if (!hasLinks && element.querySelector('[role="progressbar"]')) return { ok: false, reason: "loading", retry: true };
    if (!hasLinks && !element.textContent.trim() && !element.querySelector("img, video, svg")) return { ok: false, reason: "empty", retry: true };
    return { ok: true, kind: element.hasAttribute("aria-posinset") ? "feed" : "article" };
  }
  function createPostTracker({ doc = globalThis.document, log } = {}) {
    let processed = /* @__PURE__ */ new WeakSet();
    const live = /* @__PURE__ */ new Map();
    const listeners = { "post/add": /* @__PURE__ */ new Set(), "post/update": /* @__PURE__ */ new Set(), "post/remove": /* @__PURE__ */ new Set(), reset: /* @__PURE__ */ new Set() };
    let observer = null;
    function call(type, listener, payload) {
      try {
        listener(payload);
      } catch (error) {
        log?.error(`A ${type} listener failed`, error);
      }
    }
    function emit(type, payload) {
      for (const listener of listeners[type]) call(type, listener, payload);
    }
    function remove(element, post) {
      live.delete(element);
      processed.delete(element);
      emit("post/remove", post);
    }
    function recheck(element) {
      const post = live.get(element);
      const hrefs = idHrefs(element);
      const { id, source } = postIdFromHrefs(hrefs);
      if (id === post.id || id === null) return;
      if (post.id === null) {
        post.id = id;
        post.idSource = source;
        emit("post/update", post);
        return;
      }
      if (post.idSource === "comment_id" && source !== "comment_id" && hrefs.some((href) => href.includes(post.id))) {
        post.id = id;
        post.idSource = source;
        emit("post/update", post);
        return;
      }
      if (hrefs.some((href) => href.includes(post.id))) return;
      remove(element, post);
      add(element, post.kind);
    }
    function add(element, kind) {
      for (const inner of element.querySelectorAll(CANDIDATE_SELECTOR)) {
        const nested = live.get(inner);
        if (!nested) continue;
        remove(inner, nested);
        processed.add(inner);
      }
      const { id, source } = postIdOf(element);
      const post = { element, kind, id, idSource: source };
      processed.add(element);
      live.set(element, post);
      emit("post/add", post);
    }
    function consider(element) {
      if (processed.has(element)) {
        if (live.has(element)) recheck(element);
        return;
      }
      const verdict = classifyCandidate(element);
      if (verdict.ok) add(element, verdict.kind);
    }
    function collect(root, found) {
      if (root.nodeType !== 1) root = root.parentElement;
      if (!root?.isConnected) return;
      const owner = ownerOf(root);
      if (owner) found.add(owner);
      for (const element of root.querySelectorAll(CANDIDATE_SELECTOR)) found.add(element);
    }
    function scan(root) {
      const found = /* @__PURE__ */ new Set();
      collect(root, found);
      for (const element of found) consider(element);
    }
    function sweepRemovals() {
      if (!live.size) return;
      for (const [element, post] of [...live]) if (!element.isConnected) remove(element, post);
      if (!live.size) emit("reset", void 0);
    }
    function release(element, found) {
      const post = live.get(element);
      if (!post || element.matches(CANDIDATE_SELECTOR)) return;
      remove(element, post);
      for (const inner of element.querySelectorAll(CANDIDATE_SELECTOR)) {
        processed.delete(inner);
        found.add(inner);
      }
    }
    function onMutations(records) {
      let removals = false;
      const found = /* @__PURE__ */ new Set();
      for (const record of records) {
        if (record.removedNodes.length) removals = true;
        if (record.addedNodes.length) for (const node of record.addedNodes) collect(node, found);
        else if (record.type === "attributes") {
          release(record.target, found);
          collect(record.target, found);
        }
      }
      if (removals) sweepRemovals();
      for (const element of found) if (element.isConnected) consider(element);
    }
    function start() {
      if (observer) return;
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      observer = new Observer((records) => {
        try {
          onMutations(records);
        } catch (error) {
          log?.error("Reading new posts failed", error);
        }
      });
      const begin = () => {
        observer.observe(doc.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["href", "aria-posinset", "role"] });
        scan(doc.body);
      };
      if (doc.body) begin();
      else doc.addEventListener("DOMContentLoaded", begin, { once: true });
    }
    return {
      // type: 'post/add' | 'post/update' | 'post/remove' | 'reset'. Returns an unsubscribe.
      // A post/add listener that joins late hears about the posts already on the page first.
      on(type, listener) {
        if (!listeners[type]) throw new Error(`Unknown post event: ${type}`);
        listeners[type].add(listener);
        if (!observer) start();
        else if (type === "post/add") for (const post of [...live.values()]) call(type, listener, post);
        return () => listeners[type].delete(listener);
      },
      current: () => [...live.values()],
      // Stops watching and forgets every post. A later on() starts over and reports them again.
      stop() {
        observer?.disconnect();
        observer = null;
        live.clear();
        processed = /* @__PURE__ */ new WeakSet();
      }
    };
  }

  // src/core/dom/hide.js
  var MARK = "data-hfw-hide";
  var NOTE = "data-hfw-note";
  var HOLDER = `:has(> [${MARK}])`;
  var REPLACED = /* @__PURE__ */ new Set(["IMG", "VIDEO", "IFRAME", "CANVAS", "INPUT", "TEXTAREA", "SELECT", "OBJECT", "EMBED", "svg", "STYLE", "SCRIPT", "TEMPLATE", "LINK", "META"]);
  function hideCss({ notes }) {
    if (!notes) return `${HOLDER} { display: none !important; }`;
    return [
      `${HOLDER} > :not([${MARK}]) { display: none !important; }`,
      `[${MARK}] > * { display: none !important; }`,
      // Loose text right inside the mark has no element to hide, so it shrinks to nothing.
      `[${MARK}] { font-size: 0 !important; }`,
      `[${MARK}]::before { content: attr(${NOTE}); display: block; padding: 10px 16px; font: 13px/1.4 system-ui, sans-serif; color: var(--secondary-text, #65676b); cursor: pointer; }`
    ].join("\n");
  }
  function createHider({ doc = globalThis.document, posts, log, notesShown = () => true, onHide } = {}) {
    const counts = /* @__PURE__ */ new Map();
    const countedIds = /* @__PURE__ */ new Set();
    const countedElements = /* @__PURE__ */ new WeakSet();
    const revealed = /* @__PURE__ */ new WeakSet();
    const marks = /* @__PURE__ */ new WeakSet();
    const labels = /* @__PURE__ */ new WeakMap();
    const listeners = /* @__PURE__ */ new Set();
    let watching = false;
    const markOf = (element) => [...element.children].find((child) => child.hasAttribute(MARK)) ?? null;
    function notify() {
      for (const listener of listeners) {
        try {
          listener();
        } catch (error) {
          log?.error("A hidden-post listener failed", error);
        }
      }
    }
    function clear(element) {
      for (const child of element.children) {
        if (!child.hasAttribute(MARK)) continue;
        child.removeAttribute(MARK);
        child.removeAttribute(NOTE);
        labels.delete(child);
      }
    }
    function write(marker, reasons) {
      marker.setAttribute(MARK, [...reasons.keys()].join(" "));
      marker.setAttribute(NOTE, `Hidden: ${reasons.values().next().value}. Show`);
    }
    function reasonsOf(marker) {
      let reasons = labels.get(marker);
      if (!reasons) {
        reasons = new Map((marker.getAttribute(MARK) ?? "").split(/\s+/).filter(Boolean).map((reason) => [reason, reason]));
        labels.set(marker, reasons);
      }
      return reasons;
    }
    function count(element, reason) {
      const id = postIdOf(element).id;
      const seen = countedElements.has(element) || id !== null && countedIds.has(id);
      countedElements.add(element);
      if (id !== null) countedIds.add(id);
      if (seen) return false;
      counts.set(reason, (counts.get(reason) ?? 0) + 1);
      return true;
    }
    function watchRecycling() {
      if (watching || !posts) return;
      watching = true;
      posts.on("post/remove", ({ element }) => {
        revealed.delete(element);
        countedElements.delete(element);
        if (element.isConnected) clear(element);
      });
    }
    function onClick(event) {
      const marker = event.target;
      if (!marker?.hasAttribute?.(MARK) || !marks.has(marker) || !notesShown()) return;
      const post = marker.parentElement;
      if (!post) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      revealed.add(post);
      clear(post);
    }
    doc.addEventListener("click", onClick, true);
    return {
      // Hides a post found by the post tracker. reason is what Diagnostics counts
      // ("Sponsored", "Filter"); detail narrows it in the note ("Filter: cats"). signal says
      // what matched, for the decision list only, when detail doesn't already say it.
      // Returns false when the post can't be marked or the person chose to see it.
      hide(element, reason, detail, signal) {
        if (revealed.has(element)) return false;
        const marker = markOf(element) ?? element.firstElementChild;
        if (!marker || REPLACED.has(marker.tagName)) return false;
        watchRecycling();
        const reasons = marker.hasAttribute(MARK) ? reasonsOf(marker) : /* @__PURE__ */ new Map();
        const fresh = !reasons.has(reason);
        reasons.set(reason, detail ? `${reason}: ${detail}` : reason);
        labels.set(marker, reasons);
        write(marker, reasons);
        marks.add(marker);
        if (count(element, reason)) notify();
        if (fresh && onHide) {
          try {
            onHide({ element, reason, detail, signal });
          } catch (error) {
            log?.error("Noting a hidden post failed", error);
          }
        }
        return true;
      },
      show(element) {
        clear(element);
      },
      // Takes one reason off every post, for a feature that was just switched off. A post still
      // hidden for another reason stays hidden, under that one.
      showAll(reason) {
        for (const marker of doc.querySelectorAll(`[${MARK}]`)) {
          const reasons = reasonsOf(marker);
          if (!reasons.delete(reason)) continue;
          if (reasons.size) write(marker, reasons);
          else if (marker.parentElement) clear(marker.parentElement);
        }
      },
      isHidden: (element) => markOf(element) !== null,
      // Posts hidden since the page loaded, per reason.
      counts: () => Object.fromEntries(counts),
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      }
    };
  }

  // src/core/log.js
  var LEVELS = ["debug", "info", "warn", "error"];
  function createLog({ capacity = 400, sink = globalThis.console, now = () => /* @__PURE__ */ new Date() } = {}) {
    const entries = [];
    const listeners = /* @__PURE__ */ new Set();
    function write(level, message, detail) {
      const entry = { time: now().toISOString(), level, message: String(message) };
      if (detail !== void 0) entry.detail = describe(detail);
      entries.push(entry);
      if (entries.length > capacity) entries.shift();
      if (level !== "debug") sink?.[level]?.(`[HushFacebook Web] ${entry.message}`, ...detail === void 0 ? [] : [detail]);
      for (const listener of listeners) listener(entry);
      return entry;
    }
    const log = Object.fromEntries(LEVELS.map((level) => [level, (message, detail) => write(level, message, detail)]));
    log.entries = () => entries.slice();
    log.subscribe = (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    };
    return log;
  }
  function describe(detail) {
    if (detail instanceof Error) return `${detail.name}: ${detail.message}${detail.stack ? `
${detail.stack}` : ""}`;
    if (typeof detail === "string") return detail;
    try {
      return JSON.stringify(detail);
    } catch {
      return String(detail);
    }
  }

  // src/core/net/payload.js
  var DROP = /* @__PURE__ */ Symbol("hfw.drop");
  var GUARD = "for (;;);";
  function rulesFor(text, rules) {
    return rules.filter((rule) => !rule.markers || rule.markers.some((marker) => text.includes(marker)));
  }
  function transformDocumentLine(line, allRules, ctx, onError, parse3 = JSON.parse) {
    const rules = rulesFor(line, allRules);
    if (!rules.length) return line;
    let prefix = "";
    let body = line;
    if (body.startsWith(GUARD)) {
      prefix = GUARD;
      body = body.slice(GUARD.length);
    }
    const first = body.trimStart()[0];
    if (first !== "{" && first !== "[") return line;
    let doc;
    try {
      doc = parse3(body);
    } catch {
      return line;
    }
    let changed = false;
    for (const rule of rules) {
      let result;
      try {
        result = rule.transform(doc, ctx);
      } catch (error) {
        onError?.(rule, error);
        continue;
      }
      if (result === DROP) return null;
      if (result === true) changed = true;
    }
    return changed ? prefix + JSON.stringify(doc) : line;
  }
  function createLineStream(transformLine) {
    let pending = "";
    function emit(raw, newline) {
      const cr = raw.endsWith("\r") ? "\r" : "";
      const result = transformLine(cr ? raw.slice(0, -1) : raw);
      return result === null ? "" : result + cr + newline;
    }
    return {
      push(chunk) {
        pending += chunk;
        const end = pending.lastIndexOf("\n");
        if (end === -1) return "";
        const complete = pending.slice(0, end);
        pending = pending.slice(end + 1);
        return complete.split("\n").map((raw) => emit(raw, "\n")).join("");
      },
      flush() {
        const raw = pending;
        pending = "";
        return raw ? emit(raw, "") : "";
      }
    };
  }
  function friendlyNameOf(body, headers) {
    const header = headerValue(headers, "x-fb-friendly-name");
    if (header) return header;
    if (typeof body === "string") {
      if (!body.includes("fb_api_req_friendly_name")) return "";
      return new URLSearchParams(body).get("fb_api_req_friendly_name") ?? "";
    }
    if (body && typeof body.get === "function") return body.get("fb_api_req_friendly_name") ?? "";
    return "";
  }
  function headerValue(headers, name) {
    if (!headers) return "";
    if (typeof headers.get === "function") return headers.get(name) ?? "";
    if (Array.isArray(headers)) return headers.find(([key]) => key.toLowerCase() === name)?.[1] ?? "";
    for (const [key, value] of Object.entries(headers)) if (key.toLowerCase() === name) return value;
    return "";
  }

  // src/core/net/lightspeed.js
  var SHORT = /* @__PURE__ */ new Map([[9, 1], [10, 1], [14, 3]]);
  var WITH_BODY = /* @__PURE__ */ new Set([12, 13, 15]);
  var DATA = 13;
  function readFrames(bytes) {
    const frames = [];
    let at = 0;
    while (at < bytes.length) {
      const type = bytes[at];
      const size = SHORT.get(type);
      if (size) {
        if (at + size > bytes.length) return null;
        frames.push({ type, raw: bytes.subarray(at, at + size) });
        at += size;
        continue;
      }
      if (!WITH_BODY.has(type) || at + 6 > bytes.length) return null;
      const length = bytes[at + 3] | bytes[at + 4] << 8 | bytes[at + 5] << 16;
      if (at + 6 + length > bytes.length) return null;
      frames.push({ type, stream: bytes[at + 1] | bytes[at + 2] << 8, body: bytes.subarray(at + 6, at + 6 + length) });
      at += 6 + length;
    }
    return frames;
  }
  function writeFrames(frames) {
    const size = frames.reduce((sum, frame) => sum + (frame.raw ? frame.raw.length : 6 + frame.body.length), 0);
    const out = new Uint8Array(size);
    let at = 0;
    for (const frame of frames) {
      if (frame.raw) {
        out.set(frame.raw, at);
        at += frame.raw.length;
        continue;
      }
      const length = frame.body.length;
      out[at] = frame.type;
      out[at + 1] = frame.stream & 255;
      out[at + 2] = frame.stream >> 8 & 255;
      out[at + 3] = length & 255;
      out[at + 4] = length >> 8 & 255;
      out[at + 5] = length >> 16 & 255;
      out.set(frame.body, at + 6);
      at += 6 + length;
    }
    return out;
  }
  function frameJson(frame, decoder) {
    if (frame.type !== DATA || !frame.body || frame.body.length < 3 || frame.body[2] !== 123) return null;
    return decoder.decode(frame.body.subarray(2));
  }
  function withJson(frame, text, encoder) {
    const json = encoder.encode(text);
    const body = new Uint8Array(2 + json.length);
    body.set(frame.body.subarray(0, 2));
    body.set(json, 2);
    return { ...frame, body };
  }
  var BIG = "\0n:";
  var BIG_BACK = /"\\u0000n:(-?\d+)"/g;
  function protectBig(text) {
    let out = "";
    let last = 0;
    let at = 0;
    while (at < text.length) {
      const char = text[at];
      if (char === '"') {
        at++;
        while (at < text.length && text[at] !== '"') at += text[at] === "\\" ? 2 : 1;
        at++;
        continue;
      }
      if (char === "-" || char >= "0" && char <= "9") {
        let end = at + 1;
        while (end < text.length && "0123456789.eE+-".includes(text[end])) end++;
        const token = text.slice(at, end);
        if (/^-?\d{16,}$/.test(token) && !Number.isSafeInteger(Number(token))) {
          out += text.slice(last, at) + JSON.stringify(BIG + token);
          last = end;
        }
        at = end;
        continue;
      }
      at++;
    }
    return out + text.slice(last);
  }
  function writeJson(value) {
    return JSON.stringify(value).replace(BIG_BACK, "$1");
  }
  function readJson(text) {
    try {
      const value = JSON.parse(protectBig(text));
      return writeJson(value) === text ? value : null;
    } catch {
      return null;
    }
  }
  function readRequest(text) {
    const outer = readJson(text);
    if (!outer || typeof outer !== "object" || typeof outer.payload !== "string") return null;
    const payload = readJson(outer.payload);
    if (!payload || typeof payload !== "object") return null;
    return { outer, type: outer.type, payload };
  }
  function writeRequest(request) {
    return writeJson({ ...request.outer, payload: writeJson(request.payload) });
  }

  // src/core/net/websocket.js
  var LIGHTSPEED = /^wss:\/\/gateway\.facebook\.com\/ws\/lightspeed(?:[/?]|$)/;
  function bytesOf(data) {
    if (Object.prototype.toString.call(data) === "[object ArrayBuffer]") return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    return null;
  }
  function patchWebSocket(win, { log }) {
    const rules = [];
    const failed = /* @__PURE__ */ new Set();
    const stats = { messages: 0, unreadable: 0 };
    const proto = win.WebSocket?.prototype;
    const original = proto?.send;
    const decoder = new (win.TextDecoder ?? TextDecoder)();
    const encoder = new (win.TextEncoder ?? TextEncoder)();
    const fail = (rule, error) => {
      if (failed.has(rule.id)) return;
      failed.add(rule.id);
      log.error(`Chat rule "${rule.id}" failed, so Facebook's message went out unchanged`, error);
    };
    function rewrite(bytes, active) {
      const frames = readFrames(bytes);
      if (!frames) {
        stats.unreadable++;
        return null;
      }
      let changed = false;
      const out = frames.map((frame) => {
        const text = frameJson(frame, decoder);
        if (text === null) return frame;
        const request = readRequest(text);
        if (!request) {
          stats.unreadable++;
          return frame;
        }
        let edited = false;
        for (const rule of active) {
          try {
            if (rule.edit(request)) edited = true;
          } catch (error) {
            fail(rule, error);
            return frame;
          }
        }
        if (!edited) return frame;
        changed = true;
        return withJson(frame, writeRequest(request), encoder);
      });
      return changed ? writeFrames(out) : null;
    }
    if (typeof original === "function") {
      proto.send = function send(data) {
        try {
          if (LIGHTSPEED.test(this.url)) {
            stats.messages++;
            const active = rules.filter((rule) => {
              try {
                return rule.enabled();
              } catch (error) {
                fail(rule, error);
                return false;
              }
            });
            const bytes = active.length ? bytesOf(data) : null;
            const edited = bytes && rewrite(bytes, active);
            if (edited) {
              const isBuffer = Object.prototype.toString.call(data) === "[object ArrayBuffer]";
              return original.call(this, isBuffer ? edited.buffer : edited);
            }
          }
        } catch (error) {
          log.error("Couldn't read a chat message, so it went out unchanged", error);
        }
        return original.apply(this, arguments);
      };
    }
    return {
      installed: typeof original === "function",
      stats,
      // rule: { id, enabled(), edit(request) -> true when it changed request.payload }
      // request: { type, payload } with payload parsed (3: tasks, 4: one unqueued task).
      editChatRequests(rule) {
        rules.push(rule);
      }
    };
  }

  // src/core/net/hooks.js
  var INSTALLED = /* @__PURE__ */ Symbol.for("hushfacebook-web.net");
  var INLINE_JSON = Object.freeze({ transport: "json-parse", method: "", url: "", host: "", path: "", friendlyName: "" });
  function describeRequest({ url: url2, method = "GET", body, headers, transport, base }) {
    let parsed;
    try {
      parsed = new URL(String(url2), base);
    } catch {
      parsed = null;
    }
    return {
      transport,
      method: String(method).toUpperCase(),
      url: parsed?.href ?? String(url2),
      host: parsed?.hostname ?? "",
      path: parsed?.pathname ?? "",
      friendlyName: friendlyNameOf(body, headers),
      body
    };
  }
  function installNetworkHooks({ win, log }) {
    if (win[INSTALLED]) return win[INSTALLED];
    const requestRules = [];
    const responseRules = [];
    const failed = /* @__PURE__ */ new Set();
    const onError = (rule, error) => {
      if (failed.has(rule.id)) return;
      failed.add(rule.id);
      log.error(`Network rule "${rule.id}" failed, so Facebook got its original data`, error);
    };
    const active = (rules, ctx) => rules.filter((rule) => {
      try {
        return rule.enabled() && rule.match(ctx);
      } catch (error) {
        onError(rule, error);
        return false;
      }
    });
    const blockingRule = (ctx) => active(requestRules, ctx)[0];
    const fakeAnswer = (rule, ctx) => {
      try {
        return rule.fakeResponse?.(ctx) ?? "{}";
      } catch (error) {
        if (!failed.has(rule.id)) {
          failed.add(rule.id);
          log.error(`Network rule "${rule.id}" couldn't make its answer, so the page got an empty one`, error);
        }
        return "{}";
      }
    };
    const parse3 = win.JSON?.parse ?? JSON.parse;
    const handled = createHandledLines();
    const lineTransformer = (rules, ctx) => (line) => {
      const out = transformDocumentLine(line, rules, ctx, onError, parse3);
      const ran = rulesFor(line, rules);
      if (out !== null && ran.length) handled.add(out, ran);
      return out;
    };
    patchFetch(win, { blockingRule, fakeAnswer, active, responseRules, lineTransformer, log });
    patchXhr(win, { blockingRule, fakeAnswer, active, responseRules, lineTransformer });
    patchBeacon(win, { blockingRule, fakeAnswer });
    patchJsonParse(win, { active, responseRules, onError, handled });
    const sockets = patchWebSocket(win, { log });
    const api = {
      // The chat socket: see websocket.js. chatStats counts what it sent and couldn't read.
      editChatRequests: sockets.editChatRequests,
      chatStats: sockets.stats,
      // rule: { id, enabled(), match(ctx), fakeResponse?(ctx) }
      blockRequests(rule) {
        requestRules.push(rule);
      },
      // rule: { id, enabled(), match(ctx), markers?: string[], transform(doc, ctx) }
      // ctx.transport is 'fetch', 'xhr' or 'json-parse' (inline page data).
      transformResponses(rule) {
        responseRules.push(rule);
      }
    };
    Object.defineProperty(win, INSTALLED, { value: api });
    return api;
  }
  function patchFetch(win, { blockingRule, fakeAnswer, active, responseRules, lineTransformer, log }) {
    const original = win.fetch;
    if (typeof original !== "function") return;
    win.fetch = function fetch(input, init) {
      const isRequest = typeof win.Request === "function" && input instanceof win.Request;
      const ctx = describeRequest({
        transport: "fetch",
        url: isRequest ? input.url : input,
        method: init?.method ?? (isRequest ? input.method : "GET"),
        body: init?.body,
        headers: init?.headers ?? (isRequest ? input.headers : void 0),
        base: win.location.href
      });
      const blocker = blockingRule(ctx);
      if (blocker) {
        return win.Promise.resolve(new win.Response(fakeAnswer(blocker, ctx), { status: 200 }));
      }
      const promise = original.apply(this, arguments);
      const rules = active(responseRules, ctx);
      if (!rules.length) return promise;
      return promise.then((response) => {
        try {
          return rewriteFetchResponse(win, response, lineTransformer(rules, ctx));
        } catch (error) {
          log.error("Couldn't rewrite a fetch response, so it went through unchanged", error);
          return response;
        }
      });
    };
  }
  function rewriteFetchResponse(win, response, transformLine) {
    if (!response.body || response.type === "opaque") return response;
    const reader = response.body.getReader();
    const stream = createLineStream(transformLine);
    const decoder = new TextDecoder();
    const encoder = new TextEncoder();
    const body = new win.ReadableStream({
      async pull(controller) {
        for (; ; ) {
          const { done, value } = await reader.read();
          const text = done ? stream.push(decoder.decode()) + stream.flush() : stream.push(decoder.decode(value, { stream: true }));
          if (text) controller.enqueue(encoder.encode(text));
          if (done) {
            controller.close();
            return;
          }
          if (text) return;
        }
      },
      cancel: (reason) => reader.cancel(reason)
    });
    const headers = new win.Headers(response.headers);
    headers.delete("content-length");
    const rewritten = new win.Response(body, { status: response.status, statusText: response.statusText, headers });
    Object.defineProperty(rewritten, "url", { value: response.url });
    return rewritten;
  }
  function patchXhr(win, { blockingRule, fakeAnswer, active, responseRules, lineTransformer }) {
    const Xhr = win.XMLHttpRequest;
    if (typeof Xhr !== "function") return;
    const proto = Xhr.prototype;
    const { open, send, setRequestHeader } = proto;
    const textGetter = Object.getOwnPropertyDescriptor(proto, "responseText").get;
    const responseGetter = Object.getOwnPropertyDescriptor(proto, "response").get;
    const state = /* @__PURE__ */ new WeakMap();
    proto.open = function(method, url2) {
      state.set(this, { method, url: url2, headers: {} });
      return open.apply(this, arguments);
    };
    proto.setRequestHeader = function(name, value) {
      const entry = state.get(this);
      if (entry) entry.headers[String(name).toLowerCase()] = value;
      return setRequestHeader.apply(this, arguments);
    };
    proto.send = function(body) {
      const entry = state.get(this);
      if (!entry) return send.apply(this, arguments);
      const ctx = describeRequest({ transport: "xhr", url: entry.url, method: entry.method, body, headers: entry.headers, base: win.location.href });
      const blocker = blockingRule(ctx);
      if (blocker) return fakeXhrSuccess(win, this, ctx, fakeAnswer(blocker, ctx));
      const rules = active(responseRules, ctx);
      if (rules.length) attachTextTransform(this, lineTransformer(rules, ctx), textGetter, responseGetter);
      return send.apply(this, arguments);
    };
  }
  function attachTextTransform(xhr, transformLine, textGetter, responseGetter) {
    const stream = createLineStream(transformLine);
    let seen = 0;
    let output = "";
    let flushed = false;
    const read = () => {
      const raw = textGetter.call(xhr);
      if (raw.length > seen) {
        output += stream.push(raw.slice(seen));
        seen = raw.length;
      }
      if (xhr.readyState === 4 && !flushed) {
        output += stream.flush();
        flushed = true;
      }
      return output;
    };
    Object.defineProperty(xhr, "responseText", { configurable: true, get: read });
    Object.defineProperty(xhr, "response", {
      configurable: true,
      get: () => xhr.responseType === "" || xhr.responseType === "text" ? read() : responseGetter.call(xhr)
    });
  }
  function fakeXhrSuccess(win, xhr, ctx, text) {
    const values = { readyState: 4, status: 200, statusText: "OK", responseText: text, response: text, responseURL: ctx.url };
    for (const [key, value] of Object.entries(values)) Object.defineProperty(xhr, key, { configurable: true, value });
    win.setTimeout(() => {
      xhr.dispatchEvent(new win.Event("readystatechange"));
      xhr.dispatchEvent(new win.ProgressEvent("load"));
      xhr.dispatchEvent(new win.ProgressEvent("loadend"));
    }, 0);
  }
  function patchJsonParse(win, { active, responseRules, onError, handled }) {
    const json = win.JSON;
    const parse3 = json?.parse;
    if (typeof parse3 !== "function") return;
    json.parse = function(text) {
      const result = parse3.apply(this, arguments);
      if (typeof text !== "string" || result === null || typeof result !== "object") return result;
      let candidates = rulesFor(text, responseRules);
      if (!candidates.length) return result;
      const done = handled?.get(text);
      if (done) candidates = candidates.filter((rule) => !done.has(rule));
      for (const rule of active(candidates, INLINE_JSON)) {
        try {
          rule.transform(result, INLINE_JSON);
        } catch (error) {
          onError(rule, error);
        }
      }
      return result;
    };
  }
  var GUARD2 = "for (;;);";
  var SAMPLES = 64;
  var ENDS = 160;
  function lineKey(line) {
    let text = line.trim();
    if (text.startsWith(GUARD2)) text = text.slice(GUARD2.length).trimStart();
    const n = text.length;
    if (n <= 2 * ENDS + SAMPLES) return text;
    let sample = "";
    for (let i = 1; i < SAMPLES; i++) sample += text[Math.floor(i * n / SAMPLES)];
    return `${n}:${text.slice(0, ENDS)}${sample}${text.slice(-ENDS)}`;
  }
  function createHandledLines(limit = 64) {
    const lines = /* @__PURE__ */ new Map();
    return {
      add(line, rules = []) {
        const key = lineKey(line);
        const done = lines.get(key) ?? /* @__PURE__ */ new Set();
        for (const rule of rules) done.add(rule);
        lines.delete(key);
        lines.set(key, done);
        if (lines.size > limit) lines.delete(lines.keys().next().value);
      },
      // The rules that already looked at this line, or undefined.
      get: (line) => lines.get(lineKey(line)),
      has: (line) => lines.has(lineKey(line))
    };
  }
  function patchBeacon(win, { blockingRule, fakeAnswer }) {
    const nav = win.navigator;
    const original = nav?.sendBeacon;
    if (typeof original !== "function") return;
    nav.sendBeacon = function sendBeacon(url2, data) {
      const ctx = describeRequest({ transport: "beacon", url: url2, method: "POST", body: data, base: win.location.href });
      const blocker = blockingRule(ctx);
      if (blocker) {
        fakeAnswer(blocker, ctx);
        return true;
      }
      return original.apply(this, arguments);
    };
  }

  // src/core/route.js
  var ROUTE_TYPES = {
    "": "home",
    "home.php": "home",
    marketplace: "marketplace",
    groups: "groups",
    watch: "watch",
    reel: "reel",
    reels: "reel",
    stories: "stories",
    messages: "messages",
    notifications: "notifications",
    search: "search",
    friends: "friends",
    gaming: "gaming",
    events: "events",
    photo: "photo",
    "photo.php": "photo",
    photos: "photo",
    "permalink.php": "post",
    "story.php": "post",
    "profile.php": "profile",
    settings: "settings",
    saved: "saved",
    hashtag: "hashtag",
    feeds: "feeds",
    bookmarks: "menu"
  };
  function parseRoute(href) {
    const url2 = new URL(href);
    const parts = url2.pathname.split("/").filter(Boolean);
    const type = ROUTE_TYPES[parts[0] ?? ""] ?? "profile";
    const permalink = /\/posts\/(?:\d+|pfbid0\w+)/.test(url2.pathname) || /^\/(?:permalink|story)\.php$/.test(url2.pathname) || /^\/groups\/[^/]+\/(?:posts|permalink)\/[^/]+/.test(url2.pathname) || url2.searchParams.has("multi_permalinks") || url2.searchParams.get("view") === "permalink";
    return { href: url2.href, type, permalink, path: url2.pathname, feed: url2.searchParams.get("sk") ?? "" };
  }
  function createRouter({ win, pageAccess: pageAccess2, log, pollMs = 500 }) {
    const listeners = /* @__PURE__ */ new Set();
    let current = parseRoute(win.location.href);
    const stamp = () => {
      const root = win.document?.documentElement;
      if (!root) return;
      root.dataset.hfwRoute = current.type;
      root.dataset.hfwPermalink = String(current.permalink);
    };
    const check = () => {
      if (win.location.href === current.href) return;
      current = parseRoute(win.location.href);
      stamp();
      for (const listener of listeners) {
        try {
          listener(current);
        } catch (error) {
          log?.error("A page-change listener failed", error);
        }
      }
    };
    if (pageAccess2 === "page") {
      for (const name of ["pushState", "replaceState"]) {
        const original = win.history[name];
        win.history[name] = function() {
          const result = original.apply(this, arguments);
          check();
          return result;
        };
      }
      win.addEventListener("popstate", check);
    } else {
      win.setInterval(check, pollMs);
    }
    win.addEventListener("hashchange", check);
    whenRootReady(stamp, win.document);
    return {
      current: () => current,
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      }
    };
  }

  // src/core/settings.js
  var STORAGE_KEY = "settings";
  var EXPORT_SCHEMA = 1;
  function accountFromCookie(cookie) {
    return /(?:^|;\s*)c_user=(\d+)(?:;|$)/.exec(String(cookie ?? ""))?.[1] ?? null;
  }
  function storageKeyFor(account) {
    if (!account) return STORAGE_KEY;
    let hash = 2166136261;
    for (const char of String(account)) {
      hash ^= char.charCodeAt(0);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return `${STORAGE_KEY}@${hash.toString(36)}`;
  }
  var MIGRATIONS = [
    {
      // In v0.0.1 Hide sponsored posts also took the ads out of search and Marketplace. Someone
      // who had it off keeps those ads now that each place has its own switch.
      id: "split-ad-switch",
      before: "0.0.2",
      run(raw) {
        if (raw.hideSponsoredPosts !== false) return;
        for (const key of ["hideSponsoredSearch", "hideSponsoredMarketplace"]) {
          if (!Object.hasOwn(raw, key)) raw[key] = false;
        }
      }
    }
  ];
  function olderThan(version2, before) {
    const parts = (text) => /^(\d+)\.(\d+)\.(\d+)/.exec(String(text ?? ""))?.slice(1).map(Number);
    const a = parts(version2);
    const b = parts(before);
    if (!a || !b) return false;
    for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] < b[i];
    return false;
  }
  var GLOBAL_SETTINGS = [
    { key: "paused", type: "toggle", default: false, label: "Pause HushFacebook Web" },
    { key: "ui.launcher", type: "toggle", default: true, label: "Show the settings button on Facebook" },
    { key: "ui.hiddenNote", type: "toggle", default: false, label: "Leave a note where a post was hidden" }
  ];
  function buildSchema(features2) {
    const schema = /* @__PURE__ */ new Map();
    const add = (spec) => {
      if (schema.has(spec.key)) throw new Error(`Duplicate setting key: ${spec.key}`);
      schema.set(spec.key, spec);
    };
    for (const spec of GLOBAL_SETTINGS) add(spec);
    for (const feature of features2) {
      add({ key: feature.id, type: "toggle", default: feature.default === true, label: feature.title, featureId: feature.id });
      for (const option of feature.options ?? []) {
        add({ ...option, key: `${feature.id}.${option.key}`, featureId: feature.id });
      }
    }
    return schema;
  }
  function isValid(spec, value) {
    switch (spec.type) {
      case "toggle":
        return typeof value === "boolean";
      case "select":
        return spec.choices.some((choice) => choice.value === value);
      case "text":
        return typeof value === "string" && value.length <= (spec.maxLength ?? 2e4);
      case "number":
        return Number.isFinite(value) && value >= (spec.min ?? -Infinity) && value <= (spec.max ?? Infinity);
      default:
        return false;
    }
  }
  function createSettings({ storage, features: features2, log, version: version2 = "dev", account = null, migrations = MIGRATIONS }) {
    const schema = buildSchema(features2);
    const listeners = /* @__PURE__ */ new Set();
    const key = storageKeyFor(account);
    const doneKey = `${key}.migrated`;
    let values = migrate(load());
    function load() {
      const own = storage.get(key, void 0);
      if (own !== void 0 || key === STORAGE_KEY) return own ?? {};
      const shared = sanitize(storage.get(STORAGE_KEY, {}));
      if (Object.keys(shared).length) {
        try {
          storage.set(key, shared);
          const sharedDone = storage.get(`${STORAGE_KEY}.migrated`, void 0);
          if (Array.isArray(sharedDone)) storage.set(doneKey, sharedDone);
        } catch (error) {
          log?.error("Could not copy your settings to this account", error);
        }
      }
      return shared;
    }
    function migrate(raw) {
      const stored = storage.get(doneKey, []);
      const done = Array.isArray(stored) ? stored : [];
      const before = sanitize(raw);
      const pending = migrations.filter((migration) => !done.includes(migration.id));
      if (!pending.length) return before;
      const next = raw && typeof raw === "object" && !Array.isArray(raw) ? { ...raw } : {};
      for (const migration of pending) migration.run(next);
      const after = sanitize(next);
      try {
        if (JSON.stringify(after) !== JSON.stringify(before)) storage.set(key, after);
        storage.set(doneKey, [...done, ...pending.map((migration) => migration.id)]);
      } catch (error) {
        log?.error("Could not save a settings update", error);
      }
      return after;
    }
    function sanitize(raw) {
      const clean = {};
      if (!raw || typeof raw !== "object") return clean;
      for (const [key2, value] of Object.entries(raw)) {
        const spec2 = schema.get(key2);
        if (spec2 && isValid(spec2, value) && value !== spec2.default) clean[key2] = value;
      }
      return clean;
    }
    function persist() {
      try {
        storage.set(key, values);
      } catch (error) {
        log?.error("Could not save settings", error);
        throw error;
      }
    }
    function notify(keys, remote = false) {
      for (const listener of listeners) {
        try {
          listener({ keys, remote });
        } catch (error) {
          log?.error("A settings listener failed", error);
        }
      }
    }
    function spec(key2) {
      const found = schema.get(key2);
      if (!found) throw new Error(`Unknown setting: ${key2}`);
      return found;
    }
    storage.onChange?.(key, (raw) => {
      values = sanitize(raw);
      notify([...schema.keys()], true);
    });
    function get(key2) {
      return Object.hasOwn(values, key2) ? values[key2] : spec(key2).default;
    }
    return {
      schema,
      perAccount: key !== STORAGE_KEY,
      get,
      set(key2, value) {
        const found = spec(key2);
        if (!isValid(found, value)) throw new TypeError(`Invalid value for ${key2}: ${JSON.stringify(value)}`);
        if (value === found.default) delete values[key2];
        else values[key2] = value;
        persist();
        notify([key2]);
      },
      // A feature runs only when it's switched on and the whole script isn't paused.
      enabled(featureId) {
        return get("paused") !== true && get(featureId) === true;
      },
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      },
      snapshot: () => structuredClone(values),
      restore(snapshot) {
        values = sanitize(snapshot);
        persist();
        notify([...schema.keys()]);
      },
      reset() {
        const previous = structuredClone(values);
        values = {};
        persist();
        notify([...schema.keys()]);
        return previous;
      },
      exportJson(now = /* @__PURE__ */ new Date()) {
        return JSON.stringify({ app: "HushFacebook Web", schema: EXPORT_SCHEMA, version: version2, exported: now.toISOString(), settings: values }, null, 2);
      },
      importJson(text) {
        const parsed = JSON.parse(text);
        const incoming = parsed && typeof parsed.settings === "object" ? parsed.settings : parsed;
        if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) {
          throw new TypeError("That file has no HushFacebook Web settings in it");
        }
        const changed = { ...incoming };
        for (const migration of migrations) {
          if (olderThan(parsed.version, migration.before)) migration.run(changed);
        }
        const applied = [];
        const skipped = [];
        for (const [key2, value] of Object.entries(changed)) {
          const found = schema.get(key2);
          if (!found || !isValid(found, value)) {
            skipped.push(key2);
            continue;
          }
          if (value === found.default) delete values[key2];
          else values[key2] = value;
          applied.push(key2);
        }
        persist();
        notify(applied);
        return { applied, skipped };
      }
    };
  }

  // src/core/storage.js
  function createGmStorage() {
    if (typeof GM_getValue !== "function" || typeof GM_setValue !== "function") {
      return createLocalStorage();
    }
    return {
      kind: "gm",
      get: (key, fallback) => GM_getValue(key, fallback),
      set: (key, value) => GM_setValue(key, value),
      remove: (key) => typeof GM_deleteValue === "function" ? GM_deleteValue(key) : GM_setValue(key, void 0),
      onChange(key, listener) {
        if (typeof GM_addValueChangeListener !== "function") return;
        GM_addValueChangeListener(key, (_name, _old, value, remote) => {
          if (remote) listener(value);
        });
      }
    };
  }
  var UNKEPT_SETTINGS = "Your userscript manager doesn't give HushFacebook Web storage of its own, so your settings are kept in Facebook's page, which clears them within seconds. Tampermonkey and Violentmonkey keep them.";
  function createLocalStorage(prefix = "hfw:") {
    return {
      kind: "localStorage",
      get(key, fallback) {
        try {
          const raw = localStorage.getItem(prefix + key);
          return raw === null ? fallback : JSON.parse(raw);
        } catch {
          return fallback;
        }
      },
      set: (key, value) => localStorage.setItem(prefix + key, JSON.stringify(value)),
      remove: (key) => localStorage.removeItem(prefix + key),
      onChange(key, listener) {
        addEventListener("storage", (event) => {
          if (event.key !== prefix + key) return;
          try {
            listener(event.newValue === null ? void 0 : JSON.parse(event.newValue));
          } catch {
            listener(void 0);
          }
        });
      }
    };
  }

  // src/core/modules.js
  function whenModule(win, name, callback, { log } = {}) {
    let asked = false;
    const ask = () => {
      if (asked || typeof win.requireLazy !== "function") return;
      asked = true;
      try {
        win.requireLazy([name], (exports) => {
          try {
            callback(exports);
          } catch (error) {
            log?.error(`Couldn't use Facebook's ${name}`, error);
          }
        });
      } catch (error) {
        log?.error(`Couldn't ask Facebook for ${name}`, error);
      }
    };
    ask();
    if (asked) return;
    win.document?.addEventListener("DOMContentLoaded", ask, { once: true });
    win.addEventListener?.("load", ask, { once: true });
  }

  // src/core/storage-report.js
  var MARK_PREFIX = "hfw:";
  var MONSTER = "WebStorageMonster";
  function stepAside(store, prefix = MARK_PREFIX) {
    const held = [];
    for (let i = store.length - 1; i >= 0; i--) {
      const key = store.key(i);
      if (typeof key === "string" && key.startsWith(prefix)) held.push([key, store.getItem(key)]);
    }
    for (const [key] of held) store.removeItem(key);
    return () => {
      for (const [key, value] of held) {
        try {
          store.setItem(key, value);
        } catch {
        }
      }
    };
  }
  function wrapReport(monster, { win, onReport } = {}) {
    const target = typeof monster?.cleanNow === "function" ? monster : monster?.default;
    const original = target?.cleanNow;
    if (typeof original !== "function") return false;
    target.cleanNow = function cleanNow(...args) {
      let restore;
      try {
        restore = stepAside(win.sessionStorage);
      } catch {
        restore = null;
      }
      try {
        return original.apply(this, args);
      } finally {
        restore?.();
        onReport?.();
      }
    };
    return true;
  }
  function keepOutOfStorageReport({ win, log, diagnostics }) {
    let state = "waiting";
    let reports = 0;
    whenModule(win, MONSTER, (monster) => {
      state = wrapReport(monster, { win, onReport: () => {
        reports++;
        diagnostics?.changed();
      } }) ? "wrapped" : "changed";
      if (state === "changed") log?.warn("Facebook's storage report has changed, so the names of this script's marks for the tab may be in it");
      diagnostics?.changed();
    }, { log });
    diagnostics?.add("Facebook's storage report", () => {
      if (state === "wrapped") return `This script's marks kept out of ${reports} report${reports === 1 ? "" : "s"}`;
      return state === "changed" ? "Changed, so the marks may be in it" : "Not loaded yet";
    });
  }

  // src/core/tasks.js
  var DAY = 24 * 60 * 60 * 1e3;
  var RECENT = 10 * 60 * 1e3;
  var TASKS_KEY = "tasks";
  var CHECK_KEY = "storageCheck";
  var MIRROR_KEY = "hfw:storageCheck";
  var asTable = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
  var asRecord = (value) => value && typeof value === "object" && typeof value.token === "string" ? value : null;
  function attempt(read, fallback) {
    try {
      return read();
    } catch {
      return fallback;
    }
  }
  function createDailyTasks({ storage, log, now = () => Date.now() }) {
    const tasks = [];
    return {
      // lastSeen: another record of the last run, used when the table itself was lost.
      add(id, run, { lastSeen } = {}) {
        tasks.push({ id, run, lastSeen });
      },
      // Runs every job that hasn't run in the last day. Returns the ids it ran.
      runDue() {
        let table;
        try {
          table = { ...asTable(storage.get(TASKS_KEY, {})) };
        } catch (error) {
          log?.error("Couldn't read when the daily jobs last ran", error);
          table = {};
        }
        const ran = [];
        for (const task of tasks) {
          const other = attempt(() => Number(task.lastSeen?.()) || 0, 0);
          const last = Math.max(Number(table[task.id]) || 0, other);
          if (now() - last < DAY) continue;
          try {
            task.run();
          } catch (error) {
            log?.error(`The daily job "${task.id}" failed`, error);
          }
          table[task.id] = now();
          ran.push(task.id);
        }
        if (ran.length) {
          try {
            storage.set(TASKS_KEY, table);
          } catch (error) {
            log?.error("Couldn't note that the daily jobs ran", error);
          }
        }
        return ran;
      }
    };
  }
  var MIRROR_DB = "hushfacebook-web";
  var MIRROR_STORE = "checks";
  function pageMirror(win = globalThis) {
    const idb = attempt(() => win.indexedDB, null);
    if (!idb || typeof idb.open !== "function") return null;
    let db = null;
    let known = false;
    let record = null;
    let pending = null;
    let settle;
    const ready = new Promise((resolve) => {
      settle = resolve;
    });
    const write = (value) => {
      try {
        db.transaction(MIRROR_STORE, "readwrite").objectStore(MIRROR_STORE).put(value, MIRROR_KEY);
        return true;
      } catch {
        return false;
      }
    };
    const loaded = (value) => {
      known = true;
      record = pending ?? asRecord(value);
      if (pending) write(pending);
      pending = null;
      settle();
    };
    try {
      const request = idb.open(MIRROR_DB, 1);
      request.onupgradeneeded = () => request.result.createObjectStore(MIRROR_STORE);
      request.onsuccess = () => {
        db = request.result;
        db.onversionchange = () => db.close();
        try {
          const read = db.transaction(MIRROR_STORE, "readonly").objectStore(MIRROR_STORE).get(MIRROR_KEY);
          read.onsuccess = () => loaded(read.result);
          read.onerror = () => loaded(null);
        } catch {
          loaded(null);
        }
      };
      request.onerror = () => settle();
    } catch {
      return null;
    }
    return {
      ready,
      get: () => known ? record : null,
      set(value) {
        if (!known) {
          pending = value;
          return true;
        }
        record = value;
        return write(value);
      }
    };
  }
  function whenMirrorReady(mirror, run, { wait = 3e4, setTimer = setTimeout } = {}) {
    let done = false;
    const go = () => {
      if (done) return;
      done = true;
      run();
    };
    if (!mirror?.ready) {
      go();
      return;
    }
    mirror.ready.then(go, go);
    setTimer(go, wait);
  }
  var randomToken = () => Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
  var day = (time) => new Date(time).toISOString().slice(0, 10);
  function checkStorage({ storage, mirror, now = Date.now(), token = randomToken() }) {
    let kept;
    try {
      kept = asRecord(storage.get(CHECK_KEY, null));
    } catch (error) {
      return { ok: false, at: now, message: `Your userscript manager's storage couldn't be read (${error?.message ?? error}), so your settings may not be saved.` };
    }
    const before = mirror?.get() ?? null;
    const earlier = before && !(now - Number(before.at) < RECENT);
    const lost = earlier && (!kept || kept.token !== before.token && !(Number(kept.at) > Number(before.at))) ? `Your userscript manager didn't keep what HushFacebook Web saved on ${day(before.at)}. If you didn't reinstall the script or clear its storage since then, your settings may not be saving.` : null;
    try {
      storage.set(CHECK_KEY, { token, at: now });
      const back = asRecord(storage.get(CHECK_KEY, null));
      if (!back || back.token !== token) {
        return { ok: false, at: now, message: "Your userscript manager didn't give back what HushFacebook Web just saved, so your settings may not be saving." };
      }
    } catch (error) {
      return { ok: false, at: now, message: `Your userscript manager wouldn't save (${error?.message ?? error}), so your settings may not be saving.` };
    }
    mirror?.set({ token, at: now });
    return lost ? { ok: false, at: now, message: lost } : { ok: true, at: now };
  }
  function scheduleStorageCheck({ tasks, storage, mirror, log, toast, diagnostics, now = () => Date.now() }) {
    let result = null;
    tasks.add(CHECK_KEY, () => {
      result = checkStorage({ storage, mirror, now: now() });
      if (!result.ok) {
        log?.error(result.message);
        toast?.(result.message, { tone: "error" });
      }
      diagnostics?.changed();
    }, { lastSeen: () => mirror?.get()?.at ?? 0 });
    diagnostics?.add("Storage check", () => {
      if (result) return result.ok ? `Passed ${new Date(result.at).toLocaleString()}` : `Failed: ${result.message}`;
      const kept = attempt(() => asRecord(storage.get(CHECK_KEY, null)), null);
      return kept ? `Last ran ${new Date(kept.at).toLocaleString()}, runs again within a day` : "Runs within a day";
    });
  }

  // src/core/style.js
  function renderFeatureCss(features2, settings, log, base = []) {
    const parts = [];
    if (settings.get("paused") !== true) {
      for (const part of base) {
        try {
          parts.push(`/* ${part.id} */
${part.css(settings.get)}`);
        } catch (error) {
          log?.error(`The ${part.id} styles couldn't be built`, error);
        }
      }
    }
    for (const feature of features2) {
      if (!feature.css || !settings.enabled(feature.id)) continue;
      try {
        parts.push(`/* ${feature.id} */
${typeof feature.css === "function" ? feature.css(settings.get) : feature.css}`);
      } catch (error) {
        log?.error(`${feature.title}: its styles couldn't be built`, error);
      }
    }
    return parts.join("\n");
  }
  function mountFeatureStyles({ features: features2, settings, log, doc = document, base = [] }) {
    const style = doc.createElement("style");
    style.dataset.hushfacebookWeb = "features";
    const render = () => {
      style.textContent = renderFeatureCss(features2, settings, log, base);
    };
    render();
    whenRootReady(() => (doc.head ?? doc.documentElement).append(style), doc);
    settings.subscribe(render);
    return style;
  }

  // src/core/json-walk.js
  var SKIP = /* @__PURE__ */ Symbol("hfw.skip");
  function walk(root, visit) {
    const stack = [root];
    while (stack.length) {
      const value = stack.pop();
      if (value === null || typeof value !== "object") continue;
      if (visit(value) === SKIP) continue;
      if (Array.isArray(value)) {
        for (let i = value.length - 1; i >= 0; i--) stack.push(value[i]);
      } else {
        for (const key in value) stack.push(value[key]);
      }
    }
  }

  // src/features/feed/ad-markers.js
  var isObject = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
  var LABEL_TYPENAME = "CometStorySponsoredLabelStrategy";
  var FOLLOW_TYPENAME = "CometFeedStoryFollowButtonStrategy";
  var JOIN_TYPENAME = "GroupJoinForumAction";
  function storyMatches(node, test) {
    let found = false;
    walk(node, (value) => {
      if (found || value === node.attached_story) return SKIP;
      if (value !== node && "node" in value && "cursor" in value) return SKIP;
      if (test(value)) found = true;
      return void 0;
    });
    return found;
  }
  var storyHas = (node, typename) => storyMatches(node, (value) => value.__typename === typename);
  var hasSponsoredLabel = (node) => storyHas(node, LABEL_TYPENAME);
  function titleHas(node, typename) {
    const title = node?.comet_sections?.context_layout?.story?.comet_sections?.title;
    return isObject(title) ? storyHas(title, typename) : storyHas(node, typename);
  }
  var FEEDS = {
    queries: /^(?:CometNewsFeedPaginationQuery|GroupsCometCrossGroupFeedPaginationQuery)$/,
    routes: (route) => route?.type === "home" || /^\/groups\/feed\/?$/.test(route?.path ?? "")
  };
  var FEEDS_AND_SEARCH = {
    queries: /^(?:CometNewsFeedPaginationQuery|GroupsCometCrossGroupFeedPaginationQuery|SearchCometResultsPaginatedResultsQuery)$/,
    routes: (route) => FEEDS.routes(route) || route?.type === "search"
  };
  var INSTREAM_ADS = {
    queries: /^useInstreamAdsHaloFetcherQuery$/,
    routes: () => false
  };
  var GENAI_TYPENAME = "CometFeedStoryGenAIContentTransparencyStrategy";
  var isAiLabel = (value) => isObject(value) && value.__typename === GENAI_TYPENAME && (value.was_detected_as_ai_generated === true || value.was_self_disclosed_as_ai_generated === true || Boolean(value.ai_generated_detected_info?.gen_ai_transparency_type));
  function hasAiLabel(story) {
    if (!isObject(story)) return false;
    const metadata = story.comet_sections?.context_layout?.story?.comet_sections?.metadata;
    const own = Array.isArray(metadata) ? metadata.some(isAiLabel) : storyMatches(story, isAiLabel);
    if (own) return true;
    const shared = story.comet_sections?.content?.story?.attached_story ?? story.attached_story;
    return shared !== story && isObject(shared) && hasAiLabel(shared);
  }
  var storyOf = (edge, node) => isObject(node) && node.__typename === "Story" ? node : edge.rendering_strategy?.view_model?.click_model?.story ?? edge.rendering_strategy?.view_model?.story ?? null;
  var AD_MARKERS = [
    {
      id: "category",
      feature: "hideSponsoredPosts",
      surface: "news feed (older shape)",
      seen: "not yet",
      text: ['"SPONSORED"'],
      match: (edge) => edge.category === "SPONSORED",
      action: "drop-node"
    },
    {
      id: "cat_sensitive",
      feature: "hideSponsoredPosts",
      surface: "news feed",
      seen: "2026-10-10: on every feed edge, cat null on organic stories",
      text: ['"SPONSORED"'],
      match: (edge) => isObject(edge.cat_sensitive) && edge.cat_sensitive.cat === "SPONSORED",
      action: "drop-node"
    },
    {
      id: "sponsored_data",
      feature: "hideSponsoredPosts",
      surface: "news feed (older shape)",
      seen: "not yet",
      text: ['"sponsored_data":{'],
      match: (edge, node) => isObject(node) && node.sponsored_data != null,
      action: "drop-node"
    },
    {
      id: "th_dat_spo",
      feature: "hideSponsoredPosts",
      surface: "news feed",
      seen: "2026-10-10: null on every organic feed story, set inside a search ad",
      text: ['"th_dat_spo":{'],
      match: (edge, node) => isObject(node) && node.th_dat_spo != null,
      action: "drop-node"
    },
    {
      id: "sponsored label",
      feature: "hideSponsoredPosts",
      surface: "news feed",
      seen: '2026-10-10: the "Ad" label section of a search ad',
      text: [`"${LABEL_TYPENAME}"`],
      // Only on real edges (with a cursor): a wrapper holding an ad deep inside isn't an ad.
      match: (edge, node) => isObject(node) && "cursor" in edge && hasSponsoredLabel(node),
      action: "drop-node"
    },
    {
      id: "MarketplaceFeedAdStory",
      feature: "hideSponsoredMarketplace",
      surface: "Marketplace",
      seen: "2026-10-10: 8 ad cards pruned in the page, grid intact",
      text: ['"MarketplaceFeedAdStory"'],
      match: (edge, node) => isObject(node) && node.__typename === "MarketplaceFeedAdStory",
      action: "drop-node"
    },
    {
      id: "SEARCH_ADS",
      feature: "hideSponsoredSearch",
      surface: "search results",
      seen: "2026-10-10: the ad result pruned with its story",
      text: ['"SEARCH_ADS"'],
      match: (edge, node) => isObject(node) && node.role === "SEARCH_ADS",
      action: "drop-node"
    },
    {
      id: "instream_video_ad_breaks_comet",
      feature: "hideSponsoredReels",
      surface: "videos and reels in the feed, search, Marketplace and video pages (the ad break schedule)",
      seen: "2026-10-10: each video part comes as {id, instream_extra_config, instream_video_ad_breaks_comet}, in feed pages, video containers, Marketplace, search and inline page data; filled with MID_ROLL breaks (60 s, 120 s) on longer videos and null on the rest",
      text: ['"instream_video_ad_breaks_comet":{'],
      kind: "object",
      match: (value) => {
        const schedule = value.instream_video_ad_breaks_comet;
        return isObject(schedule) && ("mid_rolls" in schedule || "pre_roll" in schedule);
      },
      action: "empty-list",
      empty: { instream_video_ad_breaks_comet: null }
    },
    {
      id: "instream_video_ad_breaks",
      feature: "hideSponsoredReels",
      surface: "videos and reels (the ads fetched for a break)",
      seen: "2026-10-11: useInstreamAdsHaloFetcherQuery sent {scrubber: {instream_video_ad_breaks: [], post_roll_ad_break: null}} for all 31 videos and reels the test account opened; a filled answer not seen yet. Both keys only ever came in that answer",
      text: ['"instream_video_ad_breaks":[{', '"post_roll_ad_break":{'],
      scope: INSTREAM_ADS,
      kind: "object",
      match: (value) => "instream_video_ad_breaks" in value && "post_roll_ad_break" in value && (Array.isArray(value.instream_video_ad_breaks) && value.instream_video_ad_breaks.length > 0 || isObject(value.post_roll_ad_break)),
      action: "empty-list",
      empty: { instream_video_ad_breaks: [], post_roll_ad_break: null }
    },
    {
      id: "follow_button",
      feature: "hideSuggestedPosts",
      surface: "news feed and groups feed (Pages and people you don't follow)",
      seen: '2026-10-11: 36 of 137 captured Home stories, always in the title section, drawn as "Name · Follow"',
      text: [`"${FOLLOW_TYPENAME}"`],
      scope: FEEDS,
      match: (edge, node) => isObject(node) && "cursor" in edge && titleHas(node, FOLLOW_TYPENAME),
      action: "drop-node"
    },
    {
      id: "group_join",
      feature: "hideSuggestedPosts",
      surface: "news feed and groups feed (groups you aren't in)",
      seen: '2026-10-11: 17 of 137 captured Home stories, always in the title section, drawn as "Group · Join"',
      text: [`"${JOIN_TYPENAME}"`],
      scope: FEEDS,
      match: (edge, node) => isObject(node) && "cursor" in edge && titleHas(node, JOIN_TYPENAME),
      action: "drop-node"
    },
    {
      id: "genai_label",
      feature: "hideAiPosts",
      surface: "news feed, groups feed and search results (posts labeled as made with AI)",
      seen: "2026-10-11: 5 labeled stories, 1 on Home, 1 in the groups feed and 3 in search results, all detected rather than disclosed",
      text: [`"${GENAI_TYPENAME}"`],
      scope: FEEDS_AND_SEARCH,
      match: (edge, node) => "cursor" in edge && hasAiLabel(storyOf(edge, node)),
      action: "drop-node"
    }
  ];
  var DROPPED_BY = { "drop-node": ["node", "rendering_strategy"] };
  var textOf = (rows) => [...new Set(rows.flatMap((row) => row.text))];
  var AD_MARKER_TEXT = textOf(AD_MARKERS);
  function markersFor(feature) {
    const rows = AD_MARKERS.filter((row) => row.feature === feature);
    return { rows, text: textOf(rows) };
  }
  function adMarkerFor(value, rows = AD_MARKERS) {
    if (!isObject(value)) return null;
    const edge = "node" in value;
    return rows.find((row) => (row.kind ?? "edge") === "edge" ? edge && row.match(value, value.node) : row.match(value)) ?? null;
  }
  function inScope(row, ctx, route) {
    if (!row.scope) return true;
    if (ctx?.transport === "json-parse") return Boolean(route && row.scope.routes(route()));
    return row.scope.queries.test(ctx?.friendlyName ?? "");
  }
  var matchId = (value) => value.node?.post_id ?? value.node?.id ?? value.id ?? null;
  function adRule(feature, enabled, onPrune, { route, diagnostics, reason } = {}) {
    const { rows, text } = markersFor(feature);
    const report = diagnostics && reason ? (row, value) => diagnostics.decide({ post: matchId(value), rule: reason, signal: row.id, layer: "data" }) : void 0;
    return {
      id: feature,
      enabled,
      markers: text,
      match: (ctx) => ctx.transport === "json-parse" || ctx.path.startsWith("/api/graphql"),
      transform(doc, ctx) {
        const active = rows.filter((row) => inScope(row, ctx, route));
        if (!active.length) return false;
        const fired = pruneAds(doc, active, report);
        if (fired.length) onPrune?.(fired);
        return fired.length > 0;
      }
    };
  }
  function pruneAds(doc, rows = AD_MARKERS, report) {
    const fired = [];
    walk(doc, (value) => {
      const row = adMarkerFor(value, rows);
      if (!row) return void 0;
      report?.(row, value);
      if (row.action === "empty-list") {
        for (const [key, empty] of Object.entries(row.empty)) if (key in value) value[key] = Array.isArray(empty) ? [] : empty;
      } else {
        for (const key of DROPPED_BY[row.action]) delete value[key];
      }
      fired.push(row.id);
      return SKIP;
    });
    return fired;
  }

  // src/core/dom/visible-text.js
  var INVISIBLE = /[\u061C\u115F\u1160\u200B-\u200F\u202A-\u202E\u2060-\u2069\u3164\uFEFF\uFFA0]|\u034F|\u17B4|\u17B5|[\u180B-\u180F]|[\uFE00-\uFE0F]/g;
  function normalizeText(value) {
    return String(value ?? "").replace(INVISIBLE, "").replace(/\u00A0/g, " ").replace(/\s+/g, " ").trim();
  }
  var viewOf = (element) => element.ownerDocument?.defaultView ?? globalThis;
  function isHidden(element, boundary = null) {
    const view = viewOf(element);
    const stop = boundary?.parentElement ?? null;
    for (let current = element; current && current !== stop; current = current.parentElement) {
      if (current.hidden || current.getAttribute?.("aria-hidden") === "true") return true;
      const style = view.getComputedStyle?.(current);
      if (style) {
        if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return true;
        if (Number.parseFloat(style.opacity || "1") <= 0.01) return true;
        if (style.fontSize && Number.parseFloat(style.fontSize) <= 0) return true;
      }
      if (current === boundary) break;
    }
    return false;
  }
  function hasBox(rect) {
    return Boolean(rect && rect.width > 0 && rect.height > 0);
  }
  function visibleText(element, accept = null) {
    const walker = element.ownerDocument.createTreeWalker(
      element,
      4
      /* NodeFilter.SHOW_TEXT */
    );
    const hidden = /* @__PURE__ */ new Map();
    let text = "";
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const parent = node.parentElement;
      if (!hidden.has(parent)) hidden.set(parent, isHidden(parent, element) || accept !== null && !accept(parent));
      if (!hidden.get(parent)) text += node.nodeValue;
    }
    return text;
  }
  function ownText(element) {
    let text = "";
    for (const node of element.childNodes) if (node.nodeType === 3) text += node.nodeValue;
    return text;
  }

  // src/core/dom/label-cache.js
  var MAX_TEXT = 40;
  function createLabelCache({ doc = globalThis.document, max = 500 } = {}) {
    const texts = /* @__PURE__ */ new Map();
    let observer = null;
    function record(element) {
      if (!element.id) return;
      const text = normalizeText(element.textContent);
      if (!text || text.length > MAX_TEXT) return;
      texts.delete(element.id);
      texts.set(element.id, text);
      if (texts.size > max) texts.delete(texts.keys().next().value);
    }
    function capture(node) {
      if (node?.nodeType !== 1) return;
      record(node);
      for (const element of node.querySelectorAll("[id]")) record(element);
    }
    return {
      capture,
      get: (id) => texts.get(id) ?? null,
      get size() {
        return texts.size;
      },
      start() {
        if (observer) return;
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        observer = new Observer((records) => {
          for (const entry of records) for (const node of entry.addedNodes) capture(node);
        });
        const begin = () => {
          if (!observer) return;
          observer.observe(doc.body, { childList: true, subtree: true });
          capture(doc.body);
        };
        if (doc.body) begin();
        else doc.addEventListener("DOMContentLoaded", begin, { once: true });
      },
      stop() {
        observer?.disconnect();
        observer = null;
      }
    };
  }

  // src/features/feed/sponsored-dom.js
  var AD_LABELS = /* @__PURE__ */ new Map([
    ["ad", "Ad"],
    ["advertiser link", "Ad"],
    ["paid", "Ad"],
    ["paid partnership", "Ad"],
    ["sponsored", "Sponsored"]
  ]);
  function adLabel(value) {
    const key = normalizeText(value).replace(/^[·•]\s*/, "").replace(/\s*[·•]$/, "").toLowerCase();
    return AD_LABELS.has(key) ? key : null;
  }
  var HEADER_EXCLUSIONS = [
    "story_message",
    "title",
    "description",
    "like_button",
    "comment_button",
    "share_button"
  ].map((role) => `[data-ad-rendering-role="${role}"]`).join(", ") + ', [data-ad-rendering-role^="cta"]';
  var BODY_START = '[data-ad-rendering-role="story_message"], [data-ad-rendering-role="title"], video, img[src]';
  var NOT_A_LABEL = 'h1, h2, h3, h4, h5, h6, [role="heading"], [data-ad-rendering-role="profile_name"]';
  var CTA = '[data-ad-rendering-role^="cta"]';
  var MAX_LABEL = 24;
  var MAX_SOURCE = 400;
  var ownerOf2 = (element) => element.closest(CANDIDATE_SELECTOR);
  var namesSomeone = (element) => Boolean(element?.closest(NOT_A_LABEL) || element?.querySelector?.(NOT_A_LABEL));
  var within = (element, post, selector) => {
    const found = element.closest(selector);
    return Boolean(found && post.contains(found));
  };
  function headerTest(post) {
    const postRect = post.getBoundingClientRect();
    const layout = hasBox(postRect);
    const bodyStart = post.querySelector(BODY_START);
    const headerBottom = postRect.top + Math.min(230, Math.max(115, postRect.height * 0.28));
    return (element) => {
      if (ownerOf2(element) !== post || within(element, post, HEADER_EXCLUSIONS)) return false;
      if (layout) {
        const rect = element.getBoundingClientRect();
        if (hasBox(rect)) {
          return rect.top >= postRect.top - 4 && rect.top <= headerBottom && rect.left >= postRect.left - 8 && rect.right <= postRect.right + 8;
        }
      }
      return !bodyStart || Boolean(element.compareDocumentPosition(bodyStart) & 4) || element.contains(bodyStart);
    };
  }
  var styleOf = (element) => element.ownerDocument.defaultView.getComputedStyle(element);
  function glyphRecords(container, { layout, accept = null }) {
    const box = layout ? container.getBoundingClientRect() : null;
    const records = [];
    for (const leaf of [...container.querySelectorAll("span, div")].slice(0, 180)) {
      if (leaf.children.length) continue;
      const text = ownText(leaf);
      if (!text || text.length > 3 || isHidden(leaf, container) || accept && !accept(leaf)) continue;
      const style = styleOf(leaf);
      if (style.position === "absolute" || style.position === "fixed") continue;
      const order = Number.parseFloat(style.order);
      const record = { text, left: Number.NaN, top: Number.NaN, order: Number.isFinite(order) ? order : null };
      if (layout) {
        const rect = [...leaf.getClientRects()].find((r) => hasBox(r) && r.right >= box.left - 2 && r.left <= box.right + 2 && r.bottom >= box.top - 2 && r.top <= box.bottom + 2);
        if (!rect) continue;
        record.left = rect.left;
        record.top = rect.top;
      }
      records.push(record);
      if (records.length > 40) break;
    }
    return records;
  }
  function glyphStrings(records) {
    const strings = /* @__PURE__ */ new Set();
    const joined = (list, key) => normalizeText(list.slice().sort((a, b) => a[key] - b[key]).map((r) => r.text).join(""));
    const reorders = (list) => list.length >= 2 && new Set(list.map((r) => r.order)).size >= 2;
    const rows = [];
    for (const record of records.filter((r) => Number.isFinite(r.left) && Number.isFinite(r.top))) {
      let row = rows.find((candidate) => Math.abs(candidate.top - record.top) <= 3);
      if (!row) rows.push(row = { top: record.top, records: [] });
      row.records.push(record);
    }
    for (const row of rows) {
      strings.add(joined(row.records, "left"));
      const ordered2 = row.records.filter((r) => r.order !== null);
      if (reorders(ordered2)) strings.add(joined(ordered2, "order"));
    }
    const ordered = records.filter((r) => r.order !== null);
    if (reorders(ordered)) strings.add(joined(ordered, "order"));
    return [...strings].filter(Boolean);
  }
  function isScrambled(element) {
    const style = styleOf(element);
    if (element.children.length < 2 || element.children.length > 96) return false;
    return style.display === "flex" || style.display === "inline-flex" || [...element.children].some((child) => /(?:^|;)\s*order\s*:/i.test(child.getAttribute("style") ?? ""));
  }
  function decodeGlyphs(container, layout) {
    const accept = (leaf) => !leaf.closest(NOT_A_LABEL);
    return glyphStrings(glyphRecords(container, { layout, accept })).map(adLabel).find(Boolean) ?? null;
  }
  function readsAsLabel(element) {
    const values = [element.getAttribute("aria-label"), element.getAttribute("title"), element.innerText, element.textContent];
    return values.map(adLabel).find(Boolean) ?? null;
  }
  function isAdsAboutLink(href, depth = 0) {
    let url2;
    try {
      url2 = new URL(String(href ?? "").replace(/&amp;/g, "&"), "https://www.facebook.com/");
    } catch {
      return false;
    }
    const host = url2.hostname.toLowerCase();
    if (host !== "facebook.com" && !host.endsWith(".facebook.com")) return false;
    if (/^\/ads\/about\/?$/.test(url2.pathname)) return true;
    return url2.pathname === "/l.php" && depth < 2 && isAdsAboutLink(url2.searchParams.get("u"), depth + 1);
  }
  var GROUP_PAGES = /* @__PURE__ */ new Set(["category", "create", "discover", "feed", "for_you", "joins", "notifications", "search"]);
  function isGroupLink(href) {
    try {
      const match = new URL(href, "https://www.facebook.com/").pathname.match(/^\/groups\/([^/?#]+)/i);
      return Boolean(match && !GROUP_PAGES.has(match[1].toLowerCase()));
    } catch {
      return false;
    }
  }
  function readAdSignals(post, { labelCache } = {}) {
    const doc = post.ownerDocument;
    const layout = hasBox(post.getBoundingClientRect());
    const inHeader = headerTest(post);
    const visible = (element) => !isHidden(element, post) && (!layout || hasBox(element.getBoundingClientRect()));
    const cta = [...post.querySelectorAll(CTA)].find((element) => ownerOf2(element) === post) ?? null;
    const groupOrigin = [...post.querySelectorAll("a[href]")].some((a) => inHeader(a) && isGroupLink(a.getAttribute("href")));
    const corroborated = Boolean(cta) && !groupOrigin;
    const found = (signal, label) => ({ signal, label: AD_LABELS.get(label), corroborated });
    const headerText = (holder) => inHeader(holder) && !within(holder, post, NOT_A_LABEL);
    for (const element of [...post.querySelectorAll("span, div")].slice(0, 260)) {
      if (!inHeader(element) || within(element, post, NOT_A_LABEL) || !visible(element)) continue;
      if (element.textContent.length > MAX_SOURCE) continue;
      const values = [ownText(element), element.children.length ? visibleText(element, headerText) : element.textContent];
      for (const value of values) {
        const text = normalizeText(value);
        if (text && text.length <= MAX_LABEL && adLabel(text)) return found("header label", adLabel(text));
      }
    }
    for (const element of post.querySelectorAll("[aria-labelledby]")) {
      if (!inHeader(element)) continue;
      for (const id of normalizeText(element.getAttribute("aria-labelledby")).split(" ")) {
        const target = id && doc.getElementById(id);
        if (namesSomeone(target)) continue;
        const label = target ? readsAsLabel(target) ?? (isScrambled(target) ? decodeGlyphs(target, layout) : null) : adLabel(labelCache?.get(id));
        if (label) return found("labelledby", label);
      }
    }
    for (const svg of post.querySelectorAll("svg")) {
      if (!inHeader(svg)) continue;
      const values = [...svg.querySelectorAll("text")].map((text) => text.textContent);
      for (const use of svg.querySelectorAll("use")) {
        const ref = use.getAttribute("href") ?? use.getAttribute("xlink:href") ?? "";
        if (!ref.startsWith("#")) continue;
        const target = doc.getElementById(ref.slice(1));
        if (target) {
          for (const source of [target, target.nextElementSibling]) if (source && !namesSomeone(source)) values.push(source.textContent);
        } else values.push(labelCache?.get(ref.slice(1)));
      }
      const label = values.map(adLabel).find(Boolean);
      if (label) return found("svg", label);
    }
    for (const element of [...post.querySelectorAll("span, div")].slice(0, 260)) {
      if (!inHeader(element) || within(element, post, NOT_A_LABEL) || !isScrambled(element) || isHidden(element, post)) continue;
      const label = decodeGlyphs(element, layout);
      if (label) return found("glyph order", label);
    }
    for (const a of post.querySelectorAll("a[href]")) {
      if (inHeader(a) && isAdsAboutLink(a.getAttribute("href"))) return { signal: "ads link", label: "Ad", corroborated };
    }
    return corroborated ? { adButton: true } : null;
  }
  function watchSponsoredPosts({ posts, hider, enabled, labelCache, onAd, onAdButton, schedule = setTimeout, cancel = clearTimeout }) {
    const RETRIES2 = [300, 1200, 3e3];
    const timers = /* @__PURE__ */ new Map();
    const settled = /* @__PURE__ */ new WeakSet();
    function forget(element) {
      for (const timer of timers.get(element) ?? []) cancel(timer);
      timers.delete(element);
      settled.delete(element);
    }
    function check(element) {
      if (!enabled() || settled.has(element) || !element.isConnected) return;
      const result = readAdSignals(element, { labelCache });
      if (result?.signal) {
        settled.add(element);
        for (const timer of timers.get(element) ?? []) cancel(timer);
        timers.delete(element);
        if (hider.hide(element, "Sponsored", void 0, result.signal)) onAd?.(result, element);
        return;
      }
      if (result?.adButton && !timers.get(element)?.length) onAdButton?.(element);
    }
    function track({ element }) {
      forget(element);
      timers.set(element, RETRIES2.map((delay) => schedule(() => {
        timers.get(element)?.shift();
        check(element);
      }, delay)));
      check(element);
    }
    const stops = [
      posts.on("post/add", track),
      posts.on("post/update", ({ element }) => check(element)),
      posts.on("post/remove", ({ element }) => forget(element))
    ];
    return {
      check,
      // A fresh look at every post, after the switch comes back on.
      recheckAll() {
        for (const post of posts.current()) track(post);
      },
      stop() {
        for (const stop of stops) stop();
        for (const element of [...timers.keys()]) forget(element);
      }
    };
  }

  // src/features/feed/hide-sponsored-posts.js
  var ROWS_PER_SIGNAL_SHOWN = 5;
  var UNREAD_BUTTONS_BEFORE_WARNING = 3;
  function summary(counts) {
    const parts = [...counts].slice(0, ROWS_PER_SIGNAL_SHOWN).map(([name, n]) => `${name} ${n}`);
    return parts.length ? parts.join(", ") : "None yet";
  }
  var hide_sponsored_posts_default = {
    id: "hideSponsoredPosts",
    section: "feed",
    android: "Hide sponsored posts",
    title: "Hide sponsored posts",
    description: "Removes ads from the news feed before Facebook draws them, and hides any that get drawn anyway.",
    default: true,
    setup({ doc, net, posts, hider, log, settings, diagnostics, enabled }) {
      const data = /* @__PURE__ */ new Map();
      const page = /* @__PURE__ */ new Map();
      const unread = /* @__PURE__ */ new WeakSet();
      let unreadCount = 0;
      let warnedPast = false;
      let warnedUnread = false;
      const changed = () => diagnostics?.changed();
      if (net) {
        net.transformResponses(adRule("hideSponsoredPosts", enabled, (fired) => {
          for (const id of fired) data.set(id, (data.get(id) ?? 0) + 1);
          changed();
        }, { diagnostics, reason: "Sponsored" }));
      }
      if (!posts || !hider) return;
      const labelCache = createLabelCache({ doc });
      if (enabled()) labelCache.start();
      const watcher = watchSponsoredPosts({
        posts,
        hider,
        enabled,
        labelCache,
        onAd({ signal, corroborated }) {
          page.set(signal, (page.get(signal) ?? 0) + 1);
          if (net && !warnedPast) {
            warnedPast = true;
            log.warn(`An ad got past the data rules and was hidden on the page instead (${signal}${corroborated ? ", with an ad button" : ""}). The data rules may need an update.`);
          }
          changed();
        },
        onAdButton(element) {
          if (unread.has(element)) return;
          unread.add(element);
          unreadCount++;
          if (!warnedUnread && unreadCount >= UNREAD_BUTTONS_BEFORE_WARNING && page.size === 0) {
            warnedUnread = true;
            log.warn(`${unreadCount} posts had an ad button but no ad label the script could read. Facebook may have changed how it marks ads.`);
          }
          changed();
        }
      });
      let on = enabled();
      settings.subscribe(() => {
        if (enabled() === on) return;
        on = enabled();
        if (on) {
          labelCache.start();
          watcher.recheckAll();
        } else {
          labelCache.stop();
          hider.showAll("Sponsored");
        }
      });
      diagnostics?.add("Ads taken out of the data", () => net ? summary(data) : "Off: the script can't reach the page's data");
      diagnostics?.add("Ads hidden on the page", () => summary(page));
      diagnostics?.add("Posts with an ad button and no readable label", () => String(unreadCount));
    }
  };

  // src/core/dom/post-checks.js
  var RETRIES = [300, 1200, 3e3];
  function watchPostChecks({ posts, enabled, check, retries = RETRIES, schedule = setTimeout, cancel = clearTimeout }) {
    const timers = /* @__PURE__ */ new Map();
    const done = /* @__PURE__ */ new WeakSet();
    function forget(element) {
      for (const timer of timers.get(element) ?? []) cancel(timer);
      timers.delete(element);
      done.delete(element);
    }
    function run(element) {
      if (!enabled() || done.has(element) || !element.isConnected) return;
      if (!check(element)) return;
      done.add(element);
      for (const timer of timers.get(element) ?? []) cancel(timer);
      timers.delete(element);
    }
    function track({ element }) {
      forget(element);
      timers.set(element, retries.map((delay) => schedule(() => {
        timers.get(element)?.shift();
        run(element);
      }, delay)));
      run(element);
    }
    const stops = [
      posts.on("post/add", track),
      posts.on("post/update", ({ element }) => run(element)),
      posts.on("post/remove", ({ element }) => forget(element))
    ];
    return {
      // A fresh look at every post, after the switch comes back on.
      recheckAll() {
        for (const post of posts.current()) track(post);
      },
      stop() {
        for (const stop of stops) stop();
        for (const element of [...timers.keys()]) forget(element);
      }
    };
  }

  // src/features/feed/hide-suggested-posts.js
  var BUTTONS = /* @__PURE__ */ new Map([["follow", "Follow"], ["join", "Join"]]);
  function suggestionButton(post) {
    const heading = [...post.querySelectorAll('h2, h3, h4, [role="heading"]')].find((h2) => h2.closest(CANDIDATE_SELECTOR) === post);
    if (!heading) return null;
    for (const button of heading.querySelectorAll('[role="button"], button')) {
      const name = BUTTONS.get(normalizeText(visibleText(button)).toLowerCase());
      if (name) return name;
    }
    return null;
  }
  var tally = (map, key) => map.set(key, (map.get(key) ?? 0) + 1);
  var summary2 = (map) => map.size ? [...map].map(([name, n]) => `${name} ${n}`).join(", ") : "None yet";
  var hide_suggested_posts_default = {
    id: "hideSuggestedPosts",
    section: "feed",
    android: "Hide suggested and promoted posts",
    title: "Hide suggested posts",
    description: "Hides posts from Pages, people and groups you don't follow that Facebook mixes into Home and your groups feed.",
    default: true,
    setup({ net, router, posts, hider, settings, diagnostics, enabled }) {
      const data = /* @__PURE__ */ new Map();
      const page = /* @__PURE__ */ new Map();
      const changed = () => diagnostics?.changed();
      const route = () => router?.current();
      if (net) {
        net.transformResponses(adRule("hideSuggestedPosts", enabled, (fired) => {
          for (const id of fired) tally(data, id);
          changed();
        }, { route, diagnostics, reason: "Suggested" }));
      }
      diagnostics?.add("Suggested posts taken out of the data", () => net ? summary2(data) : "Off: the script can't reach the page's data");
      diagnostics?.add("Suggested posts hidden on the page", () => summary2(page));
      if (!posts || !hider) return;
      const watcher = watchPostChecks({
        posts,
        enabled,
        check(element) {
          if (!FEEDS.routes(route())) return true;
          const button = suggestionButton(element);
          if (!button) return false;
          if (hider.hide(element, "Suggested")) {
            tally(page, button);
            changed();
          }
          return true;
        }
      });
      let on = enabled();
      settings.subscribe(() => {
        if (enabled() === on) return;
        on = enabled();
        if (on) watcher.recheckAll();
        else hider.showAll("Suggested");
      });
    }
  };

  // src/features/feed/hide-reels-in-feed.js
  var REEL_LINK = 'a[href*="/reel/"]';
  var NOT_A_ROW = '[data-focus-target="stories_tray"], [role="region"], [role="dialog"], [role="complementary"], [role="navigation"]';
  var MIN_REELS = 2;
  var reelIdOf = (href) => href?.match(/\/reels?\/(\d+)/)?.[1] ?? null;
  function reelRowOf(link) {
    if (link.closest(CANDIDATE_SELECTOR)) return null;
    for (let row = link; row?.parentElement; row = row.parentElement) {
      if (row.matches(CANDIDATE_SELECTOR) || row.matches(NOT_A_ROW)) return null;
      const list = row.parentElement;
      const besidePosts = [...list.children].some((sibling) => sibling !== row && sibling.querySelector(CANDIDATE_SELECTOR));
      if (!besidePosts) continue;
      if (row.querySelector(CANDIDATE_SELECTOR) || row.querySelector(NOT_A_ROW)) return null;
      const reels = new Set([...row.querySelectorAll(REEL_LINK)].map((a) => reelIdOf(a.getAttribute("href"))).filter(Boolean));
      return reels.size >= MIN_REELS ? row : null;
    }
    return null;
  }
  var hide_reels_in_feed_default = {
    id: "hideReelsInFeed",
    section: "feed",
    android: "Hide Reels in the feed",
    title: "Hide reel rows in the feed",
    description: "Hides the rows of reels Facebook puts between posts on Home. Reels your friends post stay.",
    default: false,
    setup({ doc, win, router, hider, log, settings, diagnostics, enabled }) {
      if (!hider || !doc) return;
      let hidden = 0;
      let queued = false;
      const onHome = () => router?.current()?.type === "home";
      function sweep(root = doc.body) {
        if (!enabled() || !onHome() || !root) return;
        const rows = /* @__PURE__ */ new Set();
        for (const link of root.querySelectorAll(REEL_LINK)) {
          const row = reelRowOf(link);
          if (row && !hider.isHidden(row)) rows.add(row);
        }
        for (const row of rows) {
          if (hider.hide(row, "Reels")) {
            hidden++;
            diagnostics?.changed();
          }
        }
      }
      function schedule() {
        if (queued) return;
        queued = true;
        (win ?? globalThis).setTimeout(() => {
          queued = false;
          try {
            sweep();
          } catch (error) {
            log?.error("Looking for reel rows failed", error);
          }
        }, 250);
      }
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      const observer = new Observer((records) => {
        for (const record of records) {
          for (const node of record.addedNodes) {
            if (node.nodeType === 1 && (node.matches(REEL_LINK) || node.querySelector(REEL_LINK))) {
              schedule();
              return;
            }
          }
        }
      });
      const begin = () => {
        observer.observe(doc.body, { childList: true, subtree: true });
        schedule();
      };
      if (doc.body) begin();
      else doc.addEventListener("DOMContentLoaded", begin, { once: true });
      let on = enabled();
      settings.subscribe(() => {
        if (enabled() === on) return;
        on = enabled();
        if (on) schedule();
        else hider.showAll("Reels");
      });
      router?.subscribe(() => schedule());
      diagnostics?.add("Reel rows hidden", () => String(hidden));
    }
  };

  // src/features/feed/hide-stories-tray.js
  var HOME = 'html[data-hfw-route="home"]';
  var TRAY = '[data-focus-target="stories_tray"]';
  var POSTS = '[aria-posinset], [role="article"]';
  var COMPOSER_MARK = "data-hfw-composer";
  var TRAY_SELECTORS = [
    `${HOME} ${TRAY}`,
    // The innermost data-virtualized block around the tray, so its space goes too. Never one
    // that also holds a post.
    `${HOME} [data-virtualized]:has(${TRAY}):not(:has([data-virtualized] ${TRAY}, ${POSTS}))`
  ];
  var COMPOSER_SELECTORS = [
    `${HOME} [role="region"][aria-label="Create a post"]`,
    `${HOME} [${COMPOSER_MARK}]`
  ];
  function composerBlock(doc) {
    const tray = doc.querySelector(TRAY);
    if (!tray) return null;
    for (let block2 = tray; block2.parentElement; block2 = block2.parentElement) {
      const column = block2.parentElement;
      if (column === doc.body || column.matches('[role="main"]')) return null;
      if (!column.querySelector(POSTS)) continue;
      const before = block2.previousElementSibling;
      if (!before || before.matches('[role="banner"], [role="navigation"]')) return null;
      if (before.querySelector(`${TRAY}, ${POSTS}, [role="banner"], [role="navigation"]`)) return null;
      return before.querySelector('[role="button"]') ? before : null;
    }
    return null;
  }
  var hide_stories_tray_default = {
    id: "hideStoriesTray",
    section: "feed",
    android: "Hide Stories tray",
    title: "Hide Stories tray",
    description: "Takes the Stories row off the top of Home. Stories still open from a friend's profile or a link.",
    default: false,
    options: [
      { key: "composer", type: "toggle", label: `Also hide the "What's on your mind?" box`, default: true }
    ],
    css: (get) => {
      const selectors = [...TRAY_SELECTORS, ...get("hideStoriesTray.composer") ? COMPOSER_SELECTORS : []];
      return `${selectors.join(",\n")} { display: none !important; }`;
    },
    setup({ doc, win, log, option, enabled }) {
      if (!doc) return;
      let queued = false;
      let marked = null;
      const mark = () => {
        queued = false;
        if (!enabled() || !option("composer")) return;
        try {
          const block2 = composerBlock(doc);
          if (!block2) return;
          block2.setAttribute(COMPOSER_MARK, "");
          marked = block2;
        } catch (error) {
          log?.error("Looking for the What's on your mind box failed", error);
        }
      };
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      const observer = new Observer(() => {
        if (queued || marked?.isConnected) return;
        queued = true;
        (win ?? globalThis).setTimeout(mark, 200);
      });
      const begin = () => {
        observer.observe(doc.body, { childList: true, subtree: true });
        mark();
      };
      if (doc.body) begin();
      else doc.addEventListener("DOMContentLoaded", begin, { once: true });
    }
  };

  // src/core/filters/engine.js
  var WORD = "[\\p{L}\\p{N}_]";
  var SPECIAL = /[.*+?^${}()|[\]\\]/g;
  function regexFor(source) {
    try {
      return new RegExp(source, "iu");
    } catch {
      return new RegExp(source, "i");
    }
  }
  function phraseRegex(phrase) {
    const body = phrase.split(" ").map((word) => word.replace(SPECIAL, "\\$&")).join("\\s+");
    return new RegExp(`(?<!${WORD})${body}(?!${WORD})`, "iu");
  }
  function compileFilters(text) {
    const rules = [];
    const errors = [];
    String(text ?? "").split(/\r?\n/).forEach((raw, index) => {
      const line = normalizeText(raw);
      if (!line || line === "#" || line.startsWith("# ")) return;
      if (/^re:/i.test(line)) {
        const source = line.slice(3).trim();
        if (!source) return;
        try {
          rules.push({ phrase: line, re: regexFor(source) });
        } catch (error) {
          errors.push({ line: index + 1, phrase: line, message: error.message });
        }
        return;
      }
      rules.push({ phrase: line, re: phraseRegex(line) });
    });
    return { rules, errors };
  }
  function firstMatch(rules, values) {
    if (!rules.length) return null;
    const clean = values.filter(Boolean).map(normalizeText);
    for (const rule of rules) {
      for (const value of clean) if (rule.re.test(value)) return rule;
    }
    return null;
  }
  function filterCache() {
    let text = null;
    let compiled = { rules: [], errors: [] };
    return (next) => {
      if (next !== text) {
        text = next;
        compiled = compileFilters(next);
      }
      return compiled;
    };
  }

  // src/core/url.js
  var SHIM_HOSTS = /* @__PURE__ */ new Set(["l.facebook.com", "lm.facebook.com", "l.messenger.com"]);
  var ANY_HOST = /* @__PURE__ */ new Set([
    "fbclid",
    "mibextid",
    "fb_action_ids",
    "fb_action_types",
    "fb_ref",
    "fb_source",
    "action_object_map",
    "action_type_map",
    "action_ref_map"
  ]);
  var FACEBOOK_ONLY = /* @__PURE__ */ new Set([
    "sfnsn",
    "extid",
    "rdid",
    "share_url",
    "__tn__",
    "__so__",
    "__rv__",
    "_ft_",
    "refsrc",
    "fref",
    "refid",
    "pnref",
    "ls_ref",
    "hc_ref",
    "hc_location",
    "dti",
    "acontext",
    "action_history",
    "video_source",
    "comment_tracking",
    "m_entstream_source",
    "idorvanity",
    "paipv",
    "wtsid",
    "_rdr",
    "_rdc",
    "rdr",
    "rdc",
    "referral_story_type",
    "gd_impression_id",
    "external_ref",
    "store_visit_source"
  ]);
  var FACEBOOK_INDEXED = /^__(?:cft|xts)__\[\d+\]$/;
  function isFacebookHost(host) {
    return /(^|\.)(facebook\.com|fb\.com|messenger\.com)$/i.test(host) || /^(fb\.watch|fb\.me)$/i.test(host);
  }
  function isCdnHost(host) {
    return /(^|\.)fbcdn\.net$/i.test(host);
  }
  function parse(href, base) {
    try {
      const url2 = new URL(href, base);
      return url2.protocol === "http:" || url2.protocol === "https:" ? url2 : null;
    } catch {
      return null;
    }
  }
  function decode(text) {
    try {
      return decodeURIComponent(text.replace(/\+/g, " "));
    } catch {
      return text;
    }
  }
  function isTracking(key, value, facebook) {
    if (ANY_HOST.has(key)) return true;
    if (!facebook) return false;
    return FACEBOOK_ONLY.has(key) || FACEBOOK_INDEXED.test(key) || key === "ref" && value === "share";
  }
  function isOutbound(href) {
    const url2 = parse(href);
    return Boolean(url2) && !isFacebookHost(url2.hostname) && !isCdnHost(url2.hostname);
  }
  function unshim(href, base) {
    const url2 = parse(href, base);
    if (!url2) return null;
    const isShim = SHIM_HOSTS.has(url2.hostname) || isFacebookHost(url2.hostname) && url2.pathname === "/l.php";
    if (!isShim) return null;
    const target = parse(url2.searchParams.get("u") ?? "");
    return target ? target.href : null;
  }
  function stripTracking(href, facebook) {
    const hashAt = href.indexOf("#");
    const head = hashAt === -1 ? href : href.slice(0, hashAt);
    const hash = hashAt === -1 ? "" : href.slice(hashAt);
    const queryAt = head.indexOf("?");
    if (queryAt === -1) return href;
    let removed = false;
    const kept = head.slice(queryAt + 1).split("&").filter((part) => {
      if (!part) return false;
      const eq = part.indexOf("=");
      const key = decode(eq === -1 ? part : part.slice(0, eq));
      const value = eq === -1 ? "" : decode(part.slice(eq + 1));
      if (!isTracking(key, value, facebook)) return true;
      removed = true;
      return false;
    });
    if (!removed) return href;
    return head.slice(0, queryAt) + (kept.length ? `?${kept.join("&")}` : "") + hash;
  }
  function cleanUrl(href, { unwrap = true, base } = {}) {
    const current = unwrap && unshim(href, base) || href;
    const url2 = parse(current, base);
    if (!url2 || isCdnHost(url2.hostname)) return current;
    return stripTracking(current, isFacebookHost(url2.hostname));
  }
  function cleanCopiedText(text) {
    if (typeof text !== "string") return text;
    const trimmed = text.trim();
    if (!/^https?:\/\/\S+$/i.test(trimmed)) return text;
    const cleaned = cleanUrl(trimmed);
    return cleaned === trimmed ? text : cleaned;
  }

  // src/core/filters/story.js
  var TEXT_HOLDERS = /* @__PURE__ */ new Set(["message", "title", "description", "title_with_entities"]);
  var LINK_KEYS = /* @__PURE__ */ new Set(["external_url", "url"]);
  var SKIP_KEYS = /* @__PURE__ */ new Set(["feedback", "comments_disabled_notice_renderer", "easy_hide_button_story", "tracking", "encrypted_tracking"]);
  var KINDS = /* @__PURE__ */ new Map([
    ["StoryAttachmentPhotoStyleRenderer", "photo"],
    ["StoryAttachmentAlbumStyleRenderer", "photo"],
    ["StoryAttachmentAlbumFrameStyleRenderer", "photo"],
    ["StoryAttachmentUnifiedLightweightVideoStyleRenderer", "video"],
    ["StoryAttachmentFBReelsStyleRenderer", "video"],
    ["StoryAttachmentVideoStyleRenderer", "video"],
    ["StoryAttachmentShareStyleRenderer", "link"]
  ]);
  var MAX_DEPTH = 40;
  function hostOf(href) {
    const target = unshim(href) ?? href;
    if (!isOutbound(target)) return null;
    try {
      return new URL(target).hostname.replace(/^www\./, "");
    } catch {
      return null;
    }
  }
  function storyFields(node) {
    const text = /* @__PURE__ */ new Set();
    const authors = /* @__PURE__ */ new Set();
    const alt = /* @__PURE__ */ new Set();
    const sites = /* @__PURE__ */ new Set();
    const kinds = /* @__PURE__ */ new Set();
    (function visit(value, key, parentKey, depth) {
      if (!value || typeof value !== "object" || depth > MAX_DEPTH) return;
      if (Array.isArray(value)) {
        for (const item of value) visit(item, key, parentKey, depth + 1);
        return;
      }
      if (TEXT_HOLDERS.has(key) && typeof value.text === "string") text.add(value.text);
      if ((key === "actors" || key === "to") && typeof value.name === "string") authors.add(value.name);
      if (typeof value.accessibility_caption === "string") alt.add(value.accessibility_caption);
      if (KINDS.has(value.__typename)) kinds.add(KINDS.get(value.__typename));
      if (key === "text_format_metadata" && (value.background_color || value.preset_id || value.background_image)) kinds.add("colored");
      for (const [childKey, child] of Object.entries(value)) {
        if (SKIP_KEYS.has(childKey)) continue;
        if (typeof child === "string") {
          if (LINK_KEYS.has(childKey) && /^https?:/i.test(child)) {
            const host = hostOf(child);
            if (host) sites.add(host);
          }
          continue;
        }
        visit(child, childKey, key, depth + 1);
      }
    })(node, null, null, 0);
    return { text: [...text], authors: [...authors], alt: [...alt], sites: [...sites], kinds };
  }

  // src/core/filters/page.js
  var TEXT = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"], [data-ad-rendering-role="title"], [data-ad-rendering-role="description"]';
  var MESSAGE = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"]';
  var COMMENTS = '[role="article"][aria-label]';
  var PHOTO = 'a[href*="/photo"] img, a[href*="/photos/"] img';
  var VIDEO = 'video, a[href*="/reel/"], a[href*="/watch/"], a[href*="/videos/"]';
  var inComment = (element, post) => {
    const comment = element.closest(COMMENTS);
    return Boolean(comment && comment !== post && post.contains(comment));
  };
  function postFields(post) {
    const own = (selector) => [...post.querySelectorAll(selector)].filter((element) => !inComment(element, post));
    const text = own(TEXT).map((element) => visibleText(element)).filter(Boolean);
    const authors = own('h2 a, h3 a, h4 a, [role="heading"] a').map((a) => normalizeText(a.textContent)).filter(Boolean);
    const alt = own("img[alt]").map((img) => img.getAttribute("alt")).filter((value) => value && value.length > 3);
    const links = own("a[href]");
    const sites = [...new Set(links.map((a) => hostOf(a.href || a.getAttribute("href"))).filter(Boolean))];
    const kinds = /* @__PURE__ */ new Set();
    if (own(PHOTO).length) kinds.add("photo");
    if (own(VIDEO).length) kinds.add("video");
    if (links.some((a) => hostOf(a.href || a.getAttribute("href")) && !a.closest(MESSAGE))) kinds.add("link");
    return { text, authors, alt, sites, kinds };
  }

  // src/core/css-text.js
  var DECLARATION = /^[ \t]*-?[a-z][a-z-]*[ \t]*:[ \t]*[^:;{}\n]+;[ \t]*$/m;
  var PSEUDO = /^[ \t]*[^\s:]*:(?:(?:has|not|is|where|nth-child)\(|(?:first|last)-child\b)/im;
  function hasRule(text) {
    let start = 0;
    for (let i = 0; i < text.length; i += 1) {
      const char = text[i];
      if (char === "\n" || char === "}") start = i + 1;
      if (char !== "{") continue;
      const selector = /\S/.test(text.slice(start, i));
      let colon = false;
      let j = i + 1;
      start = j;
      for (; j < text.length && text[j] !== "{" && text[j] !== "}"; j += 1) {
        if (text[j] === ":") colon = true;
        else if (text[j] === "\n") start = j + 1;
      }
      if (selector && colon && text[j] === "}") return true;
      i = j - 1;
    }
    return false;
  }
  function looksLikeCss(text) {
    const value = String(text ?? "");
    return hasRule(value) || DECLARATION.test(value) || PSEUDO.test(value);
  }

  // src/features/feed/filters.js
  var CSS_WARNING = "Those filter lines look like CSS. Hide posts by words matches words in posts, so put CSS in Custom CSS under Appearance instead.";
  var CSS_WARNED_KEY = "hidePostsByWords.cssWarned";
  var plainLines = (text) => String(text ?? "").split(/\r?\n/).filter((line) => !/^\s*(?:re:|#(?:\s|$))/i.test(line)).join("\n");
  function fingerprint(text) {
    let hash = 2166136261;
    for (let i = 0; i < text.length; i += 1) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619) >>> 0;
    return `${text.length}:${hash.toString(16)}`;
  }
  var KINDS2 = [
    { key: "photos", kind: "photo", label: "photo posts" },
    { key: "videos", kind: "video", label: "video posts" },
    { key: "links", kind: "link", label: "link posts" },
    { key: "colored", kind: "colored", label: "colored background posts" }
  ];
  var FILTERED = {
    queries: /^(?:CometNewsFeedPaginationQuery|GroupsCometCrossGroupFeedPaginationQuery|GroupsCometFeedRegularStoriesPaginationQuery)$/,
    routes: (route) => Boolean(route) && !route.permalink && (route.type === "home" || route.type === "groups")
  };
  function filterVerdict({ rules, kinds }, fields) {
    for (const { kind, label } of KINDS2) if (kinds.has(kind) && fields.kinds.has(kind)) return label;
    return firstMatch(rules, [...fields.text, ...fields.authors, ...fields.alt, ...fields.sites])?.phrase ?? null;
  }
  function pruneFiltered(doc, filter, report) {
    const hits = [];
    walk(doc, (value) => {
      if (Array.isArray(value) || !("cursor" in value) || !value.node || typeof value.node !== "object") return void 0;
      if (value.node.__typename !== "Story" && !value.node.__isFeedUnit) return void 0;
      const reason = filterVerdict(filter, storyFields(value.node));
      if (reason === null) return SKIP;
      report?.(value.node, reason);
      delete value.node;
      delete value.rendering_strategy;
      hits.push(reason);
      return SKIP;
    });
    return hits;
  }
  var tally2 = (map, key) => map.set(key, (map.get(key) ?? 0) + 1);
  var summary3 = (map) => map.size ? [...map].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, n]) => `${name} ${n}`).join(", ") : "None yet";
  var filters_default = {
    id: "hidePostsByWords",
    section: "feed",
    android: "Hide posts by words",
    title: "Hide posts by words",
    description: "Hides posts that mention the words, people, Pages or sites you list, on Home and in groups. Posts you open by their link always show.",
    default: false,
    options: [
      { key: "words", type: "text", label: "One word, name or site per line. Start a line with re: to use a regular expression.", default: "", maxLength: 2e4 },
      ...KINDS2.map(({ key, label }) => ({ key, type: "toggle", label: `Hide all ${label}`, default: false }))
    ],
    setup({ net, router, posts, hider, log, toast, storage, settings, diagnostics, enabled, option }) {
      const compile = filterCache();
      const warned = /* @__PURE__ */ new Set();
      let checked = null;
      const warnIfCss = () => {
        if (!enabled()) return;
        const words = option("words") ?? "";
        if (words === checked) return;
        checked = words;
        if (!looksLikeCss(plainLines(words))) return;
        const print = fingerprint(words);
        if (storage?.get(CSS_WARNED_KEY, null) === print) return;
        storage?.set(CSS_WARNED_KEY, print);
        log?.warn(CSS_WARNING);
        toast?.(CSS_WARNING, { tone: "error" });
      };
      const hits = /* @__PURE__ */ new Map();
      const route = () => router?.current();
      const changed = () => diagnostics?.changed();
      function current() {
        const { rules, errors } = compile(option("words") ?? "");
        for (const error of errors) {
          if (warned.has(error.phrase)) continue;
          warned.add(error.phrase);
          log?.warn(`Filter line ${error.line} isn't a pattern the browser understands, so it's skipped: ${error.message}`);
        }
        const kinds = new Set(KINDS2.filter(({ key }) => option(key) === true).map(({ kind }) => kind));
        return { rules, kinds, errors };
      }
      const active = (filter) => filter.rules.length > 0 || filter.kinds.size > 0;
      if (net) {
        const scope = { scope: FILTERED };
        net.transformResponses({
          id: "hidePostsByWords",
          enabled,
          markers: ['"__isFeedUnit"'],
          match: (ctx) => ctx.transport === "json-parse" || ctx.path.startsWith("/api/graphql"),
          transform(doc, ctx) {
            if (!inScope(scope, ctx, route)) return false;
            const filter = current();
            if (!active(filter)) return false;
            const reasons = pruneFiltered(doc, filter, (story, reason) => diagnostics?.decide({ post: story.post_id ?? story.id, rule: "Filter", signal: reason, layer: "data" }));
            for (const reason of reasons) tally2(hits, reason);
            if (reasons.length) changed();
            return reasons.length > 0;
          }
        });
      }
      warnIfCss();
      settings?.subscribe(warnIfCss);
      diagnostics?.add("Posts hidden by your filters", () => summary3(hits));
      diagnostics?.add("Filter lines that aren't valid", () => {
        const { errors } = current();
        return errors.length ? errors.map((error) => `line ${error.line}`).join(", ") : "None";
      });
      if (!posts || !hider) return;
      const watcher = watchPostChecks({
        posts,
        enabled,
        check(element) {
          if (!FILTERED.routes(route())) return true;
          const filter = current();
          if (!active(filter)) return true;
          const reason = filterVerdict(filter, postFields(element));
          if (reason === null) return false;
          if (hider.hide(element, "Filter", reason)) {
            tally2(hits, reason);
            changed();
          }
          return true;
        }
      });
      const state = () => JSON.stringify([enabled(), option("words"), ...KINDS2.map(({ key }) => option(key))]);
      let last = state();
      settings.subscribe(() => {
        const next = state();
        if (next === last) return;
        last = next;
        hider.showAll("Filter");
        if (enabled()) watcher.recheckAll();
      });
    }
  };

  // src/core/dom/seen-watch.js
  var SEEN_AFTER_MS = 1e3;
  var THRESHOLDS = Array.from({ length: 51 }, (_, i) => i / 50);
  function halfShown(entry, screenHeight) {
    if (!entry.isIntersecting) return false;
    const shown2 = entry.intersectionRect.height;
    const tall = entry.boundingClientRect.height;
    const screen = entry.rootBounds?.height || screenHeight;
    return shown2 > 0 && shown2 >= Math.min(tall, screen) / 2;
  }
  function watchSeen({ posts, win, active, onSeen, snapshot, minMs = SEEN_AFTER_MS, now = () => win.performance.now() }) {
    const Observer = win?.IntersectionObserver;
    if (!posts || typeof Observer !== "function") return { stop() {
    }, flush() {
    } };
    const since = /* @__PURE__ */ new Map();
    const records = /* @__PURE__ */ new Map();
    function leave(element) {
      const shown2 = since.get(element);
      since.delete(element);
      if (shown2 === void 0 || now() - shown2.start < minMs) return;
      const post = records.get(element);
      if (post) onSeen(post, shown2.taken);
    }
    function start(element) {
      const post = records.get(element);
      since.set(element, { start: now(), taken: post && snapshot ? snapshot(post) : void 0 });
    }
    const observer = new Observer((entries) => {
      for (const entry of entries) {
        if (halfShown(entry, win.innerHeight)) {
          if (!since.has(entry.target) && active()) start(entry.target);
        } else {
          leave(entry.target);
        }
      }
    }, { threshold: THRESHOLDS });
    function add(post) {
      records.set(post.element, post);
      observer.observe(post.element);
    }
    function remove({ element }) {
      leave(element);
      records.delete(element);
      observer.unobserve(element);
    }
    function flush() {
      for (const element of [...since.keys()]) leave(element);
    }
    const stops = [
      posts.on("post/add", add),
      posts.on("post/remove", remove),
      posts.on("reset", () => {
        since.clear();
        records.clear();
      })
    ];
    win.addEventListener?.("pagehide", flush);
    return {
      flush,
      stop() {
        for (const stop of stops) stop();
        observer.disconnect();
        win.removeEventListener?.("pagehide", flush);
        since.clear();
        records.clear();
      }
    };
  }

  // src/core/seen-keys.js
  var TEXT_LENGTH = 48;
  var MIN_LETTERS = 24;
  var MEDIA_LINKS = [
    /[?&]fbid=(\d{6,})/,
    /\/photos\/[^/?#]+\/(\d{6,})/,
    /\/reels?\/(\d{6,})/,
    /\/videos\/(?:[^/?#]+\/)?(\d{6,})/,
    /\/watch\/?\?(?:[^#]*&)?v=(\d{6,})/
  ];
  var MEDIA_TYPES = /* @__PURE__ */ new Set(["Photo", "Video"]);
  var MESSAGE2 = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"]';
  var TITLE = '[data-ad-rendering-role="title"]';
  var HEADINGS = 'h1, h2, h3, h4, h5, h6, [role="heading"]';
  var COMMENTS2 = '[role="article"][aria-label]';
  var SKIP_KEYS2 = /* @__PURE__ */ new Set(["feedback", "comments_disabled_notice_renderer", "tracking", "encrypted_tracking"]);
  function fnv(text, seed) {
    let hash = seed >>> 0;
    for (let i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return hash.toString(36);
  }
  var squash = (text) => normalizeText(text).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
  function textKey(text) {
    const letters = squash(text);
    if (letters.length < MIN_LETTERS) return null;
    const start = letters.slice(0, TEXT_LENGTH);
    return `t:${fnv(start, 2166136261)}${fnv(start, 3735928559)}`;
  }
  function mediaIdOf(href) {
    for (const re of MEDIA_LINKS) {
      const found = String(href ?? "").match(re);
      if (found) return found[1];
    }
    return null;
  }
  function pageKeys(post) {
    const keys = /* @__PURE__ */ new Set();
    for (const a of ownLinks(post)) {
      if (a.closest(MESSAGE2) || a.closest(HEADINGS)) continue;
      const id = mediaIdOf(a.getAttribute("href"));
      if (id) keys.add(`m:${id}`);
    }
    const first = (selector) => [...post.querySelectorAll(selector)].find((element) => {
      const comment = element.closest(COMMENTS2);
      return !comment || comment === post || !post.contains(comment);
    });
    const holder = first(MESSAGE2) ?? first(TITLE);
    if (holder) {
      const text = visibleText(holder, (element) => !element.closest('[role="button"]'));
      const key = textKey(text);
      if (key) keys.add(key);
    }
    return [...keys];
  }
  var textOf2 = (holder) => typeof holder?.text === "string" && holder.text ? holder.text : null;
  var messageOf = (story) => textOf2(story?.message) ?? textOf2(story?.comet_sections?.message?.story?.message) ?? textOf2(story?.comet_sections?.message_container?.story?.message);
  function storyText(node) {
    const content = node?.comet_sections?.content?.story ?? node;
    const own = messageOf(content) ?? messageOf(node);
    if (own) return own;
    const shared = messageOf(content?.attached_story) ?? messageOf(node?.attached_story);
    if (shared) return shared;
    return storyFields({ attachments: content?.attachments ?? node?.attachments }).text[0] ?? null;
  }
  function storyKeys(node) {
    const keys = /* @__PURE__ */ new Set();
    (function visit(value, depth, attached) {
      if (!value || typeof value !== "object" || depth > 40) return;
      if (Array.isArray(value)) {
        for (const item of value) visit(item, depth + 1, attached);
        return;
      }
      if (attached && MEDIA_TYPES.has(value.__typename) && typeof value.id === "string" && /^\d{6,}$/.test(value.id)) keys.add(`m:${value.id}`);
      for (const [key2, child] of Object.entries(value)) {
        if (!SKIP_KEYS2.has(key2)) visit(child, depth + 1, attached || key2 === "attachments");
      }
    })(node, 0, false);
    const key = textKey(storyText(node));
    if (key) keys.add(key);
    return [...keys];
  }

  // src/core/seen-store.js
  var SEEN_KEY = "seenPosts";
  var CLEARED_KEY = "seenPostsCleared";
  var DAY2 = 24 * 60 * 60 * 1e3;
  var MAX_AGE = 30 * DAY2;
  var MAX_ENTRIES = 5e3;
  var SAVE_DELAY = 3e3;
  function parse2(raw, cleared = 0) {
    const entries = /* @__PURE__ */ new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return entries;
    for (const [id, at] of Object.entries(raw)) {
      if (id && Number.isFinite(at) && at > 0 && at >= cleared) entries.set(id, at);
    }
    return entries;
  }
  var clearedAt = (raw) => Number.isFinite(raw) && raw > 0 ? raw : 0;
  function createSeenStore({
    storage,
    log,
    now = Date.now,
    maxAge = MAX_AGE,
    maxEntries = MAX_ENTRIES,
    schedule = setTimeout,
    cancel = clearTimeout,
    every = setInterval
  } = {}) {
    let entries = /* @__PURE__ */ new Map();
    let cleared = 0;
    try {
      cleared = clearedAt(storage?.get(CLEARED_KEY, 0));
      entries = parse2(storage?.get(SEEN_KEY, null), cleared);
    } catch (error) {
      log?.error("Couldn't read the seen posts list, starting a new one", error);
    }
    let timer = null;
    function save() {
      timer = null;
      try {
        storage?.set(SEEN_KEY, Object.fromEntries(entries));
      } catch (error) {
        log?.error("Couldn't save the seen posts list", error);
      }
    }
    function later() {
      if (timer === null) timer = schedule(save, SAVE_DELAY);
    }
    function prune() {
      const before = entries.size;
      const cutoff = now() - maxAge;
      for (const [id, at] of entries) if (at < cutoff) entries.delete(id);
      if (entries.size > maxEntries) {
        const newest = [...entries].sort((a, b) => b[1] - a[1]).slice(0, maxEntries);
        entries = new Map(newest);
      }
      return before - entries.size;
    }
    if (prune()) later();
    const daily = every?.(() => {
      if (prune()) later();
    }, DAY2);
    daily?.unref?.();
    storage?.onChange?.(SEEN_KEY, (raw) => {
      for (const [id, at] of parse2(raw, cleared)) {
        const mine = entries.get(id);
        if (mine === void 0 || at < mine) entries.set(id, at);
      }
    });
    storage?.onChange?.(CLEARED_KEY, (raw) => {
      const at = clearedAt(raw);
      if (at <= cleared) return;
      cleared = at;
      for (const [id, seen] of entries) if (seen < cleared) entries.delete(id);
    });
    return {
      // Remembers ids not already known, keeping the first time each was seen.
      add(ids) {
        let added = false;
        for (const id of [ids].flat()) {
          if (!id || entries.has(id)) continue;
          entries.set(id, now());
          added = true;
        }
        if (added) {
          if (entries.size > maxEntries) prune();
          later();
        }
        return added;
      },
      // The ids first seen at or after from (ms), and before until.
      since(from, until = Infinity) {
        const ids = /* @__PURE__ */ new Set();
        for (const [id, at] of entries) if (at >= from && at < until) ids.add(id);
        return ids;
      },
      has: (id) => entries.has(id),
      size: () => entries.size,
      clear() {
        cleared = Math.max(now(), cleared);
        entries.clear();
        if (timer !== null) cancel(timer);
        try {
          storage?.set(CLEARED_KEY, cleared);
        } catch (error) {
          log?.error("Couldn't save when the seen posts list was forgotten", error);
        }
        save();
      },
      // Writes now instead of waiting, for when the page is going away.
      flush() {
        if (timer === null) return;
        cancel(timer);
        save();
      }
    };
  }

  // src/features/feed/hide-seen-posts.js
  var DAY3 = 24 * 60 * 60 * 1e3;
  var DAYS = [1, 3, 7, 30];
  var SHOW_KEY = "hfw.showSeen";
  var matchedBy = (key) => key.startsWith("m:") ? "same photo or video" : "same text";
  function pruneSeen(doc, isSeen, report) {
    let dropped = 0;
    walk(doc, (value) => {
      if (Array.isArray(value) || !("cursor" in value) || !value.node || typeof value.node !== "object") return void 0;
      if (value.node.__typename !== "Story" && !value.node.__isFeedUnit) return void 0;
      const key = storyKeys(value.node).find(isSeen);
      if (key === void 0) return SKIP;
      report?.(value.node, key);
      delete value.node;
      delete value.rendering_strategy;
      dropped++;
      return SKIP;
    });
    return dropped;
  }
  function tabFlag(win) {
    return {
      get() {
        try {
          return win?.sessionStorage?.getItem(SHOW_KEY) === "1";
        } catch {
          return false;
        }
      },
      set(on) {
        try {
          if (on) win.sessionStorage.setItem(SHOW_KEY, "1");
          else win.sessionStorage.removeItem(SHOW_KEY);
        } catch {
        }
      }
    };
  }
  var hide_seen_posts_default = {
    id: "hideSeenPosts",
    section: "feed",
    android: "Hide seen posts",
    title: "Hide seen posts",
    description: "Hides posts on Home and in your groups feed that you've already scrolled past. A post counts as seen after a second on screen, and it's recognized by its photo or video, or by its first words.",
    default: false,
    options: [
      {
        key: "days",
        type: "select",
        label: "Keep seen posts hidden for",
        default: 7,
        choices: DAYS.map((n) => ({ value: n, label: n === 1 ? "1 day" : `${n} days` }))
      }
    ],
    setup({ win, net, router, posts, hider, storage, actions, diagnostics, settings, log, enabled, option, now = Date.now }) {
      const store = createSeenStore({ storage, log, now });
      const flag = tabFlag(win);
      const route = () => router?.current();
      const changed = () => diagnostics?.changed();
      const days = () => DAYS.includes(Number(option("days"))) ? Number(option("days")) : 7;
      let showing = flag.get();
      let before = /* @__PURE__ */ new Set();
      let until = now();
      const refresh = (moment = now()) => {
        until = moment;
        before = store.since(now() - days() * DAY3, until);
      };
      refresh();
      const isSeen = (key) => before.has(key);
      const hiding = () => enabled() && !showing && before.size > 0;
      let dropped = 0;
      let hidden = 0;
      if (net) {
        const scope = { scope: FILTERED };
        net.transformResponses({
          id: "hideSeenPosts",
          enabled: hiding,
          markers: ['"__isFeedUnit"'],
          match: (ctx) => ctx.transport === "json-parse" || ctx.path.startsWith("/api/graphql"),
          transform(doc, ctx) {
            if (!inScope(scope, ctx, route)) return false;
            const count = pruneSeen(doc, isSeen, (story, key) => diagnostics?.decide({ post: story.post_id ?? story.id, rule: "Seen", signal: matchedBy(key), layer: "data" }));
            if (count) {
              dropped += count;
              changed();
            }
            return count > 0;
          }
        });
      }
      diagnostics?.add("Seen posts remembered", () => String(store.size()));
      diagnostics?.add("Seen posts hidden", () => {
        if (showing) return "None: showing them in this tab";
        return net ? `${dropped} taken out of the data, ${hidden} hidden on the page` : `${hidden} hidden on the page`;
      });
      let watcher = null;
      if (posts && win) {
        watchSeen({
          posts,
          win,
          active: () => enabled() && FILTERED.routes(route()),
          now,
          // Read when the post starts showing, in case Facebook puts another story in its place.
          snapshot: (post) => pageKeys(post.element),
          onSeen(post, keys) {
            if (store.add(keys?.length ? keys : pageKeys(post.element))) changed();
          }
        });
        win.addEventListener?.("pagehide", () => store.flush());
      }
      if (posts && hider) {
        watcher = watchPostChecks({
          posts,
          enabled: hiding,
          check(element) {
            if (!FILTERED.routes(route())) return true;
            const key = pageKeys(element).find(isSeen);
            if (key === void 0) return false;
            if (hider.hide(element, "Seen", void 0, matchedBy(key))) {
              hidden++;
              changed();
            }
            return true;
          }
        });
      }
      let inFeed = FILTERED.routes(route());
      router?.subscribe?.((current) => {
        const inside2 = FILTERED.routes(current);
        if (inside2 && !inFeed) {
          refresh();
          if (hiding()) watcher?.recheckAll();
        }
        inFeed = inside2;
      });
      actions?.add(() => showing ? "Hide seen posts again" : "Show seen posts in this tab", () => {
        showing = !showing;
        flag.set(showing);
        if (showing) {
          hider?.showAll("Seen");
        } else {
          refresh();
          watcher?.recheckAll();
        }
        changed();
      });
      actions?.add("Forget all seen posts", () => {
        store.clear();
        before = /* @__PURE__ */ new Set();
        hider?.showAll("Seen");
        changed();
      });
      const state = () => JSON.stringify([enabled(), days()]);
      let last = state();
      settings?.subscribe(() => {
        const next = state();
        if (next === last) return;
        last = next;
        refresh(until);
        hider?.showAll("Seen");
        if (hiding()) watcher?.recheckAll();
      });
    }
  };

  // src/features/feed/hide-ai-posts.js
  var hide_ai_posts_default = {
    id: "hideAiPosts",
    section: "feed",
    android: "Hide AI-detected posts",
    title: "Hide AI-detected posts",
    description: "Hides posts Facebook labels as made with AI, and shares of them, from Home, your groups feed and search results. It goes by the AI info label, whether Facebook detected it or the author added it.",
    default: false,
    needsPage: true,
    setup({ net, router, diagnostics, enabled }) {
      let dropped = 0;
      if (net) {
        net.transformResponses(adRule("hideAiPosts", enabled, (fired) => {
          dropped += fired.length;
          diagnostics?.changed();
        }, { route: () => router?.current(), diagnostics, reason: "AI label" }));
      }
      diagnostics?.add("AI-labeled posts taken out of the data", () => net ? String(dropped) : "Off: the script can't reach the page's data");
    }
  };

  // src/features/feed/post-dates.js
  var DATE_MARK = "data-hfw-post-date";
  var MARKERS = ['"comet_sections"'];
  var MAX_REMEMBERED = 4e3;
  var MESSAGE3 = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"]';
  var HEADINGS2 = 'h1, h2, h3, h4, h5, h6, [role="heading"]';
  var POST_DATES_CSS = `[${DATE_MARK}] { margin-inline-start: 0.25em; white-space: nowrap; }`;
  function indexTimes(data, remember2) {
    let found = 0;
    (function visit(value, depth) {
      if (!value || typeof value !== "object" || depth > 80) return;
      if (Array.isArray(value)) {
        for (const item of value) visit(item, depth + 1);
        return;
      }
      if (Number.isFinite(value.creation_time) && value.creation_time > 0 && value.comet_sections && typeof value.comet_sections === "object") {
        for (const key of storyKeys(value)) remember2(key, value.creation_time);
        found++;
        return;
      }
      for (const child of Object.values(value)) visit(child, depth + 1);
    })(data, 0);
    return found;
  }
  function createTimeBook({ max = MAX_REMEMBERED } = {}) {
    const times = /* @__PURE__ */ new Map();
    const shared = /* @__PURE__ */ new Map();
    const gone = /* @__PURE__ */ new Map();
    const add = (map, key, value) => {
      map.delete(key);
      map.set(key, value);
      if (map.size <= max) return null;
      const [oldest, time] = map.entries().next().value;
      map.delete(oldest);
      return [oldest, time];
    };
    return {
      remember(key, seconds) {
        if (shared.has(key)) {
          add(shared, key, true);
          return;
        }
        const before = times.has(key) ? times.get(key) : gone.get(key);
        gone.delete(key);
        if (before !== void 0 && before !== seconds) {
          times.delete(key);
          add(shared, key, true);
          return;
        }
        const dropped = add(times, key, seconds);
        if (dropped) add(gone, ...dropped);
      },
      // A post's time, by its first key that has one: a photo or video first, then its words.
      timeOf: (keys) => keys.map((key) => shared.has(key) ? null : times.get(key)).find((seconds) => typeof seconds === "number") ?? null
    };
  }
  function timeLinkOf(post) {
    return ownLinks(post).find((a) => a.hasAttribute("target") && !a.hasAttribute("rel") && !a.hasAttribute("aria-label") && !a.closest(MESSAGE3) && !a.closest(HEADINGS2) && !a.closest("object")) ?? null;
  }
  function formatTime(seconds, lang) {
    const when = new Date(seconds * 1e3);
    try {
      return new Intl.DateTimeFormat(lang || void 0, { dateStyle: "medium", timeStyle: "short" }).format(when);
    } catch {
      return when.toLocaleString();
    }
  }
  function showDate(doc, post, seconds, lang = doc.documentElement?.lang) {
    const link = timeLinkOf(post);
    for (const old of post.querySelectorAll(`[${DATE_MARK}]`)) {
      if (old.previousElementSibling !== link) old.remove();
    }
    if (!link || seconds === null) return false;
    const value = String(seconds);
    const next = link.nextElementSibling;
    if (next?.hasAttribute(DATE_MARK)) {
      if (next.getAttribute(DATE_MARK) !== value) {
        next.setAttribute(DATE_MARK, value);
        next.textContent = `· ${formatTime(seconds, lang)}`;
      }
      return true;
    }
    const span = doc.createElement("span");
    span.setAttribute(DATE_MARK, value);
    span.textContent = `· ${formatTime(seconds, lang)}`;
    link.after(span);
    return true;
  }
  var post_dates_default = {
    id: "keepPostDates",
    section: "feed",
    android: "Keep post dates",
    title: "Show full post dates",
    description: `Each post shows the day and time it went up next to Facebook's short "3h" or "2d", so you don't have to point at it to find out.`,
    default: false,
    needsPage: true,
    css: POST_DATES_CSS,
    setup({ doc, net, posts, enabled, settings, diagnostics }) {
      const book = createTimeBook();
      net.transformResponses({
        id: "keepPostDates",
        enabled,
        markers: MARKERS,
        // Facebook parses its feed answers and the page's inline data with JSON.parse, so this
        // sees every story. It only reads.
        match: (ctx) => ctx.transport === "json-parse",
        transform(data) {
          indexTimes(data, book.remember);
          return false;
        }
      });
      let shown2 = 0;
      const check = (element) => {
        const had = Boolean(element.querySelector(`[${DATE_MARK}]`));
        const done = showDate(doc, element, book.timeOf(pageKeys(element)));
        if (done && !had) {
          shown2++;
          diagnostics?.changed();
        }
        return done;
      };
      if (posts) {
        const watcher = watchPostChecks({ posts, enabled, check });
        posts.on("post/update", ({ element }) => {
          if (enabled()) check(element);
        });
        let on = enabled();
        settings?.subscribe(() => {
          if (enabled() === on) return;
          on = enabled();
          if (on) watcher.recheckAll();
          else for (const mark of doc.querySelectorAll(`[${DATE_MARK}]`)) mark.remove();
        });
      }
      diagnostics?.add("Post dates shown", () => String(shown2));
    }
  };

  // src/features/feed/keep-feed-place.js
  var CONSTANTS = "CometFeedStalenessConstantsEntryPointVariables";
  var ROUTES = "CometReturnToFeedRouteUtils";
  var LIMITS = ["FEED_STALE_TIMEOUT", "FEED_VISIBILITY_TIMEOUT", "FEED_STALE_PUSH_VIEW_TIMEOUT"];
  var NEVER = 2 ** 31 - 1;
  function holdLimits(exports, enabled) {
    if (!exports || typeof exports !== "object") return 0;
    let held = 0;
    for (const key of LIMITS) {
      const own = Object.getOwnPropertyDescriptor(exports, key);
      if (!own || !("value" in own) || !own.configurable || typeof own.value !== "number") continue;
      let value = own.value;
      Object.defineProperty(exports, key, {
        configurable: true,
        enumerable: own.enumerable,
        get: () => enabled() && typeof value === "number" ? NEVER : value,
        set: (next) => {
          value = next;
        }
      });
      held++;
    }
    return held;
  }
  function holdRouteCheck(exports, enabled) {
    const own = exports && typeof exports === "object" ? Object.getOwnPropertyDescriptor(exports, "isRouteEligible") : null;
    if (!own || typeof own.value !== "function" || !(own.writable || own.configurable)) return false;
    const original = own.value;
    const held = function isRouteEligible(...args) {
      return enabled() ? false : original.apply(this, args);
    };
    Object.defineProperty(exports, "isRouteEligible", { ...own, value: held });
    return true;
  }
  var WAITING = "Facebook's code isn't loaded yet";
  var keep_feed_place_default = {
    id: "keepFeedPlace",
    section: "feed",
    android: "Block background-return feed refresh",
    title: "Keep your place in the feed",
    description: "Facebook reloads Home from the top when you come back after a couple of minutes in another tab, or ten minutes away from the computer. After half an hour away it also moves you from a group, Marketplace or search to Home. With this on, you stay where you were.",
    default: false,
    needsPage: true,
    setup({ win, settings, enabled, diagnostics, log, markUnavailable }) {
      const state = { home: WAITING, pages: WAITING };
      let started = false;
      const start = () => {
        if (started || !enabled()) return;
        started = true;
        whenModule(win, CONSTANTS, (exports) => {
          const held = holdLimits(exports, enabled);
          state.home = held === LIMITS.length ? "held" : `${held} of ${LIMITS.length} limits held, Facebook's code has changed`;
          if (!held) {
            log?.warn("Keep your place in the feed couldn't find Facebook's feed refresh limits. Facebook's code has changed.");
            markUnavailable?.();
          }
          diagnostics?.changed();
        }, { log });
        whenModule(win, ROUTES, (exports) => {
          const held = holdRouteCheck(exports, enabled);
          state.pages = held ? "held" : "not held, Facebook's code has changed";
          if (!held) log?.warn("Keep your place in the feed couldn't find Facebook's return to Home check. Facebook's code has changed.");
          diagnostics?.changed();
        }, { log });
      };
      start();
      settings?.subscribe(start);
      diagnostics?.add("Return refresh on Home", () => started ? state.home : "switch off");
      diagnostics?.add("Return to Home from other pages", () => started ? state.pages : "switch off");
    }
  };

  // src/features/privacy/usage-logs.js
  var LOG_PATHS = /* @__PURE__ */ new Set(["/ajax/bnzai"]);
  var EMPTY_ANSWER = 'for (;;);{"__ar":1,"payload":null}';
  var facebookHost = (host) => host === "facebook.com" || host.endsWith(".facebook.com");
  var isUsageLog = (ctx) => facebookHost(ctx.host ?? "") && LOG_PATHS.has(ctx.path);
  var usage_logs_default = {
    id: "holdBackLogs",
    section: "privacy",
    android: "Hold back analytics uploads",
    title: "Hold back usage logs",
    description: "Facebook's site keeps a log of what you look at and click, and sends it in batches as you go. With this on, those batches never leave your browser. Nothing else is held back.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let held = 0;
      net.blockRequests({
        id: "holdBackLogs",
        enabled,
        match: isUsageLog,
        fakeResponse: () => {
          held++;
          diagnostics?.changed();
          return EMPTY_ANSWER;
        }
      });
      diagnostics?.add("Usage log batches held back", () => String(held));
    }
  };

  // src/features/reels/hide-sponsored-reels.js
  var hide_sponsored_reels_default = {
    id: "hideSponsoredReels",
    section: "reels",
    android: "Hide sponsored reels",
    title: "Hide sponsored reels",
    description: "Drops the ad breaks Facebook schedules inside videos and reels.",
    default: true,
    needsPage: true,
    // Only the count goes to Diagnostics. A cleared schedule isn't a hidden post, and the same
    // video comes back in answer after answer, so on the decision list it would push every real
    // decision off within a few minutes of scrolling video.
    setup({ net, enabled, diagnostics }) {
      let breaks = 0;
      net.transformResponses(adRule("hideSponsoredReels", enabled, (ids) => {
        breaks += ids.length;
        diagnostics?.changed();
      }));
      diagnostics?.add("Videos cleared of ad breaks", () => String(breaks));
    }
  };

  // src/features/reels/no-watch-history.js
  var HISTORY_MUTATIONS = /* @__PURE__ */ new Set(["FBUnifiedVideoSeenStateMutation"]);
  var EMPTY_SUCCESS = '{"data":{},"errors":[]}';
  var no_watch_history_default = {
    id: "noWatchHistory",
    section: "reels",
    android: "Don't send reel watch history",
    title: "Don't send watch history",
    description: "Facebook isn't told which reels and videos you've watched, so they don't shape what it shows you next. Ones you've already seen can come around again.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let held = 0;
      net.blockRequests({
        id: "noWatchHistory",
        enabled,
        match: (ctx) => HISTORY_MUTATIONS.has(ctx.friendlyName),
        fakeResponse: () => {
          held++;
          diagnostics?.changed();
          return EMPTY_SUCCESS;
        }
      });
      diagnostics?.add("Watch reports held back", () => String(held));
    }
  };

  // src/features/stories/anonymous-stories.js
  var SEEN_MUTATIONS = /* @__PURE__ */ new Set(["storiesUpdateSeenStateMutation"]);
  var anonymous_stories_default = {
    id: "anonymousStories",
    section: "stories",
    android: "View stories anonymously",
    title: "View stories anonymously",
    description: "Keeps you off the viewer list of stories you watch, because Facebook isn't told which ones you've seen. Replying or reacting still shows you.",
    default: false,
    needsPage: true,
    setup({ net, enabled }) {
      net.blockRequests({
        id: "anonymousStories",
        enabled,
        match: (ctx) => SEEN_MUTATIONS.has(ctx.friendlyName),
        fakeResponse: () => '{"data":{},"errors":[]}'
      });
    }
  };

  // src/features/stories/stop-advance.js
  var END_MARGIN = 0.5;
  var SHORTEST = 1;
  var INPUT_WINDOW = 1500;
  var isVideo = (node) => node?.tagName === "VIDEO";
  var sameCard = (video, mark) => mark && mark.src === video.currentSrc && mark.duration === video.duration;
  var WRITING = 'input, textarea, select, [contenteditable=""], [contenteditable="true"], [role="textbox"], [role="combobox"], [role="searchbox"]';
  var MENU = '[role="menu"], [role="menuitem"], [role="menuitemradio"], [role="listbox"], [role="option"]';
  var PLAY_KEYS = /* @__PURE__ */ new Set([" ", "k", "K", "Enter"]);
  var ROW_SLACK = 8;
  var inReplyBar = (button) => {
    const box = button.getBoundingClientRect?.();
    if (!box?.height) return false;
    const middle = box.top + box.height / 2;
    for (const field of button.ownerDocument?.querySelectorAll(WRITING) ?? []) {
      const row = field.getBoundingClientRect();
      if (row.height && middle >= row.top - ROW_SLACK && middle <= row.bottom + ROW_SLACK) return true;
    }
    return false;
  };
  function asksToPlay(event) {
    const start = event.composedPath?.()[0] ?? event.target;
    const element = typeof start?.closest === "function" ? start : start?.parentElement ?? null;
    if (event.type === "keydown") {
      if (!PLAY_KEYS.has(event.key)) return false;
      return !element?.closest?.(WRITING) && !element?.closest?.(MENU);
    }
    if (!element || element.closest(WRITING) || element.closest(MENU)) return false;
    const button = element.closest('button, [role="button"]');
    return Boolean(button) && !inReplyBar(button);
  }
  function createStoryHold({ doc, win = doc.defaultView, enabled, mode, inViewer, onChange, trusted = (event) => event.isTrusted, now = () => Date.now() }) {
    const held = /* @__PURE__ */ new WeakMap();
    const released = /* @__PURE__ */ new WeakMap();
    let holds = 0;
    let replays = 0;
    let lastInput = Number.NEGATIVE_INFINITY;
    const cardOf = (video) => ({ src: video.currentSrc, duration: video.duration });
    function onTime(event) {
      const video = event.target;
      if (!isVideo(video) || !enabled() || !inViewer()) return;
      const { duration, currentTime } = video;
      if (!Number.isFinite(duration) || duration < SHORTEST || video.loop) return;
      if (currentTime < duration - END_MARGIN) return;
      if (mode() === "replay") {
        video.currentTime = 0;
        replays++;
        onChange?.();
        return;
      }
      if (video.paused || sameCard(video, released.get(video))) return;
      if (!sameCard(video, held.get(video))) holds++;
      held.set(video, cardOf(video));
      video.pause();
      onChange?.();
    }
    function onPlay(event) {
      const video = event.target;
      if (!isVideo(video)) return;
      const atEnd = Number.isFinite(video.duration) && video.currentTime >= video.duration - END_MARGIN;
      const goOn = sameCard(video, held.get(video)) || atEnd;
      if (!goOn) released.delete(video);
      else if (now() - lastInput < INPUT_WINDOW) {
        held.delete(video);
        released.set(video, cardOf(video));
      }
    }
    const onInput = (event) => {
      if (!trusted(event) || !enabled() || !inViewer()) return;
      lastInput = asksToPlay(event) ? now() : Number.NEGATIVE_INFINITY;
    };
    const listen = { capture: true, passive: true };
    return {
      start() {
        doc.addEventListener("timeupdate", onTime, true);
        doc.addEventListener("play", onPlay, true);
        win?.addEventListener("pointerdown", onInput, listen);
        win?.addEventListener("keydown", onInput, listen);
      },
      stop() {
        doc.removeEventListener("timeupdate", onTime, true);
        doc.removeEventListener("play", onPlay, true);
        win?.removeEventListener("pointerdown", onInput, listen);
        win?.removeEventListener("keydown", onInput, listen);
      },
      state: () => ({ holds, replays })
    };
  }
  var inStoryViewer = (doc) => /^\/stories\//.test(doc.location?.pathname ?? "");
  var stop_advance_default = {
    id: "stopStoryAdvance",
    section: "stories",
    android: "Stop Story auto-advance",
    title: "Stop stories moving on",
    description: "A video story stays on screen when it ends instead of moving to the next one, so you go on when you're ready with the arrow. You can have it play again instead. Photo stories still move on by themselves for now.",
    default: false,
    options: [
      {
        key: "atEnd",
        type: "select",
        label: "When a story ends",
        default: "hold",
        choices: [
          { value: "hold", label: "Stay on its last moment" },
          { value: "replay", label: "Play it again" }
        ]
      }
    ],
    setup({ doc, win, enabled, option, diagnostics }) {
      const hold = createStoryHold({
        doc,
        win: win ?? doc.defaultView,
        enabled,
        mode: () => option("atEnd"),
        inViewer: () => inStoryViewer(doc),
        onChange: () => diagnostics?.changed()
      });
      hold.start();
      diagnostics?.add("Stories held at the end", () => String(hold.state().holds));
      diagnostics?.add("Stories played again", () => String(hold.state().replays));
    }
  };

  // src/features/search/hide-sponsored-search.js
  var hide_sponsored_search_default = {
    id: "hideSponsoredSearch",
    section: "search",
    android: "Hide sponsored search results",
    title: "Hide sponsored search results",
    description: "Takes the ads out of search results before Facebook draws them.",
    default: true,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      net.transformResponses(adRule("hideSponsoredSearch", enabled, void 0, { diagnostics, reason: "Sponsored result" }));
    }
  };

  // src/features/marketplace/hide-sponsored-marketplace.js
  var hide_sponsored_marketplace_default = {
    id: "hideSponsoredMarketplace",
    section: "marketplace",
    android: "Hide sponsored Marketplace listings",
    title: "Hide sponsored Marketplace listings",
    description: "Takes ad cards out of Marketplace before Facebook draws them. The listings around them stay where they are.",
    default: true,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      net.transformResponses(adRule("hideSponsoredMarketplace", enabled, void 0, { diagnostics, reason: "Sponsored listing" }));
    }
  };

  // src/features/marketplace/seller-profile.js
  var MARK2 = "data-hfw-seller-profile";
  var LABEL = "View profile";
  var PROFILE_LINKS = 'a[href*="/marketplace/profile/"]';
  var DELAY = 100;
  var SELLER_PROFILE_CSS = `
a[${MARK2}] {
  display: inline-block !important;
  margin-inline-start: 8px !important;
  color: var(--blue-link, #0866ff) !important;
  font-size: .9375rem !important;
  font-weight: 400 !important;
  white-space: nowrap !important;
  text-decoration: none !important;
}
a[${MARK2}]:hover, a[${MARK2}]:focus-visible { text-decoration: underline !important; }`;
  function sellerId(href, base) {
    try {
      const url2 = new URL(href, base);
      if (!/(^|\.)facebook\.com$/.test(url2.hostname)) return null;
      return url2.pathname.match(/^\/marketplace\/profile\/(\d+)\/?$/)?.[1] ?? null;
    } catch {
      return null;
    }
  }
  function isListing(href) {
    try {
      return /^\/marketplace\/item\/\d+/.test(new URL(href).pathname);
    } catch {
      return false;
    }
  }
  var profileUrl = (id) => `/profile.php?id=${id}`;
  function nameLinks(root, base) {
    const byId = /* @__PURE__ */ new Map();
    for (const link of root.querySelectorAll(PROFILE_LINKS)) {
      const id = sellerId(link.getAttribute("href"), base);
      if (!id) continue;
      if (!byId.has(id)) byId.set(id, []);
      byId.get(id).push(link);
    }
    const found = [];
    for (const [id, links] of byId) {
      const labels = links.map((link) => normalizeText(link.getAttribute("aria-label") ?? ""));
      const name = links.find((link, index) => {
        if (labels[index]) return false;
        const text = normalizeText(link.textContent);
        return text && labels.some((label, other) => other !== index && label === text);
      });
      if (name) found.push({ id, link: name });
    }
    return found;
  }
  function addProfileLink(doc, { id, link }) {
    const next = link.nextElementSibling;
    if (next?.hasAttribute(MARK2)) {
      if (next.getAttribute(MARK2) !== id) {
        next.setAttribute(MARK2, id);
        next.setAttribute("href", profileUrl(id));
      }
      return false;
    }
    const view = doc.createElement("a");
    view.setAttribute(MARK2, id);
    view.setAttribute("href", profileUrl(id));
    view.setAttribute("role", "link");
    view.textContent = LABEL;
    link.after(view);
    return true;
  }
  var MAX_ADDS = 20;
  function createSellerLinks({ doc, enabled, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    let added = 0;
    let timer = null;
    let shown2 = false;
    let listing = "";
    let addsFor = /* @__PURE__ */ new Map();
    const href = () => doc.location?.href ?? "";
    const wanted = () => enabled() && isListing(href());
    function sync() {
      timer = null;
      if (!wanted()) {
        for (const link of doc.querySelectorAll(`a[${MARK2}]`)) link.remove();
        shown2 = false;
        return;
      }
      if (href() !== listing) {
        listing = href();
        addsFor = /* @__PURE__ */ new Map();
      }
      for (const found of nameLinks(doc, listing)) {
        const adds = addsFor.get(found.id) ?? 0;
        if (adds >= MAX_ADDS) continue;
        if (addProfileLink(doc, found)) {
          added++;
          addsFor.set(found.id, adds + 1);
        }
      }
      shown2 = Boolean(doc.querySelector(`a[${MARK2}]`));
    }
    const schedule = () => {
      timer ??= setTimer(sync, DELAY);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (shown2 || wanted()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      added: () => added
    };
  }
  var seller_profile_default = {
    id: "sellerProfileLink",
    section: "marketplace",
    android: "Show View profile on Marketplace sellers",
    title: "View profile on Marketplace sellers",
    description: "Adds a View profile link after the seller's name on a listing, so you can see their full Facebook profile before you message them, not just their Marketplace page.",
    default: true,
    css: SELLER_PROFILE_CSS,
    setup({ doc, router, settings, diagnostics, enabled }) {
      const links = createSellerLinks({ doc, enabled });
      diagnostics?.add("Seller profile links added", () => String(links.added()));
      const begin = () => links.start();
      if (doc.body) begin();
      else doc.addEventListener("DOMContentLoaded", begin, { once: true });
      router?.subscribe(() => links.schedule());
      settings?.subscribe(() => links.schedule());
    }
  };

  // src/features/chats/shared.js
  var shown = /* @__PURE__ */ new WeakSet();
  function chatSocketRow({ net, diagnostics }) {
    if (!net || !diagnostics || shown.has(net)) return;
    shown.add(net);
    diagnostics.add("Chat socket", () => {
      const { messages, unreadable } = net.chatStats;
      if (!messages) return "Facebook hasn't sent anything over chat in this tab yet";
      const sent = `${messages} ${messages === 1 ? "message" : "messages"} sent`;
      return unreadable ? `${sent}, ${unreadable} the script couldn't read` : sent;
    });
  }

  // src/features/chats/hide-read-receipts.js
  var MARK_READ = "21";
  var hide_read_receipts_default = {
    id: "hideReadReceipts",
    section: "chats",
    android: "Hide read receipts",
    title: "Hide read receipts",
    description: "People you chat with don't see that you've read their messages, and the chat stays unread in your other apps. When you reply they'll know anyway. End-to-end encrypted chats, which most one-to-one chats are now, aren't covered, because their receipts are encrypted before the script can see them.",
    default: false,
    needsPage: true,
    setup(ctx) {
      const { net, diagnostics, enabled } = ctx;
      let held = 0;
      if (net) {
        net.editChatRequests({
          id: "hideReadReceipts",
          enabled,
          edit(request) {
            const tasks = request.type === 3 ? request.payload.tasks : null;
            if (!Array.isArray(tasks)) return false;
            const kept = tasks.filter((task) => String(task?.label) !== MARK_READ);
            if (kept.length === tasks.length) return false;
            held += tasks.length - kept.length;
            request.payload.tasks = kept;
            diagnostics?.changed();
            return true;
          }
        });
      }
      diagnostics?.add("Read receipts held back", () => net ? String(held) : "Off: the script can't reach the page's chat");
      chatSocketRow(ctx);
    }
  };

  // src/features/chats/hide-typing.js
  var PRESENCE = "3";
  var hide_typing_default = {
    id: "hideTyping",
    section: "chats",
    android: "Hide typing indicator",
    title: "Hide typing indicator",
    description: "People you chat with don't see the dots while you type. End-to-end encrypted chats aren't covered.",
    default: false,
    needsPage: true,
    setup(ctx) {
      const { net, diagnostics, enabled } = ctx;
      let quieted = 0;
      const quiet = (task) => {
        if (String(task?.label) !== PRESENCE || typeof task.payload !== "string") return false;
        const presence = readJson(task.payload);
        if (!presence || presence.is_typing !== 1) return false;
        presence.is_typing = 0;
        task.payload = writeJson(presence);
        quieted++;
        return true;
      };
      if (net) {
        net.editChatRequests({
          id: "hideTyping",
          enabled,
          edit(request) {
            const tasks = request.type === 4 ? [request.payload] : request.type === 3 ? request.payload.tasks : null;
            if (!Array.isArray(tasks)) return false;
            const changed = tasks.map(quiet).some(Boolean);
            if (changed) diagnostics?.changed();
            return changed;
          }
        });
      }
      diagnostics?.add("Typing signals turned off", () => net ? String(quieted) : "Off: the script can't reach the page's chat");
      chatSocketRow(ctx);
    }
  };

  // src/features/notifications/hide-kinds.js
  var LINKS = 'a[href*="notif_t="]';
  var KIND_MARK = "data-hfw-notif-kind";
  var ROW = '[role="listitem"]';
  var POST = '[role="article"], [aria-posinset], [role="feed"]';
  var HEADING = 'h1, h2, h3, h4, h5, h6, [role="heading"]';
  var DELAY2 = 150;
  var MAX_SEEN = 40;
  var GROUPS = [
    { option: "birthdays", label: "Birthdays", test: /birthday/, default: true },
    { option: "memories", label: "Memories", test: /memor|onthisday|on_this_day|goodwill|throwback|friendversary/, default: true },
    { option: "suggestions", label: "People you may know", test: /pymk|people_you_may_know|friend_suggest/, default: true },
    { option: "follow", label: "Pages and creators to follow", test: /to_follow|follow_suggest|page_suggest|creator_suggest/, default: true },
    { option: "activity", label: "Friends' new posts and photos", test: /friend_activity|close_friend/, default: false },
    { option: "groups", label: "Group join approvals", test: /^group_r2j/, default: false },
    { option: "reactions", label: "Reactions to your posts and comments", test: /^feedback_reaction/, default: false }
  ];
  var CUSTOM = "custom";
  function notifType(href) {
    try {
      const type = new URL(href, "https://www.facebook.com").searchParams.get("notif_t");
      return type && /^[a-z0-9_]{1,80}$/.test(type) ? type : null;
    } catch {
      return null;
    }
  }
  function parseKinds(text) {
    return new Set(String(text ?? "").split(/[\s,]+/).map((line) => line.trim().toLowerCase()).filter((line) => /^[a-z0-9_]+$/.test(line)));
  }
  function groupOf(type, custom = /* @__PURE__ */ new Set()) {
    if (custom.has(type)) return CUSTOM;
    return GROUPS.find((group) => group.test.test(type))?.option ?? "other";
  }
  var notifKey = (link) => {
    try {
      const url2 = new URL(link.getAttribute("href"), "https://www.facebook.com");
      return url2.searchParams.get("notif_id") ?? url2.href;
    } catch {
      return link.getAttribute("href");
    }
  };
  var notifCount = (node) => new Set([...node.querySelectorAll(LINKS)].map(notifKey)).size;
  function rowOf(link) {
    const row = link.closest(ROW);
    if (!row || link.closest(POST) || row.querySelector(HEADING) || notifCount(row) > 1) return null;
    return row;
  }
  function hideKindsCss(get) {
    const groups = GROUPS.filter(({ option }) => get(`hideNotificationKinds.${option}`)).map(({ option }) => option);
    if (parseKinds(get("hideNotificationKinds.custom")).size) groups.push(CUSTOM);
    if (!groups.length) return "";
    return `${groups.map((group) => `[${KIND_MARK}="${group}"]`).join(",\n")} { display: none !important; }`;
  }
  function createKindMarker({ doc, enabled, custom, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    const done = /* @__PURE__ */ new WeakMap();
    const seen = /* @__PURE__ */ new Set();
    let timer = null;
    let version2 = 0;
    function sync() {
      timer = null;
      if (!enabled()) {
        for (const row of doc.querySelectorAll(`[${KIND_MARK}]`)) row.removeAttribute(KIND_MARK);
        return;
      }
      const list = custom();
      for (const link of doc.querySelectorAll(LINKS)) {
        const href = link.getAttribute("href");
        const stamp = `${version2}|${href}`;
        if (done.get(link) === stamp) continue;
        done.set(link, stamp);
        const type = notifType(href);
        if (!type) continue;
        const row = rowOf(link);
        if (!row) continue;
        if (seen.size < MAX_SEEN) seen.add(type);
        row.setAttribute(KIND_MARK, groupOf(type, list));
      }
    }
    const schedule = () => {
      timer ??= setTimer(sync, DELAY2);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["href"] });
        sync();
      },
      // Settings changed: every row is looked at again, since a hand-listed kind may have changed.
      refresh() {
        version2++;
        schedule();
      },
      sync,
      seen: () => [...seen]
    };
  }
  var hide_kinds_default = {
    id: "hideNotificationKinds",
    section: "notifications",
    android: "Block promotional notifications",
    title: "Hide kinds of notifications",
    description: "Takes the kinds of notification you pick out of the Notifications list and page, like birthdays, memories and suggestions. The red count on the bell still counts them.",
    default: false,
    options: [
      ...GROUPS.map(({ option, label, default: on }) => ({ key: option, type: "toggle", label: `Hide ${label.charAt(0).toLowerCase()}${label.slice(1)}`, default: on })),
      { key: "custom", type: "text", lines: 1, label: "Other kinds to hide, by the names Diagnostics shows", default: "", maxLength: 2e3 }
    ],
    css: hideKindsCss,
    setup({ doc, enabled, option, settings, diagnostics }) {
      const marker = createKindMarker({ doc, enabled, custom: () => parseKinds(option("custom")) });
      const begin = () => marker.start();
      if (doc.body) begin();
      else doc.addEventListener("DOMContentLoaded", begin, { once: true });
      settings?.subscribe(() => marker.refresh());
      diagnostics?.add("Notification kinds seen", () => marker.seen().join(", ") || "None yet");
    }
  };

  // src/features/comments/orders.js
  var ORDERS = [
    { value: "relevant", token: "RANKED_FILTERED_INTENT_V1", english: "Most relevant" },
    { value: "newest", token: "REVERSE_CHRONOLOGICAL_UNFILTERED_INTENT_V1", english: "Newest" },
    { value: "all", token: "RANKED_UNFILTERED_CHRONOLOGICAL_REPLIES_INTENT_V1", english: "All comments" }
  ];
  var DEFAULT_ORDER = ORDERS[0];
  var ORDER_MARKERS = ['"selectable_intents"'];
  function createOrderTitles() {
    const learned = /* @__PURE__ */ new Map();
    return {
      learn(doc) {
        walk(doc, (value) => {
          if (Array.isArray(value) || !Array.isArray(value.selectable_intents)) return;
          for (const intent of value.selectable_intents) {
            const title = normalizeText(intent?.title);
            if (title && typeof intent.intent_token === "string") learned.set(intent.intent_token, title);
          }
        });
      },
      title: (order) => learned.get(order.token) ?? order.english,
      size: () => learned.size
    };
  }

  // src/features/comments/post-dialog.js
  function dialogOpen(doc) {
    return Boolean(doc.querySelector('[role="dialog"] [role="button"], [role="dialog"] [role="article"]'));
  }

  // src/features/comments/comment-order.js
  var MENU_WAIT = 2e3;
  var STEP = 100;
  var SCAN_DELAY = 300;
  function createOrderDriver({ doc, win = globalThis, titles, wanted, pageKey, log, onDone, menuWait = MENU_WAIT }) {
    const doneDialogs = /* @__PURE__ */ new WeakMap();
    const donePages = /* @__PURE__ */ new Set();
    let busy = false;
    const sleep = (ms) => new Promise((resolve) => win.setTimeout(resolve, ms));
    const here = () => doc.location?.href ?? "";
    function sectionOf(button) {
      const dialog = button.closest('[role="dialog"]');
      if (dialog) return doneDialogs.get(dialog) === here() ? null : { dialog };
      const page = pageKey();
      return page && !dialogOpen(doc) && !donePages.has(page) ? { page } : null;
    }
    async function menuAfter(before) {
      for (let waited = 0; waited <= menuWait; waited += STEP) {
        const menu = [...doc.querySelectorAll('[role="menu"]')].find((m) => !before.has(m) && m.querySelector('[role="menuitem"]'));
        if (menu) return menu;
        await sleep(STEP);
      }
      return null;
    }
    async function drive(button, section2, order) {
      busy = true;
      if (section2.dialog) doneDialogs.set(section2.dialog, here());
      else donePages.add(section2.page);
      try {
        const before = new Set(doc.querySelectorAll('[role="menu"]'));
        button.click();
        const menu = await menuAfter(before);
        const items = menu ? [...menu.querySelectorAll('[role="menuitem"]')] : [];
        const title = titles.title(order);
        const item = items.find((entry) => normalizeText(entry.textContent).startsWith(title)) ?? (items.length === ORDERS.length ? items[ORDERS.indexOf(order)] : null);
        if (!item) {
          if (menu) button.click();
          log?.warn(`Couldn't find "${title}" in Facebook's comment order menu`);
          return false;
        }
        item.click();
        onDone?.();
        return true;
      } finally {
        busy = false;
      }
    }
    function scan() {
      if (busy) return null;
      const order = wanted();
      if (!order || order === DEFAULT_ORDER) return null;
      const current = titles.title(DEFAULT_ORDER);
      for (const button of doc.querySelectorAll('[role="button"]')) {
        if (normalizeText(button.textContent) !== current) continue;
        const section2 = sectionOf(button);
        if (section2) return drive(button, section2, order);
      }
      return null;
    }
    return { scan };
  }
  var comment_order_default = {
    id: "commentOrder",
    section: "comments",
    android: "Default comment order",
    title: "Default comment order",
    description: "Opens comments in the order you pick instead of Most relevant, on a post's own page and when you open a post's comments from the feed. You can still change the order on any post.",
    default: false,
    options: [
      {
        key: "order",
        type: "select",
        label: "Order",
        default: "newest",
        choices: [{ value: "newest", label: "Newest first" }, { value: "all", label: "All comments, including ones Facebook filters" }]
      }
    ],
    setup({ doc, win, net, router, diagnostics, enabled, option, log }) {
      const titles = createOrderTitles();
      let changed = 0;
      net?.transformResponses({
        id: "commentOrderTitles",
        enabled,
        markers: ORDER_MARKERS,
        match: (ctx) => ctx.transport === "json-parse",
        transform(data) {
          titles.learn(data);
          return false;
        }
      });
      const driver = createOrderDriver({
        doc,
        win,
        titles,
        log,
        wanted: () => enabled() ? ORDERS.find((order) => order.value === option("order")) ?? null : null,
        pageKey: () => {
          const route = router?.current();
          return route && (route.permalink || route.type === "photo") ? route.href : null;
        },
        onDone: () => {
          changed++;
          diagnostics?.changed();
        }
      });
      diagnostics?.add("Comment sections put in your order", () => String(changed));
      let queued = false;
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      const observer = new Observer(() => {
        if (queued || !enabled()) return;
        queued = true;
        (win ?? globalThis).setTimeout(() => {
          queued = false;
          driver.scan();
        }, SCAN_DELAY);
      });
      const begin = () => observer.observe(doc.body, { childList: true, subtree: true });
      if (doc.body) begin();
      else doc.addEventListener("DOMContentLoaded", begin, { once: true });
    }
  };

  // src/features/comments/show-all-replies.js
  var REPLY_BUTTON = /^(?:view (?:all )?[\d.,]+k? (?:more )?repl(?:y|ies)|view more repl(?:y|ies)|[\d.,]+k? repl(?:y|ies))$/i;
  var REPLY_ICON = "M6.94 10.354";
  var PER_ROUND = 3;
  var PER_BUTTON = 5;
  var RETRY_ROUNDS = 3;
  var morePages = (text) => !new RegExp("\\p{Nd}", "u").test(text);
  function isReplyButton(button, text) {
    if (REPLY_BUTTON.test(text)) return true;
    if (!text || button.closest('[role="article"]')) return false;
    return Boolean(button.querySelector("svg path")?.getAttribute("d")?.startsWith(REPLY_ICON));
  }
  function createReplyExpander({ doc, win = globalThis, inPage, enabled, onClick, idleLimit = 5, delay = 800, maxClicks = 300 }) {
    const clicked = /* @__PURE__ */ new WeakMap();
    const spentInDialog = /* @__PURE__ */ new WeakMap();
    const spentOnPage = /* @__PURE__ */ new Map();
    let idle = 0;
    let timer = null;
    let rounds = 0;
    let total = 0;
    const address = () => doc.location?.href ?? "";
    const spent = (scope) => (scope === doc.body ? spentOnPage.get(address()) : spentInDialog.get(scope)) ?? 0;
    function spend(scope) {
      if (scope === doc.body) spentOnPage.set(address(), spent(scope) + 1);
      else spentInDialog.set(scope, spent(scope) + 1);
    }
    function ready(button, text) {
      const before = clicked.get(button);
      if (!before) return true;
      if (before.times >= PER_BUTTON) return false;
      return before.text !== text || morePages(text) && rounds - before.round >= RETRY_ROUNDS;
    }
    function candidates() {
      const scopes = [...doc.querySelectorAll('[role="dialog"]')];
      if (inPage() && doc.body && !dialogOpen(doc)) scopes.push(doc.body);
      const found = /* @__PURE__ */ new Map();
      for (const scope of scopes) {
        if (spent(scope) >= maxClicks) continue;
        for (const button of scope.querySelectorAll('[role="button"]')) {
          if (found.has(button)) continue;
          const text = normalizeText(button.textContent);
          if (isReplyButton(button, text) && ready(button, text)) found.set(button, scope);
        }
      }
      return [...found];
    }
    function schedule() {
      if (!timer) timer = win.setTimeout(round, delay);
    }
    function round() {
      timer = null;
      if (!enabled()) return;
      rounds++;
      const buttons = candidates();
      if (!buttons.length) {
        idle++;
        if (idle < idleLimit) schedule();
        return;
      }
      idle = 0;
      let now = 0;
      for (const [button, scope] of buttons) {
        if (now >= PER_ROUND) break;
        if (spent(scope) >= maxClicks) continue;
        clicked.set(button, { text: normalizeText(button.textContent), times: (clicked.get(button)?.times ?? 0) + 1, round: rounds });
        spend(scope);
        button.click();
        now++;
        total++;
        onClick?.();
      }
      schedule();
    }
    return {
      // The page changed: start the rounds again if they were resting.
      wake() {
        if (timer || !enabled()) return;
        idle = 0;
        schedule();
      },
      state: () => ({ idle, total, rounds, running: Boolean(timer) }),
      stop() {
        win.clearTimeout(timer);
        timer = null;
      }
    };
  }
  var show_all_replies_default = {
    id: "showAllReplies",
    section: "comments",
    android: "Comment sheet options",
    title: "Show every reply",
    description: "Opens every folded reply under comments on a post's own page and when you open a post's comments from the feed, so you don't have to click View replies.",
    default: false,
    setup({ doc, win, router, diagnostics, enabled }) {
      let opened = 0;
      const expander = createReplyExpander({
        doc,
        win: win ?? globalThis,
        enabled,
        inPage: () => {
          const route = router?.current();
          return Boolean(route && (route.permalink || route.type === "photo"));
        },
        onClick: () => {
          opened++;
          diagnostics?.changed();
        }
      });
      diagnostics?.add("Reply threads opened", () => String(opened));
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      const observer = new Observer(() => expander.wake());
      const begin = () => observer.observe(doc.body, { childList: true, subtree: true });
      if (doc.body) begin();
      else doc.addEventListener("DOMContentLoaded", begin, { once: true });
    }
  };

  // src/features/comments/hide-comment-stickers.js
  var MARK3 = "data-hfw-comment-sticker";
  var FORMS = 'form[role="presentation"]';
  var BUTTONS2 = '[role="button"][aria-haspopup]';
  var DELAY3 = 200;
  var HIDE_STICKERS_CSS = `[${MARK3}] { display: none !important; }`;
  function isCommentForm(form) {
    if (!form.querySelector('[role="textbox"][contenteditable="true"]')) return false;
    if (form.closest('[role="main"], [aria-posinset], [role="article"]')) return true;
    return Boolean(form.closest('[role="dialog"]')?.querySelector('[role="article"]'));
  }
  var isStickerButton = (button) => Boolean(button.querySelector("i")) && !button.querySelector("svg");
  function markStickerButtons(doc) {
    let marked = 0;
    for (const form of doc.querySelectorAll(FORMS)) {
      if (!isCommentForm(form)) continue;
      for (const button of form.querySelectorAll(BUTTONS2)) {
        if (button.hasAttribute(MARK3) || !isStickerButton(button)) continue;
        button.setAttribute(MARK3, "");
        marked++;
      }
    }
    return marked;
  }
  function createStickerHider({ doc, enabled, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    let timer = null;
    let hidden = 0;
    function sync() {
      timer = null;
      if (!enabled()) {
        for (const button of doc.querySelectorAll(`[${MARK3}]`)) button.removeAttribute(MARK3);
        return;
      }
      hidden += markStickerButtons(doc);
    }
    const schedule = () => {
      timer ??= setTimer(sync, DELAY3);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      hidden: () => hidden
    };
  }
  var hide_comment_stickers_default = {
    id: "hideCommentStickers",
    section: "comments",
    android: "Comment sheet options",
    title: "Hide GIF and sticker buttons",
    description: "Takes the GIF, sticker and avatar sticker buttons out of the comment box under posts. The emoji button stays, and only comment boxes on posts are touched.",
    default: false,
    css: HIDE_STICKERS_CSS,
    setup({ doc, settings, diagnostics, enabled }) {
      const hider = createStickerHider({ doc, enabled });
      const begin = () => hider.start();
      if (doc.body) begin();
      else doc.addEventListener("DOMContentLoaded", begin, { once: true });
      settings?.subscribe(() => hider.schedule());
      diagnostics?.add("Comment box buttons hidden", () => String(hider.hidden()));
    }
  };

  // src/features/comments/hide-comment-typing.js
  var COMMENT_TYPING = /^CometUFILiveTypingBroadcastMutation_(?:Start|Stop)Mutation$/;
  var hide_comment_typing_default = {
    id: "hideCommentTyping",
    section: "comments",
    android: "Hide typing indicator",
    title: "Hide that you're writing a comment",
    description: "Others looking at the same post don't see that you're writing a comment while you type one.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let held = 0;
      net.blockRequests({
        id: "hideCommentTyping",
        enabled,
        match: (ctx) => COMMENT_TYPING.test(ctx.friendlyName),
        fakeResponse: () => {
          held++;
          diagnostics?.changed();
          return EMPTY_SUCCESS;
        }
      });
      diagnostics?.add("Comment typing signals held back", () => String(held));
    }
  };

  // src/features/comments/tags-after-at.js
  var BOOTLOAD = /^useFeedComposerCometMentionsBootloadDataSource(?:WithTaggingTransparency)?Query$/;
  var MARKERS2 = ['"comet_composer_typeahead_bootload"', '"xfb_tag_suggestion_search"'];
  function emptyTagLists(doc) {
    const data = doc?.data;
    if (!data || typeof data !== "object") return 0;
    let removed = 0;
    if (Array.isArray(data.comet_composer_typeahead_bootload)) {
      removed += data.comet_composer_typeahead_bootload.length;
      data.comet_composer_typeahead_bootload = [];
    }
    const search = data.xfb_tag_suggestion_search;
    if (search && typeof search === "object" && Array.isArray(search.suggestions)) {
      removed += search.suggestions.length;
      search.suggestions = [];
    }
    return removed;
  }
  var tags_after_at_default = {
    id: "tagsAfterAt",
    section: "comments",
    android: "Tag suggestions only after @",
    title: "Tag suggestions only after @",
    description: "Typing a friend's name in a comment no longer offers to tag them. Type @ first when you do want to tag someone.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let held = 0;
      net.transformResponses({
        id: "tagsAfterAt",
        enabled,
        markers: MARKERS2,
        // By name, so the Nullstate and search answers an @ asks for are never touched.
        match: (ctx) => ctx.transport !== "json-parse" && BOOTLOAD.test(ctx.friendlyName),
        transform(doc) {
          const removed = emptyTagLists(doc);
          if (removed) {
            held += 1;
            diagnostics?.changed();
          }
          return removed > 0;
        }
      });
      diagnostics?.add("Tag lists held back", () => String(held));
    }
  };

  // src/features/comments/comments-as-written.js
  var MARKERS3 = ['"MACHINE_TRANSLATION"'];
  var OTHER_RANGES = ["delight_ranges", "image_ranges", "inline_style_ranges", "aggregated_ranges", "color_ranges"];
  var entityId = (range) => range?.entity?.id ?? null;
  function originalRanges(shown2, own) {
    if (!Array.isArray(own) || !own.length) return [];
    const rich = /* @__PURE__ */ new Map();
    for (const range of Array.isArray(shown2) ? shown2 : []) {
      const id = entityId(range);
      if (id === null) continue;
      if (!rich.has(id)) rich.set(id, []);
      rich.get(id).push(range);
    }
    const out = [];
    for (const range of own) {
      const match = rich.get(entityId(range))?.shift();
      if (match && Number.isFinite(range?.offset) && Number.isFinite(range?.length)) out.push({ ...match, offset: range.offset, length: range.length });
    }
    return out;
  }
  function putBack(block2, own) {
    block2.text = own.text;
    block2.ranges = originalRanges(block2.ranges, own.ranges);
    for (const key of OTHER_RANGES) {
      if (Array.isArray(block2[key]) && block2[key].length) block2[key] = [];
    }
  }
  function restoreComment(comment) {
    const shown2 = comment?.preferred_body;
    const own = comment?.body;
    if (!shown2 || typeof shown2 !== "object" || shown2.translation_type !== "MACHINE_TRANSLATION") return false;
    if (!own || typeof own.text !== "string" || typeof shown2.text !== "string") return false;
    putBack(shown2, own);
    shown2.translation_type = "ORIGINAL";
    const drawn = comment.body_renderer;
    if (drawn && typeof drawn === "object" && typeof drawn.text === "string" && drawn.text !== own.text) putBack(drawn, own);
    return true;
  }
  var MAX_REMEMBERED2 = 5e3;
  var RESTORED = "restored";
  var ASKED = "asked";
  function remember(seen, id, kind) {
    seen.delete(id);
    if (seen.size >= MAX_REMEMBERED2) seen.delete(seen.keys().next().value);
    seen.set(id, kind);
  }
  var CommentBook = class extends Map {
    asked = 0;
    set(id, kind) {
      if (super.get(id) === ASKED) this.asked--;
      if (kind === ASKED) this.asked++;
      return super.set(id, kind);
    }
    delete(id) {
      if (super.get(id) === ASKED) this.asked--;
      return super.delete(id);
    }
  };
  var ORIGINAL_MARKERS = ['"ORIGINAL"'];
  function forgetAsked(data, seen) {
    let forgotten = 0;
    walk(data, (value) => {
      if (Array.isArray(value)) return;
      const shown2 = value.preferred_body;
      if (!shown2 || typeof shown2 !== "object" || typeof shown2.text !== "string" || shown2.translation_type !== "ORIGINAL") return;
      if (typeof value.id === "string" && seen.get(value.id) === ASKED) {
        seen.delete(value.id);
        forgotten++;
      }
    });
    return forgotten;
  }
  function untranslate(data, seen = /* @__PURE__ */ new Map()) {
    const count = { comments: 0, copies: 0 };
    const partial = [];
    walk(data, (value) => {
      if (Array.isArray(value)) return;
      const shown2 = value.preferred_body;
      if (!shown2 || typeof shown2 !== "object") return;
      const id = typeof value.id === "string" ? value.id : null;
      if (typeof shown2.text === "string" && !("body" in value)) {
        if (id && shown2.translation_type === "MACHINE_TRANSLATION") remember(seen, id, ASKED);
        else if (id && seen.get(id) === ASKED) seen.delete(id);
        return;
      }
      if (id && seen.get(id) === ASKED) return;
      if (restoreComment(value)) {
        count.comments++;
        if (id) remember(seen, id, RESTORED);
      } else if (shown2.translation_type === "MACHINE_TRANSLATION" && typeof shown2.text !== "string") {
        partial.push(value);
      }
    });
    for (const copy of partial) {
      if (seen.get(copy.id) !== RESTORED) continue;
      copy.preferred_body.translation_type = "ORIGINAL";
      count.copies++;
    }
    return count;
  }
  var comments_as_written_default = {
    id: "noAutoTranslate",
    section: "comments",
    android: "Turn off auto-translation",
    title: "Show comments as written",
    description: "Comments in other languages show the words people wrote instead of Facebook's translation. See translation under a comment still works when you want it.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let shown2 = 0;
      const seen = new CommentBook();
      net.transformResponses({
        id: "noAutoTranslate",
        enabled,
        markers: MARKERS3,
        // Facebook parses every answer and the page's inline data with JSON.parse.
        match: (ctx) => ctx.transport === "json-parse",
        transform(data) {
          const { comments, copies } = untranslate(data, seen);
          if (comments) {
            shown2 += comments;
            diagnostics?.changed();
          }
          return comments + copies > 0;
        }
      });
      net.transformResponses({
        id: "noAutoTranslate-original",
        enabled: () => enabled() && seen.asked > 0,
        markers: ORIGINAL_MARKERS,
        match: (ctx) => ctx.transport === "json-parse",
        transform(data) {
          forgetAsked(data, seen);
          return false;
        }
      });
      diagnostics?.add("Comments shown as written", () => String(shown2));
    }
  };

  // src/features/links/link-events.js
  var EVENTS = ["pointerdown", "mousedown", "mouseup", "click", "auxclick", "contextmenu", "focusin", "dragstart"];
  var STOPPABLE = /* @__PURE__ */ new Set(["mousedown", "mouseup", "click", "auxclick"]);
  var registries = /* @__PURE__ */ new WeakMap();
  function onLinkActivation(win, handler) {
    let handlers = registries.get(win);
    if (!handlers) {
      handlers = [];
      registries.set(win, handlers);
      const listener = (event) => {
        const path = typeof event.composedPath === "function" ? event.composedPath() : [];
        const anchor = path.find((node) => node?.tagName === "A" && node.hasAttribute?.("href"));
        if (!anchor) return;
        let stop = false;
        for (const run of handlers) if (run(anchor, event) === "stop") stop = true;
        if (stop && STOPPABLE.has(event.type)) event.stopImmediatePropagation();
      };
      for (const type of EVENTS) win.addEventListener(type, listener, { capture: true, passive: true });
    }
    handlers.push(handler);
  }

  // src/features/links/sanitize-links.js
  var SHARE_LINK_MUTATIONS = /* @__PURE__ */ new Set(["useLinkSharingCreateWrappedUrlMutation"]);
  var sanitize_links_default = {
    id: "sanitizeLinks",
    section: "links",
    android: "Sanitize sharing links",
    title: "Sanitize sharing links",
    description: "Takes Facebook's tracking tags off links you open or copy. Copy link gives the post's own address instead of a share link that leads back to you.",
    default: true,
    setup({ win, net, enabled }) {
      net?.blockRequests({
        id: "sanitizeLinks",
        enabled,
        match: (ctx) => SHARE_LINK_MUTATIONS.has(ctx.friendlyName),
        fakeResponse: () => '{"data":{},"errors":[]}'
      });
      onLinkActivation(win, (anchor) => {
        if (!enabled()) return;
        const href = anchor.getAttribute("href");
        if (!href) return;
        const cleaned = cleanUrl(href, { unwrap: false, base: win.location.href });
        if (cleaned !== href && cleaned !== anchor.href) anchor.setAttribute("href", cleaned);
      });
      const clipboard = win.navigator.clipboard;
      const writeText = clipboard?.writeText;
      if (typeof writeText !== "function") return;
      clipboard.writeText = function(text) {
        return writeText.call(this, enabled() ? cleanCopiedText(text) : text);
      };
    }
  };

  // src/features/links/direct-links.js
  var direct_links_default = {
    id: "directLinks",
    section: "links",
    android: "Open links in external browser",
    title: "Skip Facebook's link redirect",
    description: "Opens outside links directly instead of through l.facebook.com, so Facebook doesn't record the click.",
    default: true,
    setup({ win, enabled }) {
      onLinkActivation(win, (anchor) => {
        if (!enabled()) return void 0;
        const href = anchor.getAttribute("href");
        const target = href && unshim(href, win.location.href);
        if (target) anchor.setAttribute("href", cleanUrl(target));
        return isOutbound(anchor.href) ? "stop" : void 0;
      });
    }
  };

  // src/features/playback/tap-to-play.js
  var NEARBY_LEVELS = 4;
  function shouldAllowPlay({ activationActive, aimedAtMedia, userStarted }) {
    return userStarted === true || activationActive === true && aimedAtMedia === true;
  }
  function pointInside(rect, point) {
    return point.x >= rect.left && point.x <= rect.right && point.y >= rect.top && point.y <= rect.bottom;
  }
  function isNear(media, target) {
    for (let node = media, level = 0; node && level < NEARBY_LEVELS; node = node.parentElement, level++) {
      if (node.contains(target)) return true;
    }
    return false;
  }
  var tap_to_play_default = {
    id: "tapToPlay",
    section: "playback",
    android: "Tap to play",
    title: "Tap to play",
    description: "Videos, reels, stories and music wait for your tap instead of starting by themselves.",
    default: false,
    setup({ win, enabled, log }) {
      const proto = win.HTMLMediaElement?.prototype;
      const play = proto?.play;
      if (typeof play !== "function") return;
      const started = /* @__PURE__ */ new WeakSet();
      let lastPress = null;
      const listen = { capture: true, passive: true };
      win.addEventListener("pointerdown", (event) => {
        if (event.isTrusted) lastPress = { point: { x: event.clientX, y: event.clientY } };
      }, listen);
      win.addEventListener("keydown", (event) => {
        if (event.isTrusted) lastPress = { target: event.target };
      }, listen);
      const aimedAt = (media) => {
        if (!lastPress) return false;
        if (lastPress.point) return pointInside(media.getBoundingClientRect(), lastPress.point);
        return isNear(media, lastPress.target);
      };
      proto.play = function() {
        if (!enabled()) return play.apply(this, arguments);
        const activationActive = win.navigator.userActivation?.isActive === true;
        if (!shouldAllowPlay({ activationActive, aimedAtMedia: aimedAt(this), userStarted: started.has(this) })) {
          log.debug("Held back autoplay");
          return win.Promise.reject(new win.DOMException("Waiting for a tap (HushFacebook Web)", "NotAllowedError"));
        }
        started.add(this);
        return play.apply(this, arguments);
      };
    }
  };

  // src/features/playback/hdr-brightness.js
  var hdr_brightness_default = {
    id: "limitHdr",
    section: "playback",
    android: "Turn off HDR brightness",
    title: "Turn off HDR brightness",
    description: "Stops HDR videos and photos from turning your screen up to full brightness. They keep their resolution.",
    default: false,
    css: "video, img, canvas { dynamic-range-limit: standard !important; }"
  };

  // src/core/download.js
  var TIMEOUT = 6e5;
  var RESERVED = /* @__PURE__ */ new Set(["<", ">", ":", '"', "/", "\\", "|", "?", "*"]);
  function invisible(code) {
    return code < 32 || code >= 127 && code <= 159 || code === 173 || code === 1564 || code === 6158 || code >= 8203 && code <= 8207 || code >= 8234 && code <= 8238 || code >= 8288 && code <= 8303 || code === 65279 || code >= 65529 && code <= 65531 || code >= 917504 && code <= 917631;
  }
  function fileName(parts, extension) {
    const joined = parts.filter(Boolean).join(" ").normalize("NFC");
    let clean = "";
    for (const char of joined) clean += RESERVED.has(char) || invisible(char.codePointAt(0)) ? " " : char;
    const base = clean.replace(/\s+/g, " ").trim().replace(/^[.~ ]+/, "");
    const cut = [...base].slice(0, 100).join("").trim().replace(/[. ]+$/, "");
    return `${cut || "Facebook"}.${extension}`;
  }
  function extensionOf(url2, fallback) {
    try {
      const parsed = new URL(url2);
      const found = parsed.searchParams.get("stp")?.match(/(?:^|_)dst-(jpe?g|png|webp|gif)/i) ?? parsed.pathname.match(/\.(mp4|m4v|webm|jpe?g|png|gif|webp|heic)$/i);
      return found ? found[1].toLowerCase().replace("jpeg", "jpg") : fallback;
    } catch {
      return fallback;
    }
  }
  var describe2 = (value) => value && typeof value === "object" ? JSON.stringify(value) : String(value ?? "");
  function viaManager(download, url2, name) {
    return new Promise((resolve, reject) => {
      download({
        url: url2,
        name,
        saveAs: false,
        timeout: TIMEOUT,
        onload: () => resolve(),
        onerror: (error) => reject(Object.assign(new Error(describe2(error?.error) || describe2(error?.details) || "the manager could not save it"), {
          cancelled: /cancel/i.test(`${describe2(error?.error)} ${describe2(error?.details)}`)
        })),
        ontimeout: () => reject(new Error("it took too long"))
      });
    });
  }
  function fetchBlob(url2, { request, win }) {
    if (request) {
      return new Promise((resolve, reject) => {
        request({
          method: "GET",
          url: url2,
          responseType: "blob",
          timeout: TIMEOUT,
          anonymous: true,
          onload: (response) => response.status >= 200 && response.status < 300 && response.response ? resolve(response.response) : reject(new Error(`the server answered ${response.status}`)),
          onerror: () => reject(new Error("the file couldn't be fetched")),
          ontimeout: () => reject(new Error("it took too long"))
        });
      });
    }
    return win.fetch(url2, { credentials: "omit" }).then((response) => {
      if (!response.ok) throw new Error(`the server answered ${response.status}`);
      return response.blob();
    });
  }
  async function saveFile({ url: url2, name, api = {}, doc = globalThis.document, win = globalThis, container = null }) {
    if (api.download) {
      try {
        await viaManager(api.download, url2, name);
        return "manager";
      } catch (error) {
        if (error.cancelled) throw Object.assign(new Error("you cancelled it", { cause: error }), { cancelled: true });
      }
    }
    const blob = await fetchBlob(url2, { request: api.request, win });
    const href = URL.createObjectURL(blob);
    const link = doc.createElement("a");
    link.href = href;
    link.download = name;
    link.rel = "noopener";
    link.style.display = "none";
    (container ?? doc.body ?? doc.documentElement).append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(href), 6e4).unref?.();
    return "link";
  }

  // src/features/downloads/find.js
  var POST2 = '[aria-posinset], [role="article"]';
  var MAX_LEVELS = 14;
  var LABELS = { downloadVideos: "video", downloadReels: "reel", downloadStories: "story", downloadPhotos: "photo" };
  function linkTarget(href) {
    const text = String(href ?? "");
    let found = text.match(/\/reels?\/(\d{6,})/);
    if (found) return { kind: "reel", id: found[1] };
    found = text.match(/\/videos\/(?:[^/?#]+\/)?(\d{6,})/) ?? text.match(/\/(?:watch(?:\/live)?|video\.php)\/?\?(?:[^#]*&)?v=(\d{6,})/);
    if (found) return { kind: "video", id: found[1] };
    found = text.match(/\/photo(?:\.php)?\/?\?(?:[^#]*&)?fbid=(\d{6,})/) ?? text.match(/\/photos\/[^/?#]+\/(\d{6,})/);
    if (found) return { kind: "photo", id: found[1] };
    return null;
  }
  function pageTarget(href) {
    let url2;
    try {
      url2 = new URL(href);
    } catch {
      return null;
    }
    const story = url2.pathname.match(/^\/stories\/[^/]+\/([^/?#]+)/);
    if (story) {
      try {
        return { kind: "story", card: decodeURIComponent(story[1]) };
      } catch {
        return { kind: "story", card: story[1] };
      }
    }
    return linkTarget(url2.pathname + url2.search);
  }
  function nearestVideoLink(element) {
    let node = element.parentElement;
    for (let level = 0; node && level < MAX_LEVELS; level++, node = node.parentElement) {
      const ids = /* @__PURE__ */ new Map();
      for (const link of node.querySelectorAll("a[href]")) {
        const target = linkTarget(link.getAttribute("href"));
        if (target && target.kind !== "photo" && !ids.has(target.id)) ids.set(target.id, target);
      }
      if (ids.size === 1) return [...ids.values()][0];
      if (ids.size > 1) return null;
      if (node.matches(POST2)) return null;
    }
    return null;
  }
  function authorOf(element) {
    const post = element.closest(POST2);
    if (!post) return null;
    const heading = [...post.querySelectorAll("h2, h3, h4")].find((h2) => h2.closest(POST2) === post);
    const name = heading?.querySelector("a, strong, span") ?? heading;
    const text = normalizeText(name?.textContent ?? "");
    return text && text.length <= 80 ? text : null;
  }
  function imageSource(img) {
    let best = null;
    for (const part of (img.getAttribute("srcset") ?? "").split(",")) {
      const [url2, size] = part.trim().split(/\s+/);
      const width = Number.parseFloat(size) || 0;
      if (url2 && (!best || width > best.width)) best = { url: url2, width };
    }
    return best?.url ?? img.currentSrc ?? img.getAttribute("src") ?? null;
  }
  var asKind = (item, kind) => item?.kind === kind ? item : null;
  function findMedia(element, { href, index }) {
    const tag = element?.tagName;
    if (tag !== "VIDEO" && tag !== "IMG") return null;
    const page = pageTarget(href);
    const fallback = tag === "IMG" ? imageSource(element) : null;
    if (page?.kind === "story") {
      const item = index?.card(page.card) ?? null;
      const kind = item?.kind ?? (tag === "VIDEO" ? "video" : "photo");
      return { feature: "downloadStories", kind, id: item?.id ?? null, item, author: item?.author ?? null, fallback };
    }
    if (tag === "VIDEO") {
      const near = nearestVideoLink(element);
      const target2 = near ?? (page && page.kind !== "photo" ? page : null);
      const feature = (target2?.kind ?? page?.kind) === "reel" ? "downloadReels" : "downloadVideos";
      const id = target2?.id ?? null;
      return { feature, kind: "video", id, item: asKind(index?.get(id), "video"), author: authorOf(element), fallback: null };
    }
    const link = element.closest("a[href]");
    const target = linkTarget(link?.getAttribute("href")) ?? (page?.kind === "photo" && !element.closest(POST2) ? page : null);
    if (target?.kind !== "photo") return null;
    return { feature: "downloadPhotos", kind: "photo", id: target.id, item: asKind(index?.get(target.id), "photo"), author: authorOf(element), fallback };
  }
  function planSave(found, { quality = "best" } = {}) {
    const label = LABELS[found.feature] ?? "media";
    if (found.kind === "video") {
      const { item } = found;
      if (!item && !found.id) return { error: "Couldn't tell which video this is. Open it from its post and try again." };
      if (!item) return { error: "Facebook hasn't sent this video's file yet. Let it play for a moment, or open it, and try again." };
      const file = (quality === "sd" ? item.files.find((f) => f.quality === "SD") : null) ?? item.files[0];
      if (!file) {
        return { error: item.dash ? "Facebook only streams this video in small pieces, so there is no single file to save." : "Facebook didn't send a file for this video." };
      }
      const name = fileName([found.author, label, item.id, file.quality === "HD" ? "HD" : null], extensionOf(file.url, "mp4"));
      return { url: file.url, name, quality: file.quality };
    }
    const url2 = found.item?.url ?? found.fallback;
    if (!url2) return { error: "Couldn't find this photo's file." };
    return { url: url2, name: fileName([found.author, label, found.id ?? found.item?.id], extensionOf(url2, "jpg")) };
  }

  // src/features/playback/resume-videos.js
  var POSITIONS_KEY = "resumeVideos.positions";
  var LENGTHS = [2, 5, 10, 20];
  var MAX_KEPT = 200;
  var SAVE_EVERY = 5;
  var START_AFTER = 30;
  var DONE_WITHIN = 20;
  var STEP_BACK = 3;
  var SAME_LENGTH = 2;
  var isVideo2 = (node) => node?.tagName === "VIDEO";
  function videoId(video, href) {
    const page = pageTarget(href);
    if (page?.kind === "story" || page?.kind === "reel") return null;
    const target = nearestVideoLink(video) ?? (page?.kind === "video" ? page : null);
    return target?.kind === "video" ? target.id : null;
  }
  function clock(seconds) {
    const whole = Math.floor(seconds);
    const h2 = Math.floor(whole / 3600);
    const m = Math.floor(whole % 3600 / 60);
    const s = String(whole % 60).padStart(2, "0");
    return h2 ? `${h2}:${String(m).padStart(2, "0")}:${s}` : `${m}:${s}`;
  }
  function createResumer({ doc, storage, enabled, minSeconds, href = () => doc.location.href, now = () => Date.now(), onResume }) {
    const tracked = /* @__PURE__ */ new WeakMap();
    let resumes = 0;
    const kept = () => storage.get(POSITIONS_KEY, {}) ?? {};
    function write(id, seconds, duration) {
      const all = kept();
      if (seconds === null) {
        if (!(id in all)) return;
        delete all[id];
      } else {
        all[id] = { t: Math.floor(seconds), d: Math.round(duration), at: now() };
        const ids = Object.keys(all);
        if (ids.length > MAX_KEPT) {
          for (const old of ids.sort((a, b) => all[a].at - all[b].at).slice(0, ids.length - MAX_KEPT)) delete all[old];
        }
      }
      storage.set(POSITIONS_KEY, all);
    }
    function entry(video) {
      const id = videoId(video, href());
      let found = tracked.get(video);
      if (!found || found.id !== id) {
        found = { id, resumed: false, heard: false, saved: Number.NEGATIVE_INFINITY, done: false, cleared: false };
        tracked.set(video, found);
      }
      return found;
    }
    const long = (video) => Number.isFinite(video.duration) && video.duration >= minSeconds();
    const watching = (event) => isVideo2(event.target) && enabled() && long(event.target);
    const audible = (video) => !video.muted && video.volume > 0;
    function onPlaying(event) {
      if (!watching(event)) return;
      const video = event.target;
      const found = entry(video);
      if (!found.id || found.resumed) return;
      found.resumed = true;
      const spot = kept()[found.id];
      if (!spot || Math.abs(spot.d - video.duration) > SAME_LENGTH) return;
      if (spot.t < START_AFTER || spot.t > video.duration - DONE_WITHIN || video.currentTime >= spot.t) return;
      video.currentTime = Math.max(START_AFTER, spot.t - STEP_BACK);
      resumes++;
      onResume?.(spot.t);
    }
    function remember2(video, force) {
      const found = entry(video);
      if (!found.id || !found.resumed) return;
      if (!found.heard) {
        if (!audible(video)) return;
        found.heard = true;
      }
      const at = video.currentTime;
      if (at > video.duration - DONE_WITHIN) {
        if (!found.done) write(found.id, null);
        found.done = true;
        return;
      }
      found.done = false;
      if (at < START_AFTER) {
        if (!found.cleared) write(found.id, null);
        found.cleared = true;
        found.saved = Number.NEGATIVE_INFINITY;
        return;
      }
      found.cleared = false;
      if (!force && Math.abs(at - found.saved) < SAVE_EVERY) return;
      found.saved = at;
      write(found.id, at, video.duration);
    }
    const onTime = (event) => watching(event) && remember2(event.target, false);
    const onPause = (event) => watching(event) && remember2(event.target, true);
    return {
      start() {
        doc.addEventListener("playing", onPlaying, true);
        doc.addEventListener("timeupdate", onTime, true);
        doc.addEventListener("pause", onPause, true);
      },
      forget: () => storage.remove(POSITIONS_KEY),
      count: () => Object.keys(kept()).length,
      resumes: () => resumes
    };
  }
  var resume_videos_default = {
    id: "resumeVideos",
    section: "playback",
    android: "Resume long videos",
    title: "Resume long videos",
    description: "A long video you stopped partway through starts where you left it the next time you play it, a few seconds early so you can find your place. Reels and stories aren't kept.",
    default: false,
    options: [
      {
        key: "minutes",
        type: "select",
        label: "Count videos longer than",
        default: 5,
        choices: LENGTHS.map((n) => ({ value: n, label: `${n} minutes` }))
      }
    ],
    setup({ doc, storage, enabled, option, toast, diagnostics, actions }) {
      const resumer = createResumer({
        doc,
        storage,
        enabled,
        minSeconds: () => Number(option("minutes") ?? 5) * 60,
        onResume: (seconds) => toast?.(`Picked up where you left off, at ${clock(seconds)}`)
      });
      resumer.start();
      diagnostics?.add("Video spots kept", () => String(resumer.count()));
      diagnostics?.add("Videos picked up", () => String(resumer.resumes()));
      actions?.add("Forget every spot", () => {
        resumer.forget();
        toast?.("Forgot every video spot");
      });
    }
  };

  // src/features/playback/keep-speed.js
  var SPEED_KEY = "keepSpeed.rate";
  var HOLDING = /* @__PURE__ */ Symbol.for("hushfacebook-web.holding-speed");
  var INPUT_WINDOW2 = 2e3;
  var SETTLED = 1;
  var MAX_REAPPLY = 3;
  var MIN_RATE = 0.25;
  var MAX_RATE = 4;
  var isVideo3 = (node) => node?.tagName === "VIDEO";
  function createSpeedKeeper({ doc, win, storage, enabled, now = () => Date.now(), trusted = (event) => event.isTrusted, inStories = () => /^\/stories\//.test(doc.location?.pathname ?? "") }) {
    const ours = /* @__PURE__ */ new WeakMap();
    const reapplied = /* @__PURE__ */ new WeakMap();
    let lastInput = Number.NEGATIVE_INFINITY;
    const kept = () => {
      const rate = Number(storage.get(SPEED_KEY, 1));
      return rate >= MIN_RATE && rate <= MAX_RATE ? rate : 1;
    };
    function give(video) {
      const rate = kept();
      if (video.playbackRate === rate) return;
      ours.set(video, rate);
      video.playbackRate = rate;
    }
    const wasLive = /* @__PURE__ */ new WeakMap();
    const isLive = (video) => video.duration === Number.POSITIVE_INFINITY || wasLive.has(video) && wasLive.get(video) === video.currentSrc;
    const skip = (video) => !isVideo3(video) || !enabled() || inStories() || video[HOLDING] || isLive(video);
    function onStart(event) {
      if (skip(event.target)) return;
      give(event.target);
    }
    function onLength(event) {
      const video = event.target;
      if (!isVideo3(video) || video.duration !== Number.POSITIVE_INFINITY) return;
      wasLive.set(video, video.currentSrc);
      if (!ours.has(video)) return;
      if (video.playbackRate === ours.get(video)) video.playbackRate = 1;
      ours.delete(video);
    }
    function onRate(event) {
      const video = event.target;
      if (skip(video)) return;
      const rate = video.playbackRate;
      if (ours.get(video) === rate) return;
      ours.delete(video);
      const picked = now() - lastInput < INPUT_WINDOW2 && video.currentTime >= SETTLED;
      if (picked) {
        if (rate >= MIN_RATE && rate <= MAX_RATE && rate !== kept()) storage.set(SPEED_KEY, rate);
        return;
      }
      const times = reapplied.get(video) ?? 0;
      if (times >= MAX_REAPPLY) return;
      reapplied.set(video, times + 1);
      give(video);
    }
    const onInput = (event) => {
      if (trusted(event)) lastInput = now();
    };
    return {
      start() {
        const listen = { capture: true, passive: true };
        win.addEventListener("pointerdown", onInput, listen);
        win.addEventListener("keydown", onInput, listen);
        doc.addEventListener("play", onStart, true);
        doc.addEventListener("loadedmetadata", onLength, true);
        doc.addEventListener("loadedmetadata", onStart, true);
        doc.addEventListener("durationchange", onLength, true);
        doc.addEventListener("ratechange", onRate, true);
      },
      kept,
      reset: () => storage.remove(SPEED_KEY)
    };
  }
  var speedLabel = (rate) => rate === 1 ? "Normal" : `${rate}x`;
  var keep_speed_default = {
    id: "keepSpeed",
    section: "playback",
    android: "Keep the reel speed",
    title: "Keep your video speed",
    description: "The speed you pick in a video's Settings menu stays for every video and reel after it, even after a reload, instead of going back to normal each time. Stories keep their own pace.",
    default: false,
    setup({ doc, win, storage, enabled, diagnostics, actions, toast }) {
      const keeper = createSpeedKeeper({ doc, win: win ?? doc.defaultView, storage, enabled });
      keeper.start();
      diagnostics?.add("Video speed kept", () => speedLabel(keeper.kept()));
      actions?.add("Back to normal speed", () => {
        keeper.reset();
        toast?.("New videos play at normal speed again");
      });
    }
  };

  // src/features/playback/hold-for-speed.js
  var HOLD_MS = 350;
  var FAST = 2;
  var CONTROLS = 'a, button, input, [role="button"], [role="slider"], [role="link"], [role="menu"], [role="dialog"], [data-hushfacebook-web]:not(html)';
  var CLICK_GRACE = 600;
  var inReels = (doc) => /^\/reels?\//.test(doc.location?.pathname ?? "");
  function reelAt(doc, target, x, y) {
    if (!target || target.closest?.(CONTROLS)) return null;
    for (const video of doc.querySelectorAll("video")) {
      const rect = video.getBoundingClientRect();
      if (rect.width > 0 && x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) return video;
    }
    return null;
  }
  function createHold({ doc, win, enabled, trusted = (event) => event.isTrusted, setTimer = (fn, ms) => win.setTimeout(fn, ms), clearTimer = (id) => win.clearTimeout(id), now = () => Date.now() }) {
    let pending = null;
    let held = null;
    let swallowUntil = null;
    let holds = 0;
    function begin() {
      const { video } = pending;
      pending = null;
      if (!video.isConnected || video.paused) return;
      held = { video, rate: video.playbackRate };
      video[HOLDING] = true;
      video.playbackRate = FAST;
      holds++;
    }
    function release(letGo) {
      if (pending) {
        clearTimer(pending.timer);
        pending = null;
      }
      if (!held) return;
      const { video, rate } = held;
      held = null;
      video.playbackRate = rate;
      delete video[HOLDING];
      swallowUntil = letGo ? now() + CLICK_GRACE : null;
    }
    function onDown(event) {
      if (!trusted(event) || event.button !== 0 || !enabled() || !inReels(doc)) return;
      const video = reelAt(doc, event.target, event.clientX, event.clientY);
      if (!video) return;
      release(false);
      pending = { video, timer: setTimer(begin, HOLD_MS) };
    }
    function onClick(event) {
      if (swallowUntil === null || now() > swallowUntil) return;
      swallowUntil = null;
      event.preventDefault();
      event.stopImmediatePropagation();
    }
    return {
      start() {
        win.addEventListener("pointerdown", onDown, { capture: true, passive: true });
        win.addEventListener("pointerup", () => release(true), { capture: true, passive: true });
        win.addEventListener("pointercancel", () => release(false), { capture: true, passive: true });
        win.addEventListener("blur", () => release(false));
        win.addEventListener("click", onClick, { capture: true });
      },
      state: () => ({ holding: Boolean(held), holds })
    };
  }
  var hold_for_speed_default = {
    id: "holdForSpeed",
    section: "reels",
    android: "Hold a reel for 2x",
    title: "Hold a reel for 2x",
    description: "Press and hold the mouse on a reel and it plays at double speed until you let go. A quick click still works as before.",
    default: false,
    setup({ doc, win, enabled, diagnostics }) {
      const hold = createHold({ doc, win: win ?? doc.defaultView, enabled });
      hold.start();
      diagnostics?.add("Reels held for 2x", () => String(hold.state().holds));
    }
  };

  // src/features/downloads/button.js
  var MIN_SIZE = 160;
  var HIDE_AFTER = 450;
  var LOOK_UP = 6;
  var OWN_LAYER = 12;
  var ROW_HEIGHT = 40;
  var DOWNLOAD_ICON = "M12 4v11m0 0l-4.5-4.5M12 15l4.5-4.5M5 19h14";
  var CSS2 = `
:host { all: initial; }
button {
  position: fixed; z-index: 2147483000; display: inline-flex; align-items: center; gap: 6px;
  padding: 7px 12px; border: 1px solid rgba(255, 255, 255, 0.18); border-radius: 999px;
  background: rgba(17, 17, 27, 0.82); color: #cdd6f4; font: 600 13px/1 system-ui, sans-serif;
  cursor: pointer; backdrop-filter: blur(8px); box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
  transition: transform 0.12s ease, background 0.12s ease;
}
button:hover { background: rgba(30, 30, 46, 0.95); transform: translateY(-1px); }
button:focus-visible { outline: 2px solid #89b4fa; outline-offset: 2px; }
button[hidden] { display: none; }
button[aria-busy="true"] { cursor: progress; opacity: 0.8; }
svg { width: 14px; height: 14px; fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
`;
  var FLOATING = "data-hfw-floating";
  var big = (rect) => rect.width >= MIN_SIZE && rect.height >= MIN_SIZE;
  var inside = (rect, x, y) => x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
  function ownLayer(media, element) {
    let node = media.parentElement;
    for (let level = 0; node && level < OWN_LAYER; level++, node = node.parentElement) {
      if (node.contains(element)) return true;
    }
    return false;
  }
  function mediaAt(doc, host, x, y, { through = false } = {}) {
    const stack = typeof doc.elementsFromPoint === "function" ? doc.elementsFromPoint(x, y) : [];
    const above = [];
    for (const element of stack) {
      if (host && element === host) {
        if (through) continue;
        return "button";
      }
      if (element.hasAttribute?.(FLOATING)) continue;
      if ((element.tagName === "VIDEO" || element.tagName === "IMG") && big(element.getBoundingClientRect())) {
        return above.every((layer) => ownLayer(element, layer)) ? element : null;
      }
      above.push(element);
    }
    let node = stack[0] ?? null;
    for (let level = 0; node && level < LOOK_UP; level++, node = node.parentElement) {
      for (const video of node.querySelectorAll("video")) {
        const rect = video.getBoundingClientRect();
        if (big(rect) && inside(rect, x, y)) return video;
      }
    }
    return null;
  }
  function createDownloadButton({ doc, win, find, run, active, log, onMissing, name = "download", text = "Download", busyText = "Saving", icon: icon2 = DOWNLOAD_ICON, row = 0, failText = "The download failed" }) {
    let host = null;
    let shadow = null;
    let button = null;
    let current = null;
    let found = null;
    const saving = /* @__PURE__ */ new Set();
    const busy = () => Boolean(current && saving.has(current));
    let hideTimer = null;
    let frame = 0;
    let point = null;
    function mount() {
      if (host?.isConnected) return;
      host = doc.createElement("div");
      host.setAttribute("data-hushfacebook-web", name);
      host.setAttribute(FLOATING, "");
      shadow = host.attachShadow({ mode: "closed" });
      const style = doc.createElement("style");
      style.textContent = CSS2;
      button = doc.createElement("button");
      button.type = "button";
      button.hidden = true;
      button.addEventListener("click", onClick);
      button.addEventListener("pointerenter", () => clearTimeout(hideTimer));
      button.addEventListener("pointerleave", hideSoon);
      shadow.append(style, button);
      (doc.body ?? doc.documentElement).append(host);
    }
    function label(words) {
      button.replaceChildren();
      const svg = doc.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("viewBox", "0 0 24 24");
      svg.setAttribute("aria-hidden", "true");
      const path = doc.createElementNS("http://www.w3.org/2000/svg", "path");
      path.setAttribute("d", icon2);
      svg.append(path);
      button.append(svg, doc.createTextNode(words));
    }
    function hide2() {
      clearTimeout(hideTimer);
      current = null;
      found = null;
      if (button) button.hidden = true;
    }
    function showState() {
      if (busy()) {
        button.setAttribute("aria-busy", "true");
        label(busyText);
      } else {
        button.removeAttribute("aria-busy");
        label(typeof text === "function" ? text(current) : text);
      }
    }
    function hideSoon() {
      clearTimeout(hideTimer);
      hideTimer = setTimeout(hide2, HIDE_AFTER);
    }
    function place2() {
      if (!current || !button) return;
      const rect = current.getBoundingClientRect();
      if (!current.isConnected || rect.bottom <= 0 || rect.top >= win.innerHeight || !big(rect)) {
        hide2();
        return;
      }
      button.style.top = `${Math.max(rect.top, 0) + 10 + row * ROW_HEIGHT}px`;
      button.style.right = `${Math.max(win.innerWidth - rect.right, 0) + 10}px`;
    }
    function check() {
      frame = 0;
      if (!point) return;
      if (!active()) {
        hide2();
        return;
      }
      mount();
      const target = mediaAt(doc, host, point.x, point.y);
      if (target === "button") {
        clearTimeout(hideTimer);
        return;
      }
      if (!target) {
        if (current) hideSoon();
        return;
      }
      clearTimeout(hideTimer);
      if (target !== current) {
        let next = null;
        try {
          next = find(target);
        } catch (error) {
          log?.error("Couldn't work out what to download", error);
        }
        if (!next) {
          hideSoon();
          return;
        }
        current = target;
        found = next;
        showState();
      }
      button.hidden = false;
      place2();
    }
    function fresh() {
      if (!active()) return null;
      if (!current?.isConnected && point) {
        const below = mediaAt(doc, host, point.x, point.y, { through: true });
        current = below && below !== "button" ? below : null;
      }
      if (!current) return null;
      try {
        return find(current);
      } catch (error) {
        log?.error("Couldn't work out what to download", error);
        return null;
      }
    }
    async function onClick(event) {
      event.preventDefault();
      event.stopPropagation();
      if (busy()) return;
      found = fresh();
      if (!found) {
        if (active()) onMissing?.();
        hide2();
        return;
      }
      const media = current;
      saving.add(media);
      showState();
      try {
        await run(found, shadow);
      } catch (error) {
        log?.error(failText, error);
      } finally {
        saving.delete(media);
        if (current === media) showState();
        if (!current) button.hidden = true;
      }
    }
    const onMove = (event) => {
      point = { x: event.clientX, y: event.clientY };
      if (!frame) frame = win.requestAnimationFrame(check);
    };
    const onScroll = () => {
      if (current) win.requestAnimationFrame(place2);
    };
    doc.addEventListener("pointermove", onMove, { capture: true, passive: true });
    win.addEventListener("scroll", onScroll, { capture: true, passive: true });
    return {
      hide: hide2,
      // For tests: the button's text and whether it shows.
      state: () => ({ shown: Boolean(button && !button.hidden), text: button?.textContent ?? "", top: button?.style.top, right: button?.style.right }),
      click: () => button?.click(),
      // The words may have changed for the media it's on, like Pop out after its window closed.
      refresh() {
        if (current && button && !busy()) showState();
      },
      stop() {
        if (frame) win.cancelAnimationFrame(frame);
        frame = 0;
        clearTimeout(hideTimer);
        doc.removeEventListener("pointermove", onMove, { capture: true });
        win.removeEventListener("scroll", onScroll, { capture: true });
        host?.remove();
      }
    };
  }

  // src/features/playback/picture-in-picture.js
  var POP_OUT_ICON = "M4 5h16v14H4zM12 12h6v5h-6z";
  function createPopOut({ doc, win, enabled, log, onPopOut }) {
    const button = createDownloadButton({
      doc,
      win,
      log,
      name: "picture-in-picture",
      row: 1,
      icon: POP_OUT_ICON,
      text: (video) => video && doc.pictureInPictureElement === video ? "Back to the page" : "Pop out",
      busyText: "Opening",
      failText: "The video couldn't pop out",
      active: enabled,
      find: (media) => media?.tagName === "VIDEO" && !media.disablePictureInPicture ? { video: media } : null,
      async run({ video }) {
        if (doc.pictureInPictureElement === video) {
          await doc.exitPictureInPicture();
          return;
        }
        await video.requestPictureInPicture();
        onPopOut?.();
      }
    });
    doc.addEventListener("enterpictureinpicture", () => button.refresh(), true);
    doc.addEventListener("leavepictureinpicture", () => button.refresh(), true);
    return button;
  }
  var picture_in_picture_default = {
    id: "pictureInPicture",
    section: "playback",
    android: "Picture-in-picture",
    title: "Picture-in-picture button",
    description: "Point at a video or reel and a Pop out button shows in its corner. Click it and the video keeps playing in a small window that stays on top while you use other tabs and apps.",
    default: false,
    setup({ doc, win, enabled, log, diagnostics, markUnavailable }) {
      if (!doc.pictureInPictureEnabled || typeof doc.exitPictureInPicture !== "function") {
        markUnavailable?.();
        return;
      }
      let popped = 0;
      createPopOut({ doc, win: win ?? doc.defaultView, enabled, log, onPopOut: () => {
        popped++;
      } });
      diagnostics?.add("Videos popped out", () => String(popped));
    }
  };

  // src/features/playback/keep-controls.js
  var KEEP = "data-hfw-keep-controls";
  var CHECK_EVERY = 1e3;
  var MAX_LEVELS2 = 12;
  var KEEP_CONTROLS_CSS = `[${KEEP}] { opacity: 1 !important; visibility: visible !important; }`;
  var isVideo4 = (node) => node?.tagName === "VIDEO";
  var TRACKS = 2;
  function positionSlider(video, seen = /* @__PURE__ */ new WeakMap()) {
    const length = Math.round(video.duration);
    if (!Number.isFinite(length) || length <= 0) return null;
    let node = video.parentElement;
    for (let level = 0; node && level < MAX_LEVELS2; level++, node = node.parentElement) {
      const sliders2 = [...node.querySelectorAll('[role="slider"]')];
      if (!sliders2.length) continue;
      const fits = sliders2.filter((slider) => Math.abs(Number(slider.getAttribute("aria-valuemax")) - length) <= 1);
      const moved = /* @__PURE__ */ new Set();
      for (const slider of fits) {
        const value = slider.getAttribute("aria-valuenow");
        const before = seen.get(slider);
        seen.set(slider, value);
        if (before !== void 0 && before !== value) moved.add(slider);
      }
      if (fits.length <= 1) return fits[0] ?? null;
      const tracking = fits.filter((slider) => Math.abs(Number(slider.getAttribute("aria-valuenow") ?? Number.NaN) - video.currentTime) <= TRACKS);
      if (tracking.length <= 1) return tracking[0] ?? null;
      if (video.currentTime <= TRACKS) return null;
      return tracking.find((slider) => moved.has(slider)) ?? null;
    }
    return null;
  }
  function keepShown(video, slider, styleOf2) {
    let marked = false;
    for (let node = slider; node && !node.contains(video); node = node.parentElement) {
      if (node.hasAttribute(KEEP)) continue;
      const style = styleOf2(node);
      if (Number(style.opacity) < 1 || style.visibility === "hidden") {
        node.setAttribute(KEEP, "");
        marked = true;
      }
    }
    return marked;
  }
  function createControlsKeeper({ doc, enabled, now = () => Date.now(), styleOf: styleOf2 = (node) => doc.defaultView.getComputedStyle(node), inReelsOrStories = () => /^\/(?:reels?|stories)\//.test(doc.location?.pathname ?? "") }) {
    const checked = /* @__PURE__ */ new WeakMap();
    const values = /* @__PURE__ */ new WeakMap();
    let kept = 0;
    function check(video) {
      if (!isVideo4(video) || !enabled() || inReelsOrStories()) return;
      const time = now();
      if (time - (checked.get(video) ?? Number.NEGATIVE_INFINITY) < CHECK_EVERY) return;
      checked.set(video, time);
      const slider = positionSlider(video, values);
      if (slider && keepShown(video, slider, styleOf2)) kept++;
    }
    return {
      start() {
        doc.addEventListener("timeupdate", (event) => check(event.target), true);
        doc.addEventListener("pause", (event) => check(event.target), true);
      },
      check,
      // Switched off: the CSS stops applying, and the marks go too so nothing is left behind.
      clear() {
        for (const node of doc.querySelectorAll(`[${KEEP}]`)) node.removeAttribute(KEEP);
      },
      kept: () => kept
    };
  }
  var keep_controls_default = {
    id: "keepControls",
    section: "playback",
    android: "Keep the progress bar",
    title: "Keep video controls on screen",
    description: "A video's progress bar and buttons stay on screen instead of fading out when you move the mouse away. Reels already keep theirs.",
    default: false,
    css: KEEP_CONTROLS_CSS,
    setup({ doc, enabled, settings, diagnostics }) {
      const keeper = createControlsKeeper({ doc, enabled });
      keeper.start();
      settings?.subscribe(() => {
        if (!enabled()) keeper.clear();
      });
      diagnostics?.add("Video controls kept on screen", () => String(keeper.kept()));
    }
  };

  // src/features/playback/video-quality.js
  var CHOICES = [
    { value: "highest", label: "The best it has" },
    { value: "1080", label: "Up to 1080p" },
    { value: "720", label: "Up to 720p" },
    { value: "480", label: "Up to 480p, to save data" },
    { value: "360", label: "Up to 360p, to save the most data" }
  ];
  var MARKERS4 = ['"manifest_xml"', '"dash_manifest"', '"all_video_dash_prefetch_representations"', '"dash_prefetch_experimental"'];
  var MAX_REMEMBERED3 = 5e3;
  var SET = /<AdaptationSet\b[^>]*?(?:\/>|>[\s\S]*?<\/AdaptationSet>)/g;
  var REPRESENTATION = /<Representation\b[^>]*?(?:\/>|>[\s\S]*?<\/Representation>)/g;
  var isVideoSet = (set) => /^<AdaptationSet\b[^>]*\bcontentType="video"/.test(set) || /^<AdaptationSet\b[^>]*\bmimeType="video\//.test(set) || !/^<AdaptationSet\b[^>]*\bcontentType=/.test(set) && /<Representation\b[^>]*\bmimeType="video\//.test(set);
  function qualityOf(representation) {
    const label = representation.match(/\bFBQualityLabel="(\d+)p/);
    if (label) return Number(label[1]);
    const width = Number(representation.match(/\bwidth="(\d+)"/)?.[1]);
    const height = Number(representation.match(/\bheight="(\d+)"/)?.[1]);
    return width && height ? Math.min(width, height) : null;
  }
  function keepQualities(qualities, choice) {
    const known = qualities.filter((quality) => quality !== null);
    if (!known.length) return qualities.map(() => true);
    if (choice === "highest") {
      const best = Math.max(...known);
      return qualities.map((quality) => quality === best);
    }
    const cap = Number(choice);
    if (!Number.isFinite(cap)) return qualities.map(() => true);
    const under = known.filter((quality) => quality <= cap);
    const allowed = under.length ? (quality) => quality !== null && quality <= cap : (quality) => quality === Math.min(...known);
    return qualities.map(allowed);
  }
  var copyId = (representation) => representation.match(/^<Representation\b[^>]*?\bid="([^"]+)"/)?.[1] ?? null;
  function createCopyBook() {
    const copies = /* @__PURE__ */ new Map();
    let answer = 0;
    let set = 0;
    const put = (id, entry) => {
      copies.delete(id);
      copies.set(id, entry);
    };
    return {
      nextAnswer() {
        answer++;
      },
      instead: (id) => copies.get(id)?.best ?? null,
      kept: (id) => copies.has(id) && copies.get(id).best === null,
      quality: (id) => copies.get(id)?.best === null ? copies.get(id).quality : null,
      makeRoom(count) {
        set++;
        let forgetting = null;
        for (const [id, entry] of copies) {
          if (entry.set !== forgetting) {
            if (copies.size + count <= MAX_REMEMBERED3 || entry.answer >= answer) return;
            forgetting = entry.set;
          }
          copies.delete(id);
        }
      },
      keep(id, quality = null) {
        if (id) put(id, { quality, best: null, answer, set });
      },
      replace(id, best) {
        if (id && best) put(id, { quality: null, best, answer, set });
      }
    };
  }
  function capManifest(xml, choice, book = createCopyBook()) {
    if (typeof xml !== "string" || !xml.includes("<Representation")) return xml;
    return xml.replace(SET, (set) => {
      if (!isVideoSet(set)) return set;
      const copies = set.match(REPRESENTATION) ?? [];
      if (!copies.length) return set;
      const qualities = copies.map(qualityOf);
      const keep = copies.length < 2 ? [true] : keepQualities(qualities, choice);
      let best = null;
      copies.forEach((copy, i) => {
        if (keep[i] && (best === null || (qualities[i] ?? -1) >= (qualities[best] ?? -1))) best = i;
      });
      book.makeRoom(copies.length);
      copies.forEach((copy, i) => {
        if (keep[i]) book.keep(copyId(copy), qualities[i]);
        else book.replace(copyId(copy), copyId(copies[best]));
      });
      if (keep.every(Boolean)) return set;
      let index = 0;
      return set.replace(REPRESENTATION, (copy) => keep[index++] ? copy : "");
    });
  }
  var isVideoCopy = (copy) => /^video\//.test(copy?.mime_type ?? "");
  function capPrefetch(entry, book) {
    const copies = entry?.representations;
    if (!Array.isArray(copies) || !copies.some(isVideoCopy)) return { entry, changed: false };
    const keeps = (copy) => !isVideoCopy(copy) || book.kept(copy?.representation_id);
    if (!copies.some((copy) => isVideoCopy(copy) && keeps(copy))) return null;
    const left = copies.filter(keeps);
    let changed = left.length !== copies.length;
    if (changed) entry.representations = left;
    if (Array.isArray(entry.initial_representation_ids)) {
      const ids = new Set(left.map((copy) => copy?.representation_id));
      const videos = new Set(copies.filter(isVideoCopy).map((copy) => copy.representation_id));
      const bestLeft = left.filter(isVideoCopy).map((copy) => copy.representation_id).reduce((best, id) => best === null || (book.quality(id) ?? -1) > (book.quality(best) ?? -1) ? id : best, null);
      const swap = (id) => {
        const best = book.instead(id);
        if (best === null) return videos.has(id) && !ids.has(id) ? bestLeft ?? id : id;
        return ids.has(best) ? best : bestLeft ?? best;
      };
      const initial = [...new Set(entry.initial_representation_ids.map(swap))].filter((id) => ids.has(id));
      if (initial.length !== entry.initial_representation_ids.length || initial.some((id, i) => id !== entry.initial_representation_ids[i])) {
        entry.initial_representation_ids = initial;
        changed = true;
      }
    }
    return { entry, changed };
  }
  function capAnswer(data, choice, book = createCopyBook()) {
    book.nextAnswer();
    let videos = 0;
    let changed = false;
    const cap = (holder, key) => {
      const before = holder[key];
      const after = capManifest(before, choice, book);
      if (after !== before) {
        holder[key] = after;
        videos++;
        changed = true;
      }
    };
    walk(data, (value) => {
      if (Array.isArray(value.dash_manifests)) {
        for (const entry of value.dash_manifests) if (entry && typeof entry.manifest_xml === "string") cap(entry, "manifest_xml");
      }
      if (typeof value.dash_manifest === "string") cap(value, "dash_manifest");
    });
    walk(data, (value) => {
      const list = value.all_video_dash_prefetch_representations;
      if (Array.isArray(list)) {
        const results = list.map((entry) => capPrefetch(entry, book));
        const ready = results.filter(Boolean).map((result) => result.entry);
        if (ready.length !== list.length) {
          value.all_video_dash_prefetch_representations = ready;
          changed = true;
        }
        if (results.some((result) => result?.changed)) changed = true;
      }
      const picks = value.dash_prefetch_experimental;
      if (Array.isArray(picks) && picks.some((id) => book.instead(id) !== null)) {
        value.dash_prefetch_experimental = picks.map((id) => book.instead(id) ?? id);
        changed = true;
      }
    });
    return { videos, changed };
  }
  var video_quality_default = {
    id: "videoQuality",
    section: "playback",
    android: "Default playback quality",
    title: "Default video quality",
    description: "Videos and reels play at the quality you pick instead of the one Facebook picks for your connection. A video with nothing under your cap plays its smallest copy. It applies to videos Facebook loads after you change it.",
    default: false,
    needsPage: true,
    options: [{ key: "quality", type: "select", label: "Play videos at", default: "highest", choices: CHOICES }],
    setup({ net, enabled, option, diagnostics }) {
      let videos = 0;
      let book = createCopyBook();
      let bookFor = null;
      net.transformResponses({
        id: "videoQuality",
        enabled,
        markers: MARKERS4,
        // Facebook's own JSON.parse sees every answer and the page's inline data, so one place
        // covers them all.
        match: (ctx) => ctx.transport === "json-parse",
        transform(data) {
          const choice = option("quality") ?? "highest";
          if (choice !== bookFor) {
            book = createCopyBook();
            bookFor = choice;
          }
          const result = capAnswer(data, choice, book);
          videos += result.videos;
          if (result.videos) diagnostics?.changed();
          return result.changed;
        }
      });
      diagnostics?.add("Videos set to your quality", () => String(videos));
    }
  };

  // src/features/appearance/declutter-table.js
  var HOSTS = ["https://www.facebook.com", "https://web.facebook.com"];
  var absolute = (path) => HOSTS.map((host) => `a[href^="${host}${path}"]`).join(", ");
  var LEFT = `[role="navigation"]:not([role="banner"] *):has(${absolute("/friends/")}):has(${absolute("/groups/")})`;
  var MENU2 = '[role="dialog"]:has(a[href*="/pages/creation/"]):has(a[href*="/events/create/"])';
  function section(path) {
    return [`a[href="${path}"]`, `a[href^="${path}?"]`, ...HOSTS.flatMap((host) => [`a[href="${host}${path}"]`, `a[href^="${host}${path}?"]`])].join(", ");
  }
  var OFFSITE = 'a[href*="l.facebook.com/l.php"], a[href^="http"]:not([href*="facebook.com"]):not([href*="fbcdn.net"])';
  var TAB_ROWS = [
    { option: "video", label: "Video", link: [section("/watch/"), section("/reel/"), section("/video/")].join(", ") },
    { option: "marketplace", label: "Marketplace", link: section("/marketplace/") },
    { option: "gaming", label: "Gaming", link: section("/gaming/") },
    { option: "groups", label: "Groups", link: section("/groups/") },
    { option: "friends", label: "Friends", link: section("/friends/") }
  ];
  var PROMOTION_ROWS = [
    { option: "ads", label: "Ads Manager, Your Ad Activity and Create an ad", link: [section("/ad_campaign/landing.php"), section("/adsmanager/"), section("/ads/activity/"), 'a[href^="/ads/create_ad/"]', absolute("/ads/create_ad/")].join(", ") },
    { option: "gaming", label: "Gaming Video and Play games", link: [section("/gaming/"), section("/gaming/play/")].join(", ") }
  ];
  var UPSELL_LINK = [OFFSITE, section("/messenger_kids/")].join(", ");
  var each = (link, wrap) => link.split(/,\s*(?![^()]*\))/).map(wrap).join(",\n");
  var place = {
    tab: (link) => each(link, (a) => `[role="banner"] li:has(${a})`),
    left: (link) => each(link, (a) => `${LEFT} li:has(${a})`),
    menu: (link) => each(link, (a) => `${MENU2} [role="listitem"]:has(${a})`)
  };
  var FIND_FRIENDS = '[role="banner"] [role="navigation"] div:has(> a[href^="/friends/"]:not([aria-label]))';
  var hide = (selectors) => `${selectors} { display: none !important; }`;

  // src/features/opening/start.js
  var CLAIM = /* @__PURE__ */ Symbol.for("hushfacebook-web.home-redirect");
  var START = /* @__PURE__ */ Symbol.for("hushfacebook-web.visit-start");
  var STARTED_KEY = "hfw:started";
  function isPlainHome(href) {
    const url2 = new URL(href);
    return /^(www|web)\.facebook\.com$/.test(url2.hostname) && parseRoute(href).type === "home" && url2.search === "";
  }
  function claimHomeRedirect(win, id) {
    if (win[CLAIM] && win[CLAIM] !== id) return false;
    win[CLAIM] = id;
    return true;
  }
  function isVisitStart(win) {
    if (win[START] !== void 0) return win[START];
    let start;
    try {
      start = !win.sessionStorage.getItem(STARTED_KEY);
      win.sessionStorage.setItem(STARTED_KEY, "1");
    } catch {
      start = false;
    }
    const entry = win.performance?.getEntriesByType?.("navigation")?.[0];
    if (entry && entry.type !== "navigate") start = false;
    win[START] = start;
    return start;
  }

  // src/features/opening/marketplace-only.js
  var MARKETPLACE = "/marketplace/";
  var MARKETPLACE_LINKS = ['[role="banner"] a[href="/marketplace/"]', ...HOSTS.map((host) => `[role="navigation"] a[href^="${host}/marketplace/"]`)].join(", ");
  var LOOP_MARK = "data-hfw-marketplace-loop";
  var GUARD_KEY = "hfw:marketplaceOnlyGuard";
  var BOUNCE_MS = 6e4;
  var MAX_BOUNCES = 4;
  var STOP_MS = 10 * 6e4;
  var OTHER_TABS = ['a[href="/"]', ...TAB_ROWS.filter((row) => row.option !== "marketplace").map((row) => row.link)].join(", ");
  var MARKETPLACE_ONLY_CSS = [
    hide([place.tab(OTHER_TABS), FIND_FRIENDS].join(",\n")),
    `html[data-hfw-route="home"]:not([${LOOP_MARK}]) [role="main"] { visibility: hidden !important; }`
  ].join("\n");
  function readGuard(storage) {
    try {
      const guard = JSON.parse(storage.getItem(GUARD_KEY) ?? "{}");
      return guard && typeof guard === "object" ? guard : {};
    } catch {
      return {};
    }
  }
  function mayRedirect(win, now = Date.now()) {
    try {
      const storage = win.sessionStorage;
      const guard = readGuard(storage);
      if (Number.isFinite(guard.stopped) && now - guard.stopped >= 0 && now - guard.stopped < STOP_MS) return false;
      const bounced = Number.isFinite(guard.sent) && now - guard.sent >= 0 && now - guard.sent < BOUNCE_MS;
      const bounces = bounced ? (Number(guard.bounces) || 0) + 1 : 0;
      if (bounces >= MAX_BOUNCES) {
        storage.setItem(GUARD_KEY, JSON.stringify({ stopped: now }));
        return false;
      }
      storage.setItem(GUARD_KEY, JSON.stringify({ sent: now, bounces }));
      return true;
    } catch {
      return true;
    }
  }
  function noteInput(win) {
    try {
      const guard = readGuard(win.sessionStorage);
      if (Number.isFinite(guard.sent)) win.sessionStorage.removeItem(GUARD_KEY);
    } catch {
    }
  }
  var isHome = (href) => {
    try {
      const url2 = new URL(href);
      return /^(www|web)\.facebook\.com$/.test(url2.hostname) && parseRoute(href).type === "home";
    } catch {
      return false;
    }
  };
  function goToMarketplace(win) {
    const link = win.document.querySelector(MARKETPLACE_LINKS);
    if (link) link.click();
    else win.location.assign(MARKETPLACE);
  }
  var marketplace_only_default = {
    id: "marketplaceOnly",
    section: "opening",
    android: "Marketplace only",
    title: "Marketplace only",
    description: "Turns Facebook into Marketplace for buying and selling, without the feed. Facebook opens on Marketplace, Home takes you there too, and the top bar keeps only Marketplace and its buttons. Profiles, chats and notifications still open. While this is on, Open on a chosen tab waits.",
    default: false,
    css: MARKETPLACE_ONLY_CSS,
    setup({ win, router, enabled, log }) {
      let warned = false;
      const leaveHome = () => {
        if (mayRedirect(win)) {
          win.location.replace(MARKETPLACE);
          return;
        }
        win.document?.documentElement?.setAttribute(LOOP_MARK, "");
        if (warned) return;
        warned = true;
        log?.warn("Marketplace only stopped sending Home to Marketplace for a while, because Marketplace keeps sending this tab back. It may not be open to this account.");
      };
      if (enabled() && isHome(win.location.href) && claimHomeRedirect(win, "marketplaceOnly")) leaveHome();
      let counting = true;
      const onInput = (event) => {
        if (!counting || !event.isTrusted || !enabled() || isHome(win.location.href)) return;
        counting = false;
        noteInput(win);
      };
      win.addEventListener("pointerdown", onInput, { capture: true, passive: true });
      win.addEventListener("keydown", onInput, { capture: true, passive: true });
      win.addEventListener("click", (event) => {
        if (!enabled() || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        const anchor = event.composedPath().find((node) => node?.tagName === "A" && node.hasAttribute?.("href"));
        if (!anchor || !isHome(anchor.href)) return;
        const target = anchor.getAttribute("target");
        if (target && target !== "_self" || anchor.hasAttribute("download")) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        goToMarketplace(win);
      }, { capture: true });
      router?.subscribe((route) => {
        if (route.type !== "home") win.document?.documentElement?.removeAttribute(LOOP_MARK);
        else if (enabled()) leaveHome();
      });
    }
  };

  // src/features/opening/following-feed.js
  var GUARD_KEY2 = "hfw:followingFeedRedirect";
  var GUARD_MS = 15e3;
  function followingFeedUrl(filter) {
    return `/?filter=${encodeURIComponent(filter)}&sk=h_chr`;
  }
  var following_feed_default = {
    id: "followingFeed",
    section: "opening",
    android: "Following feed on Home",
    title: "Following feed on Home",
    description: "Home shows the newest posts from the friends, groups and Pages you follow instead of Facebook's ranked feed.",
    default: false,
    options: [
      {
        key: "filter",
        type: "select",
        label: "Show posts from",
        default: "all",
        choices: [
          { value: "all", label: "Everyone you follow" },
          { value: "friends", label: "Friends" },
          { value: "favorites", label: "Favorites" },
          { value: "groups", label: "Groups" },
          { value: "pages", label: "Pages" }
        ]
      }
    ],
    setup({ win, enabled, option, log }) {
      const target = () => followingFeedUrl(option("filter"));
      if (enabled() && isPlainHome(win.location.href) && claimHomeRedirect(win, "followingFeed")) {
        let recent;
        try {
          recent = Date.now() - Number(win.sessionStorage.getItem(GUARD_KEY2) ?? 0) < GUARD_MS;
          win.sessionStorage.setItem(GUARD_KEY2, String(Date.now()));
        } catch {
          recent = false;
        }
        if (recent) log.warn("Facebook sent Home back to its ranked feed, so the Following feed redirect stopped to avoid a loop");
        else win.location.replace(target());
      }
      win.addEventListener(
        "click",
        (event) => {
          if (!enabled() || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
          const anchor = event.composedPath().find((node) => node?.tagName === "A" && node.hasAttribute?.("href"));
          if (!anchor || !isPlainHome(anchor.href)) return;
          event.preventDefault();
          event.stopImmediatePropagation();
          win.location.assign(target());
        },
        { capture: true }
      );
    }
  };

  // src/features/opening/open-on-tab.js
  var TABS = [
    { value: "marketplace", label: "Marketplace", path: "/marketplace/" },
    { value: "feeds", label: "Feeds, newest posts first", path: followingFeedUrl("all") },
    { value: "video", label: "Video", path: "/watch/" },
    { value: "friends", label: "Friends", path: "/friends/" },
    { value: "groups", label: "Your groups feed", path: "/groups/feed/" },
    { value: "notifications", label: "Notifications", path: "/notifications/" },
    { value: "menu", label: "Menu", path: "/bookmarks/" }
  ];
  function startPath(tab, settings) {
    if (tab === "feeds" && settings?.enabled("followingFeed")) return followingFeedUrl(settings.get("followingFeed.filter") ?? "all");
    return (TABS.find((entry) => entry.value === tab) ?? TABS[0]).path;
  }
  var open_on_tab_default = {
    id: "openOnTab",
    section: "opening",
    android: "Open on a chosen tab",
    title: "Open on a chosen tab",
    description: "Facebook opens on the page you pick instead of Home when you start it in a new tab, so you can skip the feed. Links into Facebook still open where they lead, and Home is still there when you click it.",
    default: false,
    options: [
      { key: "tab", type: "select", label: "Open on", default: "marketplace", choices: TABS.map(({ value, label }) => ({ value, label })) }
    ],
    setup({ win, settings, enabled, option, log }) {
      const start = isVisitStart(win);
      if (!start || !enabled() || !isPlainHome(win.location.href) || !claimHomeRedirect(win, "openOnTab")) return;
      const path = startPath(option("tab"), settings);
      log?.info(`Open on a chosen tab: this visit starts on ${path}`);
      win.location.replace(path);
    }
  };

  // src/core/media-index.js
  var MAX_ITEMS = 4e3;
  var PHOTO_IMAGES = ["viewer_image", "image", "photo_image", "previewImage", "large_image"];
  var LEGACY_VIDEO = [
    ["playable_url_quality_hd", "HD"],
    ["browser_native_hd_url", "HD"],
    ["playable_url", "SD"],
    ["browser_native_sd_url", "SD"]
  ];
  var MEDIA_MARKERS = ['"progressive_url"', '"playable_url', '"browser_native_', '"viewer_image"', '"photo_image"', '"image":{"uri"', '"story_card_info"'];
  var isObject2 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
  var isUrl = (value) => typeof value === "string" && /^https:\/\//.test(value);
  function videoFiles(video) {
    const result = video?.videoDeliveryResponseFragment?.videoDeliveryResponseResult;
    const files = [];
    const seen = /* @__PURE__ */ new Set();
    const add = (url2, quality) => {
      if (!isUrl(url2) || seen.has(url2)) return;
      seen.add(url2);
      files.push({ url: url2, quality });
    };
    for (const entry of Array.isArray(result?.progressive_urls) ? result.progressive_urls : []) {
      if (entry?.failure_reason) continue;
      add(entry?.progressive_url, entry?.metadata?.quality === "HD" ? "HD" : "SD");
    }
    for (const source of [video, video?.videoDeliveryLegacyFields]) {
      for (const [key, quality] of LEGACY_VIDEO) add(source?.[key], quality);
    }
    files.sort((a, b) => a.quality === b.quality ? 0 : a.quality === "HD" ? -1 : 1);
    const dash = Boolean(result?.dash_manifests?.length || result?.dash_manifest_urls?.length || result?.hls_playlist_urls?.length || video?.dash_manifest || video?.playlist);
    return { files, dash };
  }
  function photoFile(photo) {
    let best = null;
    for (const key of PHOTO_IMAGES) {
      const image = photo?.[key];
      if (!isObject2(image) || !isUrl(image.uri)) continue;
      const width = Number(image.width) || 0;
      const height = Number(image.height) || 0;
      if (!best || width * height > best.width * best.height) best = { url: image.uri, width, height };
    }
    return best;
  }
  function createMediaIndex({ max = MAX_ITEMS } = {}) {
    const items = /* @__PURE__ */ new Map();
    const cards = /* @__PURE__ */ new Map();
    const owners = /* @__PURE__ */ new Map();
    const put = (map, key, value) => {
      map.delete(key);
      map.set(key, value);
      if (map.size > max) map.delete(map.keys().next().value);
    };
    function record(value) {
      const id = typeof value.id === "string" ? value.id : null;
      if (id && value.__typename === "Video") {
        const { files, dash } = videoFiles(value);
        const old = items.get(id);
        if (files.length || dash) {
          if (!(old?.kind === "video" && old.files.length > files.length)) {
            put(items, id, {
              kind: "video",
              id,
              files,
              dash,
              width: Number(value.original_width ?? value.width) || null,
              height: Number(value.original_height ?? value.height) || null
            });
          }
        }
      } else if (id && value.__typename === "Photo") {
        const file = photoFile(value);
        const old = items.get(id);
        if (file && old?.kind !== "video" && !(old?.kind === "photo" && old.width * old.height >= file.width * file.height)) {
          put(items, id, { kind: "photo", id, ...file });
        }
      }
      if (id && "story_card_info" in value && Array.isArray(value.attachments)) {
        const media = value.attachments.map((attachment) => attachment?.media).find((m) => typeof m?.id === "string");
        if (media) put(cards, id, media.id);
      }
      const owner = value.story_bucket_owner?.name;
      if (typeof owner === "string" && Array.isArray(value.unified_stories_with_notes?.edges)) {
        for (const edge of value.unified_stories_with_notes.edges) {
          if (typeof edge?.node?.id === "string") put(owners, edge.node.id, owner);
        }
      }
    }
    return {
      // Reads every photo, video and story card in a parsed answer.
      scan(doc) {
        walk(doc, (value) => {
          if (!Array.isArray(value)) record(value);
        });
      },
      get: (id) => id === null || id === void 0 ? null : items.get(String(id)) ?? null,
      // What a story card shows, by the id in the story viewer's address, and whose it is.
      card: (cardId) => {
        const item = items.get(cards.get(cardId));
        return item ? { ...item, author: owners.get(cardId) ?? null } : null;
      },
      size: () => items.size
    };
  }

  // src/features/downloads/shared.js
  var instances = /* @__PURE__ */ new WeakMap();
  var QUALITY_OPTION = {
    key: "quality",
    type: "select",
    label: "Video quality",
    default: "best",
    choices: [{ value: "best", label: "Best (HD when there is one)" }, { value: "sd", label: "Smaller file (SD)" }]
  };
  function create({ win, doc, net, router, diagnostics, log, toast, api = gmApi() }) {
    const index = createMediaIndex();
    const switches = /* @__PURE__ */ new Map();
    const anyOn = () => [...switches.values()].some((s) => s.enabled());
    let saved = 0;
    let failed = 0;
    net?.transformResponses({
      id: "mediaIndex",
      enabled: anyOn,
      markers: MEDIA_MARKERS,
      match: (ctx) => ctx.transport === "json-parse",
      transform(data) {
        index.scan(data);
        return false;
      }
    });
    diagnostics?.add("Downloads", () => {
      const known = net ? `${index.size()} photos and videos known` : "Photos only: the script can't reach the page's data";
      return `${known}, ${saved} saved, ${failed} failed this visit`;
    });
    async function run(found, container) {
      const settings = switches.get(found.feature);
      const plan = planSave(found, { quality: settings?.quality?.() });
      if (plan.error) {
        toast?.(plan.error, { tone: "error" });
        return;
      }
      try {
        const how = await saveFile({ url: plan.url, name: plan.name, api, doc, win, container });
        saved++;
        toast?.(how === "manager" ? `Saving ${plan.name}` : `Saved ${plan.name}`);
      } catch (error) {
        if (error.cancelled) {
          toast?.(`Cancelled ${plan.name}`);
          return;
        }
        failed++;
        log?.error(`Couldn't save ${plan.name}`, error);
        toast?.(`Couldn't save it: ${error.message}.`, { tone: "error" });
      } finally {
        diagnostics?.changed();
      }
    }
    const button = createDownloadButton({
      doc,
      win,
      log,
      run,
      active: anyOn,
      onMissing: () => toast?.("There's nothing to save under the button now. Point at the photo or video again."),
      find(element) {
        const found = findMedia(element, { href: router?.current()?.href ?? win.location.href, index });
        return found && switches.get(found.feature)?.enabled() ? found : null;
      }
    });
    return {
      index,
      button,
      run,
      add(featureId, { enabled, quality = null }) {
        switches.set(featureId, { enabled, quality });
      }
    };
  }
  function downloads(ctx) {
    const key = ctx.doc ?? globalThis.document;
    let shared = instances.get(key);
    if (!shared) {
      shared = create(ctx);
      instances.set(key, shared);
    }
    return shared;
  }

  // src/features/downloads/download-photos.js
  var download_photos_default = {
    id: "downloadPhotos",
    section: "downloads",
    android: "Download any photo",
    title: "Download any photo",
    description: "Shows a Download button on photos in posts and in the photo viewer when you point at them. It saves the largest copy Facebook sent.",
    default: true,
    setup(ctx) {
      downloads(ctx).add("downloadPhotos", { enabled: ctx.enabled });
    }
  };

  // src/features/downloads/download-videos.js
  var download_videos_default = {
    id: "downloadVideos",
    section: "downloads",
    android: "Download any video",
    title: "Download any video",
    description: "Shows a Download button on videos in the feed and in Watch when you point at them. Videos save in the best quality Facebook offers unless you pick smaller files.",
    default: false,
    needsPage: true,
    options: [QUALITY_OPTION],
    setup(ctx) {
      downloads(ctx).add("downloadVideos", { enabled: ctx.enabled, quality: () => ctx.option("quality") });
    }
  };

  // src/features/downloads/download-reels.js
  var download_reels_default = {
    id: "downloadReels",
    section: "downloads",
    android: "Download any reel",
    title: "Download any reel",
    description: "Shows a Download button on reels when you point at them. Reels save in the best quality Facebook offers unless you pick smaller files.",
    default: true,
    needsPage: true,
    options: [QUALITY_OPTION],
    setup(ctx) {
      downloads(ctx).add("downloadReels", { enabled: ctx.enabled, quality: () => ctx.option("quality") });
    }
  };

  // src/features/downloads/download-stories.js
  var download_stories_default = {
    id: "downloadStories",
    section: "downloads",
    android: "Download any story",
    title: "Download any story",
    description: "Shows a Download button on the story you're watching when you point at it. Videos save in the best quality Facebook offers unless you pick smaller files.",
    default: true,
    needsPage: true,
    options: [QUALITY_OPTION],
    setup(ctx) {
      downloads(ctx).add("downloadStories", { enabled: ctx.enabled, quality: () => ctx.option("quality") });
    }
  };

  // src/features/appearance/force-dark.js
  var LIGHT = "__fb-light-mode";
  var DARK = "__fb-dark-mode";
  var MAX_SWAPS = 20;
  var MAX_LAYER_SWAPS = 200;
  var SWAP_WINDOW = 5e3;
  var WATCHERS = /* @__PURE__ */ Symbol.for("hushfacebook-web.theme-watchers");
  var METHODS = ["add", "replace", "toggle"];
  function themeWritten(method, args, result) {
    if (method === "add") return args.includes(DARK) ? DARK : args.includes(LIGHT) ? LIGHT : null;
    if (method === "replace") return result && (args[1] === DARK || args[1] === LIGHT) ? args[1] : null;
    return result === true && (args[0] === DARK || args[0] === LIGHT) ? args[0] : null;
  }
  function watchThemeWrites(doc, watcher) {
    const list = doc.documentElement?.classList;
    const proto = list ? Object.getPrototypeOf(list) : null;
    if (!proto || typeof proto.add !== "function") return;
    if (!Object.hasOwn(proto, WATCHERS)) {
      const watchers = /* @__PURE__ */ new Set();
      Object.defineProperty(proto, WATCHERS, { value: watchers });
      for (const method of METHODS) {
        const original = proto[method];
        if (typeof original !== "function") continue;
        proto[method] = function(...args) {
          const result = original.apply(this, args);
          if (watchers.size) {
            const theme = themeWritten(method, args, result);
            if (theme) {
              for (const watch of watchers) {
                try {
                  watch(this, theme);
                } catch {
                }
              }
            }
          }
          return result;
        };
      }
    }
    proto[WATCHERS].add(watcher);
    return () => proto[WATCHERS].delete(watcher);
  }
  function createDarkKeeper({ doc, enabled, log, now = () => Date.now(), isRootList = (list) => list === doc.documentElement?.classList }) {
    let swapped = false;
    let writing = false;
    let unwatch = null;
    let observer = null;
    const swaps = [];
    const layerSwaps = [];
    const layers = /* @__PURE__ */ new WeakSet();
    let layerCount = 0;
    let gaveUp = false;
    const tooMany = (list, max) => {
      const time = now();
      while (list.length && time - list[0] > SWAP_WINDOW) list.shift();
      list.push(time);
      return list.length > max;
    };
    const giveUp = () => {
      gaveUp = true;
      log?.warn("Force dark mode stopped: something on the page keeps switching Facebook back to light");
    };
    function changedLights(records) {
      const found = /* @__PURE__ */ new Set();
      for (const record of records) {
        if (record.type === "attributes") {
          if (record.target.classList?.contains(LIGHT)) found.add(record.target);
          continue;
        }
        for (const node of record.addedNodes) {
          if (node.nodeType !== 1) continue;
          if (node.classList.contains(LIGHT)) found.add(node);
          for (const inner of node.getElementsByClassName(LIGHT)) found.add(inner);
        }
      }
      return found;
    }
    const swapRoot = (root, from, to) => {
      writing = true;
      try {
        root.classList.replace(from, to);
      } finally {
        writing = false;
      }
    };
    const facebookWrote = (list, theme) => {
      if (writing || theme !== DARK || !isRootList(list)) return;
      swapped = false;
    };
    function apply(records) {
      const root = doc.documentElement;
      if (!root) return;
      const want = enabled() && !gaveUp;
      if (want) {
        unwatch ??= watchThemeWrites(doc, facebookWrote) ?? (() => {
        });
        if (root.classList.contains(LIGHT)) {
          if (tooMany(swaps, MAX_SWAPS)) return giveUp();
          swapRoot(root, LIGHT, DARK);
          swapped = true;
        }
        const lights = records ? changedLights(records) : [...doc.getElementsByClassName(LIGHT)];
        for (const layer of lights) {
          if (layer === root || !layer.classList.contains(LIGHT)) continue;
          if (layers.has(layer)) {
            if (tooMany(layerSwaps, MAX_LAYER_SWAPS)) return giveUp();
          } else {
            layerCount += 1;
            layers.add(layer);
          }
          layer.classList.replace(LIGHT, DARK);
        }
        return void 0;
      }
      if (swapped && root.classList.contains(DARK)) {
        swapRoot(root, DARK, LIGHT);
        swapped = false;
      }
      if (layerCount) {
        for (const layer of [...doc.getElementsByClassName(DARK)]) {
          if (!layers.has(layer)) continue;
          layer.classList.replace(DARK, LIGHT);
          layers.delete(layer);
        }
        layerCount = 0;
      }
      return void 0;
    }
    function start() {
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      observer = new Observer((records) => apply(records));
      observer.observe(doc.documentElement, { attributes: true, attributeFilter: ["class"], childList: true, subtree: true });
      apply();
    }
    return {
      start: () => whenRootReady(start, doc),
      apply: () => apply(),
      state: () => ({ swapped, gaveUp, layers: layerCount }),
      stop: () => {
        observer?.disconnect();
        unwatch?.();
        unwatch = null;
      }
    };
  }
  var force_dark_default = {
    id: "forceDarkMode",
    section: "appearance",
    android: "Force dark mode",
    title: "Force dark mode",
    description: "Keeps Facebook in its dark theme, whatever Facebook's own setting says. Switch it off and Facebook's choice comes back.",
    default: false,
    setup({ doc, settings, enabled, log }) {
      const keeper = createDarkKeeper({ doc, enabled, log });
      keeper.start();
      settings?.subscribe(() => keeper.apply());
    }
  };

  // src/features/appearance/amoled.js
  var BLACK = "#000000";
  var RAISED = "#121212";
  var POPOVER = "#1A1A1A";
  var AMOLED_VARS = {
    "--web-wash": BLACK,
    "--wash": BLACK,
    "--surface-background": BLACK,
    "--card-background": BLACK,
    "--nav-bar-background": BLACK,
    "--messenger-card-background": BLACK,
    "--card-background-flat": RAISED,
    "--comment-background": RAISED,
    "--input-background": RAISED,
    "--input-background-disabled": RAISED,
    "--messenger-reply-background": RAISED,
    "--toast-background": RAISED,
    "--popover-background": POPOVER
  };
  function amoledCss() {
    const lines = Object.entries(AMOLED_VARS).map(([name, value]) => `  ${name}: ${value} !important;`);
    return `.__fb-dark-mode {
${lines.join("\n")}
}`;
  }
  var amoled_default = {
    id: "amoledTheme",
    section: "appearance",
    android: "AMOLED black theme",
    title: "AMOLED black theme",
    description: "Pure black in place of Facebook's dark gray. It changes dark mode only, so turn on Facebook's dark mode or Force dark mode with it.",
    default: false,
    css: amoledCss
  };

  // src/features/appearance/accent.js
  var ACCENTS = [
    { value: "purple", label: "Purple", hex: "#7B3FE4" },
    { value: "pink", label: "Pink", hex: "#D6246E" },
    { value: "red", label: "Red", hex: "#D93025" },
    { value: "orange", label: "Orange", hex: "#E8590C" },
    { value: "green", label: "Green", hex: "#1E8E3E" },
    { value: "teal", label: "Teal", hex: "#00897B" },
    { value: "graphite", label: "Graphite", hex: "#5F6368" }
  ];
  function parseHex(value) {
    const match = /^#?([0-9a-f]{6})$/i.exec(String(value ?? "").trim());
    if (!match) return null;
    const n = Number.parseInt(match[1], 16);
    return [n >> 16 & 255, n >> 8 & 255, n & 255];
  }
  function toHsl([r, g, b]) {
    const [rr, gg, bb] = [r / 255, g / 255, b / 255];
    const max = Math.max(rr, gg, bb);
    const min = Math.min(rr, gg, bb);
    const l = (max + min) / 2;
    if (max === min) return [0, 0, l * 100];
    const d = max - min;
    const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    const h2 = max === rr ? (gg - bb) / d + (gg < bb ? 6 : 0) : max === gg ? (bb - rr) / d + 2 : (rr - gg) / d + 4;
    return [h2 * 60, s * 100, l * 100];
  }
  function toHex([h2, s, l]) {
    const ss = s / 100;
    const ll = l / 100;
    const a = ss * Math.min(ll, 1 - ll);
    const channel = (n) => {
      const k = (n + h2 / 30) % 12;
      return ll - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
    };
    return `#${[channel(0), channel(8), channel(4)].map((x) => Math.round(x * 255).toString(16).padStart(2, "0")).join("").toUpperCase()}`;
  }
  function luminance(rgb) {
    const [r, g, b] = rgb.map((c) => {
      const x = c / 255;
      return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }
  function palette(hex) {
    const rgb = parseHex(hex);
    if (!rgb) return null;
    const hsl = toHsl(rgb);
    const l = hsl[2];
    const at = (lightness) => toHex([hsl[0], hsl[1], lightness]);
    const alpha = (a) => `rgba(${rgb.join(", ")}, ${a})`;
    return {
      base: toHex(hsl),
      onBase: luminance(rgb) > 0.45 ? "#080809" : "#FFFFFF",
      alpha,
      light: {
        link: at(Math.min(l, 41)),
        toastLink: at(Math.min(l, 49)),
        pressed: at(Math.max(l, 73)),
        button: at(93),
        highlight: at(95),
        selected: at(96)
      },
      dark: {
        focus: at(Math.max(l, 55)),
        label: at(Math.max(l, 61)),
        toastLink: at(Math.max(l, 64)),
        link: at(Math.max(l, 68)),
        deemphasized: at(Math.max(l, 73))
      }
    };
  }
  function chosenColor(get) {
    const custom = String(get("accentColor.custom") ?? "").trim();
    if (parseHex(custom)) return custom.startsWith("#") ? custom : `#${custom}`;
    return (ACCENTS.find((accent) => accent.value === get("accentColor.color")) ?? ACCENTS[0]).hex;
  }
  var FILTER_IDS = {
    base: "hfw-accent-base",
    lightLink: "hfw-accent-link",
    darkLink: "hfw-accent-link-dark",
    darkDeemphasized: "hfw-accent-deemphasized-dark"
  };
  function filterColors(colors) {
    return {
      [FILTER_IDS.base]: colors.base,
      [FILTER_IDS.lightLink]: colors.light.link,
      [FILTER_IDS.darkLink]: colors.dark.link,
      [FILTER_IDS.darkDeemphasized]: colors.dark.deemphasized
    };
  }
  var url = (id) => `url("#${id}")`;
  var block = (selector, vars) => `${selector} {
${Object.entries(vars).map(([name, value]) => `  ${name}: ${value} !important;`).join("\n")}
}`;
  function accentCss(hex) {
    const colors = palette(hex);
    if (!colors) return "";
    const { base, onBase, alpha, light, dark } = colors;
    const shared = {
      "--accent": base,
      "--primary-button-background": base,
      "--primary-button-text": onBase,
      "--primary-button-icon": onBase,
      "--cursor": base,
      "--progress-ring-blue-foreground": base,
      "--progress-ring-blue-background": alpha(0.2),
      "--primary-deemphasized-button-pressed-overlay": alpha(0.15),
      "--filter-primary-accent": url(FILTER_IDS.base)
    };
    return [
      block(":root, .__fb-light-mode", {
        ...shared,
        "--focus-ring-blue": base,
        "--primary-button-pressed": light.pressed,
        "--blue-link": light.link,
        "--primary-deemphasized-button-text": light.link,
        "--primary-deemphasized-button-icon": light.link,
        "--toggle-active-icon": light.link,
        "--toggle-active-text": light.link,
        "--input-label-color-highlighted": light.link,
        "--toast-text-link": light.toastLink,
        "--primary-deemphasized-button-background": light.button,
        "--highlight-bg": light.highlight,
        "--toggle-active-background": light.selected,
        "--hosted-view-selected-state": light.selected,
        "--text-highlight": alpha(0.2),
        "--filter-accent": url(FILTER_IDS.base),
        "--filter-blue-link-icon": url(FILTER_IDS.lightLink),
        "--filter-primary-deemphasized-button-icon": url(FILTER_IDS.lightLink)
      }),
      block(".__fb-dark-mode", {
        ...shared,
        "--focus-ring-blue": dark.focus,
        "--toggle-active-background": dark.focus,
        "--primary-button-pressed": dark.deemphasized,
        "--blue-link": dark.link,
        "--primary-deemphasized-button-text": dark.deemphasized,
        "--primary-deemphasized-button-icon": dark.deemphasized,
        "--input-label-color-highlighted": dark.label,
        "--toast-text-link": dark.toastLink,
        "--primary-deemphasized-button-background": alpha(0.2),
        "--highlight-bg": alpha(0.31),
        "--text-highlight": alpha(0.45),
        "--hosted-view-selected-state": alpha(0.1),
        "--filter-accent": url(FILTER_IDS.darkLink),
        "--filter-blue-link-icon": url(FILTER_IDS.darkLink),
        "--filter-primary-deemphasized-button-icon": url(FILTER_IDS.darkDeemphasized)
      })
    ].join("\n");
  }
  var SVG_NS = "http://www.w3.org/2000/svg";
  var FILTERS_MARK = "data-hfw-accent-filters";
  function writeFilters(doc, colors) {
    let svg = doc.querySelector(`svg[${FILTERS_MARK}]`);
    if (!svg) {
      svg = doc.createElementNS(SVG_NS, "svg");
      svg.setAttribute(FILTERS_MARK, "");
      svg.setAttribute("aria-hidden", "true");
      svg.setAttribute("width", "0");
      svg.setAttribute("height", "0");
      svg.setAttribute("style", "position:absolute;width:0;height:0;overflow:hidden;pointer-events:none");
      (doc.body ?? doc.documentElement).append(svg);
    }
    const defs = doc.createElementNS(SVG_NS, "defs");
    for (const [id, color] of Object.entries(colors)) {
      const filter = doc.createElementNS(SVG_NS, "filter");
      filter.setAttribute("id", id);
      filter.setAttribute("color-interpolation-filters", "sRGB");
      const flood = doc.createElementNS(SVG_NS, "feFlood");
      flood.setAttribute("flood-color", color);
      const composite = doc.createElementNS(SVG_NS, "feComposite");
      composite.setAttribute("in2", "SourceAlpha");
      composite.setAttribute("operator", "in");
      filter.append(flood, composite);
      defs.append(filter);
    }
    svg.replaceChildren(defs);
    return svg;
  }
  var accent_default = {
    id: "accentColor",
    section: "appearance",
    android: "Accent color",
    title: "Accent color",
    description: "Your own color in place of Facebook's blue, for buttons, links, switches and highlights, in both light and dark mode.",
    default: false,
    options: [
      { key: "color", type: "select", label: "Color", default: ACCENTS[0].value, choices: ACCENTS.map(({ value, label }) => ({ value, label })) },
      { key: "custom", type: "text", lines: 1, label: "Or your own color, like #7B3FE4", default: "", maxLength: 7 }
    ],
    css: (get) => accentCss(chosenColor(get)),
    setup({ doc, settings, enabled, log }) {
      if (!doc) return;
      const sync = () => {
        try {
          const existing = doc.querySelector(`svg[${FILTERS_MARK}]`);
          if (!enabled()) {
            existing?.remove();
            return;
          }
          writeFilters(doc, filterColors(palette(chosenColor(settings.get))));
        } catch (error) {
          log?.error("Accent color: the icon colors couldn't be set", error);
        }
      };
      whenBodyReady(sync, doc);
      settings?.subscribe(() => whenBodyReady(sync, doc));
    }
  };

  // src/features/appearance/system-font.js
  var SYSTEM_STACK = 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans", "Helvetica Neue", Arial, sans-serif';
  var FONT_VARS = ["--font-family-default", "--font-family-segoe", "--font-family-apple", "--font-family-system-fds"];
  function fontName(value) {
    const name = String(value ?? "").trim().replace(/\s+/g, " ");
    return /^[\p{L}\p{N}][\p{L}\p{N} ._&+-]{0,63}$/u.test(name) ? name : "";
  }
  function fontStack(get) {
    const name = fontName(get("systemFont.font"));
    return name ? `"${name}", ${SYSTEM_STACK}` : SYSTEM_STACK;
  }
  function fontCss(get) {
    const stack = fontStack(get);
    const vars = FONT_VARS.map((name) => `  ${name}: ${stack} !important;`).join("\n");
    return `:root, .__fb-light-mode, .__fb-dark-mode {
${vars}
}
body { font-family: ${stack} !important; }`;
  }
  var system_font_default = {
    id: "systemFont",
    section: "appearance",
    android: "Use the system font",
    title: "Use the system font",
    description: "Draws Facebook's text in your computer's own interface font, or in a font you have installed.",
    default: false,
    options: [
      { key: "font", type: "text", lines: 1, label: "Or a font you have installed, by name", default: "", maxLength: 64 }
    ],
    css: fontCss
  };

  // src/features/appearance/system-emoji.js
  var EMOJI_IMG = 'img[src*="/images/emoji.php/"]';
  var ORIGINAL = "data-hfw-emoji";
  var EMOJI_FONTS = "'Apple Color Emoji','Segoe UI Emoji','Noto Color Emoji','Twemoji Mozilla',sans-serif";
  function emojiText(img, src = img.getAttribute("src") ?? "") {
    const alt = img.getAttribute("alt") ?? "";
    if ([...alt].some((char) => char.codePointAt(0) > 255)) return alt;
    const match = /\/([0-9a-f]{2,6}(?:_[0-9a-f]{2,6})*)\.png(?:$|[?#])/i.exec(src);
    if (!match) return null;
    try {
      return String.fromCodePoint(...match[1].split("_").map((hex) => Number.parseInt(hex, 16)));
    } catch {
      return null;
    }
  }
  var escapeXml = (text) => text.replace(/[&<>"']/g, (char) => `&#${char.codePointAt(0)};`);
  function emojiPicture(text) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><text x="10" y="10.5" font-size="16" text-anchor="middle" dominant-baseline="central" font-family="${EMOJI_FONTS}">${escapeXml(text)}</text></svg>`;
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  }
  function swapEmoji(img) {
    const src = img.getAttribute("src") ?? "";
    if (!src.includes("/images/emoji.php/")) return false;
    const text = emojiText(img, src);
    if (!text) return false;
    img.setAttribute(ORIGINAL, src);
    img.setAttribute("src", emojiPicture(text));
    return true;
  }
  function restoreEmoji(img) {
    const original = img.getAttribute(ORIGINAL);
    img.removeAttribute(ORIGINAL);
    if (original) img.setAttribute("src", original);
  }
  function createEmojiSwapper({ doc, enabled, log }) {
    let observer = null;
    let swapped = 0;
    const swapIn = (root) => {
      if (root.nodeType !== 1) return;
      if (root.matches(EMOJI_IMG) && swapEmoji(root)) swapped += 1;
      for (const img of root.querySelectorAll(EMOJI_IMG)) if (swapEmoji(img)) swapped += 1;
    };
    const release = (img) => {
      const original = img.getAttribute(ORIGINAL);
      if (!original) return;
      const text = emojiText(img, original);
      if (img.getAttribute("src") !== (text && emojiPicture(text))) img.removeAttribute(ORIGINAL);
    };
    const onMutations = (records) => {
      try {
        for (const record of records) {
          if (record.type === "attributes") {
            release(record.target);
            swapIn(record.target);
          } else for (const node of record.addedNodes) swapIn(node);
        }
      } catch (error) {
        log?.error("Use system emoji: swapping an emoji failed", error);
      }
    };
    function start() {
      if (observer) return;
      const root = doc.documentElement;
      if (!root) return;
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      observer = new Observer(onMutations);
      observer.observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ["src"] });
      swapIn(root);
    }
    function stop() {
      observer?.disconnect();
      observer = null;
      for (const img of doc.querySelectorAll(`img[${ORIGINAL}]`)) restoreEmoji(img);
    }
    return {
      apply: () => enabled() ? start() : stop(),
      state: () => ({ running: Boolean(observer), swapped })
    };
  }
  var system_emoji_default = {
    id: "systemEmoji",
    section: "appearance",
    android: "Use the phone's emoji",
    title: "Use your computer's emoji",
    description: "Shows emoji in posts, comments and chats with your own system's emoji instead of Facebook's pictures of them.",
    default: false,
    setup({ doc, settings, enabled, log, diagnostics }) {
      if (!doc) return;
      const swapper = createEmojiSwapper({ doc, enabled, log });
      const apply = () => {
        if (doc.documentElement) swapper.apply();
      };
      if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", apply, { once: true });
      else apply();
      settings?.subscribe(apply);
      diagnostics?.add("Emoji swapped for your own", () => enabled() ? String(swapper.state().swapped) : "off");
    }
  };

  // src/features/appearance/no-transitions.js
  var ANIMATED = '*:not([role="progressbar"], [role="progressbar"] *)';
  var NO_TRANSITIONS_CSS = `${ANIMATED}, ${ANIMATED}::before, ${ANIMATED}::after {
  transition-duration: 0.001ms !important;
  transition-delay: 0s !important;
  animation-duration: 0.001ms !important;
  animation-delay: 0s !important;
  animation-iteration-count: 1 !important;
}
html { scroll-behavior: auto !important; }`;
  var no_transitions_default = {
    id: "noTransitions",
    section: "appearance",
    android: "Turn off screen transitions",
    title: "Turn off screen transitions",
    description: "Menus, dialogs and pages appear at once, without Facebook's fades and slides. Loading spinners keep turning.",
    default: false,
    css: NO_TRANSITIONS_CSS
  };

  // src/features/appearance/hide-tabs.js
  var ON_BY_DEFAULT = /* @__PURE__ */ new Set(["video", "marketplace", "gaming"]);
  function tabsCss(get) {
    const links = TAB_ROWS.filter(({ option }) => get(`hideTabs.${option}`)).map(({ link }) => place.tab(link));
    if (get("hideTabs.findFriends")) links.push(FIND_FRIENDS);
    return links.length ? hide(links.join(",\n")) : "";
  }
  var hide_tabs_default = {
    id: "hideTabs",
    section: "appearance",
    android: "Hide tabs",
    title: "Hide tabs",
    description: "Takes the top bar tabs you pick off Facebook, and the Find friends button. Home always stays, and the tabs' pages still open from the left column.",
    default: false,
    options: [
      ...TAB_ROWS.map(({ option, label }) => ({ key: option, type: "toggle", label: `Hide ${label}`, default: ON_BY_DEFAULT.has(option) })),
      { key: "findFriends", type: "toggle", label: "Hide the Find friends button", default: true }
    ],
    css: tabsCss
  };

  // src/features/appearance/hide-tab-badges.js
  var BADGE_MARK = "data-hfw-badge";
  var COUNT = /^\d{1,3}\+?$/;
  var SCOPES = '[role="banner"], [role="navigation"]';
  var INTERACTIVE = 'a, button, [role="button"], [role="link"], [role="tab"], [role="menuitem"]';
  var TITLE_COUNT = /^\(\d{1,3}\+?\)\s*/;
  var cleanTitle = (title) => String(title ?? "").replace(TITLE_COUNT, "");
  var transparent = (color) => !color || color === "transparent" || /^rgba\(\s*0,\s*0,\s*0,\s*0\s*\)$/.test(color);
  function drawnAsBadge(element, view) {
    const style = view.getComputedStyle(element);
    return style.position === "absolute" || style.position === "fixed" || !transparent(style.backgroundColor);
  }
  function badgeBox(leaf, view = leaf.ownerDocument.defaultView) {
    const count = leaf.textContent.trim();
    if (!COUNT.test(count) || leaf.closest(INTERACTIVE) === leaf) return null;
    let box = leaf;
    let badge = drawnAsBadge(leaf, view);
    for (let el = leaf.parentElement; el; el = el.parentElement) {
      if (el.matches(SCOPES) || el.matches(INTERACTIVE) || el.querySelector(INTERACTIVE)) break;
      if (el.textContent.trim() !== count) break;
      box = el;
      badge ||= drawnAsBadge(el, view);
    }
    return badge ? box : null;
  }
  function markBadges(doc) {
    const view = doc.defaultView;
    let marked = 0;
    for (const scope of doc.querySelectorAll(SCOPES)) {
      for (const leaf of scope.querySelectorAll("span, div")) {
        if (leaf.childElementCount || !COUNT.test(leaf.textContent.trim())) continue;
        const box = badgeBox(leaf, view);
        if (box && !box.hasAttribute(BADGE_MARK)) {
          box.setAttribute(BADGE_MARK, "");
          marked += 1;
        }
      }
    }
    return marked;
  }
  function createBadgeHider({ doc, enabled, log, delay = 150 }) {
    let observer = null;
    let timer = null;
    let hidden = 0;
    const fixTitle = () => {
      const clean = cleanTitle(doc.title);
      if (clean !== doc.title) doc.title = clean;
    };
    const scan = () => {
      timer = null;
      try {
        hidden += markBadges(doc);
        fixTitle();
      } catch (error) {
        log?.error("Hide tab badges: looking for counts failed", error);
      }
    };
    const later = () => {
      if (!timer) timer = setTimeout(scan, delay);
    };
    function start() {
      if (observer || !doc.documentElement) return;
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      observer = new Observer((records) => {
        let title = false;
        let scope = false;
        for (const record of records) {
          const element = record.target.nodeType === 1 ? record.target : record.target.parentElement;
          if (element?.closest("title")) title = true;
          else if (!scope && (element?.closest(SCOPES) || [...record.addedNodes].some((node) => node.nodeType === 1 && (node.matches(SCOPES) || node.querySelector(SCOPES))))) scope = true;
        }
        if (title) fixTitle();
        if (scope) later();
      });
      observer.observe(doc.documentElement, { subtree: true, childList: true, characterData: true });
      scan();
    }
    function stop() {
      observer?.disconnect();
      observer = null;
      if (timer) clearTimeout(timer);
      timer = null;
      for (const box of doc.querySelectorAll(`[${BADGE_MARK}]`)) box.removeAttribute(BADGE_MARK);
    }
    return {
      apply: () => enabled() ? start() : stop(),
      scan,
      state: () => ({ running: Boolean(observer), hidden })
    };
  }
  var hide_tab_badges_default = {
    id: "hideTabBadges",
    section: "appearance",
    android: "Hide tab badges",
    title: "Hide tab badges",
    description: "Hides the red counts on the top bar and left column, and the count in front of the browser tab's title. The notifications are still there when you open them.",
    default: false,
    css: `[${BADGE_MARK}] { display: none !important; }`,
    setup({ doc, settings, enabled, log, diagnostics }) {
      if (!doc) return;
      const hider = createBadgeHider({ doc, enabled, log });
      if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", () => hider.apply(), { once: true });
      else hider.apply();
      settings?.subscribe(() => hider.apply());
      diagnostics?.add("Counts hidden", () => enabled() ? String(hider.state().hidden) : "off");
    }
  };

  // src/features/menu/hide-menu-promotions.js
  function promotionsCss(get) {
    const rows = PROMOTION_ROWS.filter(({ option }) => get(`hideMenuPromotions.${option}`));
    if (!rows.length) return "";
    return hide(rows.flatMap(({ link }) => [place.left(link), place.menu(link)]).join(",\n"));
  }
  var hide_menu_promotions_default = {
    id: "hideMenuPromotions",
    section: "menu",
    android: "Hide Menu promotions",
    title: "Hide Menu promotions",
    description: "Takes Facebook's ad tools and gaming pitches out of the left column and Facebook's menu.",
    default: false,
    options: PROMOTION_ROWS.map(({ option, label }) => ({ key: option, type: "toggle", label, default: true })),
    css: promotionsCss
  };

  // src/ui/icons.js
  var SLIDERS_ICON = [
    "M3 5h10v2H3z",
    "M17 5h4v2h-4z",
    "M13 3h4v6h-4z",
    "M3 11h4v2H3z",
    "M11 11h10v2H11z",
    "M7 9h4v6H7z",
    "M3 17h12v2H3z",
    "M19 17h2v2h-2z",
    "M15 15h4v6h-4z"
  ];

  // src/features/menu/menu-entry.js
  var ROW_MARK = "data-hfw-menu-entry";
  var LABEL2 = "HushFacebook Web";
  var SVG_NS2 = "http://www.w3.org/2000/svg";
  var PROFILE_LINK = 'a[href="/me/"], a[href="/me"]';
  var RETRIES_MS = [0, 50, 150, 400, 1e3, 2500];
  function accountMenuList(doc) {
    for (const dialog of doc.querySelectorAll('[role="dialog"]')) {
      if (!dialog.querySelector(PROFILE_LINK)) continue;
      const list = dialog.querySelector('[role="list"]');
      if (list) return list;
    }
    return null;
  }
  function sliders(doc) {
    const svg = doc.createElementNS(SVG_NS2, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", "20");
    svg.setAttribute("height", "20");
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("style", "display: block; fill: var(--primary-icon, currentColor)");
    for (const d of SLIDERS_ICON) {
      const path = doc.createElementNS(SVG_NS2, "path");
      path.setAttribute("d", d);
      svg.append(path);
    }
    return svg;
  }
  var ownText2 = (el) => [...el.childNodes].some((node) => node.nodeType === 3 && node.textContent.trim());
  function buildRow(template, doc) {
    const row = template.cloneNode(true);
    for (const el of [row, ...row.querySelectorAll("*")]) {
      for (const name of ["id", "aria-label", "aria-labelledby", "aria-describedby"]) el.removeAttribute(name);
    }
    const [label, ...rest] = [...row.querySelectorAll("*")].filter(ownText2);
    if (!label) return null;
    label.textContent = LABEL2;
    for (const extra of rest) extra.textContent = "";
    row.querySelector("i, svg, img")?.replaceWith(sliders(doc));
    row.setAttribute(ROW_MARK, "");
    return row;
  }
  function addRow(list, doc, onOpen) {
    if (list.querySelector(`[${ROW_MARK}]`)) return "present";
    const rows = [...list.children].filter((el) => el.getAttribute("role") === "listitem");
    const last = rows.at(-1);
    const row = last && buildRow(last, doc);
    if (!row) return "no-row";
    const run = (event) => {
      event.preventDefault();
      event.stopPropagation();
      onOpen(row);
    };
    row.addEventListener("click", run);
    row.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") run(event);
    });
    list.insertBefore(row, last);
    return "added";
  }
  function closeMenu(doc, row) {
    const dialog = row.closest('[role="dialog"]');
    if (!dialog) return;
    const label = dialog.getAttribute("aria-label");
    const opener = label && [...doc.querySelectorAll('[role="banner"] [aria-expanded="true"]')].find((el) => el.getAttribute("aria-label") === label);
    if (opener) {
      opener.click();
      return;
    }
    const Keyboard = doc.defaultView?.KeyboardEvent ?? globalThis.KeyboardEvent;
    dialog.dispatchEvent(new Keyboard("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true, cancelable: true }));
  }
  function createMenuEntry({ doc, enabled, openSettings, log, onFail, setTimer = setTimeout }) {
    let added = 0;
    let failed = false;
    let opener = null;
    let watched = null;
    const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
    const open = (row) => {
      closeMenu(doc, row);
      setTimer(() => openSettings(), 0);
    };
    function sync() {
      if (!enabled()) {
        remove();
        return;
      }
      const list = accountMenuList(doc);
      if (!list) return;
      const result = addRow(list, doc, open);
      if (result === "added") added += 1;
      if (result === "no-row" && !failed) {
        failed = true;
        log?.warn("Settings in your account menu: Facebook's account menu has no row to copy, so the HushFacebook Web row isn't there.");
        onFail?.();
      }
      watch(list.closest('[role="dialog"]'));
    }
    function watch(dialog) {
      if (!dialog || watched?.dialog === dialog) return;
      watched?.observer.disconnect();
      const observer = new Observer(() => {
        if (!dialog.isConnected) {
          observer.disconnect();
          if (watched?.dialog === dialog) watched = null;
          return;
        }
        sync();
      });
      observer.observe(dialog, { childList: true, subtree: true });
      watched = { dialog, observer };
    }
    function remove() {
      watched?.observer.disconnect();
      watched = null;
      for (const row of doc.querySelectorAll(`[${ROW_MARK}]`)) row.remove();
    }
    function start() {
      if (opener || !doc.body) return;
      opener = new Observer((records) => {
        if (!enabled()) return;
        const opened = records.some((record) => record.target.getAttribute?.("aria-expanded") === "true" && record.target.closest?.('[role="banner"]'));
        if (opened) for (const wait of RETRIES_MS) setTimer(sync, wait);
      });
      opener.observe(doc.body, { subtree: true, attributes: true, attributeFilter: ["aria-expanded"] });
    }
    return {
      apply() {
        start();
        sync();
      },
      sync,
      state: () => ({ added, failed })
    };
  }
  var menu_entry_default = {
    id: "menuEntry",
    section: "menu",
    android: "Hushfacebook in the Menu",
    title: "Settings in your account menu",
    description: "Adds a HushFacebook Web row to the menu that opens from your picture at the right end of the top bar. Click it to open these settings.",
    default: true,
    options: [
      { key: "hideButton", type: "toggle", label: "Hide the round settings button in the corner", default: false }
    ],
    setup({ doc, settings, enabled, log, diagnostics, openSettings, markUnavailable }) {
      if (!doc) return;
      const entry = createMenuEntry({ doc, enabled, openSettings: () => openSettings?.(), log, onFail: () => markUnavailable?.() });
      whenBodyReady(() => entry.apply(), doc);
      settings?.subscribe(() => entry.apply());
      diagnostics?.add("Account menu row", () => {
        if (!enabled()) return "off";
        const { added, failed } = entry.state();
        if (failed) return "Facebook's menu had no row to copy";
        return added ? `Added ${added} ${added === 1 ? "time" : "times"}` : "Menu not opened yet";
      });
    }
  };

  // src/features/meta/hide-meta-upsells.js
  var UPSELLS_CSS = hide([place.left(UPSELL_LINK), place.menu(UPSELL_LINK)].join(",\n"));
  var hide_meta_upsells_default = {
    id: "hideMetaUpsells",
    section: "meta",
    android: "Hide Meta upsells",
    title: "Hide Meta upsells",
    description: "Takes Meta AI, Meta Quest, Ray-Ban Meta, WhatsApp, Instagram and Messenger Kids out of the left column and Facebook's menu.",
    default: false,
    css: UPSELLS_CSS
  };

  // src/features/meta/hide-promotions.js
  var MARKERS5 = ['"eligible_promotions"', '"jewel_qp"'];
  var LISTS = ["eligible_promotions", "jewel_qp"];
  function emptyPromotions(data) {
    let removed = 0;
    (function visit(value, depth) {
      if (!value || typeof value !== "object" || depth > 60) return;
      if (Array.isArray(value)) {
        for (const item of value) visit(item, depth + 1);
        return;
      }
      for (const key of LISTS) {
        const nodes = value[key]?.nodes;
        if (Array.isArray(nodes) && nodes.length) {
          removed += nodes.length;
          value[key].nodes = [];
        }
      }
      for (const child of Object.values(value)) visit(child, depth + 1);
    })(data, 0);
    return removed;
  }
  var hide_promotions_default = {
    id: "hidePromotions",
    section: "meta",
    android: "Hide the Get Messenger card",
    title: "Hide Facebook's own cards and tips",
    description: "Takes out the cards Facebook puts up for its own things, like Get the Messenger app over your chats or in the Messenger menu and the tips in stories. Reminders Facebook sends the same way go too.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let removed = 0;
      net.transformResponses({
        id: "hidePromotions",
        enabled,
        markers: MARKERS5,
        // Facebook parses every answer with JSON.parse, so one place covers them all.
        match: (ctx) => ctx.transport === "json-parse",
        transform(data) {
          const count = emptyPromotions(data);
          if (count) {
            removed += count;
            diagnostics?.changed();
          }
          return count > 0;
        }
      });
      diagnostics?.add("Cards and tips held back", () => String(removed));
    }
  };

  // src/features/appearance/custom-css.js
  var custom_css_default = {
    id: "customCss",
    section: "appearance",
    android: "Custom CSS",
    title: "Custom CSS",
    description: "Your own CSS rules for Facebook, applied after everything else the script does. Handy when Facebook moves something before a switch catches up.",
    default: false,
    options: [
      { key: "css", type: "text", rows: 8, code: true, label: "CSS rules", default: "", maxLength: 5e4 }
    ],
    css: (get) => String(get("customCss.css") ?? "")
  };

  // src/features/index.js
  var features = [
    hide_sponsored_posts_default,
    hide_suggested_posts_default,
    hide_reels_in_feed_default,
    hide_stories_tray_default,
    filters_default,
    hide_seen_posts_default,
    hide_ai_posts_default,
    post_dates_default,
    keep_feed_place_default,
    hide_sponsored_reels_default,
    no_watch_history_default,
    anonymous_stories_default,
    stop_advance_default,
    hide_sponsored_search_default,
    hide_sponsored_marketplace_default,
    seller_profile_default,
    hide_read_receipts_default,
    hide_typing_default,
    hide_kinds_default,
    usage_logs_default,
    comment_order_default,
    show_all_replies_default,
    hide_comment_stickers_default,
    hide_comment_typing_default,
    tags_after_at_default,
    comments_as_written_default,
    sanitize_links_default,
    direct_links_default,
    download_photos_default,
    download_videos_default,
    download_reels_default,
    download_stories_default,
    tap_to_play_default,
    hdr_brightness_default,
    resume_videos_default,
    keep_speed_default,
    hold_for_speed_default,
    picture_in_picture_default,
    keep_controls_default,
    video_quality_default,
    force_dark_default,
    amoled_default,
    accent_default,
    system_font_default,
    system_emoji_default,
    no_transitions_default,
    hide_tabs_default,
    hide_tab_badges_default,
    menu_entry_default,
    hide_menu_promotions_default,
    hide_meta_upsells_default,
    hide_promotions_default,
    // In this order: the first to claim a Home load redirects it (opening/start.js).
    marketplace_only_default,
    open_on_tab_default,
    following_feed_default,
    // Last, so its rules come after every built-in style.
    custom_css_default
  ];

  // src/features/sections.js
  var SECTIONS = [
    { id: "feed", title: "News feed" },
    { id: "reels", title: "Reels and Watch" },
    { id: "stories", title: "Stories" },
    { id: "comments", title: "Comments" },
    { id: "search", title: "Search" },
    { id: "marketplace", title: "Marketplace" },
    { id: "chats", title: "Chats" },
    { id: "notifications", title: "Notifications" },
    { id: "privacy", title: "Privacy" },
    { id: "links", title: "Links" },
    { id: "downloads", title: "Downloads" },
    { id: "playback", title: "Playback" },
    { id: "appearance", title: "Appearance" },
    { id: "menu", title: "Menu" },
    { id: "meta", title: "Meta's other products" },
    { id: "opening", title: "Opening Facebook" },
    { id: "writing", title: "Writing" }
  ];

  // src/ui/h.js
  function h(tag, props, ...children) {
    const el = document.createElement(tag);
    for (const [key, value] of Object.entries(props ?? {})) {
      if (value === void 0 || value === null || value === false) continue;
      if (key === "class") el.className = value;
      else if (key === "text") el.textContent = value;
      else if (key === "dataset") Object.assign(el.dataset, value);
      else if (key.startsWith("on") && typeof value === "function") el.addEventListener(key.slice(2), value);
      else if (typeof value === "boolean" || typeof value === "number") el[key] = value;
      else el.setAttribute(key, value);
    }
    for (const child of children.flat(Infinity)) {
      if (child === null || child === void 0 || child === false) continue;
      el.append(child instanceof Node ? child : String(child));
    }
    return el;
  }
  var SVG_NS3 = "http://www.w3.org/2000/svg";
  function icon(paths, label) {
    const svg = document.createElementNS(SVG_NS3, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", label ? "false" : "true");
    if (label) svg.setAttribute("aria-label", label);
    for (const d of paths) {
      const path = document.createElementNS(SVG_NS3, "path");
      path.setAttribute("d", d);
      svg.append(path);
    }
    return svg;
  }

  // src/ui/styles.js
  var panelCss = `
:host { all: initial; }
* { box-sizing: border-box; }
.root {
  --base: #1e1e2e; --mantle: #181825; --crust: #11111b;
  --surface0: #313244; --surface1: #45475a; --overlay0: #6c7086;
  --text: #cdd6f4; --subtext: #a6adc8; --accent: #cba6f7; --accent-ink: #11111b;
  --green: #a6e3a1; --red: #f38ba8; --peach: #fab387;
  font: 14px/1.45 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  color: var(--text);
}
button, input, select, textarea { font: inherit; color: inherit; }
button { cursor: pointer; }
:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }

.launcher {
  position: fixed; left: 16px; bottom: 16px; z-index: 2147483000;
  width: 40px; height: 40px; border-radius: 50%; border: 1px solid rgba(203, 166, 247, 0.35);
  background: rgba(30, 30, 46, 0.82); backdrop-filter: blur(10px);
  display: grid; place-items: center; box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.launcher:hover { transform: translateY(-2px); box-shadow: 0 10px 26px rgba(0, 0, 0, 0.45); }
.launcher svg { width: 20px; height: 20px; fill: var(--accent); }
.launcher[hidden] { display: none; }

.overlay {
  position: fixed; inset: 0; z-index: 2147483001; display: grid; place-items: center;
  background: rgba(17, 17, 27, 0.55); backdrop-filter: blur(6px);
}
.overlay[hidden] { display: none; }
.dialog {
  width: min(900px, calc(100vw - 32px)); height: min(660px, calc(100vh - 32px));
  display: grid; grid-template-rows: auto 1fr; overflow: hidden;
  background: linear-gradient(160deg, rgba(49, 50, 68, 0.55), rgba(30, 30, 46, 0.96) 40%);
  border: 1px solid rgba(203, 166, 247, 0.22); border-radius: 16px;
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.55);
}
header { display: flex; align-items: center; gap: 12px; padding: 14px 18px; border-bottom: 1px solid var(--surface0); }
header h2 { margin: 0; font-size: 17px; font-weight: 650; }
.chip { font-size: 12px; padding: 2px 8px; border-radius: 999px; background: var(--surface0); color: var(--subtext); }
.spacer { flex: 1; }
.icon-button { border: 0; background: transparent; width: 32px; height: 32px; border-radius: 8px; display: grid; place-items: center; }
.icon-button:hover { background: var(--surface0); }
.icon-button svg { width: 18px; height: 18px; fill: var(--subtext); }

.body { display: grid; grid-template-columns: 210px 1fr; min-height: 0; }
nav { padding: 10px; border-right: 1px solid var(--surface0); overflow-y: auto; background: rgba(17, 17, 27, 0.35); }
nav button {
  display: block; width: 100%; text-align: left; border: 0; background: transparent;
  padding: 8px 12px; border-radius: 8px; color: var(--subtext);
}
nav button:hover { background: var(--surface0); color: var(--text); }
nav button[aria-current="page"] { background: rgba(203, 166, 247, 0.16); color: var(--accent); font-weight: 600; }
nav hr { border: 0; border-top: 1px solid var(--surface0); margin: 8px 4px; }

main { overflow-y: auto; padding: 18px 20px 28px; }
main h3 { margin: 0 0 12px; font-size: 15px; }
.card {
  padding: 14px 16px; margin-bottom: 10px; border-radius: 12px;
  background: rgba(49, 50, 68, 0.45); border: 1px solid transparent;
  transition: transform 0.15s ease, border-color 0.15s ease;
}
.card:hover { transform: translateY(-1px); border-color: rgba(203, 166, 247, 0.25); }
.row { display: flex; align-items: flex-start; gap: 14px; }
.row .text { flex: 1; }
.title { font-weight: 600; }
.desc { color: var(--subtext); font-size: 13px; margin-top: 2px; }
.note { color: var(--peach); font-size: 12px; margin-top: 6px; }
.options { margin-top: 10px; padding-top: 10px; border-top: 1px solid var(--surface0); display: grid; gap: 8px; }
.options label { display: flex; align-items: center; gap: 10px; color: var(--subtext); font-size: 13px; }
.options select, .options input[type="text"], .options input[type="number"], .options textarea {
  background: var(--mantle); border: 1px solid var(--surface1); border-radius: 8px; padding: 5px 8px;
}
.options label:has(> textarea.code) { flex-direction: column; align-items: stretch; gap: 6px; }
.options textarea.code { font-family: ui-monospace, Consolas, Menlo, monospace; font-size: 12px; line-height: 1.5; resize: vertical; white-space: pre; tab-size: 2; }

.switch { appearance: none; flex: none; width: 40px; height: 22px; margin: 2px 0 0; border-radius: 999px; background: var(--surface1); position: relative; cursor: pointer; transition: background 0.15s ease; }
.switch::after { content: ""; position: absolute; top: 3px; left: 3px; width: 16px; height: 16px; border-radius: 50%; background: var(--text); transition: transform 0.15s ease; }
.switch:checked { background: var(--accent); }
.switch:checked::after { transform: translateX(18px); background: var(--accent-ink); }
.switch:disabled { opacity: 0.45; cursor: not-allowed; }

.actions { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }
.button { border: 1px solid var(--surface1); background: var(--surface0); padding: 7px 14px; border-radius: 8px; transition: transform 0.15s ease, background 0.15s ease; }
.button:hover { transform: translateY(-1px); background: var(--surface1); }
.button.primary { background: var(--accent); color: var(--accent-ink); border-color: var(--accent); font-weight: 600; }

dl { display: grid; grid-template-columns: max-content 1fr; gap: 4px 14px; margin: 0 0 14px; font-size: 13px; }
dt { color: var(--subtext); }
dd { margin: 0; }
.log { font: 12px/1.5 ui-monospace, "Cascadia Code", Consolas, monospace; background: var(--crust); border-radius: 10px; padding: 10px 12px; max-height: 300px; overflow: auto; white-space: pre-wrap; word-break: break-word; }
.log .warn { color: var(--peach); }
.log .error { color: var(--red); }
.empty { color: var(--subtext); }

.toasts { position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%); z-index: 2147483002; display: grid; gap: 8px; justify-items: center; }
.toast {
  display: flex; align-items: center; gap: 12px; padding: 10px 14px; border-radius: 10px;
  background: rgba(30, 30, 46, 0.94); border: 1px solid var(--surface1); box-shadow: 0 10px 30px rgba(0, 0, 0, 0.45);
  animation: rise 0.18s ease-out;
}
.toast.error { border-color: rgba(243, 139, 168, 0.6); }
.toast button { border: 0; background: transparent; color: var(--accent); font-weight: 600; }
@keyframes rise { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }

@media (max-width: 640px) {
  .body { grid-template-columns: 1fr; grid-template-rows: auto 1fr; }
  nav { display: flex; gap: 4px; overflow-x: auto; border-right: 0; border-bottom: 1px solid var(--surface0); }
  nav button { white-space: nowrap; width: auto; }
  nav hr { display: none; }
}
@media (prefers-reduced-motion: reduce) {
  * { transition: none !important; animation: none !important; }
}
`;

  // src/ui/panel.js
  var CLOSE_ICON = ["M6.4 5 12 10.6 17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4 6.4 19 5 17.6 10.6 12 5 6.4z"];
  var ERROR_TOAST_GAP_MS = 15e3;
  function mountPanel({ settings, features: features2, log, hider, diagnostics, actions, unavailable, environment }) {
    const host = h("div", { dataset: { hushfacebookWeb: "ui" }, style: "all: initial !important" });
    const shadow = host.attachShadow({ mode: "closed" });
    const root = h("div", { class: "root" });
    shadow.append(h("style", { text: panelCss }), root);
    const sections = [
      ...SECTIONS.filter((section2) => features2.some((feature) => feature.section === section2.id)),
      { id: "general", title: "General", divider: true },
      { id: "diagnostics", title: "Diagnostics" }
    ];
    let current = sections[0].id;
    const hasMenuEntry = features2.some((feature) => feature.id === "menuEntry");
    const toasts = h("div", { class: "toasts", "aria-live": "polite" });
    const launcher = h(
      "button",
      { class: "launcher", type: "button", "aria-label": "Open HushFacebook Web settings", title: "HushFacebook Web settings", onclick: () => open() },
      icon(SLIDERS_ICON)
    );
    const nav = h("nav", { "aria-label": "Settings sections" });
    const main = h("main");
    const pauseState = h("span", { class: "chip" });
    const power = h("input", {
      class: "switch",
      type: "checkbox",
      role: "switch",
      "aria-label": "HushFacebook Web on",
      onchange: (event) => apply("paused", !event.target.checked)
    });
    const closeButton = h("button", { class: "icon-button", type: "button", "aria-label": "Close settings", onclick: () => close() }, icon(CLOSE_ICON));
    const dialog = h(
      "div",
      { class: "dialog", role: "dialog", "aria-modal": "true", "aria-labelledby": "hfw-title" },
      h(
        "header",
        null,
        h("h2", { id: "hfw-title", text: "HushFacebook Web" }),
        h("span", { class: "chip", text: `v${environment.version}` }),
        h("span", { class: "spacer" }),
        pauseState,
        power,
        closeButton
      ),
      h("div", { class: "body" }, nav, main)
    );
    const overlay = h("div", { class: "overlay", hidden: true, onclick: (event) => event.target === overlay && close() }, dialog);
    const fileInput = h("input", { type: "file", accept: "application/json,.json", hidden: true, onchange: importSettings });
    root.append(launcher, overlay, toasts, fileInput);
    document.body.append(host);
    function apply(key, value) {
      try {
        settings.set(key, value);
      } catch (error) {
        log.error(`Couldn't save ${key}`, error);
      }
    }
    function toast(message, { tone = "info", action, duration } = {}) {
      const el = h(
        "div",
        { class: `toast ${tone}`, role: tone === "error" ? "alert" : null },
        h("span", { text: message }),
        action ? h("button", { type: "button", text: action.label, onclick: () => {
          el.remove();
          action.run();
        } }) : null
      );
      toasts.append(el);
      setTimeout(() => el.remove(), duration ?? (action ? 7e3 : 4e3));
    }
    function toggle(key, label, { disabled = false } = {}) {
      return h("input", {
        class: "switch",
        type: "checkbox",
        role: "switch",
        "aria-label": label,
        checked: settings.get(key) === true,
        disabled,
        dataset: { key },
        onchange: (event) => apply(key, event.target.checked)
      });
    }
    function optionControl(feature, option) {
      const key = `${feature.id}.${option.key}`;
      const value = settings.get(key);
      switch (option.type) {
        case "toggle":
          return h("label", null, toggle(key, option.label), option.label);
        case "select":
          return h(
            "label",
            null,
            option.label,
            h(
              "select",
              { dataset: { key }, onchange: (event) => apply(key, option.choices.find((choice) => String(choice.value) === event.target.value)?.value) },
              option.choices.map((choice) => h("option", { value: String(choice.value), selected: choice.value === value, text: choice.label }))
            )
          );
        case "number":
          return h(
            "label",
            null,
            option.label,
            h("input", { type: "number", value: String(value), min: option.min, max: option.max, dataset: { key }, onchange: (event) => apply(key, Number(event.target.value)) })
          );
        default:
          if (option.lines === 1) {
            return h(
              "label",
              null,
              option.label,
              h("input", { type: "text", value, maxLength: option.maxLength, spellcheck: "false", dataset: { key }, onchange: (event) => apply(key, event.target.value.trim()) })
            );
          }
          return h(
            "label",
            null,
            option.label,
            h("textarea", {
              rows: option.rows ?? 3,
              class: option.code ? "code" : void 0,
              spellcheck: option.code ? "false" : void 0,
              // The browser stops a paste at the setting's limit, rather than the save failing
              // and the text being lost on the next redraw.
              maxLength: option.maxLength,
              dataset: { key },
              onchange: (event) => apply(key, event.target.value)
            }, value)
          );
      }
    }
    function featureActions(feature) {
      const list = actions?.list(feature.id) ?? [];
      if (!list.length) return null;
      return h("div", { class: "actions" }, list.map(({ label, run }) => h("button", {
        class: "button",
        type: "button",
        text: label,
        onclick: () => {
          try {
            run();
          } catch (error) {
            log.error(`${feature.title}: ${label} failed`, error);
          }
          render();
        }
      })));
    }
    function featureCard(feature) {
      const blocked = unavailable.has(feature.id);
      const on = settings.get(feature.id) === true;
      return h(
        "div",
        { class: "card" },
        h(
          "div",
          { class: "row" },
          h(
            "div",
            { class: "text" },
            h("div", { class: "title", text: feature.title }),
            h("div", { class: "desc", text: feature.description }),
            blocked ? h("div", { class: "note", text: "This one isn't available the way your userscript manager runs the script. Diagnostics explains why." }) : null,
            feature.reload ? h("div", { class: "note", text: "Applies after Facebook reloads." }) : null
          ),
          toggle(feature.id, feature.title, { disabled: blocked })
        ),
        on && feature.options?.length ? h("div", { class: "options" }, feature.options.map((option) => optionControl(feature, option))) : null,
        on ? featureActions(feature) : null
      );
    }
    function sectionView(section2) {
      return [h("h3", { text: section2.title }), ...features2.filter((feature) => feature.section === section2.id).map(featureCard)];
    }
    function generalView() {
      return [
        h("h3", { text: "General" }),
        h(
          "div",
          { class: "card" },
          h(
            "div",
            { class: "row" },
            h(
              "div",
              { class: "text" },
              h("div", { class: "title", text: "Show the settings button" }),
              h("div", { class: "desc", text: "The round button in Facebook's bottom-left corner. Your userscript manager's menu always opens settings too, and so does the row in your account menu while Settings in your account menu is on." })
            ),
            toggle("ui.launcher", "Show the settings button")
          )
        ),
        h(
          "div",
          { class: "card" },
          h(
            "div",
            { class: "row" },
            h(
              "div",
              { class: "text" },
              h("div", { class: "title", text: "Leave a note where a post was hidden" }),
              h("div", { class: "desc", text: "A short line that says why a post was hidden. Click it to see the post." })
            ),
            toggle("ui.hiddenNote", "Leave a note where a post was hidden")
          )
        ),
        h(
          "div",
          { class: "card" },
          h("div", { class: "title", text: "Back up and restore" }),
          h("div", { class: "desc", text: "Save your choices to a file, or load them from one on another browser." }),
          h(
            "div",
            { class: "actions" },
            h("button", { class: "button primary", type: "button", text: "Back up settings", onclick: exportSettings }),
            h("button", { class: "button", type: "button", text: "Restore from a file", onclick: () => fileInput.click() }),
            h("button", { class: "button", type: "button", text: "Reset to defaults", onclick: resetSettings })
          )
        )
      ];
    }
    function hiddenSummary() {
      const counts = Object.entries(hider?.counts() ?? {});
      return counts.length ? counts.map(([reason, count]) => `${reason} ${count}`).join(", ") : "None yet";
    }
    const featureRows = () => diagnostics?.rows() ?? [];
    const decisions = () => diagnostics?.decisions?.() ?? [];
    function diagnosticsView() {
      const entries = log.entries().slice(-150);
      const blocked = features2.filter((feature) => unavailable.has(feature.id)).map((feature) => feature.title);
      return [
        h("h3", { text: "Diagnostics" }),
        h(
          "dl",
          null,
          h("dt", { text: "Version" }),
          h("dd", { text: environment.version }),
          h("dt", { text: "Userscript manager" }),
          h("dd", { text: `${environment.manager} ${environment.managerVersion}` }),
          h("dt", { text: "Injection mode" }),
          h("dd", { text: environment.mode }),
          h("dt", { text: "Page access" }),
          h("dd", { text: environment.pageAccess === "page" ? "Yes" : "No. Network and playback features are off. In Violentmonkey, set this script to inject into the page." }),
          h("dt", { text: "Features that didn't start" }),
          h("dd", { text: blocked.length ? blocked.join(", ") : "None" }),
          h("dt", { text: "Posts hidden since the page loaded" }),
          h("dd", { text: hiddenSummary() }),
          ...featureRows().flatMap(({ label, value }) => [h("dt", { text: label }), h("dd", { text: value })])
        ),
        h("div", { class: "actions" }, h("button", { class: "button primary", type: "button", text: "Copy report", onclick: copyReport })),
        h("h3", { text: "Why posts were hidden", style: "margin-top: 18px" }),
        h("p", { class: "desc", text: "The last 50, newest first. data means it came out of Facebook's data before it was drawn, page means it was hidden on the page. Each post has a short tag instead of its id." }),
        decisions().length ? h("div", { class: "log" }, decisions().slice().reverse().map((decision) => h("div", { text: decisionLine(decision) }))) : h("p", { class: "empty", text: "Nothing hidden yet." }),
        h("h3", { text: "Recent log", style: "margin-top: 18px" }),
        entries.length ? h("div", { class: "log" }, entries.map((entry) => h("div", { class: entry.level, text: `${entry.time.slice(11, 19)} ${entry.level.padEnd(5)} ${entry.message}${entry.detail ? `
    ${entry.detail}` : ""}` }))) : h("p", { class: "empty", text: "Nothing logged yet." })
      ];
    }
    function render() {
      const focusedKey = shadow.activeElement?.dataset?.key;
      nav.replaceChildren(...sections.flatMap((section3) => [
        section3.divider ? h("hr") : null,
        h("button", {
          type: "button",
          text: section3.title,
          dataset: { key: `nav:${section3.id}` },
          "aria-current": section3.id === current ? "page" : null,
          onclick: () => {
            current = section3.id;
            render();
          }
        })
      ]).filter(Boolean));
      const section2 = sections.find((entry) => entry.id === current);
      main.replaceChildren(...current === "general" ? generalView() : current === "diagnostics" ? diagnosticsView() : sectionView(section2));
      if (focusedKey) root.querySelector(`[data-key="${CSS.escape(focusedKey)}"]`)?.focus();
    }
    function refreshChrome() {
      const paused = settings.get("paused") === true;
      power.checked = !paused;
      pauseState.textContent = paused ? "Paused" : "On";
      const inMenu = hasMenuEntry && settings.enabled("menuEntry") && settings.get("menuEntry.hideButton") === true && !unavailable.has("menuEntry");
      launcher.hidden = settings.get("ui.launcher") !== true || inMenu;
    }
    function exportSettings() {
      const url2 = URL.createObjectURL(new Blob([settings.exportJson()], { type: "application/json" }));
      const link = h("a", { href: url2, download: `hushfacebook-web-settings-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json` });
      root.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url2), 1e4);
      toast("Settings saved to a file.");
    }
    async function importSettings() {
      const file = fileInput.files?.[0];
      fileInput.value = "";
      if (!file) return;
      try {
        const { applied, skipped } = settings.importJson(await file.text());
        const extra = skipped.length ? `, and skipped ${skipped.length} this version doesn't know` : "";
        toast(`Restored ${applied.length} settings${extra}.`);
      } catch (error) {
        log.error("Couldn't restore settings from that file", error);
      }
    }
    function resetSettings() {
      const previous = settings.reset();
      toast("Settings are back to their defaults.", { action: { label: "Undo", run: () => settings.restore(previous) } });
    }
    async function copyReport() {
      const report = [
        `HushFacebook Web ${environment.version}`,
        `Manager: ${environment.manager} ${environment.managerVersion}, mode ${environment.mode}, page access ${environment.pageAccess}`,
        `Browser: ${navigator.userAgent}`,
        `Changed settings: ${JSON.stringify(settings.snapshot())}`,
        `Unavailable: ${[...unavailable].join(", ") || "none"}`,
        `Hidden since the page loaded: ${hiddenSummary()}`,
        ...featureRows().map(({ label, value }) => `${label}: ${value}`),
        "",
        "Why posts were hidden, oldest first:",
        ...decisions().length ? decisions().map(decisionLine) : ["nothing yet"],
        "",
        ...log.entries().slice(-150).map((entry) => `${entry.time} ${entry.level} ${entry.message}${entry.detail ? ` | ${entry.detail}` : ""}`)
      ].join("\n");
      try {
        await navigator.clipboard.writeText(report);
        toast("Report copied. Paste it into a GitHub issue.");
      } catch (error) {
        log.error("Couldn't copy the report", error);
      }
    }
    function open(sectionId) {
      if (sectionId) current = sectionId;
      overlay.hidden = false;
      render();
      closeButton.focus();
    }
    function close() {
      overlay.hidden = true;
      if (!launcher.hidden) launcher.focus();
    }
    settings.subscribe(() => {
      refreshChrome();
      if (!overlay.hidden) render();
    });
    let lastErrorToast = 0;
    const announceError = (entry) => {
      if (Date.now() - lastErrorToast < ERROR_TOAST_GAP_MS) return;
      lastErrorToast = Date.now();
      toast(`${entry.message}. Details are in Diagnostics.`, { tone: "error", action: { label: "Open", run: () => open("diagnostics") } });
    };
    let renderQueued = false;
    const refreshDiagnostics = () => {
      if (overlay.hidden || current !== "diagnostics" || renderQueued) return;
      renderQueued = true;
      requestAnimationFrame(() => {
        renderQueued = false;
        if (!overlay.hidden && current === "diagnostics") render();
      });
    };
    log.subscribe((entry) => {
      if (entry.level === "error") announceError(entry);
      refreshDiagnostics();
    });
    hider?.subscribe(refreshDiagnostics);
    diagnostics?.subscribe(refreshDiagnostics);
    const earlier = log.entries().findLast((entry) => entry.level === "error");
    if (earlier) announceError(earlier);
    refreshChrome();
    return { open, close, toast, refresh: refreshChrome };
  }

  // src/main.js
  function signedInAccount() {
    try {
      return accountFromCookie(document.cookie);
    } catch {
      return null;
    }
  }
  var RUNNING = "data-hushfacebook-web";
  var DUPLICATE = "data-hushfacebook-web-duplicate";
  function boot() {
    const log = createLog();
    const storage = createGmStorage();
    const settings = createSettings({ storage, features, log, version, account: signedInAccount() });
    const net = pageAccess === "page" ? installNetworkHooks({ win: pageWindow, log }) : null;
    const router = createRouter({ win: pageWindow, pageAccess, log });
    const posts = createPostTracker({ doc: document, log });
    const diagnostics = createDiagnostics();
    const hider = createHider({
      doc: document,
      posts,
      log,
      notesShown: () => settings.get("paused") !== true && settings.get("ui.hiddenNote") === true,
      onHide: ({ element, reason, detail, signal }) => diagnostics.decide({ post: postIdOf(element).id, rule: reason, signal: signal ?? detail, layer: "page" })
    });
    diagnostics.add("Settings kept for", () => settings.perAccount ? "This Facebook account" : "Everyone on this browser (signed out)");
    diagnostics.add("Settings kept in", () => storage.kind === "gm" ? "Your userscript manager" : "Facebook's page, which clears them");
    const actions = createActions();
    const unavailable = /* @__PURE__ */ new Set();
    let panel = null;
    const waiting = [];
    const toast = (message, options) => panel ? panel.toast(message, options) : waiting.push([message, options]);
    if (!net) {
      log.warn("Your userscript manager is running HushFacebook Web as a content script, so features that need the page are off. Diagnostics has the details.");
    }
    if (net) keepOutOfStorageReport({ win: pageWindow, log, diagnostics });
    if (storage.kind !== "gm") {
      log.warn(UNKEPT_SETTINGS);
      toast(UNKEPT_SETTINGS, { tone: "error" });
    }
    for (const feature of features) {
      if (feature.needsPage && !net) {
        unavailable.add(feature.id);
        continue;
      }
      if (!feature.setup) continue;
      try {
        feature.setup({
          win: pageWindow,
          doc: document,
          net,
          diagnostics,
          actions: actions.for(feature.id),
          storage,
          router,
          posts,
          hider,
          log,
          toast,
          openSettings: (section2) => whenBodyReady(() => panel?.open(section2)),
          // A feature that stops working after setup says so, the same as one that couldn't start.
          markUnavailable: () => {
            unavailable.add(feature.id);
            panel?.refresh();
          },
          settings,
          enabled: () => settings.enabled(feature.id),
          option: (key) => settings.get(`${feature.id}.${key}`)
        });
      } catch (error) {
        unavailable.add(feature.id);
        log.error(`${feature.title} couldn't start`, error);
      }
    }
    mountFeatureStyles({ features, settings, log, base: [{ id: "hidden posts", css: (get) => hideCss({ notes: get("ui.hiddenNote") === true }) }] });
    const tasks = createDailyTasks({ storage, log });
    const mirror = pageMirror(globalThis);
    scheduleStorageCheck({ tasks, storage, mirror, log, toast, diagnostics });
    setTimeout(() => whenMirrorReady(mirror, () => tasks.runDue()), 8e3);
    whenBodyReady(() => {
      panel = mountPanel({ settings, features, log, hider, diagnostics, actions, unavailable, environment: { version, ...managerInfo() } });
      for (const [message, options] of waiting.splice(0)) panel.toast(message, options);
      const other = document.documentElement.getAttribute(DUPLICATE);
      if (other) log.warn(`A second copy of HushFacebook Web (v${other}) is installed. Turn one off in your userscript manager.`);
    });
    registerMenuCommand("HushFacebook Web settings", () => whenBodyReady(() => panel?.open()));
    log.info(`v${version} started (${pageAccess} mode)`);
  }
  var RUNNING_KEY = /* @__PURE__ */ Symbol.for("hushfacebook-web.running");
  var running = pageWindow[RUNNING_KEY] ?? document.documentElement?.getAttribute(RUNNING);
  if (running) {
    whenRootReady(() => document.documentElement.setAttribute(DUPLICATE, version));
    console.warn(`[HushFacebook Web] v${version} didn't start because v${running} is already running.`);
  } else {
    pageWindow[RUNNING_KEY] = version;
    whenRootReady(() => document.documentElement.setAttribute(RUNNING, version));
    boot();
  }
})();
/*! HushFacebook Web: the page-side ad check below follows FB Feed Filter 0.1.0.17
 * (core.js AD_LABEL_KINDS, groupGlyphRecords, candidateGlyphStrings, decodeExactAdLabel,
 * matchesAdDisclosureUrl, isFacebookGroupStoryHref; content.js HEADER_EXCLUSIONS,
 * isHeaderGeometry, glyphRecordsFor, hasScrambledLabelStructure, labelledReferenceLabel,
 * referencedSvgLabel, hasGroupOrigin, hiddenByAncestors).
 *
 * MIT License
 *
 * Copyright (c) 2026 Facebook Feed Filter Companion contributors
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
 * to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
 * FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
