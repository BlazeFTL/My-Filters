// ==UserScript==
// @name         InterCelestial/Pahe Ad Spoof
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Spoofs performance/fetch APIs to bypass ad blockers on intercelestial.com and pahe.plus
// @author       BlazeFTL
// @match        *://intercelestial.com/*
// @match        *://*.intercelestial.com/*
// @match        *://pahe.plus/*
// @match        *://*.pahe.plus/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const W = window;
    const H = /pagead2\.googlesyndication|securepubads\.doubleclick|googletagservices|amazon-adsystem|googleadservices/i;
    const C = "https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js";
    const P = W.performance;
    const nF = W.fetch.bind(W);
    const nN = P.getEntriesByName.bind(P);
    const O = W.Object;
    const h = O.prototype.hasOwnProperty;

    // Spoof getEntriesByName
    P.getEntriesByName = function(n) {
        let r = [];
        try {
            r = nN(n) || [];
        } catch (_) {}

        if (r.length) {
            return r.map(e => {
                const t = e.transferSize | 0;
                const b = e.encodedBodySize | 0;
                const d = e.decodedBodySize | 0;

                // Fake sizes for small/zero responses to look like successful loads
                if ((t | b | d) === 0 && e.responseEnd > 0 || d > 0 && d < 2e4) {
                    return { ...e, transferSize: 96e3, encodedBodySize: 96e3, decodedBodySize: 96e3 };
                }
                return e;
            });
        }

        // Fabricate entry if no data exists but URL matches ad patterns
        if (/gpt\.js|googletagservices|doubleclick|pagead2|amazon-adsystem|googlesyndication|googleadservices/i.test(n)) {
            return [{
                name: n,
                entryType: "resource",
                startTime: 0,
                duration: 12,
                initiatorType: "script",
                transferSize: 96e3,
                encodedBodySize: 96e3,
                decodedBodySize: 96e3,
                responseEnd: 12,
                fetchStart: 0,
                responseStart: 10
            }];
        }

        return r;
    };

    // Spoof hasOwnProperty for Response objects
    O.prototype.hasOwnProperty = function(k) {
        try {
            if (this instanceof W.Response && /^(url|status|body|type|ok)$/.test(k)) return false;
        } catch (_) {}
        return h.call(this, k);
    };

    // Spoof Response.type getter
    const g = O.getOwnPropertyDescriptor(W.Response.prototype, "type")?.get;
    if (g) {
        O.defineProperty(W.Response.prototype, "type", {
            get: function() {
                try {
                    const r = g.call(this);
                    return /^(default|basic|cors)$/.test(r) ? "opaque" : r;
                } catch (_) {
                    return "opaque";
                }
            },
            configurable: true
        });
    }

    // Intercept Fetch requests to ad servers
    W.fetch = function(i, o) {
        const u = typeof i === "string" ? i : i?.url || "";
        if (H.test(u)) {
            // Redirect ad requests to jQuery CDN or return empty success
            return nF(C, { mode: "no-cors", cache: "no-store", credentials: "omit" }).catch(() => new W.Response(null, { status: 200 }));
        }
        return nF(i, o);
    };
})();