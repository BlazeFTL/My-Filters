// ==UserScript==
// @name         GitHub: Morphe Repos to Dev Branch
// @namespace    http://tampermonkey.net/
// @version      2.2
// @description  Forces MorpheApp repos (manager, patches, patcher) to always open the 'dev' branch.
// @author       BlazeFTL
// @match        https://github.com/MorpheApp/morphe-manager*
// @match        https://github.com/MorpheApp/morphe-patches*
// @match        https://github.com/MorpheApp/morphe-patcher*
// @icon         https://avatars.githubusercontent.com/u/139938337?v=4&size=64
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    // List of repositories to force-redirect to the 'dev' branch
    const REPOS = [
        'https://github.com/MorpheApp/morphe-manager',
        'https://github.com/MorpheApp/morphe-patches',
        'https://github.com/MorpheApp/morphe-patcher'
    ];

    function devUrlFor(url) {
        for (const repo of REPOS) {
            // 1. Redirect repository root to /tree/dev
            if (url === repo || url === repo + '/') {
                return repo + '/tree/dev';
            }

            // 2. Redirect 'main' or 'master' branches to 'dev'
            if (url.startsWith(repo + '/')) {
                if (/\/(tree|blob)\/(main|master)([/?#].*)?$/.test(url)) {
                    return url.replace(/\/(tree|blob)\/(main|master)/, '/$1/dev');
                }
            }
        }
        return null;
    }

    function checkAndRedirect() {
        const target = devUrlFor(location.href);
        if (target) location.replace(target);
    }

    // --- 1. Hard page loads ---
    checkAndRedirect();

    // --- 2. Rewrite links *before* GitHub's SPA router reads them ---
    document.addEventListener('click', function (e) {
        const el = e.target instanceof Element ? e.target.closest('a') : null;
        if (!el || !el.href) return;
        const target = devUrlFor(el.href);
        if (target) el.href = target;
    }, true);

    // --- 3. Catch programmatic soft navigations ---
    ['pushState', 'replaceState'].forEach(function (m) {
        const orig = history[m];
        history[m] = function () {
            const r = orig.apply(this, arguments);
            setTimeout(checkAndRedirect, 0);
            return r;
        };
    });
    window.addEventListener('popstate', checkAndRedirect);
    document.addEventListener('turbo:load', checkAndRedirect);
})();