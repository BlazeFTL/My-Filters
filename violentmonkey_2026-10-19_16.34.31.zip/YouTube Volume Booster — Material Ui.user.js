// ==UserScript==
// @name         YouTube Volume Booster — Material Ui
// @namespace    https://github.com/BlazeFTL
// @description  Custom volume slider for YouTube videos with a beautiful Material Design Light UI
// @version      1.8
// @author       BlazeFTL
// @match        *://*.youtube.com/*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_registerMenuCommand
// @grant        GM_addStyle
// @icon         https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @license      MIT
// @downloadURL https://update.greasyfork.org/scripts/582520/YouTube%20Volume%20Booster%20%E2%80%94%20Material%20Ui.user.js
// @updateURL https://update.greasyfork.org/scripts/582520/YouTube%20Volume%20Booster%20%E2%80%94%20Material%20Ui.meta.js
// ==/UserScript==

(function() {
    'use strict';

    // ─── Trusted Types (YouTube enforces require-trusted-types-for 'script') ───
    let ttPolicy = null;
    if (window.trustedTypes && trustedTypes.createPolicy) {
        try {
            ttPolicy = trustedTypes.createPolicy('boostMaterialPolicy', {
                createHTML: (s) => s
            });
        } catch (e) {
            ttPolicy = null;
        }
    }
    function setHTML(el, html) {
        if (ttPolicy) {
            el.innerHTML = ttPolicy.createHTML(html);
        } else {
            try {
                el.innerHTML = html;
            } catch (e) {
                el.textContent = '';
                const tpl = document.createElement('template');
                try { tpl.innerHTML = html; } catch (e2) { return; }
                el.appendChild(tpl.content.cloneNode(true));
            }
        }
    }

    // ─── Persist audio state across SPA navigation ───
    const STATE = window.__ytVolumeBoosterState || (window.__ytVolumeBoosterState = {
        audioContext: null,
        gainNode: null,
        videoSource: null,
        injected: false,
        isBoostEnabled: true,
        lastBoostValue: 100,
        userHasAdjusted: false
    });

    // Defensive: ensure new properties exist if old state object is reused
    if (typeof STATE.isBoostEnabled !== 'boolean') STATE.isBoostEnabled = true;
    if (typeof STATE.lastBoostValue !== 'number') STATE.lastBoostValue = 100;
    if (typeof STATE.userHasAdjusted !== 'boolean') STATE.userHasAdjusted = false;

    let { audioContext, gainNode, videoSource } = STATE;

    // ─── Configuration ───
    let showButtonSetting = GM_getValue("showBoostButton", true);
    let rememberVolumeSetting = GM_getValue("rememberVolume", false);

    // ─── Menu Commands ───
    GM_registerMenuCommand(`Toggle Boost Button (${showButtonSetting ? 'Visible' : 'Hidden'})`, () => {
        GM_setValue("showBoostButton", !showButtonSetting);
        location.reload();
    });

    GM_registerMenuCommand(`Remember Volume (${rememberVolumeSetting ? 'Enabled' : 'Disabled'})`, () => {
        GM_setValue("rememberVolume", !rememberVolumeSetting);
        location.reload();
    });

    // ─── Material Design Tokens ───
    const MD = {
        primary: '#6750A4',
        primaryContainer: '#EADDFF',
        onPrimaryContainer: '#21005D',
        surface: '#FFFBFE',
        surfaceVariant: '#E7E0EC',
        onSurface: '#1C1B1F',
        onSurfaceVariant: '#49454F',
        outline: '#79747E',
        outlineVariant: '#CAC4D0',
        shadow: '0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)',
        shadowElevated: '0 4px 6px rgba(0,0,0,0.07), 0 4px 12px rgba(0,0,0,0.15)',
        radius: '12px',
        radiusSmall: '8px',
        radiusPill: '9999px',
        font: 'Roboto, "YouTube Sans", "Segoe UI", system-ui, sans-serif',
        transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)'
    };

    // ─── Icons (SVG) ───
    const ICONS = {
        boost: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>`,
        volume: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>`,
        close: `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`
    };

    // ─── Audio Engine ───
    function calculateVolume(position, sliderMax) {
        const pos = parseFloat(position) || 0;
        const max = parseFloat(sliderMax) || 1400;
        return ((pos / max) * 1400).toFixed(1);
    }

    function initAudio(videoPlayer) {
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            gainNode = audioContext.createGain();
            gainNode.gain.value = 1.0;
            gainNode.connect(audioContext.destination);
            STATE.audioContext = audioContext;
            STATE.gainNode = gainNode;
        }
        if (audioContext.state === 'suspended') {
            audioContext.resume();
        }
        if (!videoPlayer.dataset.audioHooked) {
            try {
                videoSource = audioContext.createMediaElementSource(videoPlayer);
                videoSource.connect(gainNode);
                videoPlayer.dataset.audioHooked = 'true';
                STATE.videoSource = videoSource;
            } catch (e) {
                console.error("[Volume Booster] Audio init error:", e);
            }
        }
    }

    function setGain(value) {
        if (!gainNode || !audioContext) return;
        const now = audioContext.currentTime;
        const gain = parseFloat(value);
        if (!isFinite(gain)) return;
        gainNode.gain.setValueAtTime(gain, now);
    }

    // ─── Inject Material Styles via GM_addStyle (bypasses CSP) ───
    function injectStyles() {
        if (STATE.injected) return;
        GM_addStyle(`
            .boost-material-btn {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                height: 32px;
                padding: 0 14px;
                margin: 0 6px;
                background: ${MD.surface};
                color: ${MD.onSurface};
                border: 1px solid ${MD.outlineVariant};
                border-radius: ${MD.radiusPill};
                font-family: ${MD.font};
                font-size: 13px;
                font-weight: 500;
                letter-spacing: 0.025em;
                cursor: pointer;
                vertical-align: middle;
                box-shadow: ${MD.shadow};
                transition: ${MD.transition};
                user-select: none;
                position: relative;
                overflow: hidden;
            }
            .boost-material-btn:hover {
                background: ${MD.surfaceVariant};
                box-shadow: ${MD.shadowElevated};
                transform: translateY(-1px);
            }
            .boost-material-btn:active {
                transform: translateY(0) scale(0.98);
            }
            .boost-material-btn svg { flex-shrink: 0; }

            .boost-material-panel {
                display: none;
                align-items: center;
                gap: 10px;
                height: 32px;
                padding: 0 14px;
                margin: 0 6px;
                background: ${MD.surface};
                border: 1px solid ${MD.outlineVariant};
                border-radius: ${MD.radius};
                box-shadow: ${MD.shadowElevated};
                vertical-align: middle;
                animation: boostFadeIn 0.2s ease;
            }
            .boost-material-panel.visible { display: inline-flex; }

            @keyframes boostFadeIn {
                from { opacity: 0; transform: translateY(4px) scale(0.96); }
                to   { opacity: 1; transform: translateY(0) scale(1); }
            }

            .boost-material-badge {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                min-width: 44px;
                height: 24px;
                padding: 0 8px;
                background: #E3F2FD;
                color: #0D47A1;
                border-radius: ${MD.radiusSmall};
                font-family: ${MD.font};
                font-size: 12px;
                font-weight: 600;
                letter-spacing: 0.02em;
                white-space: nowrap;
            }

            .boost-material-slider {
                -webkit-appearance: none;
                appearance: none;
                width: 160px;
                height: 4px;
                background: ${MD.outlineVariant};
                border-radius: 2px;
                outline: none;
                cursor: pointer;
                vertical-align: middle;
            }
            .boost-material-slider::-webkit-slider-thumb {
                -webkit-appearance: none;
                appearance: none;
                width: 16px;
                height: 16px;
                background: ${MD.onSurfaceVariant};
                border-radius: 50%;
                border: 2px solid ${MD.surface};
                box-shadow: 0 1px 4px rgba(0,0,0,0.25);
                transition: ${MD.transition};
                cursor: grab;
            }
            .boost-material-slider::-webkit-slider-thumb:hover {
                transform: scale(1.25);
                box-shadow: 0 2px 8px rgba(0,0,0,0.25);
            }
            .boost-material-slider::-webkit-slider-thumb:active {
                cursor: grabbing;
                transform: scale(1.15);
            }
            .boost-material-slider::-moz-range-thumb {
                width: 16px;
                height: 16px;
                background: ${MD.onSurfaceVariant};
                border-radius: 50%;
                border: 2px solid ${MD.surface};
                box-shadow: 0 1px 4px rgba(0,0,0,0.25);
                cursor: pointer;
            }

            .boost-material-close {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 22px;
                height: 22px;
                padding: 0;
                background: transparent;
                color: ${MD.onSurfaceVariant};
                border: none;
                border-radius: 50%;
                cursor: pointer;
                transition: ${MD.transition};
            }
            .boost-material-close:hover {
                background: ${MD.surfaceVariant};
                color: ${MD.onSurface};
            }

            .boost-material-tooltip {
                position: absolute;
                bottom: calc(100% + 8px);
                left: 50%;
                transform: translateX(-50%) translateY(4px);
                padding: 4px 10px;
                background: ${MD.onSurface};
                color: ${MD.surface};
                font-family: ${MD.font};
                font-size: 11px;
                font-weight: 500;
                border-radius: 6px;
                white-space: nowrap;
                opacity: 0;
                pointer-events: none;
                transition: ${MD.transition};
                z-index: 9999;
            }
            .boost-material-btn:hover .boost-material-tooltip {
                opacity: 1;
                transform: translateX(-50%) translateY(0);
            }
        `);
        STATE.injected = true;
    }

    // ─── Main Injection ───
    function injectControls() {
        const controls = document.querySelector('.ytp-left-controls');
        const videoPlayer = document.querySelector('.video-stream');

        if (!controls || !videoPlayer || document.getElementById('boostMaterialContainer')) return;
        injectStyles();

        const container = document.createElement('div');
        container.id = 'boostMaterialContainer';
        container.style.display = 'inline-block';
        container.style.verticalAlign = 'middle';

        const boostBtn = document.createElement('button');
        boostBtn.id = 'boostMaterialBtn';
        boostBtn.className = 'boost-material-btn';
        setHTML(boostBtn, `${ICONS.boost}<span>Boost</span>`);
        if (!showButtonSetting) boostBtn.style.display = 'none';

        const tooltip = document.createElement('span');
        tooltip.className = 'boost-material-tooltip';
        tooltip.textContent = 'Toggle Volume Boost';
        boostBtn.appendChild(tooltip);

        const panel = document.createElement('div');
        panel.id = 'boostMaterialPanel';
        panel.className = 'boost-material-panel';

        const volIcon = document.createElement('span');
        setHTML(volIcon, ICONS.volume);
        volIcon.style.color = MD.onSurfaceVariant;
        volIcon.style.display = 'inline-flex';
        volIcon.style.alignItems = 'center';
        volIcon.style.cursor = 'pointer';

        const slider = document.createElement('input');
        slider.type = 'range';
        slider.id = 'boostMaterialSlider';
        slider.className = 'boost-material-slider';
        slider.min = '0';
        slider.max = '1400';
        slider.step = '1';

        const badge = document.createElement('span');
        badge.id = 'boostMaterialBadge';
        badge.className = 'boost-material-badge';
        badge.textContent = '100%';

        const closeBtn = document.createElement('button');
        closeBtn.className = 'boost-material-close';
        setHTML(closeBtn, ICONS.close);
        closeBtn.title = 'Close';

        panel.appendChild(volIcon);
        panel.appendChild(slider);
        panel.appendChild(badge);
        panel.appendChild(closeBtn);

        function updateBadgeColor(volume) {
            const v = parseFloat(volume);
            if (v <= 100) {
                badge.style.background = '#E8F5E9';
                badge.style.color = '#1B5E20';
            } else if (v <= 500) {
                badge.style.background = '#E3F2FD';
                badge.style.color = '#0D47A1';
            } else if (v <= 900) {
                badge.style.background = '#FFF3E0';
                badge.style.color = '#E65100';
            } else {
                badge.style.background = '#FFEBEE';
                badge.style.color = '#B71C1C';
            }
        }

        function applyVolumeState() {
            // Resolve target value from memory
            let targetValue = STATE.lastBoostValue;
            if (rememberVolumeSetting) {
                const saved = GM_getValue("savedVolume", null);
                if (saved !== null && !isNaN(parseFloat(saved))) {
                    targetValue = parseFloat(saved);
                }
            }
            if (isNaN(targetValue) || targetValue < 0) targetValue = 100;

            slider.value = targetValue;
            STATE.lastBoostValue = targetValue;

            // If user has never touched the slider, keep audio completely untouched
            if (!STATE.userHasAdjusted) {
                badge.textContent = '100%';
                updateBadgeColor(100);
                volIcon.style.opacity = '1';
                volIcon.title = 'Click to disable boost';
                return;
            }

            // User has adjusted before — update UI and apply gain if already hooked
            if (STATE.isBoostEnabled) {
                const volume = calculateVolume(targetValue, slider.max);
                badge.textContent = `${Math.round(volume)}%`;
                updateBadgeColor(volume);
                volIcon.style.opacity = '1';
                volIcon.title = 'Click to disable boost';
                if (videoPlayer.dataset.audioHooked) {
                    setGain(parseFloat(volume) / 100);
                }
            } else {
                badge.textContent = 'Off';
                badge.style.background = '#ECEFF1';
                badge.style.color = '#546E7A';
                volIcon.style.opacity = '0.5';
                volIcon.title = 'Click to enable boost';
                if (videoPlayer.dataset.audioHooked) {
                    setGain(1.0);
                }
            }
        }

        slider.addEventListener('input', function() {
            const val = parseFloat(this.value) || 0;
            STATE.lastBoostValue = val;
            STATE.userHasAdjusted = true;
            if (rememberVolumeSetting) {
                GM_setValue("savedVolume", val);
            }
            // Moving the slider always re-enables boost
            STATE.isBoostEnabled = true;
            // Lazy init: only create the Web Audio graph NOW when user actually moves the slider
            initAudio(videoPlayer);
            const volume = calculateVolume(val, this.max);
            const gain = parseFloat(volume) / 100;
            setGain(gain);
            badge.textContent = `${Math.round(volume)}%`;
            updateBadgeColor(volume);
            volIcon.style.opacity = '1';
            volIcon.title = 'Click to disable boost';
        });

        videoPlayer.addEventListener('timeupdate', function() {
            if (videoPlayer.currentTime === 0) {
                // Only auto-init audio if user has previously adjusted in this session
                if (rememberVolumeSetting && STATE.userHasAdjusted) {
                    initAudio(videoPlayer);
                }
                applyVolumeState();
            }
        });

        // ─── Click Boost → Show Slider, do NOT touch audio until user interacts ───
        boostBtn.addEventListener('click', function() {
            // Only init audio if user has previously adjusted (e.g., reopening on a new video)
            if (STATE.userHasAdjusted) {
                initAudio(videoPlayer);
            }
            boostBtn.style.display = 'none';
            panel.classList.add('visible');
            requestAnimationFrame(() => {
                applyVolumeState();
            });
        });

        // ─── Click X → Hide Slider, Show Button ───
        closeBtn.addEventListener('click', function() {
            panel.classList.remove('visible');
            if (showButtonSetting) {
                boostBtn.style.display = '';
            }
        });

        // ─── Click Volume Icon → Toggle Boost On/Off ───
        volIcon.addEventListener('click', function() {
            STATE.isBoostEnabled = !STATE.isBoostEnabled;

            if (!STATE.userHasAdjusted) {
                // Never touched slider — pure visual toggle, no audio graph exists yet
                if (STATE.isBoostEnabled) {
                    const volume = calculateVolume(STATE.lastBoostValue, slider.max);
                    badge.textContent = `${Math.round(volume)}%`;
                    updateBadgeColor(volume);
                    volIcon.style.opacity = '1';
                    volIcon.title = 'Click to disable boost';
                } else {
                    badge.textContent = 'Off';
                    badge.style.background = '#ECEFF1';
                    badge.style.color = '#546E7A';
                    volIcon.style.opacity = '0.5';
                    volIcon.title = 'Click to enable boost';
                }
                return;
            }

            // User has adjusted — apply the gain change
            initAudio(videoPlayer);
            if (STATE.isBoostEnabled) {
                const volume = calculateVolume(STATE.lastBoostValue, slider.max);
                setGain(parseFloat(volume) / 100);
                badge.textContent = `${Math.round(volume)}%`;
                updateBadgeColor(volume);
                volIcon.style.opacity = '1';
                volIcon.title = 'Click to disable boost';
            } else {
                setGain(1.0);
                badge.textContent = 'Off';
                badge.style.background = '#ECEFF1';
                badge.style.color = '#546E7A';
                volIcon.style.opacity = '0.5';
                volIcon.title = 'Click to enable boost';
            }
        });

        container.appendChild(boostBtn);
        container.appendChild(panel);
        controls.appendChild(container);

        applyVolumeState();
    }

    // ─── Observe for controls instead of polling ───
    const observer = new MutationObserver(() => {
        injectControls();
    });

    if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
    } else {
        window.addEventListener('DOMContentLoaded', () => {
            observer.observe(document.body, { childList: true, subtree: true });
        });
    }

    // ─── Reset boost per-video unless user opted into "Remember Volume" ───
    function resetPerVideoBoost() {
        if (rememberVolumeSetting) return;
        STATE.userHasAdjusted = false;
        STATE.isBoostEnabled = true;
        STATE.lastBoostValue = 100;
        if (STATE.gainNode && STATE.audioContext) {
            try {
                STATE.gainNode.gain.setValueAtTime(1.0, STATE.audioContext.currentTime);
            } catch (e) {}
        }
    }
    document.addEventListener('yt-navigate-finish', resetPerVideoBoost);

    document.addEventListener('yt-page-data-updated', injectControls);
    injectControls();
})();