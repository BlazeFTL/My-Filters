// ==UserScript==
// @name         UploaDao.com Auto Click
// @namespace    blazeftl
// @version      1.0
// @match        *://*.uploadao.com/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function waitForElement(selector, root = document) {
        return new Promise(resolve => {
            const found = root.querySelector(selector);
            if (found) return resolve(found);
            const obs = new MutationObserver(() => {
                const el = root.querySelector(selector);
                if (el) {
                    obs.disconnect();
                    resolve(el);
                }
            });
            obs.observe(root, { childList: true, subtree: true, attributes: true });
        });
    }

    function waitForXPath(xpath) {
        return new Promise(resolve => {
            const check = () => document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            const found = check();
            if (found) return resolve(found);
            const obs = new MutationObserver(() => {
                const el = check();
                if (el) {
                    obs.disconnect();
                    resolve(el);
                }
            });
            obs.observe(document.body, { childList: true, subtree: true, attributes: true, characterData: true });
        });
    }

    function clickSel(selector) {
        const el = document.querySelector(selector);
        if (el) el.click();
        return el;
    }

    function captchaSolved(callback) {
        let done = false;
        let intervalId;
        const finish = () => {
            if (done) return;
            done = true;
            clearInterval(intervalId);
            callback();
        };

        waitForXPath('//div[contains(@class,"iconcaptcha-modal__body-title") and normalize-space(text())="Verification complete."] | //*[@id="captcha-result" and normalize-space()="Verified!"]')
            .then(finish);

        const checkCaptcha = () => {
            try {
                const captcha = window.turnstile || window.hcaptcha || window.grecaptcha;
                const response = captcha.getResponse();
                if (response) finish();
            } catch (e) {}
        };

        checkCaptcha();
        intervalId = setInterval(checkCaptcha, 1000);
    }

    function step1() {
        clickSel('#method_free');
    }

    function step2() {
        captchaSolved(() => {
            const poll = setInterval(() => {
                const btn = document.querySelector('#downloadbtn');
                if (!btn) return;
                const secEl = document.querySelector('#seconds');
                const secVal = secEl ? parseInt(secEl.textContent, 10) : 0;
                if (!btn.disabled && secVal <= 1) {
                    clearInterval(poll);
                    btn.click();
                }
            }, 500);
        });
    }

    function step3() {
        clickSel('#direct_link .dl2-download-btn');
    }

    Promise.race([
        waitForElement('#method_free').then(() => 'p1'),
        waitForElement('#downloadbtn').then(() => 'p2'),
        waitForElement('#direct_link .dl2-download-btn').then(() => 'p3')
    ]).then(page => {
        if (page === 'p1') step1();
        else if (page === 'p2') step2();
        else step3();
    });
})();
