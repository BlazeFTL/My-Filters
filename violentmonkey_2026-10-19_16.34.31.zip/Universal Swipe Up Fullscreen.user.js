// ==UserScript==
// @name         Universal Swipe Up Fullscreen
// @namespace    ftl
// @version      1.1
// @description  Swipe up over video to enter fullscreen, swipe up in fullscreen to exit
// @match        *://*/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  let sx = 0, sy = 0, st = 0, vid = null, active = false, cur = null, jitter = 0;

  const fsEl = () => document.fullscreenElement || document.webkitFullscreenElement;

  const findVideo = (x, y) => {
    for (const v of document.querySelectorAll('video')) {
      const r = v.getBoundingClientRect();
      if (
        x >= r.left && x <= r.right &&
        y >= r.top && y <= r.bottom &&
        r.width >= innerWidth * 0.5 && r.height > 100
      ) return v;
    }
    return null;
  };

  const target = v => {
    let el = v;
    const vr = v.getBoundingClientRect();
    while (
      el.parentElement &&
      el.parentElement !== document.body &&
      el.parentElement !== document.documentElement
    ) {
      const r = el.parentElement.getBoundingClientRect();
      if (Math.abs(r.width - vr.width) < 4 && Math.abs(r.height - vr.height) < 4) el = el.parentElement;
      else break;
    }
    return el;
  };

  const wake = i => {
    const fe = fsEl();
    const v = cur && cur.isConnected ? cur : (fe && fe.querySelector && fe.querySelector('video'));
    const el = fe || (v && target(v));
    if (!el) return;
    const r = el.getBoundingClientRect();
    jitter++;
    const x = Math.round(r.left + r.width / 2 + (jitter % 2 ? 3 : -3));
    const y = Math.round(r.top + r.height / 2 + (jitter % 3 ? 2 : -2));
    const o = {
      bubbles: true, cancelable: true, composed: true, view: window,
      clientX: x, clientY: y, screenX: x, screenY: y
    };
    for (const n of v ? [el, v] : [el]) {
      for (const t of ['mouseover', 'mouseenter', 'mousemove']) {
        try { n.dispatchEvent(new MouseEvent(t, o)); } catch (e) {}
      }
      try { n.dispatchEvent(new PointerEvent('pointermove', { ...o, pointerType: 'mouse', isPrimary: true })); } catch (e) {}
    }
    if (i === 1 && v && v.controls) {
      v.controls = false;
      requestAnimationFrame(() => { v.controls = true; });
    }
  };

  const wakeSoon = () => [0, 150, 400, 800].forEach((ms, i) => setTimeout(() => wake(i), ms));

  const enter = async v => {
    cur = v;
    try {
      await target(v).requestFullscreen();
    } catch (e) {
      try {
        await v.requestFullscreen();
      } catch (e2) {
        return;
      }
    }
    if (v.videoWidth >= v.videoHeight) {
      try {
        screen.orientation.lock('landscape').catch(() => {});
      } catch (e) {}
    }
  };

  const exit = () => {
    try {
      document.exitFullscreen().catch(() => {});
    } catch (e) {}
  };

  document.addEventListener('fullscreenchange', () => {
    if (!fsEl()) {
      try {
        screen.orientation.unlock();
      } catch (e) {}
    }
    wakeSoon();
  });

  addEventListener('touchstart', e => {
    active = false;
    vid = null;
    if (e.touches.length !== 1) return;
    const t = e.touches[0];
    sx = t.clientX;
    sy = t.clientY;
    st = Date.now();
    if (fsEl()) {
      active = true;
      return;
    }
    vid = findVideo(sx, sy);
    active = !!vid;
  }, { capture: true, passive: true });

  addEventListener('touchmove', e => {
    if (!active || e.touches.length !== 1) return;
    const t = e.touches[0];
    const dx = t.clientX - sx;
    const dy = t.clientY - sy;
    if (dy < -12 && Math.abs(dx) < Math.abs(dy) * 0.6 && e.cancelable) e.preventDefault();
  }, { capture: true, passive: false });

  addEventListener('touchend', e => {
    if (!active) return;
    active = false;
    const t = e.changedTouches[0];
    const dx = t.clientX - sx;
    const dy = t.clientY - sy;
    if (dy > -70 || Math.abs(dx) > Math.abs(dy) * 0.6 || Date.now() - st > 700) {
      if (dy < -12) wakeSoon();
      return;
    }
    if (fsEl()) exit();
    else if (vid) enter(vid);
  }, { capture: true, passive: true });

  addEventListener('touchcancel', () => {
    active = false;
  }, { capture: true, passive: true });
})();
