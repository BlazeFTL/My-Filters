// ==UserScript==
// @name         Instagram Video Controls
// @name:ru      Instagram Видео Контролы
// @version      5.4
// @description  Adds a proper video player to Instagram: volume, speed, loop, screenshot, fullscreen and mini-player — without touching the sound of preview thumbnails in Explore/profile grids.
// @description:ru Добавляет нормальный плеер к видео в инстаграме: громкость, скорость, повтор участка, скриншот, полноэкранный и мини-режим — не трогая звук превьюшек в сетке Explore/профиля.
// @author       FerNikoMF
// @match        https://www.instagram.com/*
// @license      MIT
// @grant        none
// @run-at       document-end
// @namespace    https://greasyfork.org/users/1384659
// @downloadURL https://update.greasyfork.org/scripts/562988/Instagram%20Video%20Controls.user.js
// @updateURL https://update.greasyfork.org/scripts/562988/Instagram%20Video%20Controls.meta.js
// ==/UserScript==

(function () {
    'use strict';

    // SETTINGS  (v5 key; falls back to v4 for migration)
    const STORAGE_KEY = 'ig_vc_v5';
    const DEFAULTS    = { vol: 0.3, muted: false, speed: 1, shortcuts: true };

    let S = (() => {
        try {
            const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem('ig_vc_v4');
            return Object.assign({}, DEFAULTS, JSON.parse(raw) ?? {});
        } catch { return { ...DEFAULTS }; }
    })();

    const save = () => {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(S)); } catch {}
    };

    // SVG ICONS
    const IC = {
        play:  '<svg viewBox="0 0 20 20"><path d="M6 4l10 6-10 6V4z"/></svg>',
        pause: '<svg viewBox="0 0 20 20"><rect x="4" y="3" width="4" height="14"/><rect x="12" y="3" width="4" height="14"/></svg>',
        volHi: '<svg viewBox="0 0 20 20"><path d="M3 7.5v5h3.33L10 16V4L6.33 7.5H3zm11.5 2.5c0-1.5-.85-2.8-2.1-3.44v6.87C13.65 12.8 14.5 11.5 14.5 10zm2.5 0c0 2.87-1.65 5.36-4 6.6V3.4C15.35 4.64 17 7.13 17 10z"/></svg>',
        volLo: '<svg viewBox="0 0 20 20"><path d="M3 7.5v5h3.33L10 16V4L6.33 7.5H3zm11.5 2.5c0-1.5-.85-2.8-2.1-3.44v6.87C13.65 12.8 14.5 11.5 14.5 10z"/></svg>',
        volOff:'<svg viewBox="0 0 20 20"><path d="M3 7.5v5h3.33L10 16V4L6.33 7.5H3zM15.59 10l2.41-2.41-1.41-1.41L14.17 8.6l-2.41-2.42-1.41 1.41L12.76 10l-2.41 2.41 1.41 1.42 2.41-2.42 2.42 2.42 1.41-1.42L15.59 10z"/></svg>',
        fs:    '<svg viewBox="0 0 20 20"><path d="M3 7V3h4v2H5v2H3zm10-4h4v4h-2V5h-2V3zM3 13h2v2h2v2H3v-4zm12 2h-2v2h4v-4h-2v2z"/></svg>',
        pip:   '<svg viewBox="0 0 20 20"><path d="M16 9h-6v4h6V9zM18 3H2C.9 3 0 3.9 0 5v10c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 12H2V5h16v10z"/></svg>',
        loop:  '<svg viewBox="0 0 20 20"><path d="M10 4V1L6 5l4 4V6c2.76 0 5 2.24 5 5s-2.24 5-5 5-5-2.24-5-5H3c0 3.87 3.13 7 7 7s7-3.13 7-7-3.13-7-7-7z"/></svg>',
        cam:   '<svg viewBox="0 0 20 20"><path d="M7.5 1.5L6 3H3C1.9 3 1 3.9 1 5v10c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-3L12.5 1.5h-5zM10 15c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm0-6.5c-1.38 0-2.5 1.12-2.5 2.5s1.12 2.5 2.5 2.5 2.5-1.12 2.5-2.5-1.12-2.5-2.5-2.5z"/></svg>',
        more:  '<svg viewBox="0 0 20 20"><circle cx="4" cy="10" r="1.8"/><circle cx="10" cy="10" r="1.8"/><circle cx="16" cy="10" r="1.8"/></svg>',
        kbd:   '<svg viewBox="0 0 20 20"><rect x="1" y="4" width="18" height="12" rx="2"/><rect x="3.5" y="6.5" width="2" height="2" fill="#0e0e0e"/><rect x="7" y="6.5" width="2" height="2" fill="#0e0e0e"/><rect x="10.5" y="6.5" width="2" height="2" fill="#0e0e0e"/><rect x="14" y="6.5" width="2" height="2" fill="#0e0e0e"/><rect x="3.5" y="10" width="12.5" height="2" fill="#0e0e0e"/></svg>',
    };

    // GLOBAL CSS
    const CSS = `
.ivc-bar {
    position: fixed;
    display: flex; align-items: center; gap: 4px;
    height: 36px; padding: 0 8px; box-sizing: border-box;
    background: rgba(14,14,14,.88);
    backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,.08); border-radius: 10px;
    box-shadow: 0 2px 12px rgba(0,0,0,.55);
    opacity: 0; pointer-events: none;
    transition: opacity .18s ease;
    z-index: 2147483645; min-width: 120px;
}
.ivc-bar.ivc-show { opacity: 1; pointer-events: auto; }

.ivc-btn {
    all: unset; display: flex; align-items: center; justify-content: center;
    flex-shrink: 0; width: 26px; height: 26px; border-radius: 6px;
    cursor: pointer; color: #fff; opacity: .82;
    transition: background .1s, opacity .1s, transform .1s;
}
.ivc-btn:hover  { background: rgba(255,255,255,.16); opacity: 1; transform: scale(1.08); }
.ivc-btn.on     { color: #4fc3f7; opacity: 1; }
.ivc-btn.on svg { fill: #4fc3f7; }
.ivc-btn svg    { width: 16px; height: 16px; fill: currentColor; display: block; pointer-events: none; }

.ivc-prog-wrap {
    flex: 1; min-width: 0; height: 100%;
    display: flex; align-items: center;
    position: relative; cursor: pointer; padding: 0 2px;
}
input.ivc-range {
    -webkit-appearance: none; appearance: none;
    width: 100%; height: 3px; border-radius: 2px;
    background: rgba(255,255,255,.25);
    outline: none; border: none; cursor: pointer; margin: 0; padding: 0;
}
input.ivc-range::-webkit-slider-thumb {
    -webkit-appearance: none; width: 11px; height: 11px;
    border-radius: 50%; background: #fff;
    box-shadow: 0 1px 4px rgba(0,0,0,.5); cursor: pointer;
}
.ivc-ab-a, .ivc-ab-b {
    position: absolute; top: 50%; transform: translateY(-50%);
    width: 2px; height: 12px; border-radius: 1px;
    pointer-events: none; display: none;
}
.ivc-ab-a { background: #4fc3f7; }
.ivc-ab-b { background: #f06292; }

.ivc-time {
    flex-shrink: 0; font: 11px/1 monospace; color: rgba(255,255,255,.75);
    white-space: nowrap; user-select: none; pointer-events: none;
}
.ivc-bar.ivc-narrow .ivc-time { display: none; }

.ivc-vol-group { display: flex; align-items: center; flex-shrink: 0; height: 100%; }
.ivc-vol-slider {
    width: 0; opacity: 0; overflow: hidden;
    transition: width .2s, opacity .2s, margin-left .2s;
    display: flex; align-items: center;
}
.ivc-vol-group:hover .ivc-vol-slider,
.ivc-vol-slider.open { width: 52px; opacity: 1; margin-left: 4px; }
input.ivc-vol-range {
    -webkit-appearance: none; appearance: none;
    width: 52px; height: 3px; border-radius: 2px;
    outline: none; border: none; cursor: pointer; margin: 0; padding: 0;
}
input.ivc-vol-range::-webkit-slider-thumb {
    -webkit-appearance: none; width: 10px; height: 10px;
    border-radius: 50%; background: #fff; cursor: pointer;
}

.ivc-speed {
    all: unset; flex-shrink: 0;
    font: bold 12px/1 sans-serif; color: rgba(255,255,255,.8);
    cursor: pointer; padding: 0 3px; height: 100%;
    display: flex; align-items: center; transition: color .1s;
    -webkit-appearance: none; -moz-appearance: none; appearance: none;
}
.ivc-speed:hover { color: #fff; }
.ivc-speed option { background: #1a1a1a; color: #fff; font-size: 13px; }

.ivc-menu {
    position: fixed;
    background: rgba(14,14,14,.96); border: 1px solid rgba(255,255,255,.1);
    border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,.7);
    padding: 6px; display: none; flex-direction: column; gap: 2px;
    z-index: 2147483647; min-width: 152px;
}
.ivc-menu.open { display: flex; }
.ivc-menu-row {
    display: flex; align-items: center; gap: 8px;
    padding: 6px 8px; border-radius: 7px; cursor: pointer;
    color: rgba(255,255,255,.82); font: 13px/1 sans-serif;
    transition: background .1s; white-space: nowrap;
}
.ivc-menu-row:hover  { background: rgba(255,255,255,.1); color: #fff; }
.ivc-menu-row svg    { width: 16px; height: 16px; fill: currentColor; flex-shrink: 0; }
.ivc-menu-row.on     { color: #4fc3f7; }
.ivc-menu-row.on svg { fill: #4fc3f7; }
.ivc-menu-divider    { height: 1px; background: rgba(255,255,255,.08); margin: 3px 0; }
.ivc-keys { padding: 6px 8px 2px; color: rgba(255,255,255,.4); font: 11px/1.9 monospace; }
.ivc-keys b { color: rgba(255,255,255,.75); }

.ivc-osd {
    position: fixed; transform: translate(-50%,-50%);
    background: rgba(0,0,0,.72); color: #fff;
    font: bold 17px/1 sans-serif;
    padding: 9px 18px; border-radius: 9px;
    pointer-events: none; z-index: 2147483647;
    opacity: 0; transition: opacity .15s; white-space: nowrap;
}
.ivc-osd.show { opacity: 1; }
`;

    const injectCSS = () => {
        if (document.getElementById('ivc-css')) return;
        const s = document.createElement('style');
        s.id = 'ivc-css'; s.textContent = CSS;
        (document.head ?? document.documentElement).appendChild(s);
    };

    // UTILITIES
    const fmt = s => (!s || !isFinite(s))
        ? '0:00'
        : `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

    const throttle = (fn, ms) => {
        let last = 0;
        return (...args) => { const now = Date.now(); if (now - last >= ms) { last = now; fn(...args); } };
    };

    const fillRange = (el) => {
        const pct = (parseFloat(el.value) / (parseFloat(el.max) || 1)) * 100;
        el.style.background =
            `linear-gradient(to right,#fff ${pct}%,rgba(255,255,255,.22) ${pct}%)`;
    };

    // Multiple mounted videos share the same mousemove tick, so cache
    // elementFromPoint() per coordinate to avoid redundant layout work.
    let _eapX = null, _eapY = null, _eapEl = null;
    const elementAtPoint = (x, y) => {
        if (x === _eapX && y === _eapY) return _eapEl;
        _eapX = x; _eapY = y;
        _eapEl = document.elementFromPoint(x, y);
        return _eapEl;
    };

    // VIDEO REGISTRY
    const mounted     = new WeakSet();
    const speedSelEls = [];
    const kbdToggleEls = [];

    const updKbdToggle = () => {
        for (let i = kbdToggleEls.length - 1; i >= 0; i--) {
            const el = kbdToggleEls[i];
            if (!document.contains(el)) { kbdToggleEls.splice(i, 1); continue; }
            el.classList.toggle('on', S.shortcuts);
            const label = el.querySelector('span');
            if (label) label.textContent = S.shortcuts ? 'Keyboard Shortcuts: On' : 'Keyboard Shortcuts: Off';
        }
    };

    const applyState = v => {
        if (Math.abs(v.volume - S.vol) > .01 || v.muted !== S.muted) {
            v.volume = S.vol; v.muted = S.muted;
        }
        if (Math.abs(v.playbackRate - S.speed) > .01) v.playbackRate = S.speed;
    };

    // Grid/hover preview thumbnails (Explore, profile grid, hashtag, saved) are
    // wrapped in a post/reel link and were never "opened" by the user — leave
    // them to Instagram's own native silent-autoplay-on-hover behavior instead
    // of forcing our volume/mute state onto them (that's what was causing
    // multiple thumbnails to play sound over each other on hover).
    // Anything actually opened in a dialog/lightbox always counts as real,
    // even if some stray link happens to wrap it.
    const isGridThumb = v => {
        if (v.closest('[role="dialog"]')) return false;
        return !!v.closest('a[href*="/p/"],a[href*="/reel/"],a[href*="/tv/"]');
    };

    const syncAll = () => {
        document.querySelectorAll('video').forEach(v => { if (!isGridThumb(v)) applyState(v); });
        for (let i = speedSelEls.length - 1; i >= 0; i--) {
            if (!document.contains(speedSelEls[i])) { speedSelEls.splice(i, 1); continue; }
            speedSelEls[i].value = S.speed;
        }
    };
    const syncThrottle = throttle(syncAll, 50);

    const SPEEDS = [0.25, 0.5, 1, 1.25, 1.5, 2, 2.5, 3, 4];
    let activeVid = null;

    // MOUNT  –  one control overlay per <video>
    function mount(video) {
        if (mounted.has(video)) return;
        if (isGridThumb(video)) return; // let Instagram run its own hover-preview
        mounted.add(video);
        applyState(video);
        video.removeAttribute('controls');

        let abPhase = 0, abA = 0, abB = 0;

        // Build DOM
        const bar = document.createElement('div');
        bar.className = 'ivc-bar';
        bar.innerHTML =
            `<button class="ivc-btn" data-r="play">${IC.play}</button>` +
            `<div class="ivc-prog-wrap">` +
                `<input class="ivc-range" data-r="prog" type="range" min="0" max="100" step="0.1" value="0">` +
                `<div class="ivc-ab-a" data-r="mA"></div>` +
                `<div class="ivc-ab-b" data-r="mB"></div>` +
            `</div>` +
            `<span class="ivc-time" data-r="time">0:00</span>` +
            `<div class="ivc-vol-group">` +
                `<button class="ivc-btn" data-r="mute">${IC.volHi}</button>` +
                `<div class="ivc-vol-slider" data-r="volWrap">` +
                    `<input class="ivc-vol-range" data-r="vol" type="range" min="0" max="1" step="0.01" value="${S.vol}">` +
                `</div>` +
            `</div>` +
            `<select class="ivc-speed" data-r="speed">` +
                SPEEDS.map(x => `<option value="${x}"${x === S.speed ? ' selected' : ''}>${x}x</option>`).join('') +
            `</select>` +
            `<button class="ivc-btn" data-r="more">${IC.more}</button>`;

        const menu = document.createElement('div');
        menu.className = 'ivc-menu';
        menu.innerHTML =
            `<div class="ivc-menu-row" data-r="m-loop">${IC.loop}<span>A-B Loop <small style="opacity:.5">[L]</small></span></div>` +
            `<div class="ivc-menu-row" data-r="m-shot">${IC.cam}<span>Screenshot <small style="opacity:.5">[S]</small></span></div>` +
            `<div class="ivc-menu-divider"></div>` +
            `<div class="ivc-menu-row" data-r="m-pip">${IC.pip}<span>Picture in Picture <small style="opacity:.5">[P]</small></span></div>` +
            `<div class="ivc-menu-row" data-r="m-fs">${IC.fs}<span>Fullscreen <small style="opacity:.5">[F]</small></span></div>` +
            `<div class="ivc-menu-divider"></div>` +
            `<div class="ivc-menu-row" data-r="m-kbd">${IC.kbd}<span>Keyboard Shortcuts</span></div>` +
            `<div class="ivc-menu-divider"></div>` +
            `<div class="ivc-keys">` +
                `<b>Space/K</b> play/pause &nbsp; <b>← →</b> ±5s<br>` +
                `<b>↑ ↓</b> vol &nbsp; <b>, .</b> speed &nbsp; <b>M</b> mute<br>` +
                `<b>L</b> loop &nbsp; <b>S</b> shot &nbsp; <b>F</b> fullscreen` +
            `</div>`;

        const osd = document.createElement('div');
        osd.className = 'ivc-osd';

        document.body.append(bar, menu, osd);

        // Refs
        const r = {};
        [bar, menu].forEach(root =>
            root.querySelectorAll('[data-r]').forEach(el => { r[el.dataset.r] = el; })
        );
        speedSelEls.push(r.speed);
        kbdToggleEls.push(r['m-kbd']);
        fillRange(r.vol);
        updKbdToggle();

        let layoutRaf = null;
        const BAR_H = 36, BAR_GAP = 8;

        const computeBarTop = rect =>
            Math.max(4, Math.min(window.innerHeight - BAR_H - 8, rect.bottom - BAR_H - BAR_GAP));

        const layout = () => {
            layoutRaf = null;
            const rect = video.getBoundingClientRect();
            const inView = (
                rect.width > 10 && rect.height > 10 &&
                rect.bottom > 0 && rect.top  < window.innerHeight &&
                rect.right  > 0 && rect.left < window.innerWidth
            );

            if (!inView) { bar.style.display = 'none'; menu.classList.remove('open'); return; }
            bar.style.display = '';

            const top  = computeBarTop(rect);
            const left = Math.max(4, Math.min(window.innerWidth  - 124, rect.left + 8));
            const w    = Math.max(120, Math.min(window.innerWidth - left - 4, rect.width - 16));

            bar.style.top   = top  + 'px';
            bar.style.left  = left + 'px';
            bar.style.width = w    + 'px';

            osd.style.top  = (rect.top  + rect.height / 2) + 'px';
            osd.style.left = (rect.left + rect.width  / 2) + 'px';

            bar.classList.toggle('ivc-narrow', rect.width < 280);

            if (menu.classList.contains('open')) positionMenu(rect, top);
        };

        const positionMenu = (rect, barTop) => {
            menu.style.bottom = (window.innerHeight - barTop + 4) + 'px';
            menu.style.top    = 'auto';
            menu.style.right  = Math.max(0, window.innerWidth - rect.right + 8) + 'px';
            menu.style.left   = 'auto';
        };

        const scheduleLayout = () => {
            if (layoutRaf) return;
            layoutRaf = requestAnimationFrame(layout);
        };

        window.addEventListener('scroll', scheduleLayout, { passive: true, capture: true });
        window.addEventListener('resize', scheduleLayout, { passive: true });

        const ro = new ResizeObserver(scheduleLayout);
        ro.observe(video);

        // Hover / show-hide
        let hideT   = null;
        let overVid = false;
        let overBar = false;

        const show = () => {
            scheduleLayout();
            bar.classList.add('ivc-show');
            clearTimeout(hideT);
            if (!video.paused) hideT = setTimeout(hide, 2500);
        };
        const hide = () => {
            if (overVid || overBar || menu.classList.contains('open')) return;
            bar.classList.remove('ivc-show');
        };

        // Global cursor checkpoint that bypasses Instagram overlays
        const checkPointer = throttle((e) => {
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;

            const rect = video.getBoundingClientRect();
            const geomMatch = (
                rect.width > 0 && rect.height > 0 &&
                clientX >= rect.left && clientX <= rect.right &&
                clientY >= rect.top  && clientY <= rect.bottom
            );

            // Geometry alone isn't enough: on pages with virtualized/stacked
            // reels (e.g. Explore grid still mounted behind an open reel
            // dialog), several unrelated videos can share overlapping screen
            // coordinates. Confirm THIS video's own card/dialog is actually
            // what's rendered on top at that exact pixel before claiming it.
            let inVidBounds = false;
            if (geomMatch) {
                const topEl = elementAtPoint(clientX, clientY);
                const myScope = video.closest('article,[role="dialog"],section') ?? video;
                inVidBounds = !!topEl && (
                    myScope === topEl || myScope.contains(topEl) ||
                    bar.contains(topEl) || menu.contains(topEl)
                );
            }

            if (inVidBounds) {
                if (!overVid) {
                    overVid = true;
                    activeVid = video;
                }
                show();
            } else {
                if (overVid) {
                    overVid = false;
                    clearTimeout(hideT);
                    hideT = setTimeout(hide, 300);
                }
            }
        }, 150);

        document.addEventListener('mousemove', checkPointer, { passive: true });
        document.addEventListener('touchstart', checkPointer, { passive: true });

        bar.addEventListener('mouseenter',  () => { overBar = true;  clearTimeout(hideT); });
        bar.addEventListener('mouseleave',  () => { overBar = false; if (!overVid) hideT = setTimeout(hide, 300); });
        menu.addEventListener('mouseenter', () => { overBar = true;  clearTimeout(hideT); });
        menu.addEventListener('mouseleave', () => { overBar = false; if (!overVid) hideT = setTimeout(hide, 300); });

        const stopProp = e => e.stopPropagation();
        ['click', 'dblclick', 'mousedown', 'touchstart', 'pointerdown'].forEach(ev => {
            bar.addEventListener(ev,  stopProp, { passive: true });
            menu.addEventListener(ev, stopProp, { passive: true });
        });

        // OSD flash
        let osdT;
        const flash = msg => {
            osd.textContent = msg;
            osd.classList.add('show');
            clearTimeout(osdT);
            osdT = setTimeout(() => osd.classList.remove('show'), 850);
        };

        // Play / Pause
        const updPlay = () => { r.play.innerHTML = video.paused ? IC.play : IC.pause; };

        r.play.addEventListener('click', () => {
            if (video.paused) { video.play(); } else { video.pause(); }
        });
        video.addEventListener('play',  () => { updPlay(); applyState(video); show(); });
        video.addEventListener('pause', () => { updPlay(); clearTimeout(hideT); bar.classList.add('ivc-show'); });

        // Progress
        let dragging = false;
        r.prog.addEventListener('pointerdown', () => { dragging = true; });
        document.addEventListener('pointerup',  () => { dragging = false; });

        const updMarkers = () => {
            if (!video.duration) return;
            r.mA.style.display = abPhase >= 1 ? 'block' : 'none';
            r.mB.style.display = abPhase === 2 ? 'block' : 'none';
            if (abPhase >= 1) r.mA.style.left = (abA / video.duration * 100) + '%';
            if (abPhase === 2) r.mB.style.left = (abB / video.duration * 100) + '%';
        };

        video.addEventListener('timeupdate', () => {
            if (!video.duration || dragging) return;
            const pct = (video.currentTime / video.duration) * 100;
            r.prog.value = pct;
            fillRange(r.prog);
            r.time.textContent = `${fmt(video.currentTime)} / ${fmt(video.duration)}`;
            if (abPhase === 2 && video.currentTime >= abB) video.currentTime = abA;
        });

        r.prog.addEventListener('input', () => {
            fillRange(r.prog);
            if (video.duration) {
                video.currentTime = (parseFloat(r.prog.value) / 100) * video.duration;
                r.time.textContent = `${fmt(video.currentTime)} / ${fmt(video.duration)}`;
            }
        });

        // Volume
        const updVol = () => {
            const off = video.muted || video.volume === 0;
            r.mute.innerHTML = off ? IC.volOff : (video.volume > .5 ? IC.volHi : IC.volLo);
            r.vol.value = off ? 0 : video.volume;
            fillRange(r.vol);
        };

        r.vol.addEventListener('pointerdown', () => r.volWrap.classList.add('open'));
        document.addEventListener('pointerup',  () => r.volWrap.classList.remove('open'));

        r.vol.addEventListener('input', () => {
            S.vol   = parseFloat(r.vol.value);
            S.muted = S.vol === 0;
            fillRange(r.vol);
            syncThrottle();
        });
        r.vol.addEventListener('change', save);

        r.mute.addEventListener('click', () => {
            S.muted = !S.muted;
            if (!S.muted && S.vol === 0) S.vol = 0.5;
            save(); syncAll();
        });
        video.addEventListener('volumechange', updVol);

        // Speed
        const setSpeed = val => {
            S.speed = val; r.speed.value = val; save(); syncAll(); flash(`⚡ ${val}x`);
        };
        r.speed.addEventListener('change', () => setSpeed(parseFloat(r.speed.value)));

        // Overflow menu
        r.more.addEventListener('click', () => {
            menu.classList.toggle('open');
            if (menu.classList.contains('open')) {
                show();
                const rect = video.getBoundingClientRect();
                positionMenu(rect, computeBarTop(rect));
            }
        });

        // Keyboard shortcuts on/off
        r['m-kbd'].addEventListener('click', () => {
            S.shortcuts = !S.shortcuts;
            save();
            updKbdToggle();
            flash(S.shortcuts ? '⌨️ Shortcuts ON' : '⌨️ Shortcuts OFF');
        });

        document.addEventListener('click', e => {
            if (!bar.contains(e.target) && !menu.contains(e.target))
                menu.classList.remove('open');
        }, true);

        // A-B loop
        const cycleAB = () => {
            if (abPhase === 0) {
                abA = video.currentTime; abPhase = 1;
                r['m-loop'].classList.add('on');
                flash(`🔁 A = ${fmt(abA)}`);
            } else if (abPhase === 1) {
                abB = Math.max(video.currentTime, abA + 0.5); abPhase = 2;
                flash(`🔁 → ${fmt(abB)}`);
            } else {
                abPhase = 0; abA = 0; abB = 0;
                r['m-loop'].classList.remove('on');
                flash('🔁 off');
            }
            updMarkers();
        };
        r['m-loop'].addEventListener('click', cycleAB);

        // Screenshot
        const shoot = () => {
            try {
                const c = document.createElement('canvas');
                c.width  = video.videoWidth  || video.clientWidth;
                c.height = video.videoHeight || video.clientHeight;
                c.getContext('2d').drawImage(video, 0, 0);
                const a = Object.assign(document.createElement('a'), {
                    download: `ig-${Date.now()}.png`,
                    href: c.toDataURL(),
                });
                document.body.appendChild(a); a.click(); a.remove();
                flash('📷 saved');
            } catch { flash('📷 CORS ✗'); }
        };
        r['m-shot'].addEventListener('click', shoot);

        // Fullscreen
        const doFS = () => {
            if (document.fullscreenElement) {
                document.exitFullscreen?.().catch(() => {});
            } else {
                const target = video.closest('article,[role="dialog"],section') ?? video;
                (target.requestFullscreen ?? video.webkitEnterFullscreen)?.call(target);
            }
        };
        r['m-fs'].addEventListener('click', doFS);

        // PiP
        if (document.pictureInPictureEnabled) {
            r['m-pip'].addEventListener('click', async () => {
                try {
                    document.pictureInPictureElement
                        ? await document.exitPictureInPicture()
                        : await video.requestPictureInPicture();
                } catch (e) { console.warn('[ivc] PiP:', e.message); }
            });
        } else {
            r['m-pip'].style.display = 'none';
        }

        // Cleanup when video leaves DOM
        const io = new IntersectionObserver(([entry]) => {
            if (!entry.isIntersecting) {
                bar.style.display = 'none';
                menu.classList.remove('open');
            } else {
                bar.style.display = '';
                scheduleLayout();
            }
        }, { threshold: 0.01 });
        io.observe(video);

        const domObs = new MutationObserver(() => {
            if (document.contains(video)) return;
            bar.remove(); menu.remove(); osd.remove();
            io.disconnect(); domObs.disconnect(); ro.disconnect();
            window.removeEventListener('scroll', scheduleLayout, { capture: true });
            window.removeEventListener('resize', scheduleLayout);
            document.removeEventListener('mousemove', checkPointer);
            document.removeEventListener('touchstart', checkPointer);
            const si = speedSelEls.indexOf(r.speed);
            if (si !== -1) speedSelEls.splice(si, 1);
            const ki = kbdToggleEls.indexOf(r['m-kbd']);
            if (ki !== -1) kbdToggleEls.splice(ki, 1);
            if (activeVid === video) activeVid = null;
        });
        domObs.observe(document.body, { childList: true, subtree: true });

        // Keyboard handler
        video._ivcKey = e => {
            if (!S.shortcuts) return;
            if (['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName)) return;

            const take = () => { e.preventDefault(); e.stopPropagation(); };

            switch (e.key) {
                case ' ': case 'k': case 'K':
                    take();
                    if (video.paused) { video.play(); flash('▶'); }
                    else              { video.pause(); flash('⏸'); }
                    break;
                case 'ArrowRight':
                    take();
                    video.currentTime = Math.min(video.currentTime + 5, video.duration || 0);
                    flash('+5s'); break;
                case 'ArrowLeft':
                    take();
                    video.currentTime = Math.max(video.currentTime - 5, 0);
                    flash('-5s'); break;
                case 'ArrowUp':
                    take();
                    S.vol = Math.min(1, +(S.vol + .1).toFixed(2)); S.muted = false;
                    save(); syncAll(); flash(`🔊 ${Math.round(S.vol * 100)}%`); break;
                case 'ArrowDown':
                    take();
                    S.vol = Math.max(0, +(S.vol - .1).toFixed(2)); S.muted = S.vol === 0;
                    save(); syncAll(); flash(`🔉 ${Math.round(S.vol * 100)}%`); break;
                case 'm': case 'M':
                    e.preventDefault();
                    S.muted = !S.muted; if (!S.muted && S.vol === 0) S.vol = .5;
                    save(); syncAll(); flash(S.muted ? '🔇' : '🔊'); break;
                case ',': case '<': {
                    e.preventDefault();
                    const i = SPEEDS.indexOf(S.speed);
                    if (i > 0) setSpeed(SPEEDS[i - 1]); break;
                }
                case '.': case '>': {
                    e.preventDefault();
                    const i = SPEEDS.indexOf(S.speed);
                    if (i < SPEEDS.length - 1) setSpeed(SPEEDS[i + 1]); break;
                }
                case 'l': case 'L': e.preventDefault(); cycleAB(); break;
                case 's': case 'S': e.preventDefault(); shoot();   break;
                case 'f': case 'F': e.preventDefault(); doFS();    break;
                case 'p': case 'P': e.preventDefault(); r['m-pip']?.click(); break;
            }
        };

        // Initial render
        updVol(); updPlay(); layout();
    }

    // GLOBAL KEYBOARD DELEGATION
    document.addEventListener('keydown', e => {
        const v = activeVid ?? document.querySelector('video');
        v?._ivcKey?.(e);
    }, true);

    // BOOTSTRAP
    injectCSS();

    const scanVideos = throttle(() => {
        document.querySelectorAll('video').forEach(v => {
            if (isGridThumb(v)) return;
            applyState(v); mount(v);
        });
    }, 200);

    new MutationObserver(scanVideos).observe(document.body, { childList: true, subtree: true });

    setInterval(() => {
        document.querySelectorAll('video').forEach(v => {
            if (isGridThumb(v)) return;
            if (!mounted.has(v)) { mount(v); return; }
            if (Math.abs(v.volume - S.vol) > .05 || v.muted !== S.muted) {
                v.volume = S.vol; v.muted = S.muted;
            }
            if (Math.abs(v.playbackRate - S.speed) > .05) v.playbackRate = S.speed;
        });
    }, 1000);

})();