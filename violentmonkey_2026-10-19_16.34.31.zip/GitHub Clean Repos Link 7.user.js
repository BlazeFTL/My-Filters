// ==UserScript==
// @name         GitHub Clean Repos Link 7
// @namespace    https://github.com/BlazeFTL
// @description  Intercepts the click on the repositories link to remove the type=source parameter dynamically.
// @version      1.6
// @author       BlazeFTL
// @match        *://github.com/*
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    window.addEventListener('click', function(event) {
        // Find the closest link matching the repositories tab
        const repoLink = event.target.closest('a[href*="tab=repositories"]');

        if (repoLink) {
            const currentHref = repoLink.getAttribute('href');
            if (currentHref && currentHref.includes('&type=source')) {
                const cleanHref = currentHref.split('&type=source')[0];
                repoLink.setAttribute('href', cleanHref);
            }
        }
    }, true); // 'true' enables the capturing phase to run before GitHub's routing
})();
