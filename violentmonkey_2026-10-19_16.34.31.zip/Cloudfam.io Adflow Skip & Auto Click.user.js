// ==UserScript==
// @name         Cloudfam.io Adflow Skip & Auto Click
// @namespace    https://github.com/BlazeFTL
// @description  Direct jump from adflow redirection pages (premiumonboard, landing, predownload) to download.php?step=2 and auto-click download
// @version      2.0
// @author       BlazeFTL
// @match        https://cloudfam.io/adflow/premiumonboard.php?slug=*
// @match        https://cloudfam.io/adflow/landing.php?slug=*
// @match        https://cloudfam.io/adflow/predownload.php?slug=*
// @match        https://cloudfam.io/download.php?*step=2*
// @match        https://cloudfam.io/redirection0.php?slug=*
// @match        https://cloudfam.io/preload.php?slug=*
// @license      MIT
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const url = window.location.href;
    const urlParams = new URLSearchParams(window.location.search);
    const slug = urlParams.get('slug');
    const token = urlParams.get('token');

    // --- THE JUMP: From intermediate adflow/redirection pages directly to step=2 ---
    const isIntermediatePage = url.includes('premiumonboard.php') ||
                               url.includes('landing.php') ||
                               url.includes('predownload.php') ||
                               url.includes('redirection0.php') ||
                               url.includes('preload.php');

    if (isIntermediatePage && slug && token) {
        const finalUrl = `https://cloudfam.io/download.php?slug=${slug}&step=2&token=${token}`;
        window.location.replace(finalUrl);
        return;
    }

    // --- THE CLICK: On the final download page ---
    if (url.includes('step=2')) {
        const tryClick = () => {
            const btn = document.querySelector('#cf-dl-btn');
            if (btn) {
                btn.click();
                console.log('Jump successful! Download button clicked.');
                clearInterval(clicker);
            }
        };

        // Rapid check every 50ms since we want this fast
        const clicker = setInterval(tryClick, 50);

        // Stop checking after 8 seconds to prevent infinite loops
        setTimeout(() => clearInterval(clicker), 8000);
    }
})();