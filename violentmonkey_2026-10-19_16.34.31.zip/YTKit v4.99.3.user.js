// ==UserScript==
// @name         YTKit v4.99.3
// @namespace    https://github.com/SysAdminDoc/Astra-Deck
// @version      4.99.3
// @description  The Astra Deck YouTube extension as a userscript, with the same features, settings panel and themes. Loads its three YTKit libraries through @require, and downloads use the optional Astra Downloader companion app.
// @author       Matthew Parker
// @homepageURL  https://github.com/SysAdminDoc/Astra-Deck
// @supportURL   https://github.com/SysAdminDoc/Astra-Deck/issues
// @updateURL    https://raw.githubusercontent.com/SysAdminDoc/Astra-Deck/main/YTKit.user.js
// @downloadURL  https://raw.githubusercontent.com/SysAdminDoc/Astra-Deck/main/YTKit.user.js
// @license      MIT
// @icon         https://raw.githubusercontent.com/SysAdminDoc/Astra-Deck/main/extension/icons/128.png
// @match        https://youtube.com/*
// @match        https://*.youtube.com/*
// @match        https://*.youtube-nocookie.com/*
// @match        https://youtu.be/*
// @match        https://*.youtube.com/live_chat*
// @exclude      https://m.youtube.com/*
// @exclude      https://music.youtube.com/*
// @exclude      https://studio.youtube.com/*
// @run-at       document-start
// @inject-into  content
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @grant        GM_listValues
// @grant        GM_addValueChangeListener
// @grant        GM_addStyle
// @grant        GM_addElement
// @grant        GM_xmlhttpRequest
// @grant        GM_download
// @grant        GM_openInTab
// @grant        GM_registerMenuCommand
// @grant        GM_setClipboard
// @grant        GM_getResourceText
// @grant        GM_cookie
// @connect      youtube.com
// @connect      youtube-nocookie.com
// @connect      youtu.be
// @connect      i.ytimg.com
// @connect      sponsor.ajay.app
// @connect      sponsorblock.kavin.rocks
// @connect      returnyoutubedislikeapi.com
// @connect      www.reddit.com
// @connect      old.reddit.com
// @connect      raw.githubusercontent.com
// @connect      127.0.0.1
// @connect      api.openai.com
// @connect      api.anthropic.com
// @connect      generativelanguage.googleapis.com
// @connect      *
// @require      https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/YTKit-core.user.js#sha256=41a900714576bd68c38fc843252bd7961f67ec37b802476beb678b4a204e47f9
// @require      https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/YTKit-features.user.js#sha256=0d99c9d3530b772b1771daad5650ed9806d3d85b542fbe2e44e88d000be730dd
// @require      https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/YTKit-app.user.js#sha256=f30c0fda96a4e06a8cb8498bfe2d69c44a6ce29b859cff72a4999b47789ac9b7
// @resource     astra-locale-ar https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/ar/messages.json#sha256=f5cb52ecc116fdd953725e33b00674c593565c9e8a4fbbb89e84eef2b3620e0f
// @resource     astra-locale-de https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/de/messages.json#sha256=e60aa4df1fc2926b1d4bc82ec59941332b7f00e3ca40fe31e5116fce318a9733
// @resource     astra-locale-es https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/es/messages.json#sha256=6c7eec9ceed93415cb70ae978d494697ae8960eb17bc607a6fd8078d0b8633d6
// @resource     astra-locale-fr https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/fr/messages.json#sha256=487ca5285bd10698a50bf023d6a1c5cb56b1f269c642a42a87dd51264b68cc01
// @resource     astra-locale-it https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/it/messages.json#sha256=75685b5ceebd82093f0101a44677c0cdab1a312550c6e1cd4b000a6a8e095aad
// @resource     astra-locale-ja https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/ja/messages.json#sha256=b00aab5e6b3e05274a162d32e462491cd4d6b23d22e5bb4790b8b20497af7f5f
// @resource     astra-locale-ko https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/ko/messages.json#sha256=237e9e62bab1d111231212e4ad8cab5657fdf3e1516e80a2224f848d3ab1c4ba
// @resource     astra-locale-pt_BR https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/pt_BR/messages.json#sha256=5a39c5da2609634dd80be7c66c210537d70ae65d5232c5a1e8f913055ad51fe5
// @resource     astra-locale-ru https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/ru/messages.json#sha256=b1ee1af35037307f59923de0a8349ee487f176972e5ee093143d5bc867f4bd4d
// @resource     astra-locale-zh_CN https://cdn.jsdelivr.net/gh/SysAdminDoc/Astra-Deck@a62871ab929db70f40fa8a2c84e76c9189166a92/extension/_locales/zh_CN/messages.json#sha256=7b1137723ca1a45bbec534abcbda5354c239435abd84581d08ab9b50f036e887
// ==/UserScript==

// Generated by sync-userscript.js. Do not edit: the code that runs is the
// extension's own, packed into the @require libraries above, and the host
// below (userscript/host.js) stands in for the chrome.* APIs with GM_* grants.
//
// localhost is deliberately not in @connect. The companion is always reached
// by literal IP, and Firefox still resolves localhost through DNS, so a
// hostile resolver could rebind it to an internal address and use the grant
// to probe the LAN. The extension refuses it for the same reason.

const ASTRA_DECK_BUILD = {
	"version": "4.99.3",
	"runtimeId": "astra-deck-userscript",
	"menuLabel": "Open Astra Deck settings",
	"credentialMenuLabel": "AI provider key",
	"diagnosticsMenuLabel": "Copy Astra Deck diagnostics",
	"defaultLocale": "en",
	"locales": [
		"ar",
		"de",
		"en",
		"es",
		"fr",
		"it",
		"ja",
		"ko",
		"pt_BR",
		"ru",
		"zh_CN"
	],
	"localeResourcePrefix": "astra-locale-",
	"manifest": {
		"manifest_version": 3,
		"name": "__MSG_extName__",
		"description": "__MSG_extDescription__",
		"default_locale": "en",
		"homepage_url": "https://github.com/SysAdminDoc/Astra-Deck",
		"permissions": [
			"storage",
			"alarms",
			"unlimitedStorage",
			"declarativeNetRequest",
			"cookies",
			"downloads",
			"nativeMessaging",
			"sidePanel"
		],
		"host_permissions": [
			"https://*.youtube.com/*",
			"https://*.youtube-nocookie.com/*",
			"https://youtu.be/*",
			"https://i.ytimg.com/*",
			"https://sponsor.ajay.app/*",
			"https://sponsorblock.kavin.rocks/*",
			"https://returnyoutubedislikeapi.com/*",
			"https://www.reddit.com/*",
			"https://old.reddit.com/*",
			"https://raw.githubusercontent.com/*",
			"http://127.0.0.1:11434/*",
			"http://127.0.0.1:9751/*",
			"http://127.0.0.1:9761/*",
			"http://127.0.0.1:9771/*",
			"http://127.0.0.1:9781/*",
			"http://127.0.0.1:9791/*",
			"http://127.0.0.1:9851/*"
		],
		"optional_host_permissions": [
			"https://api.openai.com/*",
			"https://api.anthropic.com/*",
			"https://generativelanguage.googleapis.com/*",
			"https://*/*"
		],
		"minimum_chrome_version": "120",
		"version": "4.99.3",
		"x-ytkit-build-profile": "github-full",
		"x-ytkit-host": "userscript"
	},
	"permissions": [
		"storage",
		"alarms",
		"unlimitedStorage",
		"declarativeNetRequest",
		"cookies",
		"downloads",
		"nativeMessaging",
		"sidePanel"
	],
	"hostPermissions": [
		"https://*.youtube.com/*",
		"https://*.youtube-nocookie.com/*",
		"https://youtu.be/*",
		"https://i.ytimg.com/*",
		"https://sponsor.ajay.app/*",
		"https://sponsorblock.kavin.rocks/*",
		"https://returnyoutubedislikeapi.com/*",
		"https://www.reddit.com/*",
		"https://old.reddit.com/*",
		"https://raw.githubusercontent.com/*",
		"http://127.0.0.1:11434/*",
		"http://127.0.0.1:9751/*",
		"http://127.0.0.1:9761/*",
		"http://127.0.0.1:9771/*",
		"http://127.0.0.1:9781/*",
		"http://127.0.0.1:9791/*",
		"http://127.0.0.1:9851/*"
	],
	"optionalHostPermissions": [
		"https://api.openai.com/*",
		"https://api.anthropic.com/*",
		"https://generativelanguage.googleapis.com/*",
		"https://*/*"
	],
	"featureSettings": {
		"features/subtitles/index.js": [
			"autoSubtitles",
			"autoSubtitlesWhenMuted",
			"dualLanguageSubtitles",
			"subtitleDownload",
			"subtitlesOnRewind"
		],
		"features/video-filters/index.js": [
			"videoVisualFilters",
			"photosensitiveFlashProtection"
		],
		"features/blue-light-filter/index.js": [
			"blueLightFilter"
		],
		"features/theme-css/index.js": [
			"colorTheme",
			"oledTheme",
			"themeAccentColor"
		],
		"features/chat-style-comments/index.js": [
			"chatStyleComments"
		],
		"features/sticky-video-styles/index.js": [
			"stickyVideo"
		],
		"features/sticky-video-autoscroll/index.js": [
			"stickyVideo"
		],
		"features/sticky-video-chat/index.js": [
			"stickyVideo"
		],
		"features/sticky-video-header/index.js": [
			"stickyVideo"
		],
		"features/sticky-video/index.js": [
			"stickyVideo"
		],
		"features/sticky-chat/index.js": [
			"stickyChat"
		],
		"features/video-hider/index.js": [
			"hideVideosFromHome",
			"hideVideosHideAutoDubbed",
			"hideVideosHideLive",
			"hideVideosHideMixes",
			"hideVideosHideMovies",
			"hideVideosHidePlaylists",
			"hideVideosHideUpcoming"
		],
		"features/element-zapper/index.js": [
			"elementZapper"
		],
		"features/video-notes/index.js": [
			"videoNotes"
		],
		"features/digital-wellbeing/index.js": [
			"digitalWellbeing"
		],
		"features/search-hygiene/index.js": [
			"searchHideRelatedSearches",
			"searchHideUnrelatedShelves",
			"searchHideWatchedRecommended"
		],
		"features/search-while-watching/index.js": [
			"searchWhileWatching"
		],
		"features/video-insights/index.js": [
			"videoInsights"
		],
		"features/return-dislike/index.js": [
			"returnDislike",
			"returnDislikeOnCards"
		],
		"features/sponsorblock/index.js": [
			"sponsorBlock"
		],
		"features/dearrow/index.js": [
			"deArrow",
			"deArrowChannelOverridesPanel",
			"dearrowPeekButton"
		]
	},
	"mainWorldModule": "@main-world",
	"requiredModules": [
		"core/bridge-token.js",
		"core/browser-api.js",
		"core/injection-guard.js",
		"core/bridge-channel.js",
		"core/env.js",
		"core/storage.js",
		"core/styles.js",
		"core/settings-visual-system.js",
		"core/registry.js",
		"core/runtime-flags.js",
		"core/local-ai.js",
		"core/capability-probe.js",
		"core/selector-packs/appShell.js",
		"core/selector-packs/nav.js",
		"core/selector-packs/search.js",
		"core/selector-packs/searchResults.js",
		"core/selector-packs/subscriptions.js",
		"core/selector-packs/leftNav.js",
		"core/selector-packs/feed.js",
		"core/selector-packs/feedCard.js",
		"core/selector-packs/feedExperimentChips.js",
		"core/selector-packs/feedPlayables.js",
		"core/selector-packs/feedPrompt.js",
		"core/selector-packs/feedSponsored.js",
		"core/selector-packs/thumbnail.js",
		"core/selector-packs/shortsShelf.js",
		"core/selector-packs/watch.js",
		"core/selector-packs/relatedSidebar.js",
		"core/selector-packs/player.js",
		"core/selector-packs/mainVideo.js",
		"core/selector-packs/playerChrome.js",
		"core/selector-packs/playerSettings.js",
		"core/selector-packs/sidebar.js",
		"core/selector-packs/modals.js",
		"core/selector-packs/comments.js",
		"core/selector-packs/commentComposer.js",
		"core/selector-packs/engagementPanels.js",
		"core/selector-packs/transcriptPanel.js",
		"core/selector-packs/settingsOverlay.js",
		"core/selector-packs/profile.js",
		"core/selector-packs/notifications.js",
		"core/selector-packs/media.js",
		"core/selector-packs/liveChatFrame.js",
		"core/selector-packs/liveChat.js",
		"core/selector-packs/liveChatPlaceholder.js",
		"core/selectors.js",
		"core/trusted-html.js",
		"core/diagnostic-log.js",
		"core/external-api-health.js",
		"core/regex-safety.js",
		"core/predicate-sandbox.js",
		"core/video-type.js",
		"core/playability.js",
		"core/transcript-service.js",
		"core/transcript-index.js",
		"core/ai-summary-artifacts.js",
		"core/remote-list-scope.js",
		"core/persisted-domains.js",
		"core/settings-import-transaction.js",
		"core/storage-manager.js",
		"core/icons.js",
		"core/url.js",
		"core/text-metrics.js",
		"core/date-time.js",
		"core/failure-copy.js",
		"core/page.js",
		"core/navigation.js",
		"core/player.js",
		"core/settings-schema.js",
		"core/feature-lifecycle.js",
		"core/policy-profile.js",
		"core/settings-controller.js",
		"core/selector-health.js",
		"core/feature-health.js",
		"core/feature-disable-feed.js",
		"core/feature-bisect.js",
		"core/chapters.js",
		"core/csv.js",
		"core/dialog-guard.js",
		"core/zero-ad-dom.js",
		"core/element-zapper.js",
		"core/hide-attribution.js",
		"core/heatmap.js",
		"core/youtube-thumbnails.js",
		"core/feed-prefilter.js",
		"core/credential-vault.js",
		"core/feature-schedule.js",
		"core/companion-ports.js",
		"core/cookie-handoff.js",
		"core/data-flow.js",
		"core/toast.js",
		"core/toast-dom.js",
		"core/lifecycle-route-bridge.js",
		"features/download-ui/index.js",
		"ytkit.js",
		"background.js",
		"core/settings-sync.js",
		"features/live-chat/index.js",
		"live-chat.js",
		"@main-world"
	],
	"optionalModules": [
		"core/early-switches.js",
		"features/element-zapper/index.js",
		"features/subtitles/index.js",
		"features/video-filters/index.js",
		"features/blue-light-filter/index.js",
		"features/theme-css/index.js",
		"features/wave-8-css/index.js",
		"features/home-subs-css/index.js",
		"features/chat-style-comments/index.js",
		"features/comment-author-block/index.js",
		"features/sticky-video-styles/index.js",
		"features/sticky-video-autoscroll/index.js",
		"features/sticky-video-chat/index.js",
		"features/sticky-video-header/index.js",
		"features/sticky-video/index.js",
		"features/sticky-chat/index.js",
		"features/classic-watch-layout/index.js",
		"features/hide-auto-chapters/index.js",
		"features/video-hider/index.js",
		"features/video-notes/index.js",
		"features/replay-chat-density/index.js",
		"features/subscription-view/index.js",
		"features/subscription-groups/index.js",
		"features/digital-wellbeing/index.js",
		"features/settings-panel/index.js",
		"features/player-dock/index.js",
		"features/search-hygiene/index.js",
		"features/search-while-watching/index.js",
		"features/video-insights/index.js",
		"features/return-dislike/index.js",
		"features/sponsorblock/index.js",
		"features/dearrow/index.js"
	],
	"modules": {
		"bridgeToken": "core/bridge-token.js",
		"bridgeChannel": "core/bridge-channel.js",
		"earlyStart": [
			"core/early-switches.js"
		],
		"foundation": [
			"core/browser-api.js",
			"core/injection-guard.js",
			"core/bridge-channel.js",
			"core/env.js",
			"core/storage.js",
			"core/styles.js",
			"core/settings-visual-system.js",
			"core/registry.js",
			"core/runtime-flags.js",
			"core/local-ai.js",
			"core/capability-probe.js",
			"core/selector-packs/appShell.js",
			"core/selector-packs/nav.js",
			"core/selector-packs/search.js",
			"core/selector-packs/searchResults.js",
			"core/selector-packs/subscriptions.js",
			"core/selector-packs/leftNav.js",
			"core/selector-packs/feed.js",
			"core/selector-packs/feedCard.js",
			"core/selector-packs/feedExperimentChips.js",
			"core/selector-packs/feedPlayables.js",
			"core/selector-packs/feedPrompt.js",
			"core/selector-packs/feedSponsored.js",
			"core/selector-packs/thumbnail.js",
			"core/selector-packs/shortsShelf.js",
			"core/selector-packs/watch.js",
			"core/selector-packs/relatedSidebar.js",
			"core/selector-packs/player.js",
			"core/selector-packs/mainVideo.js",
			"core/selector-packs/playerChrome.js",
			"core/selector-packs/playerSettings.js",
			"core/selector-packs/sidebar.js",
			"core/selector-packs/modals.js",
			"core/selector-packs/comments.js",
			"core/selector-packs/commentComposer.js",
			"core/selector-packs/engagementPanels.js",
			"core/selector-packs/transcriptPanel.js",
			"core/selector-packs/settingsOverlay.js",
			"core/selector-packs/profile.js",
			"core/selector-packs/notifications.js",
			"core/selector-packs/media.js",
			"core/selector-packs/liveChatFrame.js",
			"core/selector-packs/liveChat.js",
			"core/selector-packs/liveChatPlaceholder.js",
			"core/selectors.js",
			"core/trusted-html.js",
			"core/diagnostic-log.js",
			"core/external-api-health.js",
			"core/regex-safety.js",
			"core/predicate-sandbox.js",
			"core/video-type.js",
			"core/playability.js",
			"core/transcript-service.js",
			"core/transcript-index.js",
			"core/ai-summary-artifacts.js",
			"core/remote-list-scope.js",
			"core/persisted-domains.js",
			"core/settings-import-transaction.js",
			"core/storage-manager.js",
			"core/icons.js",
			"core/url.js",
			"core/text-metrics.js",
			"core/date-time.js",
			"core/failure-copy.js",
			"core/page.js",
			"core/navigation.js",
			"core/player.js",
			"core/settings-schema.js",
			"core/feature-lifecycle.js",
			"core/policy-profile.js",
			"core/settings-controller.js",
			"core/selector-health.js",
			"core/feature-health.js",
			"core/feature-disable-feed.js",
			"core/feature-bisect.js",
			"core/chapters.js",
			"core/csv.js",
			"core/dialog-guard.js",
			"core/zero-ad-dom.js",
			"core/element-zapper.js",
			"core/hide-attribution.js",
			"core/heatmap.js",
			"core/youtube-thumbnails.js",
			"core/feed-prefilter.js",
			"core/credential-vault.js",
			"core/feature-schedule.js",
			"core/companion-ports.js",
			"core/cookie-handoff.js",
			"core/data-flow.js",
			"core/toast.js",
			"core/toast-dom.js",
			"core/lifecycle-route-bridge.js",
			"features/download-ui/index.js"
		],
		"features": [
			"features/element-zapper/index.js",
			"features/subtitles/index.js",
			"features/video-filters/index.js",
			"features/blue-light-filter/index.js",
			"features/theme-css/index.js",
			"features/wave-8-css/index.js",
			"features/home-subs-css/index.js",
			"features/chat-style-comments/index.js",
			"features/comment-author-block/index.js",
			"features/sticky-video-styles/index.js",
			"features/sticky-video-autoscroll/index.js",
			"features/sticky-video-chat/index.js",
			"features/sticky-video-header/index.js",
			"features/sticky-video/index.js",
			"features/sticky-chat/index.js",
			"features/classic-watch-layout/index.js",
			"features/hide-auto-chapters/index.js",
			"features/video-hider/index.js",
			"features/video-notes/index.js",
			"features/replay-chat-density/index.js",
			"features/subscription-view/index.js",
			"features/subscription-groups/index.js",
			"features/digital-wellbeing/index.js",
			"features/settings-panel/index.js",
			"features/player-dock/index.js",
			"features/search-hygiene/index.js",
			"features/search-while-watching/index.js",
			"features/video-insights/index.js",
			"features/return-dislike/index.js",
			"features/sponsorblock/index.js",
			"features/dearrow/index.js"
		],
		"app": "ytkit.js",
		"background": "background.js",
		"backgroundCore": [
			"core/companion-ports.js",
			"core/cookie-handoff.js",
			"core/remote-list-scope.js",
			"core/settings-schema.js",
			"core/persisted-domains.js",
			"core/policy-profile.js",
			"core/settings-sync.js",
			"core/settings-controller.js",
			"core/credential-vault.js"
		],
		"liveChat": [
			"core/browser-api.js",
			"core/env.js",
			"core/styles.js",
			"core/settings-schema.js",
			"core/policy-profile.js",
			"features/live-chat/index.js",
			"live-chat.js"
		],
		"mainWorld": [
			"core/bridge-channel.js",
			"core/injection-guard.js",
			"core/resource-unlock.js",
			"core/player.js",
			"core/audio-track.js",
			"core/feed-prefilter.js",
			"core/classic-watch-layout.js",
			"core/auto-chapters.js",
			"ytkit-main.js"
		]
	},
	"css": {
		"early": "/* Astra Deck - Early CSS injection (document_start)\n   Prevents FOUC for CSS-based features before ytkit.js loads at document_idle.\n   Rules are scoped to body classes that ytkit.js applies when features are enabled,\n   so disabled features don't incorrectly hide elements. */\n\n/* Zero-ad baseline — unconditional by design. The extension's static DNR\n   rules stop separable requests before they leave the browser; this persistent\n   document_start layer collapses known YouTube ad shells and any SPA\n   reinsertion without waiting for the document_idle runtime. Keep this list\n   narrow and selector-backed: media delivery hosts are intentionally absent. */\n#masthead-ad,\n#player-ads,\nytd-in-feed-ad-layout-renderer,\nytd-ad-slot-renderer,\nytd-rich-item-renderer:has(> #content > ytd-ad-slot-renderer),\nytd-page-top-ad-layout-renderer,\nytd-promoted-video-renderer,\nytd-display-ad-renderer,\nytd-promoted-sparkles-web-renderer,\nytm-promoted-sparkles-web-renderer,\nytd-ad-feedback-renderer,\nytd-action-companion-ad-renderer,\nytd-companion-slot-renderer,\nytd-player-legacy-desktop-watch-ads-renderer,\n[data-ytkit-zero-ad-semantic],\n.video-ads,\n.ytp-ad-module,\n.ytp-ad-overlay-container,\n.ytp-ad-player-overlay,\n.ytp-ad-text-overlay,\n.ytp-ad-skip-button-container {\n    display: none !important;\n    visibility: hidden !important;\n    pointer-events: none !important;\n    block-size: 0 !important;\n    min-block-size: 0 !important;\n    max-block-size: 0 !important;\n    margin: 0 !important;\n    padding: 0 !important;\n    overflow: hidden !important;\n}\n\n/* hideEndCards */\nbody.ytkit-hideEndCards .ytp-ce-element { display: none !important; }\n\n/* hideInfoCards */\nbody.ytkit-hideInfoCards .ytp-cards-button,\nbody.ytkit-hideInfoCards .ytp-cards-teaser { display: none !important; }\n\n/* hideNotificationBadge */\nbody.ytkit-hideNotificationBadge ytd-notification-topbar-button-renderer .notification-count,\nbody.ytkit-hideNotificationBadge .ytd-notification-topbar-button-renderer[aria-label*=\"notification\"] .yt-spec-icon-badge-shape__badge {\n    display: none !important;\n}\n\n/* hideAutoplayToggle */\nbody.ytkit-hideAutoplayToggle .ytp-autonav-toggle-button-container { display: none !important; }\n\n/* creatorCommentHighlight — logical inset so the accent sits on the reading\n   edge in RTL locales, matching the settings layer's logical-property pass. */\nbody.ytkit-creatorCommentHighlight ytd-comment-view-model.ytd-comment-view-model[creator] #body {\n    border-inline-start: 3px solid var(--yt-spec-call-to-action, #3ea6ff);\n}\n\n/* keyMoments highlight — the white-alpha rule was invisible on light theme. */\nbody.ytkit-keyMoments ytd-macro-markers-list-item-renderer.ytd-structured-description-content-renderer {\n    border-inline-start: 3px solid var(--yt-spec-10-percent-layer, rgba(255, 255, 255, 0.12));\n    padding-inline-start: 8px;\n    margin-bottom: 4px;\n}\n\nhtml:not([dark]) body.ytkit-keyMoments ytd-macro-markers-list-item-renderer.ytd-structured-description-content-renderer {\n    border-inline-start-color: rgba(0, 0, 0, 0.14);\n}\n\n/* removeAllShorts — prevent Shorts shelf flash on home/subscriptions */\nbody.ytkit-removeAllShorts ytd-rich-shelf-renderer[is-shorts],\nbody.ytkit-removeAllShorts ytd-reel-shelf-renderer,\nbody.ytkit-removeAllShorts [is-shorts].ytd-rich-grid-row,\nbody.ytkit-removeAllShorts ytd-browse grid-shelf-view-model:has(ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2):not(:has(yt-lockup-view-model)) {\n    display: none !important;\n}\n\n/* hideRelatedVideos — prevent related panel flash on watch pages */\nbody.ytkit-hideRelatedVideos ytd-watch-next-secondary-results-renderer {\n    display: none !important;\n}\n\n/* AI surfaces — each policy has its own body class so users can keep\n * summaries, Ask, Gemini, or context panels independently. The structural\n * tokens mirror the capture-backed selector packs. */\nbody.ytkit-hideAskAi ytd-watch-metadata #flexible-item-buttons > conversational-ui-watch-metadata-button-view-model,\nbody.ytkit-hideAskAi ytd-watch-metadata #flexible-item-buttons > yt-button-view-model:has([is-ask-ai]),\nbody.ytkit-hideAskAi ytd-watch-metadata #flexible-item-buttons > yt-button-view-model:has([data-action=\"ask\"]),\nbody.ytkit-hideAskAi ytd-video-description-youchat-section-view-model,\nbody.ytkit-hideAskAi ytd-reel-shelf-renderer:has([is-ask-ai]) {\n    display: none !important;\n}\n\nbody.ytkit-hideGeminiButtons ytd-watch-metadata #flexible-item-buttons > yt-button-view-model:has([data-action=\"gemini\"]),\nbody.ytkit-hideGeminiButtons ytd-watch-metadata #flexible-item-buttons > button-view-model:has([data-action=\"gemini\"]),\nbody.ytkit-hideGeminiButtons ytd-engagement-panel-section-list-renderer[target-id*=\"gemini\" i],\nbody.ytkit-hideGeminiButtons ytd-engagement-panel-section-list-renderer[panel-target-id*=\"gemini\" i],\nbody.ytkit-hideGeminiButtons [data-gemini],\nbody.ytkit-hideGeminiButtons [data-ai-type=\"gemini\"] {\n    display: none !important;\n}\n\nbody.ytkit-hideAiSummary ytd-engagement-panel-section-list-renderer[target-id*=\"ai-summary\" i],\nbody.ytkit-hideAiSummary ytd-engagement-panel-section-list-renderer[target-id*=\"summary\" i],\nbody.ytkit-hideAiSummary ytd-engagement-panel-section-list-renderer[panel-target-id*=\"summary\" i],\nbody.ytkit-hideAiSummary ytd-ai-summary-renderer,\nbody.ytkit-hideAiSummary [class*=\"ai-summary\" i],\nbody.ytkit-hideAiSummary [class*=\"aiSummary\"] {\n    display: none !important;\n}\n\nbody.ytkit-hideAiContextPanels ytd-info-panel-content-renderer:has([icon=\"info_outline\"]),\nbody.ytkit-hideAiContextPanels ytd-factoid-renderer,\nbody.ytkit-hideAiContextPanels ytd-engagement-panel-section-list-renderer[target-id*=\"context\" i],\nbody.ytkit-hideAiContextPanels ytd-engagement-panel-section-list-renderer[panel-target-id*=\"context\" i],\nbody.ytkit-hideAiContextPanels [data-panel-type=\"context\"],\nbody.ytkit-hideAiContextPanels [data-ai-surface=\"context\"] {\n    display: none !important;\n}\n\n/* hideVoiceSearch */\nbody.ytkit-hideVoiceSearch #voice-search-button { display: none !important; }\n\n/* hideMiniPlayer */\nbody.ytkit-hideMiniPlayer ytd-miniplayer { display: none !important; }\n\n/* ─────────────────────────────────────────────────────────────────────\n * Compact Clean UI preset (owner preferences, opt-in since v4.46.2)\n *\n * Previously maintained as external Stylebot + uBlock element-hiding\n * rules, then inlined unconditionally in v3.16.0. They are now gated\n * behind the `cleanUiPreset` setting (default OFF): ytkit.js adds\n * `html.ytkit-clean-ui` when the feature is enabled, exactly as the\n * v3.16.0 comment prescribed. A clean install keeps the panel search,\n * category headers (incl. their Enable-all switches), nav counts, and —\n * critically — the global toast notifications (the product's only\n * feedback + Undo surface) fully visible.\n * ──────────────────────────────────────────────────────────────────── */\n\n/* Settings panel: remove decorative / redundant chrome ───────────────── */\nhtml.ytkit-clean-ui .ytkit-brand-intro,\nhtml.ytkit-clean-ui .ytkit-brand-badges,\nhtml.ytkit-clean-ui .ytkit-search-container,\nhtml.ytkit-clean-ui .ytkit-pane-header,\nhtml.ytkit-clean-ui .ytkit-nav-count,\nhtml.ytkit-clean-ui .ytkit-shortcut,\nhtml.ytkit-clean-ui .ytkit-version {\n    display: none !important;\n}\n\n/* Settings panel: compress the left nav list.\n * Tight margins/padding on the buttons reclaim vertical room so more\n * feature toggles fit in the viewport at once. */\nhtml.ytkit-clean-ui button.ytkit-nav-btn {\n    margin: 0 !important;\n    padding: 0 !important;\n}\nhtml.ytkit-clean-ui div.ytkit-nav-list {\n    margin: -10px 0 !important;\n    padding: 0 !important;\n}\n\n/* Settings panel: suppress the global toast notifications.\n * Feedback is still visible in the diagnosticLog and inline status\n * banners; removing the floating toast keeps the UI quieter. */\nhtml.ytkit-clean-ui div.ytkit-global-toast {\n    display: none !important;\n}\n\n/* Subscriptions page: hide the \"resume load\" banner. */\nhtml.ytkit-clean-ui div.ytkit-subs-load-banner {\n    display: none !important;\n}\n\n/* Watch page: bump the channel/video-owner row down slightly so the\n * collapsed header (without the avatar image) doesn't crowd the title.\n * Pairs with the avatar hide below, so it shares the same\n * restore-native-ui opt-out guard rather than the clean-ui preset. */\nhtml:not(.ytkit-restore-native-ui) ytd-video-owner-renderer.style-scope.ytd-watch-metadata {\n    margin-top: 10px !important;\n}\n\n/* YouTube page chrome: remove skeleton / loading placeholders and\n * the \"For You\" / \"Breaking News\" / \"Shorts\" rich-section shelves.\n *\n * These (and the avatar hides below) are the author's canonical UX\n * defaults, applied at document_start so there is no flash before the\n * content script runs. They are now OPT-OUT: the \"Restore Native YouTube\n * UI\" feature adds `html.ytkit-restore-native-ui`, which the\n * `html:not(.ytkit-restore-native-ui)` guard below disables so YouTube's\n * own styling applies cleanly (no display:revert guesswork). The default\n * — class absent — keeps the rules active with zero FOUC. */\nhtml:not(.ytkit-restore-native-ui) ytd-ghost-grid-renderer.style-scope.ytd-continuation-item-renderer,\nhtml:not(.ytkit-restore-native-ui) div.style-scope.ytd-rich-section-renderer,\nhtml:not(.ytkit-restore-native-ui) ytd-rich-section-renderer.style-scope.ytd-rich-grid-renderer {\n    display: none !important;\n}\n\n/* The grid's continuation renderer is the infinite-scroll trigger: YouTube\n * loads the next page when an IntersectionObserver sees it. display:none\n * gives it no box, so channel /videos grids stopped at the first 30 videos.\n * Hiding the spinner keeps the box, and the observer still fires. */\nhtml:not(.ytkit-restore-native-ui) ytd-continuation-item-renderer.style-scope.ytd-rich-grid-renderer {\n    visibility: hidden !important;\n}\n\n/* YouTube avatars: hide the IMG element inside yt-img-shadow wrappers,\n * which collapses channel/comment avatars site-wide. The more specific\n * watch-page owner-row avatar is handled by the same rule. Opt-out via\n * the `html.ytkit-restore-native-ui` guard (see above). The signed-in\n * account button keeps its picture: hiding it left an empty outlined\n * square in the masthead (#51); `hideOwnAvatar` removes that button.\n * Product pictures use the same wrapper and aren't avatars, so the merch\n * shelf and the Products panel keep theirs. */\nhtml:not(.ytkit-restore-native-ui) img.style-scope.yt-img-shadow:not(ytd-topbar-menu-button-renderer img):not(ytd-product-list-item-renderer img):not(ytd-merch-shelf-item-renderer img),\nhtml:not(.ytkit-restore-native-ui) yt-img-shadow.style-scope.ytd-video-owner-renderer.no-transition {\n    display: none !important;\n}\n\n/* Note: the upstream Stylebot rule\n *   a.yt-simple-endpoint.style-scope.yt-formatted-string { margin-bottom: -px; }\n * was omitted because `-px` is not a valid CSS length. If a specific\n * negative margin is wanted, replace with e.g. `margin-bottom: -4px`.\n */\n\n/* ─────────────────────────────────────────────────────────────────────\n * Motion accessibility — global, always-injected coverage.\n *\n * Disables the Astra entrance animations (install prompt, download\n * progress panel, download options popup) and the What's New badge\n * pulse when the OS asks for reduced motion. `!important` is required:\n * the badge animation is applied via an inline style, and stylesheet\n * !important declarations win over non-important inline styles.\n * ──────────────────────────────────────────────────────────────────── */\n@media (prefers-reduced-motion: reduce) {\n    #ytkit-mediadl-install-prompt,\n    .ytkit-dl-progress,\n    .ytkit-dl-popup {\n        animation: none !important;\n    }\n}\n",
		"liveChat": "/* Generated from premiumLiveChat in extension/ytkit.js. Run npm run generate:live-chat-css after editing that source. */\n/* Parent-page shell: theme-var driven (dark fallbacks) so\n   the frame around the chat follows light YouTube like its\n   native siblings; the iframe interior keeps the premium\n   dark aesthetic on purpose. */\nhtml:not(.ytkit-split-active) ytd-live-chat-frame#chat,\nhtml:not(.ytkit-split-active) ytd-live-chat-frame:not([collapsed]),\nhtml:not(.ytkit-split-active) #chat.ytd-live-chat-frame {\n    position: relative;\n    border-radius: 12px !important;\n    overflow: hidden !important;\n    border: 1px solid var(--yt-spec-10-percent-layer, rgba(255,255,255,0.08)) !important;\n    background: var(--yt-spec-menu-background, #0d1119) !important;\n    box-shadow: 0 28px 80px rgba(2,6,12,0.42) !important;\n    isolation: isolate;\n}\nhtml:not(.ytkit-split-active) ytd-live-chat-frame#chat > iframe,\nhtml:not(.ytkit-split-active) ytd-live-chat-frame > iframe,\nhtml:not(.ytkit-split-active) #chat.ytd-live-chat-frame > iframe {\n    border: none !important;\n    border-radius: inherit !important;\n    background: transparent !important;\n}\nhtml:not(.ytkit-split-active) ytd-live-chat-frame #show-hide-button,\nhtml:not(.ytkit-split-active) #chat #show-hide-button {\n    border-top: 1px solid var(--yt-spec-10-percent-layer, rgba(255,255,255,0.08)) !important;\n    background: var(--yt-spec-menu-background, #0d1119) !important;\n    backdrop-filter: none;\n}\n\nhtml[data-ytkit-livechat-premium],\nhtml[data-ytkit-livechat-premium] body {\n    color-scheme: dark;\n    background: #07101b !important;\n    --ytkit-livechat-panel: rgba(15,20,30,0.86);\n    --ytkit-livechat-panel-strong: rgba(18,24,35,0.94);\n    --ytkit-livechat-surface: rgba(255,255,255,0.04);\n    --ytkit-livechat-surface-hover: rgba(255,255,255,0.065);\n    --ytkit-livechat-border: rgba(255,255,255,0.09);\n    --ytkit-livechat-border-strong: rgba(255,255,255,0.14);\n    --ytkit-livechat-text: rgba(248,250,252,0.96);\n    --ytkit-livechat-muted: rgba(148,163,184,0.86);\n    --ytkit-livechat-soft: rgba(148,163,184,0.58);\n    --ytkit-livechat-accent: #f59e0b;\n    --yt-live-chat-background-color: transparent;\n    --yt-live-chat-secondary-background-color: transparent;\n    --yt-live-chat-primary-text-color: var(--ytkit-livechat-text);\n    --yt-live-chat-secondary-text-color: var(--ytkit-livechat-muted);\n    --yt-live-chat-tertiary-text-color: var(--ytkit-livechat-soft);\n}\nhtml[data-ytkit-livechat-premium] #chat-messages,\nhtml[data-ytkit-livechat-premium] yt-live-chat-renderer,\nhtml[data-ytkit-livechat-premium] #content-pages,\nhtml[data-ytkit-livechat-premium] yt-live-chat-item-list-renderer #items {\n    background: transparent !important;\n}\nhtml[data-ytkit-livechat-premium] #chat-messages { padding: 12px 12px 0; }\nhtml[data-ytkit-livechat-premium] yt-live-chat-item-list-renderer #items { padding: 2px 2px 28px !important; }\n\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer {\n    position: sticky;\n    top: 0;\n    z-index: 5;\n    margin: 0 0 12px;\n    padding: 14px 16px !important;\n    border: 1px solid var(--ytkit-livechat-border);\n    border-radius: 12px;\n    background: #0d1928 !important;\n    box-shadow: none;\n    backdrop-filter: none;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #primary-content {\n    display: flex;\n    align-items: center;\n    gap: 12px;\n    min-width: 0;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #title {\n    font-size: 20px;\n    font-weight: 700;\n    letter-spacing: 0;\n    color: var(--ytkit-livechat-text);\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #view-selector { margin-inline-start: auto; }\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer tp-yt-paper-button#label,\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #viewer-leaderboard-entry-point button,\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #action-buttons button,\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #live-chat-header-context-menu button,\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #close-button button {\n    min-height: 36px !important;\n    border-radius: 6px !important;\n    border: 1px solid rgba(255,255,255,0.08) !important;\n    background: rgba(255,255,255,0.045) !important;\n    color: var(--ytkit-livechat-text) !important;\n    box-shadow: inset 0 1px 0 rgba(255,255,255,0.04);\n    backdrop-filter: none;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer tp-yt-paper-button#label:hover,\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #viewer-leaderboard-entry-point button:hover,\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #action-buttons button:hover,\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #live-chat-header-context-menu button:hover,\nhtml[data-ytkit-livechat-premium] yt-live-chat-header-renderer #close-button button:hover {\n    border-color: rgba(245,158,11,0.24) !important;\n    background: rgba(255,255,255,0.08) !important;\n}\n\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-membership-item-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-viewer-engagement-message-renderer {\n    animation: ytkit-livechat-fade-in 0.24s cubic-bezier(0.2,0.8,0.2,1) both;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer {\n    position: relative !important;\n    display: flex !important;\n    align-items: flex-start !important;\n    gap: 12px !important;\n    min-height: 0 !important;\n    margin: 0 0 10px !important;\n    padding: 10px 48px 10px 12px !important;\n    border-radius: 8px !important;\n    border: 1px solid var(--ytkit-livechat-border) !important;\n    background: #0d1928 !important;\n    box-shadow: none;\n    backdrop-filter: none;\n    overflow: visible !important;\n    transition: border-color 160ms ease, background 160ms ease, transform 160ms ease;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer:hover,\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer:focus-within {\n    border-color: rgba(245,158,11,0.2) !important;\n    background: #122238 !important;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer[author-is-owner] {\n    border-color: rgba(245,158,11,0.24) !important;\n    background: rgba(245,158,11,0.10) !important;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer[data-ytkit-livechat-avatar-missing=\"1\"] {\n    padding-inline-start: 60px !important;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer[data-ytkit-livechat-avatar-fallback=\"1\"]::before,\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer[data-ytkit-livechat-avatar-missing=\"1\"]::before {\n    content: attr(data-ytkit-author-initial);\n    position: absolute;\n    top: 10px;\n    inset-inline-start: 12px;\n    display: inline-flex;\n    align-items: center;\n    justify-content: center;\n    width: 36px;\n    height: 36px;\n    border-radius: 8px;\n    border: 1px solid rgba(255,255,255,0.1);\n    background: #f59e0b;\n    color: rgba(8,11,16,0.92);\n    font-size: 15px;\n    font-weight: 800;\n    line-height: 1;\n    box-shadow: 0 10px 20px rgba(0,0,0,0.28);\n}\nhtml[data-ytkit-livechat-premium] #author-photo.yt-live-chat-text-message-renderer,\nhtml[data-ytkit-livechat-premium] yt-img-shadow#author-photo.yt-live-chat-text-message-renderer,\nhtml[data-ytkit-livechat-premium] img#author-photo.yt-live-chat-text-message-renderer {\n    display: block !important;\n    visibility: visible !important;\n    opacity: 1 !important;\n    flex: 0 0 36px !important;\n    width: 36px !important;\n    height: 36px !important;\n    min-width: 36px !important;\n    min-height: 36px !important;\n    margin: 0 !important;\n    border-radius: 12px !important;\n    border: 1px solid rgba(255,255,255,0.1);\n    background:\n        linear-gradient(135deg, rgba(255,255,255,0.08), rgba(255,255,255,0.025)),\n        rgba(10,14,21,0.86) !important;\n    box-shadow: 0 10px 20px rgba(0,0,0,0.28);\n    object-fit: cover !important;\n    overflow: hidden !important;\n}\nhtml[data-ytkit-livechat-premium] #author-photo.yt-live-chat-text-message-renderer img,\nhtml[data-ytkit-livechat-premium] yt-img-shadow#author-photo.yt-live-chat-text-message-renderer img,\nhtml[data-ytkit-livechat-premium] img#author-photo.yt-live-chat-text-message-renderer {\n    display: block !important;\n    visibility: visible !important;\n    opacity: 1 !important;\n    width: 100% !important;\n    height: 100% !important;\n    min-width: 100% !important;\n    min-height: 100% !important;\n    border-radius: inherit !important;\n    object-fit: cover !important;\n    filter: none !important;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer[data-ytkit-livechat-avatar-fallback=\"1\"] #author-photo.yt-live-chat-text-message-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer[data-ytkit-livechat-avatar-fallback=\"1\"] yt-img-shadow#author-photo.yt-live-chat-text-message-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer[data-ytkit-livechat-avatar-fallback=\"1\"] img#author-photo.yt-live-chat-text-message-renderer {\n    opacity: 0.18 !important;\n}\nhtml[data-ytkit-livechat-premium] #timestamp.yt-live-chat-text-message-renderer {\n    flex: 0 0 auto !important;\n    margin: 0 10px 0 0 !important;\n    color: var(--ytkit-livechat-soft) !important;\n    font-size: 10px !important;\n    font-weight: 700;\n    letter-spacing: 0.12em;\n    text-transform: uppercase;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-author-chip.yt-live-chat-text-message-renderer {\n    flex: 0 1 auto !important;\n    min-width: 0 !important;\n    max-width: 42% !important;\n    margin: 1px 8px 0 0 !important;\n}\nhtml[data-ytkit-livechat-premium] #author-name.yt-live-chat-author-chip {\n    color: var(--ytkit-livechat-text) !important;\n    font-size: 13px !important;\n    font-weight: 700 !important;\n    letter-spacing: 0 !important;\n    white-space: nowrap !important;\n    overflow: hidden !important;\n    text-overflow: ellipsis !important;\n}\nhtml[data-ytkit-livechat-premium] #author-name.member.yt-live-chat-author-chip { color: #86efac !important; }\nhtml[data-ytkit-livechat-premium] #author-name.moderator.yt-live-chat-author-chip { color: #7dd3fc !important; }\nhtml[data-ytkit-livechat-premium] #author-name.owner.yt-live-chat-author-chip,\nhtml[data-ytkit-livechat-premium] yt-live-chat-author-chip[is-highlighted] #author-name.owner.yt-live-chat-author-chip {\n    padding: 4px 10px !important;\n    border-radius: 6px !important;\n    background: #f59e0b !important;\n    color: #16181d !important;\n}\nhtml[data-ytkit-livechat-premium] #chip-badges.yt-live-chat-author-chip:empty,\nhtml[data-ytkit-livechat-premium] #chat-badges.yt-live-chat-author-chip:empty { display: none !important; }\nhtml[data-ytkit-livechat-premium] #message.yt-live-chat-text-message-renderer {\n    flex: 1 1 auto !important;\n    min-width: 0 !important;\n    margin-top: 1px !important;\n    color: rgba(241,245,249,0.96) !important;\n    font-size: 15px !important;\n    line-height: 1.5 !important;\n    overflow-wrap: anywhere !important;\n}\nhtml[data-ytkit-livechat-premium] #message.yt-live-chat-text-message-renderer a,\nhtml[data-ytkit-livechat-premium] #show-original.yt-live-chat-text-message-renderer { color: var(--ytkit-livechat-accent) !important; }\nhtml[data-ytkit-livechat-premium] #menu.yt-live-chat-text-message-renderer,\nhtml[data-ytkit-livechat-premium] #menu.yt-live-chat-paid-message-renderer {\n    top: 10px !important;\n    inset-inline-end: 10px !important;\n    bottom: auto !important;\n    transform: none !important;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer[use-opacity-for-context-menu-visibility] #menu.yt-live-chat-text-message-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-paid-message-renderer[use-opacity-for-context-menu-visibility] #menu.yt-live-chat-paid-message-renderer {\n    opacity: 0;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer:hover #menu.yt-live-chat-text-message-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer:focus-within #menu.yt-live-chat-text-message-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-paid-message-renderer:hover #menu.yt-live-chat-paid-message-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-paid-message-renderer:focus-within #menu.yt-live-chat-paid-message-renderer {\n    opacity: 1 !important;\n}\nhtml[data-ytkit-livechat-premium] #menu-button button,\nhtml[data-ytkit-livechat-premium] #menu.yt-live-chat-text-message-renderer button,\nhtml[data-ytkit-livechat-premium] #menu.yt-live-chat-paid-message-renderer button {\n    width: 30px;\n    height: 30px;\n    border-radius: 6px;\n    border: 1px solid rgba(255,255,255,0.08);\n    background: rgba(7,10,16,0.72);\n    color: var(--ytkit-livechat-muted);\n}\n\nhtml[data-ytkit-livechat-premium] #card.yt-live-chat-paid-message-renderer,\nhtml[data-ytkit-livechat-premium] #card.yt-live-chat-paid-sticker-renderer,\nhtml[data-ytkit-livechat-premium] #card.yt-live-chat-membership-item-renderer {\n    border-radius: 8px !important;\n    border: 1px solid rgba(255,255,255,0.14);\n    box-shadow: none;\n    overflow: hidden;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-viewer-engagement-message-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-banner-renderer,\nhtml[data-ytkit-livechat-premium] yt-live-chat-item-bumper-view-model {\n    margin: 10px 0 !important;\n    padding: 12px 14px !important;\n    border-radius: 8px !important;\n    border: 1px solid var(--ytkit-livechat-border);\n    background: #122238 !important;\n    color: var(--ytkit-livechat-muted) !important;\n}\n\nhtml[data-ytkit-livechat-premium] yt-live-chat-message-input-renderer {\n    position: sticky;\n    bottom: 0;\n    z-index: 5;\n    margin-top: 4px;\n    padding: 16px 14px 18px !important;\n    border-top: 1px solid var(--ytkit-livechat-border);\n    background: #07101b !important;\n    backdrop-filter: none;\n}\nhtml[data-ytkit-livechat-premium] #input-container.yt-live-chat-message-input-renderer {\n    min-height: 44px !important;\n    border-radius: 8px !important;\n    border: 1px solid rgba(255,255,255,0.08);\n    background: rgba(15,20,28,0.84) !important;\n    box-shadow: none;\n}\nhtml[data-ytkit-livechat-premium] yt-live-chat-message-input-renderer:focus-within #input-container.yt-live-chat-message-input-renderer {\n    border-color: rgba(245,158,11,0.28);\n    background: rgba(18,24,33,0.96) !important;\n    box-shadow: inset 0 1px 0 rgba(255,255,255,0.05), 0 0 0 4px rgba(245,158,11,0.08), 0 18px 40px rgba(2,6,12,0.3);\n}\nhtml[data-ytkit-livechat-premium] #emoji-picker-button.yt-live-chat-message-input-renderer button,\nhtml[data-ytkit-livechat-premium] #picker-buttons.yt-live-chat-message-input-renderer yt-icon-button button {\n    width: 34px;\n    height: 34px;\n    border-radius: 6px;\n    background: rgba(255,255,255,0.04);\n    color: var(--ytkit-livechat-muted);\n}\nhtml[data-ytkit-livechat-premium] #send-button.yt-live-chat-message-input-renderer > .yt-live-chat-message-input-renderer {\n    min-width: 38px;\n    height: 38px;\n    border-radius: 6px !important;\n    background: #f59e0b !important;\n    color: #14181f !important;\n    box-shadow: none;\n}\nhtml[data-ytkit-livechat-premium] #send-button.yt-live-chat-message-input-renderer > .yt-live-chat-message-input-renderer[disabled] {\n    background: rgba(255,255,255,0.05) !important;\n    color: var(--ytkit-livechat-soft) !important;\n    box-shadow: none;\n}\n\nhtml[data-ytkit-livechat-premium] ::-webkit-scrollbar { width: 10px; }\nhtml[data-ytkit-livechat-premium] ::-webkit-scrollbar-track { background: transparent; }\nhtml[data-ytkit-livechat-premium] ::-webkit-scrollbar-thumb {\n    border-radius: 10px;\n    border: 2px solid transparent;\n    background: rgba(148,163,184,0.28);\n    background-clip: padding-box;\n}\nhtml[data-ytkit-livechat-premium] ::-webkit-scrollbar-thumb:hover {\n    background: rgba(245,158,11,0.34);\n    background-clip: padding-box;\n}\n\n@keyframes ytkit-livechat-fade-in {\n    from { opacity: 0; transform: translateY(8px); }\n    to { opacity: 1; transform: translateY(0); }\n}\n\n@media (prefers-reduced-motion: reduce) {\n    html[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer,\n    html[data-ytkit-livechat-premium] yt-live-chat-membership-item-renderer,\n    html[data-ytkit-livechat-premium] yt-live-chat-viewer-engagement-message-renderer {\n        animation: none !important;\n    }\n}\n\n/* This restyle paints ~50 chat selectors with hard-coded\n   rgba backgrounds, borders and text colours. In forced-colors\n   mode those are ignored for colour but the layering still\n   reads as flat, and any focusable chat control inherits a\n   box-shadow ring that is never painted. Hand every surface\n   back to the system palette and give focus a real outline. */\n@media (forced-colors: active) {\n    html[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer,\n    html[data-ytkit-livechat-premium] yt-live-chat-membership-item-renderer,\n    html[data-ytkit-livechat-premium] yt-live-chat-paid-message-renderer,\n    html[data-ytkit-livechat-premium] yt-live-chat-viewer-engagement-message-renderer {\n        background: Canvas !important;\n        color: CanvasText !important;\n        border: 1px solid CanvasText !important;\n        forced-color-adjust: none;\n    }\n\n    html[data-ytkit-livechat-premium] yt-live-chat-text-message-renderer a,\n    html[data-ytkit-livechat-premium] #author-name {\n        color: LinkText !important;\n    }\n\n    html[data-ytkit-livechat-premium] *:focus-visible {\n        outline: 2px solid Highlight !important;\n        outline-offset: 2px;\n        box-shadow: none !important;\n    }\n}\n"
	},
	"assets": {
		"icons/32.png": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAfGSURBVFhH1Zd5VFTXHcfHpjYxLiggM8zC7DOCHBWpSmIbehJkdIbZZ95D7alGAhqRZWSRRRgEQUTEqEgUVEBk19j2VG2ruEQ0xEhiYyUVU42aSoxLtC6oMPfb84AoPtMYoz09+Zxzz5k/fr/f/dzfvffNexzOT5QBUX8MfHl+g9+Q+Q3BQxL+MmawvcH+Ajvof4K1UTN65p9070bt0TXF7tceSG7WHsg4ot2/+Ihui61qqh87/rkSWhbqbnzP2DRztwlRTUbEHzIgtUWP7FY94pr0CMie1hATo3iRnffcmFKl/61xu7lr5m4zovYaSfz7BpLWYiDZrXqi3RSGiKQJ1/cl8YLZec+F4OLgISHVlr8ad1gxc6eZRO41EaYD6UcNWLhfTyZlTiFbEhVoTuRvhJPzM3b+M/NqmVH7eo3ttmGHFTN2Wkhkkwnxh4xI/9BAwirCSHj8RLIvQYgPFvI7PnaMHMvOfyYCNwQODNpsqX29zg7DDhum77LgrSYz4ptNiDtoRIBTQ9bEqUmzQ4DWRCFOJPLz2TWeiYC1pldeqaSuvlFPwfCejUzfaSURey0k7rAZxmoD0cRNJn92iMjhhUJyPEmIfyTzT5+K95Kx6/xYBgSst657dQuNHoHf2xG+y4qIJgvm7TdjTI4WWbGj8b5DgJYEITmRLMI/U0U4n8JPZBf6UfgW6UcHlFFfTq6iEfKtwG4bIvZZYag3Y1Lcb7DDIUFzghDHkkTkZKqInF3sg44MYWuHk+vFrvfU+BZbl4zfFI4egQZGgAK9y05m7bFhdL6h683o8ef2LxS6jiSJ8EmKDzm12Iecd4pxKVvcdS1b8Dt2vadCXmgU+a2jPgvcHI5fbe0V0PcJGBot8IzXnk6OVs84mCj8+ugiH5xIF5PPnWLyZZaEXMmV4EaueM8l58gh7Lo/GOVKywL/d2kyoTwcv66mMaVPgNplR0CREcPmalYdi+IMPJQsqGtN80Fbpph8sURCOnIk5NoyCW4WSG7fWi7Wsuv+IITOUHfVanvLmA3hmFgejtcYgUYK+j9Q0Dba4J2su+r+VkgQE/tBEt9wPF3UeXqJBBdypORSnpR8ky8ltwul6CyS1GIDZyC7/hMR55mmq9ZQ98eWMgJ0j0Bon8D4NSYMf3tao5/d7xdM7LGoEW4nMkQHz+RIcDFXSq7kS8mNAhnpLJLh3jvSK/dXSiey638v3s6wl6UrbLt914VjXFk4JlXQeK2GRug2GpoGO/hp+rtuc6eY++e0Z/DnncuVuL5eLsP1FTLcXslMLkdXMTOk7/SPfSKiHFOorMh+y3cdjYAyGkEVNIL7BH5ZYoFbtLbZbVbw8P457U6BsCNX0vbNChn+XSgnd1bJyf21crhKFOher/ji7lqpqn/8f8cZ/HNRnqVKvoqGH0uAeRBJnAYMmxu6gJ3GcDlPvORmoQydq+S4t4ZZuYK41itANirRXSpPY8d/J7yMsAmifNvlxwRqaUwss4KbpCOiRaHZnO/4x2uP5DluLJO67q/ubX13iYK4ShUE5Uq4yuXHUSzmsXMeg5tlWSUqoKDoJ9B7Bigoco2Em6yFzDnt1uhcTXJgVGDP6WauYst07oKPLNyrHck+6O5pvRykVAGySQlUKkEqld3dm6Vz2PM9gmeSTumVYzv7UIDCuFIaQZU0Jmy0gZuigyBNSxQ5Wviv0HaOK9IsdS5SSw5F8go+nO3d+XG4N07NEZD7q2Ug6+UgGxVAhRKoUgHVKri2yPaRKvdh7Hkf4JFuSuHmUmAEvt0CRmBSJQ1lgQmeSVqIMrREuVRL/At1CF4ZcrciRXbmcDTf1RrFx6ez+aRtJp/cyJEAZQpgswKoUgI1KqBODVKtvNNVJTGw5+3BK1bP9XDajvP6CTC3gBEIKLWDm6onXot0xCdTB1WeDv7Lp34yIzco4kAir6bF4X3vbwsE+GyugLTP5pOLcSJm73tXX60C6tVAoxqoV8FVI9+Ght7nxyO4pZjf9Myiunm5NEQFdK9AMY2xpTQUBRa4J4QRXmoYfDJ0XYqsabW+i0OUTN4Rh3DQR7HciE/jvNtPxwhwbp4AFyIFzEOIoLK39WgYBWwfBWxTg9Qrr5GtPpMfmdxjjmHoiFRrk+cSCr0deCjgX0KBm2aER2IYeIu0X4lSNAu5CVMGP1KAw+GceNvd90wsf+u/YgV3v5onwPXFYkLKVcBW9UOB7cxvJVy1snXgcAY8SB7qMGrd0m13PLIocJdSEC6nICuiMaqYhrzAiuGOMHg4tId4jpDvfeM9O0v8Ukccf87lOH77tXghukqYM6AG6pjV90k0quCqk10glWLf3qyYqS8OTbLUuqVT8HD2CeRTkK2koF5NgZtquDksWlM0cn7wk+9wH1dieH5XY/jVd/LE91CpBmqYiX0fCKBege6tEmdP8OBYnf/QJNtFRsA9k4JXDgVBPgVpIQVpgeXvI2I0FMfOeerPrvM24aBbmcKI7jL55z3bUN/XhT4BV7XkKCkTunOGxEwdOSzBXO6WYm0bnm45OTLTcpKfYzkmzjMXKHJMcnbhp+VeidDftVlR6qpWHXfVqdpcdfI2V7WsrWuLzzKyuu8rSmgLGuQZqfH2iA7hM4Mf/YYHu9CzADvnBVIi8yIVQgEzbq338YaT8/hV/H/wH+y7SsnuHLiqAAAAAElFTkSuQmCC",
		"assets/cat.gif": "data:image/gif;base64,R0lGODlhIgAVAKIHAL3/9/+Zmf8zmf/MmZmZmf+Z/wAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpDMkJBNjY5RTU1NEJFMzExOUM4QUM2MDAwNDQzRERBQyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpCREIzOEIzMzRCN0IxMUUzODhEQjgwOTYzMTgyNTE0QiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDpCREIzOEIzMjRCN0IxMUUzODhEQjgwOTYzMTgyNTE0QiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChXaW5kb3dzKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOkM1QkE2NjlFNTU0QkUzMTE5QzhBQzYwMDA0NDNEREFDIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOkMyQkE2NjlFNTU0QkUzMTE5QzhBQzYwMDA0NDNEREFDIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Af/+/fz7+vn49/b19PPy8fDv7u3s6+rp6Ofm5eTj4uHg397d3Nva2djX1tXU09LR0M/OzczLysnIx8bFxMPCwcC/vr28u7q5uLe2tbSzsrGwr66trKuqqainpqWko6KhoJ+enZybmpmYl5aVlJOSkZCPjo2Mi4qJiIeGhYSDgoGAf359fHt6eXh3dnV0c3JxcG9ubWxramloZ2ZlZGNiYWBfXl1cW1pZWFdWVVRTUlFQT05NTEtKSUhHRkVEQ0JBQD8+PTw7Ojk4NzY1NDMyMTAvLi0sKyopKCcmJSQjIiEgHx4dHBsaGRgXFhUUExIREA8ODQwLCgkIBwYFBAMCAQAAIfkECQcABwAsAAAAACIAFQAAA6J4umv+MDpG6zEj682zsRaWFWRpltoHMuJZCCRseis7xG5eDGp93bqCA7f7TFaYoIFAMMwczB5EkTzJllEUttmIGoG5bfPBjDawD7CsJC67uWcv2CRov929C/q2ZpcBbYBmLGk6W1BRY4MUDnMvJEsBAXdlknk2fCeRk2iJliAijpBlEmigjR0plKSgpKWvEUheF4tUZqZID1RHjEe8PsDBBwkAIfkECQcABwAsAAAAACIAFQAAA6B4umv+MDpG6zEj682zsRaWFWRpltoHMuJZCCRseis7xG5eDGp93TqS40XiKSYgTLBgIBAMqE/zmQSaZEzns+jQ9pC/5dQJ0VIv5KMVWxqb36opxHrNvu9ptPfGbmsBbgSAeRdydCdjXWRPchQPh1hNAQF4TpM9NnwukpRyi5chGjqJEoSOIh0plaYsZBKvsCuNjY5ptElgDyFIuj6+vwcJACH5BAkHAAcALAAAAAAiABUAAAOfeLrc/vCZSaudUY7Nu99GxhhcYZ7oyYXiQQ5pIZgzCrYuLMd8MbAiUu802flYGIhwaCAQDKpQ86nUoWqF6dP00wIby572SXE6vyMrlmhuu9GKifWaddvNQAtszXYCxgR/Zy5jYTFeXmSDiIZGdQEBd06QSBQ5e4cEkE9nnZQaG2J4F4MSLx8rkqUSZBeurhlTUqsLsi60DpZxSWBJugcJACH5BAkHAAcALAAAAAAiABUAAAOgeLrc/vCZSaudUY7Nu99GxhhcYZ7oyYXiQQ5pIZgzCrYuLMd8MbAiUu802flYGIhwaCAQDKpQ86nUoWqF6dP00wIby572SXE6vyMrlmhuu9GuifWaddvNwMkZtmY7AWMEgGcKY2ExXl5khFMVc0Z1AQF3TpJShDl8iASST2efloV5JTyJFpgOch8dgW9KZxexshGNLqgLtbW0SXFwvaJfCQAh+QQJBwAHACwAAAAAIgAVAAADoXi63P7wmUmrnVGOzbvfRsYYXGGe6MmF4kEOaSGYMwq2LizHfDGwIlLPNKGZfi6gZmggEAy2iVPZEKZqzakq+1xUFFYe90lxTsHmim6HGpvf3eR7skYJ3PC5tyystc0AboFnVXQ9XFJTZIQOYUYFTQEBeWaSVF4bbCeRk1meBJYSL3WbaReMIxQfHXh6jaYXsbEQni6oaF21ERR7l0ksvA0JACH5BAkHAAcALAAAAAAiABUAAAOeeLrc/vCZSaudUY7Nu99GxhhcYZ7oyYXiQQ5pIZgzCrYuLMfFlA4hTITEMxkIBMOuADwmhzqeM6mashTCXKw2TVKQyKuTRSx2wegnNkyJ1ozpOFiMLqcEU8BZHx6NYW8nVlZefQ1tZgQBAXJIi1eHUTRwi0lhl48QL0sogxaGDhMlUo2gh14fHhcVmnOrrxNqrU9joX21Q0IUElm7DQkAIfkECQcABwAsAAAAACIAFQAAA6J4umv+MDpG6zEj682zsRaWFWRpltoHMuJZCCRseis7xG5eDGp93bqCA7f7TFaYoIFAMMwczB5EkTzJllEUttmIGoG5bfPBjDawD7CsJC67uWcv2CRov929C/q2ZpcBbYBmLGk6W1BRY4MUDnMvJEsBAXdlknk2fCeRk2iJliAijpBlEmigjR0plKSgpKWvEUheF4tUZqZID1RHjEe8PsDBBwkAIfkECQcABwAsAAAAACIAFQAAA6B4umv+MDpG6zEj682zsRaWFWRpltoHMuJZCCRseis7xG5eDGp93TqS40XiKSYgTLBgIBAMqE/zmQSaZEzns+jQ9pC/5dQJ0VIv5KMVWxqb36opxHrNvu9ptPfGbmsBbgSAeRdydCdjXWRPchQPh1hNAQF4TpM9NnwukpRyi5chGjqJEoSOIh0plaYsZBKvsCuNjY5ptElgDyFIuj6+vwcJACH5BAkHAAcALAAAAAAiABUAAAOfeLrc/vCZSaudUY7Nu99GxhhcYZ7oyYXiQQ5pIZgzCrYuLMd8MbAiUu802flYGIhwaCAQDKpQ86nUoWqF6dP00wIby572SXE6vyMrlmhuu9GKifWaddvNQAtszXYCxgR/Zy5jYTFeXmSDiIZGdQEBd06QSBQ5e4cEkE9nnZQaG2J4F4MSLx8rkqUSZBeurhlTUqsLsi60DpZxSWBJugcJACH5BAkHAAcALAAAAAAiABUAAAOgeLrc/vCZSaudUY7Nu99GxhhcYZ7oyYXiQQ5pIZgzCrYuLMd8MbAiUu802flYGIhwaCAQDKpQ86nUoWqF6dP00wIby572SXE6vyMrlmhuu9GuifWaddvNwMkZtmY7AWMEgGcKY2ExXl5khFMVc0Z1AQF3TpJShDl8iASST2efloV5JTyJFpgOch8dgW9KZxexshGNLqgLtbW0SXFwvaJfCQAh+QQJBwAHACwAAAAAIgAVAAADoXi63P7wmUmrnVGOzbvfRsYYXGGe6MmF4kEOaSGYMwq2LizHfDGwIlLPNKGZfi6gZmggEAy2iVPZEKZqzakq+1xUFFYe90lxTsHmim6HGpvf3eR7skYJ3PC5tyystc0AboFnVXQ9XFJTZIQOYUYFTQEBeWaSVF4bbCeRk1meBJYSL3WbaReMIxQfHXh6jaYXsbEQni6oaF21ERR7l0ksvA0JACH5BAkHAAcALAAAAAAiABUAAAOeeLrc/vCZSaudUY7Nu99GxhhcYZ7oyYXiQQ5pIZgzCrYuLMfFlA4hTITEMxkIBMOuADwmhzqeM6mashTCXKw2TVKQyKuTRSx2wegnNkyJ1ozpOFiMLqcEU8BZHx6NYW8nVlZefQ1tZgQBAXJIi1eHUTRwi0lhl48QL0sogxaGDhMlUo2gh14fHhcVmnOrrxNqrU9joX21Q0IUElm7DQkAOw=="
	},
	"messages": {
		"advancedFiltersHint": "Use risk:, category:, scope:, or profile:. Spaces combine filters; commas match alternatives.",
		"advancedFiltersTitle": "Advanced filters",
		"aiCredentialDeleteFailed": "Credential could not be deleted.",
		"aiCredentialDeleted": "AI credential deleted. This can't be undone, so re-enter the key to use AI features again.",
		"aiCredentialInputPlaceholder": "Paste your API key",
		"aiCredentialInputRequired": "Enter a credential to save.",
		"aiCredentialNewLabel": "New credential",
		"aiCredentialNote": "The stored value is never shown or included in settings exports.",
		"aiCredentialProviderLabel": "Provider",
		"aiCredentialRememberLabel": "Remember after browser restart",
		"aiCredentialReplaceBtn": "Replace credential",
		"aiCredentialSaveBtn": "Save credential",
		"aiCredentialSaveFailed": "Credential could not be saved.",
		"aiCredentialSaved": "AI credential saved without exposing its value.",
		"aiCredentialStatusError": "Credential status unavailable.",
		"aiCredentialStatusNotConfigured": "Not configured",
		"aiCredentialStatusRemembered": "Configured · remembered",
		"aiCredentialStatusSession": "Configured · this session",
		"aiCredentialStatusUnavailable": "Status unavailable",
		"aiCredentialTitle": "AI provider credential",
		"aiSummaryButtonTitle": "AI Summary (set the provider key in the Astra Deck toolbar popup, or the userscript manager menu)",
		"aiSummaryByoFallbackNotice": "Using your configured BYO-key provider instead.",
		"aiSummaryCalling": "Calling AI provider…",
		"aiSummaryCallingTruncated": "Calling AI provider with the first 120,000 transcript characters…",
		"aiSummaryCitationLabel": "Transcript citation",
		"aiSummaryClose": "Close AI summary",
		"aiSummaryCopied": "Summary copied with citations",
		"aiSummaryCopy": "Copy with citations",
		"aiSummaryDelete": "Delete",
		"aiSummaryDeleted": "Saved summary deleted",
		"aiSummaryDialogLabel": "AI video summary",
		"aiSummaryExport": "Export archive",
		"aiSummaryExported": "Saved summaries exported",
		"aiSummaryFailed": "Summary failed",
		"aiSummaryFetchingTranscript": "Fetching transcript…",
		"aiSummaryInvalid": "The saved summary is invalid and cannot be displayed.",
		"aiSummaryLibrary": "Saved summaries",
		"aiSummaryNoExport": "No saved summaries to export.",
		"aiSummaryNoSaved": "No saved summaries match this search.",
		"aiSummaryRestored": "Saved summary restored",
		"aiSummarySaveFailed": "Saving the summary failed. It may disappear after a reload.",
		"aiSummarySearchLabel": "Search saved summaries",
		"aiSummarySearchPlaceholder": "Search saved summaries…",
		"aiSummaryTitle": "AI Summary",
		"aiSummaryTldr": "TL;DR",
		"altFrontendOpenAriaTpl": "Open externally at {host}",
		"altFrontendOpenBtn": "Open externally",
		"antiAdblockEvidenceTpl": "Selector: {selector} · Playback: {state}",
		"antiAdblockPauseAction": "Pause Astra ad blocking for 15 minutes",
		"antiAdblockPausedUntilTpl": "Astra ad blocking is paused until {time}.",
		"antiAdblockPlaybackAdvancing": "advancing",
		"antiAdblockPlaybackBlocked": "blocked",
		"antiAdblockPlaybackStalled": "stalled",
		"antiAdblockPlaybackUnknown": "unknown",
		"antiAdblockReloadHint": "Reload this YouTube tab to retry playback.",
		"antiAdblockResumeAction": "Resume Astra ad blocking",
		"antiAdblockResumed": "Astra ad blocking resumed.",
		"antiAdblockRulesPaused": "Astra ad blocking is temporarily paused.",
		"antiAdblockStateAdvancing": "YouTube showed an ad-block warning, but this video is still playing.",
		"antiAdblockStateBlocked": "YouTube showed an ad-block warning and playback appears blocked.",
		"antiAdblockStateStalled": "YouTube showed an ad-block warning and playback is stalled.",
		"antiAdblockStateUnknown": "YouTube showed an ad-block warning. Astra cannot confirm the playback state yet.",
		"antiAdblockTitle": "YouTube playback check",
		"astraContextMenuAria": "Astra actions",
		"audioOnlyActive": "Audio only",
		"audioOnlyLowest": "Audio mode · lowest quality",
		"audioOnlyUnavailable": "Audio-only unavailable",
		"bisectAbort": "Stop and restore",
		"bisectAborted": "Bisect stopped. Your features are back on.",
		"bisectCopy": "Copy result",
		"bisectCopyDone": "Result copied. Nothing was sent anywhere.",
		"bisectCopyFail": "Could not copy the result.",
		"bisectCulpritTpl": "It is {feature}.",
		"bisectExpired": "An unfinished bisect expired. Your features are back on.",
		"bisectFailed": "The bisect could not continue. Check Settings.",
		"bisectIntro": "Switches your features off and back on in halves so you can narrow {count} of them down to one in about ten reloads. Your settings are restored when it finishes, when you stop it, and automatically if you walk away.",
		"bisectIntroCountUnknown": "your features",
		"bisectNo": "Gone",
		"bisectNoCulprit": "No single feature is responsible. Something outside Astra Deck, or a combination of features, is causing it.",
		"bisectNothingEnabled": "No features are switched on, so there is nothing to search.",
		"bisectRestoreFailed": "Could not put your settings back. Open Settings and check them.",
		"bisectStart": "Start bisect",
		"bisectStartFailed": "Could not start: this browser profile will not save the bisect session.",
		"bisectStarted": "Reload YouTube, then answer below.",
		"bisectStepTpl": "Step {step} of about {total}. Reload YouTube, then answer: does the problem still happen?",
		"bisectTitle": "Find the feature that broke it",
		"bisectYes": "Still happens",
		"blockedWatchAllowOnce": "Allow once",
		"blockedWatchBack": "Back",
		"blockedWatchDescription": "This video is from a channel you blocked.",
		"blockedWatchTitle": "Blocked channel",
		"blockedWatchUnblock": "Unblock",
		"blockedWatchUnknownChannel": "Unknown channel",
		"brandName": "Astra Deck",
		"bufferTargetSecondsTpl": "{count}s",
		"bulkActionsAria": "Bulk card actions",
		"bulkAllow": "Allow",
		"bulkAllowedTpl": "Allowed {count} videos",
		"bulkCopiedTpl": "Copied {count} URLs",
		"bulkCopyUrls": "Copy URLs",
		"bulkDontRecommend": "Don’t recommend",
		"bulkDontRecommendTitleTpl": "Apply YouTube’s native “Don’t recommend channel” to up to {count} selected cards, hide them locally, and log the session.",
		"bulkExportLog": "Export log",
		"bulkExportLogTitle": "Download the local scrub-session summary as JSON. Nothing leaves this device.",
		"bulkExportedScrubTpl": "Exported {count} scrub sessions",
		"bulkHiddenTpl": "Hidden {count} videos",
		"videoHiderHideAllSweepingTpl": "Hidden {count} videos. Hiding the rest as they load.",
		"bulkHide": "Hide",
		"bulkNoScrubSessions": "No scrub sessions recorded yet.",
		"bulkNotInterested": "Not interested",
		"bulkNotInterestedTitleTpl": "Apply YouTube’s native “Not interested” to up to {count} selected cards, hide them locally, and log the session.",
		"bulkRestoredTpl": "Restored {count} local hides (native feedback stays applied)",
		"bulkScrubCapTpl": " ({skipped} over the {cap}-per-run cap left selected)",
		"bulkScrubDoneTpl": "Scrubbed {count}: {native} native, {count} hidden locally{capNote}",
		"bulkScrubPartialTpl": "YouTube’s menu item wasn’t found. 0 native, {count} hidden locally only{capNote}",
		"bulkScrubRunning": "A scrub session is already running.",
		"bulkScrubSelectFirst": "Select cards to scrub first.",
		"bulkSelect": "Bulk Select",
		"bulkSelectedTpl": "{count} selected",
		"bulkUndoHides": "Undo hides",
		"categoryMeta_accessibility_description": "Reduced motion, contrast, focus, and reading comfort.",
		"categoryMeta_accessibility_summary": "Motion, contrast & reading comfort",
		"categoryMeta_advanced_description": "Diagnostics, experiments, and power-user controls.",
		"categoryMeta_advanced_summary": "Power-user toggles & experimental controls",
		"categoryMeta_comments_description": "Readability, filtering, and focused comment threads.",
		"categoryMeta_comments_summary": "Readability, filtering & creator context",
		"categoryMeta_content_description": "What reaches your feeds, and what gets filtered out.",
		"categoryMeta_content_summary": "Hiding, filtering & what reaches your feeds",
		"categoryMeta_downloads_description": "Download quality, formats, and companion service.",
		"categoryMeta_downloads_summary": "Local yt-dlp downloads and server status",
		"categoryMeta_homeSubscriptions_description": "Layout and density for the home and subscription feeds.",
		"categoryMeta_homeSubscriptions_summary": "Feed layout, density & subscription views",
		"categoryMeta_integrations_description": "Handing video to other players and services you choose.",
		"categoryMeta_integrations_summary": "External players and third-party services",
		"categoryMeta_liveChat_description": "Filtering, spacing, and visibility for live streams.",
		"categoryMeta_liveChat_summary": "Filters, density & live viewing comfort",
		"categoryMeta_navigation_description": "The guide, the masthead, and moving around YouTube.",
		"categoryMeta_navigation_summary": "Guide, masthead & moving around the site",
		"categoryMeta_playback_description": "Resuming, looping, timing, and tab-aware playback.",
		"categoryMeta_playback_summary": "Speed, looping & tab-aware behavior",
		"categoryMeta_playlists_description": "The queue, Watch Later, and playlist management.",
		"categoryMeta_playlists_summary": "Queue, Watch Later & playlist tools",
		"categoryMeta_ratings_description": "Like and dislike counts, and community rating signal.",
		"categoryMeta_ratings_summary": "Likes, dislikes & community signal",
		"categoryMeta_research_description": "Transcripts, summaries, questions, and notes.",
		"categoryMeta_research_summary": "Transcripts, summaries & note taking",
		"categoryMeta_subscriptions_description": "Grouping, tagging, and managing the channels you follow.",
		"categoryMeta_subscriptions_summary": "Groups, tags & managing who you follow",
		"categoryMeta_theme_description": "Color, contrast, density, and custom appearance.",
		"categoryMeta_theme_summary": "Color, density & visual polish",
		"categoryMeta_videoPlayer_description": "Playback defaults, quality, and player behavior.",
		"categoryMeta_videoPlayer_summary": "Layout, theater behavior & player chrome",
		"categoryMeta_watchPage_description": "Actions, utilities, and helpers for the watch page.",
		"categoryMeta_watchPage_summary": "Actions, utilities & page-level helpers",
		"channelAgePublishedOnTpl": "Published on {date}",
		"channelAgeScheduledForTpl": "Scheduled for {date}",
		"clearFilterAria": "Clear quick toggle filter",
		"clearFilterBtn": "Clear Filter",
		"clipboardWriteFailed": "Clipboard write failed",
		"closeBtnAria": "Close",
		"commentBlockAlreadyTpl": "{author} is already blocked",
		"commentBlockMenuItemTpl": "Block {author}",
		"commentBlockToastTpl": "Blocked {author}. Their comments are hidden.",
		"commentBlockUndoneTpl": "Unblocked {author}",
		"commentDuplicateHide": "Hide similar comments",
		"commentDuplicateShowTpl": "Show {count} similar comments",
		"commentHeatLikesTplOne": "{count} like",
		"commentHeatLikesTplOther": "{count} likes",
		"commentRepliesLoadedTplOne": "{count} reply",
		"commentRepliesLoadedTplOther": "{count} replies",
		"commentSearchActiveHint": "Your search stays active while YouTube loads the comment list.",
		"commentSearchAria": "Search comments",
		"commentSearchClearAria": "Clear comment search",
		"commentSearchCountMatch": "{count} match",
		"commentSearchCountMatches": "{count} matches",
		"commentSearchCountThread": "{count} thread",
		"commentSearchCountThreads": "{count} threads",
		"commentSearchEmptyCopy": "Try a shorter phrase, a creator name, or clear the filter to bring every thread back.",
		"commentSearchEmptyTitle": "No matching comments",
		"commentSearchEscapeHint": "Press Esc to clear anytime. New comments stay counted automatically.",
		"commentSearchEyebrow": "Find in Comments",
		"commentSearchNavigatorHint": "Use Next or Previous in Comment Navigator to jump between matches.",
		"commentSearchNoMatches": "No matches",
		"commentSearchNoThreadsForQuery": "No comment threads match “{query}”.",
		"commentSearchPlaceholder": "Search creators, phrases, or topics…",
		"commentSearchReadyThread": "{count} comment thread is ready to scan. Search creators, phrases, or topics.",
		"commentSearchReadyThreads": "{count} comment threads are ready to scan. Search creators, phrases, or topics.",
		"commentSearchShorterHint": "Try a shorter phrase, a creator name, or clear the filter.",
		"commentSearchShowingMatches": "Showing {visible} of {total} comment threads for “{query}”.",
		"commentSearchSyncHint": "The search bar will stay in sync as more comments arrive.",
		"commentSearchWaiting": "Waiting for comments to load…",
		"commentNavNoMatches": "No matching threads",
		"commentNavThreadsReady": "Visible threads ready",
		"commentNavFilterTitleTpl": "Search filter: {query}",
		"quickLinksInvalidUrlNote": "Use a path that starts with / or a full https:// URL.",
		"commentNavAria": "Comment thread navigator",
		"commentNavLabel": "Thread Navigator",
		"commentNavPrevious": "Previous",
		"commentNavNext": "Next",
		"commentNavPreviousTitle": "Jump to previous visible comment thread",
		"commentNavNextTitle": "Jump to next visible comment thread",
		"quickLinksRemove": "Remove",
		"quickLinksEdit": "Edit",
		"quickLinksEditTitle": "Edit links",
		"quickLinksEditAria": "Edit launcher links",
		"quickLinksLabelPlaceholder": "Label…",
		"quickLinksLabelAria": "Launcher link label",
		"quickLinksUrlPlaceholder": "/path or URL…",
		"quickLinksUrlAria": "Launcher link destination",
		"quickLinksAdd": "Add",
		"quickLinksAddAria": "Add launcher link",
		"quickLinksSettings": "Settings",
		"quickLinksSettingsTitle": "Open settings",
		"quickLinksSettingsAriaTpl": "Open {brand} settings",
		"chaptersNoneFound": "No chapters found",
		"chapterNavLastChapter": "Last chapter",
		"commentSearchWaitingForQuery": "Waiting for comments to load for “{query}”…",
		"commentTranslateAction": "Translate",
		"commentTranslateAuto": "Auto (browser language)",
		"commentTranslateFailed": "Translation failed",
		"commentTranslateShowOriginal": "Show original",
		"commentTranslateUnavailable": "Translation unavailable in this browser",
		"commentTranslating": "Translating…",
		"commonActive": "Active",
		"commonAll": "All",
		"commonChecking": "Checking…",
		"commonClear": "Clear",
		"commonClose": "Close",
		"commonCopyFailed": "Copy failed",
		"commonDone": "Done",
		"commonExport": "Export",
		"commonImport": "Import",
		"commonJustNow": "Just now",
		"commonLoading": "Loading…",
		"commonPreparing": "Preparing…",
		"commonReady": "Ready",
		"commonRefresh": "Refresh",
		"commonReset": "Reset",
		"commonTryAgain": "Try again",
		"commonUnexpectedError": "unexpected error",
		"commonUntitled": "Untitled",
		"contextNoteAnyTab": "Quick toggles are saved now and sync when YouTube is open.",
		"contextNoteInlinePanel": "Open the settings workspace on this tab. Quick toggles apply immediately.",
		"contextNoteLaunch": "Open a watchable YouTube tab to use the full in-page workspace.",
		"contextStateAnyTab": "Any Tab",
		"contextStateAriaLabel": "Tab context",
		"contextStateLocal": "Local",
		"contextStateYouTube": "YouTube",
		"controlPlural": "controls",
		"controlSingular": "control",
		"dataFlowActive": "active",
		"dataFlowCobaltGrantPurpose": "Self-hosted Cobalt can process this video through this site until access is removed.",
		"dataFlowCreds": "creds",
		"dataFlowDriver": "driver",
		"dataFlowFilterListGrantPurpose": "Video Hider can fetch data from this site until access is removed.",
		"dataFlowGrant": "grant",
		"dataFlowGrantActive": "granted",
		"dataFlowGrantNeeded": "permission needed",
		"dataFlowGrantRemove": "Remove access",
		"dataFlowGrantRemoveAriaTpl": "Remove site access for {host}",
		"dataFlowGrantRemoveFailedTpl": "Could not remove site access for {host}.",
		"dataFlowGrantRemovedTpl": "Removed site access for {host}.",
		"dataFlowGrantedHostsCountTpl": "{count} granted",
		"dataFlowGrantedHostsTitle": "Granted site access",
		"dataFlowInactive": "idle",
		"dataFlowNote": "Active origins are highlighted. Disable the driving toggle to mute an origin entirely.",
		"dataFlowProfile": "profile",
		"dataFlowRisk": "risk",
		"dataFlowSharedGrantPurpose": "Video Hider and self-hosted Cobalt can use this site until access is removed.",
		"dataFlowSummaryTpl": "{active}/{total} origins active",
		"dataFlowTitle": "Data flow",
		"dataMgmtAria": "Data management",
		"dlCobaltButtonTitle": "Try your self-hosted Cobalt instance when Astra Downloader is offline",
		"dlCobaltFailedTpl": "Cobalt fallback failed: {error}",
		"dlCobaltInstanceRequired": "Configure a self-hosted Cobalt HTTPS origin in the toolbar popup Settings overview, then grant access to that site.",
		"dlCobaltOpened": "Cobalt fallback: opened media URL in new tab.",
		"dlCobaltProfileOnly": "Cobalt fallback is only enabled in the GitHub/full profile.",
		"dlCobaltRunningSkip": "Astra Downloader is running; fallback skipped.",
		"dlFailureTpl": "Astra Downloader: {error} {advice}",
		"dlFormatAudio320": "320kbps, universal",
		"dlFormatAudioAac": "AAC, Apple-friendly",
		"dlFormatAudioLossless": "Lossless audio",
		"dlFormatAudioOpus": "Smaller, high quality",
		"dlFormatAudioPcm": "Uncompressed PCM",
		"dlFormatVideoLossless": "Lossless container",
		"dlFormatVideoUniversal": "Universal, best compat",
		"dlFormatVideoWeb": "Web-optimized",
		"dlHealthApiTooNew": "newer than this extension",
		"dlHealthAuth": "Auth",
		"dlHealthDenoFailed": "Deno provision failed",
		"dlHealthDenoFailedLabel": "Deno: failed",
		"dlHealthDenoFailedTpl": "Deno provision failed: {error}",
		"dlHealthDenoProvisioned": "Deno provisioned successfully",
		"dlHealthDownloader": "Downloader",
		"dlHealthLegacy": "legacy",
		"dlHealthLegacyAuthTitle": "Using legacy /health token bootstrap because native messaging is unavailable.",
		"dlHealthLive": "live",
		"dlHealthNative": "native",
		"dlHealthNativeAuthTitle": "Token received over browser native messaging; /health token echo suppressed.",
		"dlHealthNotRunning": "not running",
		"dlHealthOffline": "offline",
		"dlHealthPillAriaTpl": "{label} {value}",
		"dlHealthPillTpl": "{label}: {value}",
		"dlHealthProvisioning": "Provisioning…",
		"dlHealthRegionAria": "Downloader health",
		"dlHealthSabrLimitedTitle": "Some YouTube videos use SABR-only formats that yt-dlp cannot yet download natively. See yt-dlp issue #12482.",
		"dlHealthUnknown": "unknown",
		"dlHealthUnreachable": "unreachable",
		"dlHealthUserscriptAuthTitle": "Token from the one-time userscript pairing in Astra Downloader.",
		"dlHealthUserscriptPaired": "paired",
		"dlHistoryAllFormats": "All formats",
		"dlHistoryAllStatuses": "All statuses",
		"dlHistoryButton": "History",
		"dlHistoryButtonTitle": "View recent downloads",
		"dlHistoryCloseAria": "Close recent downloads",
		"dlHistoryComplete": "Complete",
		"dlHistoryCount": "{start}-{end} of {filtered} filtered · {total} retained",
		"dlHistoryDateFromAria": "Filter history saved from date",
		"dlHistoryDateToAria": "Filter history saved through date",
		"dlHistoryEmpty": "No completed downloads yet.",
		"dlHistoryExportTruncatedTpl": "Exported the most recent {count} downloads. Narrow the filters to export older entries.",
		"dlHistoryExporting": "Exporting…",
		"dlHistoryFormatAria": "Filter history by format",
		"dlHistoryNewest": "Newest first",
		"dlHistoryNext": "Next",
		"dlHistoryNoMatches": "No downloads match these filters.",
		"dlHistoryOldest": "Oldest first",
		"dlHistoryPrevious": "Previous",
		"dlHistoryRegionAria": "Recent downloads",
		"dlHistorySearchAria": "Search download history",
		"dlHistorySearchPlaceholder": "Search title or filename",
		"dlHistorySortAria": "Sort download history",
		"dlHistoryStatusAria": "Filter history by status",
		"dlHistoryTitle": "Recent Downloads",
		"dlHistoryUnavailableCount": "History unavailable",
		"dlHistoryUnreachable": "Astra Downloader unreachable. Start Astra Downloader and try again.",
		"dlInstallApiMismatchTpl": "Astra Downloader is running, but this Astra Deck speaks an older API than it accepts{versions}. Update the extension, then choose Check again.",
		"dlInstallApiVersionsTpl": " (it needs at least API {minimum})",
		"dlInstallCheckAgain": "Check again",
		"dlInstallCheckDetail": "Use this after running the setup file.",
		"dlInstallCheckingService": "Checking for the Astra Downloader service…",
		"dlInstallCloseAria": "Close local downloader prompt",
		"dlInstallCommandCopied": "Command copied",
		"dlInstallCommandCopiedHint": "Fallback command copied. Use it in PowerShell only if the setup file cannot run.",
		"dlInstallCommandDetail": "Use only if the downloaded setup file cannot run.",
		"dlInstallConnectionCheck": "Connection check",
		"dlInstallCopyCommand": "Copy fallback command",
		"dlInstallDownloadDetail": "Recommended. Installs or repairs Astra Downloader.",
		"dlInstallDownloadSetup": "Download setup",
		"dlInstallDownloadedHint": "Setup downloaded. Open the file, finish installation, then choose Check again.",
		"dlInstallDownloadingSetup": "Downloading the setup file…",
		"dlInstallDownloadingSetupShort": "Downloading setup…",
		"dlInstallLocalDownloads": "Local downloads",
		"dlInstallNativeRequiredDesc": "Astra Downloader is running, but this version cannot hand its private token to the browser. Update it with Download setup below, then choose Check again.",
		"dlInstallNoResponse": "The service did not respond. Run setup below to repair Astra Downloader, then check again.",
		"dlInstallNotDetected": "Not detected yet",
		"dlInstallNotDetectedHint": "Setup was not detected yet. Make sure the installer finished, then check again.",
		"dlInstallNotPaired": "Not paired yet",
		"dlInstallOpenSetup": "Open setup file",
		"dlInstallOpenedHint": "The setup file should be open. Finish installation, then choose Check again.",
		"dlInstallPortConflictTpl": "Another program is answering on Astra Downloader’s port {port}{version}. It is usually a leftover downloader from an earlier install. Close it, remove it from Startup apps (look for “YTYT-Downloader” or “Astra Deck Downloader”), then start Astra Downloader and choose Check again.",
		"dlInstallPortVersionTpl": " (reporting version {version})",
		"dlInstallReconnectTitle": "Reconnect Astra Downloader",
		"dlInstallRepairDesc": "Astra Deck cannot reach the downloader service right now. Start it again if it is installed, or run setup to repair the local service.",
		"dlInstallRepairHint": "Fastest path: start the service again first. If it still does not respond, run setup to repair the install.",
		"dlInstallSetupDesc": "Enable reliable audio and video downloads by installing Astra Downloader on this device. One setup covers future downloads.",
		"dlInstallSetupHint": "Recommended path: download setup, open the file, then return here and check again.",
		"dlInstallSetupReady": "Setup ready",
		"dlInstallSetupTitle": "Set up local downloads",
		"dlInstallSkip": "Skip for now",
		"dlInstallStartDetail": "Fastest fix if the downloader is installed but idle.",
		"dlInstallStartService": "Start service",
		"dlInstallStarting": "Starting…",
		"dlInstallStartingService": "Starting the Astra Downloader service…",
		"dlInstallStepCheck": "Choose Check again so Astra Deck can confirm the service is ready.",
		"dlInstallStepDownload": "Download the Astra Downloader setup file.",
		"dlInstallStepOpen": "Open the setup file from Downloads and finish installation.",
		"dlInstallStepStart": "Start the service again if the downloader is already installed.",
		"dlInstallUserscriptNotPairedHint": "Astra Downloader is running but did not pair. Choose Pair userscript there first, then check again within two minutes.",
		"dlInstallUserscriptPairDesc": "Astra Downloader is running and needs to pair with the userscript once. In Astra Downloader, open Browser extension and choose Pair userscript, then choose Check again here within two minutes. Pairing needs Astra Downloader 2.16.0 or newer, which Download setup below installs.",
		"dlLocalOptionsTitle": "Show local download options",
		"dlPopupAria": "Download options",
		"dlPopupChange": "Change",
		"dlPopupChangeAria": "Choose a download folder",
		"dlPopupClipEndAria": "Clip end timestamp",
		"dlPopupClipEndPlaceholder": "End · 1:30",
		"dlPopupClipFormat": "Enter both clip times as seconds, MM:SS, or HH:MM:SS.",
		"dlPopupClipHint": "Leave blank for the full video. Clips are frame-accurately re-cut after download.",
		"dlPopupClipInvalid": "Enter a valid clip range with an end later than its start.",
		"dlPopupClipRange": "Clip range (optional)",
		"dlPopupClipStartAria": "Clip start timestamp",
		"dlPopupClipStartPlaceholder": "Start · 0:00",
		"dlPopupClipTooShort": "Clip must be at least 0.1 seconds long.",
		"dlPopupCtaAudio": "Download audio",
		"dlPopupCtaAudioAriaTpl": "Download audio as {format}",
		"dlPopupCtaVideo": "Download video",
		"dlPopupCtaVideoAriaTpl": "Download video as {format} at {quality}",
		"dlPopupDefault": "Default",
		"dlPopupDownloaderNotPaired": "Pair Astra Downloader with the userscript first",
		"dlPopupDownloaderOffline": "Downloader not running",
		"dlPopupFormat": "Format",
		"dlPopupFormatsAdjusted": "switched to Best",
		"dlPopupFormatsHint": "Ask Astra Downloader which resolutions this video actually has.",
		"dlPopupFormatsLoading": "Checking…",
		"dlPopupFormatsNone": "Astra Downloader reported no video streams for this URL.",
		"dlPopupFormatsProbe": "Check what's available",
		"dlPopupFormatsRecheck": "Check again",
		"dlPopupFormatsRungUnavailableTpl": "Not available. This video tops out at {max}p",
		"dlPopupFormatsSummaryTpl": "{count} formats · {min}p to {max}p available",
		"dlPopupFormatsUnavailable": "Format list unavailable.",
		"dlPopupLoading": "Loading…",
		"dlPopupOutsideRoots": "That folder is outside the allowed download locations and will be rejected. Add it to ExtraOutputRoots or pick a subfolder of your download path.",
		"dlPopupPickerUnavailable": "Folder picker unavailable",
		"dlPopupPicking": "Picking…",
		"dlPopupPlaylistClear": "Clear",
		"dlPopupPlaylistClipConflict": "Choose either a clip range or playlist items.",
		"dlPopupPlaylistHint": "Preview to choose a bounded subset. Without a selection, this video downloads normally.",
		"dlPopupPlaylistItems": "Playlist items",
		"dlPopupPlaylistListAria": "Playlist item selection",
		"dlPopupPlaylistLoading": "Loading…",
		"dlPopupPlaylistPreview": "Preview playlist",
		"dlPopupPlaylistRefresh": "Refresh preview",
		"dlPopupPlaylistSelectAll": "Select all",
		"dlPopupPlaylistSelectionTpl": "{selected} selected · {shown} shown · {total} total",
		"dlPopupPlaylistUnavailable": "Playlist preview unavailable.",
		"dlPopupQuality": "Quality",
		"dlPopupQualitySizeTitleTpl": "Estimated download size: {size}",
		"dlPopupQualitySizeTpl": "{quality} · {size}",
		"dlPopupReset": "Reset",
		"dlPopupResetAria": "Reset to default download folder",
		"dlPopupSaveTo": "Save to",
		"dlPopupTabAudioOnly": "Audio only",
		"dlPopupTabVideo": "Video",
		"dlPopupTitle": "Download options",
		"dlPopupTypeAria": "Download type",
		"dlProgressActiveEtaTpl": "{pct}% complete. {eta} remaining.",
		"dlProgressActiveTpl": "{pct}% complete. Stay on YouTube while Astra Downloader finishes.",
		"dlProgressAriaAudio": "Audio download progress",
		"dlProgressAriaVideo": "Video download progress",
		"dlProgressBadgeAudio": "Audio Download",
		"dlProgressBadgeVideo": "Video Download",
		"dlProgressCompleteCopy": "Astra Downloader finished successfully.",
		"dlProgressConnectAudio": "Connecting to Astra Downloader.",
		"dlProgressConnectVideo": "Connecting to Astra Downloader.",
		"dlProgressDismissAria": "Dismiss download progress",
		"dlProgressEtaPrefix": "ETA",
		"dlProgressFailureDefault": "Astra Downloader failed",
		"dlProgressInProgress": "In progress",
		"dlProgressLocal": "Local",
		"dlProgressLostCopy": "Astra Deck lost contact with Astra Downloader. Choose Repair downloader to recover.",
		"dlProgressLostTitle": "Connection to Astra Downloader lost",
		"dlProgressLostToast": "Lost contact with Astra Downloader.",
		"dlProgressLostTrackCopy": "Astra Downloader reported an unrecognized status. Check its window for the result.",
		"dlProgressLostTrackTitle": "Lost track of this download",
		"dlProgressPreparing": "Preparing download…",
		"dlProgressQueue": "Queue",
		"dlProgressReady": "Ready",
		"dlProgressReconnectingCopy": "Momentary hiccup with Astra Downloader. Retrying automatically.",
		"dlProgressSkippedDefault": "Nothing was downloaded.",
		"dlProgressStateComplete": "Complete",
		"dlProgressStateDownloading": "Downloading",
		"dlProgressStateError": "Error",
		"dlProgressStateFailed": "Failed",
		"dlProgressStateFinishing": "Finishing",
		"dlProgressStateLost": "Connection Lost",
		"dlProgressStateNeedsAttention": "Needs Attention",
		"dlProgressStateNothingDownloaded": "Nothing Downloaded",
		"dlProgressStatePreparing": "Preparing",
		"dlProgressStateReconnecting": "Reconnecting",
		"dlProgressStateSkipped": "Skipped",
		"dlProgressStateUnknown": "Status Unknown",
		"dlProgressWaiting": "Waiting",
		"dlProgressWrappingUp": "Wrapping up",
		"dlRepairAria": "Open Astra Downloader repair steps",
		"dlRepairBtn": "Repair downloader",
		"dlStreamButtonTitle": "Show adaptive format URLs",
		"dlStreamCopied": "Stream URL copied",
		"dlStreamCopyUrl": "Copy URL",
		"dlStreamEmpty": "No stream URLs parsed. YouTube may have served SABR-only formats. Astra Downloader handles those through youtube:formats=duplicate.",
		"dlStreamLinksTitle": "Stream Links",
		"dlStreamSabrOnly": "SABR-only",
		"dlStreamWarning": "URLs are short-lived and may not work in your browser. Use Astra Downloader or hand off to yt-dlp/VLC instead.",
		"dualSubtitleLanguageAuto": "Automatic alternate language",
		"dualSubtitleTrackAria": "Secondary subtitles",
		"dwBreakTitle": "Take a Break",
		"dwDailyLimitTitle": "Daily Limit Reached",
		"dwShortsHardBlockHint": "This hard block resets at your next local midnight.",
		"dwShortsHardBlockMessage": "You have reached your {limit}-minute Shorts budget for today. Leave Shorts to continue watching other YouTube videos.",
		"dwShortsLeaveButton": "Leave Shorts",
		"dwShortsLimitEyebrow": "Shorts Guard",
		"dwShortsLimitResetHint": "The Shorts budget resets at your next local midnight.",
		"dwShortsLimitTitle": "Shorts Limit Reached",
		"dwShortsSnoozeButton": "Snooze 5 Minutes",
		"dwShortsSnoozeMessage": "You have watched {minutes} minutes of Shorts today. Take a break, or snooze the guard for five more minutes.",
		"emptyNoMatch": "No quick toggles match",
		"emptyNoMatchHint": "Clear the filter to see every quick control again.",
		"emptyNoToggles": "No quick toggles available",
		"emptyNoTogglesHint": "The popup could not load any quick controls right now.",
		"enabledLabel": "enabled",
		"exportBtn": "Export",
		"exportFilterListBtn": "Export rules",
		"extActionTitle": "Astra Deck",
		"extDescription": "Premium watch-page customization, split layouts, content controls, and local downloads for YouTube.",
		"extName": "Astra Deck",
		"externalHealthAria": "External API health",
		"externalHealthAvailabilityTpl": "availability {state}",
		"externalHealthCopyAria": "Copy external API health report to clipboard",
		"externalHealthCopyBtn": "Copy report",
		"externalHealthCopyDone": "Copied. Paste it into a GitHub issue.",
		"externalHealthCopyFail": "Could not copy.",
		"externalHealthCopyNeedYt": "Open a YouTube tab to build the report.",
		"externalHealthCopyPending": "Building report…",
		"externalHealthDetailEmpty": "No requests observed in this tab yet.",
		"externalHealthEmpty": "No external API services tracked yet.",
		"externalHealthRefreshTpl": "refreshed {age} ago",
		"externalHealthSourceTpl": "source {source}",
		"externalHealthTitle": "External API health",
		"externalHealthTotalTpl": "{count} services",
		"failureCauseAuth": "The credentials were rejected. Check the key in Settings, then retry.",
		"failureCauseBadData": "The data could not be read. Check the file, then try again.",
		"failureCauseCancelled": "The request was cancelled.",
		"failureCauseNetwork": "The service could not be reached. Check your connection, then try again.",
		"failureCauseNotFound": "That item was not found. It may have moved or been removed.",
		"failureCauseOffline": "Your device looks offline. Reconnect, then try again.",
		"failureCausePermission": "Access was not granted. Allow it, then retry.",
		"failureCauseRateLimit": "Too many requests were sent. Wait a minute, then try again.",
		"failureCauseServer": "The service reported an error on its side. Try again later.",
		"failureCauseStorage": "There is not enough storage space. Free some space, then try again.",
		"failureCauseTimeout": "The request took too long. Try again in a moment.",
		"failureCauseTooLarge": "The data is too large to handle. Use a smaller file.",
		"failureCauseUnknown": "Something unexpected went wrong. The diagnostic log has the details.",
		"failureCauseUnsupported": "This browser cannot run that feature. Update it, then retry.",
		"featureHealthAgeDaysTpl": "{count}d ago",
		"featureHealthAgeHoursTpl": "{count}h ago",
		"featureHealthAgeMinutesTpl": "{count}m ago",
		"featureHealthAgeSecondsTpl": "{count}s ago",
		"featureHealthAllWellTpl": "{healthy} features working",
		"featureHealthDegradedTpl": "{count} degraded",
		"featureHealthEmpty": "No enabled features sampled yet.",
		"featureHealthFailedTpl": "{count} failed",
		"featureHealthHealthyTpl": "{count} working",
		"featureHealthMoreTpl": "+{count} more",
		"featureHealthNote": "Degraded means the feature loaded but something it depends on stopped answering. Reload YouTube to re-check.",
		"featureHealthReasonAntiAdblockTpl": "YouTube warning via {selector}; playback {state}",
		"featureHealthReasonApiTpl": "{service}: {detail}",
		"featureHealthReasonCanaryTpl": "YouTube {version} changed {surface}",
		"featureHealthReasonSelectorFallbackTpl": "Page element “{surface}” only matched a backup rule",
		"featureHealthReasonSelectorTpl": "Page element “{surface}” no longer found",
		"featureHealthStatusDegraded": "Degraded",
		"featureHealthStatusFailed": "Failed",
		"featureHealthStatusHealthy": "Working",
		"featureHealthStatusIdle": "Not active here",
		"featureHealthTitle": "Feature health",
		"featurePerfAria": "Feature performance",
		"featurePerfEmpty": "No features initialized yet.",
		"featurePerfTitle": "Feature init timing",
		"featurePerfTotalTpl": "{count} features measured",
		"featureReportChangedTpl": "Settings changed from their defaults ({count}):",
		"featureReportCopy": "Copy feature list",
		"featureReportCopyDone": "Feature list copied. Nothing was sent anywhere.",
		"featureReportCopyFail": "Could not copy the feature list.",
		"featureReportCopyTitle": "Copies setting names only, never their values. Nothing is sent anywhere.",
		"featureReportNoneChanged": "none",
		"featureReportPrivacyNote": "Names only, no values. Nothing was sent anywhere. This is on your clipboard and you decide whether to paste it.",
		"featureScheduleDaysTpl": "Active {window} on {days}",
		"featureScheduleEveryDayTpl": "Active {window} every day",
		"feature_abHide_ask_desc": "Hide Ask or AI button below videos",
		"feature_abHide_ask_name": "Ask/AI Button",
		"feature_abHide_clip_desc": "Hide clip button below videos",
		"feature_abHide_clip_name": "Clip Button",
		"feature_abHide_like_desc": "Hide like button below videos",
		"feature_abHide_like_name": "Like Button",
		"feature_abHide_moreActions_desc": "Hide more actions button below videos",
		"feature_abHide_moreActions_name": "More Actions (…)",
		"feature_abHide_save_desc": "Hide save button below videos",
		"feature_abHide_save_name": "Save Button",
		"feature_abHide_share_desc": "Hide share button below videos",
		"feature_abHide_share_name": "Share Button",
		"feature_abHide_sponsor_desc": "Hide join/sponsor button below videos",
		"feature_abHide_sponsor_name": "Join/Sponsor Button",
		"feature_abHide_thanks_desc": "Hide thanks button below videos",
		"feature_abHide_thanks_name": "Thanks Button",
		"feature_abLoop_desc": "Set two points on the video timeline and loop between them. Visual markers on the progress bar.",
		"feature_abLoop_name": "A-B Loop",
		"feature_actionToasts_desc": "Show a short popup after actions like hiding a video, marking one as watched or skipping a chapter. Off by default. Warnings and errors still pop up, screen readers still hear every notice, and the settings panel keeps its own confirmations.",
		"feature_actionToasts_name": "Action Notices",
		"feature_adaptiveLiveLayout_desc": "Automatically adjust layout for live stream chat side-by-side",
		"feature_adaptiveLiveLayout_name": "Adaptive Live Layout",
		"feature_ageRestrictionBypass_desc": "Bypass age verification by fetching video data from YouTube’s embed endpoint. No sign-in required.",
		"feature_ageRestrictionBypass_name": "Age Restriction Bypass",
		"feature_aiVideoSummary_desc": "Bring-your-own-key LLM summary of the current video transcript (OpenAI/Anthropic/Gemini/Ollama)",
		"feature_aiVideoSummary_name": "AI Video Summary",
		"feature_alwaysShowProgressBar_desc": "Keep the video progress bar visible at all times instead of hiding on idle",
		"feature_alwaysShowProgressBar_name": "Always Show Progress Bar",
		"feature_antiTranslateAudioTrack_desc": "When YouTube serves an auto-dubbed track, select the original through the reviewed player bridge.",
		"feature_antiTranslateAudioTrack_name": "Anti-Translate Audio Track",
		"feature_antiTranslateChapters_desc": "Restores original-language chapter titles in the chapter list and the player hover label. Reads them from the original description, which is where YouTube builds chapters from in the first place.",
		"feature_antiTranslateChapters_name": "Anti-Translate Chapters",
		"feature_antiTranslateThumbnails_desc": "Restore the original-language thumbnail image on cards whose text was localised. Uses the player response on the watch page and YouTube's own same-origin oEmbed endpoint elsewhere, so it needs no extra site access.",
		"feature_antiTranslateThumbnails_name": "Anti-Translate Thumbnails",
		"feature_antiTranslateTranscript_desc": "Strips translation track parameters from the engagement-panel transcript URL so YouTube serves the original-language captions. Best-effort; works when the original-language track is available.",
		"feature_antiTranslateTranscript_name": "Anti-Translate Transcript",
		"feature_antiTranslate_desc": "Prevent YouTube from auto-translating video titles AND descriptions to your locale. Restores the original-language text on grid thumbnails + watch page.",
		"feature_antiTranslate_name": "Anti-Translate (Original Titles + Descriptions)",
		"feature_astraContextMenu_desc": "Right-click the player or a feed card to get Astra actions: Hide channel, Copy video URL, Copy timestamp link, Open transcript. Default off. On those two surfaces it replaces the native right-click menu; everywhere else on the page the browser menu is untouched.",
		"feature_astraContextMenu_name": "Astra Context Menu",
		"feature_audioAutoGain_desc": "Balance quiet videos toward a comfortable listening level with a bounded, adaptive Web Audio gain stage.",
		"feature_audioAutoGain_name": "Audio Auto-Gain",
		"feature_audioEqHighGainDb_desc": "High-shelf gain centered at 8 kHz, from -12 dB to +12 dB.",
		"feature_audioEqHighGainDb_name": "EQ High Band",
		"feature_audioEqLowGainDb_desc": "Low-shelf gain centered at 120 Hz, from -12 dB to +12 dB.",
		"feature_audioEqLowGainDb_name": "EQ Low Band",
		"feature_audioEqMidGainDb_desc": "Peaking gain centered at 1 kHz, from -12 dB to +12 dB.",
		"feature_audioEqMidGainDb_name": "EQ Mid Band",
		"feature_audioHighPass_desc": "Reduce muddy low-frequency rumble with an 80 Hz high-pass filter in the MAIN-world audio graph.",
		"feature_audioHighPass_name": "Audio High-Pass Filter",
		"feature_audioNormalization_desc": "Compress dynamic range so quiet and loud passages play at similar volume. Uses a DynamicsCompressorNode in the MAIN world audio graph.",
		"feature_audioNormalization_name": "Audio Normalization",
		"feature_audioOnlyPlayback_desc": "Collapse the video and ask the player for the cheapest stream it has, so a watch page costs roughly what a podcast does. YouTube exposes no true audio-only stream to extensions, so the pill reports whether you got one or just the lowest quality. Works on live streams too, where a multi-hour session makes the saving largest.",
		"feature_audioOnlyPlayback_name": "Audio-Only Mode",
		"feature_audioPan_desc": "Shift audio balance left or right via a StereoPannerNode in the MAIN world audio graph. Range -1 (full left) to 1 (full right), 0 = center.",
		"feature_audioPan_name": "Audio Pan",
		"feature_audioParametricEq_desc": "Apply a three-band low, mid, and high EQ in the MAIN-world audio graph. Off by default; each band is bounded to -12 dB to +12 dB.",
		"feature_audioParametricEq_name": "Parametric EQ",
		"feature_audioSyncOffsetMs_desc": "Adjust audio timing relative to video from -500 ms to +500 ms. Positive values add audio delay; negative values use the minimum available Web Audio latency.",
		"feature_audioSyncOffsetMs_name": "Audio Sync Offset",
		"feature_audioTrackLanguage_desc": "Select your preferred audio language through the player bridge without opening or clicking YouTube settings.",
		"feature_audioTrackLanguage_name": "Preferred Audio Track Language",
		"feature_autoClosePopups_desc": "Automatically dismisses cookie consent, survey prompts, and other YouTube popups",
		"feature_autoClosePopups_name": "Auto-Close Popups",
		"feature_autoDismissContentWarning_desc": "Automatically clicks \"I understand and wish to proceed\" on videos with content warnings",
		"feature_autoDismissContentWarning_name": "Auto-Dismiss Content Warnings",
		"feature_autoDismissStillWatching_desc": "Automatically clicks the \"Continue Watching\" button when YouTube pauses playback for inactivity",
		"feature_autoDismissStillWatching_name": "Auto-Dismiss \"Still Watching?\"",
		"feature_autoDownloadOnVisit_desc": "Automatically start download when visiting a video page",
		"feature_autoDownloadOnVisit_name": "Auto-Download Videos",
		"feature_autoExitFullscreen_desc": "Leave fullscreen automatically when a video finishes, unless a playlist or queue advances to a next video",
		"feature_autoExitFullscreen_name": "Auto-Exit Fullscreen at End",
		"feature_autoExpandComments_desc": "Automatically expand truncated comments so full text is always visible",
		"feature_autoExpandComments_name": "Auto-Expand Comments",
		"feature_autoExpandDescription_desc": "Automatically expands the video description so you never need to click \"Show more\"",
		"feature_autoExpandDescription_name": "Auto-Expand Description",
		"feature_autoLikeSubscribed_desc": "Automatically like videos from channels you’re subscribed to after watching for 30 seconds",
		"feature_autoLikeSubscribed_name": "Auto-Like Subscribed Channels",
		"feature_autoMaxResolution_desc": "Force the highest available stream on every video (1080p Premium when offered)",
		"feature_autoMaxResolution_name": "Always Best Quality",
		"feature_autoOpenChapters_desc": "Automatically open the chapters panel when available",
		"feature_autoOpenChapters_name": "Auto-Open Chapters",
		"feature_autoOpenTranscript_desc": "Automatically open the transcript panel when available",
		"feature_autoOpenTranscript_name": "Auto-Open Transcript",
		"feature_autoPauseOnSwitch_desc": "Pauses playback when you switch to another tab, resumes when you return",
		"feature_autoPauseOnSwitch_name": "Auto-Pause on Tab Switch",
		"feature_autoSkipChapters_desc": "Automatically skip chapters matching patterns (intro, outro, recap, sponsor). Comma-separated.",
		"feature_autoSkipChapters_name": "Auto-Skip Chapters",
		"feature_autoSubtitlesWhenMuted_desc": "Turn captions on automatically while the video is muted and restore the previous caption state on unmute",
		"feature_autoSubtitlesWhenMuted_name": "Subtitles While Muted",
		"feature_autoSubtitles_desc": "Automatically turns on closed captions when a video starts playing",
		"feature_autoSubtitles_name": "Auto-Enable Subtitles",
		"feature_autoTheaterMode_desc": "Automatically enter theater (wide) mode when opening a video",
		"feature_autoTheaterMode_name": "Auto Theater Mode",
		"feature_blueLightFilter_desc": "Apply a warm tint to reduce blue light emission. Configurable intensity.",
		"feature_blueLightFilter_name": "Blue Light Filter",
		"feature_blueLightIntensity_desc": "Set the strength of the warm tint when Blue Light Filter is enabled.",
		"feature_blueLightIntensity_name": "Blue Light Intensity",
		"feature_bulkCardActions_desc": "Toggle select-mode to multi-pick feed cards, then bulk hide, allow, copy URLs, or run a bounded recommendation scrub (\"Not interested\" / \"Don't recommend channel\") with a local session log and undo.",
		"feature_bulkCardActions_name": "Bulk Card Actions",
		"feature_bypassPlaylistMode_desc": "Strip the &list= parameter from clicked thumbnails so you don’t get stuck inside someone’s playlist",
		"feature_bypassPlaylistMode_name": "Bypass Playlist Mode on Clicks",
		"feature_channelAgeDisplay_desc": "Shows how old a video is (e.g. \"2 years, 3 months ago\") next to the upload date.",
		"feature_channelAgeDisplay_name": "Video Age Display",
		"feature_channelSubCount_desc": "Shows the channel subscriber count more prominently below videos",
		"feature_channelSubCount_name": "Enhanced Channel Info",
		"feature_chapterJumpButtons_desc": "Prev/Next chapter buttons in the player right-controls, so you can skip to the previous or next chapter",
		"feature_chapterJumpButtons_name": "Chapter Jump Buttons",
		"feature_chapterNavButtons_desc": "Add Previous/Next Chapter buttons to the video player controls",
		"feature_chapterNavButtons_name": "Chapter Navigation",
		"feature_chatHide_banner_desc": "Hide chat banners",
		"feature_chatHide_banner_name": "Chat Banner",
		"feature_chatHide_bots_desc": "Filter out known bot messages",
		"feature_chatHide_bots_name": "Bot Messages",
		"feature_chatHide_emoji_desc": "Hide emoji picker button",
		"feature_chatHide_emoji_name": "Emoji Button",
		"feature_chatHide_header_desc": "Hide the live chat header bar",
		"feature_chatHide_header_name": "Chat Header",
		"feature_chatHide_leaderboard_desc": "Hide chat leaderboard",
		"feature_chatHide_leaderboard_name": "Leaderboard",
		"feature_chatHide_levelUp_desc": "Hide level up messages",
		"feature_chatHide_levelUp_name": "Level Up Messages",
		"feature_chatHide_menu_desc": "Hide the chat overflow menu",
		"feature_chatHide_menu_name": "Chat Menu (…)",
		"feature_chatHide_modeNotices_desc": "Hide the \"slow mode is on\" notice and its members-only siblings",
		"feature_chatHide_modeNotices_name": "Mode Notices",
		"feature_chatHide_polls_desc": "Hide polls in live chat",
		"feature_chatHide_polls_name": "Polls & Poll Banner",
		"feature_chatHide_popout_desc": "Hide the popout chat button",
		"feature_chatHide_popout_name": "Popout Button",
		"feature_chatHide_reactions_desc": "Hide chat reactions panel",
		"feature_chatHide_reactions_name": "Reactions",
		"feature_chatHide_superChats_desc": "Hide super chat messages",
		"feature_chatHide_superChats_name": "Super Chats",
		"feature_chatHide_support_desc": "Hide support/buy buttons in chat",
		"feature_chatHide_support_name": "Support Buttons",
		"feature_chatHide_ticker_desc": "Hide the super chat ticker",
		"feature_chatHide_ticker_name": "Super Chat Ticker",
		"feature_chatHide_timestamps_desc": "Hide chat timestamps",
		"feature_chatHide_timestamps_name": "Timestamps",
		"feature_chatHide_topFan_desc": "Hide fan/member badges",
		"feature_chatHide_topFan_name": "Fan Badges",
		"feature_chatKeywordFilter_desc": "Hide chat messages containing these words (comma-separated)",
		"feature_chatKeywordFilter_name": "Chat Keyword Filter",
		"feature_chatStyleComments_desc": "Premium comment layout that preserves pinned comments, creator hearts, replies, and native actions",
		"feature_chatStyleComments_name": "Studio Comments",
		"feature_chronologicalNotifications_desc": "Sort notifications chronologically (newest first)",
		"feature_chronologicalNotifications_name": "Sort Notifications",
		"feature_cinemaAmbientGlow_desc": "Projects dominant video colors as a soft glow behind the player for an immersive cinema feel",
		"feature_cinemaAmbientGlow_name": "Cinema Ambient Glow",
		"feature_classicLayoutProfile_desc": "Pick a layout profile. Modern keeps YouTube’s 2025 layout. Classic 2020 restores tighter spacing and the smaller masthead. Classic 2016 restores the older watch page proportions.",
		"feature_classicLayoutProfile_name": "Layout Profile",
		"feature_classicPlayerChrome_desc": "One-toggle restoration of the pre-Delhi/Liquid Glass player look: opaque square controls, classic progress bar, original time display. CSS-only, no DOM rebuild.",
		"feature_classicPlayerChrome_name": "Classic Player Chrome",
		"feature_cleanShareUrls_desc": "Strip tracking params (si, pp, feature) from copied/shared YouTube links",
		"feature_cleanShareUrls_name": "Clean Share URLs",
		"feature_cleanUiPreset_desc": "Owner preset: hides panel branding, search, and category headers, compresses navigation, silences toast notifications, and hides the subscriptions resume banner. Off by default.",
		"feature_cleanUiPreset_name": "Compact Clean UI",
		"feature_codecSelector_desc": "Choose which video codec to prefer: Auto, Power-efficient (ask this device), H.264 (low CPU), VP9, or AV1 (best quality). Shares codec engine with Force H.264.",
		"feature_codecSelector_name": "Codec Selector",
		"feature_colorThemeManager_desc": "Apply a color palette across YouTube (dark mode only)",
		"feature_colorThemeManager_name": "Color Theme",
		"feature_commentAuthorBlock_desc": "Adds Block to the menu on every comment. Comments and replies from a blocked author stay hidden on every video.",
		"feature_commentAuthorBlock_name": "Block Comment Authors",
		"feature_commentBlockedAuthors_desc": "One author per line: an @handle, a channel id, or a channel link. Delete a line to unblock that author.",
		"feature_commentBlockedAuthors_name": "Blocked Comment Authors",
		"feature_commentDuplicateCollapse_desc": "Collapse near-duplicate comments under an accessible expander using local text comparison only.",
		"feature_commentDuplicateCollapse_name": "Collapse Similar Comments",
		"feature_commentEnhancements_desc": "Highlight creator/OP replies, show like heat indicators, and add collapse-all-replies toggle per thread",
		"feature_commentEnhancements_name": "Comment Enhancements",
		"feature_commentFilterManager_desc": "Hide comment threads whose author or text matches a rule. Comma-separated keywords, !word to allowlist, or /pattern/flags for regex (ReDoS-guarded).",
		"feature_commentFilterManager_name": "Comment Filter",
		"feature_commentFilterRules_desc": "One rule per line or comma-separated. word hides matches, !word always allows, @author targets the author, /pattern/i runs a regex (ReDoS-guarded).",
		"feature_commentFilterRules_name": "Comment Filter Rules",
		"feature_commentLanguageAllowlist_desc": "Show only comments in these language codes, such as en, es, or fr. Leave empty to allow every language; detection stays local and fails open when uncertain.",
		"feature_commentLanguageAllowlist_name": "Comment Language Allowlist",
		"feature_commentNavigator_desc": "Floating thread navigator with live counts for visible comments and filtered results",
		"feature_commentNavigator_name": "Comment Navigator",
		"feature_commentSearch_desc": "Adds a search bar above comments to filter and find specific comments",
		"feature_commentSearch_name": "Comment Search",
		"feature_commentTranslateTarget_desc": "Language to translate comments into. Auto follows your browser language.",
		"feature_commentTranslateTarget_name": "Translate Comments Into",
		"feature_commentTranslate_desc": "Adds a Translate link under comments that are not already in your language, using Chrome’s built-in on-device Translator. Nothing is sent to a server and no API key is needed; when the browser has no Translator the link says so instead of failing quietly.",
		"feature_commentTranslate_name": "Translate Comments",
		"feature_compactLayout_desc": "Reduce spacing and padding for a denser interface",
		"feature_compactLayout_name": "Compact Layout",
		"feature_compactUnfixedHeader_desc": "Reduce header height and let it scroll away instead of staying fixed",
		"feature_compactUnfixedHeader_name": "Compact / Unfixed Header",
		"feature_condenseComments_desc": "Reduce spacing between comments for a tighter layout",
		"feature_condenseComments_name": "Condense Comments",
		"feature_copyChapterMarkdown_desc": "Copy all video chapters as a markdown timestamp list, from a button in the player controls",
		"feature_copyChapterMarkdown_name": "Copy Chapters as Markdown",
		"feature_copyVideoTitle_desc": "Adds a copy button next to the video title for one-click title copying",
		"feature_copyVideoTitle_name": "Copy Video Title Button",
		"feature_creatorCommentHighlight_desc": "Makes creator-badged and creator-hearted comments stand out with a stronger visual treatment",
		"feature_creatorCommentHighlight_name": "Highlight Creator Comments",
		"feature_customCssCode_desc": "CSS applied while Custom CSS is enabled",
		"feature_customCssCode_name": "Custom CSS Rules",
		"feature_customCssInjection_desc": "Inject your own custom CSS rules into YouTube pages",
		"feature_customCssInjection_name": "Custom CSS",
		"feature_customProgressBarColor_desc": "Change the red progress bar to any color",
		"feature_customProgressBarColor_name": "Custom Progress Bar Color",
		"feature_customSelectionColor_desc": "Override the default text-selection background with your chosen color",
		"feature_customSelectionColor_name": "Custom Text Selection Color",
		"feature_customSpeedButtons_desc": "Adds quick speed buttons below the video player with presets from 0.5x to 3x",
		"feature_customSpeedButtons_name": "Speed Preset Buttons",
		"feature_daCacheTTL_desc": "Hours to cache branding data locally before refreshing",
		"feature_daCacheTTL_name": "Cache Duration",
		"feature_daFallbackFormat_desc": "Format the original title when no crowdsourced submission exists",
		"feature_daFallbackFormat_name": "Format Original Titles",
		"feature_daReplaceThumbs_desc": "Replace clickbait thumbnails with video screenshots",
		"feature_daReplaceThumbs_name": "Replace Thumbnails",
		"feature_daReplaceTitles_desc": "Replace clickbait titles with crowdsourced alternatives",
		"feature_daReplaceTitles_name": "Replace Titles",
		"feature_daShowOriginalHover_desc": "Hover over a replaced title to see the original",
		"feature_daShowOriginalHover_name": "Show Original on Hover",
		"feature_daShowOriginalTitle_desc": "Show the original title beneath the DeArrow replacement",
		"feature_daShowOriginalTitle_name": "Show Original Title",
		"feature_daSurfaceHome_desc": "Use DeArrow on the YouTube home feed",
		"feature_daSurfaceHome_name": "Home Feed",
		"feature_daSurfacePlaylist_desc": "Use DeArrow on playlist pages and in the watch-page playlist panel",
		"feature_daSurfacePlaylist_name": "Playlists",
		"feature_daSurfaceRelated_desc": "Use DeArrow in the recommendations beside a video",
		"feature_daSurfaceRelated_name": "Related Videos",
		"feature_daSurfaceSearch_desc": "Use DeArrow in YouTube search results",
		"feature_daSurfaceSearch_name": "Search Results",
		"feature_daSurfaceSubscriptions_desc": "Use DeArrow in the subscriptions feed",
		"feature_daSurfaceSubscriptions_name": "Subscriptions Feed",
		"feature_daSurfaceWatch_desc": "Use DeArrow on the primary video and its metadata",
		"feature_daSurfaceWatch_name": "Watch Page",
		"feature_daThumbFallback_desc": "What replaces a thumbnail nobody has submitted to DeArrow yet. Random frame matches DeArrow itself, and the stills are frames YouTube takes from every upload.",
		"feature_daThumbFallback_name": "Covers Without a Submission",
		"feature_daTitleFormat_desc": "How to format replacement titles",
		"feature_daTitleFormat_name": "Title Format",
		"feature_deArrowCasualMode_desc": "Keep descriptive titles unchanged and only replace titles that have crowd-submitted DeArrow alternatives",
		"feature_deArrowCasualMode_name": "Casual Mode",
		"feature_deArrowChannelOverridesPanel_desc": "Adds a small DeArrow mode chip next to the channel name on the watch page. Cycles through DeArrow → Original → Off → DeArrow per click. Overrides persist in deArrowChannelOverrides keyed by channel ID.",
		"feature_deArrowChannelOverridesPanel_name": "DeArrow Per-Channel Overrides",
		"feature_deArrow_desc": "Replace clickbait titles and thumbnails with SponsorBlock data licensed under CC BY-NC-SA 4.0",
		"feature_deArrow_name": "DeArrow",
		"feature_dearrowPeekButton_desc": "Hold Alt to temporarily reveal original YouTube titles (undoes DeArrow/custom titles while pressed)",
		"feature_dearrowPeekButton_name": "DeArrow Peek Button",
		"feature_debugMode_desc": "Enable verbose diagnostic logging to the console",
		"feature_debugMode_name": "Debug Mode",
		"feature_denseMode_desc": "Tightens row spacing, padding, and font metrics across Astra-injected surfaces. It doesn’t change YouTube’s native layout, only our own panels, chips, pills, and toolbars.",
		"feature_denseMode_name": "Dense Mode",
		"feature_diagnosticLog_desc": "Capture a rolling log of YTKit errors and export as JSON for bug reports",
		"feature_diagnosticLog_name": "Diagnostic Error Log",
		"feature_digitalWellbeing_desc": "Break reminders every N minutes of active playback + optional daily watch-time cap. Timers persist across SPA navigation.",
		"feature_digitalWellbeing_name": "Digital Wellbeing",
		"feature_disableAutoplayNext_desc": "Prevents the next video from automatically playing when the current one finishes",
		"feature_disableAutoplayNext_name": "Disable Autoplay Next Video",
		"feature_disableInfiniteScroll_desc": "Replace infinite scroll with a \"Load More\" button on home, search, and subscriptions pages",
		"feature_disableInfiniteScroll_name": "Disable Infinite Scroll",
		"feature_disableLoudnessNormalization_desc": "Stop YouTube nudging the player volume back down below 100%. This does NOT disable YouTube’s loudness normalization, which runs in a Web Audio node an extension can’t reach, so quiet videos stay quiet. Only the volume slider stops drifting.",
		"feature_disableLoudnessNormalization_name": "Keep Volume At Full",
		"feature_disableMiniPlayer_desc": "Prevent the mini player from appearing when navigating away",
		"feature_disableMiniPlayer_name": "Disable Mini Player",
		"feature_disablePlayOnHover_desc": "Stop videos from playing when hovering over thumbnails",
		"feature_disablePlayOnHover_name": "Disable Hover Preview",
		"feature_disableSpaNavigation_desc": "Force full page loads instead of YouTube’s smooth transitions (fixes player sizing issues)",
		"feature_disableSpaNavigation_name": "Disable SPA Navigation",
		"feature_downloadAudioFormat_desc": "Default format for audio-only downloads",
		"feature_downloadAudioFormat_name": "Audio Format",
		"feature_downloadCobaltFallback_desc": "When Astra Downloader is unreachable, use a self-hosted Cobalt HTTPS instance after setting its origin in the toolbar popup and granting access to that one site. No public Cobalt instance is included.",
		"feature_downloadCobaltFallback_name": "Self-Hosted Cobalt Fallback",
		"feature_downloadHealthPanel_desc": "Show pills for Astra Downloader yt-dlp version, ffmpeg freshness, and PO Token provider state next to the download button. Reads /health every 30 s; no extra storage.",
		"feature_downloadHealthPanel_name": "Downloader Health Pills",
		"feature_downloadHistoryPanel_desc": "Adds a \"History\" button next to the download button on watch pages. Lists the last 50 downloads recorded by Astra Downloader. Local only, fetched from the local /history endpoint once per session.",
		"feature_downloadHistoryPanel_name": "Download History Panel",
		"feature_downloadQuality_desc": "Preferred video quality for downloads",
		"feature_downloadQuality_name": "Download Quality",
		"feature_downloadScreenshotFormat_desc": "Output format for the player screenshot button. PNG is lossless and copies to clipboard; JPEG/WebP are smaller files but download-only.",
		"feature_downloadScreenshotFormat_name": "Screenshot Format",
		"feature_downloadStreamLinksPanel_desc": "Advanced: expose the raw adaptive video/audio stream URLs (mp4/webm) parsed from ytInitialPlayerResponse. Local only, no telemetry. Useful for yt-dlp or VLC handoff. Default off.",
		"feature_downloadStreamLinksPanel_name": "Stream Links Panel",
		"feature_downloadSubtitlesWithScreenshot_desc": "Bake the currently rendered caption line into the bottom band of the screenshot. Off by default. Requires Video Screenshot.",
		"feature_downloadSubtitlesWithScreenshot_name": "Include Subtitles In Screenshot",
		"feature_downloadThumbnail_desc": "Adds a button below the video to download the current video thumbnail in max resolution",
		"feature_downloadThumbnail_name": "Download Thumbnail Button",
		"feature_downloadVideoFormat_desc": "Default container format for video downloads",
		"feature_downloadVideoFormat_name": "Video Format",
		"feature_dualLanguageSubtitles_desc": "Show an independently selected second caption track below YouTube captions when available",
		"feature_dualLanguageSubtitles_name": "Dual-language Subtitles",
		"feature_dualSubtitleLanguage_desc": "Choose the caption language rendered below native YouTube captions",
		"feature_dualSubtitleLanguage_name": "Second Subtitle Language",
		"feature_elementZapper_desc": "Click a shelf, panel, or promo to hide it, and keep hiding it.",
		"feature_elementZapper_name": "Element Zapper",
		"feature_enableCPU_Tamer_desc": "Reduce CPU usage by throttling background timers; in hidden tabs it also force-releases YouTube web locks and closes idle database connections",
		"feature_enableCPU_Tamer_name": "CPU Tamer",
		"feature_enableHandleRevealer_desc": "Show the original channel name next to @handle in comments",
		"feature_enableHandleRevealer_name": "Comment Handle Revealer",
		"feature_expandVideoWidth_desc": "Stretch the video to fill the space when sidebar is hidden",
		"feature_expandVideoWidth_name": "Expand Video Width",
		"feature_featureDisableFeed_desc": "Pause features the project has confirmed broken by a YouTube change, until a fix ships. Fetches a small text file from the Astra Deck repository; it can only ever pause a feature, never enable one.",
		"feature_featureDisableFeed_name": "Known-Breakage Notices",
		"feature_feedPrefilter_desc": "Remove blocked channels from YouTube's feed data before the page builds a card from it, instead of hiding the card afterwards. Playlists and the video player are never touched.",
		"feature_feedPrefilter_name": "Filter Feeds Before Render",
		"feature_feedTriageProfile_desc": "Flip on a curated focus recipe: hides Shorts, live streams, upcoming premieres, mixes, watched videos, and AI Summary. Toggling off restores prior values.",
		"feature_feedTriageProfile_name": "Feed Triage Profile",
		"feature_fineSpeedControl_desc": "Extend speed range to 0.1x-16x with 0.05x increments. Scroll on the speed badge to adjust.",
		"feature_fineSpeedControl_name": "Fine Speed Control",
		"feature_fitPlayerToWindow_desc": "Make the video player fill the entire browser window",
		"feature_fitPlayerToWindow_name": "Fit Player to Window",
		"feature_floatingLogoOnWatch_desc": "Replace native player right-controls with Astra quick links, local tools, and settings",
		"feature_floatingLogoOnWatch_name": "Astra Player Dock",
		"feature_focusedMode_desc": "Hides everything except the video player and comments for a distraction-free experience",
		"feature_focusedMode_name": "Focused Mode",
		"feature_forceDarkEverywhere_desc": "Applies dark theme to YouTube pages that may not respect dark mode (settings, about, etc.)",
		"feature_forceDarkEverywhere_name": "Force Dark on All YouTube Pages",
		"feature_forceDvr_desc": "Ask YouTube to expose rewind for live streams that advertise DVR as disabled. Experimental and off by default; if the player response changes shape, Astra Deck leaves it untouched and reports the degradation.",
		"feature_forceDvr_name": "Force DVR for Live Streams",
		"feature_forceH264_desc": "Prefer H.264 (AVC) over VP9/AV1 for lower CPU usage on older hardware. May reduce max quality. Uses MAIN world codec bridge.",
		"feature_forceH264_name": "Force H.264 Codec",
		"feature_forceStandardFps_desc": "Dims HFR entries in the quality menu. For reliable 30fps, enable Force H.264 which caps at 1080p30.",
		"feature_forceStandardFps_name": "Force Standard Frame Rate",
		"feature_forcedColorsSupport_desc": "Always active: when the OS reports forced-colors (Windows High Contrast, GTK forced colors), Astra-injected controls automatically use system colors so text remains readable and focus rings are visible. The media query itself is the gate; this toggle is retained for settings compatibility and has no additional effect.",
		"feature_forcedColorsSupport_name": "Forced Colors / High Contrast Support",
		"feature_frameByFrameButtons_desc": "Add visible step-back (,) and step-forward (.) buttons to the player controls for precise frame navigation",
		"feature_frameByFrameButtons_name": "Frame-by-Frame Buttons",
		"feature_fullTitles_desc": "Remove the 2-line clamp on thumbnail titles so long titles show in full",
		"feature_fullTitles_name": "Show Full Video Titles",
		"feature_fullWidthSubscriptions_desc": "Expand the subscription grid to fill the page",
		"feature_fullWidthSubscriptions_name": "Full-Width Subscriptions",
		"feature_fullscreenOnDoubleClick_desc": "Double-click anywhere on the video to toggle fullscreen (replaces default seek behavior)",
		"feature_fullscreenOnDoubleClick_name": "Double-Click Fullscreen",
		"feature_fullscreenScroll_desc": "Scroll down while fullscreen to read the description, comments, and related videos; scroll back up to return to the video",
		"feature_fullscreenScroll_name": "Scroll in Fullscreen",
		"feature_globalAriaLiveRegion_desc": "Mounts a single hidden role=status / aria-live=polite container under the document body. Screen readers announce any text Astra writes into it (toast bodies, filter outcomes, download status changes).",
		"feature_globalAriaLiveRegion_name": "Live Region For Toasts",
		"feature_grayscaleThumbnails_desc": "Shows thumbnails in grayscale to reduce visual distraction. Color comes back on hover.",
		"feature_grayscaleThumbnails_name": "Grayscale Thumbnails",
		"feature_guideHide_footer_desc": "Hide the Guide footer links",
		"feature_guideHide_footer_name": "Footer",
		"feature_guideHide_gaming_desc": "Hide the Gaming entry",
		"feature_guideHide_gaming_name": "Gaming",
		"feature_guideHide_help_desc": "Hide the Help entry",
		"feature_guideHide_help_name": "Help",
		"feature_guideHide_history_desc": "Hide the History entry",
		"feature_guideHide_history_name": "History",
		"feature_guideHide_home_desc": "Hide the Home entry in the Guide",
		"feature_guideHide_home_name": "Home",
		"feature_guideHide_learning_desc": "Hide the Learning topic entry",
		"feature_guideHide_learning_name": "Learning",
		"feature_guideHide_likedVideos_desc": "Hide the Liked Videos entry",
		"feature_guideHide_likedVideos_name": "Liked Videos",
		"feature_guideHide_live_desc": "Hide the Live topic entry",
		"feature_guideHide_live_name": "Live",
		"feature_guideHide_movies_desc": "Hide the Movies & TV entry",
		"feature_guideHide_movies_name": "Movies & TV",
		"feature_guideHide_music_desc": "Hide the Music topic entry",
		"feature_guideHide_music_name": "Music",
		"feature_guideHide_news_desc": "Hide the News topic entry",
		"feature_guideHide_news_name": "News",
		"feature_guideHide_playlists_desc": "Hide the Playlists entry",
		"feature_guideHide_playlists_name": "Playlists",
		"feature_guideHide_premium_desc": "Hide the YouTube Premium entry",
		"feature_guideHide_premium_name": "YouTube Premium",
		"feature_guideHide_reportHistory_desc": "Hide the Report History entry",
		"feature_guideHide_reportHistory_name": "Report History",
		"feature_guideHide_settings_desc": "Hide the Settings entry",
		"feature_guideHide_settings_name": "Settings",
		"feature_guideHide_sports_desc": "Hide the Sports topic entry",
		"feature_guideHide_sports_name": "Sports",
		"feature_guideHide_studio_desc": "Hide the YouTube Studio entry",
		"feature_guideHide_studio_name": "YouTube Studio",
		"feature_guideHide_subscriptions_desc": "Hide the Subscriptions entry",
		"feature_guideHide_subscriptions_name": "Subscriptions",
		"feature_guideHide_trending_desc": "Hide the Trending entry",
		"feature_guideHide_trending_name": "Trending",
		"feature_guideHide_watchLater_desc": "Hide the Watch Later entry",
		"feature_guideHide_watchLater_name": "Watch Later",
		"feature_guideHide_yourVideos_desc": "Hide the Your Videos / Studio entry",
		"feature_guideHide_yourVideos_name": "Your Videos",
		"feature_heatmapSmartSpeed_desc": "Play the parts nobody rewatches faster, and drop back to your own speed through the most-replayed moments. Off by default; needs a video with heatmap data.",
		"feature_heatmapSmartSpeed_name": "Heatmap Smart Speed",
		"feature_hiddenActionButtonsManager_desc": "Choose which action buttons to hide below videos",
		"feature_hiddenActionButtonsManager_name": "Hide Action Buttons",
		"feature_hiddenChatElementsManager_desc": "Choose which live chat elements to hide",
		"feature_hiddenChatElementsManager_name": "Hide Chat Elements",
		"feature_hiddenGuideElementsManager_desc": "Choose individual left-navigation (Guide) entries to hide",
		"feature_hiddenGuideElementsManager_name": "Hide Guide Elements",
		"feature_hiddenPlayerControlsManager_desc": "Choose which player control buttons to hide",
		"feature_hiddenPlayerControlsManager_name": "Hide Player Controls",
		"feature_hiddenWatchElementsManager_desc": "Choose which elements to hide below videos",
		"feature_hiddenWatchElementsManager_name": "Hide Watch Page Elements",
		"feature_hideAiContextPanels_desc": "Remove fact-checking and contextual information panels",
		"feature_hideAiContextPanels_name": "Hide AI Context Panels",
		"feature_hideAiSummary_desc": "Remove AI-generated summary panels only",
		"feature_hideAiSummary_name": "Hide AI Summary",
		"feature_hideAirplayButton_desc": "Remove the Airplay icon from the player controls",
		"feature_hideAirplayButton_name": "Hide Airplay Button",
		"feature_hideAskAi_desc": "Remove Ask AI buttons and conversational sections",
		"feature_hideAskAi_name": "Hide Ask AI",
		"feature_hideAutoplayToggle_desc": "Removes the autoplay toggle switch from the player controls",
		"feature_hideAutoplayToggle_name": "Hide Autoplay Toggle",
		"feature_hideChannelJoinButton_desc": "Remove the Join/membership button on channel pages",
		"feature_hideChannelJoinButton_name": "Hide Channel Join Button",
		"feature_hideCollaborations_desc": "Hide multi-creator collaboration uploads from your subscriptions feed",
		"feature_hideCollaborations_name": "Hide Collaborations",
		"feature_hideCommentActionMenu_desc": "Remove action menu from individual comments",
		"feature_hideCommentActionMenu_name": "Hide Comment Actions",
		"feature_hideCommentComposer_desc": "Remove the \"Add a comment\" text field above comments",
		"feature_hideCommentComposer_name": "Hide Comment Composer",
		"feature_hideCommentDislikeButton_desc": "Remove the dislike button from comment actions since it adds no useful feedback",
		"feature_hideCommentDislikeButton_name": "Hide Comment Dislike",
		"feature_hideCommentReplyButton_desc": "Remove the Reply button on individual comments",
		"feature_hideCommentReplyButton_name": "Hide Comment Reply Button",
		"feature_hideCommentTeaser_desc": "Remove the \"Scroll for comments\" prompt on watch pages",
		"feature_hideCommentTeaser_name": "Hide Comment Teaser",
		"feature_hideCreateButton_desc": "Remove the \"Create\" button from the header toolbar",
		"feature_hideCreateButton_name": "Hide Create Button",
		"feature_hideDescriptionExtras_desc": "Remove extra elements in the description area",
		"feature_hideDescriptionExtras_name": "Hide Description Extras",
		"feature_hideDescriptionRow_desc": "Remove the video description panel below the player",
		"feature_hideDescriptionRow_name": "Hide Description",
		"feature_hideEndCards_desc": "Removes the clickable end screen cards/annotations that overlay the video in the last seconds. Also covered by Hide Video End Content.",
		"feature_hideEndCards_name": "Hide End Screen Cards",
		"feature_hideFundraiser_desc": "Remove fundraiser and donation badges",
		"feature_hideFundraiser_name": "Hide Fundraisers",
		"feature_hideGeminiButtons_desc": "Remove Gemini-branded actions without hiding other AI surfaces",
		"feature_hideGeminiButtons_name": "Hide Gemini Buttons",
		"feature_hideHashtags_desc": "Remove hashtag links above video titles",
		"feature_hideHashtags_name": "Hide Hashtags",
		"feature_hideInfoCards_desc": "Removes the \"i\" info card teasers and popups that appear during video playback",
		"feature_hideInfoCards_name": "Hide Info Cards",
		"feature_hideInfoPanels_desc": "Remove Wikipedia/context info boxes that appear below videos (FEMA, COVID, etc.)",
		"feature_hideInfoPanels_name": "Hide Info Panels",
		"feature_hideJumpAheadButton_desc": "Remove the Jump Ahead prompt that appears after skipping on eligible videos.",
		"feature_hideJumpAheadButton_name": "Hide Jump Ahead",
		"feature_hideLatestPosts_desc": "Hide community posts and updates sections from feeds",
		"feature_hideLatestPosts_name": "Hide Latest Posts",
		"feature_hideThumbnailBadges_desc": "Hide the \"New\", \"4K\" and \"CC\" badges on video cards. The duration and the watched bar stay.",
		"feature_hideThumbnailBadges_name": "Hide Thumbnail Badges",
		"feature_hideLiveChatEngagement_desc": "Remove engagement prompts in live chat",
		"feature_hideLiveChatEngagement_name": "Hide Chat Engagement",
		"feature_hideMembersOnly_desc": "Hide members-only feed cards on Home and Subscriptions",
		"feature_hideMembersOnly_name": "Hide Members Only",
		"feature_hideMerchShelf_desc": "Remove merchandise promotions below videos",
		"feature_hideMerchShelf_name": "Hide Merch Shelf",
		"feature_hideNewsHome_desc": "Hide news sections from the homepage",
		"feature_hideNewsHome_name": "Hide News Section",
		"feature_hideNotificationBadge_desc": "Removes the red notification count badge from the bell icon",
		"feature_hideNotificationBadge_name": "Hide Notification Badge",
		"feature_hideNotificationButton_desc": "Remove the notification bell icon from the header",
		"feature_hideNotificationButton_name": "Hide Notification Bell",
		"feature_hideOwnAvatar_desc": "Remove your account avatar button from the header",
		"feature_hideOwnAvatar_name": "Hide Own Avatar",
		"feature_hidePaidContentOverlay_desc": "Remove \"Includes paid promotion\" overlays on thumbnails and watch pages",
		"feature_hidePaidContentOverlay_name": "Hide Promotion Badges",
		"feature_hidePaidPromotionWatch_desc": "Remove \"paid promotion\" labels on watch pages",
		"feature_hidePaidPromotionWatch_name": "Hide Paid Promotion",
		"feature_hidePinnedComments_desc": "Remove pinned comments from the comments section",
		"feature_hidePinnedComments_name": "Hide Pinned Comments",
		"feature_hidePlannedLivestreams_desc": "On the Subscriptions page, hide scheduled livestreams and premieres that only show a \"Notify me\" button. They reappear automatically once they go live.",
		"feature_hidePlannedLivestreams_name": "Hide Planned Livestreams",
		"feature_hidePlayables_desc": "Hide YouTube Playables gaming content from feeds",
		"feature_hidePlayables_name": "Hide Playables",
		"feature_hidePlaylistsHome_desc": "Hide playlist sections from the homepage",
		"feature_hidePlaylistsHome_name": "Hide Playlist Shelves",
		"feature_hideQueueOnThumbnails_desc": "Remove the \"Add to queue\" overlay button that appears on thumbnail hover",
		"feature_hideQueueOnThumbnails_name": "Hide \"Add to Queue\" on Thumbnails",
		"feature_hideRelatedVideos_desc": "Remove the related videos panel on watch pages",
		"feature_hideRelatedVideos_name": "Hide Related Videos",
		"feature_hideSearchSidebar_desc": "Remove the right-hand sidebar on search results pages",
		"feature_hideSearchSidebar_name": "Hide Search Sidebar",
		"feature_hideSidebar_desc": "Remove the left navigation sidebar completely",
		"feature_hideSidebar_name": "Hide Sidebar",
		"feature_hideSubscriptionOptions_desc": "Remove the \"Latest\" header and view toggles on subscriptions",
		"feature_hideSubscriptionOptions_name": "Hide Layout Options",
		"feature_hideVideoEndContent_desc": "Remove end cards, end screen, annotations, and video grid when videos finish. Superset of Hide End Screen Cards.",
		"feature_hideVideoEndContent_name": "Hide Video End Content",
		"feature_hideVideosFromHome_desc": "Hide videos/channels from feeds. Includes keyword filter, duration filter, and channel blocking.",
		"feature_hideVideosFromHome_name": "Video Hider",
		"feature_hideVideosLowSignalFilter_desc": "Hide videos that remain below the view threshold after the age threshold. Missing card metadata fails open.",
		"feature_hideVideosLowSignalFilter_name": "Hide Low-Signal Videos",
		"feature_hideVideosLowSignalMinAgeDays_desc": "Only treat a low-view card as low-signal after this many days. Missing age metadata fails open.",
		"feature_hideVideosLowSignalMinAgeDays_name": "Low-Signal Age Threshold",
		"feature_hideVideosLowSignalMinViews_desc": "Minimum views used by the low-signal heuristic. Set to 0 to disable its view side.",
		"feature_hideVideosLowSignalMinViews_name": "Low-Signal View Threshold",
		"feature_hideVideosSyntheticNarrationFilter_desc": "Hide cards whose title, description, or channel text contains explicit synthetic-narration markers. Runs locally with no network or crowd database.",
		"feature_hideVideosSyntheticNarrationFilter_name": "Synthetic Narration Markers",
		"feature_hideVideosUploadCadenceFilter_desc": "Hide cards exposing an upload cadence above the local per-day threshold. Cards without cadence text remain visible.",
		"feature_hideVideosUploadCadenceFilter_name": "Upload Cadence Filter",
		"feature_hideVideosUploadCadencePerDay_desc": "Maximum uploads per day accepted by the upload-cadence heuristic.",
		"feature_hideVideosUploadCadencePerDay_name": "Upload Cadence Threshold",
		"feature_hideVoiceSearch_desc": "Remove the microphone icon from the search bar",
		"feature_hideVoiceSearch_name": "Hide Voice Search",
		"feature_hideWatchedVideos_desc": "Dim or hide videos with a red progress bar (already watched) from feeds",
		"feature_hideWatchedVideos_name": "Hide Watched Videos",
		"feature_homepageGridAlign_desc": "Force a uniform thumbnail grid on the homepage. Prevents misaligned rows caused by variable title and metadata heights.",
		"feature_homepageGridAlign_name": "Homepage Grid Align",
		"feature_initialPlayerStateBackground_desc": "When opening a watch page in a background tab, play or pause regardless of YouTube’s default. Useful for queueing-up multiple tabs.",
		"feature_initialPlayerStateBackground_name": "Initial Player State (Background)",
		"feature_initialPlayerStateForeground_desc": "When opening a watch page in the foreground, play or pause regardless of the previous session’s autoplay choice. “Inherit” leaves YouTube’s native behavior alone.",
		"feature_initialPlayerStateForeground_name": "Initial Player State (Foreground)",
		"feature_jumpToMostReplayed_desc": "Add a player control that seeks straight to the most-replayed moment. It appears only on videos where YouTube actually provides the heatmap.",
		"feature_jumpToMostReplayed_name": "Jump to Most Replayed",
		"feature_keyMoments_desc": "Highlights chapter markers on the progress bar with colored segments for quick visual navigation",
		"feature_keyMoments_name": "Key Moments Highlights",
		"feature_likeViewRatio_desc": "Shows the like-to-view percentage next to the view count on watch pages",
		"feature_likeViewRatio_name": "Like-to-View Ratio",
		"feature_listFeedLayout_desc": "Show Home, Subscriptions, and Search video cards as rows with thumbnails on the left and metadata on the right. Off by default and mutually exclusive with Videos Per Row.",
		"feature_listFeedLayout_name": "List Feed Layout",
		"feature_liveLatencyCatchup_desc": "Show live latency and buffer in the player chrome, then use a bounded playback-rate boost to reach the configured live edge target.",
		"feature_liveLatencyCatchup_name": "Live Latency Catch-up",
		"feature_liveLatencyMaxRate_desc": "Maximum playback rate used while catching up; your saved channel speed is restored afterward.",
		"feature_liveLatencyMaxRate_name": "Live Catch-up Max Rate",
		"feature_liveLatencyTargetSeconds_desc": "Start catch-up above this live-edge delay. Lower values catch up sooner but may change speed more often.",
		"feature_liveLatencyTargetSeconds_name": "Live Latency Target",
		"feature_liveSpeedReset_desc": "When a live stream played above 1x catches up to the live edge, reset to 1x; your speed is restored if you seek back behind the edge",
		"feature_liveSpeedReset_name": "Live Catch-Up Speed Reset",
		"feature_localAiSummary_desc": "Use Chrome’s built-in Summarizer API when available; use the configured BYO-key lane when it is unavailable.",
		"feature_localAiSummary_name": "Local AI Summary (Browser Built-In)",
		"feature_localAiTranscriptQa_desc": "Ask citation-backed questions with Chrome on-device AI or an explicitly selected configured provider.",
		"feature_localAiTranscriptQa_name": "Transcript Q&A",
		"feature_logarithmicVolume_desc": "Remap the native volume slider to a logarithmic gain curve for finer control at quiet listening levels.",
		"feature_logarithmicVolume_name": "Logarithmic Volume Curve",
		"feature_logoToSubscriptions_desc": "Point the native YouTube home mark to your subscriptions feed",
		"feature_logoToSubscriptions_name": "Logo Click → Subscriptions",
		"feature_lowPowerProfile_desc": "When on, disables CPU-heavy features (cinema ambient glow, visual filters, playback stats overlay, monetization indicator, transcript index, transcript viewer, blue light filter) and bumps storage LRU sweep cadence. Toggle off to restore previous values from the backup snapshot.",
		"feature_lowPowerProfile_name": "Low Power Profile",
		"feature_miniPlayerBar_desc": "Shows a floating mini-player bar at the bottom when you scroll past the video",
		"feature_miniPlayerBar_name": "Mini Player Bar",
		"feature_monetizationIndicator_desc": "Adds a pill under the title showing whether the video is monetized (has ads or a sponsorship overlay) or not. It’s a heuristic built from the paid promotion overlay, the sponsorship card, and SponsorBlock category data when available.",
		"feature_monetizationIndicator_name": "Monetization Indicator",
		"feature_monoToStereo_desc": "Center mono audio equally in both ears. Fixes one-sided recordings, lectures, and old content that sounds unbalanced on headphones.",
		"feature_monoToStereo_name": "Mono to Stereo",
		"feature_musicVideoSpeedLock_desc": "When Persistent Playback Speed is enabled, keep music-category videos at 1x so songs aren’t sped up",
		"feature_musicVideoSpeedLock_name": "Lock 1x Speed on Music Videos",
		"feature_newPlayerUiRestore_desc": "Hides YouTube’s new-player chrome elements (Delhi modern overflow panel, pill action surfaces). Restores a tighter progress bar and original-style controls.",
		"feature_newPlayerUiRestore_name": "Restore Classic Player Chrome",
		"feature_noAmbientMode_desc": "Turn off the glowing background effect that matches video colors",
		"feature_noAmbientMode_name": "Disable Ambient Mode",
		"feature_noFrostedGlass_desc": "Remove blur effects from UI elements",
		"feature_noFrostedGlass_name": "Disable Frosted Glass",
		"feature_notInterestedButton_desc": "Add an X button on video thumbnails to quickly dismiss videos via YouTube’s feedback API",
		"feature_notInterestedButton_name": "\"Not Interested\" on Thumbnails",
		"feature_notificationHideRead_desc": "Hide notifications that YouTube marks as already read.",
		"feature_notificationHideRead_name": "Hide Read Notifications",
		"feature_notificationMaxCount_desc": "Limit the number of notifications shown. Set to 0 to show all.",
		"feature_notificationMaxCount_name": "Notification Count",
		"feature_notifyAutoDubbedAudio_desc": "Show a one-time toast when YouTube auto-selects an AI-dubbed audio track (e.g. an English-dubbed Korean video). You can manually switch to the original track in the player settings.",
		"feature_notifyAutoDubbedAudio_name": "Notify on AI-Dubbed Audio",
		"feature_nyanCatProgressBar_desc": "Replace the video progress bar with a Nyan Cat animation",
		"feature_nyanCatProgressBar_name": "Nyan Cat Progress Bar",
		"feature_oledTheme_desc": "True OLED black (#000) backgrounds via the --yt-sys-color-baseline tokens. Survives YouTube’s native theme switches because we hook the tokens themselves, not the surface classes.",
		"feature_oledTheme_name": "OLED Theme",
		"feature_openInAlternativeFrontend_desc": "Adds a button next to the player to open the current video in your configured alternative frontend (Invidious / Piped / FreeTube). Default instance is yewtu.be; change via alternativeFrontendInstance setting.",
		"feature_openInAlternativeFrontend_name": "Open In Alternative Frontend",
		"feature_openInNewTab_desc": "Makes video links on the home/subscriptions page open in a new tab instead of navigating away",
		"feature_openInNewTab_name": "Open Videos in New Tab",
		"feature_pauseOtherTabs_desc": "When a video starts playing, pause YouTube in all other tabs",
		"feature_pauseOtherTabs_name": "Pause Other Tabs on Play",
		"feature_pcHide_autoplay_desc": "Hide autoplay toggle from player",
		"feature_pcHide_autoplay_name": "Autoplay Toggle",
		"feature_pcHide_captions_desc": "Hide captions overlay on video",
		"feature_pcHide_captions_name": "Captions Display",
		"feature_pcHide_fullscreen_desc": "Hide fullscreen button from player",
		"feature_pcHide_fullscreen_name": "Fullscreen Button",
		"feature_pcHide_miniplayer_desc": "Hide miniplayer button from player",
		"feature_pcHide_miniplayer_name": "Miniplayer Button",
		"feature_pcHide_next_desc": "Hide next video button from player",
		"feature_pcHide_next_name": "Next Video Button",
		"feature_pcHide_pip_desc": "Hide PiP button from player",
		"feature_pcHide_pip_name": "Picture-in-Picture",
		"feature_pcHide_settings_desc": "Hide settings gear from player controls",
		"feature_pcHide_settings_name": "Settings Gear",
		"feature_pcHide_subtitles_desc": "Hide subtitles button from player",
		"feature_pcHide_subtitles_name": "Subtitles Button",
		"feature_pcHide_theater_desc": "Hide theater mode button from player",
		"feature_pcHide_theater_name": "Theater Mode Button",
		"feature_pcHide_ytLogo_desc": "Hide the native brand button from player controls",
		"feature_pcHide_ytLogo_name": "Native Brand Button",
		"feature_perChannelIntroOutro_desc": "Skip the first N and last M seconds of every video on a given channel. Set offsets per channel from the watch page (Tools → Set Intro/Outro). Stored under perChannelIntroOutroData.",
		"feature_perChannelIntroOutro_name": "Per-Channel Intro/Outro Skip",
		"feature_perChannelSpeed_desc": "Remember and auto-apply preferred playback speed for each channel",
		"feature_perChannelSpeed_name": "Per-Channel Speed Memory",
		"feature_persistentQueueAutoAdvance_desc": "Remove the finished video and start the next Watch Feed entry automatically.",
		"feature_persistentQueueAutoAdvance_name": "Watch Feed Auto-Advance",
		"feature_persistentQueue_desc": "Build a local Watch Feed from video pages and thumbnails, then play it in order.",
		"feature_persistentQueue_name": "Watch Feed",
		"feature_persistentSpeed_desc": "Remember your preferred playback speed globally and auto-apply it to every video",
		"feature_persistentSpeed_name": "Persistent Playback Speed",
		"feature_photosensitiveDimPercent_desc": "How strongly to dim the player while flashing content is detected.",
		"feature_photosensitiveDimPercent_name": "Dim Strength",
		"feature_photosensitiveFlashProtection_desc": "Sample video frames locally and briefly dim the player when a large luminance change is detected.",
		"feature_photosensitiveFlashProtection_name": "Photosensitive Flash Protection",
		"feature_photosensitiveFlashThreshold_desc": "Minimum frame luminance change that triggers protection.",
		"feature_photosensitiveFlashThreshold_name": "Flash Sensitivity",
		"feature_pipButton_desc": "Adds a one-click PiP button to the player controls for native browser Picture-in-Picture",
		"feature_pipButton_name": "Picture-in-Picture Button",
		"feature_playbackErrorRecovery_desc": "When the player shows an error screen, reload the page and restore position and speed automatically (max 3 attempts per video)",
		"feature_playbackErrorRecovery_name": "Playback Error Auto-Recovery",
		"feature_playbackSpeedOSD_desc": "Show speed overlay on the video player (like VLC) instead of corner toast",
		"feature_playbackSpeedOSD_name": "Speed Change OSD",
		"feature_playbackStatsOverlay_desc": "Shows video codec, resolution, bitrate, and dropped frame count as a togglable overlay",
		"feature_playbackStatsOverlay_name": "Playback Stats Overlay",
		"feature_playlistAutoSkipWatched_desc": "When a playlist entry reaches at least 90% watched, continue to the next entry below that threshold. This stays off until enabled.",
		"feature_playlistAutoSkipWatched_name": "Auto-Skip Watched Playlist Items",
		"feature_playlistEnhancer_desc": "Adds shuffle, copy, duration sorting, per-playlist resume, and watched-item controls to playlist panels.",
		"feature_playlistEnhancer_name": "Playlist Enhancer",
		"feature_playlistQuickRemove_desc": "Show a trash icon on each item in playlists you own for one-click removal",
		"feature_playlistQuickRemove_name": "Playlist Quick-Remove Overlay",
		"feature_playlistSearch_desc": "Adds a search input above playlist panels to filter items by title",
		"feature_playlistSearch_name": "Playlist Search",
		"feature_popOutPlayer_desc": "Detach the video into a resizable floating Picture-in-Picture window with transport controls",
		"feature_popOutPlayer_name": "Pop-Out Player",
		"feature_preciseViewCounts_desc": "Show full view counts (1,234,567) instead of truncated (1.2M)",
		"feature_preciseViewCounts_name": "Precise View Counts",
		"feature_preferDescriptiveAudio_desc": "When the preferred language offers an audio-description track, select it before the standard track.",
		"feature_preferDescriptiveAudio_name": "Prefer Descriptive Audio",
		"feature_preloadComments_desc": "Eagerly load the comment section so it is ready when you scroll down",
		"feature_preloadComments_name": "Preload Comments",
		"feature_premiumLiveChat_desc": "Refine live chat with a polished header, raised message rows, and a better composer.",
		"feature_premiumLiveChat_name": "Premium Live Chat",
		"feature_presetFocus_desc": "Distraction-free viewing: hide Shorts, related videos, infinite scroll, notifications, and autoplay. Enables Zen Mode and Digital Wellbeing tracking. Toggle off to restore prior values.",
		"feature_presetFocus_name": "Focus Preset",
		"feature_presetPowerUser_desc": "Maximum feature density: playback stats, persistent speed, fine speed control, resume playback, mini player bar, focused mode, A-B loop. Toggle off to restore prior values.",
		"feature_presetPowerUser_name": "Power User Preset",
		"feature_presetPrivacy_desc": "Privacy-focused bundle: clean share URLs, hide tracking chips, block infinite scroll, disable SPA navigation. Toggle off to restore prior values.",
		"feature_presetPrivacy_name": "Privacy Preset",
		"feature_presetResearcher_desc": "Research/study bundle: transcript viewer, timestamp bookmarks, watch time tracker, AI summary, comment search. Toggle off to restore prior values.",
		"feature_presetResearcher_name": "Researcher Preset",
		"feature_preventAutoplay_desc": "Stop videos from automatically playing on page load",
		"feature_preventAutoplay_name": "Prevent Autoplay",
		"feature_qualityProfileMatrix_desc": "Set different default qualities for normal / theater / fullscreen / background / embed contexts. ISOLATED-world detects the context and writes data-ytkit-quality-context on <html>; the MAIN-world bridge re-applies the matching quality via movie_player.setPlaybackQualityRange().",
		"feature_qualityProfileMatrix_name": "Per-Context Quality",
		"feature_quickLinkEditor_desc": "Customize the Astra launcher menu. One link per line: Label | URL.",
		"feature_quickLinkEditor_name": "Edit Launcher Links",
		"feature_quickLinkMenu_desc": "Adds a compact quick-links menu in the masthead with customizable links",
		"feature_quickLinkMenu_name": "Quick Links",
		"feature_reactionSpammer_desc": "Select live chat reactions and send them in a randomized loop.",
		"feature_reactionSpammer_name": "Reaction Spammer",
		"feature_rectangularizeYouTube_desc": "Strips YouTube’s pill / stadium / fully-rounded backdrops. Any backdrop with border-radius > 12px gets clamped to 8px. Avatars and progress rings stay circular.",
		"feature_rectangularizeYouTube_name": "Rectangularize UI",
		"feature_redditComments_desc": "Find Reddit discussions mentioning the current video (button in secondary sidebar)",
		"feature_redditComments_name": "Reddit Comments",
		"feature_redirectHomeToSubs_desc": "Automatically redirect the YouTube homepage to your subscriptions feed",
		"feature_redirectHomeToSubs_name": "Redirect Home to Subscriptions",
		"feature_redirectShorts_desc": "Open Shorts in the standard video player",
		"feature_redirectShorts_name": "Redirect Shorts",
		"feature_redirectToVideosTab_desc": "Open channel pages directly on the Videos tab",
		"feature_redirectToVideosTab_name": "Channels → Videos Tab",
		"feature_reducedMotion_desc": "Forces every Astra-injected animation, transition, and scroll behavior to be near-instant. Respects the OS prefers-reduced-motion setting automatically; this toggle adds an unconditional override on top.",
		"feature_reducedMotion_name": "Reduced Motion (strong)",
		"feature_remainingTimeCompact_desc": "Show remaining time as minutes (e.g. -1h24m) instead of full h:mm:ss.",
		"feature_remainingTimeCompact_name": "Compact Remaining Time",
		"feature_remainingTimeDisplay_desc": "Show time remaining next to current time in the player, adjusted for playback speed",
		"feature_remainingTimeDisplay_name": "Remaining Time Display",
		"feature_remainingTimeHideFullscreen_desc": "Hide the remaining time readout while the player is fullscreen",
		"feature_remainingTimeHideFullscreen_name": "Hide in Fullscreen",
		"feature_rememberVolume_desc": "Persist your volume level across videos and sessions",
		"feature_rememberVolume_name": "Remember Volume",
		"feature_removeAllShorts_desc": "Hide all Shorts videos from feeds and recommendations",
		"feature_removeAllShorts_name": "Remove Shorts",
		"feature_removeScrubber_desc": "Remove the round scrubber handle from the video progress bar",
		"feature_removeScrubber_name": "Hide Scrubber Handle",
		"feature_replayChatDensity_desc": "Show an optional activity sparkline above the progress bar for videos with replay chat, with click-to-seek highlights.",
		"feature_replayChatDensity_name": "Replay Chat Density",
		"feature_researchSpacedReview_desc": "Export study/work-mode data to Markdown or CSV, or build a bounded local transcript study pack from visible videos.",
		"feature_researchSpacedReview_name": "Study / Work Export",
		"feature_researchTranscriptIndex_desc": "Indexes captions for eligible videos you visit through the shared transcript service, without opening YouTube’s transcript panel. Search stays local in IndexedDB; no telemetry.",
		"feature_researchTranscriptIndex_name": "Transcript Search Index",
		"feature_researchTranscriptSearchPanel_desc": "Adds a \"Search transcripts\" button on the watch page that opens a search UI over the local IndexedDB transcript index. Requires Transcript Search Index to be on. Default off.",
		"feature_researchTranscriptSearchPanel_name": "Transcript Search Panel",
		"feature_restoreNativeYouTubeUi_desc": "Show the channel/comment avatars and home-feed shelves that Astra Deck hides by default. Toggles the early.css opt-out class so YouTube renders its own styling.",
		"feature_restoreNativeYouTubeUi_name": "Restore Native YouTube UI",
		"feature_resumePlayback_desc": "Remember where you stopped watching and automatically resume from that point",
		"feature_resumePlayback_name": "Resume Playback Position",
		"feature_returnDislikeOnCards_desc": "Show an estimated like-ratio bar on visible video thumbnails, using the same bounded Return YouTube Dislike cache.",
		"feature_returnDislikeOnCards_name": "Thumbnail Like-Ratio Bars",
		"feature_returnDislike_desc": "Restore an estimated dislike count via the public Return YouTube Dislike API. Cached locally; respects a 100 req/min budget. No cookies sent. Off by default.",
		"feature_returnDislike_name": "Return YouTube Dislike",
		"feature_reversePlaylist_desc": "Adds a \"Reverse\" button to playlist panels to play oldest first",
		"feature_reversePlaylist_name": "Reverse Playlist Button",
		"feature_rssFeedLink_desc": "Show an RSS feed link on channel pages for subscribing via RSS readers",
		"feature_rssFeedLink_name": "RSS Feed Link",
		"feature_sbCat_filler_desc": "Tangential or filler content",
		"feature_sbCat_filler_name": "Skip Filler",
		"feature_sbCat_interaction_desc": "\"Like, subscribe, comment\" reminders",
		"feature_sbCat_interaction_name": "Skip Interaction Reminders",
		"feature_sbCat_intro_desc": "Intro animations and branding",
		"feature_sbCat_intro_name": "Skip Intros",
		"feature_sbCat_music_offtopic_desc": "Non-music sections in music videos",
		"feature_sbCat_music_offtopic_name": "Skip Non-Music",
		"feature_sbCat_outro_desc": "Endcards and outro sequences",
		"feature_sbCat_outro_name": "Skip Outros",
		"feature_sbCat_poi_highlight_desc": "Jump to the highlight/point of interest (disabled by default)",
		"feature_sbCat_poi_highlight_name": "Highlight Point of Interest",
		"feature_sbCat_preview_desc": "Preview or recap of upcoming content",
		"feature_sbCat_preview_name": "Skip Previews",
		"feature_sbCat_selfpromo_desc": "Creator promoting their own products or channels",
		"feature_sbCat_selfpromo_name": "Skip Self-Promotion",
		"feature_sbCat_sponsor_desc": "Paid promotions and sponsorship segments",
		"feature_sbCat_sponsor_name": "Skip Sponsors",
		"feature_sbPerChannelProfiles_desc": "Override which SponsorBlock categories are skipped on a per-channel basis. Adds a chip next to the channel name on the watch page to configure overrides. Overrides persist in sbPerChannelProfilesData with a 500-entry cap.",
		"feature_sbPerChannelProfiles_name": "SponsorBlock Per-Channel Profiles",
		"feature_scrollToPlayer_desc": "Automatically scrolls to the top of the page when navigating to a new video",
		"feature_scrollToPlayer_name": "Scroll to Player on Navigate",
		"feature_scrollWheelSpeed_desc": "Adjust playback speed by scrolling the mouse wheel over the video player",
		"feature_scrollWheelSpeed_name": "Scroll Wheel Speed",
		"feature_searchFilterDefaults_desc": "Automatically apply a default sort order (upload date, view count, or rating) to YouTube search results",
		"feature_searchFilterDefaults_name": "Search Filter Defaults",
		"feature_searchHideRelatedSearches_desc": "Hide related-search chip blocks without removing filters, corrections, or direct results.",
		"feature_searchHideRelatedSearches_name": "Hide Related Search Blocks",
		"feature_searchHideUnrelatedShelves_desc": "Keep direct video, channel, and playlist results while hiding unrelated search-page shelves.",
		"feature_searchHideUnrelatedShelves_name": "Hide Unrelated Search Shelves",
		"feature_searchHideWatchedRecommended_desc": "Hide watched-progress results and recommendation interleaves from YouTube search.",
		"feature_searchHideWatchedRecommended_name": "Hide Watched and Recommended Results",
		"feature_searchWhileWatching_desc": "Show YouTube search results in a lightweight watch-page panel without interrupting playback.",
		"feature_searchWhileWatching_name": "Search While Watching",
		"feature_selectionColor_desc": "Choose the highlight color used while custom text selection is enabled",
		"feature_selectionColor_name": "Selection Color",
		"feature_selectorHealthPanel_desc": "Review live selector drift signals and export a JSON health report for fixture refreshes.",
		"feature_selectorHealthPanel_name": "Selector Health",
		"feature_settingsProfiles_desc": "Save, load, switch, import, and export named setting configurations (e.g. Gaming / Work / Music). Controls appear at the top of the settings panel when enabled.",
		"feature_settingsProfiles_name": "Settings Profiles",
		"feature_shareMenuCleaner_desc": "Removes social media buttons from the share dialog, leaving only the URL copy option",
		"feature_shareMenuCleaner_name": "Clean Share Menu",
		"feature_shortsAsRegularVideo_desc": "Add native browser playback controls and scrubbing to YouTube Shorts",
		"feature_shortsAsRegularVideo_name": "Shorts Player Controls",
		"feature_shortsAutoAdvance_desc": "Stop Shorts from looping and scroll to the next Short automatically when one finishes",
		"feature_shortsAutoAdvance_name": "Shorts Auto-Advance",
		"feature_shortsDailyLimitMin_desc": "Maximum minutes of Shorts playback per local day. Set to 0 to disable.",
		"feature_shortsDailyLimitMin_name": "Shorts Daily Limit",
		"feature_shortsDailyLimitMode_desc": "Choose whether reaching the limit blocks Shorts or offers five-minute snoozes.",
		"feature_shortsDailyLimitMode_name": "Shorts Limit Action",
		"feature_shortsSpeedControl_desc": "Adds a click-to-cycle playback speed chip to the Shorts player (0.5x-2x), honoring your persistent speed default",
		"feature_shortsSpeedControl_name": "Shorts Speed Control",
		"feature_showChannelVideoCount_desc": "Display total uploaded video count next to the channel name on watch pages",
		"feature_showChannelVideoCount_name": "Show Channel Video Count",
		"feature_showLocalDownloadButton_desc": "Add a yt-dlp download options button on watch pages",
		"feature_showLocalDownloadButton_name": "Download Button",
		"feature_showPlaylistDuration_desc": "Display total playlist runtime and speed-adjusted estimate next to the playlist header",
		"feature_showPlaylistDuration_name": "Show Playlist Duration",
		"feature_showStatisticsDashboard_desc": "Track videos watched, time on YouTube, and videos hidden",
		"feature_showStatisticsDashboard_name": "Statistics Dashboard",
		"feature_showTimeInTabTitle_desc": "Prepend current playback time [5:23] to the browser tab title",
		"feature_showTimeInTabTitle_name": "Show Time in Tab Title",
		"feature_sleepTimer_desc": "Pause playback after a chosen number of minutes. The player countdown chip lets you cancel or add 5 minutes.",
		"feature_sleepTimer_name": "Sleep Timer",
		"feature_softBottomGradient_desc": "Reduce the dark gradient behind the player control bar",
		"feature_softBottomGradient_name": "Soften Bottom Gradient",
		"feature_sortCommentsNewest_desc": "Automatically switch the comment sort order to \"Newest first\" on every video",
		"feature_sortCommentsNewest_name": "Sort Comments Newest First",
		"feature_speedIndicatorOverlay_desc": "Shows the current playback speed as a small overlay on the video when not at 1x",
		"feature_speedIndicatorOverlay_name": "Speed Indicator Overlay",
		"feature_speedStep_desc": "How much to change speed per scroll tick",
		"feature_speedStep_name": "Speed Step Amount",
		"feature_sponsorBlockBaseUrl_desc": "Choose the primary HTTPS host used by SponsorBlock and DeArrow.",
		"feature_sponsorBlockBaseUrl_name": "SponsorBlock API Host",
		"feature_sponsorBlockCanonicalHost_label": "Canonical (sponsor.ajay.app)",
		"feature_sponsorBlockDisabled_label": "Disabled",
		"feature_sponsorBlockMirrorHost_label": "Mirror (sponsorblock.kavin.rocks)",
		"feature_sponsorBlockMirrorUrl_desc": "Try this approved mirror once when the primary API host fails.",
		"feature_sponsorBlockMirrorUrl_name": "SponsorBlock Fallback Host",
		"feature_sponsorBlock_desc": "Automatically skip sponsored segments, intros, outros, and other non-content sections using SponsorBlock data licensed under CC BY-NC-SA 4.0",
		"feature_sponsorBlock_name": "SponsorBlock",
		"feature_sponsoredContentFilter_desc": "Collapse comment and description blocks that look like sponsorships or affiliate promotions. Each item explains the match and can be restored.",
		"feature_sponsoredContentFilter_name": "Sponsored Content Filter",
		"feature_squareAvatars_desc": "Make channel avatars square instead of round",
		"feature_squareAvatars_name": "Square Avatars",
		"feature_squareSearchBar_desc": "Remove rounded corners from the search bar",
		"feature_squareSearchBar_name": "Square Search Bar",
		"feature_stickyChat_desc": "Keeps the live chat panel pinned at the top of the sidebar when scrolling",
		"feature_stickyChat_name": "Sticky Live Chat",
		"feature_stickyVideo_desc": "Fullscreen video on watch pages. Scroll down to reveal comments side-by-side. Scroll back to top to return to fullscreen.",
		"feature_stickyVideo_name": "Theater Split",
		"feature_storageQuotaLRU_desc": "LRU-cap growing settings and stores (ytkit-hidden-videos, ytkit-blocked-channels, videoNotesData, ytkit-bookmarks, ytkit-watch-progress, ytkit-watch-time, da_branding_cache, sb_segments_cache) to prevent quota exhaustion",
		"feature_storageQuotaLRU_name": "Storage Quota Management",
		"feature_styledFilterChips_desc": "Compact, native-feeling filter chips on home and subscriptions",
		"feature_styledFilterChips_name": "Styled Filter Chips",
		"feature_subStyleBgColor_desc": "Choose the color behind caption text",
		"feature_subStyleBgColor_name": "Caption Background Color",
		"feature_subStyleBgOpacity_desc": "Set the opacity behind caption text",
		"feature_subStyleBgOpacity_name": "Caption Background Opacity",
		"feature_subStyleBottomOffset_desc": "Move captions up from the bottom edge of the player",
		"feature_subStyleBottomOffset_name": "Caption Bottom Offset",
		"feature_subStyleColor_desc": "Choose the caption foreground color",
		"feature_subStyleColor_name": "Caption Text Color",
		"feature_subStyleFontFamily_desc": "Choose the typeface used for captions",
		"feature_subStyleFontFamily_name": "Caption Font Family",
		"feature_subStyleFontSize_desc": "Scale caption text from 50% to 300%",
		"feature_subStyleFontSize_name": "Caption Font Size",
		"feature_subStyleTextShadow_desc": "Add a dark shadow so captions stay readable over bright video",
		"feature_subStyleTextShadow_name": "Caption Text Shadow",
		"feature_subscriptionGroups_desc": "PocketTube-grade local groups for your subscriptions feed. Create named groups, add channels via the Edit Channels panel, sort by date/duration/unwatched/new-since-last-visit, and back up or migrate groups with JSON, CSV, or OPML. Import also reads the subscriptions you export from Google Takeout or NewPipe.",
		"feature_subscriptionGroups_name": "Subscription Groups",
		"feature_subscriptionViewControls_desc": "Choose Grid, List, or Compact subscriptions layouts and optionally sort the currently loaded cards newest first.",
		"feature_subscriptionViewControls_name": "Subscription View Controls",
		"feature_subscriptionsGrid_desc": "Use a denser grid layout on the subscriptions page",
		"feature_subscriptionsGrid_name": "Subscriptions Grid",
		"feature_subtitleDownload_desc": "One-click SRT download of the active caption track. It’s a standalone player button, so no sidebar is required.",
		"feature_subtitleDownload_name": "Subtitle Download (SRT)",
		"feature_subtitleStyling_desc": "Override YouTube caption appearance: font size, family, and color, plus background, position, and shadow",
		"feature_subtitleStyling_name": "Subtitle Styling",
		"feature_subtitlesOnRewind_desc": "After seeking backwards, show captions for 10 seconds so you can catch the missed line, then restore the previous caption state",
		"feature_subtitlesOnRewind_name": "Subtitles on Rewind",
		"feature_theaterAutoScroll_desc": "Scroll video into full view when theater mode activates",
		"feature_theaterAutoScroll_name": "Theater Auto-Scroll",
		"feature_themeAccentColor_desc": "Custom accent color for highlights, progress bar, and active UI elements",
		"feature_themeAccentColor_name": "Accent Color",
		"feature_thinScrollbar_desc": "Use a slim, unobtrusive scrollbar",
		"feature_thinScrollbar_name": "Thin Scrollbar",
		"feature_thumbnailPreviewSize_desc": "Increase the size of thumbnail hover previews for easier viewing on large screens",
		"feature_thumbnailPreviewSize_name": "Large Thumbnail Previews",
		"feature_thumbnailQualityUpgrade_desc": "Upgrades video thumbnails to maximum resolution where available",
		"feature_thumbnailQualityUpgrade_name": "HD Thumbnails",
		"feature_timestampBookmarks_desc": "Bookmark moments in videos with custom notes. Click a bookmark to seek. Persists across sessions.",
		"feature_timestampBookmarks_name": "Timestamp Bookmarks",
		"feature_titleCaseMode_desc": "Choose the casing used while title transformation is enabled",
		"feature_titleCaseMode_name": "Title Case Style",
		"feature_titleCaseTransform_desc": "Override YouTube’s clickbait UPPERCASE titles with a casing style of your choice",
		"feature_titleCaseTransform_name": "Transform Video Title Case",
		"feature_titleNormalization_desc": "Convert ALL CAPS titles to Title Case. Reduces clickbait without changing meaning.",
		"feature_titleNormalization_name": "Normalize Clickbait Titles",
		"feature_tokenThemeBridge_desc": "Pipes the user’s themeAccentColor into YouTube’s native --yt-sys-color-* tokens so native badges, hover states, and primary buttons follow the Astra accent without restyling each surface.",
		"feature_tokenThemeBridge_name": "Native Token Theme Bridge",
		"feature_transcriptAiHandoff_desc": "Adds a player-button that copies the transcript and opens your chosen AI tool with a summarization prompt pre-filled",
		"feature_transcriptAiHandoff_name": "Transcript → AI One-Click Handoff",
		"feature_transcriptQaLane_desc": "Keep questions on-device or use the configured provider with its existing permission, privacy, and request-budget controls.",
		"feature_transcriptQaLane_name": "Transcript Q&A Provider",
		"feature_transcriptViewer_desc": "Adds a clickable transcript panel in the sidebar with timestamp navigation and export (txt/srt/clipboard/LLM prompt)",
		"feature_transcriptViewer_name": "Transcript Sidebar",
		"feature_uiFontFamily_desc": "Override the interface typeface. A short curated list rather than a free-text field, because an arbitrary font-family string is a CSS injection surface, and Custom CSS already exists for that.",
		"feature_uiFontFamily_name": "UI Font",
		"feature_uiFontSize_desc": "Override the base interface font size (0 = YouTube default, otherwise 8 to 20px)",
		"feature_uiFontSize_name": "UI Font Size",
		"feature_uiStyleManager_desc": "Choose rounded or square UI elements",
		"feature_uiStyleManager_name": "UI Style",
		"feature_videoAgeColors_desc": "Color-coded thumbnail borders by upload age: fresh (green), week (blue), month (yellow), year (orange), ancient (red)",
		"feature_videoAgeColors_name": "Video Age Color Coding",
		"feature_videoContextMenu_desc": "Right-click on the video player for yt-dlp download actions",
		"feature_videoContextMenu_name": "Player Download Menu",
		"feature_videoFlip_desc": "Mirror the video horizontally or vertically. Useful for mirrored dance tutorials, text readability, or flipped recordings.",
		"feature_videoFlip_name": "Video Flip",
		"feature_videoInsights_desc": "Reveal category, exact upload date, channel ID, and published tags from YouTube page metadata, with a bounded GitHub-full fallback.",
		"feature_videoInsights_name": "Video Insights",
		"feature_videoLoopButton_desc": "Add a loop toggle button to the player controls for one-click video looping",
		"feature_videoLoopButton_name": "Video Loop Button",
		"videoLoopButtonDockNote": "While Astra Player Dock is on, it hides this button. Use the dock's Repeat button instead.",
		"feature_videoNotes_desc": "Keep a local note for the current video, export the notes archive, and cap the store at the 1000 most recently edited videos.",
		"feature_videoNotes_name": "Per-Video Notes",
		"feature_videoResolutionBadge_desc": "Shows a 4K, HD, or SD badge on video thumbnails based on available quality",
		"feature_videoResolutionBadge_name": "Resolution Badge on Thumbnails",
		"feature_videoRotation_desc": "Rotate the video 90, 180, or 270 degrees via CSS transform. Useful for sideways phone recordings.",
		"feature_videoRotation_name": "Video Rotation",
		"feature_videoScreenshot_desc": "Capture the current video frame as a PNG image. It copies to the clipboard and downloads.",
		"feature_videoScreenshot_name": "Video Screenshot",
		"feature_videoVisualFilters_desc": "Adjust brightness / contrast / saturation / hue / grayscale / sepia via CSS filter on the video element",
		"feature_videoVisualFilters_name": "Video Visual Filters",
		"feature_videoZoom_desc": "Hold Ctrl and scroll on the video to zoom in, then drag to pan around",
		"feature_videoZoom_name": "Video Zoom & Pan",
		"feature_videosPerRow_desc": "Set how many video thumbnails per row (0 = dynamic based on window width)",
		"feature_videosPerRow_name": "Videos Per Row",
		"feature_vlcMpvHandoff_desc": "GitHub-full profile only. Adds buttons next to the player that fire ytvlc:// or ytmpv:// protocol URLs. The protocol handler must be registered on your OS. Astra Deck never runs binaries directly. Default off.",
		"feature_vlcMpvHandoff_name": "VLC / MPV Stream Handoff",
		"feature_volumeBoostLevel_desc": "Gain multiplier for Volume Boost (1.0 = unity, max 10.0)",
		"feature_volumeBoostLevel_name": "Volume Boost Level",
		"feature_volumeBoost_desc": "Amplify audio beyond 100% via a Web Audio gain node (up to 10x). Useful for quiet recordings. Adjust intensity with volumeBoostLevel.",
		"feature_volumeBoost_name": "Volume Boost",
		"feature_volumeWheelMode_desc": "Scroll the mouse wheel over the player to change volume in 5% steps. A floating indicator chip surfaces the new level for 1.2 s; no keyboard shortcut is added.",
		"feature_volumeWheelMode_name": "Volume Wheel",
		"feature_watchHistoryAnalytics_desc": "Modal dashboard visualizing your 30-day YouTube watch time as a CSS bar chart (requires Watch Time Tracker)",
		"feature_watchHistoryAnalytics_name": "Watch History Analytics",
		"feature_watchLaterCleanup_desc": "Adds a \"Remove Watched\" button to the Watch Later playlist header for batch cleanup",
		"feature_watchLaterCleanup_name": "Watch Later Cleanup Button",
		"feature_watchLaterQuickAdd_desc": "Adds a clock icon on every thumbnail for one-click Watch Later saving",
		"feature_watchLaterQuickAdd_name": "Watch Later Quick Button",
		"feature_watchLaterWorkbench_desc": "Bulk tools for the Watch Later playlist: filter by age, duration, watched state, channel, or title, preview and sort matches, export CSV/JSON, and remove in bounded recoverable sessions",
		"feature_watchLaterWorkbench_name": "Watch Later Workbench",
		"feature_watchPageRestyle_desc": "Premium watch-page layout for title, description, and metadata without hiding native controls",
		"feature_watchPageRestyle_name": "Watch Page Restyle",
		"feature_watchPageTabs_desc": "Horizontal tab bar above the comments/description area to quickly switch views on the watch page",
		"feature_watchPageTabs_name": "Watch Page Tabs",
		"feature_watchProgress_desc": "Show colored progress bars on video thumbnails based on your watch history (saved locally)",
		"feature_watchProgress_name": "Watch Progress Indicators",
		"feature_watchTimeTracker_desc": "Track your daily/weekly YouTube watch time with a stats widget in the settings panel",
		"feature_watchTimeTracker_name": "Watch Time Tracker",
		"feature_wheelSeek_desc": "Scroll the mouse wheel over the progress bar to seek. Step defaults to 5 s (configure via wheelSeekStepSec). Scrolling elsewhere over the player still drives Volume Wheel if it is on; the two features do not conflict.",
		"feature_wheelSeek_name": "Wheel Seek",
		"feature_widenSearchBar_desc": "Expand the search bar to use more available space",
		"feature_widenSearchBar_name": "Widen Search Bar",
		"feature_wpHide_askAISection_desc": "Hide AI section in description",
		"feature_wpHide_askAISection_name": "Ask AI Section",
		"feature_wpHide_askButton_desc": "Hide Ask AI button",
		"feature_wpHide_askButton_name": "Ask Button",
		"feature_wpHide_channelInfoCards_desc": "Hide channel info cards in description",
		"feature_wpHide_channelInfoCards_name": "Channel Info Cards",
		"feature_wpHide_joinButton_desc": "Hide join/membership button",
		"feature_wpHide_joinButton_name": "Join Button",
		"feature_wpHide_moreActions_desc": "Hide more actions menu button",
		"feature_wpHide_moreActions_name": "More Actions (…)",
		"feature_wpHide_podcastSection_desc": "Hide podcast/course section in description",
		"feature_wpHide_podcastSection_name": "Podcast/Course Section",
		"feature_wpHide_saveButton_desc": "Hide save to playlist button",
		"feature_wpHide_saveButton_name": "Save Button",
		"feature_wpHide_transcriptSection_desc": "Hide transcript section in description",
		"feature_wpHide_transcriptSection_name": "Transcript Section",
		"feature_zenMode_desc": "Dims the page around the video player for a focused viewing experience",
		"feature_zenMode_name": "Zen Mode",
		"filterListExportFail": "Filter-list export failed",
		"filterListExported": "Video Hider rules exported.",
		"filterListFailureBadFormat": "the response was not a supported Astra Deck filter list",
		"filterListFailureExpired": "the last verification is older than 7 days",
		"filterListFailureHttpTpl": "the server returned HTTP {status}",
		"filterListFailureIntegrity": "SHA-256 verification was unavailable",
		"filterListFailureStorage": "the verified list could not be saved",
		"filterListFailureTooLarge": "the response exceeded the 1 MiB limit",
		"filterListFailureUnreachable": "the source could not be reached",
		"filterListHashUnavailable": "not recorded",
		"filterListImportFail": "Filter-list import failed",
		"filterListImportNotJson": "That file is not valid JSON.",
		"filterListImportRollback": "Filter-list import failed; previous data was restored.",
		"filterListImported": "Video Hider rules imported. Undo Import is available.",
		"filterListNotModified": "Filter list checked; cached content is unchanged.",
		"filterListRefreshDaily": "Daily",
		"filterListRefreshFail": "Filter-list refresh failed",
		"filterListRefreshManual": "Manual only",
		"filterListRefreshModeLabel": "Automatic refresh",
		"filterListRefreshWeekly": "Weekly",
		"filterListRefreshed": "Video Hider filter list refreshed.",
		"filterListStatusActiveTpl": "Following {host}. Checked {age}; format v{version}; SHA-256 {hash}.",
		"filterListStatusErrorTpl": "No rules from {host} are active. Last refresh failed because {reason}.",
		"filterListStatusExported": "Local filter rules exported.",
		"filterListStatusFail": "Something went wrong. Your saved rules were not changed.",
		"filterListStatusFollowingTpl": "Following the filter list at {host}.",
		"filterListStatusImported": "Filter rules imported. Undo Import is available.",
		"filterListStatusInvalidUrl": "Enter a full HTTPS address, with no username, password, or # fragment.",
		"filterListStatusLastFailedTpl": "The last refresh of {host} did not succeed. Cached rules are still in use.",
		"filterListStatusNoTab": "Open a YouTube tab to refresh the remote list.",
		"filterListStatusPendingTpl": "Not fetched yet. Choose Refresh list now to follow {host}.",
		"filterListStatusPermissionNeeded": "Astra Deck needs your permission to read from that site. Choose Allow when your browser asks.",
		"filterListStatusPreferenceFail": "Could not save filter-list preferences.",
		"filterListStatusPrivateHost": "That address is on a private or local network. Filter lists must be served from a public HTTPS site.",
		"filterListStatusReady": "No filter list is being followed.",
		"filterListStatusRefreshFail": "Could not refresh the list. Check the address, then try again.",
		"filterListStatusRefreshReasonTpl": "Could not refresh the list because {reason}.",
		"filterListStatusRefreshed": "Remote filter list refreshed.",
		"filterListStatusStaleActiveTpl": "Cached {host} rules remain active; checked {age}; {reason}. Format v{version}; SHA-256 {hash}.",
		"filterListStatusStalePausedTpl": "Cached {host} rules are paused; checked {age}; {reason}. Format v{version}; SHA-256 {hash}.",
		"filterListStatusStateReadFail": "Could not read the filter-list state. Reload the extension, then open the popup again.",
		"filterListStopFailed": "Could not stop following the filter list.",
		"filterListStoppedTpl": "Stopped following {host}. No filter-list-only site access remains.",
		"filterListTimeUnknown": "at an unknown time",
		"filterListToolsDesc": "Back up your Video Hider rules, restore them from a file, or follow a filter list published on a site you trust.",
		"filterListToolsEyebrow": "Video Hider",
		"filterListToolsTitle": "Filter lists",
		"filterListUrlLabel": "Filter list URL (optional)",
		"filterListUrlPlaceholder": "https://example.com/astra-deck-rules.json",
		"filterListUseStaleLabel": "Use the last verified rules if refresh fails or they become older than 7 days",
		"filterTogglesHelpTitle": "Free text matches names, descriptions, keys, and translated labels. Mini-DSL: risk:safe|api|local-companion|experimental|store-risk, category:<name>, scope:global|feed|watch|player|comments|live-chat|subscriptions|downloads|popup, profile:store-safe|github-full|both. Combine with spaces (AND) and commas (OR within field).",
		"filterTogglesLabel": "Filter quick toggles",
		"filterTogglesPlaceholder": "Filter controls…",
		"floatingChatControlsAria": "Floating chat controls",
		"floatingChatDragAria": "Move floating chat",
		"floatingChatDragKeysAria": "Use the arrow keys to move the panel, or hold Shift to move it further.",
		"floatingChatDragTitle": "Drag to move",
		"floatingChatOpacityAria": "Chat opacity",
		"forceDvrDegraded": "DVR could not be enabled because the live player response changed.",
		"groupQuickControls": "Quick Controls",
		"healthClearAria": "Clear diagnostic log",
		"healthClearBtn": "Clear",
		"healthCopyAria": "Copy diagnostic details",
		"healthCopyBtn": "Copy",
		"healthEventPlural": "events",
		"healthEventSingular": "event",
		"healthFallbackPrefix": "TrustedTypes fallback active",
		"healthSaveAria": "Save diagnostic log as JSON",
		"healthSaveBtn": "Save",
		"healthTitle": "Diagnostics",
		"heatmapJumpAria": "Jump to the most replayed moment",
		"heatmapJumpedToast": "Jumped to the most replayed moment",
		"hiddenCardNoteTpl": "Hidden by {feature}: {rule}",
		"hiddenRuleCollaboration": "multi-creator upload",
		"hiddenRuleScheduled": "scheduled livestream or premiere",
		"hiddenRuleShorts": "Shorts video",
		"hideAllButtonLabel": "Hide All",
		"hideAllButtonTitle": "Hide all visible videos on this page",
		"importBtn": "Import",
		"importFilterListBtn": "Import rules",
		"languageAr": "العربية (Arabic)",
		"languageAuto": "Auto (browser default)",
		"languageAutoDetectedTpl": "{label} ({detected})",
		"languageCoverageTpl": "{language} ({percent}% translated)",
		"languageDe": "Deutsch (German)",
		"languageEn": "English",
		"languageEs": "Español (Spanish)",
		"languageFr": "Français (French)",
		"languageIt": "Italiano (Italian)",
		"languageJa": "日本語 (Japanese)",
		"languageKo": "한국어 (Korean)",
		"languagePtBr": "Português (Brazilian Portuguese)",
		"languageRu": "Русский (Russian)",
		"languageSelectLabel": "Display language",
		"languageTitle": "Display language",
		"languageZhCn": "简体中文 (Simplified Chinese)",
		"likeViewRatioAriaTpl": "Like rate {ratio}% based on {likes} likes and {views} views",
		"likeViewRatioLabel": "Like Rate",
		"likeViewRatioTitleTpl": "{likes} likes from {views} views",
		"liveLatencyReadout": "Live {latency}s · buffer {buffer}s",
		"loadingState": "Loading",
		"maintenanceMenu": "Maintenance",
		"openDashboard": "Dashboard",
		"openFullSettings": "Open Workspace",
		"openThumbnailChecking": "Checking…",
		"openThumbnailFailed": "Could not open the thumbnail. Try again in a moment.",
		"openThumbnailLabel": "View",
		"openThumbnailRetry": "Retry",
		"openThumbnailTitle": "Open thumbnail at full size",
		"openYouTube": "Open YouTube",
		"optionalHostBannerDetailMany": "{count} enabled enrichment features need host access: {origins}.",
		"optionalHostBannerDetailOne": "1 enabled enrichment feature needs host access: {origins}.",
		"optionalHostBannerTitle": "External access needed",
		"optionalHostGrantAria": "Grant optional host access",
		"optionalHostGrantBtn": "Grant access",
		"optionalHostGrantName": "optional host access",
		"optionalHostPermissionAria": "Permission needed.",
		"optionalHostPermissionBadge": "permission needed",
		"optionalHostPermissionGranted": "Optional host access granted.",
		"optionalHostPermissionMissingTooltip": "Host access for this optional feature is denied or was revoked. Enable the setting again to grant access.",
		"optionalHostPermissionRevoked": "Optional host access was revoked. Re-enable the affected setting to grant access again.",
		"optionalHostPrevious": "the previous host",
		"optionalHostUnknown": "optional host access",
		"pageControlDismissTpl": "Dismiss {label}",
		"panelCloseAria": "Close settings",
		"panelCloseTitle": "Close settings",
		"panelIntro": "Search, tune, and apply YouTube controls live without leaving the page.",
		"panelLiveApplyBadge": "Live apply",
		"panelNavGroupCommunity": "Community",
		"panelNavGroupInteraction": "Interaction",
		"panelNavGroupPersonalization": "Personalization",
		"panelNavGroupPlayer": "Player",
		"panelNavGroupSystem": "System",
		"panelPaneContextAriaTpl": "{category} current preferences",
		"panelReorderAria": "Reorder categories",
		"panelReorderDown": "Move the selected category down",
		"panelReorderMoved": "Category moved.",
		"panelReorderUp": "Move the selected category up",
		"panelSearchAria": "Search settings by name, page, category, or control type",
		"panelSearchClearAria": "Clear settings search",
		"panelSearchClearTitle": "Clear search",
		"panelSearchHint": "Search by name, page, category, control type, or description.",
		"panelSearchPlaceholder": "Search settings, pages, controls…",
		"panelSearchStateBadge": "Search",
		"panelSearchStateClear": "Clear search",
		"panelSearchStateCopy": "Type a control, page, or category to narrow the menu instantly.",
		"panelSearchStateTitle": "Search across all settings",
		"panelSidebarAria": "Settings categories",
		"panelTitle": "Settings",
		"photosensitiveFlashDetected": "Flashing content detected. Player dimmed.",
		"playbackStatsDataChecking": "Checking with Astra Downloader…",
		"playbackStatsDataQualityTpl": "{quality}: {size}",
		"playbackStatsDataUnavailable": "Unavailable",
		"playbackStatsDataUsage": "Download size estimates",
		"playerCcAria": "Toggle closed captions",
		"playerCcTitle": "Closed captions",
		"playerDockHomeLink": "Go to home",
		"playerDownloadAria": "Download video",
		"playerDownloadTitle": "Download Video",
		"playerGearAriaTpl": "Open {brand} settings",
		"playerGearTitleTpl": "{brand} Settings",
		"playerRepeatAria": "Toggle repeat",
		"playerRepeatOffToast": "Repeat off",
		"playerRepeatOnToast": "Repeat on",
		"playerRepeatTitle": "Repeat",
		"playlistAutoSkipOff": "Auto-skip: Off",
		"playlistAutoSkipOn": "Auto-skip: On",
		"playlistAutoSkipTitle": "Skip playlist entries with at least 90% watched progress",
		"playlistCopied": "Copied",
		"playlistCopyAllTitle": "Copy all playlist video URLs",
		"playlistCopyBlocked": "Clipboard access was blocked. Try again or use the browser copy shortcut.",
		"playlistCopyRetry": "Retry",
		"playlistCopyUrls": "Copy URLs",
		"playlistCopyVisibleTitle": "Copy the visible playlist video URLs",
		"playlistCopying": "Copying…",
		"playlistCurrentIsLast": "Resume Last",
		"playlistDuplicateCountTpl": "{count} duplicates",
		"playlistDurationLongest": "Duration ↓",
		"playlistDurationShortest": "Duration ↑",
		"playlistHiddenDuplicatesTpl": "{count} duplicates hidden",
		"playlistHideDuplicates": "Hide Duplicates",
		"playlistHideDuplicatesTitle": "Hide repeated videos in this playlist panel",
		"playlistNoResumeTitle": "No earlier video is remembered for this playlist",
		"playlistNoUrls": "No URLs",
		"playlistNoUrlsToast": "No playlist URLs are ready to copy yet.",
		"playlistRestoreOrderTitle": "Restore the original playlist order",
		"playlistResumeLast": "Resume Last",
		"playlistResumeLastTitle": "Open the last video remembered for this playlist",
		"playlistShowDuplicates": "Show Duplicates",
		"playlistShowDuplicatesTitle": "Show repeated videos in this playlist panel",
		"playlistShuffle": "Shuffle",
		"playlistShuffleNeedTwo": "Need at least 2 playlist items to shuffle.",
		"playlistShuffleTitle": "Play a random visible video from this playlist panel",
		"playlistSortDuration": "Sort Duration",
		"playlistSortDurationTitle": "Sort playlist items by duration; activate again to reverse",
		"playlistStatusLoading": "Playlist",
		"playlistToolsTitle": "Playlist Tools",
		"playlistVideoCountTpl": "{count} videos",
		"popupTitle": "Astra Deck",
		"preciseViewCountTpl": "{count} views",
		"presetFocusOff": "Focus preset off. Previous values restored.",
		"presetFocusOn": "Focus preset applied. Toggle off to restore.",
		"presetLowPowerOff": "Low Power off. Previous feature flags restored.",
		"presetLowPowerOn": "Low Power on. Toggle off to restore your previous feature flags.",
		"presetPowerUserOff": "Power User preset off. Previous values restored.",
		"presetPowerUserOn": "Power User preset applied. Toggle off to restore.",
		"presetPrivacyOff": "Privacy preset off. Previous values restored.",
		"presetPrivacyOn": "Privacy preset applied. Toggle off to restore.",
		"presetResearcherOff": "Researcher preset off. Previous values restored.",
		"presetResearcherOn": "Researcher preset applied. Toggle off to restore.",
		"profileImportFailed": "Profile import failed",
		"qtGroup_Feed_Cleanup": "Feed Cleanup",
		"qtGroup_Focus": "Focus",
		"qtGroup_Playback": "Playback",
		"qtGroup_Privacy": "Privacy",
		"qtGroup_Utilities": "Utilities",
		"qtGroup_Watch_Flow": "Watch Flow",
		"qt_autoTheaterMode_desc": "Open videos in theater view",
		"qt_autoTheaterMode_name": "Auto Theater Mode",
		"qt_blueLightFilter_desc": "Warm the player for late viewing",
		"qt_blueLightFilter_name": "Blue-Light Filter",
		"qt_cleanShareUrls_desc": "Remove tracking from share links",
		"qt_cleanShareUrls_name": "Clean URLs",
		"qt_commentSearch_desc": "Filter watch-page comments inline",
		"qt_commentSearch_name": "Comment Search",
		"qt_deArrow_desc": "Replace clickbait titles and thumbnails",
		"qt_deArrow_name": "DeArrow",
		"qt_debugMode_desc": "Record detailed local diagnostics",
		"qt_debugMode_name": "Diagnostic Logging",
		"qt_digitalWellbeing_desc": "Track breaks and daily viewing",
		"qt_digitalWellbeing_name": "Digital Wellbeing",
		"qt_disableAutoplayNext_desc": "Stop the next video from starting",
		"qt_disableAutoplayNext_name": "Disable Autoplay",
		"qt_disableInfiniteScroll_desc": "Stop endless feed loading",
		"qt_disableInfiniteScroll_name": "Cap Infinite Scroll",
		"qt_githubFullProfile_desc": "Turn on github-full toggles such as Cobalt and AI keys",
		"qt_githubFullProfile_name": "GitHub-Full Profile",
		"qt_hideRelatedVideos_desc": "Clear the watch-page side rail",
		"qt_hideRelatedVideos_name": "Hide Related",
		"qt_miniPlayerBar_desc": "Keep controls visible while scrolling",
		"qt_miniPlayerBar_name": "Mini Player Bar",
		"qt_persistentSpeed_desc": "Keep playback speed consistent",
		"qt_persistentSpeed_name": "Persistent Speed",
		"qt_privacyDataFlowPanel_desc": "Show every API origin Astra Deck can contact",
		"qt_privacyDataFlowPanel_name": "Data-Flow Panel",
		"qt_removeAllShorts_desc": "Remove Shorts shelves and links",
		"qt_removeAllShorts_name": "Hide Shorts",
		"qt_safeStoreProfile_desc": "Hide github-full toggles + scrub keys on export",
		"qt_safeStoreProfile_name": "Store-Safe Profile",
		"qt_sponsorBlock_desc": "Skip crowd-marked sponsor segments",
		"qt_sponsorBlock_name": "SponsorBlock",
		"qt_syncSettings_desc": "Opt in to sync safe preferences and Video Hider blocklists",
		"qt_syncSettings_name": "Browser Sync",
		"qt_transcriptViewer_desc": "Read, jump, and export captions",
		"qt_transcriptViewer_name": "Transcript Sidebar",
		"queueClear": "Clear",
		"queueClose": "Close",
		"queueCleared": "Watch Feed cleared",
		"queueExport": "Export",
		"queueImport": "Import",
		"queuePanelAria": "Astra Watch Feed",
		"queuePanelTitle": "Watch Feed",
		"queuePlayNext": "Start watching",
		"quickGroupCountTpl": "{enabled}/{total}",
		"quickToggleAriaTpl": "{name}. {description}. {state}.{permission}",
		"quickTogglesAria": "Quick toggles",
		"quickTogglesEyebrow": "Quick toggles",
		"reactionSenderChooseOne": "Choose at least one available reaction.",
		"reactionSenderCollapseAria": "Collapse panel",
		"reactionSenderEmpty": "No reactions found. Open the reaction button, then refresh.",
		"reactionSenderExpandAria": "Expand panel",
		"reactionSenderHideAria": "Hide reaction spammer panel",
		"reactionSenderIntervalAria": "Reaction interval in milliseconds",
		"reactionSenderIntervalLabel": "Interval",
		"reactionSenderLauncherBtn": "React",
		"reactionSenderOpenAria": "Open reaction sender",
		"reactionSenderPickerHint": "Open YouTube’s reaction picker, then refresh this list.",
		"reactionSenderRateWarning": "Rapid reactions may be rate-limited by YouTube. The minimum interval is 500 ms.",
		"reactionSenderRefresh": "Refresh reactions",
		"reactionSenderRiskToast": "Reaction Spammer: YouTube may rate-limit or flag rapid reactions. Use at your own risk.",
		"reactionSenderRunningTplOne": "Running with {count} reaction.",
		"reactionSenderRunningTplOther": "Running with {count} reactions.",
		"reactionSenderRunningWaiting": "Running, waiting for selected reactions.",
		"reactionSenderSelectOne": "Select at least one reaction.",
		"reactionSenderSelectedTplOne": "{count} reaction selected.",
		"reactionSenderSelectedTplOther": "{count} reactions selected.",
		"reactionSenderSentTpl": "Sent {emoji}",
		"reactionSenderStart": "Start",
		"reactionSenderStartSpamming": "Start spamming",
		"reactionSenderStop": "Stop",
		"reactionSenderStopped": "Stopped",
		"reactionSenderTest": "Test",
		"reactionSenderTestHint": "Use Test to send one reaction before starting.",
		"reactionSenderTestTitleTpl": "Send {emoji} once",
		"reactionSenderTitle": "Reaction sender",
		"redditCommentsFailed": "Could not load Reddit discussions",
		"redditResultMetaTpl": "r/{subreddit} • {score} pts • {comments} comments",
		"redditResultUntitled": "(untitled)",
		"reenableMediadlAria": "Re-enable Astra Downloader install prompts",
		"reenableMediadlBtn": "Enable Downloader Prompts",
		"refreshFilterListBtn": "Refresh list now",
		"replayChatDensityAria": "Chat activity across this video. Click the chart to seek.",
		"replayChatDensityTitle": "Chat activity. Click to seek.",
		"resetBtn": "Reset",
		"resultsAllAvailableTpl": "{count} quick controls are available in this popup",
		"resultsCountTpl": "{count} {controls}",
		"resultsMatchTpl": "{visible} of {total} {controls} match this filter",
		"resultsMatching": "matching",
		"resultsVisibleTpl": "{count} matching",
		"sbSkipCategory_filler": "filler tangent",
		"sbSkipCategory_interaction": "interaction reminder",
		"sbSkipCategory_intro": "intro",
		"sbSkipCategory_music_offtopic": "non-music section",
		"sbSkipCategory_outro": "outro",
		"sbSkipCategory_preview": "preview or recap",
		"sbSkipCategory_selfpromo": "self promotion",
		"sbSkipCategory_sponsor": "sponsor",
		"sbSkippedAnnounceTpl": "Skipped {category} segment.",
		"schemaBadgeGithubFullTitle": "This setting only applies when GitHub-Full Profile is enabled.",
		"schemaBadgeLocalOnly": "local only",
		"schemaBadgeLocalOnlyTitle": "This value is stored in extension storage on this device. It is never synced to a Google account, never sent to Astra Deck servers, and is redacted from the bug-report bundle (Diagnostics → Save).",
		"schemaBadgeNoEditorTpl": "{type} (no inline editor)",
		"schemaBadgeUnavailable": "unavailable",
		"schemaBadgeUnavailableTitleTpl": "This setting requires a capability not available in this browser: {capabilities}. Toggling the setting has no effect until the capability becomes available.",
		"schemaJsonExpectedArray": "Expected an array",
		"schemaJsonExpectedObject": "Expected an object",
		"schemaJsonInvalid": "Invalid JSON. Check the syntax, then apply.",
		"schemaJsonInvalidAtTpl": "Invalid JSON at position {position}. Fix it, then apply.",
		"schemaOverviewAllView": "Show all settings",
		"schemaOverviewChangedCountTpl": "{count} changed",
		"schemaOverviewChangedView": "Changed from defaults",
		"schemaOverviewCopyDiff": "Copy changed settings",
		"schemaOverviewCopyDiffDone": "Changed settings copied to clipboard.",
		"schemaOverviewCopyDiffEmpty": "No settings differ from their defaults.",
		"schemaOverviewCopyDiffFail": "Could not copy changed settings.",
		"schemaOverviewCountTpl": "{enabled} of {total} settings on, across {categories} categories",
		"schemaOverviewDiffCurrent": "Current",
		"schemaOverviewDiffDefault": "Default",
		"schemaOverviewValueEmpty": "Empty",
		"schemaOverviewDiffEmpty": "All settings use their defaults.",
		"schemaOverviewEyebrow": "Settings overview",
		"schemaOverviewNoMatchesTpl": "No setting matches \"{term}\". Try a feature name, a category, a page like watch or feed, or a control type like boolean.",
		"schemaOverviewToolsAria": "Settings diff tools",
		"schemaResetAriaTpl": "Reset {key} to default value",
		"schemaResetTitleTpl": "Reset {key} to default ({value})",
		"schemaSurfaceHere": "here",
		"schemaSurfaceHereTitle": "This setting can be changed in the popup.",
		"schemaSurfacePanel": "in-page panel",
		"schemaSurfacePanelTitle": "This setting is edited in the Astra Deck panel on YouTube. Opens it.",
		"screenshotCaptureFailed": "Screenshot capture failed",
		"searchWatchClose": "Close search results",
		"searchWatchEmpty": "No supported results found.",
		"searchWatchError": "Search results could not be loaded.",
		"searchWatchInputLabel": "Search YouTube",
		"searchWatchLoading": "Searching YouTube…",
		"searchWatchOpenError": "The result could not be opened.",
		"searchWatchOpenHintNew": "Results open in a new tab.",
		"searchWatchOpenHintSame": "Results replace the current video.",
		"searchWatchPlaceholder": "Search while watching…",
		"searchWatchResultsStatus": "{count} results for \"{query}\"",
		"searchWatchRetry": "Try again",
		"searchWatchSubmit": "Search",
		"searchWatchTitle": "Search without stopping playback",
		"selectorAutoRefreshCheckedTpl": "auto-checked {age}",
		"selectorAutoRefreshNeverChecked": "auto-refresh on, no check yet",
		"selectorAutoRefreshUpdatedTpl": "last update {age}",
		"selectorCanaryBuildUnknown": "current build",
		"selectorCanaryDiagnosticsAction": "Open diagnostics",
		"selectorCanaryNoticeTpl": "YouTube {version} changed page elements used by {features}.",
		"selectorHealthAssetTpl": "Rules: {status} · {version} · {source}",
		"selectorHealthCopyAria": "Copy selector-health report to clipboard",
		"selectorHealthCopyBtn": "Copy report",
		"selectorHealthCopyDone": "Copied. Paste it into a GitHub issue.",
		"selectorHealthCopyNeedYt": "Open a YouTube tab to build the report.",
		"selectorHealthCopyNoSnap": "No snapshot available. The page may still be loading.",
		"selectorHealthCopyPending": "Building report…",
		"selectorHealthCopySaveFallback": "Couldn’t copy to the clipboard. Try again, or use the Diagnostics Save button to download the report instead.",
		"selectorHealthCtxCountTpl": "{ctx}: {count}",
		"selectorHealthEmpty": "No surfaces sampled yet.",
		"selectorHealthExportAria": "Export selector health JSON",
		"selectorHealthRefreshAria": "Refresh selector rules",
		"selectorHealthRefreshBtn": "Refresh rules",
		"selectorHealthRefreshFailed": "Selector rules were not refreshed.",
		"selectorHealthRefreshPending": "Refreshing selector rules…",
		"selectorHealthTitle": "Selector health",
		"selectorHealthTotalTpl": "{count} surfaces tracked",
		"selectorHealthYouTubeBuildTpl": "YouTube {version}",
		"serviceOutageDismiss": "Dismiss",
		"serviceOutageTpl": "{service} is not answering. That is the service, not Astra Deck.",
		"settingValueUnrecognized": "Unrecognized: {value}",
		"settingsActiveSectionFallback": "Video Player",
		"settingsAutoDisabledConflictTpl": "Auto-disabled {features}. {reason}",
		"settingsCardReset": "Reset",
		"settingsCardResetTitleTpl": "Reset “{name}” to its default",
		"settingsCategoryAriaTpl": "{category}. {summary}",
		"settingsCategoryFractionTpl": "{enabled}/{total}",
		"settingsCategoryItemsTpl": "{count} Items",
		"settingsCategoryOnTpl": "{count} On",
		"settingsCategorySummaryFallback": "Category settings",
		"settingsChangedCountTpl": "{count} changed",
		"settingsChangedFilter": "Changed",
		"settingsChangedFilterTitle": "Show only settings you have changed from their defaults",
		"settingsChangedNone": "Nothing changed",
		"settingsChoiceChangedTpl": "{name} changed to {value}.",
		"settingsColorSettingFallback": "Color setting",
		"settingsColorUpdatedTpl": "{name} updated.",
		"settingsConflictWithTpl": "conflicts with {featureName}",
		"settingsDlActionsAria": "Downloader actions",
		"settingsDlCheckingStatus": "Checking downloader status…",
		"settingsDlCommandCopied": "Fallback command copied. Use it only if the setup file cannot run.",
		"settingsDlCopyCommand": "Copy command",
		"settingsDlCopyCommandTitle": "Copy the fallback PowerShell install command",
		"settingsDlDownloadTitle": "Download the Astra Downloader setup file and reveal it in Downloads",
		"settingsDlGetSetup": "Get setup file",
		"settingsDlGetSetupTitle": "Download the current Astra Downloader setup file to install or update it",
		"settingsDlNotConnected": "Not connected. Local downloads need the setup helper.",
		"settingsDlOpenSetup": "Open setup",
		"settingsDlPreparingSetup": "Preparing the setup file…",
		"settingsDlRunning": "Running",
		"settingsDlRunningTpl": "Running{version}. yt-dlp server ready.",
		"settingsDlSetupDownloaded": "Setup downloaded. Open the file, finish installation, then refresh.",
		"settingsDlSetupOpened": "Setup opened. Finish installation, then refresh.",
		"settingsDlStartFailed": "The service did not start. Run setup to repair Astra Downloader.",
		"settingsDlStartFailedToast": "Astra Downloader did not start. Run setup to repair it.",
		"settingsDlStartTitle": "Try to start the Astra Downloader service",
		"settingsDlTryingStart": "Trying to start the Astra Downloader service…",
		"settingsDownloaderSetupTitle": "Download the Astra Deck downloader setup file",
		"settingsDownloaderTitle": "Astra Downloader",
		"settingsEnableAllAriaTpl": "Enable all settings in {category}",
		"settingsExportAriaTpl": "Export {brand} settings",
		"settingsExportedStatus": "Settings exported. The download is ready.",
		"settingsExportedToast": "Settings exported successfully",
		"settingsFeatureClearAriaTpl": "Clear {featureName}",
		"settingsFeatureKnownBroken": "Paused: a YouTube change broke this feature in this version of Astra Deck. Your setting is untouched and it starts working again when a fix ships.",
		"settingsFeatureKnownBrokenIssueTpl": "Issue #{issue}",
		"settingsFooterSaved": "Saved",
		"settingsGenericSettingFallback": "Setting",
		"settingsGitHubTitle": "View on GitHub",
		"settingsGroupSummaryFallback": "Settings group",
		"settingsHealthNeedsAttention": "Needs attention",
		"settingsHostAccessNeededTpl": "{name} needs host access before it can be enabled. Try again and approve the browser prompt.",
		"settingsImportAriaTpl": "Import {brand} settings",
		"settingsImportDoneTpl": "{message} Undo is available in the toast.",
		"settingsImportHistoryAriaLabel": "Import YouTube Takeout watch history",
		"settingsImportHistoryLabel": "Import History",
		"settingsImportInvalid": "Import failed. Choose a valid Astra Deck settings export.",
		"settingsImportReadFailed": "Could not read import file",
		"settingsImportUndoUnavailable": "Import undo is no longer available.",
		"settingsInsightsAria": "Settings status and backup actions",
		"settingsInsightsEnabled": "Enabled",
		"settingsInsightsExtension": "Extension",
		"settingsInsightsHealth": "Health",
		"settingsInsightsLastSave": "Last save",
		"settingsInsightsLiveApply": "Live apply",
		"settingsInsightsProfile": "Profile",
		"settingsInsightsReadyDesc": "Controls are loaded. Service health appears beside affected features.",
		"settingsInsightsRecovery": "Recovery",
		"settingsInsightsRuleEngine": "Rule engine",
		"settingsInsightsSavedLocally": "Saved locally",
		"settingsInsightsSections": "Sections",
		"settingsInsightsStatus": "Status",
		"settingsInsightsUndoToasts": "Undo toasts",
		"settingsPaneDescriptionFallback": "Adjust how this part of YouTube behaves.",
		"settingsPanelContentControls": "Content Controls",
		"settingsRangeSettingFallback": "Range setting",
		"settingsResetChooseSection": "Choose a settings section before resetting.",
		"settingsResetDoneTpl": "{category} reset to defaults. Undo is available in the toast.",
		"settingsResetGroupTitle": "Reset this group to defaults",
		"settingsResetRestoredToastTpl": "“{category}” restored",
		"settingsResetRestoredTpl": "{category} restored.",
		"settingsResetToastTpl": "“{category}” reset to defaults",
		"settingsSearchHint": "Try a feature name, page, or words like comments, transcript, download, or theme.",
		"settingsSearchMatchesTpl": "{count} matches",
		"settingsSearchMatchingTpl": "{count} matching settings",
		"settingsSearchNoMatches": "No matches",
		"settingsSearchNoneTpl": "No settings found for “{query}”",
		"settingsSearchShowingTpl": "Showing results across {sections} sections for “{query}”. Changes save automatically as you toggle or edit a result.",
		"settingsSectionAiContent": "AI content",
		"settingsSectionAllDisabled": "Disabled all settings in this section.",
		"settingsSectionAllEnabled": "Enabled all settings in this section.",
		"settingsSectionAudio": "Audio",
		"settingsSectionAutomation": "Automation",
		"settingsSectionCaptionsNavigation": "Captions & navigation",
		"settingsSectionCaptureSubtitles": "Capture & subtitles",
		"settingsSectionComposition": "Composition",
		"settingsSectionControls": "Controls",
		"settingsSectionCustomCss": "Custom CSS",
		"settingsSectionDensity": "Density",
		"settingsSectionDiagnostics": "Diagnostics",
		"settingsSectionDiscovery": "Discovery",
		"settingsSectionDiscoveryTranslation": "Discovery & translation",
		"settingsSectionEntryPoints": "Entry points",
		"settingsSectionFeedLayout": "Feed layout",
		"settingsSectionFeedToolsAutomation": "Feed tools & automation",
		"settingsSectionFeedVisibility": "Feed visibility",
		"settingsSectionFilters": "Filters",
		"settingsSectionFormats": "Formats",
		"settingsSectionFoundation": "Foundation",
		"settingsSectionHeader": "Header",
		"settingsSectionInsightsNotes": "Insights & notes",
		"settingsSectionMessages": "Messages",
		"settingsSectionNavigation": "Navigation",
		"settingsSectionNotifications": "Notifications",
		"settingsSectionPageElements": "Page elements",
		"settingsSectionPerformance": "Performance",
		"settingsSectionPlaybackQuality": "Playback & quality",
		"settingsSectionPlayerChrome": "Player chrome",
		"settingsSectionPlayerStateControls": "Player state & controls",
		"settingsSectionPresentation": "Presentation",
		"settingsSectionProfilesWellbeing": "Profiles & wellbeing",
		"settingsSectionRecoveryFullscreen": "Recovery & fullscreen",
		"settingsSectionSession": "Session",
		"settingsSectionSharingActions": "Sharing & actions",
		"settingsSectionShortsDiscovery": "Shorts controls",
		"settingsSectionSponsorblockDearrow": "SponsorBlock & DeArrow",
		"settingsSectionSurfaces": "Surfaces",
		"settingsSectionThreadBehavior": "Thread behavior",
		"settingsSectionTiming": "Timing",
		"settingsSectionToolsHealth": "Tools & health",
		"settingsSectionTranscriptAi": "Transcript & AI",
		"settingsSectionTransformDisplay": "Transform & display",
		"settingsSectionVisibility": "Visibility",
		"settingsShortsDependencyAction": "Open Digital Wellbeing",
		"settingsShortsDependencyCopy": "Daily Shorts limits run through Digital Wellbeing.",
		"settingsShortsLedgerEmpty": "No Shorts watch time recorded today.",
		"settingsShortsLedgerName": "Shorts today",
		"settingsShortsLedgerSnooze": "Snoozed until {time}.",
		"settingsShortsLedgerSummary": "{minutes} min watched today.",
		"settingsSingleResetToastTpl": "“{name}” reset to default",
		"settingsSubFeatureBadge": "Sub",
		"settingsSyncDesc": "Optional: sync validated preferences and Video Hider blocklists through your browser account. Secrets and consent stay local.",
		"settingsSyncOff": "Off. This device only.",
		"settingsSyncOn": "On. Preferences and blocklists sync through your browser account.",
		"settingsSyncTitle": "Browser sync",
		"settingsSyncUnavailable": "Browser sync is unavailable in this browser.",
		"settingsSyncUndo": "Undo last sync",
		"settingsSyncUndoAria": "Restore the local state from before the last browser sync",
		"settingsSyncUndoDone": "Last browser sync undone locally.",
		"settingsSyncUndoFailed": "Could not undo the last browser sync.",
		"settingsTakeoutImportInvalid": "Import failed. Choose a valid YouTube Takeout watch-history JSON file.",
		"settingsTextSettingFallback": "Text setting",
		"settingsValueSavedTpl": "{name} saved.",
		"settingsVersionPrefix": "v",
		"settingsWriteFailed": "Settings could not be saved",
		"shortsDailyLimitMode_hard": "Hard block",
		"shortsDailyLimitMode_snooze": "Snooze 5 minutes",
		"sidebarDocTitle": "Astra Deck: Firefox Sidebar",
		"sidepanelDocTitle": "Astra Deck: Dashboard",
		"sleepTimerHint": "Pause playback after the selected number of minutes.",
		"sleepTimerTitle": "Sleep timer",
		"spAgeNever": "never",
		"spCategory_comments": "Comments",
		"spCategory_dev_diagnostics": "Developer Diagnostics",
		"spCategory_enrichment": "Enrichment",
		"spCategory_feed": "Feed",
		"spCategory_general": "General",
		"spCategory_nav": "Navigation",
		"spCategory_playback_audio": "Playback and Audio",
		"spCategory_privacy_profiles": "Privacy Profiles",
		"spCategory_research_ai": "Research AI",
		"spCategory_shorts": "Shorts",
		"spCategory_watch_player": "Video Player",
		"spCategory_shell": "Page Layout",
		"spCategory_quality_codec": "Quality and Codecs",
		"spCategory_content_filter": "Content Filters",
		"spCategory_live_chat": "Live Chat",
		"spCategory_subscriptions": "Subscriptions",
		"spCategory_downloads": "Downloads",
		"spCategory_subtitles": "Subtitles",
		"spCategory_a11y_perf": "Accessibility and Performance",
		"spContextChecking": "Checking tab",
		"spContextYouTubeTab": "YouTube tab",
		"spEmptyNoTab": "No YouTube tab active.",
		"spEmptyTitleError": "Needs a refresh",
		"spEmptyTitleIdle": "Waiting for signal",
		"spEmptyTitleSuccess": "All clear",
		"spExternalBudgetTpl": "budget {used}/{limit}",
		"spExternalCacheTpl": "cache {state}",
		"spExternalCopy": "Shows whether SponsorBlock, DeArrow, and RYD are responding.",
		"spExternalEmptyNoData": "No external services have been used in this session. Play or navigate once to collect request health.",
		"spExternalEmptyNoDataTitle": "No requests observed yet",
		"spExternalEmptyNoResponse": "Content script is not responding. Reload YouTube, then refresh external API health.",
		"spExternalEmptyNoResponseTitle": "Reconnect integration health",
		"spExternalEmptyNoTab": "Open YouTube to see SponsorBlock, DeArrow, and RYD request health.",
		"spExternalEmptyNoTabTitle": "Open YouTube to check integrations",
		"spExternalFallbackTpl": "fallback {state}",
		"spExternalHostTpl": "host {host}",
		"spExternalKicker": "Integrations",
		"spExternalListAria": "External API health list",
		"spExternalNoRequests": "No requests observed yet.",
		"spExternalOkAgoTpl": "ok {age} ago",
		"spExternalTitle": "Service connections",
		"spLocalOnly": "Local only",
		"spMeta_api": "API",
		"spMeta_comments": "Comments",
		"spMeta_feed": "Feed",
		"spMeta_global": "Global",
		"spMeta_player": "Player",
		"spMeta_safe": "Safe",
		"spMeta_watch": "Watch",
		"spOverviewContextLabel": "Context",
		"spOverviewCopy": "Open a YouTube tab to stream diagnostics, then use quick settings for live recovery.",
		"spOverviewEnabledLabel": "Enabled",
		"spOverviewKicker": "Live workspace",
		"spOverviewSummaryAria": "Dashboard summary",
		"spOverviewTitle": "Workspace health at a glance",
		"spPerfCopy": "Shows which features take longest to start on this YouTube tab.",
		"spPerfEmptyNoData": "Start playback or navigate once, then refresh to capture feature timing.",
		"spPerfEmptyNoDataTitle": "No startup timings yet",
		"spPerfEmptyNoResponse": "Content script is not responding. Reload the YouTube tab, then refresh diagnostics.",
		"spPerfEmptyNoResponseTitle": "Reconnect the active tab",
		"spPerfEmptyNoTab": "Open YouTube in the active tab, then refresh to measure startup timing.",
		"spPerfEmptyNoTabTitle": "Open YouTube to measure startup",
		"spPerfKicker": "Runtime",
		"spPerfListAria": "Feature init timing list",
		"spPerfRowAriaTpl": "{feature}: {ms}ms",
		"spPerfTitle": "Startup timing",
		"spPerfTotalTpl": "{count} measured",
		"spRefreshAria": "Refresh all dashboard sections",
		"spRefreshBtn": "Refresh",
		"spRefreshStatusReady": "Ready",
		"spReloadPanel": "Reload panel",
		"spReloadPanelAria": "Reload the Astra Deck panel",
		"spRiskTpl": "{risk} risk",
		"spRowHostAccessDeniedTpl": "{name}. Needs site access before it can be enabled.",
		"spRowSaveFailedTpl": "{name}. Save failed. Try refreshing the dashboard.",
		"spRowStateRetry": "Try again",
		"spRowStateSaving": "Saving",
		"spScopeTpl": "{scope} scope",
		"spSelectorCopy": "Flags page changes before a control stops working.",
		"spSelectorDriftTpl": "{count} drift",
		"spSelectorEmptyNoData": "Navigate YouTube once, then refresh to sample the surfaces this dashboard tracks.",
		"spSelectorEmptyNoDataTitle": "No surfaces sampled yet",
		"spSelectorEmptyNoResponse": "Content script is not responding. Reload YouTube, then refresh diagnostics.",
		"spSelectorEmptyNoResponseTitle": "Reconnect selector health",
		"spSelectorEmptyNoTab": "Open YouTube in the active tab to check whether page selectors still fit.",
		"spSelectorEmptyNoTabTitle": "Open YouTube to check page fit",
		"spSelectorErrTpl": "{count} err",
		"spSelectorHighChurn": "high churn",
		"spSelectorHitsTpl": "{count} hits",
		"spSelectorKicker": "Page fit",
		"spSelectorListAria": "Selector health list",
		"spSelectorMissTpl": "{count} miss",
		"spSelectorNeedsCapture": "needs capture",
		"spSelectorTitle": "Page compatibility",
		"spSelectorTotalTpl": "{count} surfaces",
		"spSettingRowTitleTpl": "{key} ({category})",
		"spSettingsClearAria": "Clear settings filter",
		"spSettingsClearBtn": "Clear",
		"spSettingsClearFilter": "Clear filter",
		"spSettingsClearFilterAria": "Clear quick settings filter",
		"spSettingsCopy": "Grouped toggles save immediately and sync to open YouTube tabs.",
		"spSettingsCountOnTpl": "{enabled}/{total} on",
		"spSettingsEmptyDefault": "No settings match.",
		"spSettingsEmptyMsg": "Quick settings could not load. Reload the panel, or use the toolbar popup on a YouTube tab to manage every Astra Deck control.",
		"spSettingsEmptyTitle": "No quick settings available",
		"spSettingsErrorMsg": "Quick settings could not load because browser storage is unavailable. Reload the panel, or use the toolbar popup after the extension context is ready.",
		"spSettingsErrorTitle": "Quick settings unavailable",
		"spSettingsKicker": "Live apply",
		"spSettingsListAria": "Settings toggles",
		"spSettingsNoMatchTitle": "No matching quick settings",
		"spSettingsNoMatchTpl": "No settings match \"{query}\". Clear the filter to return to all controls.",
		"spSettingsSearchAria": "Filter settings by name, risk, scope, or category",
		"spSettingsSearchPlaceholder": "Filter settings, risk, scope, or category",
		"spSettingsTitle": "Quick settings",
		"spSkipToSettings": "Skip to settings",
		"spStatSize": "Storage",
		"spStatStoredSettings": "Customized",
		"spStatUnavailable": "Unavailable",
		"spStateUnknown": "unknown",
		"spStatusDisabledTpl": "{name} disabled",
		"spStatusEnabledTpl": "{name} enabled",
		"spStatusHostAccessDenied": "Astra Deck needs host access for this optional feature before it can be enabled.",
		"spStatusOpenYouTube": "Open YouTube for live diagnostics",
		"spStatusRefreshFailed": "Refresh failed. Try again.",
		"spStatusRefreshing": "Refreshing…",
		"spStatusSaveFailed": "Could not save setting",
		"spStatusSettingsLoadFailed": "Diagnostics updated; quick settings could not load",
		"spStatusUpdated": "Live diagnostics updated",
		"spStorageCopy": "Counts local settings, hidden videos, blocked channels, and saved notes.",
		"spStorageStatsAria": "Storage statistics",
		"spStorageUnavailableDetail": "Reload the extension context to read local data.",
		"spSubtitle": "Live diagnostics",
		"spVersionAria": "Extension version",
		"speedBtnAriaTpl": "Default playback speed {speed}. Click to change.",
		"speedBtnTitleTpl": "Default playback speed: {speed}. Applies to every video.",
		"speedPopupAria": "Default playback speed",
		"speedPopupHeader": "Default speed",
		"speedPopupSub": "Applies to every video until changed.",
		"sponsorCachedSegmentTitleTpl": "{label} (cached at {time})",
		"sponsoredFilterAffiliateReason": "affiliate promotion",
		"sponsoredFilterCommentLabel": "Sponsored comment",
		"sponsoredFilterDescriptionLabel": "Sponsored description",
		"sponsoredFilterHideTpl": "Hide {label} ({reason})",
		"sponsoredFilterShowTpl": "Show {label} ({reason})",
		"sponsoredFilterSponsorReason": "sponsor disclosure",
		"spq_autoTheaterMode_desc": "Open videos in theater view.",
		"spq_blueLightFilter_desc": "Warm the player for late viewing.",
		"spq_cleanShareUrls_desc": "Remove tracking parameters from copied links.",
		"spq_commentSearch_desc": "Filter watch-page comments inline.",
		"spq_deArrow_desc": "Replace clickbait titles and thumbnails.",
		"spq_debugMode_desc": "Record detailed local diagnostics for troubleshooting.",
		"spq_debugMode_name": "Diagnostic Logging",
		"spq_digitalWellbeing_desc": "Track breaks and daily viewing time.",
		"spq_disableAutoplayNext_desc": "Stop the next video from starting automatically.",
		"spq_disableAutoplayNext_name": "Disable Autoplay",
		"spq_disableInfiniteScroll_desc": "Stop feeds from loading forever.",
		"spq_disableInfiniteScroll_name": "Cap Infinite Scroll",
		"spq_hideRelatedVideos_desc": "Clear the watch-page side rail.",
		"spq_miniPlayerBar_desc": "Keep essential controls visible while scrolling.",
		"spq_persistentSpeed_desc": "Keep playback speed consistent between videos.",
		"spq_privacyDataFlowPanel_desc": "Review every service Astra Deck can contact.",
		"spq_privacyDataFlowPanel_name": "Data-Flow Panel",
		"spq_removeAllShorts_desc": "Remove Shorts shelves and navigation links.",
		"spq_sponsorBlock_desc": "Skip crowd-marked sponsor segments.",
		"spq_transcriptViewer_desc": "Read, jump through, and export captions.",
		"statBlocked": "Blocked",
		"statBookmarks": "Bookmarks",
		"statHidden": "Hidden",
		"statKeys": "Keys",
		"statStorage": "Storage",
		"statusAllDataCleared": "All data cleared.",
		"statusAllDataClearedUndo": "All data cleared. Click Undo Reset to restore (until you close the browser).",
		"statusBackupExported": "Backup exported.",
		"statusBackupExportedNoTranscript": "Backup exported without the transcript index because no responsive YouTube tab was available.",
		"statusBackupImported": "Backup imported.",
		"statusBackupImportedNoTranscript": "Extension data imported with Undo available. The transcript index was left unchanged because no responsive YouTube tab was available.",
		"statusBackupImportedUndo": "Backup imported. Click Undo Import to restore the previous state. The undo point lasts 7 days and survives closing the browser.",
		"statusClipboardUnavailable": "Copying isn’t available here. Select the text and copy it yourself instead.",
		"statusCompanionCurrentTpl": "Astra Downloader already at v{version}.",
		"statusCompanionReadyTpl": "Astra Downloader update ready: v{current} → v{latest}. Restarting with v{rollback} retained for automatic rollback.",
		"statusCompanionUpdateFailedTpl": "Astra Downloader update failed. {error}",
		"statusDiagClearFail": "Could not clear log",
		"statusDiagCleared": "Diagnostic log cleared.",
		"statusDiagCopied": "Diagnostic copied to clipboard.",
		"statusDiagSaveFail": "Could not save log",
		"statusDiagSaved": "Diagnostic log saved.",
		"statusExportFail": "Export failed",
		"statusImportBackupFileFailed": "Astra Deck could not save a backup file of your previous data first, so Undo Import is the only way back.",
		"statusImportBackupTooNew": "That backup comes from a newer version of Astra Deck. Update Astra Deck, then import it again. Nothing was changed.",
		"statusImportBackupWrittenTpl": "Your previous data was saved to {file} first.",
		"statusImportFail": "Import failed",
		"statusImportNotBackup": "That file is not an Astra Deck backup. Choose the .json file produced by Export. A valid backup contains an \"exportVersion\" field.",
		"statusImportNothingFound": "That backup holds nothing Astra Deck can import, so nothing was changed.",
		"statusImportPreviewApplyTpl": "Import preview: {preview}. Applying with rollback…",
		"statusImportPreviewSummaryTpl": "Preview: {preview}.",
		"statusImportSkippedKeysTplOne": "{count} setting from a newer version was skipped: {keys}",
		"statusImportSkippedKeysTplOther": "{count} settings from a newer version were skipped: {keys}",
		"statusImportSnapshotFail": "Import stopped. Astra Deck could not save an undo point to extension storage, so export a backup first.",
		"statusImportSummaryTpl": "{status} {preview}",
		"statusImportUndoExpired": "Undo Import is no longer available. The undo point expired after 7 days.",
		"statusImportUndoFail": "Undo Import failed",
		"statusImportWrongFile": "That file isn't an Astra Deck backup, so nothing was imported. Choose the .json file that Export saved.",
		"statusMediadlReenableFail": "Could not re-enable Astra Downloader prompts. Open your browser's extensions page and reload.",
		"statusMediadlReenabled": "Astra Downloader install prompts re-enabled. Reload a YouTube tab to see them.",
		"statusOpenDashboardFail": "Could not open dashboard",
		"statusOpenWorkspaceFail": "Could not open the full workspace. Try again.",
		"statusPerKeyResetFail": "Could not reset",
		"statusPerKeyResetTpl": "{key} reset to default.",
		"statusQuickCtrlLoadFail": "Quick controls could not be loaded. Try reopening the popup.",
		"statusResetDoneNoTranscript": "Extension data cleared with Undo available. Transcript data was left unchanged because no responsive YouTube tab was available. Stored AI credentials were retained.",
		"statusResetDoneUndo": "Portable settings, histories, queues, and transcript data cleared. Stored AI credentials are retained; use Delete credential to remove them. Click Undo Reset to restore them. The undo point lasts 7 days and survives closing the browser.",
		"statusResetFail": "Reset failed",
		"statusResetSnapshotFail": "Reset stopped. Astra Deck could not save an undo point to extension storage, so export a backup first.",
		"statusResetUndoExpired": "Undo is no longer available. The undo point expired after 7 days.",
		"statusResetUndoFail": "Undo failed",
		"statusResetUndone": "Reset undone. All data restored.",
		"statusSettingsImportFailed": "Import failed while applying data; previous state was restored.",
		"statusSettingsImportNoEntries": "No importable settings or local data found.",
		"statusSettingsImportNoKnown": "No known settings found in file.",
		"statusSettingsImportUndone": "Import undone. Previous settings and local data restored.",
		"statusStorageReadFail": "Storage read failed",
		"statusTakeoutImportUndone": "Takeout import undone",
		"statusTakeoutNoEntries": "No valid YouTube Takeout watch-history entries found.",
		"statusUpdateFailed": "Update failed.",
		"statusUpdateYtdlpNoTab": "Open a YouTube tab first. The popup needs one to reach Astra Downloader.",
		"statusWelcomePresetFail": "Could not apply preset",
		"statusWelcomeProfileFail": "Could not apply profile",
		"statusWelcomeProfileFull": "GitHub-Full profile enabled. Astra Downloader and AI providers are now available.",
		"statusWelcomeProfileSafe": "Store-safe profile active. Open Full Settings to explore features.",
		"statusYoutubeStateChanged": "YouTube changed its page state before reset, so nothing was cleared.",
		"statusYoutubeStateEmpty": "No stale YouTube page-state keys were found.",
		"statusYoutubeStateNoTab": "Open a YouTube tab before resetting its local page state.",
		"statusYoutubeStateReset": "Cleared {count} stale YouTube page-state keys. Reload YouTube to apply; Undo remains available while the original tab stays open.",
		"statusYoutubeStateResetFail": "YouTube state reset failed",
		"statusYoutubeStateResetPartialUndo": "Cleared {count} stale YouTube page-state keys. {big} exceeded the backup limit, so Undo cannot restore them.",
		"statusYoutubeStateRestored": "Restored {count} YouTube page-state keys. Reload YouTube to apply them.",
		"statusYoutubeStateUndoExpired": "YouTube state Undo is no longer available for the original tab.",
		"statusYoutubeStateUndoFail": "YouTube state Undo failed",
		"statusYtdlpCurrentTpl": "yt-dlp already at v{version}",
		"statusYtdlpFromTpl": " (from v{version})",
		"statusYtdlpRestoredTpl": " Active version restored to v{version}.",
		"statusYtdlpRollbackTpl": " Last-known-good: v{version}.",
		"statusYtdlpUpdateFailedTpl": "yt-dlp update failed. {error}{recovery}",
		"statusYtdlpUpdatedTpl": "yt-dlp updated to v{version}{from}",
		"stickyVideoCloseSidePanelTitle": "Close side panel",
		"stickyVideoLiveActionsAria": "Live video actions",
		"stickyVideoLiveBadge": "LIVE",
		"stickyVideoLiveInfoAria": "Live video information",
		"stickyVideoLiveVideoFallback": "Live video",
		"stickyVideoNowWatching": "Now watching",
		"stickyVideoQuickLinksAria": "Quick links",
		"stickyVideoResizePanelsLabel": "Resize Theater Split panels",
		"stickyVideoSubscriptionsLink": "Go to subscriptions",
		"stickyVideoUploadedTpl": "Uploaded {date}",
		"stickyVideoVideoActionsAria": "Video actions",
		"stickyVideoWatchingNowTpl": "{count} watching now",
		"storageBannerCorruptionTpl": "Storage data is malformed. Choose Reset to recover.",
		"storageBannerHardTpl": "Astra Deck is storing {size}. Trimming the largest lists below keeps it fast.",
		"storageBannerReset": "Reset",
		"storageBannerResetAria": "Reset all local data",
		"storageBannerSoftTpl": "Astra Deck is storing {size} of data on this device.",
		"storageBannerTitle": "Storage usage high",
		"storagePreloadFailed": "Astra Deck could not read your saved settings. This page is running on defaults, so reload to try again.",
		"storageStatsAriaLabel": "Storage statistics",
		"subscriptionAgeDaysShortTpl": "{days}d",
		"subscriptionAiTagsGenerateTitle": "Shift+click to generate AI tags",
		"subscriptionAiTagsGeneratingTpl": "Generating tags for \"{group}\"…",
		"subscriptionAiTagsGenerationFailedTpl": "Tag generation failed: {error}",
		"subscriptionAiTagsNoCards": "No matching cards rendered yet. Scroll the feed, then try again.",
		"subscriptionAiTagsNoUsable": "Summarizer returned no usable tags.",
		"subscriptionAiTagsRegenerateTitleTpl": "AI tags: {tags} · Shift+click to regenerate",
		"subscriptionAiTagsRequired": "Enable \"AI Tags For Subscription Groups\" first.",
		"subscriptionAiTagsTaggedTpl": "Tagged \"{group}\": {tags}",
		"subscriptionAllSubscriptions": "All subscriptions",
		"subscriptionArchiveAdded": "Scheduled",
		"subscriptionArchiveExisting": "already configured",
		"subscriptionArchiveNoChannels": "Add channels to this group before scheduling downloads.",
		"subscriptionArchiveStartCompanion": "Start Astra Downloader before scheduling channel downloads.",
		"subscriptionArchiveUnavailable": "The Astra Downloader companion is not available.",
		"subscriptionBatchFallbackLabel": "subscription-groups:fallback",
		"subscriptionChannelPlural": "channels",
		"subscriptionChannelSingular": "channel",
		"subscriptionChannelsMarkedReadTpl": "Marked {count} {channels} read for {group}",
		"subscriptionCreateGroupDialogAria": "Create subscription group",
		"subscriptionCreateSubgroupDialogAria": "Create subscription subgroup",
		"subscriptionDialogCancel": "Cancel",
		"subscriptionDialogCreate": "Create",
		"subscriptionDigestCloseAria": "Close group notifications digest",
		"subscriptionDigestEmpty": "Create subscription groups with + Group to split new-video counts by topic.",
		"subscriptionDigestMarkAllRead": "Mark all read",
		"subscriptionDigestMarkAllReadAria": "Mark every rendered channel as read",
		"subscriptionDigestMarkAllReadEmpty": "Nothing new since your last visit",
		"subscriptionDigestMarkRead": "Mark read",
		"subscriptionDigestMarkReadAriaTpl": "Mark {group} digest as read",
		"subscriptionDigestMetaTpl": "{newCount} new of {renderedCount} rendered videos",
		"subscriptionDigestNewTpl": "{count} new",
		"subscriptionDigestOpen": "Open Digest",
		"subscriptionDigestOpenAria": "Open the per-group notifications digest",
		"subscriptionDigestRegionAria": "Group notifications digest",
		"subscriptionDigestRenderedTpl": "{shown} shown / {channels} channels",
		"subscriptionDigestTitle": "Group Digest",
		"subscriptionDigestView": "View",
		"subscriptionDigestViewAriaTpl": "View {group} subscriptions",
		"subscriptionExportCsvAria": "Export subscription groups as CSV",
		"subscriptionExportCsvLabel": "CSV",
		"subscriptionExportJsonAria": "Export subscription groups as JSON",
		"subscriptionExportOpmlAria": "Export subscription groups as OPML",
		"subscriptionExportOpmlLabel": "OPML",
		"subscriptionGroupChipAriaTpl": "{name}. {count} {channels}{subgroup}",
		"subscriptionGroupChipTpl": "{prefix}{name} ({count}){tags}",
		"subscriptionGroupDelete": "Delete",
		"subscriptionGroupDeleteAriaTpl": "Delete the group {group}",
		"subscriptionGroupDeleteConfirmTpl": "Delete \"{group}\" and its {count} channels? Your subscriptions are not affected.",
		"subscriptionGroupDeleted": "Group deleted",
		"subscriptionGroupDeletedTpl": "Deleted \"{group}\" and its {count} channels. Your subscriptions are not affected.",
		"subscriptionGroupDialogTitle": "Name this group",
		"subscriptionGroupEmpty": "No channels in this group yet. Choose Edit Channels to add some.",
		"subscriptionGroupNameAria": "Group name",
		"subscriptionGroupNoVideos": "No videos visible in this group",
		"subscriptionGroupPlaceholder": "e.g. Coding, Music, News",
		"subscriptionGroupPlayingTpl": "Playing {count} videos from {group}{truncated}",
		"subscriptionGroupRename": "Rename",
		"subscriptionGroupRenameAriaTpl": "Rename the group {group}",
		"subscriptionGroupRenamePrompt": "New name for this group",
		"subscriptionGroupRenamed": "Group renamed",
		"subscriptionGroupRestoreConflict": "That group name is in use again, so it was not restored.",
		"subscriptionGroupRestored": "Group restored",
		"subscriptionGroupsEmptyCopy": "Choose + Group to create your first group.",
		"subscriptionGroupsEmptyTitle": "No groups yet",
		"subscriptionGroupsExported": "Exported subscription groups",
		"subscriptionGroupsExportedCsv": "Exported subscription groups as CSV",
		"subscriptionGroupsExportedOpml": "Exported subscription groups as OPML",
		"subscriptionGroupsImportFailedTpl": "Import failed: {error}",
		"subscriptionGroupsImportOpmlFailedTpl": "OPML import failed: {error}",
		"subscriptionGroupsRestored": "Restored previous subscription groups",
		"subscriptionHealthCloseAria": "Close subscription health center",
		"subscriptionHealthFailedTpl": "Health scan failed: {error} The feed may still be loading, so Rescan may help.",
		"subscriptionHealthMetaTpl": "{channels} rendered channels · {groups} groups",
		"subscriptionHealthMoreTpl": "+{count} more. Use Stage Stale in the toolbar to stage every candidate at once.",
		"subscriptionHealthNewEmpty": "Nothing new since your last visit stamp.",
		"subscriptionHealthNewHeading": "New since last visit",
		"subscriptionHealthNewSummaryTpl": "{videos} new videos from {channels} channels since your last visit.",
		"subscriptionHealthNoStaleCards": "No stale subscription cards found in the rendered feed.",
		"subscriptionHealthOpenAria": "Open the subscription health center",
		"subscriptionHealthRegionAria": "Subscription health center",
		"subscriptionHealthRemovedStagedTpl": "Removed {count} staged unsubscribes",
		"subscriptionHealthRescan": "Rescan",
		"subscriptionHealthRescanAria": "Rescan the rendered feed for subscription health",
		"subscriptionHealthStage": "Stage",
		"subscriptionHealthStageAriaTpl": "Stage {channel} for unsubscribe review",
		"subscriptionHealthStaged": "staged",
		"subscriptionHealthStagedCountTpl": "Staged {count} stale channels for unsubscribe review",
		"subscriptionHealthStagedEmpty": "Nothing staged. Stage stale channels to review them before a bounded unsubscribe session.",
		"subscriptionHealthStagedHeading": "Staged unsubscribes (review before applying, 30-day recovery window)",
		"subscriptionHealthStaleEmpty": "No stale channels detected among the rendered cards. Scroll to load more of the feed, then Rescan.",
		"subscriptionHealthStaleHeadingTpl": "Stale channels (≥{days} days, rendered feed)",
		"subscriptionHealthStatNewChannels": "new channels",
		"subscriptionHealthStatNewVideos": "new videos",
		"subscriptionHealthStatStaged": "staged for review",
		"subscriptionHealthStatStale": "stale candidates",
		"subscriptionHealthTitle": "Subscription Health",
		"subscriptionHealthUndoAllAria": "Undo every staged unsubscribe",
		"subscriptionHealthUndoAllTpl": "Undo all staged ({count})",
		"subscriptionHealthUndoByTpl": "undo by {date}",
		"subscriptionHealthUndoStage": "Undo stage",
		"subscriptionHealthUndoStageAriaTpl": "Undo staged unsubscribe for {channel}",
		"subscriptionImportAria": "Import subscription groups",
		"subscriptionImportTitle": "Import subscription groups (merges with your groups; Shift+click replaces them)",
		"subscriptionImportedOpml": "Imported OPML",
		"subscriptionLoadedOnlyHint": "Newest first sorts only videos loaded on this page. Scroll to load more.",
		"subscriptionMembersAdded": "Channel added to group",
		"subscriptionMembersCapped": "Group is full at 1000 channels. Remove one first.",
		"subscriptionMembersCloseAria": "Close the channel membership editor",
		"subscriptionMembersEmpty": "No channels rendered yet. Scroll the subscriptions feed, then reopen this panel.",
		"subscriptionMembersIncludeChannelAriaTpl": "Include {channel} in {group}",
		"subscriptionMembersListAria": "Rendered channels",
		"subscriptionMembersMeta": "Check a channel to add it to this group. Changes save immediately. Scroll the feed to surface more channels.",
		"subscriptionMembersRegionAriaTpl": "Edit channels in {group}",
		"subscriptionMembersRemoved": "Channel removed from group",
		"subscriptionMembersTitleTpl": "Edit channels in {group}",
		"subscriptionMenuUnsubscribe": "Unsubscribe",
		"subscriptionNewBadge": "NEW",
		"subscriptionOrderGroupsHint": "Sort in the group toolbar orders this feed. Your saved order applies when Subscription Groups is off.",
		"subscriptionOrderLabel": "Order",
		"subscriptionOrderNative": "YouTube order",
		"subscriptionOrderNewestLoaded": "Newest first (loaded only)",
		"subscriptionQueueCappedTpl": " (capped at {count})",
		"subscriptionRenderedSubscriptions": "rendered subscriptions",
		"subscriptionSortLatest": "Latest first",
		"subscriptionSortNewSinceLastVisit": "New since last visit",
		"subscriptionSortPopular": "Most popular (views)",
		"subscriptionSortShortest": "Shortest first",
		"subscriptionSortUnwatched": "Unwatched first",
		"subscriptionSortYouTubeDefault": "YouTube default",
		"subscriptionStagedBadge": "STAGED",
		"subscriptionStagedReviewTitle": "Unsubscribe staged for review.",
		"subscriptionStagedUndoTitleTpl": "Unsubscribe staged. Undo window ends {date}.",
		"subscriptionStaleAgeTitleTpl": "{days} days since the newest rendered upload on this card",
		"subscriptionStaleBadge": "STALE",
		"subscriptionSubgroupNameTpl": "Name a subgroup under {group}",
		"subscriptionSubgroupPlaceholder": "e.g. Frontend, DevOps, Jazz",
		"subscriptionSubgroupSuffix": ". Subgroup",
		"subscriptionSummarizerUnavailable": "Local Summarizer not available; enable the Chrome AI origin trial.",
		"subscriptionToolbarAllAria": "Show all subscriptions",
		"subscriptionToolbarArchive": "Auto-download",
		"subscriptionToolbarArchiveAriaTpl": "Schedule new uploads from {group}",
		"subscriptionToolbarArchiveTitle": "Schedule this group in Astra Downloader. Existing uploads are deduplicated by the companion archive.",
		"subscriptionToolbarAria": "Subscription group controls",
		"subscriptionToolbarDigest": "Digest",
		"subscriptionToolbarEditChannels": "Edit Channels",
		"subscriptionToolbarGroups": "Groups",
		"subscriptionToolbarHealth": "Health",
		"subscriptionToolbarHealthCountTpl": "Health ({count})",
		"subscriptionToolbarHealthTitle": "Stale channels, staged unsubscribes, new-video counts, and exports in one panel.",
		"subscriptionToolbarNewGroup": "+ Group",
		"subscriptionToolbarNewGroupAria": "Create subscription group",
		"subscriptionToolbarNewSubgroup": "+ Subgroup",
		"subscriptionToolbarNewSubgroupAria": "Create subscription subgroup",
		"subscriptionToolbarPlayAll": "Play All",
		"subscriptionToolbarPlayAllAriaTpl": "Play all videos from {group}",
		"subscriptionToolbarScanStale": "Scan Stale",
		"subscriptionToolbarScanStaleAria": "Scan rendered subscriptions for stale channels",
		"subscriptionToolbarSort": "Sort",
		"subscriptionToolbarSortAria": "Sort subscriptions",
		"subscriptionToolbarStageStale": "Stage Stale",
		"subscriptionToolbarStageStaleAria": "Stage rendered stale channels for unsubscribe review",
		"subscriptionToolbarStageStaleTitle": "Stage rendered stale channels for review. No YouTube unsubscribe buttons are clicked.",
		"subscriptionToolbarStale": "Stale",
		"subscriptionToolbarStaleFlaggedTpl": "{count} stale channels flagged",
		"subscriptionToolbarUndoStagedAriaTpl": "Undo {count} staged unsubscribe items",
		"subscriptionToolbarUndoStagedTpl": "Undo Staged ({count})",
		"subscriptionUnsubscribeCapTpl": "{count} remain staged beyond the {cap}-per-run cap.",
		"subscriptionUnsubscribeEmpty": "Nothing is staged for unsubscribe.",
		"subscriptionUnsubscribeLogAria": "Export the local unsubscribe session log as JSON",
		"subscriptionUnsubscribeLogButton": "Unsubscribe log",
		"subscriptionUnsubscribeLogEmpty": "No unsubscribe sessions recorded yet.",
		"subscriptionUnsubscribeLogExportedTpl": "Exported {count} unsubscribe sessions",
		"subscriptionUnsubscribeRunAriaTpl": "Unsubscribe up to {count} staged channels in this bounded session",
		"subscriptionUnsubscribeRunTitleTpl": "Apply YouTube unsubscribe only to the staged review list, up to {count} channels at 400 ms pacing.",
		"subscriptionUnsubscribeRunTpl": "Unsubscribe staged ({count})",
		"subscriptionUnsubscribeRunning": "An unsubscribe session is already running.",
		"subscriptionUnsubscribeSessionTpl": "{removed} unsubscribed, {failed} unchanged; {remaining} remain staged.",
		"subscriptionViewCompact": "Compact",
		"subscriptionViewGrid": "Grid",
		"subscriptionViewLabel": "View",
		"subscriptionViewList": "List",
		"subscriptionViewToolbarLabel": "Subscription view controls",
		"subtitleDownloadFailed": "Subtitle download failed",
		"switchLabelOff": "off",
		"switchLabelOn": "on",
		"thumbnailDownloadAria": "Download thumbnail",
		"thumbnailDownloadBusy": "Downloading…",
		"thumbnailDownloadDone": "Downloaded",
		"thumbnailDownloadDoneAria": "Thumbnail downloaded",
		"thumbnailDownloadFailed": "Thumbnail download failed. Check the browser download prompt and try again.",
		"thumbnailDownloadFailedAria": "Thumbnail download failed. Retry",
		"thumbnailDownloadLabel": "Thumbnail",
		"thumbnailDownloadRetry": "Retry",
		"timestampBookmarkAddedTpl": "Bookmarked at {time}",
		"timestampBookmarkAlreadyExists": "Bookmark already exists here",
		"timestampBookmarkRemovedTpl": "Removed bookmark at {time}",
		"timestampBookmarkRestoredTpl": "Restored bookmark at {time}",
		"timestampBookmarksAddNoteMeta": "Add a note to remember why it matters",
		"timestampBookmarksDeleteAriaTpl": "Delete bookmark at {time}",
		"timestampBookmarksEmptyCopy": "Use Save Current Time to pin a moment from this video and add notes you can revisit later.",
		"timestampBookmarksEmptyStatus": "Save important moments here so you can jump back without scrubbing.",
		"timestampBookmarksEmptyTitle": "No bookmarks yet",
		"timestampBookmarksEyebrow": "Jump Back In",
		"timestampBookmarksJumpAriaTpl": "Jump to {time}",
		"timestampBookmarksJumpLabel": "Jump to moment",
		"timestampBookmarksNoteAriaTpl": "Note for bookmark at {time}",
		"timestampBookmarksNoteLabel": "Note",
		"timestampBookmarksNotePlaceholder": "Add note…",
		"timestampBookmarksRegionAriaTpl": "{count} bookmarks for this video",
		"timestampBookmarksSaveCurrentTime": "Save Current Time",
		"timestampBookmarksSavedNoteMeta": "Saved note included",
		"timestampBookmarksSavedStatus": "Jump back to saved moments and keep quick notes beside each one.",
		"timestampBookmarksSavedTpl": "{count} Saved",
		"timestampHighlightExport": "Export Highlight Pack",
		"timestampHighlightExportAria": "Export this video’s highlights, notes, bookmarks, and summary",
		"timestampHighlightExportFailed": "Highlight export failed. Your saved data is unchanged.",
		"timestampHighlightExported": "Highlight pack exported as Markdown and JSON.",
		"timestampHighlightExporting": "Preparing highlight pack…",
		"timestampHighlightNoVideo": "No video is currently open.",
		"toastActionManage": "Manage",
		"toastActionOpen": "Open",
		"toastActionUndo": "Undo",
		"toastActionStop": "Stop",
		"toastCookieHandoffDisclosure": "Authenticated download: only the required YouTube sign-in cookies are being sent to Astra Downloader on this device.",
		"toastDismissAria": "Dismiss notification",
		"toastDlCmdCopied": "Fallback install command copied. Use it only if you cannot run the downloaded setup file.",
		"toastDlInProgress": "A download is already in progress.",
		"toastDlInstallPrompt": "Install Astra Downloader to enable downloads.",
		"toastDlPreparingAudio": "Preparing your audio download…",
		"toastDlPreparingVideo": "Preparing your video download…",
		"toastDlReady": "Astra Downloader is ready.",
		"toastDlRequestFailed": "Astra Downloader request failed.",
		"toastDlRunning": "Astra Downloader is running!",
		"toastDlStarted": "Astra Downloader started!",
		"toastDlStarting": "Starting Astra Downloader…",
		"toastDlStopped": "Astra Downloader stopped. Starting it again…",
		"toastDlTimedOut": "Astra Downloader took too long to answer. The download may already be queued, so check the downloader before trying again.",
		"toastStorageWriteFailed": "Astra Deck cannot save to this browser profile. Recent changes may be lost.",
		"toggleRiskTooltip_api": "Talks to an external API server",
		"toggleRiskTooltip_experimental": "Experimental feature; behaviour may change",
		"toggleRiskTooltip_local_companion": "Talks to the local Astra Downloader (127.0.0.1)",
		"toggleRiskTooltip_store_risk": "Higher review-policy sensitivity. GitHub-full only.",
		"toggleStateOff": "Disabled",
		"toggleStateOffLower": "disabled",
		"toggleStateOn": "Enabled",
		"toggleStateOnLower": "enabled",
		"toggleStatusTpl": "{name} {state}.",
		"toggleUpdateFailTpl": "Couldn’t update {name}. Try again.",
		"transcriptBatchCancelled": "Transcript batch cancelled after navigation",
		"transcriptBatchExportedToastTpl": "Exported transcript study pack ({done}/{total} succeeded)",
		"transcriptBatchExportedTpl": "Exported {done}/{total}; failures are included in JSONL",
		"transcriptBatchQueueCapTpl": "Queue cap {count}, one recovery pass per video",
		"transcriptBatchTitle": "Transcript study pack",
		"transcriptCaptions": "Captions",
		"transcriptCollapse": "Collapse",
		"transcriptCollapseAria": "Collapse transcript",
		"transcriptCopiedTpl": "{label} copied to clipboard",
		"transcriptCopyAiPrompt": "Copy AI Prompt",
		"transcriptCopyAiPromptTitle": "Copy a ready-to-paste summary prompt",
		"transcriptCopyFailedTpl": "Failed to copy {label}",
		"transcriptCopyText": "Copy Text",
		"transcriptCopyTextTitle": "Copy plain-text transcript to clipboard",
		"transcriptDownloadFailed": "Download failed",
		"transcriptDownloadSrt": "Download SRT",
		"transcriptDownloadSrtTitle": "Download SubRip subtitle file",
		"transcriptDownloadTxt": "Download TXT",
		"transcriptDownloadTxtTitle": "Download plain-text transcript",
		"transcriptDownloadedTpl": "Transcript downloaded! ({count} segments)",
		"transcriptExpand": "Expand",
		"transcriptExpandAria": "Expand transcript",
		"transcriptExpiryUnknown": "not advertised",
		"transcriptExportActionsAria": "Transcript export actions",
		"transcriptEyebrow": "Captions & Exports",
		"transcriptFetching": "Fetching transcript…",
		"transcriptIndexUsageFailed": "Could not measure the local index.",
		"transcriptIndexUsageLoading": "Measuring local index…",
		"transcriptIndexUsageTpl": "{count} of {maxCount} videos indexed, {size} of {budget}. Oldest entries are removed first.",
		"transcriptJumpAriaTpl": "Jump to {time} in the transcript",
		"transcriptLanguageUnknown": "language unknown",
		"transcriptLlmPrompt": "LLM prompt",
		"transcriptLoadFailed": "Failed to load transcript",
		"transcriptMetaPanelTpl": "Loaded from {source} {age}; {language}.",
		"transcriptMetaRefreshedTpl": "Replaced an expired caption URL from {source}; fetched {age}; {language}.",
		"transcriptMetaSourceTpl": "Loaded from {source} {age}; {language}; track URL expiry: {expires}.",
		"transcriptNoCaptions": "No Captions",
		"transcriptNoCaptionsHelp": "Try another video with captions enabled, or reopen this panel after captions finish loading.",
		"transcriptNoVideoId": "No video ID found",
		"transcriptPanelFallback": "Panel Fallback",
		"transcriptPreparingControls": "Preparing transcript controls for this video.",
		"transcriptQaAsk": "Ask",
		"transcriptQaButton": "Q&A",
		"transcriptQaButtonTitle": "Ask citation-backed questions about this video.",
		"transcriptQaCitationLabel": "Transcript citation",
		"transcriptQaClose": "Close Transcript Q&A",
		"transcriptQaConfiguredUnavailable": "The configured provider lane is unavailable in this build or profile.",
		"transcriptQaDialogDescription": "Answers use selected transcript passages. Every displayed claim links to its supporting timestamp.",
		"transcriptQaDialogTitle": "Transcript Q&A",
		"transcriptQaFailed": "The transcript question could not be answered.",
		"transcriptQaHistory": "Transcript Q&A history",
		"transcriptQaHistoryRestored": "Saved questions restored for this transcript and provider.",
		"transcriptQaLaneConfigured": "Configured provider",
		"transcriptQaLaneOnDevice": "On-device only",
		"transcriptQaLoading": "Loading transcript evidence…",
		"transcriptQaLocalUnavailable": "The on-device Prompt API is unavailable. Select a configured provider to use a permitted remote or Ollama lane.",
		"transcriptQaNoAnswer": "The selected transcript passages do not support an answer.",
		"transcriptQaNoHistory": "No saved questions for this transcript yet.",
		"transcriptQaNoTranscript": "No transcript is available for this video.",
		"transcriptQaQuestionLabel": "Question",
		"transcriptQaQuestionPlaceholder": "Ask a question about this video…",
		"transcriptQaReady": "Ready for a transcript question.",
		"transcriptQaSaveFailed": "Saving the Q&A history failed. It may disappear after a reload.",
		"transcriptQaThinking": "Checking transcript evidence…",
		"transcriptRefreshedTrack": "Refreshed Track",
		"transcriptRetryHelp": "Reload the page or try again in a moment if captions are still processing.",
		"transcriptShowOriginal": "Show Original",
		"transcriptSourceInnertube": "fresh YouTube player data",
		"transcriptSourcePanel": "the current YouTube transcript panel",
		"transcriptSourcePlayerGlobal": "the current page player data",
		"transcriptSourceUnknown": "YouTube captions",
		"transcriptSourceWatchPage": "a fresh YouTube watch page",
		"transcriptStoreChecking": "Checking the transcript store…",
		"transcriptStoreClearFailed": "The export was saved, but the store could not be cleared.",
		"transcriptStoreClearNow": "Clear the store",
		"transcriptStoreClearNowAria": "Clear the store, after checking the exported file",
		"transcriptStoreDamagedTplOne": "Transcript store: {size} across {count} video, {corrupt} of them unreadable.",
		"transcriptStoreDamagedTplOther": "Transcript store: {size} across {count} videos, {corrupt} of them unreadable.",
		"transcriptStoreEmpty": "Transcript store: empty.",
		"transcriptStoreExportFailed": "Could not export the transcript store. Nothing was cleared.",
		"transcriptStoreExportUnconfirmed": "Astra Deck can't confirm the export reached your downloads, so nothing was cleared yet. Check for astra-deck-transcripts-recovery.json, then press Clear the store.",
		"transcriptStoreFailed": "Transcript store: could not be measured.",
		"transcriptStoreNoTab": "Transcript store: open a YouTube tab to measure it.",
		"transcriptStoreOkTplOne": "Transcript store: {size} across {count} video.",
		"transcriptStoreOkTplOther": "Transcript store: {size} across {count} videos.",
		"transcriptStoreRecover": "Export and clear",
		"transcriptStoreRecoverAria": "Export the readable transcripts, then clear the damaged store",
		"transcriptStoreRecoveredTplOne": "Exported {count} readable transcript and cleared the store.",
		"transcriptStoreRecoveredTplOther": "Exported {count} readable transcripts and cleared the store.",
		"transcriptTimeUnknown": "at an unknown time",
		"transcriptTitle": "Transcript",
		"transcriptTranslate": "Translate",
		"transcriptTranslateTitle": "Translate transcript on-device using Chrome Translator API",
		"transcriptTranslateUnavailable": "Chrome Translator API not available in this browser",
		"transcriptTranslatedTpl": "Translated to {language}",
		"transcriptTranslating": "Translating…",
		"transcriptTranslationFailedTpl": "Translation failed: {error}",
		"transcriptUnavailable": "No transcript available for this video",
		"transcriptUnavailableLabel": "Unavailable",
		"transcriptUnavailableNow": "The transcript could not be fetched from YouTube right now.",
		"uiFontDefault": "YouTube default",
		"uiFontMono": "Monospace",
		"uiFontReadable": "High-legibility (dyslexia-friendly)",
		"uiFontSerif": "Serif",
		"uiFontSystem": "System UI",
		"ui_commentLikeBadge": "Like",
		"ui_commentLikeBadgeCountAriaTpl": "{label}. {count} likes",
		"ui_rydCachedTitleHoursTpl": "Cached dislike count from Return YouTube Dislike ({hours}h old).",
		"ui_rydCachedTitleRecent": "Cached dislike count from Return YouTube Dislike (<1h old).",
		"ui_rydCardRatioSuffix": "liked · estimated by Return YouTube Dislike",
		"ui_rydCountAriaTpl": "{count} estimated dislikes. {estimate}",
		"ui_rydEstimateDisclosure": "Return YouTube Dislike counts are estimates after YouTube removed public dislike totals; low-traffic videos can be less accurate.",
		"ui_rydEstimateShort": "est.",
		"ui_rydLiveTitleTpl": "Live dislike count from Return YouTube Dislike ({used}/{limit}/min used). {estimate}",
		"ui_rydOff": "RYD off",
		"ui_rydPaused": "RYD paused",
		"ui_rydPausedTitleTpl": "Return YouTube Dislike is paused. Rate limited at {used}/{limit} per minute. Resumes in {seconds}s.",
		"ui_rydRatioTitleTpl": "Like ratio uses estimated Return YouTube Dislike counts. {estimate}",
		"ui_rydRatioTpl": "{ratio}% liked",
		"ui_rydSampleTpl": "Estimated from {sample} recorded votes.",
		"ui_rydUnavailableTitle": "Return YouTube Dislike is unavailable. The API didn’t return a usable response, so check your network or try again later.",
		"undo": "Undo",
		"undoImportAria": "Restore data from the most recent Import",
		"undoImportBtn": "Undo Import",
		"undoResetAria": "Restore data from the most recent Reset",
		"undoResetBtn": "Undo Reset",
		"unknown": "Unknown",
		"updateCompanionAria": "Update Astra Downloader companion",
		"updateCompanionBtn": "Update Astra Downloader",
		"updateYtdlpAria": "Force yt-dlp self-update",
		"updateYtdlpBtn": "Update yt-dlp",
		"videoHiderAddAllowedChannelCopy": "Paste a channel URL, handle, or channel ID. Only channels in this list are filtered by allowlist mode; an empty list is safe and applies no channel filter.",
		"videoHiderAddAllowedChannelTitle": "Add Allowed Channel",
		"videoHiderAddAllowedVideoCopy": "Paste a YouTube URL or video ID to keep it visible even when a filter still matches.",
		"videoHiderAddAllowedVideoTitle": "Add Allowed Video",
		"videoHiderAddBlockedChannelCopy": "Paste a channel URL, handle, or channel ID to add it to the channel blocklist.",
		"videoHiderAddBlockedChannelTitle": "Add Blocked Channel",
		"videoHiderAddHiddenVideoCopy": "Paste a YouTube URL or video ID to add it directly to the hidden list.",
		"videoHiderAddHiddenVideoTitle": "Add Hidden Video",
		"videoHiderAddedAllowedVideoToast": "Video added to allowed list",
		"videoHiderAddedHiddenVideoToast": "Video added to hidden list",
		"videoHiderAllowChannelButton": "Allow Channel",
		"videoHiderAllowRightClickBlockDesc": "Use right-click on the thumbnail X button to block the whole channel.",
		"videoHiderAllowRightClickBlockTitle": "Allow right-click channel blocking",
		"videoHiderAllowVideoButton": "Allow Video",
		"videoHiderAllowedChannelLabel": "Allowed Channel",
		"videoHiderAllowedChannelToast": "Channel allowed: {name}",
		"videoHiderAllowedChannelsCountTpl": "{count} channels allowed",
		"videoHiderAllowedChannelsStatus": "Allowed",
		"videoHiderAllowedChannelsTab": "Allowed Channels",
		"videoHiderAllowedVideoPreviewAltTpl": "Preview thumbnail for allowed video {videoId}",
		"videoHiderAllowedVideoSummary": "Allowed by manual restore. Automatic filters skip this video while the exception remains.",
		"videoHiderAllowedVideosRestored": "Allowed videos restored",
		"videoHiderAllowedVideosTab": "Allowed Videos",
		"videoHiderAlreadyAllowedChannelToast": "{name} is already allowed",
		"videoHiderAlreadyAllowedVideoToast": "Video is already allowed",
		"videoHiderAlreadyBlockedChannelToast": "{name} is already blocked",
		"videoHiderBlockedChannelAddedToast": "{name} blocked",
		"videoHiderAllowedChannelAddedToast": "{name} allowed",
		"videoHiderClearedAllowedChannelsToast": "Cleared {count} allowed channels",
		"videoHiderAlreadyHiddenVideoToast": "Video is already hidden",
		"videoHiderBatchesSuffix": "batches",
		"videoHiderBlockChannelButton": "Block Channel",
		"videoHiderBlockedChannelLabel": "Blocked Channel",
		"videoHiderBlockedChannelToast": "Blocked: {name}",
		"videoHiderBlockedChannelsStatus": "Blocked",
		"videoHiderBlockedChannelsTab": "Blocked Channels",
		"videoHiderChannelActionToggle": "Allow right-click channel actions",
		"videoHiderChannelActionToggleDesc": "Use right-click on the thumbnail X button to add the channel to the active channel list.",
		"videoHiderChannelAllowlistCopy": "Only channels in this list remain eligible for channel-based filtering. Remove an entry to let that channel pass the allowlist check again. Astra Deck matches the canonical channel ID first, then falls back to handle, vanity path, URL, and legacy ID.",
		"videoHiderChannelAllowlistEmptyCopy": "Add channels here or right-click the thumbnail X button to allow a channel. An empty allowlist is safe and applies no channel filter.",
		"videoHiderChannelAllowlistEmptyEyebrow": "Allowlist is empty",
		"videoHiderChannelAllowlistEmptyTitle": "No allowed channels yet",
		"videoHiderChannelAllowlistEyebrow": "Allowlist",
		"videoHiderChannelAllowlistPlaceholder": "https://youtube.com/@channel or @handle",
		"videoHiderChannelAllowlistToggle": "Use channel allowlist mode",
		"videoHiderChannelAllowlistToggleDesc": "Only channels in Allowed Channels are considered by channel filtering. An empty list is safe and applies no channel filter.",
		"videoHiderChannelBlockingDisabled": "Channel blocking is disabled",
		"videoHiderChannelBlocklistCopy": "Blocked channels stay hidden across supported feeds until you remove them here. Astra Deck matches the canonical channel ID first, then falls back to handle, vanity path, URL, and legacy ID.",
		"videoHiderChannelBlocklistEmptyCopy": "Right-click the thumbnail X button when you want to block a channel everywhere that Video Hider runs. Channel IDs are preferred, with handles and URLs kept as fallbacks.",
		"videoHiderChannelBlocklistEmptyEyebrow": "Channel Blocks",
		"videoHiderChannelBlocklistEmptyTitle": "No blocked channels yet",
		"videoHiderChannelBlocklistEyebrow": "Blocklist",
		"videoHiderChannelBlocklistPlaceholder": "https://youtube.com/@channel or @handle",
		"videoHiderChannelListCount": "{count} in Your List",
		"videoHiderChannelsRestored": "Channels restored",
		"videoHiderClearAllowedChannels": "Clear Allowed Channels",
		"videoHiderClearAllowedTpl": "Clear Allowed Videos ({count})",
		"videoHiderClearAllowedVideosTpl": "Cleared {count} allowed videos",
		"videoHiderClearBlockedChannels": "Unblock All Channels",
		"videoHiderClearBlockedChannelsTpl": "Unblock All Channels ({count})",
		"videoHiderClearHiddenEntriesTpl": "Cleared {count} hidden list entries",
		"videoHiderClearHiddenListTpl": "Clear Hidden List Only ({count})",
		"videoHiderConsecutiveBatchesDesc": "Lower values stop faster. Higher values allow more loading before the limiter steps in.",
		"videoHiderConsecutiveBatchesLabel": "Consecutive Hidden Batches",
		"videoHiderDaysSuffix": "days old",
		"videoHiderDurationFilterDesc": "Automatically hide videos shorter than your chosen minimum length.",
		"videoHiderDurationFilterTitle": "Duration Filter",
		"videoHiderEnableAria": "Enable Video Hider",
		"videoHiderFeatureOff": "Feature Off",
		"videoHiderFeatureOn": "Feature On",
		"videoHiderFiltersLimitsTab": "Filters & Limits",
		"videoHiderHiddenListRestored": "Hidden list restored",
		"videoHiderHiddenReason": "Hidden by Video Hider: {reason}",
		"videoHiderHiddenToast": "Video hidden",
		"videoHiderHiddenVideoPreviewAltTpl": "Preview thumbnail for hidden video {videoId}",
		"videoHiderHiddenVideoSummary": "Hidden from recommendations until you restore it. Restoring can add an exception so automatic rules leave it visible.",
		"videoHiderHiddenVideosRestored": "Hidden videos restored",
		"videoHiderHiddenVideosTab": "Hidden Videos",
		"videoHiderHideAgain": "Hide Again",
		"videoHiderHideAllowedVideoAriaTpl": "Hide allowed video {videoId} again",
		"videoHiderHideAutoDubbedDesc": "Hide cards labeled as dubbed, auto-dubbed, or alternate-audio videos.",
		"videoHiderHideAutoDubbedTitle": "Hide auto-dubbed videos",
		"videoHiderHideButtonAllowChannel": "Hide this video (right-click to allow channel)",
		"videoHiderHideButtonBlockChannel": "Hide this video (right-click to block channel)",
		"videoHiderHideLiveDesc": "Hide live-now cards and live recommendations when they appear in supported feeds.",
		"videoHiderHideLiveTitle": "Hide live streams",
		"videoHiderHideLowViewDesc": "Hide videos below the view-count threshold when YouTube exposes a view count on the card.",
		"videoHiderHideLowViewTitle": "Hide low-view videos",
		"videoHiderHideMixesDesc": "Hide radio-style mixes and auto-generated recommendation mixes.",
		"videoHiderHideMixesTitle": "Hide YouTube Mixes",
		"videoHiderHideMoviesDesc": "Hide rental, purchase, free-with-ads, and movie-labeled cards.",
		"videoHiderHideMoviesTitle": "Hide movies",
		"videoHiderHidePlaylistsDesc": "Hide playlist and multi-video cards from supported feed surfaces.",
		"videoHiderHidePlaylistsTitle": "Hide playlist cards",
		"videoHiderHideUpcomingDesc": "Hide scheduled, upcoming, and reminder-driven video cards.",
		"videoHiderHideUpcomingTitle": "Hide upcoming premieres",
		"videoHiderHideVideoButton": "Hide Video",
		"videoHiderInvalidChannelInput": "Enter a valid YouTube channel URL, handle, or channel ID.",
		"videoHiderInvalidVideoInput": "Enter a valid YouTube video URL or 11-character video ID.",
		"videoHiderKeywordHintAllow": "!keyword always allows matches",
		"videoHiderKeywordHintHide": "keyword hides matches",
		"videoHiderKeywordHintRegex": "/pattern/i runs a regex rule",
		"videoHiderKeywordRulesTab": "Keyword Rules",
		"videoHiderKeywordStatusEmpty": "Empty",
		"videoHiderKeywordStatusLive": "Live",
		"videoHiderKeywordsPlaceholder": "reaction, unboxing, prank, shorts…",
		"videoHiderKeywordsRulesCopy": "Separate entries with commas. Rules apply immediately after you update this field.",
		"videoHiderKeywordsRulesLabel": "Keywords & Rules",
		"videoHiderKeywordsRulesSectionCopy": "Hide videos by title or channel text. Add comma-separated keywords, use ! to always allow a match, or start with / for regex.",
		"videoHiderLoadLimiterAria": "Enable subscription load limiter",
		"videoHiderLoadLimiterDesc": "Recommended if you hide a lot of subscription feed content.",
		"videoHiderLoadLimiterLabel": "Enable Load Limiter",
		"videoHiderLocalHeuristicsDesc": "Optional, card-local checks for explicit synthetic narration, aging low-view uploads, and unusually high upload cadence. No network or crowd database is used.",
		"videoHiderLocalHeuristicsTitle": "Local low-signal heuristics",
		"videoHiderLowViewThresholdDesc": "Videos below this view count are hidden only when low-view filtering is enabled.",
		"videoHiderLowViewThresholdLabel": "Low-View Threshold",
		"videoHiderMarkWatched": "Mark as watched",
		"videoHiderMarkWatchedToggle": "Show mark-as-watched button",
		"videoHiderMarkWatchedToggleDesc": "Add a per-card control that marks a video watched locally. Marked cards dim, or hide when Remove hidden cards is enabled.",
		"videoHiderMarkedWatched": "Marked as watched",
		"videoHiderMinimumDurationDesc": "Use 0 to disable this rule.",
		"videoHiderMinimumDurationLabel": "Minimum Duration",
		"videoHiderMinutesSuffix": "minutes",
		"videoHiderMissingHiddenVideoToast": "Video was not in the hidden list",
		"videoHiderMovedHiddenVideoToast": "Video moved from hidden to allowed",
		"videoHiderNoVisibleVideos": "No visible videos to hide",
		"videoHiderOpenAllowedVideoAriaTpl": "Open allowed video {videoId} on YouTube",
		"videoHiderOpenChannel": "Open Channel",
		"videoHiderOpenHiddenVideoAriaTpl": "Open hidden video {videoId} on YouTube",
		"videoHiderOpenOnYouTube": "Open on YouTube",
		"videoHiderPaneDescription": "Review hidden videos, manage channel lists, and tune automatic filters without leaving the page.",
		"videoHiderPreviewUnavailable": "Preview unavailable",
		"videoHiderQuickActionsAria": "Video Hider quick actions",
		"videoHiderReasonAutoDubbed": "the auto-dubbed filter",
		"videoHiderReasonBlockedChannel": "a blocked channel rule",
		"videoHiderReasonBlockedChannelNamedTpl": "a blocked channel rule ({channel})",
		"videoHiderReasonChannelNotAllowed": "your channel allowlist",
		"videoHiderReasonChannelNotAllowedNamedTpl": "your channel allowlist ({channel})",
		"videoHiderReasonDuration": "the minimum-duration rule",
		"videoHiderReasonKeyword": "a keyword rule",
		"videoHiderReasonLive": "the live-stream filter",
		"videoHiderReasonLowSignal": "the low-signal view/age filter",
		"videoHiderReasonLowView": "the low-view filter",
		"videoHiderReasonManual": "your saved hidden list",
		"videoHiderReasonMarkedWatched": "your local watched marker",
		"videoHiderReasonMix": "the YouTube Mix filter",
		"videoHiderReasonMovie": "the movie filter",
		"videoHiderReasonPlaylist": "the playlist filter",
		"videoHiderReasonPredicate": "your advanced local rule",
		"videoHiderReasonSyntheticDisclosed": "YouTube's own altered-or-synthetic disclosure",
		"videoHiderReasonSyntheticNarration": "the synthetic-narration marker filter",
		"videoHiderReasonUpcoming": "the upcoming-premiere filter",
		"videoHiderReasonUploadCadence": "the upload-cadence filter",
		"videoHiderReasonWatchedRatio": "the watched-ratio filter",
		"videoHiderRememberRestoredDesc": "Keep restored videos visible by adding them to Allowed Videos, even when another rule still matches.",
		"videoHiderRememberRestoredTitle": "Remember restored videos",
		"videoHiderRemoveAllowedChannel": "Remove from Allowlist",
		"videoHiderRemoveAllowedVideoAriaTpl": "Remove allowed-video exception for {videoId}",
		"videoHiderRemoveException": "Remove Exception",
		"videoHiderRemoveFromList": "Remove From List",
		"videoHiderRemoveHiddenCardsDesc": "When enabled, matching videos are removed from the feed DOM instead of only being hidden with CSS.",
		"videoHiderRemoveHiddenCardsTitle": "Remove hidden cards automatically",
		"videoHiderRemoveHiddenVideoAriaTpl": "Remove hidden video {videoId} from the hidden list without adding an exception",
		"videoHiderRemovePage": "Remove Hidden Videos On This Page",
		"videoHiderRemovePageNone": "No hidden videos to remove from this page",
		"videoHiderRemovePageTpl": "Remove {count} hidden videos from this page",
		"videoHiderRemovedHiddenVideoToast": "Video removed from hidden list",
		"videoHiderRemovedPageTpl": "Removed {count} hidden videos from this page",
		"videoHiderRestoreAllTpl": "Restore & Allow All Hidden Videos ({count})",
		"videoHiderRestoreAllow": "Restore & Allow",
		"videoHiderRestoreHiddenVideoAriaTpl": "Restore hidden video {videoId} and add an allowed-video exception",
		"videoHiderRestoreHiddenVideosTpl": "Restored {count} hidden videos",
		"videoHiderRestorePageNone": "No hidden videos on this page",
		"videoHiderRestorePageTitle": "Restore hidden videos on this page",
		"videoHiderRestorePageTpl": "Restore {count} hidden videos on this page",
		"videoHiderRestoredAllVideos": "Restored all videos",
		"videoHiderRuleGuardTpl": "Video Hider filters matched {count} of {total} cards, so they were left visible.",
		"videoHiderScopeChannelsDesc": "Apply your filter rules on channel pages. Videos you hid yourself still show on their own channel.",
		"videoHiderScopeChannelsTitle": "Channel pages",
		"videoHiderScopeHomeDesc": "Hide matches on the YouTube home feed.",
		"videoHiderScopeHomeTitle": "Home",
		"videoHiderScopeOtherDesc": "Keep Video Hider active on miscellaneous browse surfaces.",
		"videoHiderScopeOtherTitle": "Other YouTube surfaces",
		"videoHiderScopeSearchDesc": "Apply video and channel rules on search result pages.",
		"videoHiderScopeSearchTitle": "Search results",
		"videoHiderScopeSubscriptionsDesc": "Hide matches and show bulk controls on the subscriptions feed.",
		"videoHiderScopeSubscriptionsTitle": "Subscriptions",
		"videoHiderScopeWatchDesc": "Apply rules to recommendations beside and below the player.",
		"videoHiderScopeWatchTitle": "Watch pages",
		"videoHiderShowFilterReasonDesc": "Show a small note beside every card Astra Deck hides, whether it came from Video Hider, Hide Collaborations, Hide planned livestreams, or Remove Shorts. The note names the feature and the rule that matched.",
		"videoHiderShowFilterReasonTitle": "Explain hidden cards",
		"videoHiderShowThumbnailHideButtonDesc": "Display the X button on supported video thumbnails for one-click hiding.",
		"videoHiderShowThumbnailHideButtonTitle": "Show thumbnail hide button",
		"videoHiderSubsGuard": "Subscriptions Guard",
		"videoHiderSubsKeepPaused": "Keep Paused",
		"videoHiderSubsLoadChipTitle": "Subscriptions Paused",
		"videoHiderSubsLoadControlsAria": "Open subscription load controls",
		"videoHiderSubsLoadPaused": "Subscription Feed Paused",
		"videoHiderSubsLoadSummaryTpl": "{hidden} hidden of {loaded} scanned",
		"videoHiderSubsPauseReasonTpl": "{percent} of scanned videos were hidden, so Astra Deck paused auto-loading before the feed churned through more empty batches.",
		"videoHiderSubsResume": "Resume",
		"videoHiderSubsResumeLoading": "Resume Loading",
		"videoHiderSubsReviewFilters": "Review Filters",
		"videoHiderSubsScannedStat": "Scanned",
		"videoHiderSubsStreakStat": "Streak",
		"videoHiderSubscriptionLoadLimiterDesc": "Stop endless loading on Subscriptions when too many consecutive batches are fully hidden.",
		"videoHiderSubscriptionLoadLimiterTitle": "Subscription Load Limiter",
		"videoHiderTabsAria": "Video Hider Sections",
		"videoHiderUnblockChannel": "Unblock",
		"videoHiderUnblockChannelAriaTpl": "Unblock channel {channelName}",
		"videoHiderUnblockedChannelsTpl": "Unblocked {count} channels",
		"videoHiderUndoAll": "Undo All",
		"videoHiderUnmarkWatched": "Unmark as watched",
		"videoHiderUnmarkedWatched": "Watched mark removed",
		"videoHiderUploadsPerDaySuffix": "uploads/day",
		"videoHiderVideoIdLabel": "Video ID",
		"videoHiderVideoUrlPlaceholder": "https://youtube.com/watch?v=...",
		"videoHiderViewsSuffix": "views",
		"videoHiderWatchedRatioDesc": "Use 0 to disable. Cards with a resume bar at or above this percent are hidden.",
		"videoHiderWatchedRatioLabel": "Hide Watched Ratio",
		"videoHiderWatchedRatioSuffix": "% watched",
		"videoInsightsCategory": "Category",
		"videoInsightsChannelId": "Channel ID",
		"videoInsightsLoading": "Loading video details…",
		"videoInsightsNoTags": "No tags published",
		"videoInsightsSourceCache": "Cached YouTube details",
		"videoInsightsSourceDegraded": "From this page. YouTube lookup unavailable.",
		"videoInsightsSourceNetwork": "Refreshed from YouTube",
		"videoInsightsSourcePage": "From this page",
		"videoInsightsSourceThrottled": "From this page. YouTube lookup paused.",
		"videoInsightsTags": "Tags",
		"videoInsightsTitle": "Video insights",
		"videoInsightsUnavailable": "Not provided",
		"videoInsightsUnchecked": "Not checked",
		"videoInsightsUploaded": "Uploaded",
		"videoNotesDelete": "Delete",
		"videoNotesDeleteAria": "Delete the note for this video",
		"videoNotesEmpty": "No note saved for this video.",
		"videoNotesEmptyCopy": "Start typing below to save a note for this video.",
		"videoNotesEmptyTitle": "No note yet",
		"videoNotesExport": "Export Notes",
		"videoNotesExportAria": "Export all video notes",
		"videoNotesExportEmpty": "No video notes to export.",
		"videoNotesExportedTpl": "Exported {count} video notes",
		"videoNotesEyebrow": "Local Notes",
		"videoNotesIdUnavailable": "Video ID unavailable",
		"videoNotesInputAria": "Notes for this video",
		"videoNotesPlaceholder": "Write notes for this video…",
		"videoNotesRegionAria": "Per-video notes",
		"videoNotesRemoved": "Removed video note",
		"videoNotesRestored": "Video note restored",
		"videoNotesSaveFailed": "Couldn’t save. Storage is full or unavailable.",
		"videoNotesSaved": "Saved locally.",
		"videoNotesSavedUnderTpl": "Saved under {videoId}",
		"videoNotesSaving": "Saving…",
		"videoNotesTitle": "Video Notes",
		"watchFeedAddButton": "Add to Watch Feed",
		"watchFeedAddCurrent": "Add this video to Watch Feed",
		"watchFeedAdded": "Added to Watch Feed",
		"watchFeedAddedButton": "In Watch Feed",
		"watchFeedAddVideoTpl": "Add {title} to Watch Feed",
		"watchFeedAlreadyAdded": "Already in Watch Feed",
		"watchFeedFullTpl": "Watch Feed is full ({count})",
		"watchFeedImportFullTpl": "Watch Feed import: {added} added, {duplicates} already present, {full} left out because the feed holds {count}",
		"watchFeedImportInvalid": "Import failed: not a valid Watch Feed JSON file",
		"watchFeedImportResultTpl": "Watch Feed import: {added} added, {duplicates} already present",
		"watchFeedMoveDownTpl": "Move down: {title}",
		"watchFeedMoveUpTpl": "Move up: {title}",
		"watchFeedOpenAriaOne": "Open Watch Feed ({count} video)",
		"watchFeedOpenAriaOther": "Open Watch Feed ({count} videos)",
		"watchFeedPillTpl": "Watch Feed · {count}",
		"watchFeedPlayingNow": "Playing now",
		"watchFeedRemoveCurrent": "Remove this video from Watch Feed",
		"watchFeedRemoved": "Removed from Watch Feed",
		"watchFeedRemoveTpl": "Remove from Watch Feed: {title}",
		"watchFeedRemoveVideoTpl": "Remove {title} from Watch Feed",
		"watchFeedRowTooltipTpl": "{title} by {channel}",
		"watchLaterNotInMenu": "Couldn’t find Watch Later in this menu. Try the native Save action on this card.",
		"watchLaterNothingToRemove": "Nothing to remove",
		"watchLaterRemoveFailedOne": "Couldn’t remove {count} video. YouTube’s menu item wasn’t found.",
		"watchLaterRemoveFailedOther": "Couldn’t remove {count} videos. YouTube’s menu item wasn’t found.",
		"watchLaterRemoveWatched": "Remove Watched",
		"watchLaterRemoveWatchedAria": "Remove all watched videos from Watch Later",
		"watchLaterRemovedAll": "Removed {count} ✓",
		"watchLaterRemovedPartial": "Removed {removed} of {total}",
		"watchLaterRemovingProgress": "Removing {current} / {total}…",
		"watchLaterSaveManually": "Open More actions on this card to save it manually.",
		"watchLaterScanning": "Scanning…",
		"welcomeBody": "Pick a profile to start. You can change it any time in Settings.",
		"welcomeDismiss": "Skip",
		"welcomeDismissAria": "Dismiss welcome card",
		"welcomePresetBody": "How will you use YouTube? Pick a preset or skip to configure manually.",
		"welcomePresetFocusDesc": "Reduce Shorts, related videos, infinite scroll, autoplay, and session drift.",
		"welcomePresetFocusTitle": "Focus",
		"welcomePresetGroupAria": "Pick a usage preset",
		"welcomePresetPowerDesc": "Persistent speed, A-B loop, stats overlay, PiP, and focused mode.",
		"welcomePresetPowerTitle": "Power User",
		"welcomePresetPrivacyDesc": "Clean URLs, hide Shorts, block infinite scroll, and keep AI summaries off.",
		"welcomePresetPrivacyTitle": "Privacy",
		"welcomePresetResearcherDesc": "Transcripts, bookmarks, watch time, summaries, and comment search.",
		"welcomePresetResearcherTitle": "Researcher",
		"welcomePresetSkip": "Skip and configure manually",
		"welcomeProfileFullDesc": "Adds the local downloader, Cobalt fallback, custom CSS, and AI summary providers.",
		"welcomeProfileFullTitle": "GitHub-Full",
		"welcomeProfileGroupAria": "Pick a starting profile",
		"welcomeProfileRecommended": "Recommended",
		"welcomeProfileSafeDesc": "Everything that ships on extension stores. No download companion, no BYO AI keys.",
		"welcomeProfileSafeTitle": "Store-Safe",
		"welcomeTitle": "Welcome to Astra Deck",
		"whaCloseAria": "Close watch time dashboard",
		"whaEmptyCopy": "Turn on Watch Time Tracker in Astra Deck settings, then watch a video. Your last 30 days appear here, and the data never leaves this device.",
		"whaEmptyTitle": "No watch time tracked yet",
		"whaOpenButton": "📊 Watch Stats",
		"whaStatActiveDays": "Active days",
		"whaStatAllTime": "All time",
		"whaStatDailyAvg": "Daily avg",
		"whaStatTotal": "Total (30d)",
		"whaTitle": "Watch Time, Last 30 Days",
		"whatsNewDetailFromTpl": "Updated to v{version} (from v{previous}). See what changed.",
		"whatsNewDetailTpl": "Updated to v{version}. See what changed.",
		"whatsNewDismiss": "Dismiss",
		"whatsNewDismissAria": "Dismiss",
		"whatsNewOpen": "Read changelog",
		"whatsNewTitle": "Updated",
		"wlwbAgeAria": "Minimum video age in days",
		"wlwbAgeDaysTpl": "{days}d",
		"wlwbAgeLoading": "Loading upload dates…",
		"wlwbAgePlaceholder": "Older than days…",
		"wlwbAgeUnavailableTplOne": "{count} loaded row has no readable upload age and is excluded from age filtering.",
		"wlwbAgeUnavailableTplOther": "{count} loaded rows have no readable upload age and are excluded from age filtering.",
		"wlwbChannelAria": "Channel name filter",
		"wlwbChannelPlaceholder": "Channel contains…",
		"wlwbCloseAria": "Close workbench",
		"wlwbDurationMaxAria": "Maximum duration in minutes",
		"wlwbDurationMaxPlaceholder": "Duration ≤ minutes…",
		"wlwbDurationMinAria": "Minimum duration in minutes",
		"wlwbDurationMinPlaceholder": "Duration ≥ minutes…",
		"wlwbEmptyCopy": "Clear a filter or scroll Watch Later to load more videos.",
		"wlwbEmptyTitle": "No videos in this view",
		"wlwbExportCsv": "Export CSV",
		"wlwbExportJson": "Export JSON",
		"wlwbExportedToastTpl": "Exported {count} loaded Watch Later entries",
		"wlwbLogEmpty": "Removal log is empty",
		"wlwbNoMatches": "No matching rows to remove",
		"wlwbNothingToUndo": "No removed Watch Later videos are waiting for Undo.",
		"wlwbOpenAria": "Open the Watch Later workbench",
		"wlwbOpenBtn": "Workbench",
		"wlwbPanelAria": "Watch Later workbench",
		"wlwbRecoveryEmpty": "No removed videos are waiting for recovery.",
		"wlwbRecoveryStatusTplOne": "{count} removed video is available to restore.",
		"wlwbRecoveryStatusTplOther": "{count} removed videos are available to restore.",
		"wlwbRecoveryTitle": "Undo recovery",
		"wlwbRemovalLogBtn": "Removal log",
		"wlwbRemoveMatchedTpl": "Remove matched (max {limit}/run)",
		"wlwbRemovedRemainingTpl": "{count} still match, so run it again",
		"wlwbRemovedToastTplOne": "Removed {count} video{remaining}. Recovery list is in the removal log.",
		"wlwbRemovedToastTplOther": "Removed {count} videos{remaining}. Recovery list is in the removal log.",
		"wlwbRemovingTpl": "Removing {current} / {total}…",
		"wlwbRestoreFailedTpl": "Could not restore {title}: {error}",
		"wlwbRestoredBatchTplOne": "Restored {restored} of {total} removed video to Watch Later.",
		"wlwbRestoredBatchTplOther": "Restored {restored} of {total} removed videos to Watch Later.",
		"wlwbRestoredItemTpl": "Restored {title} to Watch Later",
		"wlwbRowMetaTpl": "{percent}% · {duration} · {age}",
		"wlwbRowTitleTpl": "{title} by {channel} ({percent}% watched)",
		"wlwbSortAria": "Preview sort order",
		"wlwbSortLongest": "Longest first",
		"wlwbSortPlaylist": "Playlist order",
		"wlwbSortShortest": "Shortest first",
		"wlwbSortTitle": "Title A to Z",
		"wlwbStateAny": "Any watched state",
		"wlwbStateInProgress": "In progress",
		"wlwbStateUnwatched": "Unwatched",
		"wlwbStateWatched": "Watched (90%+)",
		"wlwbStatusTpl": "{matched} of {loaded} loaded videos match. Scroll the playlist to load more rows before running.",
		"wlwbTitleAria": "Title filter",
		"wlwbTitlePlaceholder": "Title contains…",
		"wlwbUndoAll": "Undo all",
		"wlwbUndoItem": "Undo",
		"wlwbUnknownAge": "age ?",
		"wlwbUnknownDuration": "duration ?",
		"wlwbWatchedAria": "Minimum watched percent filter",
		"wlwbWatchedPlaceholder": "Watched ≥ % (e.g. 90)",
		"wlwbWatchedStateAria": "Watched state filter",
		"workspaceEyebrow": "Settings workspace",
		"workspaceSupport": "Quick toggles save immediately and sync to YouTube.",
		"workspaceTitle": "Controls and backups",
		"youtubeStateResetToast": "YouTube state cleared ({count}). Use Undo in Astra Deck before closing this tab.",
		"youtubeStateRestoreToast": "YouTube state restored ({count}). Reload the page to apply it.",
		"zapConfidenceBroad": "Matches this element anywhere it appears",
		"zapConfidenceHigh": "Scoped to one page section",
		"zapHiddenNote": "Hidden by an element rule you made.",
		"zapNoRules": "No rules yet.",
		"zapPaneDesc": "Hide a shelf, panel, or promo by clicking it. Rules are built from YouTube’s own element names, so they keep working after a redesign.",
		"zapPaneTitle": "Element Zapper",
		"zapPickCancel": "Cancel",
		"zapPickHint": "Click a shelf, panel, or promo to hide it. Press Escape to cancel.",
		"zapPickHintKeys": "Or press the arrow keys to move through the page and Enter to choose.",
		"zapPickStart": "Pick an element to hide",
		"zapRefuseOwnUi": "That is part of Astra Deck.",
		"zapRefusePlayer": "The player is off limits. Hiding part of it breaks playback.",
		"zapRefusePlaylist": "Playlist items are off limits. Hiding one renumbers the list.",
		"zapRefuseTooBroad": "That is the whole page, not an element on it.",
		"zapRefuseUnknown": "Nothing here can be turned into a durable rule.",
		"zapRefuseVideoCard": "That is a single video. Use Video Hider to hide videos and channels.",
		"zapRuleAdded": "Element hidden. The rule is saved.",
		"zapRuleDuplicate": "A rule for that element already exists.",
		"zapRuleRemove": "Remove",
		"zapRuleRemoveAriaTpl": "Remove the rule for {selector}",
		"zapRuleToggleAriaTpl": "Apply the rule for {selector}",
		"settingsCopyDiagnosticsTitle": "Copy diagnostics for a bug report",
		"diagnosticsMenuCopyFailed": "Couldn't copy the diagnostics. Open the settings panel and use the bug button under the sidebar.",
		"feature_hideVideosMadeWithAiFilter_name": "Made With AI Label",
		"feature_hideVideosMadeWithAiFilter_desc": "Hide videos YouTube labels as made with AI. Astra learns the label when you open a video, then hides that video's cards everywhere. Sends nothing.",
		"feature_hideVideosMadeWithAiLookups_name": "Look Up AI Labels",
		"feature_hideVideosMadeWithAiLookups_desc": "Works with Made With AI Label. Asks YouTube for each card's label so labeled videos hide before you open them: one small request per card, four at a time, without your cookies.",
		"videoHiderReasonMadeWithAi": "YouTube's \"Made with AI\" label",
		"videoHiderAiLabelTitle": "YouTube's AI label",
		"videoHiderAiLabelDesc": "YouTube only shows its \"Made with AI\" label on the watch page, never on a card.",
		"heatmapJumpAfterAdToast": "Jumping to the most replayed moment once the ad ends",
		"schemaSurfaceBackup": "backup file",
		"schemaSurfaceBackupTitle": "No editor for this one yet. Export a backup, change the value in the file, then import it.",
		"dwDailyLimitBadgeTpl": "{minutes} Min Today",
		"dwDailyLimitHint": "Dismissing this reminder will keep it quiet until your next local day starts.",
		"dwDailyLimitDismissButton": "Dismiss Until Tomorrow",
		"dwBreakBadgeTpl": "{minutes} Min Session",
		"dwBreakHint": "Playback is paused until you choose to resume.",
		"dwDailyLimitMessageTplOne": "You have watched {minutes} minute today. Take the rest of the day off, or come back tomorrow with a fresh reset.",
		"dwDailyLimitMessageTplOther": "You have watched {minutes} minutes today. Take the rest of the day off, or come back tomorrow with a fresh reset.",
		"dwBreakMessageTplOne": "You have been watching for {minutes} minute. Rest your eyes, stretch, or look away from the screen for a moment before continuing.",
		"dwBreakMessageTplOther": "You have been watching for {minutes} minutes. Rest your eyes, stretch, or look away from the screen for a moment before continuing.",
		"subImportNewTpl": "{count} new",
		"subImportUpdatedTpl": "{count} updated",
		"subImportRemovedTpl": "{count} removed",
		"subImportReplacedAll": "Replaced all groups.",
		"subImportSkippedTpl": "{skipped}.",
		"subStaleReasonTplOne": "{count} day since the newest upload on its page",
		"subStaleReasonTplOther": "{count} days since the newest upload on its page",
		"subImportChannelsTplOne": "{count} channel",
		"subImportChannelsTplOther": "{count} channels",
		"subImportSkippedGroupsTplOne": "{count} skipped group",
		"subImportSkippedGroupsTplOther": "{count} skipped groups",
		"subImportSkippedChannelsTplOne": "{count} skipped channel",
		"subImportSkippedChannelsTplOther": "{count} skipped channels",
		"subImportDuplicateChannelsTplOne": "skipped {count} duplicate channel",
		"subImportDuplicateChannelsTplOther": "skipped {count} duplicate channels",
		"subImportSummaryTplOne": "Imported {count} subscription group from {source} ({details}).",
		"subImportSummaryTplOther": "Imported {count} subscription groups from {source} ({details}).",
		"subImportGroupNameTpl": "{source} subscriptions",
		"dlInstallerReadyCopiedTpl": "Setup file ready. {hint} The fallback command was copied too.",
		"dlInstallerReadyTpl": "Setup file ready. {hint}",
		"bisectReportUnknown": "unknown",
		"bisectReportCulpritTpl": "Astra Deck feature bisect: {feature}",
		"bisectReportNoCulprit": "Astra Deck feature bisect: no single feature is responsible",
		"bisectReportUnknownBrowser": "unknown browser",
		"bisectReportPageTpl": "Page: {page}",
		"bisectReportStepsTplOne": "{count} step",
		"bisectReportStepsTplOther": "{count} steps",
		"bisectReportSearchedTplOne": "Searched {count} enabled feature in {steps}",
		"bisectReportSearchedTplOther": "Searched {count} enabled features in {steps}",
		"importPreviewTpl": "{replace}, {merge}, {dropped}; {excluded}",
		"importPreviewReplaceTplOne": "{count} item replaces",
		"importPreviewReplaceTplOther": "{count} items replace",
		"importPreviewMergeTplOne": "{count} setting merges",
		"importPreviewMergeTplOther": "{count} settings merge",
		"importPreviewDroppedTplOne": "{count} item dropped",
		"importPreviewDroppedTplOther": "{count} items dropped",
		"importPreviewExcludedTplOne": "{count} cache, runtime, diagnostic, or credential domain intentionally excluded",
		"importPreviewExcludedTplOther": "{count} cache, runtime, diagnostic, or credential domains intentionally excluded",
		"externalHealthAgeNever": "never",
		"importSummaryNoChanges": "no value changes",
		"importSummarySkippedTpl": "{count} skipped",
		"importSummaryTpl": "Imported {summary}.",
		"importSummaryExtrasTpl": "{extras}.",
		"takeoutNothingNew": "No new watch-history entries imported.",
		"takeoutDuplicatesTplOne": "{count} duplicate already existed.",
		"takeoutDuplicatesTplOther": "{count} duplicates already existed.",
		"takeoutSkippedTplOne": "{count} older entry was outside the {days}-day analytics window.",
		"takeoutSkippedTplOther": "{count} older entries were outside the {days}-day analytics window.",
		"takeoutImportedTplOne": "Imported {count} Takeout watch entry into local watch analytics.",
		"takeoutImportedTplOther": "Imported {count} Takeout watch entries into local watch analytics.",
		"importSummarySettingsTplOne": "{count} setting updated",
		"importSummarySettingsTplOther": "{count} settings updated",
		"importSummaryHiddenVideosTplOne": "{count} hidden video",
		"importSummaryHiddenVideosTplOther": "{count} hidden videos",
		"importSummaryAllowedVideosTplOne": "{count} allowed video",
		"importSummaryAllowedVideosTplOther": "{count} allowed videos",
		"importSummaryWatchedVideosTplOne": "{count} marked-watched video",
		"importSummaryWatchedVideosTplOther": "{count} marked-watched videos",
		"importSummaryBlockedChannelsTplOne": "{count} blocked channel",
		"importSummaryBlockedChannelsTplOther": "{count} blocked channels",
		"importSummaryAllowedChannelsTplOne": "{count} allowed channel",
		"importSummaryAllowedChannelsTplOther": "{count} allowed channels",
		"importSummaryBookmarksTplOne": "{count} video with bookmarks",
		"importSummaryBookmarksTplOther": "{count} videos with bookmarks",
		"importSummaryAiSummariesTplOne": "{count} AI summary",
		"importSummaryAiSummariesTplOther": "{count} AI summaries",
		"importSummaryDuplicatesTplOne": "{count} duplicate",
		"importSummaryDuplicatesTplOther": "{count} duplicates",
		"dlInstallerRunHint": "Open Downloads and double-click the setup file to install.",
		"stickyVideoShowCommentsLabel": "Show comments",
		"stickyVideoReplayPaneAria": "Side panel content",
		"stickyVideoReplayCommentsTab": "Comments",
		"stickyVideoReplayChatTab": "Live chat replay",
		"settingsPanelUnavailable": "The settings panel didn't load. Reload the page to try again.",
		"quickLinksRemovedTpl": "Removed \"{name}\"",
		"quickLinksAddedTpl": "Added \"{name}\"",
		"quickLinksLimitNoteTpl": "Limit reached ({count}/{max}). Remove an entry above to add a new one.",
		"quickLinksUsageNoteTpl": "Use a site path like /feed/history or a full https:// URL. ({count}/{max} used)",
		"quickLinksLimitToastTpl": "Quick Links limit reached ({max}). Remove one to add a new entry.",
		"sleepTimerSetAnnounceTplOne": "Sleep timer set for {count} minute.",
		"sleepTimerSetAnnounceTplOther": "Sleep timer set for {count} minutes.",
		"sleepTimerExtendedAnnounceTplOne": "Sleep timer extended by {count} minute.",
		"sleepTimerExtendedAnnounceTplOther": "Sleep timer extended by {count} minutes.",
		"sleepTimerPresetAriaTplOne": "Set sleep timer for {count} minute",
		"sleepTimerPresetAriaTplOther": "Set sleep timer for {count} minutes",
		"watchTimeStatsTpl": "Today: {today} | This week: {week} | All time: {total}",
		"chapterSkippedToastTpl": "Skipped: \"{title}\"",
		"playlistSearchFilteredCountTpl": "{visible} of {total}",
		"playlistSearchItemCountTplOne": "{count} item",
		"playlistSearchItemCountTplOther": "{count} items",
		"commentSearchMatchPositionTpl": "Match {current} of {total}",
		"commentSearchThreadPositionTpl": "Thread {current} of {total}",
		"commentSearchThreadsReadyTpl": "{visible} of {total} threads ready",
		"settingsProfileSavedTpl": "Profile saved: {name}",
		"settingsProfileNotFoundTpl": "Profile not found: {name}",
		"settingsProfileAppliedTpl": "Applied profile: {name}. Reloading…",
		"settingsProfileDeletedTpl": "Profile deleted: {name}",
		"settingsProfilesImportedTplOne": "Imported {count} profile",
		"settingsProfilesImportedTplOther": "Imported {count} profiles",
		"chaptersCopiedMarkdownTplOne": "{count} chapter copied as Markdown",
		"chaptersCopiedMarkdownTplOther": "{count} chapters copied as Markdown",
		"autoDubbedTrackFallback": "an AI-dubbed track",
		"autoDubbedToastTpl": "Audio: YouTube selected {track}. Switch to Original in the player settings if preferred.",
		"autoDubbedAnnounceTpl": "Audio track is {track}; the original track may be available in the player settings.",
		"deArrowModeDearrow": "DeArrow",
		"deArrowModeOriginal": "Original",
		"deArrowModeOff": "Off",
		"deArrowChannelChipTpl": "DeArrow: {mode}",
		"deArrowTitleReplacedTpl": "Title replaced by DeArrow: {title}",
		"deArrowChannelChipTitle": "Click to cycle DeArrow mode for this channel (DeArrow / Original / Off)",
		"deArrowChannelOverrideToastTpl": "DeArrow override set to \"{mode}\" for this channel.",
		"transcriptBatchQueuedTpl": "{count}/{max} queued; one recovery pass per video",
		"transcriptBatchFetchingTpl": "Fetching {current}/{total}; one recovery pass per video",
		"transcriptSearchStillIndexing": "The current video is still being indexed.",
		"transcriptSearchNoMatchesTpl": "No transcripts matched \"{query}\".",
		"protocolHandoffToastTpl": "{player} handoff fired. If nothing opened, register the handler on your OS first.",
		"pageModalEnabledCountTplOne": "{count} Enabled",
		"pageModalEnabledCountTplOther": "{count} Enabled",
		"pageModalShortcutCountTplOne": "{count} Shortcut",
		"pageModalShortcutCountTplOther": "{count} Shortcuts",
		"pageModalAppliesLive": "Applies Live",
		"statusSettingsImportUndoFailed": "Import undo failed.",
		"statusSettingsImportInvalidFormat": "Invalid file format.",
		"statusSettingsImportNoKnownKeys": "No known settings found in file.",
		"statusSettingsImportNothing": "No importable settings or local data found.",
		"videoHiderReviewEyebrow": "Restore & Review",
		"videoHiderHiddenReadyTplOne": "{count} Hidden Video Ready to Review",
		"videoHiderHiddenReadyTplOther": "{count} Hidden Videos Ready to Review",
		"videoHiderReviewCopy": "Restore one item at a time, remove an entry from the list without creating an exception, or reset the whole list if you want YouTube recommendations to start fresh again.",
		"videoHiderExceptionsEyebrow": "Manual Exceptions",
		"videoHiderAllowedProtectedTplOne": "{count} Allowed Video Protected From Filters",
		"videoHiderAllowedProtectedTplOther": "{count} Allowed Videos Protected From Filters",
		"videoHiderExceptionsCopy": "Remove an exception to let automatic rules evaluate the video again, or hide it again to move it back to the hidden list.",
		"videoHiderAllowedChannelCountTplOne": "{count} Allowed Channel",
		"videoHiderAllowedChannelCountTplOther": "{count} Allowed Channels",
		"videoHiderBlockedChannelCountTplOne": "{count} Blocked Channel",
		"videoHiderBlockedChannelCountTplOther": "{count} Blocked Channels",
		"settingsSearchSectionMatchesTplOne": "{count} match",
		"settingsSearchSectionMatchesTplOther": "{count} matches",
		"settingsHostAccessNeededAll": "Some settings need host access. Try again and approve the browser prompt.",
		"videoHiderInputViews": "view counts",
		"videoHiderInputAges": "upload ages",
		"videoHiderInputDurations": "durations",
		"videoHiderInputPairTpl": "{first} or {second}",
		"videoHiderInputTrioTpl": "{first}, {second} or {third}",
		"videoHiderInputsUnreadableTpl": "Can't read {inputs} on this page's cards, so the filters that need them aren't hiding anything.",
		"dlHealthRuntimeMissing": "missing",
		"dlHealthRuntimeUnverified": "unverified",
		"dlHealthRuntimeReady": "ready",
		"dlHealthRuntimeRepairTpl": "{version} · repair",
		"dlHealthRuntimeBundledTpl": "{status} (bundled)",
		"dlHealthRuntimeRepairTitleTpl": "Repair the configured {runtime} runtime",
		"feature_restoreClassicWatchLayout_name": "Classic Watch Layout",
		"feature_restoreClassicWatchLayout_desc": "Undoes the side-panel watch page YouTube started testing in October 2026. Comments and the description go back under the video, recommendations go back to the right and the theater button returns.",
		"feature_watchLayoutFlagOverrides_name": "Extra Layout Flags",
		"feature_watchLayoutFlagOverrides_desc": "Astra already turns off the flags behind the side-panel page. Add a flag name per line to turn off more of them, or put a minus sign in front of one of Astra's to leave it on.",
		"feature_hideAutoChapters_name": "Hide AI Chapters",
		"feature_hideAutoChapters_desc": "Removes the chapters YouTube generates on its own, from the progress bar and the chapters panel. Chapters the creator wrote in the description stay.",
		"feature_viewsOnSeparateLine_name": "Views on Their Own Line",
		"feature_viewsOnSeparateLine_desc": "On Home and Subscriptions, put the views and the upload age back on their own line under the channel name, so a long channel name no longer cuts them off.",
		"toastPlaybackRecoveredTpl": "Playback recovered (attempt {attempt} of {max})",
		"toastPlaylistReversed": "Playlist reversed",
		"toastScreenshotSavedCopied": "Screenshot saved and copied to the clipboard.",
		"toastScreenshotCopyBlocked": "Screenshot saved. Copying it to the clipboard was blocked, but the PNG still downloaded.",
		"toastScreenshotCopyUnavailable": "Screenshot saved. Copying images to the clipboard isn't available here.",
		"toastSleepTimerElapsed": "Sleep timer is up. Playback paused.",
		"toastLoopPointATpl": "Loop point A set at {time}",
		"toastLoopPointBTpl": "Loop point B set at {time}",
		"toastLoopingTpl": "Looping {start} to {end}",
		"toastLoopCleared": "A-B loop cleared",
		"toastDismissed": "Dismissed",
		"toastVideoPoppedOut": "Video popped out",
		"toastPipActive": "Picture-in-Picture is on",
		"toastPipUnsupported": "Picture-in-Picture isn't supported here",
		"toastAgeBypassNeedsAttention": "Age-restriction bypass couldn't handle this video. The diagnostic log has the details.",
		"toastAgeBypassed": "Age restriction bypassed",
		"toastTitleStillLoading": "The video title is still loading. Try again in a moment.",
		"toastAlreadyPoppedOut": "The video is already popped out",
		"toastCaughtUpToLive": "Caught up to live. Speed is back to 1x.",
		"toastSpeedTpl": "Speed: {speed}x",
		"toastAutoDownloadStarted": "Auto-download started",
		"toastSponsorBlockOverridesReset": "This channel's SponsorBlock overrides are back to your global defaults.",
		"toastFetchingCaptions": "Fetching captions…",
		"toastSrtDownloaded": "SRT downloaded",
		"toastDiagnosticLogActive": "Diagnostic log is on. To share it, open the settings panel and use the bug button under the sidebar.",
		"toastPromptCopiedTargetOpened": "Prompt copied and the chosen site opened",
		"toastHandoffFailed": "Handoff failed. Check the diagnostic log.",
		"toastFeedTriageApplied": "Feed Triage applied. Turn it off to restore your previous filter settings.",
		"toastFeedTriageOff": "Feed Triage is off. Your previous filter settings are back.",
		"toastStudyExportOne": "Exported {format} with {count} bookmark",
		"toastStudyExportOther": "Exported {format} with {count} bookmarks",
		"toastTranscriptIndexCleared": "Transcript index cleared.",
		"toastTranscriptIndexClearFailed": "Couldn't clear the transcript index. Try again.",
		"toastTranscriptIndexPaused": "Transcript indexing paused. It'll try again when you come back to this video.",
		"toastTranscriptIndexOff": "Transcript Search Index is off. Turn it on first.",
		"toastImportTooLargeTpl": "The import file is over the {size} MB limit.",
		"toastSafeMode": "Safe mode: every feature is off. Run ytkit.unsafe() in the console to leave it.",
		"toastCrashSafeMode": "Astra Deck crashed several times in a row and switched to safe mode. Check your settings or reset them.",
		"deArrowCoverRandom": "Random frame (DeArrow)",
		"deArrowCoverStart": "Still near the start",
		"deArrowCoverMiddle": "Still from the middle",
		"deArrowCoverEnd": "Still near the end",
		"deArrowCoverOriginal": "Keep the original"
	}
};

// Astra Deck userscript host.
//
// The userscript runs the extension's own code. sync-userscript.js packs the
// extension sources into @require libraries that only REGISTER each file as a
// function; this host decides what runs where and when, the way the manifest
// does for the extension:
//
//   document-start  core/bridge-token.js and early.css, in the sandbox
//                   the MAIN-world scripts, injected into the page
//                   background.js, in the sandbox under its own scope
//   document-idle   the ISOLATED runtime, in the manifest's order
//   live_chat frame the live-chat content group, and nothing else
//
// Every chrome.* call the extension makes lands on an adapter built here from
// GM_* grants. The adapter lives in the userscript sandbox only: the page can
// never reach it, and nothing privileged is ever handed to the MAIN world.
(function astraDeckUserscriptHost(BUILD) {
    'use strict';

    const HOST_GLOBAL = globalThis;
    const HOST_WINDOW = typeof window !== 'undefined' ? window : HOST_GLOBAL;
    const HOST_SELF = typeof self !== 'undefined' ? self : HOST_WINDOW;
    const LOG_PREFIX = '[Astra Deck userscript]';
    const REGISTRY_KEY = '__astraDeckUserscriptModules';
    const STATE_KEY = '__astraDeckUserscript';
    const INTERNAL_PREFIX = '__astraDeck.';
    const JOURNAL_KEY = INTERNAL_PREFIX + 'journal';
    const INSTALLED_VERSION_KEY = INTERNAL_PREFIX + 'installedVersion';
    const RUNTIME_ID = BUILD.runtimeId;
    const PACKAGE_BASE_URL = 'https://' + RUNTIME_ID + '.userscript.invalid/';
    const TAB_ID = 1 + Math.floor(Math.random() * 2147483000);
    const INSTANCE_TOKEN = Math.random().toString(36).slice(2) + Date.now().toString(36);
    const nativeFetch = typeof HOST_GLOBAL.fetch === 'function' ? HOST_GLOBAL.fetch.bind(HOST_GLOBAL) : null;
    // A manager can't block a request before it's sent the way the extension's
    // declarativeNetRequest ruleset does, so the userscript states the narrower
    // contract it does keep: ad shells hidden from document-start.
    const AD_CONTRACT_ATTRIBUTE = 'data-ytkit-userscript-ad-contract';
    const AD_CONTRACT = 'document-start-shells-only';

    const hostState = {
        version: BUILD.version,
        route: 'pending',
        manager: describeManager(),
        phase: 'starting',
        startedAt: Date.now(),
        errors: []
    };
    HOST_GLOBAL[STATE_KEY] = hostState;

    function describeManager() {
        try {
            if (typeof GM_info === 'object' && GM_info) {
                return String(GM_info.scriptHandler || 'unknown') + ' ' + String(GM_info.version || '');
            }
        } catch (_) {
            // reason: GM_info is informational only
        }
        return 'unknown';
    }

    function recordError(stage, error) {
        const message = String(error?.message || error || 'unknown error').slice(0, 400);
        hostState.errors.push({ stage, message, at: Date.now() });
        if (hostState.errors.length > 50) hostState.errors.shift();
        try {
            console.error(LOG_PREFIX + ' ' + stage + ' failed:', error);
        } catch (_) {
            // reason: console may be unavailable in exotic sandboxes
        }
    }

    // ── Route ────────────────────────────────────────────────────────────────
    // Mirrors the manifest: the main groups run in the top frame of a YouTube
    // page, the live-chat group runs in every live_chat document (the iframe
    // and the pop-out window), and every other frame gets nothing.
    function classifyRoute() {
        const hostname = String(location.hostname || '').toLowerCase();
        const pathname = String(location.pathname || '');
        if (/^(m|music|studio)\.youtube\.com$/.test(hostname)) return 'skip';
        const youtube = hostname === 'youtube.com' || hostname.endsWith('.youtube.com');
        if (youtube && pathname.startsWith('/live_chat')) return 'live-chat';
        let top = true;
        try {
            top = HOST_WINDOW.top === HOST_WINDOW.self;
        } catch (_) {
            top = false;
        }
        return top ? 'main' : 'skip';
    }

    const route = classifyRoute();
    hostState.route = route;
    if (route === 'skip') {
        hostState.phase = 'skipped';
        return;
    }

    // Only the modules the host can't boot without. Between releases this
    // file on main can be newer than the release libraries it pins, and a
    // feature module they don't carry yet is skipped and recorded by the
    // runtime instead (failedFeatureModules), not fatal for the whole script.
    const registry = HOST_GLOBAL[REGISTRY_KEY];
    hostState.missingOptionalModules = (BUILD.optionalModules || [])
        .filter((path) => typeof registry?.[path] !== 'function');
    const missingModules = BUILD.requiredModules.filter((path) => typeof registry?.[path] !== 'function');
    if (missingModules.length) {
        hostState.phase = 'failed';
        recordError('library check', new Error('The Astra Deck libraries did not load (missing '
            + missingModules.slice(0, 3).join(', ') + (missingModules.length > 3 ? ', ...' : '')
            + '). Reinstall the userscript or check that raw.githubusercontent.com is reachable.'));
        return;
    }

    // ── Small helpers ────────────────────────────────────────────────────────
    function cloneJson(value) {
        if (value === undefined) return undefined;
        return JSON.parse(JSON.stringify(value));
    }

    function sameJson(left, right) {
        return JSON.stringify(left) === JSON.stringify(right);
    }

    function later(run) {
        Promise.resolve().then(run).catch((error) => recordError('deferred task', error));
    }

    function createEvent(label) {
        const listeners = new Set();
        return {
            addListener(listener) {
                if (typeof listener === 'function') listeners.add(listener);
            },
            removeListener(listener) {
                listeners.delete(listener);
            },
            hasListener(listener) {
                return listeners.has(listener);
            },
            hasListeners() {
                return listeners.size > 0;
            },
            dispatch(...args) {
                for (const listener of [...listeners]) {
                    try {
                        listener(...args);
                    } catch (error) {
                        recordError(label + ' listener', error);
                    }
                }
            },
            listeners() {
                return [...listeners];
            }
        };
    }

    // chrome.runtime.lastError is only meaningful inside a callback, exactly
    // as in the browser: it is set for the duration of the call and cleared.
    let activeLastError = null;

    function invokeCallback(callback, value, error) {
        activeLastError = error ? { message: String(error?.message || error) } : null;
        try {
            callback(value);
        } catch (callbackError) {
            recordError('api callback', callbackError);
        } finally {
            activeLastError = null;
        }
    }

    // Every method accepts a trailing callback (Chrome style) and otherwise
    // returns a promise (Firefox and MV3 style), and results always arrive
    // asynchronously, as they do from a real extension API.
    function apiMethod(implementation) {
        return function adaptedApiMethod(...args) {
            let callback = null;
            if (args.length && typeof args[args.length - 1] === 'function') callback = args.pop();
            let result;
            try {
                result = Promise.resolve(implementation(...args));
            } catch (error) {
                result = Promise.reject(error);
            }
            if (!callback) return result;
            result.then(
                (value) => invokeCallback(callback, value, null),
                (error) => invokeCallback(callback, undefined, error)
            );
            return undefined;
        };
    }

    function gm(name) {
        // Each grant is read by its literal name: a manager exposes only the
        // grants the header declares, as free identifiers in the sandbox.
        try {
            switch (name) {
                case 'getValue': return typeof GM_getValue === 'function' ? GM_getValue : null;
                case 'setValue': return typeof GM_setValue === 'function' ? GM_setValue : null;
                case 'deleteValue': return typeof GM_deleteValue === 'function' ? GM_deleteValue : null;
                case 'listValues': return typeof GM_listValues === 'function' ? GM_listValues : null;
                case 'addValueChangeListener': return typeof GM_addValueChangeListener === 'function' ? GM_addValueChangeListener : null;
                case 'addStyle': return typeof GM_addStyle === 'function' ? GM_addStyle : null;
                case 'addElement': return typeof GM_addElement === 'function' ? GM_addElement : null;
                case 'xmlhttpRequest': return typeof GM_xmlhttpRequest === 'function' ? GM_xmlhttpRequest : null;
                case 'download': return typeof GM_download === 'function' ? GM_download : null;
                case 'openInTab': return typeof GM_openInTab === 'function' ? GM_openInTab : null;
                case 'registerMenuCommand': return typeof GM_registerMenuCommand === 'function' ? GM_registerMenuCommand : null;
                case 'setClipboard': return typeof GM_setClipboard === 'function' ? GM_setClipboard : null;
                case 'getResourceText': return typeof GM_getResourceText === 'function' ? GM_getResourceText : null;
                case 'cookie': return (typeof GM_cookie === 'object' || typeof GM_cookie === 'function') && GM_cookie ? GM_cookie : null;
                default: return null;
            }
        } catch (_) {
            return null;
        }
    }

    const GM_API = {
        getValue: gm('getValue'),
        setValue: gm('setValue'),
        deleteValue: gm('deleteValue'),
        listValues: gm('listValues'),
        addValueChangeListener: gm('addValueChangeListener'),
        addStyle: gm('addStyle'),
        addElement: gm('addElement'),
        xmlhttpRequest: gm('xmlhttpRequest'),
        download: gm('download'),
        openInTab: gm('openInTab'),
        registerMenuCommand: gm('registerMenuCommand'),
        setClipboard: gm('setClipboard'),
        getResourceText: gm('getResourceText'),
        cookie: gm('cookie')
    };

    // ── storage ──────────────────────────────────────────────────────────────
    // storage.local maps key for key onto GM values, the same keys the old
    // hand-written userscript used, so an existing install keeps its settings,
    // hidden videos, bookmarks and caches with no migration step. Other tabs
    // hear about a write through one journal key, because a GM value listener
    // has to name the key it watches.
    const storageChanged = createEvent('storage.onChanged');
    const contentStorageChanged = createEvent('content storage.onChanged');
    const localChanged = createEvent('storage.local.onChanged');
    const sessionChanged = createEvent('storage.session.onChanged');
    const lastKnownLocal = new Map();

    function normalizeKeyQuery(keys) {
        if (keys === null || keys === undefined) return { all: true, names: [], defaults: {} };
        if (typeof keys === 'string') return { all: false, names: [keys], defaults: {} };
        if (Array.isArray(keys)) return { all: false, names: keys.map(String), defaults: {} };
        if (typeof keys === 'object') return { all: false, names: Object.keys(keys), defaults: keys };
        throw new TypeError('storage.get: invalid keys argument');
    }

    // A macrotask, so the write's own promise settles first, as in Chrome.
    function emitStorageChange(changes, areaName) {
        if (!Object.keys(changes).length) return;
        setTimeout(() => {
            storageChanged.dispatch(cloneJson(changes), areaName);
            (areaName === 'local' ? localChanged : sessionChanged).dispatch(cloneJson(changes));
            if (areaName === 'local') contentStorageChanged.dispatch(cloneJson(changes), areaName);
        }, 0);
    }

    function localKeys() {
        const list = GM_API.listValues ? GM_API.listValues() : [];
        return (Array.isArray(list) ? list : []).filter((key) => !String(key).startsWith(INTERNAL_PREFIX));
    }

    const NO_VALUE = Symbol('no value');

    function readLocal(key) {
        const value = GM_API.getValue(key, NO_VALUE);
        if (value === NO_VALUE || value === undefined) {
            lastKnownLocal.delete(key);
            return NO_VALUE;
        }
        lastKnownLocal.set(key, cloneJson(value));
        return value;
    }

    function publishJournal(keys) {
        if (!keys.length) return;
        try {
            GM_API.setValue(JOURNAL_KEY, { source: INSTANCE_TOKEN, keys, at: Date.now(), nonce: Math.random() });
        } catch (error) {
            recordError('storage journal', error);
        }
    }

    const localArea = {
        QUOTA_BYTES: 1073741824,
        onChanged: localChanged,
        get: apiMethod((keys) => {
            const query = normalizeKeyQuery(keys);
            const names = query.all ? localKeys() : query.names;
            const out = {};
            for (const key of names) {
                const value = readLocal(key);
                if (value !== NO_VALUE) out[key] = cloneJson(value);
                else if (Object.hasOwn(query.defaults, key)) out[key] = cloneJson(query.defaults[key]);
            }
            return out;
        }),
        getKeys: apiMethod(() => localKeys()),
        set: apiMethod((items) => {
            if (!items || typeof items !== 'object') throw new TypeError('storage.set: items must be an object');
            const changes = {};
            for (const [key, raw] of Object.entries(items)) {
                if (raw === undefined || typeof raw === 'function') continue;
                const next = cloneJson(raw);
                const previous = readLocal(key);
                if (previous !== NO_VALUE && sameJson(previous, next)) continue;
                GM_API.setValue(key, next);
                lastKnownLocal.set(key, cloneJson(next));
                changes[key] = previous === NO_VALUE ? { newValue: next } : { oldValue: cloneJson(previous), newValue: next };
            }
            publishJournal(Object.keys(changes));
            emitStorageChange(changes, 'local');
        }),
        remove: apiMethod((keys) => {
            const names = typeof keys === 'string' ? [keys] : (Array.isArray(keys) ? keys.map(String) : []);
            const changes = {};
            for (const key of names) {
                const previous = readLocal(key);
                if (previous === NO_VALUE) continue;
                GM_API.deleteValue(key);
                lastKnownLocal.delete(key);
                changes[key] = { oldValue: cloneJson(previous) };
            }
            publishJournal(Object.keys(changes));
            emitStorageChange(changes, 'local');
        }),
        clear: apiMethod(() => {
            const changes = {};
            for (const key of localKeys()) {
                const previous = readLocal(key);
                GM_API.deleteValue(key);
                lastKnownLocal.delete(key);
                if (previous !== NO_VALUE) changes[key] = { oldValue: cloneJson(previous) };
            }
            publishJournal(Object.keys(changes));
            emitStorageChange(changes, 'local');
        }),
        getBytesInUse: apiMethod((keys) => {
            const query = normalizeKeyQuery(keys);
            const names = query.all ? localKeys() : query.names;
            let total = 0;
            for (const key of names) {
                const value = readLocal(key);
                if (value !== NO_VALUE) total += key.length + JSON.stringify(value).length;
            }
            return total;
        }),
        setAccessLevel: apiMethod(() => undefined)
    };

    if (GM_API.addValueChangeListener) {
        try {
            GM_API.addValueChangeListener(JOURNAL_KEY, (_name, _oldValue, entry, remote) => {
                if (!remote || !entry || entry.source === INSTANCE_TOKEN || !Array.isArray(entry.keys)) return;
                const changes = {};
                for (const key of entry.keys) {
                    if (typeof key !== 'string' || key.startsWith(INTERNAL_PREFIX)) continue;
                    const hadPrevious = lastKnownLocal.has(key);
                    const previous = lastKnownLocal.get(key);
                    const current = readLocal(key);
                    if (current === NO_VALUE) {
                        if (hadPrevious) changes[key] = { oldValue: previous };
                    } else if (!hadPrevious || !sameJson(previous, current)) {
                        changes[key] = hadPrevious
                            ? { oldValue: previous, newValue: cloneJson(current) }
                            : { newValue: cloneJson(current) };
                    }
                }
                emitStorageChange(changes, 'local');
            });
        } catch (error) {
            recordError('cross-tab storage listener', error);
        }
    }

    // storage.session lives as long as the tab, the closest a userscript gets
    // to a browser session. It is shared by this tab's content and background.
    const sessionValues = new Map();
    const sessionArea = {
        QUOTA_BYTES: 10485760,
        onChanged: sessionChanged,
        get: apiMethod((keys) => {
            const query = normalizeKeyQuery(keys);
            const names = query.all ? [...sessionValues.keys()] : query.names;
            const out = {};
            for (const key of names) {
                if (sessionValues.has(key)) out[key] = cloneJson(sessionValues.get(key));
                else if (Object.hasOwn(query.defaults, key)) out[key] = cloneJson(query.defaults[key]);
            }
            return out;
        }),
        getKeys: apiMethod(() => [...sessionValues.keys()]),
        set: apiMethod((items) => {
            if (!items || typeof items !== 'object') throw new TypeError('storage.set: items must be an object');
            const changes = {};
            for (const [key, raw] of Object.entries(items)) {
                if (raw === undefined || typeof raw === 'function') continue;
                const next = cloneJson(raw);
                const had = sessionValues.has(key);
                const previous = sessionValues.get(key);
                if (had && sameJson(previous, next)) continue;
                sessionValues.set(key, next);
                changes[key] = had ? { oldValue: cloneJson(previous), newValue: cloneJson(next) } : { newValue: cloneJson(next) };
            }
            emitStorageChange(changes, 'session');
        }),
        remove: apiMethod((keys) => {
            const names = typeof keys === 'string' ? [keys] : (Array.isArray(keys) ? keys.map(String) : []);
            const changes = {};
            for (const key of names) {
                if (!sessionValues.has(key)) continue;
                changes[key] = { oldValue: cloneJson(sessionValues.get(key)) };
                sessionValues.delete(key);
            }
            emitStorageChange(changes, 'session');
        }),
        clear: apiMethod(() => {
            const changes = {};
            for (const [key, value] of sessionValues) changes[key] = { oldValue: cloneJson(value) };
            sessionValues.clear();
            emitStorageChange(changes, 'session');
        }),
        getBytesInUse: apiMethod(() => {
            let total = 0;
            for (const [key, value] of sessionValues) total += key.length + JSON.stringify(value).length;
            return total;
        }),
        setAccessLevel: apiMethod(() => undefined)
    };

    const storageApi = {
        local: localArea,
        session: sessionArea,
        onChanged: storageChanged
    };

    // Chrome keeps storage.session away from content scripts unless the worker
    // opens it up, and the AI credential vault caches keys there.
    const contentStorageApi = {
        local: localArea,
        onChanged: contentStorageChanged
    };

    // ── i18n ─────────────────────────────────────────────────────────────────
    // English ships inside the main file so every label resolves even if a
    // locale resource failed to download; the others arrive as @resource
    // files. Lookup is case-insensitive and falls back to English per key,
    // as chrome.i18n does.
    const RTL_LOCALES = new Set(['ar', 'fa', 'he', 'ur']);
    const localeCache = new Map();

    function lowerKeyMap(flat) {
        const map = new Map();
        for (const [key, message] of Object.entries(flat || {})) map.set(key.toLowerCase(), message);
        return map;
    }

    function readBundledLocale(locale) {
        if (localeCache.has(locale)) return localeCache.get(locale);
        let flat = null;
        if (locale === BUILD.defaultLocale) {
            flat = BUILD.messages;
        } else if (BUILD.locales.includes(locale) && GM_API.getResourceText) {
            try {
                const text = GM_API.getResourceText(BUILD.localeResourcePrefix + locale);
                if (text) {
                    flat = {};
                    for (const [key, entry] of Object.entries(JSON.parse(text))) {
                        if (entry && typeof entry.message === 'string') flat[key] = entry.message;
                    }
                }
            } catch (error) {
                recordError('locale ' + locale, error);
            }
        }
        localeCache.set(locale, flat);
        return flat;
    }

    function resolveUiLocale() {
        const requested = String((HOST_GLOBAL.navigator && HOST_GLOBAL.navigator.language) || BUILD.defaultLocale);
        const tag = requested.replace(/-/g, '_');
        const exact = BUILD.locales.find((locale) => locale.toLowerCase() === tag.toLowerCase());
        if (exact) return exact;
        const base = tag.split('_')[0].toLowerCase();
        return BUILD.locales.find((locale) => locale.toLowerCase() === base) || BUILD.defaultLocale;
    }

    const uiLocale = resolveUiLocale();
    let activeMessages = null;
    let fallbackMessages = null;

    function messageTables() {
        if (!fallbackMessages) fallbackMessages = lowerKeyMap(readBundledLocale(BUILD.defaultLocale));
        if (!activeMessages) {
            const flat = uiLocale === BUILD.defaultLocale ? null : readBundledLocale(uiLocale);
            activeMessages = flat ? lowerKeyMap(flat) : fallbackMessages;
        }
        return [activeMessages, fallbackMessages];
    }

    function predefinedMessage(name) {
        const rtl = RTL_LOCALES.has(uiLocale.split('_')[0]);
        switch (name) {
            case '@@extension_id': return RUNTIME_ID;
            case '@@ui_locale': return uiLocale;
            case '@@bidi_dir': return rtl ? 'rtl' : 'ltr';
            case '@@bidi_reversed_dir': return rtl ? 'ltr' : 'rtl';
            case '@@bidi_start_edge': return rtl ? 'right' : 'left';
            case '@@bidi_end_edge': return rtl ? 'left' : 'right';
            default: return null;
        }
    }

    function getMessage(name, substitutions) {
        const key = String(name ?? '');
        const predefined = predefinedMessage(key.toLowerCase());
        if (predefined !== null) return predefined;
        const [active, fallback] = messageTables();
        const lower = key.toLowerCase();
        const template = active.has(lower) ? active.get(lower) : fallback.get(lower);
        if (typeof template !== 'string') return '';
        const values = substitutions === undefined || substitutions === null
            ? []
            : (Array.isArray(substitutions) ? substitutions : [substitutions]).map((value) => String(value));
        return template.replace(/\$(\$|[1-9])/g, (match, token) => (token === '$' ? '$' : (values[Number(token) - 1] ?? '')));
    }

    const i18nApi = {
        getMessage,
        getUILanguage: () => uiLocale.replace(/_/g, '-'),
        getAcceptLanguages: apiMethod(() => Array.from(HOST_GLOBAL.navigator?.languages || [uiLocale.replace(/_/g, '-')])),
        detectLanguage: apiMethod(() => ({ isReliable: false, languages: [] }))
    };

    // ── Packaged resources ───────────────────────────────────────────────────
    // runtime.getURL() hands out data: URLs for the small bundled images and a
    // private .invalid address for everything else. The content fetch below
    // answers those addresses from the bundle (locale files included), so the
    // extension's own `fetch(chrome.runtime.getURL(...))` works unchanged.
    function packagePath(path) {
        return String(path ?? '').replace(/^\/+/, '');
    }

    function getURL(path) {
        const relative = packagePath(path);
        if (Object.hasOwn(BUILD.assets, relative)) return BUILD.assets[relative];
        return PACKAGE_BASE_URL + relative;
    }

    function packagedResponse(relative) {
        const localeMatch = /^_locales\/([A-Za-z_]+)\/messages\.json$/.exec(relative);
        if (localeMatch) {
            const flat = readBundledLocale(localeMatch[1]);
            if (flat) {
                const body = {};
                for (const [key, message] of Object.entries(flat)) body[key] = { message };
                return new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'application/json' } });
            }
        }
        return new Response('Not found', { status: 404, statusText: 'Not Found' });
    }

    function requestUrlOf(input) {
        if (typeof input === 'string') return input;
        if (input && typeof input.url === 'string') return input.url;
        return String(input);
    }

    function contentFetch(input, init) {
        const url = requestUrlOf(input);
        if (url.startsWith(PACKAGE_BASE_URL)) {
            return Promise.resolve(packagedResponse(url.slice(PACKAGE_BASE_URL.length).split(/[?#]/)[0]));
        }
        if (!nativeFetch) return Promise.reject(new TypeError('fetch is unavailable'));
        return nativeFetch(input, init);
    }

    // ── Background fetch ─────────────────────────────────────────────────────
    // The service worker fetches cross-origin under host permissions. Here the
    // same calls go through GM_xmlhttpRequest (bounded by @connect) and come
    // back as real Response objects, so the worker's streaming size caps,
    // header checks and redirect refusal all run exactly as written.
    const NULL_BODY_STATUSES = new Set([101, 103, 204, 205, 304]);

    function headersToObject(headers) {
        const out = {};
        if (!headers) return out;
        if (typeof headers.forEach === 'function' && !Array.isArray(headers)) {
            headers.forEach((value, key) => { out[key] = value; });
            return out;
        }
        const entries = Array.isArray(headers) ? headers : Object.entries(headers);
        for (const [key, value] of entries) out[String(key)] = String(value);
        return out;
    }

    function parseResponseHeaders(raw) {
        const headers = new Headers();
        for (const line of String(raw || '').split(/\r?\n/)) {
            const at = line.indexOf(':');
            if (at <= 0) continue;
            try {
                headers.append(line.slice(0, at).trim(), line.slice(at + 1).trim());
            } catch (_) {
                // reason: a header the Fetch API refuses is dropped, as a browser would
            }
        }
        return headers;
    }

    function abortError(signal) {
        const reason = signal?.reason;
        if (reason instanceof Error) return reason;
        try {
            return new DOMException('The operation was aborted.', 'AbortError');
        } catch (_) {
            const error = new Error('The operation was aborted.');
            error.name = 'AbortError';
            return error;
        }
    }

    function sameOriginAsPage(url) {
        try {
            return new URL(url).origin === location.origin;
        } catch (_) {
            return false;
        }
    }

    function normalizedUrl(url) {
        try {
            return new URL(url).href;
        } catch (_) {
            return String(url);
        }
    }

    function backgroundFetch(input, init = {}) {
        const request = typeof Request === 'function' && input instanceof Request ? input : null;
        const url = normalizedUrl(new URL(requestUrlOf(input), location.href).href);
        if (url.startsWith(PACKAGE_BASE_URL)) return contentFetch(url, init);
        // The page's own origin needs no grant and keeps real streaming.
        if (sameOriginAsPage(url) && nativeFetch) return nativeFetch(input, init);
        if (!GM_API.xmlhttpRequest) return Promise.reject(new TypeError('Failed to fetch: GM_xmlhttpRequest is not granted'));

        return new Promise((resolve, reject) => {
            const signal = init.signal || request?.signal || null;
            if (signal?.aborted) {
                reject(abortError(signal));
                return;
            }
            const method = String(init.method || request?.method || 'GET').toUpperCase();
            const headers = headersToObject(init.headers || request?.headers);
            let data = init.body;
            if (typeof URLSearchParams === 'function' && data instanceof URLSearchParams) {
                if (!Object.keys(headers).some((key) => key.toLowerCase() === 'content-type')) {
                    headers['content-type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
                }
                data = data.toString();
            }
            const redirectMode = init.redirect || request?.redirect || 'follow';
            let settled = false;
            let handle = null;
            const finish = (settle, value) => {
                if (settled) return;
                settled = true;
                if (signal) signal.removeEventListener('abort', onAbort);
                settle(value);
            };
            const onAbort = () => {
                try {
                    handle?.abort?.();
                } catch (_) {
                    // reason: the request may already have finished
                }
                finish(reject, abortError(signal));
            };
            if (signal) signal.addEventListener('abort', onAbort, { once: true });

            const details = {
                method,
                url,
                headers,
                responseType: 'arraybuffer',
                anonymous: (init.credentials || request?.credentials) === 'omit',
                onload(result) {
                    const status = Number(result?.status) || 0;
                    if (status < 200 || status > 599) {
                        finish(reject, new TypeError('Failed to fetch'));
                        return;
                    }
                    const finalUrl = result.finalUrl ? normalizedUrl(result.finalUrl) : url;
                    const redirected = finalUrl !== url;
                    if (redirected && redirectMode === 'error') {
                        finish(reject, new TypeError('Failed to fetch: redirect refused'));
                        return;
                    }
                    let response;
                    try {
                        // A redirect under 'manual' is reported as a 3xx for the
                        // requested address: the caller refuses it, fail closed.
                        const reportedStatus = redirected && redirectMode === 'manual' ? 302 : status;
                        const body = NULL_BODY_STATUSES.has(reportedStatus) || method === 'HEAD' || reportedStatus === 302 && redirected
                            ? null
                            : (result.response ?? null);
                        response = new Response(body, {
                            status: reportedStatus,
                            statusText: String(result.statusText || ''),
                            headers: parseResponseHeaders(result.responseHeaders)
                        });
                        Object.defineProperties(response, {
                            url: { value: redirected && redirectMode === 'manual' ? url : finalUrl },
                            redirected: { value: redirected && redirectMode === 'follow' },
                            type: { value: 'basic' }
                        });
                    } catch (error) {
                        finish(reject, error);
                        return;
                    }
                    finish(resolve, response);
                },
                onerror() {
                    finish(reject, new TypeError('Failed to fetch'));
                },
                ontimeout() {
                    finish(reject, new TypeError('Failed to fetch: timed out'));
                },
                onabort() {
                    finish(reject, abortError(signal));
                }
            };
            if (redirectMode === 'manual' || redirectMode === 'error') details.redirect = redirectMode;
            if (data !== undefined && data !== null && method !== 'GET' && method !== 'HEAD') details.data = data;
            try {
                handle = GM_API.xmlhttpRequest(details);
            } catch (error) {
                finish(reject, error);
            }
        });
    }

    // ── runtime messaging ────────────────────────────────────────────────────
    const contentOnMessage = createEvent('content runtime.onMessage');
    const backgroundOnMessage = createEvent('background runtime.onMessage');

    function pageSender() {
        return {
            id: RUNTIME_ID,
            url: location.href,
            origin: location.origin,
            frameId: 0,
            documentLifecycle: 'active',
            tab: currentTab()
        };
    }

    function extensionSender() {
        return { id: RUNTIME_ID, url: PACKAGE_BASE_URL + '_generated_background_page.html', origin: PACKAGE_BASE_URL.slice(0, -1) };
    }

    function currentTab() {
        return {
            id: TAB_ID,
            index: 0,
            windowId: 1,
            active: true,
            highlighted: true,
            incognito: false,
            pinned: false,
            url: location.href,
            title: document.title || ''
        };
    }

    function deliverMessage(event, message, sender) {
        return new Promise((resolve, reject) => {
            let payload;
            try {
                payload = cloneJson(message);
            } catch (error) {
                reject(new Error('Could not serialize message: ' + (error?.message || error)));
                return;
            }
            later(() => {
                const listeners = event.listeners();
                if (!listeners.length) {
                    reject(new Error('Could not establish connection. Receiving end does not exist.'));
                    return;
                }
                let settled = false;
                let keepOpen = false;
                const sendResponse = (value) => {
                    if (settled) return;
                    settled = true;
                    try {
                        resolve(cloneJson(value));
                    } catch (error) {
                        reject(error);
                    }
                };
                for (const listener of listeners) {
                    let result;
                    try {
                        result = listener(payload, sender, sendResponse);
                    } catch (error) {
                        recordError('onMessage listener', error);
                        continue;
                    }
                    if (result === true) {
                        keepOpen = true;
                    } else if (result && typeof result.then === 'function') {
                        keepOpen = true;
                        result.then((value) => sendResponse(value), (error) => {
                            if (settled) return;
                            settled = true;
                            reject(error instanceof Error ? error : new Error(String(error)));
                        });
                    }
                }
                if (!settled && !keepOpen) {
                    settled = true;
                    resolve(undefined);
                }
            });
        });
    }

    function sendMessageArgs(args) {
        // sendMessage(message) or sendMessage(extensionId, message, options)
        if (typeof args[0] === 'string' && args.length >= 2) return args[1];
        return args[0];
    }

    // ── alarms (background) ──────────────────────────────────────────────────
    const onAlarm = createEvent('alarms.onAlarm');
    const alarms = new Map();
    const MAX_TIMER_MS = 2147483000;

    function snapshotAlarm(alarm) {
        const out = { name: alarm.name, scheduledTime: alarm.scheduledTime };
        if (alarm.periodInMinutes) out.periodInMinutes = alarm.periodInMinutes;
        return out;
    }

    function armAlarm(alarm) {
        clearTimeout(alarm.timer);
        const wait = Math.max(0, alarm.scheduledTime - Date.now());
        alarm.timer = setTimeout(() => {
            if (alarms.get(alarm.name) !== alarm) return;
            if (Date.now() + 5 < alarm.scheduledTime) {
                armAlarm(alarm);
                return;
            }
            const fired = snapshotAlarm(alarm);
            if (alarm.periodInMinutes) {
                alarm.scheduledTime = Date.now() + alarm.periodInMinutes * 60000;
                armAlarm(alarm);
            } else {
                alarms.delete(alarm.name);
            }
            onAlarm.dispatch(fired);
        }, Math.min(wait, MAX_TIMER_MS));
    }

    const alarmsApi = {
        onAlarm,
        create: apiMethod((nameOrInfo, maybeInfo) => {
            const name = typeof nameOrInfo === 'string' ? nameOrInfo : '';
            const info = (typeof nameOrInfo === 'string' ? maybeInfo : nameOrInfo) || {};
            const period = Number(info.periodInMinutes) > 0 ? Number(info.periodInMinutes) : 0;
            let when = Number(info.when);
            if (!Number.isFinite(when)) {
                const delay = Number(info.delayInMinutes) > 0 ? Number(info.delayInMinutes) : period;
                when = Date.now() + delay * 60000;
            }
            const existing = alarms.get(name);
            if (existing) clearTimeout(existing.timer);
            const alarm = { name, scheduledTime: when, periodInMinutes: period, timer: null };
            alarms.set(name, alarm);
            armAlarm(alarm);
        }),
        get: apiMethod((name = '') => {
            const alarm = alarms.get(String(name));
            return alarm ? snapshotAlarm(alarm) : undefined;
        }),
        getAll: apiMethod(() => [...alarms.values()].map(snapshotAlarm)),
        clear: apiMethod((name = '') => {
            const alarm = alarms.get(String(name));
            if (!alarm) return false;
            clearTimeout(alarm.timer);
            alarms.delete(String(name));
            return true;
        }),
        clearAll: apiMethod(() => {
            for (const alarm of alarms.values()) clearTimeout(alarm.timer);
            const had = alarms.size > 0;
            alarms.clear();
            return had;
        })
    };

    // ── downloads (background) ───────────────────────────────────────────────
    const downloadsChanged = createEvent('downloads.onChanged');
    const downloadsErased = createEvent('downloads.onErased');
    let nextDownloadId = 1;

    function fileNameFromUrl(url) {
        try {
            const last = new URL(url).pathname.split('/').filter(Boolean).pop();
            return last ? decodeURIComponent(last) : 'download';
        } catch (_) {
            return 'download';
        }
    }

    const downloadsApi = {
        onChanged: downloadsChanged,
        onErased: downloadsErased,
        download: apiMethod((options = {}) => {
            const url = String(options.url || '');
            const id = nextDownloadId++;
            const name = String(options.filename || fileNameFromUrl(url)).split(/[\\/]/).pop();
            if (!GM_API.download) {
                if (!GM_API.openInTab) throw new Error('Downloads are not available in this userscript manager.');
                GM_API.openInTab(url, { active: true });
                return id;
            }
            GM_API.download({
                url,
                name,
                saveAs: options.saveAs === true,
                headers: options.headers ? headersToObject(Object.fromEntries((options.headers || []).map((h) => [h.name, h.value]))) : undefined,
                onload: () => downloadsChanged.dispatch({ id, state: { previous: 'in_progress', current: 'complete' } }),
                onerror: (result) => downloadsChanged.dispatch({
                    id,
                    state: { previous: 'in_progress', current: 'interrupted' },
                    error: { current: String(result?.error || 'FAILED') }
                })
            });
            return id;
        }),
        show: apiMethod(() => true),
        showDefaultFolder: apiMethod(() => undefined),
        search: apiMethod(() => []),
        erase: apiMethod(() => []),
        cancel: apiMethod(() => undefined)
    };

    // ── tabs, permissions, cookies, action (background) ──────────────────────
    let nextOpenedTabId = TAB_ID + 1;
    const tabsApi = {
        query: apiMethod(() => [currentTab()]),
        get: apiMethod((tabId) => {
            if (Number(tabId) !== TAB_ID) throw new Error('No tab with id: ' + tabId + '.');
            return currentTab();
        }),
        sendMessage: apiMethod((tabId, message) => {
            if (Number(tabId) !== TAB_ID) throw new Error('Could not establish connection. Receiving end does not exist.');
            return deliverMessage(contentOnMessage, message, extensionSender());
        }),
        create: apiMethod((properties = {}) => {
            const url = String(properties.url || '');
            if (!GM_API.openInTab) throw new Error('Opening tabs is not available in this userscript manager.');
            GM_API.openInTab(url, { active: properties.active !== false, insert: true, setParent: true });
            return { id: nextOpenedTabId++, index: 1, windowId: 1, active: properties.active !== false, url, pendingUrl: url };
        })
    };

    // Host permissions work as in the browser: the manifest's hosts are always
    // granted, optional ones only after permissions.request(), which the
    // extension only calls from the user's click on a "grant access" control.
    // Grants persist per install. Until one exists the worker refuses the host
    // before any request is made, so @connect * never becomes a silent proxy.
    const GRANTED_ORIGINS_KEY = INTERNAL_PREFIX + 'grantedOrigins';
    const permissionsAdded = createEvent('permissions.onAdded');
    const permissionsRemoved = createEvent('permissions.onRemoved');

    function grantedOrigins() {
        let value = [];
        try {
            value = GM_API.getValue(GRANTED_ORIGINS_KEY, []);
        } catch (_) {
            value = [];
        }
        return Array.isArray(value) ? value.filter((origin) => typeof origin === 'string') : [];
    }

    function parsePattern(pattern) {
        const match = /^(\*|https?|wss?):\/\/(\*|(?:\*\.)?[^/*]+)(\/.*)$/.exec(String(pattern || ''));
        return match ? { scheme: match[1], host: match[2].toLowerCase(), path: match[3] } : null;
    }

    function patternCovers(grant, wanted) {
        if (grant === '<all_urls>') return true;
        const outer = parsePattern(grant);
        const inner = parsePattern(wanted);
        if (!outer || !inner) return grant === wanted;
        const schemeOk = outer.scheme === inner.scheme
            || (outer.scheme === '*' && inner.scheme !== '*' && /^https?$/.test(inner.scheme));
        if (!schemeOk) return false;
        let hostOk = outer.host === '*' || outer.host === inner.host;
        if (!hostOk && outer.host.startsWith('*.')) {
            const base = outer.host.slice(2);
            const innerHost = inner.host.startsWith('*.') ? inner.host.slice(2) : inner.host;
            hostOk = innerHost === base || innerHost.endsWith('.' + base);
        }
        if (!hostOk) return false;
        const pathRe = new RegExp('^' + outer.path.split('*').map((part) => part.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*') + '$');
        return pathRe.test(inner.path.replace(/\*/g, ''));
    }

    function originGranted(origin) {
        return [...BUILD.hostPermissions, ...grantedOrigins()].some((grant) => patternCovers(grant, origin));
    }

    function isDeclaredOptional(origin) {
        return BUILD.optionalHostPermissions.some((declared) => patternCovers(declared, origin));
    }

    const permissionsApi = {
        onAdded: permissionsAdded,
        onRemoved: permissionsRemoved,
        contains: apiMethod((query = {}) => {
            const permissions = Array.isArray(query.permissions) ? query.permissions : [];
            const origins = Array.isArray(query.origins) ? query.origins : [];
            return permissions.every((permission) => BUILD.permissions.includes(permission))
                && origins.every(originGranted);
        }),
        request: apiMethod((query = {}) => {
            const origins = Array.isArray(query.origins) ? query.origins.map(String) : [];
            const permissions = Array.isArray(query.permissions) ? query.permissions : [];
            if (!permissions.every((permission) => BUILD.permissions.includes(permission))) return false;
            if (!origins.every(isDeclaredOptional)) return false;
            const current = grantedOrigins();
            const added = origins.filter((origin) => !originGranted(origin));
            if (added.length) {
                GM_API.setValue(GRANTED_ORIGINS_KEY, [...current, ...added]);
                permissionsAdded.dispatch({ permissions: [], origins: added });
            }
            return true;
        }),
        remove: apiMethod((query = {}) => {
            const origins = Array.isArray(query.origins) ? query.origins.map(String) : [];
            const current = grantedOrigins();
            const kept = current.filter((grant) => !origins.includes(grant));
            if (kept.length === current.length) return false;
            GM_API.setValue(GRANTED_ORIGINS_KEY, kept);
            permissionsRemoved.dispatch({ permissions: [], origins: current.filter((grant) => origins.includes(grant)) });
            return true;
        }),
        getAll: apiMethod(() => ({ permissions: [...BUILD.permissions], origins: [...BUILD.hostPermissions, ...grantedOrigins()] }))
    };

    const cookiesApi = {
        getAll: apiMethod((details = {}) => new Promise((resolve, reject) => {
            const list = GM_API.cookie?.list;
            if (typeof list !== 'function') {
                reject(new Error('Cookie access is not available in this userscript manager.'));
                return;
            }
            try {
                list.call(GM_API.cookie, details, (cookies, error) => {
                    if (error) reject(new Error(String(error)));
                    else resolve(Array.isArray(cookies) ? cookies : []);
                });
            } catch (error) {
                reject(error);
            }
        }))
    };

    const noop = apiMethod(() => undefined);
    const actionApi = {
        setBadgeText: noop,
        setBadgeBackgroundColor: noop,
        setBadgeTextColor: noop,
        setTitle: noop,
        setIcon: noop,
        getBadgeText: apiMethod(() => ''),
        onClicked: createEvent('action.onClicked')
    };

    // ── runtime ──────────────────────────────────────────────────────────────
    const onInstalled = createEvent('runtime.onInstalled');
    const onSuspend = createEvent('runtime.onSuspend');

    function createRuntime(kind) {
        const isBackground = kind === 'background';
        const runtime = {
            id: RUNTIME_ID,
            getURL,
            getManifest: () => cloneJson(BUILD.manifest),
            getPlatformInfo: apiMethod(() => ({ os: 'unknown', arch: 'unknown', nacl_arch: 'unknown' })),
            onMessage: isBackground ? backgroundOnMessage : contentOnMessage,
            onMessageExternal: createEvent('runtime.onMessageExternal'),
            onConnect: createEvent('runtime.onConnect'),
            onInstalled,
            onStartup: createEvent('runtime.onStartup'),
            onSuspend,
            onUpdateAvailable: createEvent('runtime.onUpdateAvailable'),
            sendMessage: apiMethod((...args) => {
                const message = sendMessageArgs(args);
                if (isBackground || route !== 'main') {
                    // The worker's own runtime.sendMessage targets extension
                    // pages, which a userscript does not have; so does a frame
                    // that runs no background.
                    throw new Error('Could not establish connection. Receiving end does not exist.');
                }
                return deliverMessage(backgroundOnMessage, message, pageSender());
            }),
            openOptionsPage: apiMethod(() => deliverMessage(contentOnMessage, { type: 'YTKIT_OPEN_PANEL' }, extensionSender()).catch(() => undefined)),
            reload: () => location.reload()
        };
        Object.defineProperty(runtime, 'lastError', {
            get: () => activeLastError || undefined,
            enumerable: true
        });
        return runtime;
    }

    function createApi(kind) {
        const api = {
            runtime: createRuntime(kind),
            storage: kind === 'background' ? storageApi : contentStorageApi,
            i18n: i18nApi
        };
        if (kind === 'background') {
            api.alarms = alarmsApi;
            api.downloads = downloadsApi;
            api.tabs = tabsApi;
            api.permissions = permissionsApi;
            api.cookies = cookiesApi;
            api.action = actionApi;
        }
        return api;
    }

    const contentApi = createApi('content');

    // ── Module execution ─────────────────────────────────────────────────────
    // Each registered file is `function (globalThis, self, window, chrome,
    // browser, fetch, importScripts, trustedTypes)`, so the same source runs
    // against whichever scope it needs.
    const contentScope = {
        global: HOST_GLOBAL,
        self: HOST_SELF,
        window: HOST_WINDOW,
        chrome: contentApi,
        browser: contentApi,
        fetch: contentFetch,
        importScripts: undefined,
        trustedTypes: HOST_GLOBAL.trustedTypes
    };

    function runModule(path, scope) {
        const moduleFunction = registry[path];
        if (typeof moduleFunction !== 'function') throw new Error('Module is not bundled: ' + path);
        moduleFunction.call(undefined, scope.global, scope.self, scope.window, scope.chrome, scope.browser,
            scope.fetch, scope.importScripts, scope.trustedTypes);
    }

    // The ISOLATED modules read chrome/browser from globalThis as well as by
    // name. Both point at the adapter, in the sandbox only.
    function exposeContentApi() {
        for (const name of ['chrome', 'browser']) {
            try {
                Object.defineProperty(HOST_GLOBAL, name, { value: contentApi, configurable: true, writable: true, enumerable: false });
            } catch (_) {
                try {
                    HOST_GLOBAL[name] = contentApi;
                } catch (__) {
                    // reason: checked below
                }
            }
        }
        if (HOST_GLOBAL.chrome !== contentApi || HOST_GLOBAL.browser !== contentApi) {
            throw new Error('Could not install the extension API adapter in this userscript sandbox');
        }
    }

    // Tampermonkey on Firefox hands scripts a window with addEventListener but
    // no dispatchEvent. Listeners added through it sit on the real window, so
    // dispatching there reaches them (storage-changed, the player resize nudge,
    // selector misses, runtime-ready).
    function completeEventTarget() {
        const realWindow = typeof document !== 'undefined' ? document.defaultView : null;
        if (!realWindow || typeof realWindow.dispatchEvent !== 'function') return;
        for (const target of new Set([HOST_GLOBAL, HOST_WINDOW])) {
            if (typeof target.dispatchEvent === 'function') continue;
            try {
                Object.defineProperty(target, 'dispatchEvent', {
                    value: (event) => realWindow.dispatchEvent(event),
                    configurable: true,
                    writable: true,
                    enumerable: false
                });
            } catch (error) {
                recordError('event target', error);
            }
        }
    }

    function addStyle(css, label) {
        try {
            if (GM_API.addStyle) {
                const node = GM_API.addStyle(css);
                if (node && typeof node.setAttribute === 'function') node.setAttribute('data-astra-deck-style', label);
                return;
            }
            const style = document.createElement('style');
            style.setAttribute('data-astra-deck-style', label);
            style.textContent = css;
            (document.head || document.documentElement).appendChild(style);
        } catch (error) {
            recordError('style ' + label, error);
        }
    }

    function whenDocumentElement(run) {
        if (document.documentElement) {
            run();
            return;
        }
        const observer = new MutationObserver(() => {
            if (!document.documentElement) return;
            observer.disconnect();
            run();
        });
        observer.observe(document, { childList: true });
    }

    function whenIdle(run) {
        const go = () => setTimeout(run, 0);
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', go, { once: true });
        } else {
            go();
        }
    }

    // ── MAIN world ───────────────────────────────────────────────────────────
    // The page-world scripts are one registered function whose SOURCE is
    // injected; it never runs in the sandbox. GM_addElement is the only route
    // that clears YouTube's Trusted Types and script-src policy under every
    // manager; a manager without it gets the ISOLATED runtime alone.
    function injectMainWorld() {
        const mainWorld = registry[BUILD.mainWorldModule];
        if (typeof mainWorld !== 'function') throw new Error('MAIN-world bundle is missing');
        if (!GM_API.addElement) throw new Error('GM_addElement is not granted; page-world features are off');
        const code = '(' + Function.prototype.toString.call(mainWorld) + ')();';
        const node = GM_API.addElement(document.documentElement, 'script', { textContent: code });
        if (node && typeof node.remove === 'function') node.remove();
        document.documentElement.setAttribute('data-astra-deck-userscript', BUILD.version);
    }

    // ── Background ───────────────────────────────────────────────────────────
    // background.js runs in this tab's sandbox with its own global object, so
    // the core modules it loads through importScripts get a namespace of their
    // own, exactly as they would in the service worker.
    let backgroundStarted = false;

    // ── AI provider keys ─────────────────────────────────────────────────────
    // Kept where the old userscript kept them, in the manager's own storage,
    // which youtube.com's scripts can't read. Left alone, the extension's vault
    // falls back to IndexedDB, and in a userscript that is the page's. Keys the
    // old userscript saved sit under the same names, so they carry over.
    const CREDENTIAL_PREFIX = 'ytkit:ai-credential:';
    const CREDENTIAL_PROVIDERS = Object.freeze(['openai', 'anthropic', 'gemini']);
    const credentialStore = Object.freeze({
        get: async (provider) => {
            const value = GM_API.getValue(CREDENTIAL_PREFIX + provider, '');
            return typeof value === 'string' ? value : '';
        },
        set: async (provider, credential) => {
            GM_API.setValue(CREDENTIAL_PREFIX + provider, String(credential));
        },
        delete: async (provider) => {
            GM_API.deleteValue(CREDENTIAL_PREFIX + provider);
        }
    });

    function useManagerCredentialStore(core) {
        const create = core?.createCredentialVault;
        // Without the module, background.js runs with no vault, as it would in
        // the extension, and AI features report the vault unavailable.
        if (typeof create !== 'function') return;
        core.createCredentialVault = (options = {}) => create({ ...options, persistentStore: credentialStore });
    }

    function startBackground() {
        const backgroundApi = createApi('background');
        const backgroundGlobal = {
            chrome: backgroundApi,
            browser: undefined,
            crypto: HOST_GLOBAL.crypto,
            indexedDB: HOST_GLOBAL.indexedDB,
            IDBKeyRange: HOST_GLOBAL.IDBKeyRange,
            navigator: HOST_GLOBAL.navigator,
            location: { href: PACKAGE_BASE_URL + 'background.js', origin: PACKAGE_BASE_URL.slice(0, -1) }
        };
        backgroundGlobal.globalThis = backgroundGlobal;
        backgroundGlobal.self = backgroundGlobal;
        const scope = {
            global: backgroundGlobal,
            self: backgroundGlobal,
            window: undefined,
            chrome: backgroundApi,
            browser: undefined,
            fetch: backgroundFetch,
            importScripts: undefined,
            trustedTypes: undefined
        };
        for (const path of BUILD.modules.backgroundCore) runModule(path, scope);
        useManagerCredentialStore(backgroundGlobal.YTKitCore);
        runModule(BUILD.modules.background, scope);
        backgroundStarted = true;
        HOST_WINDOW.addEventListener('pagehide', () => onSuspend.dispatch(), { once: true });
        later(dispatchInstallEvent);
    }

    function dispatchInstallEvent() {
        let previous = null;
        try {
            previous = GM_API.getValue(INSTALLED_VERSION_KEY, null);
        } catch (_) {
            previous = null;
        }
        if (previous === BUILD.version) return;
        let reason = 'update';
        if (!previous) {
            // A settings object from the old hand-written userscript means this
            // is an upgrade, not a first run: no first-run onboarding.
            let legacy = null;
            try {
                legacy = GM_API.getValue('ytSuiteSettings', null);
            } catch (_) {
                legacy = null;
            }
            reason = legacy ? 'update' : 'install';
        }
        try {
            GM_API.setValue(INSTALLED_VERSION_KEY, BUILD.version);
        } catch (error) {
            recordError('install marker', error);
        }
        onInstalled.dispatch(previous ? { reason, previousVersion: String(previous) } : { reason });
    }

    // ── ISOLATED runtime ─────────────────────────────────────────────────────
    // The same sequence runtime-bootstrap.js runs in the extension, with the
    // same observable state, minus dynamic import().
    function shouldLoadFeature(modulePath, settings) {
        const keys = BUILD.featureSettings[modulePath];
        return !(Array.isArray(keys) && keys.length
            && keys.every((key) => Object.hasOwn(settings, key) && settings[key] === false));
    }

    async function startIsolatedRuntime() {
        const bootstrapState = {
            schemaVersion: 1,
            phase: 'starting',
            active: true,
            duplicateInjections: 0,
            generation: 1,
            startedAt: Date.now(),
            completedAt: null,
            failure: null,
            failedFeatureModules: [],
            host: 'userscript'
        };
        HOST_GLOBAL.__ytkitRuntimeBootstrap = bootstrapState;
        const stageTimings = Object.create(null);
        bootstrapState.stageTimings = stageTimings;
        const timeStage = (name, run) => {
            const startedAt = performance.now();
            try {
                return run();
            } finally {
                stageTimings[name] = Math.round((performance.now() - startedAt) * 100) / 100;
            }
        };

        contentApi.runtime.sendMessage({ type: 'YTKIT_ZERO_AD_STATUS' }).then((status) => {
            const state = status?.ok && status?.enabled ? 'enabled' : 'unavailable';
            document.documentElement?.setAttribute('data-ytkit-zero-ad-ruleset', state);
            bootstrapState.zeroAdRuleset = state;
        }, () => {
            bootstrapState.zeroAdRuleset = 'unavailable';
        });

        const settingsPromise = contentApi.storage.local.get('ytSuiteSettings')
            .then((result) => (result?.ytSuiteSettings && typeof result.ytSuiteSettings === 'object' ? result.ytSuiteSettings : {}))
            .catch(() => ({}));

        timeStage('coreLoaderMs', () => {
            for (const path of BUILD.modules.foundation) runModule(path, contentScope);
        });
        const routeBridgeInstalled = HOST_GLOBAL.YTKitCore?.installLifecycleRouteBridge?.() === true;
        if (!routeBridgeInstalled) {
            console.error('[YTKit] Lifecycle route bridge failed to install; SPA route tokens will not advance');
        }
        bootstrapState.routeBridgeInstalled = routeBridgeInstalled;
        const settingsStartedAt = performance.now();
        const settings = await settingsPromise;
        stageTimings.settingsReadMs = Math.round((performance.now() - settingsStartedAt) * 100) / 100;
        // A module the pinned libraries don't carry yet is a newer feature
        // than this release has; it's listed, not loaded and not an error.
        bootstrapState.unbundledFeatureModules = hostState.missingOptionalModules.slice();
        const featureModules = BUILD.modules.features.filter((path) => shouldLoadFeature(path, settings)
            && typeof registry[path] === 'function');
        stageTimings.featureModuleCount = featureModules.length;
        const failedFeatureModules = [];
        timeStage('featureModulesMs', () => {
            for (const path of featureModules) {
                try {
                    runModule(path, contentScope);
                } catch (error) {
                    failedFeatureModules.push(path);
                    const reason = error?.message || String(error || 'unknown error');
                    console.error('[YTKit] feature module failed to load: ' + path + ' - ' + reason);
                    HOST_GLOBAL.YTKitCore?.DiagnosticLog?.record?.('feature-module-load', 'feature module failed to load: ' + path + ' - ' + reason);
                }
            }
        });
        bootstrapState.failedFeatureModules = failedFeatureModules;
        stageTimings.featureModuleFailureCount = failedFeatureModules.length;
        timeStage('monolithMs', () => runModule(BUILD.modules.app, contentScope));
        HOST_GLOBAL.dispatchEvent?.(new CustomEvent('ytkit-runtime-ready'));
        bootstrapState.phase = 'ready';
        bootstrapState.completedAt = Date.now();
    }

    function startLiveChat() {
        whenIdle(() => {
            try {
                addStyle(BUILD.css.liveChat, 'live-chat');
                for (const path of BUILD.modules.liveChat) runModule(path, contentScope);
                hostState.phase = 'ready';
            } catch (error) {
                hostState.phase = 'failed';
                recordError('live chat runtime', error);
            }
        });
    }

    function hostText(key, fallback) {
        return getMessage(key) || fallback;
    }

    let hostToast = null;
    function notify(message, isError = false) {
        const core = HOST_GLOBAL.YTKitCore;
        if (!hostToast && core?.toastDom?.createToastSystem && core.toast) {
            hostToast = core.toastDom.createToastSystem({
                inferToastTone: core.toast.inferToastTone,
                getToastRgb: core.toast.getToastRgb,
                getToastBadgeLabel: core.toast.getToastBadgeLabel
            });
        }
        if (hostToast) hostToast.showToast(message, isError ? '#ef4444' : '#22c55e');
        else if (isError) recordError('ai credential', new Error(message));
    }

    function currentAiProvider() {
        const settings = GM_API.getValue('ytSuiteSettings', null);
        const provider = settings && typeof settings === 'object' ? settings.aiSummaryProvider : '';
        return CREDENTIAL_PROVIDERS.includes(provider) ? provider : CREDENTIAL_PROVIDERS[0];
    }

    // The manager menu is the userscript's toolbar popup: a sender with no tab,
    // the only kind the background accepts a key from. Prompts are the input a
    // userscript has there. An empty key removes the saved one, and the prompt
    // says so.
    async function manageAiCredential() {
        const title = hostText('aiCredentialTitle', 'AI provider credential');
        const providerLabel = hostText('aiCredentialProviderLabel', 'Provider');
        const choices = CREDENTIAL_PROVIDERS.join(', ');
        const answer = HOST_WINDOW.prompt(`${title}\n${providerLabel}: ${choices}`, currentAiProvider());
        if (answer === null) return;
        const provider = String(answer).trim().toLowerCase();
        if (!CREDENTIAL_PROVIDERS.includes(provider)) {
            notify(`${providerLabel}: ${choices}`, true);
            return;
        }
        const placeholder = hostText('aiCredentialInputPlaceholder', 'Paste your API key');
        const credential = HOST_WINDOW.prompt(`${placeholder} (${provider}). Leave it empty to remove the saved key.`, '');
        if (credential === null) return;
        const remove = !String(credential).trim();
        const message = remove
            ? { type: 'YTKIT_AI_CREDENTIAL_DELETE', provider }
            : { type: 'YTKIT_AI_CREDENTIAL_SET', provider, credential: String(credential), remember: true };
        const response = await deliverMessage(backgroundOnMessage, message, extensionSender());
        if (!response?.ok) {
            const fallback = remove
                ? hostText('aiCredentialDeleteFailed', 'Credential could not be deleted.')
                : hostText('aiCredentialSaveFailed', 'Credential could not be saved.');
            notify(response?.error?.message || fallback, true);
            return;
        }
        notify(remove
            ? hostText('aiCredentialDeleted', 'AI credential deleted.')
            : hostText('aiCredentialSaved', 'AI credential saved without exposing its value.'));
    }

    // A manager menu click gives the page no user activation, so the page
    // clipboard refuses it; GM_setClipboard doesn't need one.
    async function copyDiagnostics() {
        const response = await deliverMessage(contentOnMessage, { type: 'YTKIT_BUILD_BUG_REPORT' }, extensionSender());
        if (!response?.ok || !response.report) throw new Error(response?.error || 'diagnostics unavailable');
        const text = JSON.stringify(response.report, null, 2);
        // Awaited so a manager whose GM_setClipboard returns a promise can
        // report a refusal; the plain sync form only fails by throwing.
        if (GM_API.setClipboard) await GM_API.setClipboard(text);
        else await HOST_WINDOW.navigator.clipboard.writeText(text);
        notify(hostText('statusDiagCopied', 'Diagnostic copied to clipboard.'));
    }

    function registerMenu() {
        if (!GM_API.registerMenuCommand) return;
        try {
            GM_API.registerMenuCommand(BUILD.menuLabel, () => {
                deliverMessage(contentOnMessage, { type: 'YTKIT_OPEN_PANEL' }, extensionSender())
                    .catch((error) => recordError('open settings', error));
            });
            GM_API.registerMenuCommand(BUILD.diagnosticsMenuLabel, () => {
                copyDiagnostics().catch((error) => {
                    recordError('diagnostics', error);
                    notify(hostText(
                        'diagnosticsMenuCopyFailed',
                        "Couldn't copy the diagnostics. Open the settings panel and use the bug button under the sidebar."
                    ), true);
                });
            });
            GM_API.registerMenuCommand(BUILD.credentialMenuLabel, () => {
                manageAiCredential().catch((error) => {
                    recordError('ai credential', error);
                    notify(hostText('aiCredentialSaveFailed', 'Credential could not be saved.'), true);
                });
            });
        } catch (error) {
            recordError('menu command', error);
        }
    }

    // The old hand-written userscript kept Return YouTube Dislike under a key
    // the extension retired, so loading its settings would quietly turn the
    // feature off. Renamed once, on this host's first run over an old install.
    // Extension installs never pass through here, so a years-old retired key
    // there stays retired.
    const LEGACY_USERSCRIPT_RENAMES = Object.freeze({ returnYoutubeDislike: 'returnDislike' });

    function migrateLegacyUserscriptSettings() {
        if (GM_API.getValue(INSTALLED_VERSION_KEY, null)) return;
        const settings = GM_API.getValue('ytSuiteSettings', null);
        if (!settings || typeof settings !== 'object' || Array.isArray(settings)) return;
        const next = { ...settings };
        let changed = false;
        for (const [from, to] of Object.entries(LEGACY_USERSCRIPT_RENAMES)) {
            if (!Object.prototype.hasOwnProperty.call(next, from)) continue;
            if (!Object.prototype.hasOwnProperty.call(next, to)) next[to] = next[from];
            delete next[from];
            changed = true;
        }
        if (changed) GM_API.setValue('ytSuiteSettings', next);
    }

    // ── Start ────────────────────────────────────────────────────────────────
    completeEventTarget();
    try {
        exposeContentApi();
    } catch (error) {
        hostState.phase = 'failed';
        recordError('adapter', error);
        return;
    }

    try {
        migrateLegacyUserscriptSettings();
    } catch (error) {
        recordError('settings migration', error);
    }

    if (route === 'live-chat') {
        startLiveChat();
        return;
    }

    try {
        startBackground();
    } catch (error) {
        recordError('background', error);
    }
    hostState.backgroundStarted = backgroundStarted;

    whenDocumentElement(() => {
        try {
            runModule(BUILD.modules.bridgeToken, contentScope);
        } catch (error) {
            recordError('bridge token', error);
        }
        addStyle(BUILD.css.early, 'early');
        document.documentElement.setAttribute(AD_CONTRACT_ATTRIBUTE, AD_CONTRACT);
        try {
            injectMainWorld();
        } catch (error) {
            recordError('page-world scripts', error);
        }
        // The early page-world switches, after the page world as in the
        // manifest. The extension imports the channel module there; here it
        // runs from the registry first, and the runtime's later run of it
        // keeps this writer.
        const earlyModules = (BUILD.modules.earlyStart || []).filter((path) => typeof registry[path] === 'function');
        if (earlyModules.length) {
            try {
                runModule(BUILD.modules.bridgeChannel, contentScope);
                for (const modulePath of earlyModules) runModule(modulePath, contentScope);
            } catch (error) {
                recordError('early switches', error);
            }
        }
    });

    registerMenu();

    whenIdle(() => {
        HOST_GLOBAL.__ytkitRuntimePromise = startIsolatedRuntime().then(
            () => {
                hostState.phase = 'ready';
            },
            (error) => {
                hostState.phase = 'failed';
                const state = HOST_GLOBAL.__ytkitRuntimeBootstrap;
                if (state) {
                    state.phase = 'failed';
                    state.active = false;
                    state.completedAt = Date.now();
                    state.failure = String(error?.message || error || 'runtime-load-failed').slice(0, 240);
                }
                // The early switches published at document start have no
                // feature left to confirm them, so they come off.
                try {
                    HOST_GLOBAL.YTKitCore?.earlyBridgeSwitches?.settle?.(() => false);
                } catch (settleError) {
                    recordError('early switches', settleError);
                }
                recordError('runtime', error);
            }
        );
    });
})(ASTRA_DECK_BUILD);
