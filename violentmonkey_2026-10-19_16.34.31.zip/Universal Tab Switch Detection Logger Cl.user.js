// ==UserScript==
// @name         Universal Tab Switch Detection Logger Cl
// @namespace    blazeftl
// @version      2.0
// @description  Logs tab-switch detection hooks and suggests uBlock Origin filters
// @match        *://*/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const HOST = location.hostname.replace(/^www\./, '');
    const IS_TOP = (() => { try { return window.top === window; } catch (err) { return false; } })();
    const entries = new Map();
    const pending = new Set();
    const origAdd = EventTarget.prototype.addEventListener;
    const origHasFocus = Document.prototype.hasFocus;
    const fnToString = Function.prototype.toString;
    const timeout = window.setTimeout;
    const KIND_LABEL = { listener: 'Listener', property: 'Read', method: 'Call', handler: 'Handler' };
    const PROP_SET = {
        'document.hidden': 'false',
        'document.webkitHidden': 'false',
        'document.visibilityState': 'visible',
        'document.webkitVisibilityState': 'visible'
    };
    const WATCHED = new Set([
        'visibilitychange', 'webkitvisibilitychange', 'mozvisibilitychange', 'msvisibilitychange',
        'blur', 'focus', 'pagehide', 'pageshow', 'beforeunload', 'unload', 'freeze', 'resume'
    ]);
    let busy = false;
    let nextId = 1;
    let flushUI = null;
    let flushTimer = 0;

    try {
        if (typeof Error.stackTraceLimit === 'number' && Error.stackTraceLimit < 30) Error.stackTraceLimit = 30;
    } catch (err) {}

    const pad = (n, l = 2) => String(n).padStart(l, '0');
    function fmt(ms) {
        const d = new Date(ms);
        return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`;
    }

    function rootDomain(h) {
        const p = h.split('.');
        const n = p.length;
        if (n <= 2) return h;
        return (p[n - 1].length === 2 && p[n - 2].length <= 3) ? p.slice(-3).join('.') : p.slice(-2).join('.');
    }

    function fileName(u) {
        return u.split(/[?#]/)[0].split('/').pop() || '';
    }

    function shortUrl(u) {
        return /^https?:/i.test(u) ? u.replace(/^https?:\/\//i, '').split(/[?#]/)[0] : u;
    }

    function urlKind(u) {
        if (!u) return 'other';
        if (u.split('#')[0] === location.href.split('#')[0]) return 'inline';
        if (/^https?:/i.test(u)) return 'url';
        return 'other';
    }

    function parseStack(raw) {
        const out = [];
        for (const line of raw.split('\n')) {
            const l = line.trim();
            if (!l || l === 'Error') continue;
            let m = l.match(/^at\s+(?:(.*?)\s+\()?(.*?):(\d+):(\d+)\)?$/);
            if (m) { out.push({ fn: m[1] || '', url: m[2], line: +m[3], col: +m[4] }); continue; }
            m = l.match(/^(.*?)@(.*?):(\d+):(\d+)$/);
            if (m) out.push({ fn: m[1], url: m[2], line: +m[3], col: +m[4] });
        }
        return out;
    }

    function targetName(t) {
        if (t === document) return 'document';
        if (t === window) return 'window';
        if (t && t.nodeType === 1) {
            let s = t.tagName.toLowerCase();
            if (t.id) s += '#' + t.id;
            return s;
        }
        return (t && t.constructor && t.constructor.name) || 'unknown';
    }

    function fnInfo(fn) {
        let f = fn;
        if (fn && typeof fn === 'object' && typeof fn.handleEvent === 'function') f = fn.handleEvent;
        if (typeof f !== 'function') return { name: '', src: '' };
        let src = '';
        try { src = fnToString.call(f); } catch (err) {}
        return { name: f.name || '', src: src.replace(/\s+/g, ' ').slice(0, 400) };
    }

    function optsString(o) {
        if (o === true) return 'capture';
        if (!o || typeof o !== 'object') return '';
        const a = [];
        if (o.capture) a.push('capture');
        if (o.once) a.push('once');
        if (o.passive) a.push('passive');
        if (o.signal) a.push('signal');
        return a.join(', ');
    }

    function pickPattern(name, src) {
        if (name && name.length > 2 && name !== 'handleEvent' && !/^(bound |anonymous)/.test(name)) return name;
        const found = (src.match(/[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)+/g) || [])
            .find(s => s.length > 7 && !/^(console|Math|Object|JSON)\./.test(s));
        return found || '';
    }

    function pickScript(frames) {
        for (const f of frames) {
            const k = urlKind(f.url);
            if (k === 'url') {
                let hn = '';
                try { hn = new URL(f.url).hostname; } catch (err) {}
                return { kind: 'url', url: f.url, host: hn, third: !!hn && rootDomain(hn) !== rootDomain(location.hostname) };
            }
            if (k === 'inline') return { kind: 'inline', url: f.url, host: location.hostname, third: false };
        }
        return null;
    }

    const F = (label, text, primary) => ({ label, text, primary });

    function buildFilters(e) {
        const out = [];
        const dom = e.host;
        if (!dom) return out;
        const p = e.script;
        const file = p && p.kind === 'url' ? fileName(p.url) : '';
        if (e.kind === 'listener') {
            out.push(F('Scriptlet: defuse listener', `${dom}##+js(aeld, ${e.type}${e.pattern ? ', ' + e.pattern : ''})`, true));
        } else if (e.kind === 'property') {
            const v = PROP_SET[e.detail];
            if (v) out.push(F('Scriptlet: spoof value', `${dom}##+js(set, ${e.detail}, ${v})`, true));
            if (file) out.push(F('Scriptlet: abort when read by this script', `${dom}##+js(aost, ${e.detail}, ${file})`, false));
        } else if (e.kind === 'method') {
            out.push(F('Scriptlet: spoof return value', `${dom}##+js(set, document.hasFocus, trueFunc)`, true));
        } else if (e.kind === 'handler') {
            out.push(F('Scriptlet: ignore handler assignment', `${dom}##+js(set, ${e.detail.replace(/^window\./, '')}, noopFunc)`, true));
        }
        if (p && p.kind === 'url') {
            out.push(F('Network: block this script', `||${shortUrl(p.url)}$script,domain=${dom}`, false));
        }
        return out;
    }

    function schedule() {
        if (!flushUI || flushTimer) return;
        flushTimer = timeout.call(window, flushUI, 100);
    }

    function record(kind, detail, extra) {
        if (busy) return;
        busy = true;
        try {
            let frames = parseStack(new Error().stack || '');
            let cut = -1;
            frames.forEach((f, i) => { if (/tdl[A-Z]/.test(f.fn)) cut = i; });
            frames = frames
                .slice(cut + 1)
                .filter(f => !/^(chrome|moz|safari-web)-extension:/.test(f.url))
                .slice(0, 10);
            const top = frames[0];
            const key = [kind, detail, top ? `${top.url}:${top.line}:${top.col}` : ''].join('|');
            const now = Date.now();
            let e = entries.get(key);
            if (e) {
                e.count++;
                e.last = now;
            } else {
                e = Object.assign({
                    id: nextId++, key, kind, detail, host: HOST, page: location.href,
                    frame: IS_TOP ? 'top frame' : 'iframe', count: 1, first: now, last: now, frames,
                    type: '', target: '', listenerName: '', listenerSrc: '', opts: '', pattern: ''
                }, extra);
                e.script = pickScript(frames);
                e.filters = buildFilters(e);
                e.search = [
                    kind, detail, e.target, e.listenerName, e.listenerSrc,
                    ...frames.map(f => f.url + ' ' + f.fn), ...e.filters.map(f => f.text)
                ].join(' ').toLowerCase();
                entries.set(key, e);
                console.log('[TabDetect]', kind, detail, e);
            }
            pending.add(e);
            schedule();
        } finally {
            busy = false;
        }
    }

    EventTarget.prototype.addEventListener = function tdlAddEventListener(type, listener, options) {
        if (WATCHED.has(type)) {
            const fi = fnInfo(listener);
            const tn = targetName(this);
            record('listener', `${type} on ${tn}`, {
                type, target: tn, listenerName: fi.name, listenerSrc: fi.src,
                opts: optsString(options), pattern: pickPattern(fi.name, fi.src)
            });
        }
        return origAdd.apply(this, arguments);
    };

    function hookGetter(proto, prop, label) {
        const d = Object.getOwnPropertyDescriptor(proto, prop);
        if (!d || !d.get) return;
        Object.defineProperty(proto, prop, {
            get: function tdlGetter() {
                record('property', label, { target: 'document' });
                return d.get.call(this);
            },
            set: d.set,
            configurable: true,
            enumerable: d.enumerable
        });
    }

    hookGetter(Document.prototype, 'hidden', 'document.hidden');
    hookGetter(Document.prototype, 'visibilityState', 'document.visibilityState');
    hookGetter(Document.prototype, 'webkitHidden', 'document.webkitHidden');
    hookGetter(Document.prototype, 'webkitVisibilityState', 'document.webkitVisibilityState');

    Document.prototype.hasFocus = function tdlHasFocus() {
        record('method', 'document.hasFocus()', { target: 'document' });
        return origHasFocus.apply(this, arguments);
    };

    function hookHandlerProp(target, label, prop) {
        let d = Object.getOwnPropertyDescriptor(target, prop);
        if (!d) d = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(target), prop);
        if (!d || !d.set) return;
        Object.defineProperty(target, prop, {
            get: d.get,
            set: function tdlSetHandler(fn) {
                if (typeof fn === 'function') {
                    const fi = fnInfo(fn);
                    record('handler', `${label}.${prop}`, {
                        type: prop.slice(2), target: label, listenerName: fi.name, listenerSrc: fi.src,
                        pattern: pickPattern(fi.name, fi.src)
                    });
                }
                d.set.call(this, fn);
            },
            configurable: true,
            enumerable: d.enumerable
        });
    }

    ['onblur', 'onfocus', 'onpagehide', 'onpageshow', 'onbeforeunload', 'onunload']
        .forEach(p => hookHandlerProp(window, 'window', p));
    ['onvisibilitychange', 'onblur', 'onfocus']
        .forEach(p => hookHandlerProp(document, 'document', p));

    const NS = 'http://www.w3.org/2000/svg';
    const I = {
        bug: 'M20 8h-2.81a5.985 5.985 0 0 0-1.82-1.96L17 4.41 15.59 3l-2.17 2.17C12.96 5.06 12.49 5 12 5s-.96.06-1.41.17L8.41 3 7 4.41l1.62 1.63C7.88 6.55 7.26 7.22 6.81 8H4v2h2.09c-.05.33-.09.66-.09 1v1H4v2h2v1c0 .34.04.67.09 1H4v2h2.81c1.04 1.79 2.97 3 5.19 3s4.15-1.21 5.19-3H20v-2h-2.09c.05-.33.09-.66.09-1v-1h2v-2h-2v-1c0-.34-.04-.67-.09-1H20V8zm-6 8h-4v-2h4v2zm0-4h-4v-2h4v2z',
        min: 'M19 13H5v-2h14v2z',
        del: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
        copy: 'M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z',
        search: 'M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
        more: 'M16.59 8.59 12 13.17 7.41 8.59 6 10l6 6 6-6z',
        check: 'M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z'
    };

    const CSS = `
*{box-sizing:border-box;margin:0}
[hidden]{display:none!important}
.wrap{--p:#6750a4;--op:#fff;--pc:#eaddff;--opc:#21005d;--s:#fffbfe;--sc:#f7f2fa;--sch:#ece6f0;--ol:#79747e;--olv:#cac4d0;--on:#1d1b20;--onv:#49454f;
font:400 13px/1.45 Roboto,"Segoe UI",system-ui,-apple-system,sans-serif;color:var(--on);-webkit-font-smoothing:antialiased}
.fab{position:relative;width:56px;height:56px;border:0;border-radius:16px;background:var(--pc);color:var(--opc);display:grid;place-items:center;cursor:pointer;
box-shadow:0 1px 3px rgba(0,0,0,.3),0 4px 8px 3px rgba(0,0,0,.15);transition:box-shadow .2s}
.fab:hover{box-shadow:0 1px 3px rgba(0,0,0,.3),0 6px 12px 4px rgba(0,0,0,.18)}
.fab svg{width:26px;height:26px;fill:currentColor}
.badge{position:absolute;top:-6px;right:-6px;min-width:20px;height:20px;padding:0 6px;border-radius:10px;background:var(--p);color:#fff;font:500 11px/20px Roboto,"Segoe UI",sans-serif;text-align:center}
.panel{position:relative;width:400px;max-width:calc(100vw - 24px);max-height:min(74vh,640px);display:flex;flex-direction:column;background:var(--s);
border:1px solid var(--olv);border-radius:24px;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.18),0 12px 32px rgba(0,0,0,.16)}
header{flex:none;display:flex;align-items:center;gap:2px;padding:10px 8px 6px 20px;cursor:grab;user-select:none;touch-action:none}
header:active{cursor:grabbing}
.titles{flex:1;min-width:0}
.title{font-size:17px;font-weight:500;line-height:1.3}
.sub{font-size:12px;color:var(--onv);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.icon{flex:none;width:38px;height:38px;border:0;border-radius:50%;background:transparent;color:var(--onv);display:grid;place-items:center;cursor:pointer}
.icon:hover{background:rgba(29,27,32,.08)}
.icon:focus-visible,.btn:focus-visible,.fc:focus-visible,.fab:focus-visible,.head:focus-visible{outline:2px solid var(--p);outline-offset:-2px}
.icon svg{width:20px;height:20px;fill:currentColor}
.icon.sm{width:32px;height:32px}
.icon.sm svg{width:18px;height:18px}
.search{flex:none;margin:4px 16px 8px;height:44px;padding:0 16px;display:flex;align-items:center;gap:10px;background:var(--sch);border-radius:24px;color:var(--onv)}
.search svg{width:20px;height:20px;fill:currentColor;flex:none}
.search input{flex:1;min-width:0;border:0;outline:0;background:transparent;font:inherit;font-size:14px;color:var(--on)}
.search input::placeholder{color:var(--onv)}
.chips{flex:none;display:flex;gap:8px;padding:0 16px 10px;overflow-x:auto;scrollbar-width:none}
.fc{flex:none;height:32px;padding:0 12px;border:1px solid var(--ol);border-radius:8px;background:transparent;color:var(--onv);font:500 12.5px Roboto,"Segoe UI",sans-serif;cursor:pointer;display:flex;align-items:center;gap:6px}
.fc:hover{background:rgba(29,27,32,.06)}
.fc.on{background:#e8def8;border-color:transparent;color:#1d192b}
.fc svg{display:none;width:16px;height:16px;fill:currentColor}
.fc.on svg{display:block}
.fc b{font-weight:500;opacity:.65}
.list{flex:1 1 auto;min-height:140px;overflow-y:auto;border-top:1px solid var(--olv);scrollbar-width:thin}
.empty{padding:40px 24px;text-align:center;color:var(--onv)}
.empty .e1{font-size:15px;font-weight:500;color:var(--on);margin-bottom:4px}
.row{border-bottom:1px solid var(--olv)}
.row.open{background:var(--sc)}
.head{width:100%;display:flex;align-items:center;gap:12px;padding:10px 12px 10px 16px;border:0;background:transparent;text-align:left;cursor:pointer;font:inherit;color:inherit}
.head:hover{background:rgba(103,80,164,.07)}
.chip{flex:none;font-size:12px;font-weight:500;padding:3px 10px;border-radius:8px}
.chip.listener{background:#eaddff;color:#21005d}
.chip.property{background:#d3e3fd;color:#041e49}
.chip.method{background:#c4eed0;color:#072711}
.chip.handler{background:#ffdcc2;color:#2e1500}
.txt{flex:1;min-width:0;display:flex;flex-direction:column;gap:1px}
.name{font-size:13.5px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.meta{display:flex;gap:10px;font-size:11.5px;color:var(--onv);overflow:hidden;white-space:nowrap}
.meta span{overflow:hidden;text-overflow:ellipsis}
.cnt{flex:none;min-width:24px;padding:1px 8px;border-radius:10px;background:var(--pc);color:var(--opc);font-size:12px;font-weight:500;text-align:center}
.cnt:empty{display:none}
.chev svg{display:block;width:22px;height:22px;fill:var(--onv);transition:transform .2s}
.row.open .chev svg{transform:rotate(180deg)}
.body{display:none;padding:0 16px 16px}
.row.open .body{display:block}
dl{display:grid;grid-template-columns:76px 1fr;gap:6px 12px;font-size:12.5px;margin:4px 0 8px}
dt{color:var(--onv)}
dd{word-break:break-all}
.tag{display:inline-block;margin-left:6px;padding:0 8px;border-radius:6px;background:var(--sch);color:var(--onv);font-size:11.5px;font-weight:500}
.tag.tp{background:#ffd8e4;color:#31111d}
.sec{font-size:13px;font-weight:500;color:var(--p);margin:14px 0 6px}
ol{list-style:none;display:flex;flex-direction:column;gap:6px}
li{background:var(--s);border:1px solid var(--olv);border-radius:12px;padding:7px 10px;font:11.5px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
li .fn{display:block;font-weight:600}
li .loc{display:block;color:var(--onv);word-break:break-all}
pre{background:var(--s);border:1px solid var(--olv);border-radius:12px;padding:9px 10px;font:11.5px/1.5 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-all;max-height:112px;overflow:auto}
.flt{display:flex;align-items:flex-start;gap:6px;margin-bottom:8px;padding:9px 6px 9px 12px;background:var(--s);border:1px solid var(--olv);border-radius:12px}
.flt .ft{flex:1;min-width:0}
.flt small{display:block;margin-bottom:3px;font-size:11.5px;color:var(--onv)}
.flt code{font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;word-break:break-all;color:var(--opc)}
footer{flex:none;display:flex;align-items:center;gap:6px;padding:10px 14px 12px 20px;border-top:1px solid var(--olv);background:var(--s)}
.stat{flex:1;font-size:12px;color:var(--onv)}
.btn{height:38px;padding:0 18px;border:0;border-radius:19px;background:transparent;color:var(--p);font:500 13.5px Roboto,"Segoe UI",sans-serif;cursor:pointer}
.btn:hover{background:rgba(103,80,164,.09)}
.btn.fill{background:var(--p);color:var(--op)}
.btn.fill:hover{background:#5b4699;box-shadow:0 1px 3px rgba(0,0,0,.3)}
.snack{position:absolute;left:50%;bottom:68px;transform:translate(-50%,8px);padding:11px 18px;border-radius:8px;background:#322f35;color:#f5eff7;font-size:13.5px;white-space:nowrap;
opacity:0;pointer-events:none;transition:opacity .2s,transform .2s;box-shadow:0 2px 6px rgba(0,0,0,.3)}
.snack.show{opacity:1;transform:translate(-50%,0)}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
`;

    function h(tag, props, ...kids) {
        const el = document.createElement(tag);
        if (props) {
            for (const k in props) {
                const v = props[k];
                if (k === 'class') el.className = v;
                else if (k === 'text') el.textContent = v;
                else if (k === 'data') { for (const d in v) el.dataset[d] = v[d]; }
                else if (v === true) el.setAttribute(k, '');
                else if (v !== false && v != null) el.setAttribute(k, v);
            }
        }
        for (const c of kids) if (c != null && c !== false) el.append(c);
        return el;
    }

    function icon(d) {
        const s = document.createElementNS(NS, 'svg');
        s.setAttribute('viewBox', '0 0 24 24');
        const p = document.createElementNS(NS, 'path');
        p.setAttribute('d', d);
        s.append(p);
        return s;
    }

    function scriptLabel(e) {
        const p = e.script;
        if (!p) return 'unknown source';
        if (p.kind === 'inline') return 'inline script';
        return fileName(p.url) || p.host;
    }

    function buildUI() {
        const host = document.createElement('div');
        host.style.cssText = 'all:initial;display:block;position:fixed;right:16px;bottom:16px;z-index:2147483647;';
        const root = host.attachShadow({ mode: 'closed' });
        try {
            const sheet = new CSSStyleSheet();
            sheet.replaceSync(CSS);
            root.adoptedStyleSheets = [sheet];
        } catch (err) {
            const st = document.createElement('style');
            st.textContent = CSS;
            root.append(st);
        }

        const bClear = h('button', { class: 'icon', type: 'button', title: 'Clear log' }, icon(I.del));
        const bMin = h('button', { class: 'icon', type: 'button', title: 'Minimize' }, icon(I.min));
        const head = h('header', null,
            h('div', { class: 'titles' },
                h('div', { class: 'title', text: 'Tab detect log' }),
                h('div', { class: 'sub', text: `${HOST || location.protocol} (${IS_TOP ? 'top frame' : 'iframe'})` })),
            bClear, bMin);
        const q = h('input', { type: 'text', placeholder: 'Search events, scripts, filters', spellcheck: 'false' });
        const search = h('div', { class: 'search' }, icon(I.search), q);
        const chipsEl = h('div', { class: 'chips' });
        const empty = h('div', { class: 'empty' },
            h('div', { class: 'e1', text: 'No detections yet' }),
            h('div', { text: 'Hooks are active. Switch tabs or reload to trigger checks.' }));
        const list = h('div', { class: 'list' }, empty);
        const stat = h('span', { class: 'stat' });
        const bJson = h('button', { class: 'btn', type: 'button', text: 'Export JSON' });
        const bCopy = h('button', { class: 'btn fill', type: 'button', text: 'Copy filters' });
        const snack = h('div', { class: 'snack' });
        const panel = h('section', { class: 'panel' }, head, search, chipsEl, list, h('footer', null, stat, bJson, bCopy), snack);
        const badge = h('span', { class: 'badge', text: '0' });
        const fab = h('button', { class: 'fab', type: 'button', title: 'Tab detect log', hidden: true }, icon(I.bug), badge);
        root.append(h('div', { class: 'wrap' }, panel, fab));

        const rows = new Map();
        let kindFilter = 'all';
        let toastT = 0;

        function toast(m) {
            snack.textContent = m;
            snack.classList.add('show');
            clearTimeout(toastT);
            toastT = timeout.call(window, () => snack.classList.remove('show'), 1600);
        }

        function legacyCopy(text) {
            const ta = h('textarea', { style: 'position:fixed;top:0;left:0;opacity:0' });
            ta.value = text;
            document.documentElement.append(ta);
            ta.select();
            try { document.execCommand('copy'); toast('Copied'); } catch (err) { toast('Copy failed'); }
            ta.remove();
        }

        function copy(text) {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(() => toast('Copied'), () => legacyCopy(text));
            } else {
                legacyCopy(text);
            }
        }

        function applyFilter() {
            const term = q.value.trim().toLowerCase();
            rows.forEach(r => {
                r.el.hidden = !((kindFilter === 'all' || r.e.kind === kindFilter) && (!term || r.e.search.includes(term)));
            });
        }

        const chipRefs = {};
        [['all', 'All'], ['listener', 'Listeners'], ['property', 'Reads'], ['method', 'Calls'], ['handler', 'Handlers']].forEach(([k, label]) => {
            const n = h('b', { text: '0' });
            const c = h('button', { class: 'fc' + (k === 'all' ? ' on' : ''), type: 'button' }, icon(I.check), label, n);
            chipRefs[k] = { c, n };
            origAdd.call(c, 'click', () => {
                kindFilter = k;
                for (const x in chipRefs) chipRefs[x].c.classList.toggle('on', x === k);
                applyFilter();
            });
            chipsEl.append(c);
        });

        function createRow(e) {
            const cnt = h('span', { class: 'cnt' });
            const tm = h('span');
            const srcEl = h('span', { text: scriptLabel(e) + (e.script && e.script.third ? ' from ' + e.script.host : '') });
            const headBtn = h('button', { class: 'head', type: 'button' },
                h('span', { class: 'chip ' + e.kind, text: KIND_LABEL[e.kind] }),
                h('span', { class: 'txt' },
                    h('span', { class: 'name', text: e.detail }),
                    h('span', { class: 'meta' }, srcEl, tm)),
                cnt,
                h('span', { class: 'chev' }, icon(I.more)));

            const dl = h('dl');
            const add = (k, v, tag) => { if (v) dl.append(h('dt', { text: k }), h('dd', null, v, tag)); };
            add('Page', e.page);
            add('Frame', e.frame);
            add('Target', e.target);
            add('Event', e.type);
            if (e.kind === 'listener' || e.kind === 'handler') add('Listener', e.listenerName || '(anonymous)');
            add('Options', e.opts);
            if (e.script) {
                add('Script', e.script.kind === 'url' ? e.script.url : 'Inline in page HTML',
                    h('span', { class: 'tag' + (e.script.third ? ' tp' : ''), text: e.script.kind === 'inline' ? 'inline' : e.script.third ? '3rd-party' : '1st-party' }));
            }
            add('First seen', fmt(e.first));

            const body = h('div', { class: 'body' }, dl);
            if (e.frames.length) {
                body.append(
                    h('div', { class: 'sec', text: 'Call stack' }),
                    h('ol', null, ...e.frames.map(f => h('li', null,
                        h('span', { class: 'fn', text: f.fn || '(anonymous)' }),
                        h('span', { class: 'loc', title: f.url, text: `${shortUrl(f.url)}:${f.line}:${f.col}` })))));
            }
            if (e.listenerSrc) body.append(h('div', { class: 'sec', text: 'Listener source' }), h('pre', { text: e.listenerSrc }));
            if (e.filters.length) {
                body.append(h('div', { class: 'sec', text: 'uBlock Origin filters' }));
                e.filters.forEach(f => body.append(
                    h('div', { class: 'flt' },
                        h('div', { class: 'ft' }, h('small', { text: f.label }), h('code', { text: f.text })),
                        h('button', { class: 'icon sm', type: 'button', title: 'Copy filter', data: { copy: f.text } }, icon(I.copy)))));
            }
            return { el: h('div', { class: 'row' }, headBtn, body), cnt, tm, e };
        }

        flushUI = function flush() {
            flushTimer = 0;
            const stick = list.scrollHeight - list.scrollTop - list.clientHeight < 48;
            let added = false;
            pending.forEach(e => {
                let r = rows.get(e.id);
                if (!r) {
                    r = createRow(e);
                    rows.set(e.id, r);
                    list.append(r.el);
                    added = true;
                }
                r.cnt.textContent = e.count > 1 ? '×' + e.count : '';
                r.tm.textContent = fmt(e.last);
            });
            pending.clear();
            let total = 0;
            const kc = { all: entries.size, listener: 0, property: 0, method: 0, handler: 0 };
            entries.forEach(e => { total += e.count; kc[e.kind]++; });
            for (const k in chipRefs) chipRefs[k].n.textContent = kc[k];
            stat.textContent = `${entries.size} unique, ${total} hits`;
            badge.textContent = entries.size;
            empty.hidden = entries.size > 0;
            if (added) {
                applyFilter();
                if (stick) list.scrollTop = list.scrollHeight;
            }
        };

        origAdd.call(list, 'click', ev => {
            const cp = ev.target.closest('[data-copy]');
            if (cp) { copy(cp.dataset.copy); return; }
            const hd = ev.target.closest('.head');
            if (hd) hd.parentNode.classList.toggle('open');
        });
        origAdd.call(q, 'input', applyFilter);

        origAdd.call(bClear, 'click', () => {
            entries.clear();
            pending.clear();
            rows.forEach(r => r.el.remove());
            rows.clear();
            flushUI();
        });

        origAdd.call(bCopy, 'click', () => {
            const set = new Set();
            entries.forEach(e => e.filters.forEach(f => { if (f.primary) set.add(f.text); }));
            if (!set.size) { toast('No filters yet'); return; }
            copy(`! Tab Switch Detection Logger: ${HOST}\n${[...set].join('\n')}`);
        });

        origAdd.call(bJson, 'click', () => {
            const data = {
                page: location.href,
                host: HOST,
                frame: IS_TOP ? 'top' : 'iframe',
                userAgent: navigator.userAgent,
                generated: new Date().toISOString(),
                entries: [...entries.values()].map(e => {
                    const c = Object.assign({}, e);
                    delete c.search;
                    return c;
                })
            };
            const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
            const a = h('a', { href: url, download: `tab-detect-${HOST || 'page'}.json` });
            document.documentElement.append(a);
            a.click();
            a.remove();
            timeout.call(window, () => URL.revokeObjectURL(url), 2000);
            toast('Exported');
        });

        function keepInView() {
            if (!host.style.left) return;
            const r = host.getBoundingClientRect();
            host.style.left = Math.min(Math.max(8, r.left), Math.max(8, window.innerWidth - r.width - 8)) + 'px';
            host.style.top = Math.min(Math.max(8, r.top), Math.max(8, window.innerHeight - r.height - 8)) + 'px';
        }

        function setOpen(o) {
            panel.hidden = !o;
            fab.hidden = o;
            keepInView();
        }

        origAdd.call(bMin, 'click', () => setOpen(false));
        origAdd.call(fab, 'click', () => setOpen(true));
        origAdd.call(window, 'resize', keepInView);

        let drag = null;
        origAdd.call(head, 'pointerdown', ev => {
            if (ev.target.closest('button')) return;
            const r = host.getBoundingClientRect();
            drag = { dx: ev.clientX - r.left, dy: ev.clientY - r.top };
            head.setPointerCapture(ev.pointerId);
        });
        origAdd.call(head, 'pointermove', ev => {
            if (!drag) return;
            host.style.left = (ev.clientX - drag.dx) + 'px';
            host.style.top = (ev.clientY - drag.dy) + 'px';
            host.style.right = 'auto';
            host.style.bottom = 'auto';
        });
        origAdd.call(head, 'pointerup', () => { drag = null; keepInView(); });

        document.documentElement.append(host);
        flushUI();
    }

    if (document.readyState === 'loading') {
        origAdd.call(document, 'DOMContentLoaded', buildUI, { once: true });
    } else {
        buildUI();
    }
})();
