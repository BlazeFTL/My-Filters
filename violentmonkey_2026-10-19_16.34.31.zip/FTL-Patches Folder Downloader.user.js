// ==UserScript==
// @name         FTL-Patches Folder Downloader
// @namespace    ftl-patches
// @version      1.4.0
// @description  List app folders in FTL-Patches, download patches + extensions as one ZIP with repo structure kept
// @match        https://github.com/BlazeFTL/FTL-Patches
// @match        https://github.com/BlazeFTL/FTL-Patches/*
// @grant        GM_xmlhttpRequest
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @connect      api.github.com
// @connect      raw.githubusercontent.com
// @icon         https://avatars.githubusercontent.com/u/139938337?v=4&size=64
// @run-at       document-idle
// ==/UserScript==

(() => {
  'use strict';

  const OWNER = 'BlazeFTL';
  const REPO = 'FTL-Patches';
  const PATCH_ROOT = 'patches/src/main/kotlin/app/ftl/patches';
  const EXT_ROOT = 'extensions';
  const RES_ROOT = 'patches/src/main/resources';
  const API = `https://api.github.com/repos/${OWNER}/${REPO}`;
  const RAW = `https://raw.githubusercontent.com/${OWNER}/${REPO}`;
  const CONCURRENCY = 8;
  const EXT_ALIASES = {
    addsavedata: ['addsave', 'toast'],
    customdpi: ['dpi'],
    spoofsignature: ['signature'],
  };

  const enc = s => s.split('/').map(encodeURIComponent).join('/');
  const cache = {};
  let defaultBranch = '';
  let branches = [];
  let loadedRef = '';
  let manual = false;
  let busy = false;
  let apps = [];
  let exts = [];
  let paths = [];

  GM_registerMenuCommand('Set GitHub token', () => {
    const v = prompt('GitHub token (blank to clear)', GM_getValue('token', ''));
    if (v !== null) GM_setValue('token', v.trim());
  });

  const req = (url, json) =>
    new Promise((resolve, reject) => {
      const headers = { Accept: json ? 'application/vnd.github+json' : '*/*' };
      const token = GM_getValue('token', '');
      if (token) headers.Authorization = `token ${token}`;
      GM_xmlhttpRequest({
        method: 'GET',
        url,
        headers,
        responseType: json ? 'text' : 'arraybuffer',
        onload: r => {
          if (r.status < 200 || r.status >= 300) {
            reject(new Error(`HTTP ${r.status}: ${url}`));
            return;
          }
          resolve(json ? JSON.parse(r.responseText) : r.response);
        },
        onerror: () => reject(new Error(`Network error: ${url}`)),
        ontimeout: () => reject(new Error(`Timeout: ${url}`)),
      });
    });

  const host = document.createElement('div');
  host.id = 'ftl-dl-host';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `
<style>
:host{all:initial}
*{box-sizing:border-box;font:13px/1.4 system-ui,sans-serif}
.panel{--bg:#fff;--fg:#1f2328;--bd:#d0d7de;--hl:#ddf4ff;--in:#f6f8fa;--ac:#8250df;--ex:#f6f0ff}
@media (prefers-color-scheme:dark){.panel{--bg:#161b22;--fg:#e6edf3;--bd:#30363d;--hl:#0c2d4d;--in:#0d1117;--ac:#a371f7;--ex:#21173a}}
.fab{position:fixed;left:14px;top:0;z-index:2147483647;width:46px;height:46px;border-radius:50%;border:0;background:#238636;color:#fff;font-weight:700;box-shadow:0 2px 8px #0006;touch-action:none;user-select:none;-webkit-user-select:none;cursor:grab}
.panel{position:fixed;left:10px;top:10px;z-index:2147483647;width:min(94vw,380px);max-height:72vh;display:none;flex-direction:column;gap:8px;padding:10px;border-radius:10px;background:var(--bg);color:var(--fg);border:1px solid var(--bd);box-shadow:0 6px 24px #0006}
.panel.open{display:flex}
.bar{display:flex;flex-wrap:wrap;gap:8px 10px;align-items:center}
.bar label{display:flex;gap:4px;align-items:center;white-space:nowrap}
input[type=text],select{width:100%;padding:6px 8px;border-radius:6px;border:1px solid var(--bd);background:var(--in);color:var(--fg)}
select{flex:1;min-width:0;width:auto}
.rescan{border:1px solid var(--bd);border-radius:6px;background:var(--in);color:var(--fg);padding:6px 10px}
.st{opacity:.75;font-size:12px;word-break:break-word}
.list{overflow:auto;flex:1;min-height:80px}
.row{display:flex;align-items:center;gap:8px;padding:6px 4px;border-bottom:1px solid var(--bd)}
.row.ext{border:1px solid var(--ac);border-radius:8px;margin:4px 0 6px;background:var(--ex)}
.row.ext .tag{border-color:var(--ac);color:var(--ac);opacity:1}
.plus{opacity:.6;font-weight:700}
.tag.x{border-color:var(--ac);color:var(--ac);opacity:1}
.row.cur{background:var(--hl)}
.name{flex:1;word-break:break-all;font-weight:600}
.tag{font-size:11px;opacity:.7;border:1px solid var(--bd);border-radius:10px;padding:0 6px}
.row button{border:0;border-radius:6px;background:#238636;color:#fff;padding:6px 10px}
.busy .row button{opacity:.5;pointer-events:none}
</style>
<button class="fab">ZIP</button>
<div class="panel">
  <div class="bar">
    <select class="br"></select>
    <button class="rescan" title="Rescan">&#8635;</button>
    <label><input type="checkbox" class="cp">Patch</label>
    <label><input type="checkbox" class="ce">Ext</label>
  </div>
  <input type="text" class="q" placeholder="Search folder">
  <div class="st"></div>
  <div class="list"></div>
</div>`;

  const $ = s => root.querySelector(s);
  const fab = $('.fab');
  const panel = $('.panel');
  const branchSel = $('.br');
  const rescan = $('.rescan');
  const chkPatch = $('.cp');
  const chkExt = $('.ce');
  const search = $('.q');
  const stEl = $('.st');
  const list = $('.list');

  chkPatch.checked = GM_getValue('patch', true);
  chkExt.checked = GM_getValue('ext', true);
  chkPatch.onchange = () => GM_setValue('patch', chkPatch.checked);
  chkExt.onchange = () => GM_setValue('ext', chkExt.checked);

  const status = t => {
    stEl.textContent = t;
  };

  const setBusy = v => {
    busy = v;
    panel.classList.toggle('busy', v);
  };

  const pageRef = () => {
    const m = location.pathname.match(/^\/[^/]+\/[^/]+\/(?:tree|blob)\/([^/]+)/);
    return m ? decodeURIComponent(m[1]) : '';
  };

  const context = () => {
    const m = location.pathname.match(new RegExp(`^/${OWNER}/${REPO}/(?:tree|blob)/[^/]+/(.+)$`, 'i'));
    if (!m) return null;
    const rest = decodeURIComponent(m[1]);
    if (rest.startsWith(`${PATCH_ROOT}/`)) return { kind: 'app', name: rest.slice(PATCH_ROOT.length + 1).split('/')[0] };
    if (rest.startsWith(`${EXT_ROOT}/`)) return { kind: 'ext', name: rest.slice(EXT_ROOT.length + 1).split('/')[0] };
    return null;
  };

  const topDirs = rootPath => {
    const prefix = `${rootPath}/`;
    const set = new Set();
    for (const p of paths) {
      if (!p.startsWith(prefix)) continue;
      const parts = p.slice(prefix.length).split('/');
      if (parts.length > 1) set.add(parts[0]);
    }
    return [...set].sort((a, b) => a.toLowerCase().localeCompare(b.toLowerCase()));
  };

  const extsFor = name => {
    const lower = name.toLowerCase();
    const set = new Set();
    const same = exts.find(e => e.toLowerCase() === lower);
    if (same) set.add(same);
    for (const e of EXT_ALIASES[lower] || []) set.add(e);
    return [...set].filter(e => exts.includes(e));
  };

  const render = () => {
    const q = search.value.trim().toLowerCase();
    const ctx = context();
    const used = new Set();
    const items = apps.map(name => {
      const extList = extsFor(name);
      extList.forEach(e => used.add(e));
      return { kind: 'app', name, extList };
    });
    for (const e of exts) if (!used.has(e)) items.push({ kind: 'ext', name: e, extList: [] });
    const isCtx = i => !!ctx && ((ctx.kind === i.kind && ctx.name === i.name) || (ctx.kind === 'ext' && i.extList.includes(ctx.name)));
    const shown = items.filter(i => i.name.toLowerCase().includes(q) || i.extList.some(e => e.toLowerCase().includes(q)));
    shown.sort((a, b) => (isCtx(b) ? 1 : 0) - (isCtx(a) ? 1 : 0));
    list.replaceChildren(
      ...shown.map(i => {
        const row = document.createElement('div');
        row.className = `row${i.kind === 'ext' ? ' ext' : ''}${isCtx(i) ? ' cur' : ''}`;
        const name = document.createElement('span');
        name.className = 'name';
        name.textContent = i.name;
        name.title =
          i.kind === 'app'
            ? [`${PATCH_ROOT}/${i.name}`, ...i.extList.map(e => `${EXT_ROOT}/${e}`)].join('\n')
            : `${EXT_ROOT}/${i.name}`;
        const tag = document.createElement('span');
        tag.className = 'tag';
        tag.textContent = i.kind === 'app' ? 'patch' : 'ext';
        row.append(name, tag);
        if (i.extList.length) {
          const plus = document.createElement('span');
          plus.className = 'plus';
          plus.textContent = '+';
          const extTag = document.createElement('span');
          extTag.className = 'tag x';
          extTag.textContent = i.extList.length > 1 ? `ext \u00d7${i.extList.length}` : 'ext';
          extTag.title = i.extList.join(', ');
          row.append(plus, extTag);
        }
        const btn = document.createElement('button');
        btn.textContent = 'Download';
        btn.onclick = () => run(i.kind, i.name);
        row.append(btn);
        return row;
      })
    );
  };

  const fillBranches = selected => {
    const names = !selected || branches.includes(selected) ? branches : [selected, ...branches];
    branchSel.replaceChildren(
      ...names.map(n => {
        const o = document.createElement('option');
        o.value = n;
        o.textContent = n === defaultBranch ? `${n} (default)` : n;
        return o;
      })
    );
    if (selected) branchSel.value = selected;
  };

  const loadBranches = async () => {
    if (branches.length) return;
    defaultBranch = (await req(API, true)).default_branch;
    const out = [];
    for (let page = 1; page <= 5; page++) {
      const b = await req(`${API}/branches?per_page=100&page=${page}`, true);
      out.push(...b.map(x => x.name));
      if (b.length < 100) break;
    }
    out.sort((a, b) => (b === defaultBranch) - (a === defaultBranch) || a.localeCompare(b));
    branches = out;
  };

  const summary = () => `${apps.length} apps, ${exts.length} extensions`;

  const load = async force => {
    try {
      const ref = branchSel.value;
      if (!ref) return;
      status(`Scanning ${ref}...`);
      if (force) delete cache[ref];
      if (!cache[ref]) {
        const d = await req(`${API}/git/trees/${encodeURIComponent(ref)}?recursive=1`, true);
        cache[ref] = d.tree.filter(e => e.type === 'blob').map(e => e.path);
      }
      if (ref !== branchSel.value) return;
      paths = cache[ref];
      loadedRef = ref;
      apps = topDirs(PATCH_ROOT);
      exts = topDirs(EXT_ROOT);
      status(`${ref}: ${summary()}`);
      render();
    } catch (e) {
      status(e.message);
    }
  };

  const fetchFiles = async (files, ref, label, onFile) => {
    let i = 0;
    let done = 0;
    const worker = async () => {
      while (i < files.length) {
        const p = files[i++];
        const buf = await req(`${RAW}/${enc(ref)}/${enc(p)}`);
        onFile(p, buf);
        status(`${label} ${++done}/${files.length}`);
      }
    };
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, files.length) }, worker));
  };

  const crcTable = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();

  const crc32 = u8 => {
    let c = 0xffffffff;
    for (let i = 0; i < u8.length; i++) c = crcTable[(c ^ u8[i]) & 0xff] ^ (c >>> 8);
    return (c ^ 0xffffffff) >>> 0;
  };

  const buildZip = files => {
    const te = new TextEncoder();
    const d = new Date();
    const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    const local = [];
    const central = [];
    let offset = 0;
    let cdSize = 0;
    for (const [path, data] of files) {
      const name = te.encode(path);
      const crc = crc32(data);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true);
      lh.setUint16(4, 20, true);
      lh.setUint16(6, 0x0800, true);
      lh.setUint16(8, 0, true);
      lh.setUint16(10, time, true);
      lh.setUint16(12, date, true);
      lh.setUint32(14, crc, true);
      lh.setUint32(18, data.length, true);
      lh.setUint32(22, data.length, true);
      lh.setUint16(26, name.length, true);
      lh.setUint16(28, 0, true);
      local.push(lh.buffer, name, data);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true);
      ch.setUint16(4, 20, true);
      ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x0800, true);
      ch.setUint16(10, 0, true);
      ch.setUint16(12, time, true);
      ch.setUint16(14, date, true);
      ch.setUint32(16, crc, true);
      ch.setUint32(20, data.length, true);
      ch.setUint32(24, data.length, true);
      ch.setUint16(28, name.length, true);
      ch.setUint16(30, 0, true);
      ch.setUint16(32, 0, true);
      ch.setUint16(34, 0, true);
      ch.setUint16(36, 0, true);
      ch.setUint32(38, 0, true);
      ch.setUint32(42, offset, true);
      central.push(ch.buffer, name);
      offset += 30 + name.length + data.length;
      cdSize += 46 + name.length;
    }
    const end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true);
    end.setUint16(8, files.size, true);
    end.setUint16(10, files.size, true);
    end.setUint32(12, cdSize, true);
    end.setUint32(16, offset, true);
    return new Blob([...local, ...central, end.buffer], { type: 'application/zip' });
  };

  const save = (blob, filename) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  };

  const run = async (kind, name) => {
    if (busy) return;
    const wantPatch = chkPatch.checked;
    const wantExt = chkExt.checked;
    if (kind === 'app' && !wantPatch && !wantExt) {
      status('Tick Patch and/or Ext');
      return;
    }
    setBusy(true);
    try {
      const ref = loadedRef;
      const decoder = new TextDecoder();
      const extNames = new Set(kind === 'app' ? extsFor(name) : []);
      const files = new Map();
      const put = (p, b) => {
        files.set(p, new Uint8Array(b));
      };

      if (kind === 'app') {
        const patchFiles = paths.filter(p => p.startsWith(`${PATCH_ROOT}/${name}/`));
        await fetchFiles(patchFiles, ref, `${name} patch`, (p, b) => {
          if (wantPatch) put(p, b);
          if (p.endsWith('.kt')) {
            for (const m of decoder.decode(b).matchAll(/extendWith\(\s*"extensions\/([^"]+?)\.mpe"\s*\)/g)) extNames.add(m[1]);
          }
        });
        if (wantPatch) {
          const resFiles = paths.filter(
            p => p.startsWith(`${RES_ROOT}/`) && p.slice(RES_ROOT.length + 1).split('/').length > 1 && p.slice(RES_ROOT.length + 1).split('/')[0].toLowerCase() === name.toLowerCase()
          );
          await fetchFiles(resFiles, ref, `${name} resources`, put);
        }
        if (wantExt) {
          for (const e of extNames) {
            const extFiles = paths.filter(p => p.startsWith(`${EXT_ROOT}/${e}/`));
            await fetchFiles(extFiles, ref, `${e} ext`, put);
          }
        }
      } else {
        const extFiles = paths.filter(p => p.startsWith(`${EXT_ROOT}/${name}/`));
        await fetchFiles(extFiles, ref, `${name} ext`, put);
      }

      if (!files.size) {
        status('Nothing found');
        return;
      }
      status('Zipping...');
      const blob = buildZip(files);
      save(blob, kind === 'app' ? `${name}.zip` : `${name}-extension.zip`);
      const extInfo = kind === 'app' && wantExt ? ` | ext: ${extNames.size ? [...extNames].join(', ') : 'none'}` : '';
      status(`Done: ${files.size} files${extInfo}`);
    } catch (e) {
      status(e.message);
    } finally {
      setBusy(false);
    }
  };

  const openPanel = async () => {
    try {
      status('Loading branches...');
      await loadBranches();
      const want = manual ? branchSel.value : pageRef() || branchSel.value || defaultBranch;
      fillBranches(want);
      if (loadedRef !== want) {
        await load(false);
      } else {
        status(`${want}: ${summary()}`);
        render();
      }
    } catch (e) {
      status(e.message);
    }
  };

  const FAB = 46;
  const clampPos = (x, y) => [
    Math.min(Math.max(0, x), window.innerWidth - FAB),
    Math.min(Math.max(0, y), window.innerHeight - FAB),
  ];

  const placePanel = () => {
    const r = fab.getBoundingClientRect();
    const pw = panel.offsetWidth || Math.min(window.innerWidth * 0.94, 380);
    const left = Math.max(8, Math.min(r.left, window.innerWidth - pw - 8));
    panel.style.left = `${left}px`;
    if (r.top > window.innerHeight / 2) {
      panel.style.top = 'auto';
      panel.style.bottom = `${window.innerHeight - r.top + 8}px`;
      panel.style.maxHeight = `${Math.min(window.innerHeight * 0.72, r.top - 16)}px`;
    } else {
      panel.style.bottom = 'auto';
      panel.style.top = `${r.bottom + 8}px`;
      panel.style.maxHeight = `${Math.min(window.innerHeight * 0.72, window.innerHeight - r.bottom - 16)}px`;
    }
  };

  const setPos = (x, y, persist) => {
    const [cx, cy] = clampPos(x, y);
    fab.style.left = `${cx}px`;
    fab.style.top = `${cy}px`;
    if (persist) GM_setValue('pos', { x: cx, y: cy });
    if (panel.classList.contains('open')) placePanel();
  };

  const togglePanel = () => {
    if (panel.classList.toggle('open')) {
      placePanel();
      openPanel();
    }
  };

  const saved = GM_getValue('pos', null);
  setPos(saved ? saved.x : 14, saved ? saved.y : window.innerHeight - FAB - 14, false);
  window.addEventListener('resize', () => setPos(parseFloat(fab.style.left), parseFloat(fab.style.top), false));

  let drag = null;
  fab.addEventListener('pointerdown', e => {
    drag = { sx: e.clientX, sy: e.clientY, ox: parseFloat(fab.style.left), oy: parseFloat(fab.style.top), moved: false };
    if (fab.setPointerCapture) fab.setPointerCapture(e.pointerId);
  });
  fab.addEventListener('pointermove', e => {
    if (!drag) return;
    const dx = e.clientX - drag.sx;
    const dy = e.clientY - drag.sy;
    if (!drag.moved && Math.hypot(dx, dy) < 6) return;
    drag.moved = true;
    setPos(drag.ox + dx, drag.oy + dy, false);
  });
  const endDrag = e => {
    if (!drag) return;
    const d = drag;
    drag = null;
    if (d.moved) setPos(parseFloat(fab.style.left), parseFloat(fab.style.top), true);
    else if (e.type === 'pointerup') togglePanel();
  };
  fab.addEventListener('pointerup', endDrag);
  fab.addEventListener('pointercancel', endDrag);
  fab.addEventListener('contextmenu', e => e.preventDefault());

  branchSel.onchange = () => {
    manual = true;
    load(true);
  };
  rescan.onclick = () => load(true);
  search.oninput = render;

  const mount = () => {
    const inRepo = location.pathname.toLowerCase().startsWith(`/${OWNER}/${REPO}`.toLowerCase());
    if (!inRepo) {
      host.remove();
      return;
    }
    if (!host.isConnected) document.documentElement.appendChild(host);
  };

  const onNav = () => {
    mount();
    if (panel.classList.contains('open') && loadedRef) render();
  };

  ['turbo:load', 'turbo:render', 'pjax:end', 'popstate'].forEach(e => document.addEventListener(e, onNav));
  new MutationObserver(mount).observe(document.documentElement, { childList: true });
  mount();
})();
