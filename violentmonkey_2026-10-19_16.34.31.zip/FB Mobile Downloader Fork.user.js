// ==UserScript==
// @name        FB Mobile Downloader Fork
// @namespace   ftl.fb-mobile-downloader
// @version     1.4.6
// @description Download photos, videos, reels and stories on Facebook mobile. Works without page injection.
// @match       https://m.facebook.com/*
// @match       https://mobile.facebook.com/*
// @match       https://www.facebook.com/*
// @match       https://web.facebook.com/*
// @exclude     https://www.facebook.com/plugins/*
// @exclude     https://web.facebook.com/plugins/*
// @run-at      document-start
// @inject-into content
// @noframes
// @grant       GM_getValue
// @grant       GM_setValue
// @grant       GM_registerMenuCommand
// @grant       GM_download
// @grant       GM_openInTab
// @grant       GM_xmlhttpRequest
// @grant       GM_setClipboard
// @grant       unsafeWindow
// @connect     facebook.com
// @connect     fbcdn.net
// @connect     fbsbx.com
// @icon        https://www.facebook.com/favicon.ico
// ==/UserScript==

(() => {
  "use strict";
  if (globalThis.__fbMobileDownloader) return;
  globalThis.__fbMobileDownloader = true;

  const pageWin = typeof unsafeWindow !== "undefined" && unsafeWindow ? unsafeWindow : window;
  const doc = document;
  const FLOATING = "data-fbmd";
  const MIN = 150;
  const LOOK_UP = 14;
  const OWN_LAYER = 24;
  const TOP_BAR = 56;
  const BOTTOM_BAR = 60;
  const TIMEOUT = 6e5;
  const STALL = 25e3;
  const MAX_ITEMS = 4e3;
  const MAX_BUTTONS = 3;
  const RETRY_MS = 15e3;
  const POST = '[aria-posinset], [role="article"], article';
  const QUALITIES = ["best", "max", "sd", "ask"];
  const QUALITY_NAMES = { best: "Best single file (HD)", max: "Highest available (merged)", sd: "Smaller file (SD)", ask: "Ask every time" };
  const DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/130.0";
  const MARKERS = ['"progressive_url"', '"playable_url', '"browser_native_', '"viewer_image"', '"photo_image"', '"image":{"uri"', '"story_card_info"', '"dash_manifest'];
  const DOWNLOAD_ICON = "M12 4v11m0 0l-4.5-4.5M12 15l4.5-4.5M5 19h14";
  const SPINNER_ICON = "M12 3a9 9 0 1 0 9 9";
  const CHECK_ICON = "M5 12.5l4.5 4.5L19 7.5";

  const read = (key, fallback) => {
    try {
      return typeof GM_getValue === "function" ? GM_getValue(key, fallback) : fallback;
    } catch {
      return fallback;
    }
  };
  const write = (key, value) => {
    try {
      if (typeof GM_setValue === "function") GM_setValue(key, value);
    } catch {}
  };
  const clamp01 = (n) => Math.min(1, Math.max(0, n));
  const DEFAULT_POS = { x: 1, y: 0 };
  const loadPos = () => {
    try {
      const p = JSON.parse(read("pos", ""));
      if (Number.isFinite(p?.x) && Number.isFinite(p?.y)) return { x: clamp01(p.x), y: clamp01(p.y) };
    } catch {}
    const legacy = { tr: [1, 0], tl: [0, 0], br: [1, 1], bl: [0, 1] }[read("corner", "tr")];
    return legacy ? { x: legacy[0], y: legacy[1] } : { ...DEFAULT_POS };
  };
  const prefs = {
    pos: loadPos(),
    quality: QUALITIES.includes(read("quality", "best")) ? read("quality", "best") : "best",
    enabled: read("enabled", true) !== false,
    hook: read("hook", true) !== false
  };
  const stats = { saved: 0, failed: 0, hook: false, ever: false, parses: 0, hits: 0 };

  const isObject = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
  const pathOnly = (url) => {
    try {
      return new URL(url).pathname;
    } catch {
      return null;
    }
  };
  const isUrl = (value) => typeof value === "string" && /^https:\/\//.test(value);
  const normalizeText = (value) => String(value ?? "").replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF\uE000-\uF8FF]/g, "").replace(/[\p{Co}\p{Cn}\p{Cs}]/gu, "").replace(/\u00A0/g, " ").replace(/\s+/g, " ").trim();
  const describe = (value) => (value && typeof value === "object" ? JSON.stringify(value) : String(value ?? ""));
  const keyOf = (found) => (found.cardId ? `c:${found.cardId}` : found.id ? `i:${found.id}` : null);
  const fmtSize = (n) => (n >= 1073741824 ? `${(n / 1073741824).toFixed(2)} GB` : n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

  function extensionOf(url, fallback) {
    try {
      const parsed = new URL(url);
      const found = parsed.searchParams.get("stp")?.match(/(?:^|_)dst-(jpe?g|png|webp|gif)/i) ?? parsed.pathname.match(/\.(mp4|m4v|m4a|webm|jpe?g|png|gif|webp|heic)$/i);
      return found ? found[1].toLowerCase().replace("jpeg", "jpg") : fallback;
    } catch {
      return fallback;
    }
  }

  function walk(root, visit) {
    const stack = [root];
    while (stack.length) {
      const value = stack.pop();
      if (value === null || typeof value !== "object") continue;
      visit(value);
      if (Array.isArray(value)) {
        for (let i = value.length - 1; i >= 0; i--) stack.push(value[i]);
      } else {
        for (const key in value) stack.push(value[key]);
      }
    }
  }

  const LEGACY_VIDEO = [
    ["playable_url_quality_hd", "HD"],
    ["browser_native_hd_url", "HD"],
    ["playable_url", "SD"],
    ["browser_native_sd_url", "SD"]
  ];
  const PHOTO_IMAGES = ["viewer_image", "image", "photo_image", "previewImage", "large_image"];
  const decodeXml = (text) => text.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");

  const isAvc = (codecs) => /^avc/i.test(codecs);
  const isHevc = (codecs) => /^(hvc|hev)/i.test(codecs);
  const codecName = (codecs) => (isAvc(codecs) ? "H.264" : isHevc(codecs) ? "H.265" : /^av0?1/i.test(codecs) ? "AV1" : /^vp0?9/i.test(codecs) ? "VP9" : "");

  function dashTracks(video) {
    const result = video?.videoDeliveryResponseFragment?.videoDeliveryResponseResult;
    const manifests = Array.isArray(result?.dash_manifests) ? result.dash_manifests : [];
    const xmls = manifests.map((m) => m?.manifest_xml).filter((x) => typeof x === "string");
    if (typeof video?.dash_manifest === "string") xmls.push(video.dash_manifest);
    const reps = [];
    for (const xml of xmls) {
      for (const set of xml.match(/<AdaptationSet[\s\S]*?<\/AdaptationSet>/g) ?? []) {
        const head = set.slice(0, set.indexOf(">") + 1);
        for (const rep of set.match(/<Representation\b[\s\S]*?<\/Representation>/g) ?? []) {
          const open = rep.slice(0, rep.indexOf(">") + 1);
          const type = /audio/i.test(open) ? "audio" : /video/i.test(open) ? "video" : /audio/i.test(head) ? "audio" : /video/i.test(head) ? "video" : null;
          const base = rep.match(/<BaseURL>([^<]+)<\/BaseURL>/)?.[1];
          const url = base ? decodeXml(base.trim()) : null;
          if (type && isUrl(url)) {
            reps.push({
              type,
              url,
              bandwidth: Number(open.match(/bandwidth="(\d+)"/)?.[1]) || 0,
              height: Number(open.match(/\bheight="(\d+)"/)?.[1]) || Number(open.match(/FBQualityLabel="(\d+)/)?.[1]) || 0,
              codecs: open.match(/codecs="([^"]+)"/)?.[1] ?? head.match(/codecs="([^"]+)"/)?.[1] ?? ""
            });
          }
        }
      }
    }
    for (const manifest of manifests) {
      for (const rep of Array.isArray(manifest?.representations) ? manifest.representations : []) {
        const mime = String(rep?.mime_type ?? "");
        const type = mime.startsWith("audio") ? "audio" : mime.startsWith("video") ? "video" : null;
        if (type && isUrl(rep?.base_url)) reps.push({ type, url: rep.base_url, bandwidth: Number(rep.bandwidth) || 0, height: Number(rep.height) || 0, codecs: String(rep.codecs ?? "") });
      }
    }
    const rank = (r) => (isAvc(r.codecs) ? 3e12 : isHevc(r.codecs) ? 2e12 : /^mp4a/i.test(r.codecs) ? 1e12 : 0) + r.bandwidth;
    const allVideo = reps.filter((x) => x.type === "video");
    const compatible = allVideo.filter((x) => isAvc(x.codecs) || isHevc(x.codecs));
    const byHeight = new Map();
    for (const r of compatible.length ? compatible : allVideo) {
      const key = r.height || `bw${r.bandwidth}`;
      const old = byHeight.get(key);
      if (!old || rank(r) > rank(old)) byHeight.set(key, r);
    }
    const videos = [...byHeight.values()].sort((a, b) => b.height - a.height || b.bandwidth - a.bandwidth);
    const audio = reps.filter((x) => x.type === "audio").sort((a, b) => rank(b) - rank(a))[0] ?? null;
    return videos.length ? { videos, audio } : null;
  }

  function videoFiles(video) {
    const result = video?.videoDeliveryResponseFragment?.videoDeliveryResponseResult;
    const files = [];
    const seen = new Set();
    const add = (url, quality) => {
      if (!isUrl(url) || seen.has(url)) return;
      seen.add(url);
      files.push({ url, quality });
    };
    for (const entry of Array.isArray(result?.progressive_urls) ? result.progressive_urls : []) {
      if (entry?.failure_reason) continue;
      add(entry?.progressive_url, entry?.metadata?.quality === "HD" ? "HD" : "SD");
    }
    for (const source of [video, video?.videoDeliveryLegacyFields]) {
      for (const [key, quality] of LEGACY_VIDEO) add(source?.[key], quality);
    }
    files.sort((a, b) => (a.quality === b.quality ? 0 : a.quality === "HD" ? -1 : 1));
    const tracks = dashTracks(video);
    const dash = Boolean(tracks || result?.dash_manifests?.length || result?.dash_manifest_urls?.length || result?.hls_playlist_urls?.length || video?.dash_manifest || video?.playlist);
    return { files, dash, tracks };
  }

  function mergeFiles(a, b) {
    const seen = new Set();
    const out = [];
    for (const file of [...a, ...b]) {
      if (seen.has(file.url)) continue;
      seen.add(file.url);
      out.push(file);
    }
    out.sort((x, y) => (x.quality === y.quality ? 0 : x.quality === "HD" ? -1 : 1));
    return out;
  }

  function photoFile(photo) {
    let best = null;
    for (const key of PHOTO_IMAGES) {
      const image = photo?.[key];
      if (!isObject(image) || !isUrl(image.uri)) continue;
      const width = Number(image.width) || 0;
      const height = Number(image.height) || 0;
      if (!best || width * height > best.width * best.height) best = { url: image.uri, width, height };
    }
    return best;
  }

  function createMediaIndex(max = MAX_ITEMS) {
    const items = new Map();
    const cards = new Map();
    const owners = new Map();
    const put = (map, key, value) => {
      map.delete(key);
      map.set(key, value);
      if (map.size > max) map.delete(map.keys().next().value);
    };
    function record(value) {
      const id = typeof value.id === "string" ? value.id : null;
      if (id && value.__typename === "Video") {
        const { files, dash, tracks } = videoFiles(value);
        const old = items.get(id);
        const prev = old?.kind === "video" ? old : null;
        if (files.length || dash) {
          put(items, id, {
            kind: "video",
            id,
            files: prev && prev.files.length > files.length ? prev.files : files,
            dash: dash || Boolean(prev?.dash),
            tracks: tracks ?? prev?.tracks ?? null,
            width: Number(value.original_width ?? value.width) || null,
            height: Number(value.original_height ?? value.height) || null
          });
        }
      } else if (id && value.__typename === "Photo") {
        const file = photoFile(value);
        const old = items.get(id);
        if (file && old?.kind !== "video" && !(old?.kind === "photo" && old.width * old.height >= file.width * file.height)) {
          put(items, id, { kind: "photo", id, ...file });
        }
      }
      if (id && "story_card_info" in value && Array.isArray(value.attachments)) {
        const media = value.attachments.map((attachment) => attachment?.media).find((m) => typeof m?.id === "string");
        if (media) put(cards, id, media.id);
      }
      const owner = value.story_bucket_owner?.name;
      if (typeof owner === "string" && Array.isArray(value.unified_stories_with_notes?.edges)) {
        for (const edge of value.unified_stories_with_notes.edges) {
          if (typeof edge?.node?.id === "string") put(owners, edge.node.id, owner);
        }
      }
    }
    return {
      scan(data) {
        walk(data, (value) => {
          if (!Array.isArray(value)) record(value);
        });
      },
      get: (id) => (id === null || id === undefined ? null : items.get(String(id)) ?? null),
      card(cardId) {
        const item = items.get(cards.get(cardId));
        return item ? { ...item, author: owners.get(cardId) ?? null } : null;
      },
      byUrl(url) {
        const path = pathOnly(url);
        if (!path) return null;
        for (const item of items.values()) {
          if (item.kind !== "video") continue;
          if (item.files.some((f) => pathOnly(f.url) === path) || item.tracks?.videos.some((t) => pathOnly(t.url) === path)) return item;
        }
        return null;
      },
      add: (item) => put(items, item.id, item),
      forget: (id) => items.delete(String(id)),
      size: () => items.size
    };
  }

  const index = createMediaIndex();

  function ingestJsonText(text) {
    if (typeof text !== "string" || text.length < 40 || !MARKERS.some((marker) => text.includes(marker))) return true;
    try {
      index.scan(JSON.parse(text));
      return true;
    } catch {
      return false;
    }
  }

  const scriptTries = new WeakMap();
  const scriptDone = new WeakSet();
  function ingestDom() {
    for (const script of doc.querySelectorAll('script[type="application/json"]')) {
      if (scriptDone.has(script)) continue;
      const text = script.textContent;
      if (!text) continue;
      if (ingestJsonText(text)) {
        scriptDone.add(script);
        continue;
      }
      const tries = (scriptTries.get(script) ?? 0) + 1;
      scriptTries.set(script, tries);
      if (tries >= 3) scriptDone.add(script);
    }
  }

  function ingestHtml(html) {
    const pattern = /<script[^>]*type="application\/json"[^>]*>([\s\S]*?)<\/script>/g;
    let match;
    while ((match = pattern.exec(html))) ingestJsonText(match[1]);
  }

  const URL_KEYS = /"(playable_url_quality_hd|browser_native_hd_url|playable_url|browser_native_sd_url|progressive_url)":"(https:[^"]+)"/g;
  function scrapeVideo(html, id) {
    const needles = [`"id":"${id}"`, `"video_id":"${id}"`, `"videoId":"${id}"`, `"videoID":"${id}"`];
    for (const needle of needles) {
      let from = 0;
      for (let hit = 0; hit < 6; hit++) {
        const at = html.indexOf(needle, from);
        if (at === -1) break;
        from = at + needle.length;
        for (const slice of [html.slice(at, at + 14e3), html.slice(Math.max(0, at - 4e3), at)]) {
          const files = [];
          const seen = new Set();
          for (const m of slice.matchAll(URL_KEYS)) {
            let url;
            try {
              url = JSON.parse(`"${m[2]}"`);
            } catch {
              continue;
            }
            if (!isUrl(url) || seen.has(url)) continue;
            seen.add(url);
            const near = slice.slice(m.index, m.index + m[0].length + 400).match(/"quality":"(HD|SD)"/)?.[1];
            files.push({ url, quality: /hd/i.test(m[1]) || near === "HD" ? "HD" : "SD" });
          }
          if (files.length) {
            files.sort((a, b) => (a.quality === b.quality ? 0 : a.quality === "HD" ? -1 : 1));
            return files;
          }
        }
      }
    }
    return [];
  }

  let hooked = null;
  function hookJsonParse() {
    if (hooked) return true;
    try {
      const json = pageWin.JSON;
      const original = json?.parse;
      if (typeof original !== "function") return false;
      const wrapper = function (text, reviver) {
        const out = original.call(this, text, reviver);
        try {
          if (typeof text === "string" && text.length > 80) {
            stats.parses++;
            if (out !== null && typeof out === "object" && MARKERS.some((marker) => text.includes(marker))) {
              stats.hits++;
              index.scan(out);
            }
          }
        } catch {}
        return out;
      };
      if (typeof exportFunction === "function") json.parse = exportFunction(wrapper, pageWin);
      else if (pageWin === window) json.parse = wrapper;
      else return false;
      try {
        const probe = json.parse('{"a":1}');
        if (!probe || probe.a !== 1) throw new Error("probe");
      } catch {
        json.parse = original;
        return false;
      }
      hooked = { json, original };
      stats.ever = true;
      return true;
    } catch {
      return false;
    }
  }

  function unhookJsonParse() {
    if (!hooked) return;
    try {
      hooked.json.parse = hooked.original;
    } catch {}
    hooked = null;
  }

  function gmGetText(url, desktop) {
    return new Promise((resolve, reject) => {
      const fail = (status) => reject(Object.assign(new Error(`the server answered ${status}`), { status }));
      if (typeof GM_xmlhttpRequest === "function") {
        const headers = { Accept: "text/html,application/xhtml+xml,application/json" };
        if (desktop) {
          headers["User-Agent"] = DESKTOP_UA;
          headers["Accept-Language"] = "en-US,en;q=0.9";
        }
        GM_xmlhttpRequest({
          method: "GET",
          url,
          timeout: 3e4,
          headers,
          onload: (r) => (r.status >= 200 && r.status < 300 && typeof r.responseText === "string" ? resolve(r.responseText) : fail(r.status)),
          onerror: () => reject(new Error("the page couldn't be fetched")),
          ontimeout: () => reject(new Error("it took too long"))
        });
        return;
      }
      fetch(url, { credentials: "include" }).then((r) => (r.ok ? r.text() : fail(r.status))).then(resolve, reject);
    });
  }

  const sizeCache = new Map();
  function headSize(url) {
    if (sizeCache.has(url)) return sizeCache.get(url);
    const promise = new Promise((resolve) => {
      if (typeof GM_xmlhttpRequest !== "function") return resolve(null);
      const parse = (r) => {
        const headers = String(r?.responseHeaders ?? "");
        const range = headers.match(/^content-range:\s*bytes\s+[\d-]+\/(\d+)/im);
        if (range) return Number(range[1]);
        const length = headers.match(/^content-length:\s*(\d+)/im);
        return length ? Number(length[1]) : null;
      };
      const attempt = (method, headers, next) => {
        const fallback = () => (next ? next() : resolve(null));
        try {
          const req = GM_xmlhttpRequest({
            method,
            url,
            headers,
            anonymous: true,
            timeout: 15e3,
            onprogress: (r) => {
              if (method !== "GET") return;
              const n = parse(r);
              if (n > 0) {
                resolve(n);
                try {
                  req?.abort?.();
                } catch {}
              }
            },
            onload: (r) => {
              const n = r.status >= 200 && r.status < 300 ? parse(r) : null;
              if (n > 0) resolve(n);
              else fallback();
            },
            onerror: fallback,
            ontimeout: fallback
          });
        } catch {
          fallback();
        }
      };
      attempt("HEAD", {}, () => attempt("GET", { Range: "bytes=0-0" }, null));
    });
    sizeCache.set(url, promise);
    return promise;
  }

  const optionSize = (option) => Promise.all(option.parts.map((part) => headSize(part.url))).then((sizes) => (sizes.every((n) => n > 0) ? sizes.reduce((a, b) => a + b, 0) : null));

  function linkTarget(href) {
    const text = String(href ?? "");
    let found = text.match(/\/reels?\/(\d{6,})/);
    if (found) return { kind: "reel", id: found[1] };
    found = text.match(/\/videos\/(?:[^/?#]+\/)?(\d{6,})/) ?? text.match(/\/(?:watch(?:\/live)?|video\.php)\/?\?(?:[^#]*&)?v=(\d{6,})/);
    if (found) return { kind: "video", id: found[1] };
    found = text.match(/\/video_redirect\/?\?(?:[^#]*&)?src=([^&#]+)/);
    if (found) {
      try {
        const url = decodeURIComponent(found[1]);
        if (isUrl(url)) return { kind: "video", id: null, direct: url };
      } catch {}
    }
    found = text.match(/\/photo(?:\.php)?\/?\?(?:[^#]*&)?fbid=(\d{6,})/) ?? text.match(/\/photos\/[^/?#]+\/(\d{6,})/);
    if (found) return { kind: "photo", id: found[1] };
    return null;
  }

  function pageTarget(href) {
    let url;
    try {
      url = new URL(href);
    } catch {
      return null;
    }
    const story = url.pathname.match(/^\/stories\/[^/]+\/([^/?#]+)/);
    if (story) {
      try {
        return { kind: "story", card: decodeURIComponent(story[1]) };
      } catch {
        return { kind: "story", card: story[1] };
      }
    }
    return linkTarget(url.pathname + url.search);
  }

  function overlap(a, b) {
    const w = Math.min(a.right, b.right) - Math.max(a.left, b.left);
    const h = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
    return w > 0 && h > 0 ? w * h : 0;
  }

  function byOverlap(element, list) {
    const box = element.getBoundingClientRect();
    let best = null;
    let area = 0;
    for (const { target, link } of list) {
      const shared = overlap(link.getBoundingClientRect(), box);
      if (shared > area) {
        best = target;
        area = shared;
      }
    }
    return area >= box.width * box.height * 0.3 ? best : null;
  }

  function nearestLink(element, wantPhoto) {
    let node = element.parentElement;
    for (let level = 0; node && level < LOOK_UP; level++, node = node.parentElement) {
      const ids = new Map();
      for (const link of node.querySelectorAll("a[href]")) {
        const target = linkTarget(link.getAttribute("href"));
        if (!target || (target.kind === "photo") !== wantPhoto) continue;
        const key = target.id ?? target.direct;
        if (!ids.has(key)) ids.set(key, { target, link });
      }
      if (ids.size === 1) return [...ids.values()][0].target;
      if (ids.size > 1) return byOverlap(element, [...ids.values()]);
      if (node.matches(POST)) return null;
    }
    return null;
  }

  function authorOf(element) {
    const post = element.closest(POST);
    if (!post) return null;
    const heading = [...post.querySelectorAll("h2, h3, h4")].find((h) => h.closest(POST) === post);
    const name = heading?.querySelector("a, strong, span") ?? heading;
    const text = normalizeText(name?.textContent ?? "");
    return text && text.length <= 80 ? text : null;
  }

  function imageSource(img) {
    let best = null;
    for (const part of (img.getAttribute("srcset") ?? "").split(",")) {
      const [url, size] = part.trim().split(/\s+/);
      const width = Number.parseFloat(size) || 0;
      if (isUrl(url) && (!best || width > best.width)) best = { url, width };
    }
    const direct = best?.url ?? img.currentSrc ?? img.getAttribute("src") ?? null;
    return isUrl(direct) ? direct : null;
  }

  function directVideo(element) {
    for (const value of [element.currentSrc, element.getAttribute("src"), element.querySelector("source")?.getAttribute("src")]) {
      if (isUrl(value)) return { url: value, id: null };
    }
    let node = element;
    for (let level = 0; node && level < 6; level++, node = node.parentElement) {
      const store = node.getAttribute?.("data-store");
      if (!store || !store.includes('"src"')) continue;
      try {
        const data = JSON.parse(store);
        if (isUrl(data?.src)) return { url: data.src, id: typeof data.videoID === "string" ? data.videoID : null };
      } catch {}
    }
    return null;
  }

  function visibleArea(element) {
    const r = element.getBoundingClientRect();
    const w = Math.min(r.right, window.innerWidth) - Math.max(r.left, 0);
    const h = Math.min(r.bottom, window.innerHeight) - Math.max(r.top, 0);
    return { w, h, area: w > 0 && h > 0 ? w * h : 0, rect: r };
  }

  function bestVideo() {
    let best = null;
    let top = 0;
    for (const video of doc.querySelectorAll("video")) {
      const area = visibleArea(video).area * (video.paused ? 1 : 3);
      if (area > top) {
        best = video;
        top = area;
      }
    }
    return best;
  }

  function attrVideoId(element) {
    let node = element;
    for (let level = 0; node && level < 10; level++, node = node.parentElement) {
      const value = node.getAttribute?.("data-video-id");
      if (value && /^\d{6,}$/.test(value)) return value;
    }
    return null;
  }

  const ID_PROP = /^(videoID|videoId|video_id)$/;
  const HOLDER_PROP = /^(video|videoData|media|attachment|story|feedback|node)$/;
  const idLike = (value) => (typeof value === "string" || typeof value === "number") && /^\d{9,20}$/.test(String(value));

  function scanProps(props, level, prefix, out, depth) {
    if (!props || typeof props !== "object" || depth > 2) return;
    let names;
    try {
      names = Object.keys(props).slice(0, 60);
    } catch {
      return;
    }
    for (const name of names) {
      let value;
      try {
        value = props[name];
      } catch {
        continue;
      }
      const path = prefix ? `${prefix}.${name}` : name;
      if (ID_PROP.test(name) && idLike(value)) out.push({ level, path, id: String(value), strong: true });
      else if (depth > 0 && /^(id|__id)$/.test(name) && idLike(value)) out.push({ level, path, id: String(value), strong: /^video/i.test(prefix) });
      else if (value && typeof value === "object" && HOLDER_PROP.test(name)) scanProps(value, level, path, out, depth + 1);
    }
  }

  function reactInfo(element, verbose) {
    const out = { candidates: [], fiber: false, levels: [], error: null };
    try {
      const raw = element.wrappedJSObject ?? element;
      const key = Object.keys(raw).find((k) => /^__react(Fiber|InternalInstance)\$/.test(k));
      if (!key) return out;
      out.fiber = true;
      let fiber = raw[key];
      for (let level = 0; fiber && level < 70; level++, fiber = fiber.return) {
        let props = null;
        try {
          props = fiber.memoizedProps;
        } catch {}
        if (props && typeof props === "object") {
          scanProps(props, level, "", out.candidates, 0);
          if (verbose && level < 16) {
            let type = "";
            try {
              const t = fiber.type;
              type = typeof t === "string" ? t : String(t?.displayName ?? t?.name ?? "");
            } catch {}
            out.levels.push({ level, type: type.slice(0, 40), props: Object.keys(props).slice(0, 14) });
          }
        }
        if (!verbose && out.candidates.some((c) => c.strong)) break;
      }
    } catch (error) {
      out.error = String(error?.message ?? error);
    }
    return out;
  }

  function reactVideoId(element) {
    return reactInfo(element, false).candidates.find((c) => c.strong)?.id ?? null;
  }

  function findMedia(element, href) {
    const tag = element?.tagName;
    if (tag !== "VIDEO" && tag !== "IMG") return null;
    const here = pageTarget(href);
    const fallback = tag === "IMG" ? imageSource(element) : null;
    if (here?.kind === "story") {
      const direct = tag === "VIDEO" ? directVideo(element) : null;
      return { kind: tag === "VIDEO" ? "video" : "photo", label: "story", id: null, cardId: here.card, author: null, fallback, direct: direct?.url ?? null };
    }
    if (tag === "VIDEO") {
      const direct = directVideo(element);
      const page = here && (here.kind === "reel" || here.kind === "video") && element === bestVideo() ? here : null;
      const near = page ? null : nearestLink(element, false);
      const target = page ?? near;
      const reel = (target?.kind ?? here?.kind) === "reel";
      let id = target?.id ?? direct?.id ?? attrVideoId(element) ?? null;
      if (!id && direct?.url) id = index.byUrl(direct.url)?.id ?? null;
      if (!id) id = reactVideoId(element);
      return { kind: "video", label: reel ? "reel" : "video", id, cardId: null, author: authorOf(element), fallback: null, direct: direct?.url ?? target?.direct ?? null };
    }
    let target = linkTarget(element.closest("a[href]")?.getAttribute("href"));
    if (target?.kind !== "photo") target = nearestLink(element, true);
    if (!target && here?.kind === "photo" && !element.closest(POST)) target = here;
    if (target?.kind !== "photo") return null;
    return { kind: "photo", label: "photo", id: target.id, cardId: null, author: authorOf(element), fallback, direct: null };
  }

  const lookup = (found) => (found.cardId ? index.card(found.cardId) : index.get(found.id));

  function hasAny(item) {
    if (item?.kind === "video") return Boolean(item.files.length || item.tracks?.videos.length);
    if (item?.kind === "photo") return Boolean(item.url);
    return false;
  }

  function hasBest(item) {
    if (item?.kind === "video") return item.files.some((f) => f.quality === "HD") || Boolean(item.tracks?.videos.length);
    return hasAny(item);
  }

  const tried = new Map();
  const desktopUrl = (url) => url.replace(/^https:\/\/(?:m|mobile|touch|web)\.facebook\.com/, "https://www.facebook.com");

  function remoteUrls(found) {
    const www = "https://www.facebook.com";
    const urls = [];
    if (found.cardId) {
      urls.push(desktopUrl(location.href), location.href);
    } else if (found.kind === "photo" && found.id) {
      urls.push(`${www}/photo/?fbid=${found.id}`, `${location.origin}/photo/?fbid=${found.id}`);
    } else if (found.id) {
      const watch = `${www}/watch/?v=${found.id}`;
      const reel = `${www}/reel/${found.id}/`;
      urls.push(...(found.label === "reel" ? [reel, watch] : [watch, reel]), `https://m.facebook.com/watch/?v=${found.id}`, `https://m.facebook.com/reel/${found.id}/`);
    }
    return urls;
  }

  async function remote(found) {
    const www = "https://www.facebook.com";
    const urls = remoteUrls(found);
    const pages = await Promise.all(urls.map((url) => gmGetText(url, url.startsWith(www)).then((html) => html, () => null)));
    let reached = false;
    for (const html of pages) {
      if (html === null) continue;
      reached = true;
      ingestHtml(html);
      const item = lookup(found);
      if (hasBest(item)) return true;
      if (found.kind === "video" && found.id) {
        const files = scrapeVideo(html, found.id);
        if (files.length) {
          const cur = lookup(found);
          const prev = cur?.kind === "video" ? cur : null;
          index.add({ kind: "video", id: found.id, files: mergeFiles(prev?.files ?? [], files), dash: Boolean(prev?.dash), tracks: prev?.tracks ?? null, width: prev?.width ?? null, height: prev?.height ?? null });
        }
      }
    }
    return reached;
  }

  async function resolve(found, force, ask) {
    ingestDom();
    let item = lookup(found);
    const key = keyOf(found);
    const wait = ask ? 3e3 : RETRY_MS;
    if (key && (force || (!hasBest(item) && Date.now() - (tried.get(key) ?? 0) > wait))) {
      if (await remote(found)) tried.set(key, Date.now());
      item = lookup(found);
    }
    return item;
  }

  const NAME_BLOCKLIST = /^(open app|search|notifications?|messenger|marketplace|reels?|follow|following|like|likes|comment|comments|share|shares|more|tap to unmute|tap to mute|verified|public|friends|profile picture|settings|menu|options|home|watch|groups?|gaming|video call|mute|unmute|facebook)$/i;

  function isNameLike(txt) {
    if (!txt) return false;
    txt = txt.trim();
    if (txt.length < 2 || txt.length > 50) return false;
    if (NAME_BLOCKLIST.test(txt)) return false;
    if (/^[\d\s+.,KkMm]+$/.test(txt)) return false;
    return true;
  }

  function nameBeside(avatar) {
    const ar = avatar.getBoundingClientRect();
    for (let node = avatar.parentElement; node; node = node.parentElement) {
      let best = null;
      let score = Infinity;
      for (const el of node.querySelectorAll("*")) {
        if (el.children.length > 2) continue;
        let parts = 0;
        for (const c of el.children) if (normalizeText(c.textContent)) parts++;
        if (parts > 1) continue;
        let own = "";
        for (const n of el.childNodes) if (n.nodeType === 3) own += n.textContent;
        if (parts > 0 && normalizeText(own)) continue;
        const text = normalizeText(el.textContent);
        if (!isNameLike(text)) continue;
        const r = el.getBoundingClientRect();
        if (!r.width || !r.height || r.left < ar.right - 4) continue;
        const dy = Math.abs((r.top + r.bottom) / 2 - (ar.top + ar.bottom) / 2);
        if (dy > 24) continue;
        const s = r.left - ar.right + dy * 2;
        if (s < score) {
          score = s;
          best = text;
        }
      }
      if (best) return best;
      if (node === doc.body) break;
    }
    return null;
  }

  const AVATARS = 'img, [role="img"], svg image';
  const squareish = (r) => r.width >= 24 && r.width <= 64 && Math.abs(r.width - r.height) <= 6;

  function profileName(element) {
    const vh = window.innerHeight;
    const links = [...doc.querySelectorAll('a[aria-label^="See owner pro"]')].filter((a) => {
      const r = a.getBoundingClientRect();
      return r.width > 0 && r.height > 0 && r.top < vh && r.bottom > 0 && isNameLike(normalizeText(a.textContent));
    });
    if (links.length) {
      let pool = links;
      for (let node = element?.parentElement, level = 0; node && level < 14; level++, node = node.parentElement) {
        const inside = links.filter((a) => node.contains(a));
        if (inside.length) {
          pool = inside;
          break;
        }
      }
      const box = element?.getBoundingClientRect();
      const cy = box ? (box.top + box.bottom) / 2 : vh / 2;
      const gap = (a) => {
        const r = a.getBoundingClientRect();
        return Math.abs((r.top + r.bottom) / 2 - cy);
      };
      pool.sort((a, b) => gap(a) - gap(b));
      return normalizeText(pool[0].textContent);
    }
    for (const el of doc.querySelectorAll(AVATARS)) {
      const r = el.getBoundingClientRect();
      if (!squareish(r) || r.top >= vh || r.bottom <= 0 || r.bottom < vh * 0.55 || r.left > window.innerWidth * 0.3) continue;
      return nameBeside(el);
    }
    return null;
  }

  function feedAuthor(element) {
    const box = element.getBoundingClientRect();
    let avatar = null;
    let bottom = -Infinity;
    for (const el of doc.querySelectorAll(AVATARS)) {
      const r = el.getBoundingClientRect();
      if (!squareish(r) || r.left > window.innerWidth * 0.45) continue;
      if (r.bottom > box.top + 6 || box.top - r.bottom > 700) continue;
      if (r.bottom > bottom) {
        bottom = r.bottom;
        avatar = el;
      }
    }
    return avatar ? nameBeside(avatar) : null;
  }

  function pageSlug() {
    const m = location.pathname.match(/^\/([^/]+)\/(?:videos|posts|photos|reel)\//);
    if (!m || /^(?:reels?|watch|stories|photo|video|groups|share)$/i.test(m[1])) return null;
    try {
      return decodeURIComponent(m[1]);
    } catch {
      return m[1];
    }
  }

  function standalone(element) {
    const here = pageTarget(location.href);
    return Boolean(here && (here.kind === "story" || here.kind === "photo" || element === bestVideo()));
  }

  function authorFor(element, found) {
    const steps = [];
    if (element) {
      if (standalone(element)) steps.push(() => profileName(element));
      steps.push(() => feedAuthor(element));
    }
    steps.push(() => found.author, pageSlug);
    for (const step of steps) {
      let value = null;
      try {
        value = step();
      } catch {}
      if (value) return value;
    }
    return null;
  }

  function cleanName(name) {
    const text = String(name ?? "")
      .normalize("NFC")
      .replace(/[\p{Co}\p{Cn}\p{Cs}]/gu, " ")
      .replace(/[<>:"/\\|?*\u0000-\u001f\u007f-\u009f\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff\ue000-\uf8ff]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .replace(/^[.~ ]+/, "");
    return [...text].slice(0, 60).join("").trim().replace(/[\s.\p{S}\p{Co}\p{Cn}]+$/u, "") || "Facebook";
  }

  const pad = (n) => (n < 10 ? `0${n}` : `${n}`);
  function dateStamp() {
    const d = new Date();
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    return `${pad(d.getDate())} ${months[d.getMonth()]}_${d.getFullYear()}`;
  }

  function buildOptions(found, item, base) {
    const isVideo = item ? item.kind === "video" : found.kind === "video";
    const name = (extension, suffix) => `${base}${suffix ? `-${suffix}` : ""}.${extension}`;
    const options = [];
    if (!isVideo) {
      const url = item?.url ?? found.fallback;
      if (url) options.push({ id: "photo", label: "Photo", note: item?.url ? "full size" : "as shown", rank: 1, single: true, parts: [{ url, name: name(extensionOf(url, "jpg")) }] });
      for (const option of options) option.name = option.parts[0].name;
      return options;
    }
    const seen = new Set();
    for (const file of item?.files ?? []) {
      if (seen.has(file.quality)) continue;
      seen.add(file.quality);
      options.push({ id: `file:${file.quality}`, label: file.quality, note: "single file", rank: file.quality === "HD" ? 720 : 360, single: true, parts: [{ url: file.url, name: name(extensionOf(file.url, "mp4")) }] });
    }
    const audio = item?.tracks?.audio ?? null;
    for (const track of item?.tracks?.videos ?? []) {
      const label = track.height ? `${track.height}p` : `${Math.round(track.bandwidth / 1000)} kbps`;
      const parts = [{ url: track.url, name: name("mp4", "video") }];
      if (audio) parts.push({ url: audio.url, name: name("m4a", "audio") });
      const note = [codecName(track.codecs), audio ? "video + audio" : "video only"].filter(Boolean).join(", ");
      options.push({ id: `dash:${label}`, label, note, rank: track.height || 1, single: false, merge: audio ? { video: track.url, audio: audio.url } : null, name: name("mp4"), parts });
    }
    if (audio) options.push({ id: "audio", label: "Audio only", note: "m4a", rank: 0, single: true, audio: true, parts: [{ url: audio.url, name: name("m4a") }] });
    if (!options.length && found.direct) options.push({ id: "direct", label: "Page file", note: "as the page plays it", rank: 360, single: true, parts: [{ url: found.direct, name: name(extensionOf(found.direct, "mp4")) }] });
    for (const option of options) option.name ??= option.parts[0].name;
    options.sort((a, b) => b.rank - a.rank || Number(b.single) - Number(a.single));
    return options;
  }

  function pickOption(options, quality) {
    const video = options.filter((o) => !o.audio);
    const pool = video.length ? video : options;
    const singles = pool.filter((o) => o.single);
    if (quality === "max") return pool[0];
    if (quality === "sd") return singles[singles.length - 1] ?? pool[pool.length - 1];
    return singles.find((o) => o.label === "HD") ?? pool[0];
  }

  function unavailable(found, item) {
    if (found.kind === "video" || item?.kind === "video") {
      if (!found.id && !found.cardId) return "Couldn't tell which video this is. Open it from its post and try again.";
      if (item?.dash) return "Facebook only streams this video in small pieces, so there is no single file to save.";
      return "Couldn't get this video's file. Let it play for a moment, or open it, and try again.";
    }
    return "Couldn't find this photo's file.";
  }

  const be32 = (b, o) => ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
  const be64 = (b, o) => be32(b, o) * 4294967296 + be32(b, o + 4);
  const fourcc = (b, o) => String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]);
  const cc = (text) => Uint8Array.from([...text].map((c) => c.charCodeAt(0)));

  function u32s(list) {
    const out = new Uint8Array(list.length * 4);
    const view = new DataView(out.buffer);
    for (let i = 0; i < list.length; i++) view.setUint32(i * 4, list[i]);
    return out;
  }

  function mk(type, ...parts) {
    let size = 8;
    for (const part of parts) size += part.length;
    const out = new Uint8Array(size);
    new DataView(out.buffer).setUint32(0, size);
    out.set(cc(type), 4);
    let at = 8;
    for (const part of parts) {
      out.set(part, at);
      at += part.length;
    }
    return out;
  }

  const full = (type, version, flags, ...parts) => mk(type, u32s([(version << 24) | flags]), ...parts);

  function kids(buf, start, end) {
    const out = [];
    let pos = start;
    while (pos + 8 <= end) {
      let size = be32(buf, pos);
      const type = fourcc(buf, pos + 4);
      let head = 8;
      if (size === 1) {
        size = be64(buf, pos + 8);
        head = 16;
      } else if (size === 0) {
        size = end - pos;
      }
      if (size < head || pos + size > end) break;
      out.push({ type, start: pos, body: pos + head, end: pos + size });
      pos += size;
    }
    return out;
  }

  const child = (list, type) => list.find((k) => k.type === type);

  async function scanTop(blob) {
    const top = [];
    let pos = 0;
    while (pos + 8 <= blob.size) {
      const head = new Uint8Array(await blob.slice(pos, pos + 16).arrayBuffer());
      let size = be32(head, 0);
      let headSize = 8;
      if (size === 1) {
        size = be64(head, 8);
        headSize = 16;
      } else if (size === 0) {
        size = blob.size - pos;
      }
      if (size < headSize) throw new Error("damaged MP4");
      top.push({ type: fourcc(head, 4), start: pos, size, headSize });
      pos += size;
    }
    return top;
  }

  async function readTrack(blob) {
    const top = await scanTop(blob);
    const moovBox = top.find((b) => b.type === "moov");
    if (!moovBox || !top.some((b) => b.type === "moof")) throw new Error("not a fragmented MP4");
    const moov = new Uint8Array(await blob.slice(moovBox.start, moovBox.start + moovBox.size).arrayBuffer());
    const root = kids(moov, moovBox.headSize, moov.length);
    const trak = child(root, "trak");
    const tkhd = child(kids(moov, trak.body, trak.end), "tkhd");
    const mdia = child(kids(moov, trak.body, trak.end), "mdia");
    const mdiaKids = kids(moov, mdia.body, mdia.end);
    const mdhd = child(mdiaKids, "mdhd");
    const hdlr = child(mdiaKids, "hdlr");
    const minf = child(mdiaKids, "minf");
    const minfKids = kids(moov, minf.body, minf.end);
    const stbl = child(minfKids, "stbl");
    const stsd = child(kids(moov, stbl.body, stbl.end), "stsd");
    const mdhdV1 = moov[mdhd.body] === 1;
    const trackId = be32(moov, tkhd.body + (moov[tkhd.body] === 1 ? 20 : 12));
    const trex = { dur: 0, size: 0, flags: 0 };
    const mvex = child(root, "mvex");
    const trexBox = mvex ? kids(moov, mvex.body, mvex.end).find((k) => k.type === "trex" && be32(moov, k.body + 4) === trackId) : null;
    if (trexBox) {
      trex.dur = be32(moov, trexBox.body + 12);
      trex.size = be32(moov, trexBox.body + 16);
      trex.flags = be32(moov, trexBox.body + 20);
    }
    const track = {
      kind: fourcc(moov, hdlr.body + 8),
      timescale: be32(moov, mdhd.body + (mdhdV1 ? 20 : 12)),
      lang: (moov[mdhd.body + (mdhdV1 ? 32 : 20)] << 8) | moov[mdhd.body + (mdhdV1 ? 33 : 21)],
      hdlr: moov.slice(hdlr.start, hdlr.end),
      minfCopy: minfKids.filter((k) => k.type !== "stbl").map((k) => moov.slice(k.start, k.end)),
      stsd: moov.slice(stsd.start, stsd.end),
      tkhdTail: moov.slice(tkhd.end - 44, tkhd.end),
      dur: [],
      size: [],
      flags: [],
      cto: [],
      chunks: [],
      startTicks: 0
    };
    if (!track.timescale) throw new Error("no timescale");
    let ticks = 0;
    let started = false;
    for (const box of top) {
      if (box.type !== "moof") continue;
      const buf = new Uint8Array(await blob.slice(box.start, box.start + box.size).arrayBuffer());
      for (const traf of kids(buf, box.headSize, buf.length).filter((k) => k.type === "traf")) {
        const parts = kids(buf, traf.body, traf.end);
        const tfhd = child(parts, "tfhd");
        if (!tfhd || be32(buf, tfhd.body + 4) !== trackId) continue;
        const tfFlags = be32(buf, tfhd.body) & 0xffffff;
        let o = tfhd.body + 8;
        let base = box.start;
        let defDur = trex.dur;
        let defSize = trex.size;
        let defFlags = trex.flags;
        if (tfFlags & 1) {
          base = be64(buf, o);
          o += 8;
        }
        if (tfFlags & 2) o += 4;
        if (tfFlags & 8) {
          defDur = be32(buf, o);
          o += 4;
        }
        if (tfFlags & 16) {
          defSize = be32(buf, o);
          o += 4;
        }
        if (tfFlags & 32) defFlags = be32(buf, o);
        const tfdt = child(parts, "tfdt");
        if (tfdt) ticks = buf[tfdt.body] === 1 ? be64(buf, tfdt.body + 4) : be32(buf, tfdt.body + 4);
        if (!started) {
          started = true;
          track.startTicks = ticks;
        }
        let cursor = base;
        for (const trun of parts.filter((k) => k.type === "trun")) {
          const version = buf[trun.body];
          const f = be32(buf, trun.body) & 0xffffff;
          const count = be32(buf, trun.body + 4);
          let p = trun.body + 8;
          if (f & 1) {
            cursor = base + (be32(buf, p) | 0);
            p += 4;
          }
          let firstFlags = null;
          if (f & 4) {
            firstFlags = be32(buf, p);
            p += 4;
          }
          const chunk = { pos: cursor, bytes: 0, count, start: ticks };
          for (let i = 0; i < count; i++) {
            let dur = defDur;
            let size = defSize;
            let flags = i === 0 && firstFlags !== null ? firstFlags : defFlags;
            let cto = 0;
            if (f & 0x100) {
              dur = be32(buf, p);
              p += 4;
            }
            if (f & 0x200) {
              size = be32(buf, p);
              p += 4;
            }
            if (f & 0x400) {
              flags = be32(buf, p);
              p += 4;
            }
            if (f & 0x800) {
              cto = version === 1 ? be32(buf, p) | 0 : be32(buf, p);
              p += 4;
            }
            track.dur.push(dur);
            track.size.push(size);
            track.flags.push(flags);
            track.cto.push(cto);
            cursor += size;
            chunk.bytes += size;
            ticks += dur;
          }
          if (chunk.pos + chunk.bytes > blob.size) throw new Error("truncated MP4");
          if (chunk.count) track.chunks.push(chunk);
        }
      }
    }
    if (!track.dur.length) throw new Error("no samples");
    return track;
  }

  function runLengths(values) {
    const out = [];
    for (const value of values) {
      const last = out[out.length - 1];
      if (last && last[0] === value) last[1]++;
      else out.push([value, 1]);
    }
    return out;
  }

  function buildTrak(t, number, offsets, movieScale) {
    const sum = (list) => list.reduce((a, b) => a + b, 0);
    const mediaDur = sum(t.dur);
    const toMovie = (ticks) => Math.round((ticks * movieScale) / t.timescale);
    let firstPts = 0;
    if (t.cto.some((v) => v !== 0)) {
      let dts = 0;
      firstPts = Infinity;
      for (let i = 0; i < t.cto.length; i++) {
        firstPts = Math.min(firstPts, dts + t.cto[i]);
        dts += t.dur[i];
      }
    }
    const shift = Math.max(firstPts, 0);
    const edits = [];
    if (t.startTicks > 0) edits.push([toMovie(t.startTicks), -1]);
    edits.push([toMovie(mediaDur), shift]);
    const trackDur = edits.reduce((n, e) => n + e[0], 0);
    const edts = t.startTicks > 0 || shift > 0 ? mk("edts", full("elst", 0, 0, u32s([edits.length].concat(edits.flatMap(([d, m]) => [d, m, 0x00010000]))))) : new Uint8Array(0);
    const tkhd = full("tkhd", 0, 3, u32s([0, 0, number, 0, trackDur, 0, 0, 0, t.kind === "soun" ? 0x01000000 : 0]), t.tkhdTail);
    const mdhd = full("mdhd", 0, 0, u32s([0, 0, t.timescale, mediaDur, (t.lang << 16) >>> 0]));
    const stts = full("stts", 0, 0, u32s([runLengths(t.dur).length].concat(runLengths(t.dur).flatMap(([d, c]) => [c, d]))));
    const hasCto = t.cto.some((v) => v !== 0);
    const negative = t.cto.some((v) => v < 0);
    const ctts = hasCto ? full("ctts", negative ? 1 : 0, 0, u32s([runLengths(t.cto).length].concat(runLengths(t.cto).flatMap(([v, c]) => [c, v])))) : new Uint8Array(0);
    const sync = [];
    t.flags.forEach((f, i) => {
      if (!(f & 0x10000)) sync.push(i + 1);
    });
    const stss = sync.length && sync.length < t.flags.length ? full("stss", 0, 0, u32s([sync.length].concat(sync))) : new Uint8Array(0);
    const perChunk = runLengths(t.chunks.map((c) => c.count));
    const stscRows = [];
    let first = 1;
    for (const [count, repeat] of perChunk) {
      stscRows.push(first, count, 1);
      first += repeat;
    }
    const stsc = full("stsc", 0, 0, u32s([perChunk.length].concat(stscRows)));
    const stsz = full("stsz", 0, 0, u32s([0, t.size.length].concat(t.size)));
    const stco = full("stco", 0, 0, u32s([offsets.length].concat(offsets)));
    const stbl = mk("stbl", t.stsd, stts, ctts, stss, stsc, stsz, stco);
    const minf = mk("minf", ...t.minfCopy, stbl);
    return { trak: mk("trak", tkhd, edts, mk("mdia", mdhd, t.hdlr, minf)), duration: trackDur };
  }

  function buildMoov(tracks, offsets) {
    const traks = tracks.map((t, i) => buildTrak(t, i + 1, offsets[i], 1000));
    const duration = Math.max(...traks.map((t) => t.duration));
    const mvhd = full("mvhd", 0, 0, u32s([0, 0, 1000, duration, 0x00010000, 0x01000000, 0, 0, 0x00010000, 0, 0, 0, 0x00010000, 0, 0, 0, 0x40000000, 0, 0, 0, 0, 0, 0, tracks.length + 1]));
    return mk("moov", mvhd, ...traks.map((t) => t.trak));
  }

  async function muxMp4(videoBlob, audioBlob) {
    const tracks = [await readTrack(videoBlob), await readTrack(audioBlob)];
    if (tracks[0].kind !== "vide" || tracks[1].kind !== "soun") throw new Error("unexpected stream types");
    const blobs = [videoBlob, audioBlob];
    const items = [];
    tracks.forEach((t, ti) => t.chunks.forEach((c, ci) => items.push({ ti, ci, at: c.start / t.timescale })));
    items.sort((a, b) => a.at - b.at || a.ti - b.ti);
    const total = items.reduce((n, it) => n + tracks[it.ti].chunks[it.ci].bytes, 0);
    if (total > 4e9) throw new Error("too large to merge");
    const ftyp = mk("ftyp", cc("isom"), u32s([512]), cc("isom"), cc("iso2"), cc("avc1"), cc("mp41"));
    const offsetsFor = (base) => {
      const offs = tracks.map((t) => new Array(t.chunks.length).fill(0));
      let at = base;
      for (const it of items) {
        offs[it.ti][it.ci] = at;
        at += tracks[it.ti].chunks[it.ci].bytes;
      }
      return offs;
    };
    const probe = buildMoov(tracks, offsetsFor(0));
    const moov = buildMoov(tracks, offsetsFor(ftyp.length + probe.length + 8));
    const head = new Uint8Array(8);
    new DataView(head.buffer).setUint32(0, total + 8);
    head.set(cc("mdat"), 4);
    const parts = [ftyp, moov, head];
    for (const it of items) {
      const c = tracks[it.ti].chunks[it.ci];
      parts.push(blobs[it.ti].slice(c.pos, c.pos + c.bytes));
    }
    return new Blob(parts, { type: "video/mp4" });
  }

  function viaManager(url, name) {
    return new Promise((resolve, reject) => {
      let timer = 0;
      let finished = false;
      const settle = (fn, value) => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        fn(value);
      };
      const arm = () => {
        clearTimeout(timer);
        timer = setTimeout(() => settle(reject, new Error("the manager stalled")), STALL);
      };
      arm();
      try {
        GM_download({
          url,
          name,
          saveAs: false,
          timeout: TIMEOUT,
          onprogress: arm,
          onload: () => settle(resolve),
          onerror: (error) => settle(reject, Object.assign(new Error(describe(error?.error) || describe(error?.details) || "the manager could not save it"), { cancelled: /cancel/i.test(`${describe(error?.error)} ${describe(error?.details)}`) })),
          ontimeout: () => settle(reject, new Error("it took too long"))
        });
      } catch (error) {
        settle(reject, error);
      }
    });
  }

  function fetchBlob(url, onProgress) {
    return new Promise((resolve, reject) => {
      const fail = (status) => reject(Object.assign(new Error(`the server answered ${status}`), { status }));
      if (typeof GM_xmlhttpRequest === "function") {
        GM_xmlhttpRequest({
          method: "GET",
          url,
          responseType: "blob",
          timeout: TIMEOUT,
          anonymous: true,
          onprogress: (r) => onProgress?.(r.loaded || 0, r.total || 0),
          onload: (r) => (r.status >= 200 && r.status < 300 && r.response ? resolve(r.response) : fail(r.status)),
          onerror: () => reject(new Error("the file couldn't be fetched")),
          ontimeout: () => reject(new Error("it took too long"))
        });
        return;
      }
      fetch(url, { credentials: "omit" }).then((r) => (r.ok ? r.blob() : fail(r.status))).then(resolve, reject);
    });
  }

  async function saveFile({ url, name }) {
    if (typeof GM_download === "function") {
      try {
        await viaManager(url, name);
        return "manager";
      } catch (error) {
        if (error.cancelled) throw Object.assign(new Error("you cancelled it", { cause: error }), { cancelled: true });
      }
    }
    let blob;
    try {
      blob = await fetchBlob(url);
    } catch (error) {
      if (error.status || typeof GM_openInTab !== "function") throw error;
      GM_openInTab(url, { active: true });
      return "tab";
    }
    saveBlobLink(blob, name);
    return "link";
  }

  function saveBlobLink(blob, name) {
    const href = URL.createObjectURL(blob);
    const link = doc.createElement("a");
    link.href = href;
    link.download = name;
    link.rel = "noopener";
    link.style.display = "none";
    (doc.body ?? doc.documentElement).append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(href), 6e4);
  }

  async function saveMerged(choice, say) {
    const slots = [{ loaded: 0, total: 0 }, { loaded: 0, total: 0 }];
    let last = 0;
    const track = (slot) => (loaded, total) => {
      slot.loaded = loaded;
      if (total) slot.total = total;
      const now = Date.now();
      if (now - last < 500) return;
      last = now;
      const all = slots[0].total + slots[1].total;
      if (all > 0) say(`Downloading ${Math.min(99, Math.round(((slots[0].loaded + slots[1].loaded) * 100) / all))}%`);
    };
    const [video, audio] = await Promise.all([fetchBlob(choice.merge.video, track(slots[0])), fetchBlob(choice.merge.audio, track(slots[1]))]);
    say("Merging video and audio");
    let merged = null;
    try {
      merged = await muxMp4(video, audio);
    } catch (error) {
      say("Couldn't merge them. Saving video and audio as two files.", "error");
    }
    if (!merged) {
      saveBlobLink(video, choice.parts[0].name);
      saveBlobLink(audio, choice.parts[1].name);
      return "split";
    }
    saveBlobLink(merged, choice.name);
    return "link";
  }

  const CSS = `
:host { all: initial; }
* { box-sizing: border-box; }
@keyframes spin { to { transform: rotate(360deg); } }
.pill {
  position: fixed; z-index: 2147483646; display: none; align-items: stretch; overflow: hidden;
  border-radius: 999px; background: rgba(255,255,255,0.94);
  -webkit-backdrop-filter: blur(14px) saturate(1.6); backdrop-filter: blur(14px) saturate(1.6);
  border: 1px solid rgba(0,0,0,0.06); box-shadow: 0 6px 20px rgba(0,0,0,0.18), 0 1px 3px rgba(0,0,0,0.12);
  touch-action: none; user-select: none; -webkit-user-select: none;
  transition: box-shadow 0.15s, transform 0.15s;
}
.pill.on { display: inline-flex; }
.pill.drag { transform: scale(1.04); box-shadow: 0 12px 30px rgba(0,0,0,0.28); }
.pill[aria-busy] .main { opacity: 0.75; }
.pill button {
  display: inline-flex; align-items: center; justify-content: center; min-height: 44px; min-width: 44px; margin: 0; padding: 0 14px; border: 0;
  background: transparent; color: #1c1e21; font: 600 14px/1 system-ui, sans-serif;
  -webkit-tap-highlight-color: transparent; touch-action: manipulation;
}
.pill .main svg { color: #1877f2; width: 20px; height: 20px; }
.pill .main svg.ok { color: #1a9e48; }
.pill .more { padding: 0 12px; border-left: 1px solid rgba(0,0,0,0.09); color: #65676b; }
.pill svg { width: 18px; height: 18px; fill: none; stroke: currentColor; stroke-width: 2.2; stroke-linecap: round; stroke-linejoin: round; }
.pill svg.spin { animation: spin 0.8s linear infinite; }
.toast {
  position: fixed; z-index: 2147483647; left: 50%; bottom: calc(env(safe-area-inset-bottom, 0px) + 76px);
  transform: translateX(-50%); max-width: 88vw; padding: 11px 16px; border-radius: 14px; display: none;
  background: #fff; color: #1c1e21; font: 500 14px/1.35 system-ui, sans-serif; text-align: center;
  box-shadow: 0 8px 24px rgba(0,0,0,0.22), 0 0 0 1px rgba(0,0,0,0.05); word-break: break-word;
}
.toast.show { display: block; }
.toast.err { background: #fff1f0; color: #b42318; box-shadow: 0 8px 24px rgba(180,35,24,0.2), 0 0 0 1px #fecdca; }
.sheet { position: fixed; inset: 0; z-index: 2147483647; display: none; align-items: flex-end; justify-content: center; background: rgba(0,0,0,0.35); }
.sheet.show { display: flex; }
.panel {
  width: 100%; max-width: 480px; max-height: 76vh; overflow: auto; background: #fff; color: #1c1e21;
  border-radius: 20px 20px 0 0; padding: 8px 0 calc(env(safe-area-inset-bottom, 0px) + 10px);
  box-shadow: 0 -8px 30px rgba(0,0,0,0.2); font: 500 16px/1.3 system-ui, sans-serif;
}
.bar { width: 40px; height: 4px; border-radius: 2px; background: #d0d3d8; margin: 4px auto 12px; }
.panel h4 { margin: 0; padding: 0 20px 2px; font: 700 17px/1.2 system-ui, sans-serif; }
.sub { padding: 0 20px 10px; font: 500 12px/1.35 system-ui, sans-serif; color: #65676b; word-break: break-all; }
.opt {
  display: flex; justify-content: space-between; align-items: center; gap: 12px; width: 100%; min-height: 58px;
  margin: 0; padding: 8px 20px; border: 0; background: transparent; color: #1c1e21; font: inherit; text-align: left;
  -webkit-tap-highlight-color: transparent;
}
.opt .lb { display: block; font: 600 16px/1.2 system-ui, sans-serif; }
.opt small { display: block; margin-top: 3px; color: #65676b; font: 500 12.5px/1.2 system-ui, sans-serif; }
.opt .sz { flex: none; padding: 6px 10px; border-radius: 999px; background: rgba(24,119,242,0.1); color: #1877f2; font: 600 13px/1 system-ui, sans-serif; text-align: center; }
.opt .sz:empty { display: none; }
.opt:active { background: rgba(24,119,242,0.08); }
.opt.cancel { justify-content: center; margin-top: 6px; border-top: 1px solid rgba(0,0,0,0.08); color: #65676b; font-weight: 600; }
`;

  const ui = (() => {
    let host = null;
    let root = null;
    let toastEl = null;
    let sheetEl = null;
    let panelEl = null;
    let pending = null;
    let toastTimer = 0;
    let onClick = () => {};
    let onDrop = () => {};
    const entries = [];
    const make = (tag, className) => {
      const node = doc.createElement(tag);
      if (className) node.className = className;
      return node;
    };
    const svgOf = (path, className) => {
      const svg = doc.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("viewBox", "0 0 24 24");
      svg.setAttribute("aria-hidden", "true");
      if (className) svg.setAttribute("class", className);
      const shape = doc.createElementNS("http://www.w3.org/2000/svg", "path");
      shape.setAttribute("d", path);
      svg.append(shape);
      return svg;
    };
    function mount() {
      if (host?.isConnected) return true;
      const parent = doc.documentElement;
      if (!parent || !doc.body) return false;
      host = make("div");
      host.setAttribute(FLOATING, "");
      root = host.attachShadow({ mode: "closed" });
      const style = make("style");
      style.textContent = CSS;
      toastEl = make("div", "toast");
      toastEl.setAttribute("role", "status");
      sheetEl = make("div", "sheet");
      panelEl = make("div", "panel");
      sheetEl.append(panelEl);
      sheetEl.addEventListener("click", (event) => {
        if (event.target === sheetEl && pending) pending(null);
      });
      root.append(style, toastEl, sheetEl);
      for (const entry of entries) root.append(entry.wrap);
      parent.append(host);
      return true;
    }
    function createEntry() {
      const wrap = make("div", "pill");
      const main = make("button", "main");
      main.type = "button";
      const more = make("button", "more");
      more.type = "button";
      more.setAttribute("aria-label", "Choose quality");
      more.append(svgOf("M6 9l6 6 6-6"));
      wrap.append(main, more);
      const entry = { wrap, main, more, item: null, sig: "", box: null, dragging: false };
      const fire = (menu) => (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (entry.item) onClick(entry.item, menu);
      };
      main.addEventListener("click", fire(false));
      more.addEventListener("click", fire(true));
      for (const type of ["pointerdown", "pointerup", "touchstart", "touchend", "mousedown", "mouseup"]) {
        wrap.addEventListener(type, (event) => event.stopPropagation());
      }
      let drag = null;
      let suppress = 0;
      wrap.addEventListener("pointerdown", (event) => {
        if (event.pointerType === "mouse" && event.button !== 0) return;
        const r = wrap.getBoundingClientRect();
        drag = { id: event.pointerId, sx: event.clientX, sy: event.clientY, left: r.left, top: r.top, moved: false, x: r.left, y: r.top };
      });
      wrap.addEventListener("pointermove", (event) => {
        if (!drag || event.pointerId !== drag.id) return;
        const dx = event.clientX - drag.sx;
        const dy = event.clientY - drag.sy;
        if (!drag.moved) {
          if (Math.hypot(dx, dy) < 8 || !entry.box) return;
          drag.moved = true;
          entry.dragging = true;
          wrap.classList.add("drag");
          try {
            wrap.setPointerCapture(event.pointerId);
          } catch {}
        }
        event.preventDefault();
        const b = entry.box;
        drag.x = Math.min(Math.max(drag.left + dx, b.x0), b.x0 + b.w);
        drag.y = Math.min(Math.max(drag.top + dy, b.y0), b.y0 + b.h);
        wrap.style.right = wrap.style.bottom = "auto";
        wrap.style.left = `${drag.x}px`;
        wrap.style.top = `${drag.y}px`;
      });
      const finish = (event) => {
        if (!drag || event.pointerId !== drag.id) return;
        const d = drag;
        drag = null;
        if (!d.moved) return;
        entry.dragging = false;
        wrap.classList.remove("drag");
        suppress = Date.now() + 500;
        const b = entry.box;
        onDrop({ x: b.w > 0 ? clamp01((d.x - b.x0) / b.w) : prefs.pos.x, y: b.h > 0 ? clamp01((d.y - b.y0) / b.h) : prefs.pos.y });
      };
      wrap.addEventListener("pointerup", finish);
      wrap.addEventListener("pointercancel", finish);
      wrap.addEventListener(
        "click",
        (event) => {
          if (Date.now() < suppress) {
            event.preventDefault();
            event.stopPropagation();
          }
        },
        true
      );
      return entry;
    }
    function place(entry, element) {
      const wrap = entry.wrap;
      const r = element.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const top = Math.max(r.top, TOP_BAR);
      const bottom = Math.min(r.bottom, vh - BOTTOM_BAR);
      const left = Math.max(r.left, 0);
      const right = Math.min(r.right, vw);
      if (bottom - top < 80 || right - left < 80) return false;
      const m = 8;
      const pw = wrap.offsetWidth || 110;
      const ph = wrap.offsetHeight || 44;
      const w = Math.max(0, right - left - 2 * m - pw);
      const h = Math.max(0, bottom - top - 2 * m - ph);
      entry.box = { x0: left + m, y0: top + m, w, h };
      const s = wrap.style;
      s.right = s.bottom = "auto";
      s.left = `${entry.box.x0 + prefs.pos.x * w}px`;
      s.top = `${entry.box.y0 + prefs.pos.y * h}px`;
      return true;
    }
    function paint(entry) {
      if (entry.dragging) return;
      const item = entry.item;
      if (!item || !item.element.isConnected) {
        entry.wrap.classList.remove("on");
        return;
      }
      const phase = item.busy || "";
      const sig = `${phase}|${item.menu}`;
      if (sig !== entry.sig) {
        entry.sig = sig;
        entry.main.replaceChildren(phase === "work" ? svgOf(SPINNER_ICON, "spin") : phase ? svgOf(CHECK_ICON, "ok") : svgOf(DOWNLOAD_ICON));
        entry.main.setAttribute("aria-label", phase === "work" ? "Working" : phase ? "Ready" : `Download ${item.found.label}`);
        entry.more.style.display = item.menu && !phase ? "" : "none";
        entry.wrap.toggleAttribute("aria-busy", phase === "work");
      }
      entry.wrap.classList.add("on");
      if (!place(entry, item.element)) entry.wrap.classList.remove("on");
    }
    return {
      isHost: (node) => node === host,
      onClick(fn) {
        onClick = fn;
      },
      onDrop(fn) {
        onDrop = fn;
      },
      sync(items) {
        if (!items.length && !entries.length) return;
        if (!mount()) return;
        const used = new Set();
        const assigned = new Map();
        for (const item of items) {
          const entry = entries.find((e) => !used.has(e) && e.item && e.item.element === item.element);
          if (entry) {
            used.add(entry);
            assigned.set(item, entry);
          }
        }
        for (const item of items) {
          if (assigned.has(item)) continue;
          let entry = entries.find((e) => !used.has(e));
          if (!entry) {
            entry = createEntry();
            entries.push(entry);
            root.append(entry.wrap);
          }
          used.add(entry);
          assigned.set(item, entry);
        }
        for (const entry of entries) {
          if (used.has(entry)) continue;
          entry.item = null;
          if (!entry.dragging) entry.wrap.classList.remove("on");
        }
        for (const [item, entry] of assigned) {
          entry.item = item;
          paint(entry);
        }
      },
      reposition() {
        for (const entry of entries) if (entry.item) paint(entry);
      },
      hideAll() {
        for (const entry of entries) {
          entry.item = null;
          if (!entry.dragging) entry.wrap.classList.remove("on");
        }
      },
      choose(options, fileBase) {
        if (!mount()) return Promise.resolve(null);
        if (pending) pending(null);
        return new Promise((resolve) => {
          const close = (value) => {
            pending = null;
            sheetEl.className = "sheet";
            panelEl.replaceChildren();
            resolve(value);
          };
          pending = close;
          const title = make("h4");
          title.textContent = "Choose quality";
          const sub = make("div", "sub");
          sub.textContent = fileBase;
          panelEl.replaceChildren(make("div", "bar"), title, sub);
          for (const option of options) {
            const row = make("button", "opt");
            row.type = "button";
            const text = make("span");
            const label = make("span", "lb");
            label.textContent = option.label;
            const note = make("small");
            note.textContent = option.note;
            text.append(label, note);
            const size = make("span", "sz");
            size.textContent = "…";
            row.append(text, size);
            row.addEventListener("click", () => close(option));
            panelEl.append(row);
            optionSize(option).then(
              (n) => {
                size.textContent = n ? fmtSize(n) : "";
              },
              () => {
                size.textContent = "";
              }
            );
          }
          const cancel = make("button", "opt cancel");
          cancel.type = "button";
          cancel.textContent = "Cancel";
          cancel.addEventListener("click", () => close(null));
          panelEl.append(cancel);
          sheetEl.className = "sheet show";
        });
      },
      toast(message, tone) {
        if (!mount()) return;
        toastEl.textContent = message;
        toastEl.className = `toast show${tone === "error" ? " err" : ""}`;
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => {
          toastEl.className = "toast";
        }, tone === "error" ? 6500 : 3200);
      }
    };
  })();

  async function run(found, { ask = false, retried = false, want = null, base = null, element = null, onPhase = null } = {}) {
    const live = base ? null : authorFor(element, found);
    let item = null;
    try {
      item = await resolve(found, retried, ask);
    } catch (error) {
      item = lookup(found);
    }
    if (!base) {
      const who = found.cardId ? item?.author ?? live : live ?? item?.author;
      base = `${cleanName(who)}-${found.label[0].toUpperCase()}${found.label.slice(1)}-${dateStamp()}`;
    }
    const options = buildOptions(found, item, base);
    if (!options.length) {
      stats.failed++;
      ui.toast(unavailable(found, item), "error");
      return;
    }
    let choice = want ? options.find((o) => o.label === want) : null;
    if (!choice) {
      if (ask || (prefs.quality === "ask" && options.length > 1)) {
        onPhase?.("ready");
        choice = await ui.choose(options, base);
        if (!choice) return;
        onPhase?.("work");
      } else {
        choice = pickOption(options, prefs.quality);
      }
    }
    ui.toast(choice.merge ? "Downloading video and audio" : `Saving ${choice.name}`);
    try {
      let how = "manager";
      if (choice.merge) how = await saveMerged(choice, (message, tone) => ui.toast(message, tone));
      else for (const part of choice.parts) how = await saveFile(part);
      stats.saved++;
      ui.toast(how === "tab" ? "Opened in a new tab. Long-press the video there to save it." : how === "split" ? "Saved video and audio as two files" : `Saved ${choice.name}`);
      onPhase?.("done");
    } catch (error) {
      if (error.cancelled) {
        ui.toast(`Cancelled ${choice.name}`);
        return;
      }
      if (!retried && [401, 403, 404, 410].includes(error.status)) {
        const old = lookup(found);
        if (old) index.forget(old.id);
        return run(found, { retried: true, want: choice.label, base, element, onPhase });
      }
      stats.failed++;
      ui.toast(`Couldn't save it: ${error.message}.`, "error");
    }
  }

  function createController() {
    let job = null;
    let phase = "work";
    let doneUntil = 0;
    const cache = new WeakMap();
    let idleTimer = 0;
    let frame = 0;
    let shown = [];
    let last = [];

    const area = (element) => {
      const { w, h, rect } = visibleArea(element);
      if (rect.width < MIN || rect.height < MIN || w < MIN * 0.8 || h < MIN * 0.8) return 0;
      return w * h;
    };

    const ownLayer = (media, layer) => {
      if (layer.contains(media)) return true;
      const dialog = layer.closest?.('[role="dialog"]');
      if (dialog && !dialog.contains(media)) return false;
      let node = media.parentElement;
      for (let level = 0; node && node !== doc.body && node !== doc.documentElement && level < OWN_LAYER; level++, node = node.parentElement) {
        if (node.contains(layer)) return true;
      }
      return false;
    };

    const occluded = (element) => {
      const { rect } = visibleArea(element);
      const x = (Math.max(rect.left, 0) + Math.min(rect.right, window.innerWidth)) / 2;
      const y = (Math.max(rect.top, TOP_BAR) + Math.min(rect.bottom, window.innerHeight - BOTTOM_BAR)) / 2;
      let stack = [];
      try {
        stack = doc.elementsFromPoint(x, y);
      } catch {
        return false;
      }
      const at = stack.indexOf(element);
      const above = at === -1 ? stack : stack.slice(0, at);
      return !above.every((layer) => ui.isHost(layer) || layer.hasAttribute?.(FLOATING) || ownLayer(element, layer));
    };

    const find = (element, fresh) => {
      const hit = cache.get(element);
      if (!fresh && hit && Date.now() - hit.at < 1200 && hit.href === location.href) return hit.found;
      let found = null;
      try {
        found = findMedia(element, location.href);
      } catch {
        found = null;
      }
      cache.set(element, { found, at: Date.now(), href: location.href });
      return found;
    };

    function refresh() {
      idleTimer = 0;
      if (!prefs.enabled || doc.hidden) {
        shown = [];
        ui.hideAll();
        return;
      }
      const state = job ? phase : Date.now() < doneUntil ? "done" : null;
      if (state) {
        for (const item of shown) item.busy = state;
        ui.sync(shown);
        return;
      }
      const list = [];
      for (const element of doc.querySelectorAll("video, img")) {
        const value = area(element);
        if (value > 0) list.push([element, value]);
      }
      list.sort((a, b) => b[1] - a[1]);
      const next = [];
      for (const [element] of list.slice(0, 10)) {
        if (next.length >= MAX_BUTTONS) break;
        if (occluded(element)) continue;
        const found = find(element, false);
        if (!found) continue;
        next.push({ element, found, busy: false, menu: found.kind === "video" });
      }
      shown = next;
      if (next.length) last = next;
      ui.sync(next);
    }

    const schedule = (ms) => {
      clearTimeout(idleTimer);
      idleTimer = setTimeout(refresh, ms);
    };

    ui.onDrop((pos) => {
      prefs.pos = pos;
      write("pos", JSON.stringify(pos));
      ui.reposition();
    });

    ui.onClick(async (item, menu) => {
      if (job) return;
      const element = item.element;
      ingestDom();
      const found = element.isConnected ? find(element, true) : null;
      if (!found) {
        ui.toast("There's nothing to save here. Scroll a little and try again.");
        schedule(0);
        return;
      }
      const onPhase = (next) => {
        phase = next;
        refresh();
      };
      job = { element };
      phase = "work";
      refresh();
      try {
        await run(found, { ask: menu, element, onPhase });
      } catch (error) {
        stats.failed++;
        ui.toast(`Couldn't save it: ${error?.message ?? error}.`, "error");
      } finally {
        const ok = phase === "done";
        job = null;
        phase = "work";
        if (ok) {
          doneUntil = Date.now() + 1800;
          setTimeout(() => schedule(0), 1850);
        }
        schedule(0);
      }
    });

    window.addEventListener(
      "scroll",
      () => {
        if (shown.length && !frame) {
          frame = window.requestAnimationFrame(() => {
            frame = 0;
            ui.reposition();
          });
        }
        schedule(160);
      },
      { capture: true, passive: true }
    );
    window.addEventListener("resize", () => schedule(120), { passive: true });
    window.addEventListener("orientationchange", () => schedule(300), { passive: true });
    doc.addEventListener("visibilitychange", () => schedule(0));
    doc.addEventListener("pointerup", () => schedule(250), { capture: true, passive: true });
    setInterval(() => {
      if (!doc.hidden) schedule(0);
    }, 2000);
    schedule(500);
    return { refresh: () => schedule(0), shown: () => (shown.length ? shown : last) };
  }

  function whenBody(fn) {
    if (doc.body) return fn();
    let done = false;
    const wait = () => {
      if (done || !doc.body) return;
      done = true;
      observer.disconnect();
      fn();
    };
    const observer = new MutationObserver(wait);
    observer.observe(doc.documentElement ?? doc, { childList: true, subtree: true });
    doc.addEventListener("DOMContentLoaded", wait, { once: true });
  }

  function watchScripts() {
    let timer = 0;
    const sweep = () => {
      timer = 0;
      ingestDom();
    };
    const queue = () => {
      if (!timer) timer = setTimeout(sweep, 700);
    };
    const start = () => {
      new MutationObserver(queue).observe(doc.documentElement, { childList: true, subtree: true });
      queue();
    };
    if (doc.documentElement) start();
    else {
      const root = new MutationObserver(() => {
        if (!doc.documentElement) return;
        root.disconnect();
        start();
      });
      root.observe(doc, { childList: true });
    }
    doc.addEventListener("DOMContentLoaded", sweep);
    window.addEventListener("load", sweep);
  }

  function menu(label, fn) {
    try {
      if (typeof GM_registerMenuCommand === "function") GM_registerMenuCommand(label, fn);
    } catch {}
  }

  const short = (url) => {
    try {
      const u = new URL(url);
      return `${u.host}${u.pathname.slice(0, 70)}`;
    } catch {
      return String(url ?? "").slice(0, 80);
    }
  };

  function summarize(item) {
    if (!item) return null;
    if (item.kind !== "video") return { kind: item.kind, url: short(item.url) };
    return {
      kind: "video",
      dash: item.dash,
      files: item.files.map((f) => `${f.quality} ${short(f.url)}`),
      tracks: item.tracks ? { videos: item.tracks.videos.map((v) => `${v.height}p ${codecName(v.codecs)}`), audio: Boolean(item.tracks.audio) } : null
    };
  }

  function probe(url, desktop) {
    return new Promise((resolve) => {
      if (typeof GM_xmlhttpRequest !== "function") return resolve({ url, error: "no GM_xmlhttpRequest" });
      const headers = { Accept: "text/html,application/xhtml+xml,application/json" };
      if (desktop) {
        headers["User-Agent"] = DESKTOP_UA;
        headers["Accept-Language"] = "en-US,en;q=0.9";
      }
      const t0 = Date.now();
      GM_xmlhttpRequest({
        method: "GET",
        url,
        timeout: 3e4,
        headers,
        onload: (r) => resolve({ url, status: r.status, finalUrl: r.finalUrl, ms: Date.now() - t0, html: typeof r.responseText === "string" ? r.responseText : "" }),
        onerror: () => resolve({ url, error: "network error" }),
        ontimeout: () => resolve({ url, error: "timeout" })
      });
    });
  }

  const countOf = (text, part) => text.split(part).length - 1;

  function attrChain(element) {
    const out = [];
    for (let node = element, level = 0; node && level < 6; level++, node = node.parentElement) {
      const list = [];
      for (const a of node.attributes) {
        if (a.name === "style" || a.name === "class") continue;
        list.push(/\d{10,}/.test(a.value) ? `${a.name}=${a.value.slice(0, 60)}` : a.name);
      }
      out.push({ level, tag: node.tagName.toLowerCase(), attrs: list.slice(0, 14) });
    }
    return out;
  }

  async function debugReport(items) {
    ingestDom();
    const report = { script: "1.4.4", href: location.href, here: pageTarget(location.href), known: index.size(), hook: stats.hook, hookEver: stats.ever, parses: stats.parses, hits: stats.hits, hidden: doc.hidden, ua: navigator.userAgent, items: [] };
    for (const item of items.slice(0, 2)) {
      const { element } = item;
      const { fallback, direct, ...found } = item.found;
      const links = [];
      const seen = new Set();
      for (let node = element.parentElement, level = 0; node && level < LOOK_UP; level++, node = node.parentElement) {
        for (const a of node.querySelectorAll("a[href]")) {
          const href = a.getAttribute("href");
          if (seen.has(href) || seen.size >= 14) continue;
          seen.add(href);
          links.push({ level, href: String(href).slice(0, 110), target: linkTarget(href) });
        }
      }
      const srcText = String(element.currentSrc || element.getAttribute("src") || "");
      const entry = {
        tag: element.tagName,
        src: short(srcText),
        blob: srcText.startsWith("blob:"),
        found: { ...found, direct: direct ? short(direct) : null },
        known: summarize(lookup(item.found)),
        links,
        attrs: attrChain(element),
        react: reactInfo(element, true),
        idFromSrc: direct ? index.byUrl(direct)?.id ?? null : null,
        probes: []
      };
      for (const url of remoteUrls(item.found)) {
        const r = await probe(url, url.startsWith("https://www.facebook.com"));
        if (r.html === undefined) {
          entry.probes.push(r);
          continue;
        }
        const id = item.found.id ?? "";
        ingestHtml(r.html);
        entry.probes.push({
          url,
          status: r.status,
          finalUrl: short(r.finalUrl),
          ms: r.ms,
          len: r.html.length,
          scripts: countOf(r.html, 'type="application/json"'),
          hasId: id ? r.html.includes(`"${id}"`) : false,
          playableHd: countOf(r.html, '"playable_url_quality_hd"'),
          nativeHd: countOf(r.html, '"browser_native_hd_url"'),
          playable: countOf(r.html, '"playable_url"'),
          progressive: countOf(r.html, '"progressive_url"'),
          dash: countOf(r.html, '"dash_manifest'),
          videoNodes: countOf(r.html, '"__typename":"Video"'),
          loginWall: /login_form|\/login\/\?|checkpoint/i.test(r.html.slice(0, 200000)),
          scraped: id ? scrapeVideo(r.html, id).map((f) => f.quality) : [],
          afterIngest: summarize(lookup(item.found))
        });
      }
      report.items.push(entry);
    }
    return report;
  }

  function copyText(text) {
    try {
      if (typeof GM_setClipboard === "function") {
        GM_setClipboard(text, "text");
        return true;
      }
    } catch {}
    try {
      navigator.clipboard?.writeText(text);
      return true;
    } catch {}
    return false;
  }

  function boot() {
    const sleep = () => {
      unhookJsonParse();
      stats.hook = false;
    };
    const wake = () => {
      if (prefs.hook) stats.hook = hookJsonParse();
    };
    wake();
    doc.addEventListener("visibilitychange", () => (doc.hidden ? sleep() : wake()));
    window.addEventListener("pagehide", sleep);
    window.addEventListener("pageshow", wake);
    watchScripts();
    let controller = null;
    whenBody(() => {
      controller ??= createController();
    });
    menu("Reset button position", () => {
      prefs.pos = { ...DEFAULT_POS };
      write("pos", JSON.stringify(prefs.pos));
      ui.toast("Button position reset");
      controller?.refresh();
    });
    menu("Change default video quality", () => {
      prefs.quality = QUALITIES[(QUALITIES.indexOf(prefs.quality) + 1) % QUALITIES.length];
      write("quality", prefs.quality);
      ui.toast(`Video quality: ${QUALITY_NAMES[prefs.quality]}`);
    });
    menu("Turn button on / off", () => {
      prefs.enabled = !prefs.enabled;
      write("enabled", prefs.enabled);
      ui.toast(prefs.enabled ? "Download button on" : "Download button off");
      controller?.refresh();
    });
    menu("Page hook on / off (reload page)", () => {
      prefs.hook = !prefs.hook;
      write("hook", prefs.hook);
      if (!prefs.hook) sleep();
      ui.toast(`Page hook ${prefs.hook ? "on" : "off"}. Reload the page.`);
    });
    menu("Debug report (copy)", async () => {
      const items = controller?.shown() ?? [];
      if (!items.length) {
        ui.toast("No download button on screen. Scroll a video into view first.", "error");
        return;
      }
      ui.toast("Collecting debug info");
      let text;
      try {
        text = JSON.stringify(await debugReport(items), null, 1);
      } catch (error) {
        text = `debug failed: ${error?.message ?? error}`;
      }
      console.log(text);
      ui.toast(copyText(text) ? "Debug report copied" : "Couldn't copy. See the browser console.", "info");
    });
    menu("Status", () => {
      ingestDom();
      ui.toast(`${index.size()} media known. Page hook ${stats.hook ? "on" : "off"}. ${stats.saved} saved, ${stats.failed} failed.`);
    });
  }

  boot();
})();
