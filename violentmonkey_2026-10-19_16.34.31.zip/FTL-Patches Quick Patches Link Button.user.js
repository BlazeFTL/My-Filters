// ==UserScript==
// @name         FTL-Patches Quick Patches Link Button
// @namespace    hyperion
// @version      1.0
// @match        https://github.com/BlazeFTL/FTL-Patches*
// @icon         https://avatars.githubusercontent.com/u/139938337?v=4&size=64
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const TARGET = 'https://github.com/BlazeFTL/FTL-Patches/tree/dev/patches/src/main/kotlin/app/ftl/patches';
  const ID = 'ftl-patches-quicklink-btn';
  const POS_KEY = 'ftl-patches-btn-pos';

  function savePos(x, y) {
    localStorage.setItem(POS_KEY, JSON.stringify({ x, y }));
  }

  function loadPos() {
    try {
      return JSON.parse(localStorage.getItem(POS_KEY));
    } catch {
      return null;
    }
  }

  function addButton() {
    if (document.getElementById(ID)) return;

    const btn = document.createElement('a');
    btn.id = ID;
    btn.href = TARGET;
    btn.textContent = '📁 Patches';
    btn.style.cssText = `
      position: fixed;
      z-index: 9999;
      background: #238636;
      color: #fff;
      padding: 10px 16px;
      border-radius: 8px;
      font: 600 13px -apple-system, sans-serif;
      text-decoration: none;
      box-shadow: 0 2px 8px rgba(0,0,0,.3);
      touch-action: none;
      user-select: none;
      cursor: grab;
    `;

    const pos = loadPos();
    if (pos) {
      btn.style.left = pos.x + 'px';
      btn.style.top = pos.y + 'px';
    } else {
      btn.style.bottom = '20px';
      btn.style.right = '20px';
    }

    let dragging = false;
    let moved = false;
    let startX, startY, origX, origY;

    btn.addEventListener('pointerdown', (e) => {
      dragging = true;
      moved = false;
      btn.setPointerCapture(e.pointerId);
      const rect = btn.getBoundingClientRect();
      origX = rect.left;
      origY = rect.top;
      startX = e.clientX;
      startY = e.clientY;
      btn.style.left = origX + 'px';
      btn.style.top = origY + 'px';
      btn.style.right = 'auto';
      btn.style.bottom = 'auto';
      btn.style.cursor = 'grabbing';
    });

    btn.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) moved = true;
      let x = origX + dx;
      let y = origY + dy;
      x = Math.max(0, Math.min(window.innerWidth - btn.offsetWidth, x));
      y = Math.max(0, Math.min(window.innerHeight - btn.offsetHeight, y));
      btn.style.left = x + 'px';
      btn.style.top = y + 'px';
    });

    btn.addEventListener('pointerup', (e) => {
      if (!dragging) return;
      dragging = false;
      btn.style.cursor = 'grab';
      if (moved) {
        e.preventDefault();
        savePos(parseFloat(btn.style.left), parseFloat(btn.style.top));
      }
    });

    btn.addEventListener('click', (e) => {
      if (moved) e.preventDefault();
    });

    document.body.appendChild(btn);
  }

  addButton();
  new MutationObserver(addButton).observe(document.body, { childList: true, subtree: true });
})();
