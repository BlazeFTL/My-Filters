// ==UserScript==
// @name         StashBay.com All-in-One
// @namespace    BlazeFTL
// @version      2.0
// @match        *://povathemes.com/*
// @match        *://stsh.in/*
// @run-at       document-start
// @inject-into  page
// @grant        none
// ==/UserScript==

(() => {
  const BOOST = 1;

  const def = (o, k, v) => {
    try {
      Object.defineProperty(o, k, { get: () => v, configurable: true });
    } catch {}
  };
  for (const o of [Document.prototype, document]) {
    def(o, 'hidden', false);
    def(o, 'visibilityState', 'visible');
    def(o, 'webkitHidden', false);
    def(o, 'webkitVisibilityState', 'visible');
  }
  try {
    document.hasFocus = () => true;
  } catch {}
  const stop = e => e.stopImmediatePropagation();
  window.addEventListener('visibilitychange', stop, true);
  document.addEventListener('visibilitychange', stop, true);
  window.addEventListener('pagehide', stop, true);
  window.addEventListener('blur', stop, true);

  const realRaf = window.requestAnimationFrame.bind(window);
  window.requestAnimationFrame = cb => {
    let done = false;
    const run = t => {
      if (done) return;
      done = true;
      cb(t);
    };
    const id = realRaf(run);
    setTimeout(() => run(performance.now()), 50);
    return id;
  };

  if (BOOST !== 1) {
    const realNow = performance.now.bind(performance);
    const t0 = realNow();
    performance.now = () => t0 + (realNow() - t0) * BOOST;
  }

  let clicks = 0;
  let last = 0;
  let stopTicker = () => {};

  const tick = () => {
    const btn = document.getElementById('hop-continue');
    if (!btn || btn.disabled) return;
    const gate = document.getElementById('hop-gate');
    if (!gate || gate.hidden) return;
    const tm = document.getElementById('hop-gate-timer');
    if (tm && !tm.hidden) return;
    const wait = ((parseInt(gate.dataset.timerSeconds, 10) || 10) + 1) * 1000;
    if (performance.now() < wait) return;
    if (getComputedStyle(btn).pointerEvents === 'none') return;
    if (Date.now() - last < 4000) return;
    if (clicks >= 5) {
      stopTicker();
      return;
    }
    last = Date.now();
    clicks++;
    window.scrollTo(0, document.body.scrollHeight);
    btn.click();
  };

  const fallback = () => {
    const iv = setInterval(tick, 1000);
    stopTicker = () => clearInterval(iv);
  };

  try {
    const w = new Worker(
      URL.createObjectURL(
        new Blob(['setInterval(()=>postMessage(0),500)'], { type: 'text/javascript' })
      )
    );
    w.onmessage = tick;
    w.onerror = () => {
      w.terminate();
      fallback();
    };
    stopTicker = () => w.terminate();
  } catch {
    fallback();
  }
})();
