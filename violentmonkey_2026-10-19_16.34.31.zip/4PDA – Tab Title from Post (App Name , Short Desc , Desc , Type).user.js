// ==UserScript==
// @name         4PDA – Tab Title from Post (App Name , Short Desc , Desc , Type)
// @namespace    4pda-tab-title
// @version      1.1.0
// @description  Rewrites the tab title of a 4pda.to topic to "App Name , Краткое описание , Описание , Тип"
//               of the post linked via #entryXXXXXXX. Works on original Russian AND auto-translated pages.
// @match        *://4pda.to/forum/index.php?*showtopic=*
// @match        *://4pda.ru/forum/index.php?*showtopic=*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=4pda.to
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(() => {
  'use strict';

  /* ---------------- config ---------------- */
  const ORDER = ['short', 'desc', 'type']; // parts of the new title, in order (after app name)
  const SEP   = ' , ';                     // separator between parts
  const WITH_VERSION = false;              // true => append version at the end
  const WITH_APPNAME = true;               // true => prepend app name from topic title

  /* ---------- label -> field (RU original + translated variants) ---------- */
  const classify = (label) => {
    const l = label.toLowerCase();
    if (/^(краткое описание|короткий опис|short description|kurzbeschreibung|description courte|descripción corta)/.test(l)) return 'short';
    if (/^(описание|опис|description|beschreibung|descripción|descrizione)/.test(l))                                    return 'desc';
    if (/^(тип|typ|type|tipo)/.test(l))                                                                                  return 'type';
    if (/^(версия|версія|version|versión|versione)/.test(l))                                                             return 'version';
    return null;
  };

  const clean = (s) => s
    .replace(/^[\s"«»“”']+/, '')
    .replace(/[\s"«»“”']+$/, '')
    .trim();

  /* ---------- app name from .topic_title_post (part before "|") ---------- */
  function appName() {
    const el = document.querySelector('.topic_title_post');
    if (!el) return '';
    const firstLine = (el.textContent || '').split('\n').map(s => s.trim()).find(Boolean) || '';
    const idx = firstLine.indexOf('|');
    return clean(idx !== -1 ? firstLine.slice(0, idx) : firstLine);
  }

  /* ---------- read the fields out of one post body ---------- */
  function extract(body) {
    const fields = {};
    const lines = (body.innerText || '')
      .split('\n').map(l => l.trim()).filter(Boolean);

    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(/^(.{1,60}?)\s*[:：]\s*(.*)$/);   // "Label: value"
      if (!m) continue;
      const key = classify(m[1]);
      if (!key || fields[key]) continue;

      let val = clean(m[2]);
      if (!val && i + 1 < lines.length) val = clean(lines[i + 1]); // value on next line
      if (val) fields[key] = val;
    }
    return fields;
  }

  /* ---------- which post to use? the one from #entryXXXXXXX ---------- */
  function targetPost() {
    const m = location.hash.match(/#entry(\d+)/);
    if (!m) return null;

    const byId = document.getElementById('post-main-' + m[1]);
    if (byId) return byId;

    const a = document.querySelector('a[name="entry' + m[1] + '"]');
    if (a) {
      const wrap = a.closest('div[data-post]');
      const b = wrap && wrap.querySelector('.post_body');
      if (b) return b;
    }
    return null; // anchored post not on this page (pagination)
  }

  function pickBody() {
    const t = targetPost();
    if (t) return t;
    // no anchor (or post not loaded): first post that actually has the fields
    for (const b of document.querySelectorAll('.post_body')) {
      const f = extract(b);
      if (f.short || f.desc || f.type) return b;
    }
    return null;
  }

  /* ---------- build the new tab title ---------- */
  function refresh() {
    const body = pickBody();
    if (!body) return;

    const f = extract(body);
    const keys = WITH_VERSION ? ORDER.concat('version') : ORDER;
    const parts = [];
    if (WITH_APPNAME) {
      const name = appName();
      if (name) parts.push(name);
    }
    parts.push(...keys.map(k => f[k]).filter(Boolean));

    const title = parts.join(SEP);
    if (title && title !== document.title) document.title = title;
  }

  /* ---------- re-run whenever DOM changes (translation, lazy load) ---------- */
  let timer;
  const queue = () => { clearTimeout(timer); timer = setTimeout(refresh, 250); };

  new MutationObserver(queue).observe(document.documentElement, {
    childList: true, subtree: true, characterData: true
  });
  window.addEventListener('hashchange', queue);
  queue();

  /* ---------- fix: post drifts out of view during first seconds after load ---------- */
  // Cause: images/ads/avatars finish loading and reflow the page *without* any DOM
  // mutation, so a MutationObserver never sees it. Poll via rAF instead.
  const SCROLL_OFFSET = 120; // px of breathing room above the post; raise/lower to taste

  function scrollToEntry() {
    const m = location.hash.match(/#entry(\d+)/);
    if (!m) return null;
    const el = document.querySelector('a[name="entry' + m[1] + '"]') ||
               document.getElementById('post-main-' + m[1]);
    if (el) {
      el.scrollIntoView({ block: 'start' });
      window.scrollBy(0, -SCROLL_OFFSET);
    }
    return el;
  }

  function hookImageLoads() {
    document.querySelectorAll('img').forEach((img) => {
      if (!img.complete) {
        img.addEventListener('load', scrollToEntry, { once: true });
        img.addEventListener('error', scrollToEntry, { once: true });
      }
    });
  }

  function armScrollFix(maxMs) {
    hookImageLoads();
    const start = Date.now();
    let lastTop = null, stable = 0;
    const tick = () => {
      const el = scrollToEntry();
      if (el) {
        const top = el.getBoundingClientRect().top;
        stable = (lastTop !== null && Math.abs(top - lastTop) < 1) ? stable + 1 : 0;
        lastTop = top;
      }
      if (stable < 90 && Date.now() - start < maxMs) requestAnimationFrame(tick);
    };
    tick();
  }
  window.addEventListener('hashchange', () => armScrollFix(10000));
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') armScrollFix(10000);
  });
  armScrollFix(10000);
})();
