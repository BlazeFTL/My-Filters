// ==UserScript==
// @name         dropmms Fix Real Links
// @namespace    blazeftl
// @version      1.0
// @match        *://dropmms.net/*
// @match        *://dropmms.co/*
// @icon         data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%2064%2064%22%3E%3Crect%20width=%2264%22%20height=%2264%22%20rx=%2214%22%20fill=%22%231565a8%22/%3E%3Cpath%20d=%22M32%208C32%208%2014%2028%2014%2040a18%2018%200%200%200%2036%200C50%2028%2032%208%2032%208Z%22%20fill=%22%23e6208c%22/%3E%3Cpath%20d=%22M26%2033H31A7.5%207.5%200%200%201%2031%2048H26Z%22%20fill=%22none%22%20stroke=%22%23fff%22%20stroke-width=%224%22%20stroke-linejoin=%22round%22/%3E%3C/svg%3E
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function () {
  'use strict';

  const URL_RE = /https?:\/\/[^\s"<]+/;

  function fixLink(a) {
    if (a.dataset.fixed) return;
    const href = a.getAttribute('href');
    if (href && href !== '#' && href !== 'javascript:void(0)') return;

    const text = a.textContent;
    const m = text.match(URL_RE);
    if (!m) return;

    const real = m[0].replace(/\/+$/, '');
    a.setAttribute('href', real);
    a.dataset.fixed = '1';

    a.addEventListener('click', function (e) {
      e.stopImmediatePropagation();
      e.preventDefault();
      window.open(real, '_blank', 'noopener');
    }, true);
  }

  function scan(root) {
    root.querySelectorAll('a[href="#"], a[href="javascript:void(0)"]').forEach(fixLink);
  }

  scan(document);

  new MutationObserver((muts) => {
    for (const m of muts) {
      for (const n of m.addedNodes) {
        if (n.nodeType === 1) {
          if (n.matches && n.matches('a')) fixLink(n);
          scan(n);
        }
      }
    }
  }).observe(document.body, { childList: true, subtree: true });
})();
