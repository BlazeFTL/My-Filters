// ==UserScript==
// @name         Gofile Clone Download Button
// @namespace    https://github.com/BlazeFTL
// @description  Clones download button to the left of 3-dot menu
// @version      1.1
// @author       BlazeFTL
// @match        *://gofile.io/*
// @icon               https://gofile.io/assets/img/favicon32.png
// @license      MIT
// ==/UserScript==

(() => {
    'use strict';

    function cloneDownloadBtn() {
        const menuBtn = document.querySelector('button[data-action="item-menu"]');
        if (!menuBtn) return;

        const container = menuBtn.parentElement;
        if (!container || container.querySelector('.cloned-dl-btn')) return;

        let originalBtn = container.querySelector('button[data-action="download"]');
        let newBtn;

        if (originalBtn) {
            newBtn = originalBtn.cloneNode(true);
            newBtn.classList.remove('hidden', 'lg:inline-flex');
            newBtn.classList.add('inline-flex', 'cloned-dl-btn');
        } else {
            newBtn = document.createElement('button');
            newBtn.type = 'button';
            newBtn.title = 'Download';
            newBtn.className = 'btn-secondary inline-flex !px-2.5 !py-1 text-xs cloned-dl-btn';
            newBtn.textContent = 'Download';
            newBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                menuBtn.click();
                setTimeout(() => {
                    const dropdownDl = Array.from(document.querySelectorAll('div[role="menu"] button[role="menuitem"]'))
                        .find(btn => btn.textContent.includes('Download'));
                    if (dropdownDl) dropdownDl.click();
                }, 50);
            });
        }

        container.insertBefore(newBtn, menuBtn);
    }

    const observer = new MutationObserver(cloneDownloadBtn);
    observer.observe(document.body, { childList: true, subtree: true });
    cloneDownloadBtn();
})();
