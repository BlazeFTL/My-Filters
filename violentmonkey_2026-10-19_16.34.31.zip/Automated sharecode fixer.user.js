// ==UserScript==
// @name         Automated sharecode fixer
// @namespace    https://nsaneforums.com/
// @version      1.4.8
// @description  A sharecode fixer that hyperlinks the fixed links directly in the browser without any user interaction required. More info at https://nsaneforums.com/topic/378180-sharecode-fixer-and-generator-by-bl4ckcyb3renigm4/
// @author       Bl4ckCyb3rEnigm4 at https://nsaneforums.com/profile/117489-bl4ckcyb3renigm4/
// @match        https://nsaneforums.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=nsaneforums.com
// @grant        none
// @homepageURL  https://nsaneforums.com/topic/378180-sharecode-fixer-and-generator-by-bl4ckcyb3renigm4/
// ==/UserScript==

//Changes:
//    - Solved a bug when fixing links
//    - Added the sharecoding(site and sharecode regenerated) of the fixed link and removing the button to copy the password when mentioning a post

(function() {
    (async () => {
            var dereferrer="https://refhide.com/?";

            //Change this variable to:
            //true - if you want to open a new tab when you click on the fixed link
            //false - if you want to open the fixed link in the current tab WITHOUT opening a new tab
            //DEFAULT: true
            var Newpage=true;

            //Change this variable to:
            //true - if you use a download manager and so you prefer not having the "Fixed link: " on the left of the fixed link
            //false - if you want to keep the "Fixed link: " on the left of the fixed link
            //DEFAULT: false
            var DownMan=false;

            //Change this variable to:
            //true - if you want to have a quick way to copy the link by using a button on the side of the fixed links
            //false - if you want no button to be on the side of the links
            //DEFAULT: true
            var Easycopy=true;

            //Change this variable to:
            //true - if you want the button for copying the link to display the copy icon
            //false - if you want the button for copying the link to display "Copy"
            //DEFAULT: true
            var CopyIcon=true;

            //Change this variable to:
            //true - if you want the button for copying the link to display the "Copy" text
            //false - if you want the button for copying the link to display no text
            //DEFAULT: true
            var CopyText=true;

            //Change this variable to:
            //L - if you want the button to be on the left of the fixed link
            //R - if you want the button to be on the right of the fixed link
            //DEFAULT: "L"
            var ButtonPos="L";

            //Change this variable to:
            //true - if you want to remove the links that point to the sharecode's topic
            //       and to this script's topic([!] [?])
            //false - if you want to remove them
            //DEFAULT: true
            var informationLinks=true;

            //Change this variable to:
            //true - if you want to have a quick way to copy the password listed on the topic
            //false - if you want no button to be on the side of the passwords
            //DEFAULT: true
            var EasycopyPWD=true;

            //Change this variable to:
            //true - if you want the button for copying the password to display the copy icon
            //false - if you want the button for copying the password to display "Copy"
            //DEFAULT: true
            var CopyPWDIcon=true;

            //Change this variable to:
            //true - if you want the button for copying the password to display the "Copy" text
            //false - if you want the button for copying the password to display no text
            //DEFAULT: true
            var CopyPWDText=true;

            //Change this variable to:
            //true - if you want two buttons, added in the top right corner, to fix
            //       sharecoded links that aren't fixed automatically by the
            //       script(special cases)
            //       Usage: Select the sharecoded link and press the button
            //       "Open fixed link" or "Copy fixed link" in the top right corner
            //false - if you want no button to fix special cases
            //DEFAULT: true
            var ManFix=true;

            //Change this variable to:
            //The time, in milliseconds (thousandths of a second), the scripts should
            //wait between checks, to see if you changed the page on a topic
            //Lower is better()
            //0.1 sec=100 milliseconds
            //0.2 sec=200 milliseconds
            //0.5 sec=500 milliseconds
            //1 sec=1000 milliseconds
            //DEFAULT: 250
            var CheckDelay=250;



            //Change this variable to:
            //true - if you want to apply a custom CSS to fixed links
            //false - if you don't want to apply a custom CSS to fixed links
            //DEFAULT: false
            var CustomLinkCSS=false;

            //Edit the following CSS style to change how links are
            //displayed
            //For reference: https://www.w3schools.com/Css/css_intro.asp
            var CustomLinkCSSStyle=`.customLink {
                  color: green;
                  font-weight: bold;
                }`;

            var Settings=[Newpage, DownMan, Easycopy, ButtonPos, CopyIcon, CopyText, dereferrer, informationLinks, EasycopyPWD, CopyPWDIcon, CopyPWDText, CustomLinkCSS];



            var Elem=document.createElement('style');
            Elem.innerText=`.buttonPadding {
                  margin-top: 0.25%;
                  margin-bottom: 0.25%;
                }`;
            document.head.appendChild(Elem);

            if (Easycopy || ManFix || EasycopyPWD) {
                    var Elem=document.createElement('script');
                    Elem.text="function Copytoclip(text, notification) {if(notification=='Notification'){text=decodeURIComponent(text);};var Elem=document.createElement('textarea');Elem.value=text;document.body.appendChild(Elem);Elem.select();document.execCommand('copy');document.body.removeChild(Elem);document.getElementById(notification).classList.toggle('fade');setTimeout(function() {document.getElementById(notification).classList.toggle('fade');}, 3000);}";
                    document.body.appendChild(Elem);
            }

            if (ManFix) {
                    var Elem=document.createElement('script');
                    Elem.text="function ManFix(n){var LINK='';var Selvar=window.getSelection().toString();var i=1;var SelAr=Selvar.split(/\\r\\n|\\r|\\n/g, 3);function f(){window.open('"+Settings[6]+"'+LINK.replace('#', '%23').replace('?', '%3F').replace('&', '%26'));};if (SelAr[1].replace(/ /g,'')==''){i=2};if (Selvar.indexOf('http')!=-1){LINK='http'+Selvar.split('http', 2)[1].split(/\\r\\n|\\r|\\n/g, 2)[0]+SelAr[i].slice(SelAr[i].indexOf('/'), SelAr[i].length);}else{LINK='http://'+Selvar.split(' ', 2)[1].split(/\\r\\n|\\r|\\n/g, 2)[0]+SelAr[i].slice(SelAr[i].indexOf('/'), SelAr[i].length);};if(n==0){f();}else if (n==1){Copytoclip(LINK, 'Notification');};}";
                    document.body.appendChild(Elem);
                    document.getElementById('elUserNav').innerHTML='<li><button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="ManFix(1)">Copy fixed link</button></li><li><button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="ManFix(0)">Open fixed link</button></li>'+document.getElementById('elUserNav').innerHTML;

            }
            if (Easycopy || ManFix) {
                 var Elem=document.createElement('style');
                 Elem.innerText=`#Notification {
                   pointer-events: none;
                   opacity: 1;
                   transition: opacity 1s;
                 }

                 #Notification.fade {
                   opacity: 0;
                 }`;
                 document.head.appendChild(Elem);

                 var Elem=document.createElement('div');
                 Elem.id="Notification";
                 document.body.appendChild(Elem);
                 Notification=document.getElementById("Notification");
                 Notification.classList.toggle('fade');

                 Notification.innerHTML="<div><h3>Link copied to the clipboard</h3></div>";
                 Notification.classList.add('ipsMenu');
                 Notification.classList.add('ipsMenu_auto');
                 Notification.classList.add('ipsHide');
                 Notification.classList.add('ipsMenu_bottomCenter');

                 Notification.style.margin="auto";
                 Notification.style.position="fixed";
                 Notification.style.left="10%";
                 Notification.style.right="10%";
                 Notification.style.bottom="5%";
                 Notification.style.zIndex="5500";
                 Notification.style.display="block";
                 Notification.style.textAlign="center";
                 Notification.style.verticalAlign="middle";



            }

            if(EasycopyPWD){
                var Elem=document.createElement('style');
                 Elem.innerText=`#NotificationPWD {
                   pointer-events: none;
                   opacity: 1;
                   transition: opacity 1s;
                 }

                 #NotificationPWD.fade {
                   opacity: 0;
                 }`;
                 document.head.appendChild(Elem);

                 var Elem=document.createElement('div');
                 Elem.id="NotificationPWD";
                 document.body.appendChild(Elem);
                 Notification=document.getElementById("NotificationPWD");
                 Notification.classList.toggle('fade');

                 Notification.innerHTML="<div><h3>Password copied to the clipboard</h3></div>";
                 Notification.classList.add('ipsMenu');
                 Notification.classList.add('ipsMenu_auto');
                 Notification.classList.add('ipsHide');
                 Notification.classList.add('ipsMenu_bottomCenter');

                 Notification.style.margin="auto";
                 Notification.style.position="fixed";
                 Notification.style.left="10%";
                 Notification.style.right="10%";
                 Notification.style.bottom="5%";
                 Notification.style.zIndex="5500";
                 Notification.style.display="block";
                 Notification.style.textAlign="center";
                 Notification.style.verticalAlign="middle";
            }

            if (CustomLinkCSS){
                var Elem=document.createElement('style');
                Elem.innerText=CustomLinkCSSStyle;
                document.head.appendChild(Elem);
            }

            wait('.cke_editable').then((elm) => {
                var editor = document.querySelector(".cke_editable");
                var observer = new MutationObserver(restore);
                var mutationConfig = { attributes: true, childList: true, subtree: true, characterData: true };
                observer.observe(editor, mutationConfig);
            });

            if (window.location.href.indexOf("https://nsaneforums.com/topic/378180-sharecode-fixer-and-generator-by-bl4ckcyb3renigm4/")!=-1){
                var Elem=document.createElement('script');
                    Elem.text="function CopyScripttoclip(text) {text=document.getElementById(text).textContent;var Elem=document.createElement('textarea');Elem.value=text;document.body.appendChild(Elem);Elem.select();document.execCommand('copy');document.body.removeChild(Elem);document.getElementById('NotificationScript').classList.toggle('fade');setTimeout(function() {document.getElementById('NotificationScript').classList.toggle('fade');}, 3000);}";
                    document.body.appendChild(Elem);
                var Elem=document.createElement('style');
                 Elem.innerText=`#NotificationScript {
                   opacity: 1;
                   transition: opacity 1s;
                 }

                 #NotificationScript.fade {
                   opacity: 0;
                 }`;
                 document.head.appendChild(Elem);

                 var Elem=document.createElement('div');
                 Elem.id="NotificationScript";
                 document.body.appendChild(Elem);
                 Notification=document.getElementById("NotificationScript");
                 Notification.classList.toggle('fade');

                 Notification.innerHTML="<div><h3>Script copied to the clipboard</h3></div>";
                 Notification.classList.add('ipsMenu');
                 Notification.classList.add('ipsMenu_auto');
                 Notification.classList.add('ipsHide');
                 Notification.classList.add('ipsMenu_bottomCenter');

                 Notification.style.margin="auto";
                 Notification.style.position="fixed";
                 Notification.style.left="10%";
                 Notification.style.right="10%";
                 Notification.style.bottom="5%";
                 Notification.style.zIndex="5500";
                 Notification.style.display="block";
                 Notification.style.textAlign="center";
                 Notification.style.verticalAlign="middle";
                 let currentPage = location.href;
                    var loadingStarted=false;
                    var loadingEnded=false;
                    setInterval(function()
                        {
                                if (currentPage !=location.href){
                                try {
                                        var checkLoading=document.getElementById("elAjaxLoading").style["display"];
                                }
                                catch {
                                        var checkLoading="none";
                                }
                                //Loading started
                                if(checkLoading=="" && !loadingStarted && !loadingEnded)
                                {
                                        loadingStarted=true;
                                }

                                if(checkLoading=="none" && loadingStarted && !loadingEnded) {
                                        loadingEnded=true;
                                }
                                if(loadingStarted && loadingEnded)
                                {
                                        easycopyscript(Settings);
                                        currentPage=location.href;
                                        loadingStarted=false;
                                        loadingEnded=false;
                                }
                        }
                        }, CheckDelay);
                easycopyscript(Settings);
            }
            if (window.location.href.indexOf("https://nsaneforums.com/topic/378180-sharecode-fixer-and-generator-by-bl4ckcyb3renigm4/")==-1){
                var childold="";
            var lineold="";
            var posts=document.getElementsByClassName("cPost_contentWrap");
            checkeverypost(posts, Settings, childold, lineold)
            let currentPage = location.href;
            var loadingStarted=false;
            var loadingEnded=false;
            setInterval(function()
                {
                        if (currentPage !=location.href){
                        wait('.cke_editable').then((elm) => {
                            var editor = document.querySelector(".cke_editable");
                            var observer = new MutationObserver(restore);
                            var mutationConfig = { attributes: true, childList: true, subtree: true, characterData: true };
                            observer.observe(editor, mutationConfig);
                        });
                        try {
                                var checkLoading=document.getElementById("elAjaxLoading").style["display"];
                        }
                        catch {
                                var checkLoading="none";
                        }

                        if(checkLoading=="" && !loadingStarted && !loadingEnded)
                        {
                                loadingStarted=true;
                        }

                        if(checkLoading=="none" && loadingStarted && !loadingEnded) {
                                loadingEnded=true;
                        }
                        if(loadingStarted && loadingEnded)
                        {
                                var childold="";
                                var lineold="";
                                var posts=document.getElementsByClassName("cPost_contentWrap");
                                checkeverypost(posts, Settings, childold, lineold)
                                currentPage = location.href;
                                loadingStarted=false;
                                loadingEnded=false;
                        }
                }
                }, CheckDelay);
            }
    })();
})();

async function easycopyscript(Settings) {
        var posts=document.getElementsByClassName("ipsComment");
        for(var i1=0; i1<posts.length; i1++){
               if (posts[i1].getElementsByClassName("cAuthorPane_author")[0].textContent.indexOf("Bl4ckCyb3rEnigm4")!=-1){
                spoilers=posts[i1].getElementsByClassName("cPost_contentWrap")[0].getElementsByClassName("ipsCode prettyprint");
                if (spoilers.length>0){
                        for(var i2=0; i2<spoilers.length; i2++){
                                if(spoilers[i2].innerHTML.indexOf("// ==UserScript==")!=1) {
                                      var scriptId="script"+i1.toString()+i2.toString();
                                      spoilers[i2].id=scriptId;
                                        button=document.createElement("span");
                                        button.innerHTML='<button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="CopyScripttoclip('+"'"+scriptId+"'"+')">' + (Settings[4] ? '<i class="fa fa-copy"></i>' : '') + ' ' + (Settings[5] ? 'Copy the below script' : '') +' '+ (Settings[4] ? '<i class="fa fa-code"></i>' : '') +'</button>';
                                        spoilers[i2].parentNode.parentNode.insertAdjacentElement('beforebegin', button);
                                }
                        }
                }
               }
        }
}


async function divcheck(divs, Settings, childold, lineold) {
        for(var i3=divs.length-1; i3>-1; i3--){
                check(divs[i3], Settings, childold, lineold)
        }
}

async function checkeverypost(posts, Settings, childold, lineold) {
        var post="";
        var spoilers;
        for(var i1=0; i1<posts.length; i1++){
                post=posts[i1].getElementsByClassName("ipsType_normal ipsType_richText ipsPadding_bottom ipsContained")[0];
                if (post.getElementsByClassName("ipsSpoiler_contents ipsClearfix").length>0) {
                        spoilers=post.getElementsByClassName("ipsSpoiler_contents ipsClearfix");
                        for(var i2=0; i2<spoilers.length; i2++){
                                if (spoilers[i2].getElementsByClassName("ipsSpoiler_contents ipsClearfix").length>0) {
                                        check(spoilers[i2].getElementsByClassName("ipsSpoiler_contents ipsClearfix")[0], Settings, childold, lineold);
                                }
                                else {
                                        check(spoilers[i2], Settings, childold, lineold);
                                }
                        }
                }
                if (post.getElementsByTagName("div").length>0) {
                        divcheck(post.getElementsByTagName("div"), Settings, childold, lineold);
                }
                check(post, Settings, childold, lineold);
        }
}

function sanitize(string){
        return string.replace(" ", " ").replace("&nbsp;", "").replace("</span>", "").replace(" ", "").replace("<span>", "").replace("</em>", "").replace("<em>", "").replace("</b>", "").replace("<strong>", "").replace("</strong>", "");
}

async function check(postcontent, Settings, childold, lineold) {
        var children = postcontent.children;
        var child;
        var site="";
        var sharecode="";
        var sitelink="";
        var childTEXT="";
        var oldELEM=-1;
        var lines;
        var newlines="";
        var prevData="";
        var reSite = /site(.*?):/i;
        var reSharecode = /sharecode(.*?):(?<!https:)(?<!color:)(?<!vertical-align:)/i;
        var firstmatch=-1;
        var pwdDelimiterS=[/pwd(.*?):\s*/i, /password(.*?):\s*/i, /pass(.*?):\s*/i, /pw(.*?):\s*/i];
        var pwdDelimiter="";
        var password="";
        for(var i=0; i<children.length; i++){
                if (firstmatch!=-1 && i-firstmatch>2){
                        firstmatch=-1;
                        site=="";
                        siteDelimiter="";
                }
                child=children[i];
                childTEXT=child.textContent.replace(" ", " ");
                if (child.innerHTML.split("</p>").length>1 && child.innerHTML.split("</p>").length>child.innerHTML.split("<br>").length && !(child.innerHTML.split('onclick="Copytoclip(').length>1)) {
                        newlines="";
                        lines=child.innerHTML.split("</p>");
                        for(var i5=0; i5<lines.length; i5++){
                                if (firstmatch!=-1 && i5-firstmatch>2){
                                        firstmatch=-1;
                                        site=="";
                                        siteDelimiter="";
                                }
                                if (Settings[8]) {
                                        password="";
                                        for(var iPwd=0; iPwd<pwdDelimiterS.length; iPwd++){
                                                try{
                                                        pwdDelimiter=pwdDelimiterS[iPwd].exec(lines[i5])[0];
                                                        iPwd=pwdDelimiterS.length;
                                                        password=lines[i5].split(pwdDelimiter)[1].replace(/(\r\n|\n|\r)/gm, "");
                                                        if (password.split(' ').length>1){
                                                            password="";
                                                            pwdDelimiter="";
                                                        }
                                                        else {
                                                            var newlines="";
                                                            prevNextData=lines[i5].split(pwdDelimiter);
                                                            lines[i5]=prevNextData[0]+'<button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="Copytoclip('+"'"+password+"', 'NotificationPWD'"+')">' + (Settings[9] ? '<i class="fa fa-key"></i>' : '') + ' ' + (Settings[10] ? 'Copy' : '')+'</button>'+prevNextData[1];
                                                            for(i6=0; i6<lines.length; i6++){
                                                                    if (! lines[i6]=="") {
                                                                            newlines+=lines[i6]+"</p>";
                                                                    }
                                                            }
                                                            child.innerHTML=newlines;
                                                            lines=child.innerHTML.split("</p>");
                                                        }
                                                }
                                                catch  {
                                                        password="";
                                                        pwdDelimiter="";
                                                }
                                        }
                                }
                                var siteDelimiter="";
                                var sharecodeDelimiter="";
                                if(siteDelimiter=="" && site=="") {
                                        try{
                                                siteDelimiter = reSite.exec(lines[i5])[0];
                                                if(siteDelimiter=="Site:" || siteDelimiter=="site:") {
                                                        siteDelimiter="";
                                                }
                                                else{
                                                        firstmatch=i5;
                                                }
                                        }
                                        catch  {
                                                siteDelimiter="";
                                        }
                                }
                                if(sharecodeDelimiter=="" && sharecode=="") {
                                        try{
                                                sharecodeDelimiter = reSharecode.exec(lines[i5])[0];
                                                if(sharecodeDelimiter=="Sharecode:" || sharecodeDelimiter=="sharecode:" || sharecodeDelimiter.indexOf("http") != -1) {
                                                        sharecodeDelimiter="";
                                                }
                                        }
                                        catch  {
                                                sharecodeDelimiter="";
                                        }
                                }
                                if (siteDelimiter != "" && site==""){
                                        try{
                                                firstmatch=i5;
                                                site="http"+lines[i5].split(siteDelimiter)[1].split("http")[1].split('"')[0].split("<")[0].replace("&nbsp;", "");
                                                oldELEM=i4;
                                                siteDelimiter=="";
                                        }
                                        catch {
                                                siteDelimiter=="";
                                                site="";
                                        }
                                }
                                if (sharecodeDelimiter!= "" && sharecode==""){
                                        sharecode=sanitize(lines[i5].split(sharecodeDelimiter)[1]);
                                        sharecodeDelimiter="";

                                }
                                if ((lines[i5].indexOf("Site:") != -1 || lines[i5].indexOf("site:") != -1) && site!="") {
                                        site="";
                                }
                                if (lines[i5].indexOf("Site:") != -1 || lines[i5].indexOf("site:") != -1) {
                                        if (lines[i5].indexOf("Site:") != -1) {
                                                firstmatch=i5;
                                              prevData=lines[i5].split("Site:")[0];
                                              lines[i5]="Site:"+lines[i5].split("Site:")[1];
                                        }else if (childTEXT.indexOf("site:") != -1) {
                                                firstmatch=i5;
                                              prevData=lines[i5].split("site:")[0];
                                              lines[i5]="site:"+lines[i5].split("site:")[1];
                                        }
                                        if (lines[i5].indexOf("http") != -1) {
                                                firstmatch=i5;
                                                oldELEM=i5;
                                                site="http"+lines[i5].split("http")[1].split("<")[0].split('"')[0];
                                                sharecode="";
                                        }
                                        else if (lines[i5].indexOf("www") != -1) {
                                                firstmatch=i5;
                                                oldELEM=i5;
                                                site="www"+lines[i5].split("www")[1].split("<")[0].split('"')[0];
                                                sharecode="";
                                        }
                                }

                                if (lines[i5].indexOf("Sharecode") != -1) {
                                        if (lines[i5].split(">").length>1) {
                                                sharecode=lines[i5].split(">");
                                                for(var i6=sharecode.length-1; i6>-1; i6--){
                                                        if (sharecode[i6].split("/").length>1) {
                                                                sharecode=sharecode[i6];
                                                                i6=-1;
                                                        }
                                                        else if (i6==0) {
                                                                sharecode="";
                                                        }
                                                }
                                        }
                                        else {
                                                sharecode=lines[i5].split(":")
                                                if (sharecode[sharecode.length-1]=="\n") {
                                                        sharecode=sharecode[sharecode.length-2];
                                                }
                                                else {
                                                        sharecode=sharecode[sharecode.length-1];
                                                }
                                        }
                                        sharecode=sharecode.replace("&nbsp;", "").replace("</span>", "").replace(" ", "");
                                }
                                if (sharecode!="" && site!="") {
                                        sharecode=sharecode.replace("&nbsp;", "").replace("</span>", "").replace(" ", "").replace(" ", "").split("<")[0];
                                        if (sharecode.split(":").length>1) {
                                                sharecode=sharecode.split(":")[1];
                                        }
                                        site=site.replace("&nbsp;", "").replace("</span>", "").replace(" ", "").replace(" ", "");
                                        if (site.slice(-1)=="/") {
                                                site = site.slice(0, -1);
                                                firstmatch=i5;
                                        }
                                        if (sharecode.slice(0, 1)!="/") {
                                                sharecode="/"+sharecode;
                                        }
                                        if (site.indexOf("http") == -1) {
                                                site="https://"+site+sharecode;
                                                firstmatch=i5;
                                        }
                                        else {
                                                site=site+sharecode;
                                        }
                                        site=site.replace(/\s+/g, '');
                                        if (Settings[2] && Settings[3]=="L") {
                                                sitelink+='<button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="Copytoclip('+"'"+site.replace('#', '%23').replace('?', '%3F').replace('&', '%26')+"', 'Notification'"+')">' + (Settings[4] ? '<i class="fa fa-copy"></i>' : '') + ' ' + (Settings[5] ? 'Copy' : '')+'</button>  ';
                                        }
                                        if (! Settings[1]) {
                                                sitelink+='<b class="fixedText">Fixed link'+(Settings[7] ? '<sup><a href="https://nsaneforums.com/topic/378180-sharecode-fixer-and-generator-by-bl4ckcyb3renigm4/" rel="" target="_blank"><span style="color:#003a7e;"> [!]</span></a></sup><sup><a href="https://nsaneforums.com/topic/21385-how-to-work-with-sharecodes/" rel="" target="_blank"><span style="color:#e74c3c;"> [?]</span></a></sup>' : '')+': </b>';
                                        }
                                        sitelink+='<a class="fixedLink"'+(Settings[11] ? 'class="customLink" ' : '')+'href="'+Settings[6]+site.replace('#', '%23').replace('?', '%3F').replace('&', '%26')+'"';
                                        if (Settings[0]) {
                                                sitelink+=' target="_blank">';
                                        }else {
                                                sitelink+=">";
                                        }
                                        sitelink+=site+"</a>";
                                        if (Settings[2] && Settings[3]=="R") {
                                                sitelink+='  <button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="Copytoclip('+"'"+site.replace('#', '%23').replace('?', '%3F').replace('&', '%26')+"', 'Notification'"+')">'+(Settings[4] ? '<i class="fa fa-copy"></i>' : '') + ' ' + (Settings[5] ? 'Copy' : '')+'</button>';
                                        }

                                        if (prevData.slice(prevData.length-3, prevData.length)=="<b>") {
                                                prevData=prevData.slice(0, prevData.length-3);
                                        }

                                        if (oldELEM!=-1 && oldELEM!=i5){
                                                lines[i5-1]=prevData+" "+sitelink;
                                                lines[i5]="";
                                        }
                                        else {
                                                lines[i5]=prevData+" "+sitelink;
                                        }
                                        oldELEM=-1;
                                        newlines="";
                                        site="";
                                        sharecode="";
                                        sitelink="";
                                        for(i6=0; i6<lines.length; i6++){
                                                if (! lines[i6]=="") {
                                                        newlines+=lines[i6]+"</p>";
                                                }
                                        }
                                        child.innerHTML=newlines;
                                }
                        }
                }
                else if (child.innerHTML.split("<br>").length>1 && !(child.innerHTML.split('onclick="Copytoclip(').length>1)) {
                        newlines="";

                        var siteDelimiter="";
                        var sharecodeDelimiter="";
                        lines=child.innerHTML.split("<br>");
                        for(var i4=0; i4<lines.length; i4++){
                                if (firstmatch!=-1 && i4-firstmatch>2){
                                        firstmatch=-1;
                                        site=="";
                                        siteDelimiter="";
                                }
                                if (Settings[8]) {
                                        for(var iPwd=0; iPwd<pwdDelimiterS.length; iPwd++){
                                                try{
                                                        pwdDelimiter=pwdDelimiterS[iPwd].exec(lines[i4])[0];
                                                        iPwd=pwdDelimiterS.length;
                                                        password=lines[i4].split(pwdDelimiter)[1].replace(/(\r\n|\n|\r)/gm, "");
                                                        if (password.split(' ').length>1){
                                                            password="";
                                                            pwdDelimiter="";
                                                        }
                                                        else {
                                                            var newlines="";
                                                            prevNextData=lines[i4].split(pwdDelimiter);
                                                            lines[i4]=prevNextData[0]+'<button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="Copytoclip('+"'"+password+"', 'NotificationPWD'"+')">' + (Settings[9] ? '<i class="fa fa-key"></i>' : '') + ' ' + (Settings[10] ? 'Copy' : '')+'</button>'+prevNextData[1];
                                                            for(i4=0; i4<lines.length; i4++){
                                                                    if (! lines[i4]=="") {
                                                                            newlines+=lines[i4]+"<br>";
                                                                    }
                                                            }
                                                            child.innerHTML=newlines;
                                                            lines=child.innerHTML.split("<br>");
                                                            childTEXT=child.textContent.replace(" ", " ");
                                                        }
                                                }
                                                catch  {
                                                        password="";
                                                        pwdDelimiter="";
                                                }
                                        }
                                }
                                if ((lines[i4].indexOf("Site:") != -1 || lines[i4].indexOf("site:") != -1) && site!="") {
                                        site="";
                                }
                                if(siteDelimiter=="" && site=="") {
                                        try{
                                                siteDelimiter = reSite.exec(lines[i4])[0];
                                                if(siteDelimiter=="Site:" || siteDelimiter=="site:") {
                                                        siteDelimiter="";
                                                }else{
                                                        firstmatch=i4;
                                                }
                                        }
                                        catch  {
                                                siteDelimiter="";
                                        }
                                }
                                if(sharecodeDelimiter=="" && sharecode=="") {
                                        try{
                                                sharecodeDelimiter = reSharecode.exec(lines[i4])[0];
                                                if(sharecodeDelimiter=="Sharecode:" || sharecodeDelimiter=="sharecode:" || sharecodeDelimiter.indexOf("http") != -1) {
                                                        sharecodeDelimiter="";
                                                }
                                        }
                                        catch  {
                                                sharecodeDelimiter="";
                                        }
                                }
                                if (siteDelimiter != "" && site==""){
                                        try{
                                                site="http"+lines[i4].split(siteDelimiter)[1].split("http")[1].split('"')[0].split("<")[0].replace("&nbsp;", "");
                                                oldELEM=i4;
                                                siteDelimiter=="";
                                                firstmatch=i4;
                                        }
                                        catch {
                                                siteDelimiter=="";
                                                site="";
                                        }

                                }
                                if (sharecodeDelimiter!= "" && sharecode==""){
                                        sharecode=sanitize(lines[i4].split(sharecodeDelimiter)[1]);
                                        sharecodeDelimiter="";
                                }

                                if (site=="" && (lines[i4].indexOf("Site:") != -1 || lines[i4].indexOf("site:") != -1)) {
                                        if (lines[i4].indexOf("Site:") != -1) {
                                                prevData=lines[i4].split("Site:")[0];
                                                lines[i4]="Site:"+lines[i4].split("Site:")[1];
                                                firstmatch=i4;
                                        }else if (lines[i4].indexOf("site:") != -1) {
                                                prevData=lines[i4].split("site:")[0];
                                                lines[i4]="site:"+lines[i4].split("site:")[1];
                                                firstmatch=i4;
                                        }
                                        if (lines[i4].indexOf("http") != -1) {
                                                oldELEM=i4;
                                                site="http"+lines[i4].split("http")[1].split("<")[0].split('"')[0];
                                                sharecode="";
                                                firstmatch=i4;
                                        }
                                        else if (lines[i4].indexOf("www") != -1) {
                                                oldELEM=i4;
                                                site="www"+lines[i4].split("www")[1].split("<")[0].split('"')[0];
                                                sharecode="";
                                                firstmatch=i4;
                                        }
                                }
                                if (sharecode=="" && lines[i4].indexOf("Sharecode") != -1) {
                                        if (lines[i4].split(">").length>1) {
                                                sharecode=lines[i4].split(">");
                                                for(i6=sharecode.length-1; i6>-1; i6--){
                                                        if (sharecode[i6].split("/").length>1) {
                                                                sharecode=sharecode[i6];
                                                                i6=-1;
                                                        }
                                                        else if (i6==0) {
                                                                sharecode="";
                                                        }
                                                }
                                        }
                                        else {
                                                sharecode=lines[i4].split(":")
                                                sharecode=sharecode[sharecode.length-1];
                                        }
                                }
                                if (sharecode!="" && site!="") {
                                        sharecode=sharecode.replace("&nbsp;", "").replace("</span>", "").replace(" ", "").replace(" ", "").split("<")[0];
                                        if (sharecode.split(":").length>1) {
                                                sharecode=sharecode.split(":")[1];
                                        }
                                        site=site.replace("&nbsp;", "").replace("</span>", "").replace(" ", "").replace(" ", "");
                                        if (site.slice(-1)=="/") {
                                                site = site.slice(0, -1);
                                                firstmatch=i4;
                                        }
                                        if (sharecode.slice(0, 1)!="/") {
                                                sharecode="/"+sharecode;
                                        }
                                        if (site.indexOf("http") == -1) {
                                                site="https://"+site+sharecode;
                                                firstmatch=i4;
                                        }
                                        else {
                                                site=site+sharecode;
                                        }
                                        site=site.replace(/\s+/g, '');
                                        if (Settings[2] && Settings[3]=="L") {
                                                sitelink+='<button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="Copytoclip('+"'"+site.replace('#', '%23').replace('?', '%3F').replace('&', '%26')+"', 'Notification'"+')">'+(Settings[4] ? '<i class="fa fa-copy"></i>' : '') + ' ' + (Settings[5] ? 'Copy' : '')+'</button>  ';
                                        }
                                        if (! Settings[1]) {
                                                sitelink+='<b class="fixedText">Fixed link'+(Settings[7] ? '<sup><a href="https://nsaneforums.com/topic/378180-sharecode-fixer-and-generator-by-bl4ckcyb3renigm4/" rel="" target="_blank"><span style="color:#003a7e;"> [!]</span></a></sup><sup><a href="https://nsaneforums.com/topic/21385-how-to-work-with-sharecodes/" rel="" target="_blank"><span style="color:#e74c3c;"> [?]</span></a></sup>' : '')+': </b>';
                                        }
                                        sitelink+='<a class="fixedLink"'+(Settings[11] ? 'class="customLink" ' : '')+'href="'+Settings[6]+site.replace('#', '%23').replace('?', '%3F').replace('&', '%26')+'"';
                                        if (Settings[0]) {
                                                sitelink+=' target="_blank">';
                                        }else {
                                                sitelink+=">";
                                        }
                                        sitelink+=site+"</a>";
                                        if (Settings[2] && Settings[3]=="R") {
                                                sitelink+='  <button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="Copytoclip('+"'"+site.replace('#', '%23').replace('?', '%3F').replace('&', '%26')+"', 'Notification'"+')">'+(Settings[4] ? '<i class="fa fa-copy"></i>' : '') + ' ' + (Settings[5] ? 'Copy' : '')+'</button>';
                                        }

                                        if (prevData.slice(prevData.length-3, prevData.length)=="<b>") {
                                                prevData=prevData.slice(0, prevData.length-3);
                                        }

                                        if (oldELEM!=-1 && oldELEM!=i4){
                                                lines[i4-1]=prevData+" "+sitelink;
                                                lines[i4]="";
                                        }
                                        else {
                                                lines[i4]=prevData+" "+sitelink;
                                        }
                                        oldELEM=-1;
                                        newlines="";
                                        site="";
                                        sharecode="";
                                        sitelink="";

                                        siteDelimiter="";
                                        sharecodeDelimiter="";
                                }
                        }
                        newlines="";
                        for(i4=0; i4<lines.length; i4++){
                                                if (! lines[i4]=="") {
                                                        newlines+=lines[i4]+"<br>";
                                                }
                                        }
                                        child.innerHTML=newlines;
                }
                else if (childTEXT.indexOf("Site:") != -1 || childTEXT.indexOf("site:") != -1) {
                        if (childTEXT.indexOf("Site:") != -1) {
                                prevData=childTEXT.split("Site:")[0];
                                childTEXT="Site:"+childTEXT.split("Site:")[1];
                                firstmatch=i;
                        }else if (childTEXT.indexOf("site:") != -1) {
                                prevData=childTEXT.split("site:")[0];
                                childTEXT="site:"+childTEXT.split("site:")[1];
                                firstmatch=i;
                        }

                        if (childTEXT.indexOf("http") != -1) {
                                childold=child;
                                site=childTEXT.split("http")[1].split("\n")[0];
                                if (site.split("<").length>1) {
                                        site=site.split("<");
                                        site=site[site.length-2];
                                }
                                site="http"+site;
                                sharecode="";
                                firstmatch=i;
                        }
                        else if (childTEXT.indexOf("www") != -1) {
                                childold=child;
                                site=childTEXT.split("www")[1].split("\n")[0];
                                if (site.split("<").length>1) {
                                        site=site.split("<");
                                        site=site[site.length-2];
                                }
                                site="www"+site;
                                sharecode="";
                                firstmatch=i;
                        }

                        if (site.indexOf("Sharecode [?") != -1) {
                                site=site.split("Sharecode [?")[0];
                        }else if (site.indexOf("Sharecode:") != -1) {
                                site=site.split("Sharecode:")[0];
                        }else if (site.indexOf("sharecode:") != -1) {
                                site=site.split("sharecode:")[0];
                        }else if (site.indexOf("sharecode [?") != -1) {
                                site=site.split("sharecode [?")[0];
                        }else if (site.indexOf("Sharecode") != -1) {
                                site=site.split("Sharecode")[0];
                        }else if (site.indexOf("sharecode") != -1) {
                                site=site.split("sharecode")[0];
                        }
                }
                if (Settings[8] && !(child.innerHTML.split('onclick="Copytoclip(').length>1)) {
                        for(var iPwd=0; iPwd<pwdDelimiterS.length; iPwd++){
                                try{
                                        pwdDelimiter=pwdDelimiterS[iPwd].exec(childTEXT)[0];
                                        iPwd=pwdDelimiterS.length;
                                        password=childTEXT.split(pwdDelimiter)[1].replace(/(\r\n|\n|\r)/gm, "");
                                        if (password.split(' ').length>1){
                                            password="";
                                            pwdDelimiter="";
                                        }
                                        else {
                                            var pwdbutton='<button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="Copytoclip('+"'"+password+"', 'NotificationPWD'"+')">' + (Settings[9] ? '<i class="fa fa-key"></i>' : '') + ' ' + (Settings[10] ? 'Copy' : '')+'</button>  ';
                                            prevNextData=childTEXT.split(pwdDelimiter);
                                            child.innerHTML=prevNextData[0]+pwdbutton+prevNextData[1];
                                            childTEXT=child.textContent.replace(" ", " ");
                                        }
                                }
                                catch  {
                                        password="";
                                        pwdDelimiter="";
                                }
                        }
                }
                if (childTEXT.indexOf("Sharecode [?") != -1) {
                        sharecode=childTEXT.split("Sharecode [?")[1].split(":")[1].split("\n")[0];
                }else if (childTEXT.indexOf("Sharecode:") != -1) {
                        sharecode=childTEXT.split("Sharecode:")[1].split("\n")[0];
                }else if (childTEXT.indexOf("sharecode:") != -1) {
                        sharecode=childTEXT.split("sharecode:")[1].split("\n")[0];
                }else if (childTEXT.indexOf("sharecode [?") != -1) {
                        sharecode=childTEXT.split("sharecode [?")[1].split(":")[1].split("\n")[0];
                }else if (childTEXT.indexOf("Sharecode") != -1) {
                        sharecode=childTEXT.split("Sharecode")[1].split("\n")[0].split(" ")[1];
                }else if (childTEXT.indexOf("sharecode") != -1) {
                        sharecode=childTEXT.split("sharecode")[1].split("\n")[0].split(" ")[1];
                }
                if (sharecode!="" && site!="") {
                        sharecode=sharecode.replace("&nbsp;", "").replace("</span>", "").replace(" ", "").replace(" ", "").replace("//", "").split("<")[0];
                        if (sharecode.split(":").length>1) {
                                sharecode=sharecode.split(":")[1];
                        }
                        site=site.replace("&nbsp;", "").replace("</span>", "").replace(" ", "").replace(" ", "");
                        if (site.slice(-1)=="/") {
                                site = site.slice(0, -1);
                                firstmatch=i;
                        }
                        if (sharecode.slice(0, 1)!="/") {
                                sharecode="/"+sharecode;
                        }
                        if (childold!="") {childold.innerHTML="";}
                        if (site.indexOf("http") == -1) {
                                site="https://"+site+sharecode;
                                firstmatch=i;
                        }
                        else {
                                site=site+sharecode;
                        }
                        site=site.replace(/\s+/g, '');
                        if (Settings[2] && Settings[3]=="L") {
                                sitelink+='<button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="Copytoclip('+"'"+site.replace('#', '%23').replace('?', '%3F').replace('&', '%26')+"', 'Notification'"+')">'+(Settings[4] ? '<i class="fa fa-copy"></i>' : '') + ' ' + (Settings[5] ? 'Copy' : '')+'</button>  ';
                        }
                        if (! Settings[1]) {
                                sitelink+='<b class="fixedText">Fixed link'+(Settings[7] ? '<sup><a href="https://nsaneforums.com/topic/378180-sharecode-fixer-and-generator-by-bl4ckcyb3renigm4/" rel="" target="_blank"><span style="color:#003a7e;"> [!]</span></a></sup><sup><a href="https://nsaneforums.com/topic/21385-how-to-work-with-sharecodes/" rel="" target="_blank"><span style="color:#e74c3c;"> [?]</span></a></sup>' : '')+': </b>';
                        }
                        sitelink+='<a class="fixedLink"'+(Settings[11] ? 'class="customLink" ' : '')+'href="'+Settings[6]+site.replace('#', '%23').replace('?', '%3F').replace('&', '%26')+'"';
                        if (Settings[0]) {
                                sitelink+=' target="_blank">';
                        }else {
                                sitelink+=">";
                        }
                        sitelink+=site+"</a>";
                        if (Settings[2] && Settings[3]=="R") {
                                sitelink+='  <button type="button" class="ipsButton ipsButton_important ipsButton_verySmall buttonPadding" onclick="Copytoclip('+"'"+site.replace('#', '%23').replace('?', '%3F').replace('&', '%26')+"', 'Notification'"+')">'+(Settings[4] ? '<i class="fa fa-copy"></i>' : '') + ' ' + (Settings[5] ? 'Copy' : '')+'</button>';
                        }

                        if (prevData.slice(prevData.length-3, prevData.length)=="<b>") {
                                prevData=prevData.slice(0, prevData.length-3);
                        }

                        child.innerHTML=prevData+" "+sitelink;
                        site="";
                        sharecode="";
                        childold="";
                        sitelink="";
                }
        }
}
async function wait(selector) {
    return new Promise(resolve => {
        if (document.querySelector(selector)) {
            return 0;
        }

        var observer = new MutationObserver(mutations => {
            if (document.querySelector(selector)) {
                observer.disconnect();
                resolve(document.querySelector(selector));
            }
        });
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    });
}

async function restore() {
    var editor = document.querySelector(".cke_editable");
    editor.querySelectorAll(".fixedLink").forEach(generated => {
            var site=generated.text;
            var sharecode=site.slice(site.indexOf("/", 9), site.length);
            site=site.slice(0, site.indexOf("/", 9));
            var newNode = document.createElement("b");
            newNode.innerHTML="Site:";
            generated.parentNode.insertBefore(newNode, generated);

            newNode = document.createTextNode(" ");
            generated.parentNode.insertBefore(newNode, generated);

            newNode = document.createElement("a");
            newNode.setAttribute("href", site);
            newNode.setAttribute("ipsnoembed", "false");
            newNode.setAttribute("rel", "external nofollow noopener");
            newNode.setAttribute("target", "_blank");
            newNode.innerHTML=site;
            generated.parentNode.insertBefore(newNode, generated);

            newNode = document.createElement("br");
            generated.parentNode.insertBefore(newNode, generated);

            newNode = document.createElement("b");
            newNode.innerHTML='Sharecode<sup _title="How to use Sharecode System" data-ipstooltip=""><a href="https://nsaneforums.com/topic/21385-how-to-work-with-sharecodes/" rel="" target="_blank"><span style="color:#e74c3c;"> [?]</span></a></sup>:';
            generated.parentNode.insertBefore(newNode, generated);

            newNode = document.createTextNode(" ");
            generated.parentNode.insertBefore(newNode, generated);

            newNode = document.createTextNode(sharecode);
            generated.parentNode.insertBefore(newNode, generated);

            generated.remove();
        });

        editor.querySelectorAll(".fa-key").forEach(icon => {
            newNode = document.createTextNode("Password: ");
            button=icon.parentNode;
            button.parentNode.insertBefore(newNode, button);
            button.remove();
        });

        editor.querySelectorAll(".fixedText").forEach(generated => {generated.remove();});
        editor.querySelectorAll(".buttonPadding").forEach(generated => {generated.remove();});
}