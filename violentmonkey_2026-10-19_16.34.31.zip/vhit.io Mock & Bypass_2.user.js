// ==UserScript==
// @name         vhit.io Mock & Bypass
// @namespace    blazeftl
// @version      1.3
// @match        *://*.upfilesgo.com/*
// @match        *://*.upfion.com/*
// @match        *://*.upfiles.app/*
// @match        *://*.upfiles-urls.com/*
// @icon          data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAclBMVEVHcEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuN+QrNeUtN+QsNuU7Q+clMOUdKuTFx/f///+bnvF/hO7W1/r5+f8UI+SwsvRQWOkuOOX////p6vwtN+UtN+UtNuUtN+UwNePgPcbzAAAAJnRSTlMA4P+JYy3KQPKocOdQDENZwf/7/v7p8Obi6OD+5ez3/+x7tCXWEG4QoRIAAAEsSURBVHgBrM4HCoBADETRybY0vf91xcIaNCDFRx8+MDhQuVTkqPXTaMiwaLMdQ6vdGKfuRL6TguoTeVlwWBkXVURueFKhoBhelhaIzTnDoBkMT4zwYU2FQEdCQ2A1YSHI/RDIV8B9E4jk48cD+ABl0AWiwyAQBNAeIcsKzvCl979iN7XYRIGHOljIE9hfvL6ZWDiQ+K9neQFWi0KcLOUSam7Jiva6A6MgC0mDxVgKYPCoXIGx1AiPqpt8BcWHFRet1j5RxhUE/++At1RF5gtACZIM5i2iUNmDOapkwAGAVKVmpG0E9qYZJz4AGhtmpQ0kA1AM9gJraQ7aAElXTZxmYnZQgs52OElPrUw8hLgbioj/fcEPHbIeOPt3A7ffs5Ct8LuCv/+T2H6X++0BOtkvFeq3h8AAAAAASUVORK5CYII=
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    if (window.vhit) return;

    Object.defineProperty(window, 'vhit', {
        value: {
            detectAdblock: () => Object.assign(Promise.resolve(false), { valueOf: () => false }),
            report: () => {},
            trackPage: () => {}
        },
        writable: false,
        configurable: false
    });
})();
