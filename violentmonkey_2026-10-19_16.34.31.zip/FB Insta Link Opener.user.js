// ==UserScript==
// @name         FB Insta Link Opener
// @namespace    BlazeFTL
// @version      0.1
// @match        *://*.facebook.com/*
// @icon        https://www.facebook.com/favicon.ico
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function extractUsername(label) {
        const parts = label.split(',').map(s => s.trim()).filter(s => s && s.toLowerCase() !== 'instagram');
        return parts[0] || null;
    }

    function handler(e) {
        const el = e.target.closest('[aria-label*="Instagram"]');
        if (!el) return;
        const label = el.getAttribute('aria-label');
        const username = extractUsername(label);
        if (!username) return;
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        window.open(`https://www.instagram.com/${username}/`, '_blank');
    }

    document.addEventListener('click', handler, true);
})();
