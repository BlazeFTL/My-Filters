// ==UserScript==
// @name         TorUpload Auto-Click
// @namespace    https://github.com/BlazeFTL
// @description  Clicks #startfree, then #method_free once form action points to nathanmichael, then download when timer <= 1s.
// @version      1.3
// @author       BlazeFTL
// @match        https://nathanmichaelphoto.com/*
// @match        https://torupload.com/*
// @icon         https://www.google.com/s2/favicons?sz=128&domain=torupload.com
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let startClicked = false;
    let methodClicked = false;

    const checkInterval = setInterval(() => {
        const startBtn = document.getElementById('startfree');
        if (startBtn && !startClicked) {
            startClicked = true;
            startBtn.click();
        }

        const methodBtn = document.getElementById('method_free');
        if (methodBtn && !methodClicked) {
            const form = methodBtn.form || document.getElementById('downloadfile');
            const action = form ? (form.getAttribute('action') || '') : '';
            if (/^https?:\/\/(www\.)?nathanmichael/i.test(action)) {
                methodClicked = true;
                methodBtn.click();
            }
        }

        const xdInput = document.getElementById('xd');
        const downloadBtn = document.getElementById('downloadbtn');
        const captchaInput = document.querySelector('.captcha_code');
        const secondsSpan = document.getElementById('seconds');

        const hasToken = xdInput && xdInput.value.trim() !== "";
        const timerReady = !secondsSpan || secondsSpan.innerText === "" || parseInt(secondsSpan.innerText) <= 1;
        const captchaReady = captchaInput && captchaInput.value.length === 4;

        if (hasToken && timerReady && captchaReady && downloadBtn) {
            if (downloadBtn.disabled) {
                downloadBtn.disabled = false;
            }
            downloadBtn.click();
            clearInterval(checkInterval);
        }
    }, 250);
})();
