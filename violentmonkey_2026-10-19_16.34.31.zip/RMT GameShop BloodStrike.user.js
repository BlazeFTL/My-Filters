// ==UserScript==
// @name         RMT GameShop BloodStrike
// @namespace    hyperion
// @version      1.0
// @match        https://rmtgameshop.com/*
// @match        https://www.rmtgameshop.com/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const LINK = 'https://rmtgameshop.com/product/blood-strike-gold-top-up-in-bangladesh';
  const UID = '587099882544';
  const SERVER = 'bloodstrike';
  const norm = s => (s || '').toLowerCase().replace(/\s+/g, '');

  const style = document.createElement('style');
  style.textContent = '[data-bs-box] > :not([data-bs-item]){display:none!important}';
  document.documentElement.appendChild(style);

  function setValue(el, value) {
    const proto = el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function patchSearch() {
    document.querySelectorAll('.fixed.inset-0 .max-h-80.overflow-y-auto').forEach(box => {
      if (box.querySelector(':scope > [data-bs-item]')) return;
      if (!box.closest('.fixed.inset-0').querySelector('input')) return;
      box.setAttribute('data-bs-box', '');
      const a = document.createElement('a');
      a.setAttribute('data-bs-item', '');
      a.href = LINK;
      a.className = 'border-border bg-bg-tertiary hover:border-primary/50 hover:bg-primary/5 group flex w-full cursor-pointer items-center gap-3 rounded-lg border p-3 text-left transition-all';
      a.innerHTML =
        '<div class="border-border text-primary flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-lg border bg-linear-to-br from-white/5 to-white/10 font-medium">B</div>' +
        '<div class="min-w-0 flex-1"><div class="text-text-primary font-medium">BloodStrike</div></div>' +
        '<div class="bg-primary/10 text-primary shrink-0 rounded-lg px-2 py-1 text-xs font-medium">View</div>';
      box.appendChild(a);
    });
  }

  const done = new WeakSet();

  function prefill() {
    if (!location.pathname.includes('blood-strike')) return;
    const input = document.querySelector('input[placeholder="User ID"]');
    if (input && !done.has(input)) {
      done.add(input);
      setValue(input, UID);
    }
    document.querySelectorAll('select').forEach(sel => {
      if (done.has(sel)) return;
      const opt = Array.from(sel.options).find(o => norm(o.textContent) === SERVER);
      if (!opt) return;
      done.add(sel);
      setValue(sel, opt.value);
    });
  }

  let raf;
  const run = () => {
    patchSearch();
    prefill();
  };

  new MutationObserver(() => {
    cancelAnimationFrame(raf);
    raf = requestAnimationFrame(run);
  }).observe(document.documentElement, { childList: true, subtree: true });

  run();
})();
