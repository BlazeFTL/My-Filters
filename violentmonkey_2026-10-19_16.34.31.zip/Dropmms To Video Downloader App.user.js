// ==UserScript==
// @name         Dropmms To Video Downloader App
// @namespace    ftl-patches
// @version      2.3
// @match        https://*.dropmms.co/*
// @icon         data:image/svg+xml,%3Csvg%20xmlns=%22http://www.w3.org/2000/svg%22%20viewBox=%220%200%2064%2064%22%3E%3Crect%20width=%2264%22%20height=%2264%22%20rx=%2214%22%20fill=%22%231565a8%22/%3E%3Cpath%20d=%22M32%208C32%208%2014%2028%2014%2040a18%2018%200%200%200%2036%200C50%2028%2032%208%2032%208Z%22%20fill=%22%23e6208c%22/%3E%3Cpath%20d=%22M26%2033H31A7.5%207.5%200%200%201%2031%2048H26Z%22%20fill=%22none%22%20stroke=%22%23fff%22%20stroke-width=%224%22%20stroke-linejoin=%22round%22/%3E%3C/svg%3E
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const PKG = 'video.downloader.videodownloader';
  const COMPONENT = PKG + '/' + PKG + '.activity.MainTabsActivity';
  const NO_APP_HASH = '#ftl-noapp';

  const STRICT_SITES = [
    { host: 'dropmms.co', path: /^\/v\/[A-Za-z0-9]+/ },
    { host: 'vidara.to', path: /^\/v\/[A-Za-z0-9]+/ },
    { host: 'luluvido.com', path: /^\/(?:d\/)?[A-Za-z0-9]{8,}\/?$/ },
    { host: 'luluvid.com', path: /^\/(?:d\/)?[A-Za-z0-9]{8,}\/?$/ },
  ];

  const TRUSTED_HOSTS = [
    'streamfiles.net',
    'playmate.to',
    'lulust.com',
  ];

  function hostMatches(hostname, host) {
    return hostname === host || hostname.endsWith('.' + host);
  }

  function isVideoUrl(href) {
    try {
      const u = new URL(href, location.href);
      if (u.hash === NO_APP_HASH) return false;

      const strict = STRICT_SITES.find(function (s) {
        return hostMatches(u.hostname, s.host);
      });

      if (strict) return strict.path.test(u.pathname);

      return TRUSTED_HOSTS.some(function (h) {
        return hostMatches(u.hostname, h);
      });
    } catch (e) {
      return false;
    }
  }

  function toIntentUrl(href) {
    const u = new URL(href, location.href);
    u.hash = '';
    const stripped = u.href.replace(/^https?:\/\//, '');
    const fallback = encodeURIComponent(u.href + NO_APP_HASH);

    return 'intent://' + stripped +
      '#Intent;scheme=' + u.protocol.replace(':', '') +
      ';package=' + PKG +
      ';component=' + COMPONENT +
      ';S.browser_fallback_url=' + fallback +
      ';end';
  }

  if (isVideoUrl(location.href)) {
    location.href = toIntentUrl(location.href);
    return;
  }

  document.addEventListener('click', function (e) {
    const a = e.target.closest && e.target.closest('a[href]');
    if (!a || !isVideoUrl(a.href)) return;

    e.preventDefault();
    e.stopPropagation();
    location.href = toIntentUrl(a.href);
  }, true);

  const nativeOpen = window.open;
  window.open = function (url) {
    if (url && isVideoUrl(String(url))) {
      location.href = toIntentUrl(String(url));
      return null;
    }
    return nativeOpen.apply(this, arguments);
  };
})();
