// ==UserScript==
// @name         GitHub Editor Auto-Scroll 1.6
// @namespace    https://github.com/BlazeFTL
// @description  Jumps to bottom of My-Filters editor ONLY if no specific line anchor (#L) is present. Supports SPA navigation.
// @version      1.6
// @author       BlazeFTL
// @match        https://github.com/BlazeFTL/My-Filters*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let lastUrl = location.href;

    const jumpToBottom = () => {
        // 1. Only trigger if on an edit page
        if (!window.location.pathname.includes('/edit/')) {
            return;
        }

        // 2. DO NOT trigger if a line anchor (e.g., #L2536) is present
        if (window.location.hash.match(/^#L\d+/)) {
            return;
        }

        // Search for the CodeMirror 6 scroller (GitHub's current editor)
        const scroller = document.querySelector('.cm-scroller') ||
                         document.querySelector('.cm-content') ||
                         document.querySelector('textarea[name="value"]');

        if (scroller) {
            // Check if we've already scrolled this specific element
            if (scroller.dataset.hasJumped === "true") return;

            scroller.focus();
            scroller.scrollTop = scroller.scrollHeight;

            // Handle standard textareas if present
            if (scroller.setSelectionRange && scroller.value) {
                const len = scroller.value.length;
                scroller.setSelectionRange(len, len);
            }

            scroller.dataset.hasJumped = "true";
        }
    };

    // Use MutationObserver to watch for page content changes (SPA navigation)
    const observer = new MutationObserver(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            // Reset jump state on URL change
            const oldScroller = document.querySelector('[data-has-jumped="true"]');
            if (oldScroller) delete oldScroller.dataset.hasJumped;
        }
        jumpToBottom();
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Initial check
    setTimeout(jumpToBottom, 1000);
})();
