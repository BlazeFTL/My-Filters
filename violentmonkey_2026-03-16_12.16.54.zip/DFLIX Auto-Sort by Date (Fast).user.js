// ==UserScript==
// @name         DFLIX Auto-Sort by Date (Fast)
// @namespace    https://github.com/BlazeFTL
// @description  Fastest possible auto-sort for DFLIX using MutationObservers.
// @version      1.0
// @author       BlazeFTL
// @match        http://dflix.live/*
// @match        https://dflix.live/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const TARGET_LABEL = 'Date Added (Recent)';

    const fastSort = () => {
        const sortButton = Array.from(document.querySelectorAll('button')).find(btn =>
            btn.textContent.includes('Sort:')
        );

        if (!sortButton || sortButton.textContent.includes(TARGET_LABEL)) return;

        // Immediate click to open dropdown
        sortButton.click();

        // Use a very fast internal observer to catch the dropdown the moment React renders it
        const dropdownObserver = new MutationObserver((_, observer) => {
            const options = document.querySelectorAll('button');
            const targetOption = Array.from(options).find(opt => opt.textContent.trim() === TARGET_LABEL);

            if (targetOption) {
                targetOption.click();
                observer.disconnect(); // Stop looking once clicked
            }
        });

        dropdownObserver.observe(document.body, { childList: true, subtree: true });

        // Safety timeout to disconnect if dropdown fails to open
        setTimeout(() => dropdownObserver.disconnect(), 2000);
    };

    // Watch for page transitions and initial load
    const mainObserver = new MutationObserver(fastSort);
    mainObserver.observe(document.body, { childList: true, subtree: true });

    // Initial check
    fastSort();
})();

