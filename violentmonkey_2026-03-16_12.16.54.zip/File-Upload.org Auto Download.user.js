// ==UserScript==
// @name         File-Upload.org Auto Download
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automate download process on file-upload.org
// @author       BlazeFTL
// @match        https://*.file-upload.org/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function waitForElement(selector, callback) {
        const observer = new MutationObserver((mutations, obs) => {
            const element = document.querySelector(selector);
            if (element) {
                callback(element);
                obs.disconnect();
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    // Step 1: Click the first button
    waitForElement(".m-2.submit-btn.btn-outline-primary.btn", (button) => {
        console.log("First page button found, clicking...");
        button.click();
    });

    // Step 2: Handle CAPTCHA and countdown timer
    waitForElement("[src*='hcaptcha.com/captcha']", (captcha) => {
       // alert("Please complete the CAPTCHA manually.");
    });

    function clickDownloadAfterTimer() {
        const downloadButton = document.querySelector(".downloadbtn.download-btn.btn-primary.btn");
        if (downloadButton) {
            console.log("Download button after timer found, clicking...");
            downloadButton.click();
        } else {
            setTimeout(clickDownloadAfterTimer, 1000);
        }
    }

    setTimeout(clickDownloadAfterTimer, 32000); // Wait 30 seconds before clicking the button

    // Step 3: Final download button
    waitForElement("#downloadButton", (finalButton) => {
        console.log("Final download button found, clicking...");
        finalButton.click();
    });

})();

