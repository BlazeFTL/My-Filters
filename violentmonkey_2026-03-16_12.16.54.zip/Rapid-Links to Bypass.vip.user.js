// ==UserScript==
// @name         Rapid-Links to Bypass.vip
// @namespace    https://github.com/BlazeFTL
// @description  Redirects rapid-links to bypass.vip and auto-fills the URL
// @version      1.0
// @author       BlazeFTL
// @match        https://rapid-links.com/s?*
// @match        https://bypass.vip/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const currentUrl = window.location.href;

    // Phase 1: If on the source site, redirect to the bypasser with the link as a parameter
    if (currentUrl.includes('rapid-links.com/s?')) {
        const targetUrl = encodeURIComponent(currentUrl);
        window.location.href = `https://bypass.vip/?url=${targetUrl}`;
        return;
    }

    // Phase 2: If on bypass.vip, check for the URL parameter and fill the form
    if (currentUrl.includes('bypass.vip')) {
        const urlParams = new URLSearchParams(window.location.search);
        const linkToBypass = urlParams.get('url');

        if (linkToBypass) {
            // Wait for the elements to be available in the DOM
            const checkExist = setInterval(function() {
                const inputField = document.getElementById('bypassInput');
                const submitBtn = document.getElementById('submitButton');

                if (inputField && submitBtn) {
                    clearInterval(checkExist);

                    // Fill the input
                    inputField.value = decodeURIComponent(linkToBypass);

                    // Trigger input events so the site's scripts recognize the text
                    inputField.dispatchEvent(new Event('input', { bubbles: true }));
                    inputField.dispatchEvent(new Event('change', { bubbles: true }));

                    // Attempt to click the button
                    // Note: If hCaptcha is present, the button might remain 'disabled'
                    // until the captcha is solved.
                    if (!submitBtn.disabled) {
                        submitBtn.click();
                    } else {
                        console.log("Waiting for captcha to be solved before clicking...");
                    }
                }
            }, 500); // Check every 500ms
        }
    }
})();

