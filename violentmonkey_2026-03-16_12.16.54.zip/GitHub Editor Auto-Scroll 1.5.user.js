// ==UserScript==
// @name         GitHub Editor Auto-Scroll 1.5
// @namespace    https://github.com/BlazeFTL
// @description  Jumps to bottom of My-Filters editor ONLY if no specific line anchor (#L) is present.
// @version      1.5
// @author       BlazeFTL
// @match        https://github.com/BlazeFTL/My-Filters/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let hasJumped = false;
    let lastUrl = location.href;

    const jumpToBottom = () => {
        // 1. Only trigger if on an edit page
        if (!location.href.includes('/edit/')) {
            hasJumped = false;
            return;
        }

        // 2. DO NOT trigger if a line anchor (e.g., #L2536) is present
        if (window.location.hash.match(/^#L\d+/)) {
            return;
        }

        if (hasJumped) return;

        const scroller = document.querySelector('.cm-scroller') ||
                         document.querySelector('.cm-content') ||
                         document.querySelector('textarea[name="value"]');

        if (scroller && (scroller.scrollHeight > 100)) {
            scroller.focus();
            scroller.scrollTop = scroller.scrollHeight;

            if (scroller.setSelectionRange) {
                const len = scroller.value.length;
                scroller.setSelectionRange(len, len);
            }

            hasJumped = true;
        }
    };

    const observer = new MutationObserver(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            hasJumped = false;
        }
        jumpToBottom();
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Initial check
    setTimeout(jumpToBottom, 1000);

})();
