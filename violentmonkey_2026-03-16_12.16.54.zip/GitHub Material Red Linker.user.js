// ==UserScript==
// @name         GitHub Material Red Linker
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Material design red links with minimal footprint.
// @author       BlazeFTL
// @match        https://github.com/uBlockOrigin/uAssets/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const style = document.createElement('style');
    style.innerHTML = `
        .custom-github-link {
    background-color: rgba(207, 34, 46, 0.08); /* Slightly lighter */
    color: #cf222e !important;
    padding: 0px 4px; /* Tiny bit of side breathing room */
    margin: 0px 1px;
    border-radius: 4px;
    font-weight: 500;
    text-decoration: none !important;
    transition: all 0.1s ease;

    /* The Magic Fixes */
    display: inline; /* Use inline for perfect text flow */
    box-decoration-break: clone;
    -webkit-box-decoration-break: clone;
    border-bottom: 1.5px solid rgba(207, 34, 46, 0.2); /* Adds 'Material' depth */
}

.custom-github-link:hover {
    background-color: #cf222e;
    color: #ffffff !important;
    border-bottom-color: transparent;
}

    `;
    document.head.appendChild(style);

    const urlRegex = /(https?:\/\/[^\s<]+)/g;

    function linkify() {
        const elements = document.querySelectorAll('.markdown-body p:not([data-linked]), .markdown-body code.notranslate:not([data-linked])');

        elements.forEach(el => {
            el.setAttribute('data-linked', 'true');
            if (el.querySelector('a')) return;

            const originalHTML = el.innerHTML;
            const newHTML = originalHTML.replace(urlRegex, (url) => {
                return `<a href="${url}" target="_blank" class="custom-github-link">${url}</a>`;
            });

            if (originalHTML !== newHTML) {
                el.innerHTML = newHTML;
            }
        });
    }

    let timeout;
    const debouncedLinkify = () => {
        clearTimeout(timeout);
        timeout = setTimeout(linkify, 200);
    };

    linkify();

    const observer = new MutationObserver(debouncedLinkify);
    observer.observe(document.body, { childList: true, subtree: true });
})();
