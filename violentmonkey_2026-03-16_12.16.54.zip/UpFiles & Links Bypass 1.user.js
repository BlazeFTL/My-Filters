// ==UserScript==
// @name         UpFiles & Links Bypass 1
// @namespace    https://github.com/BlazeFTL
// @description  Bypasses Anti-Adblock and forced timers on UpFiles and related domains.
// @version      1.0
// @author       BlazeFTL
// @match        *://upfilesgo.com/*
// @match        *://upplinks.net/*
// @match        *://upfion.com/*
// @match        *://upfiles.app/*
// @match        *://upfiles-urls.com/*
// @match        *://falpus.com/*
// @match        *://exeygo.com/*
// @license      MIT
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // 1. Anti-Adblock Defeater (innerHTML Hook)
    const originalSet = Object.getOwnPropertyDescriptor(Element.prototype, "innerHTML").set;
    const originalGet = Object.getOwnPropertyDescriptor(Element.prototype, "innerHTML").get;

    Object.defineProperty(Element.prototype, "innerHTML", {
        get() {
            return originalGet.call(this);
        },
        set(value) {
            if (typeof value === 'string' && value.includes("disable Adblock")) {
                return;
            }
            originalSet.call(this, value);
        }
    });

    // 2. Timer & Logic Bypass (Promise Proxy)
    const pattern = /free-download-form|'\),_0x|\)\]\(function\(_0x/;

    const handlerInner = {
        apply: (target, thisArg, args) => {
            const firstArg = args[0];
            if (typeof firstArg === 'boolean' && firstArg === true) {
                args[0] = false;
            }
            setTimeout(() => Reflect.apply(target, thisArg, args), 1000);
        }
    };

    const handlerOuter = {
        apply: (target, thisArg, args) => {
            const callback = args[0];
            if (typeof callback === 'function' && pattern.test(callback.toString())) {
                args[0] = new Proxy(callback, handlerInner);
            }
            return Reflect.apply(target, thisArg, args);
        }
    };

    window.Promise.prototype.then = new Proxy(window.Promise.prototype.then, handlerOuter);

    // 3. Button Unlocker (Post-Load)
    window.addEventListener("load", () => {
        const btn = document.querySelector("form#go-link button#link-button");
        if (btn) {
            const cleanBtn = btn.cloneNode(true);
            btn.parentNode.replaceChild(cleanBtn, btn);
            cleanBtn.removeAttribute("disabled");
        }
    });
})();

