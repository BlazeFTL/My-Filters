// ==UserScript==
// @name         Vplink 2 Page ByPass Only Single Links
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Ultra-simplified config - Paste triggers directly from the address bar
// @author       BlazeFTL
// @match        *://*/*
// @run-at       document-start
// @grant        none
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    // ================= CONFIGURATION AREA =================
    const CONFIG = {
        // Paste URL up to the "=" (No ID at the end)
        // Example: https://newsfront.xyz/studyhotels/?smartcation
        sourceTrigger: 'newsfront.xyz/studyhotels/?smartcation',

        // Example: https://sarkarijobcorner.com/educatestudy/estudypost/?eduonline
        interTrigger: 'sarkarijobcorner.com/educatestudy/estudypost/?eduonline',

        finalDomain: 'vplink.in',
        timer: 20
    };
    // ======================================================

    // Helper to extract domain and param key from the trigger strings
    const parseTrigger = (trigger) => {
        const domain = trigger.split('/')[0];
        const param = trigger.split('?')[1] || '';
        return { domain, param };
    };

    const source = parseTrigger(CONFIG.sourceTrigger);
    const inter = parseTrigger(CONFIG.interTrigger);

    const url = window.location.href;
    const params = new URLSearchParams(window.location.search);

    // --- STAGE 1: SOURCE DOMAIN ---
    if (url.includes(source.domain) && params.has(source.param)) {
        const id = params.get(source.param);
        window.stop();

        // Constructs the redirect to the intermediate URL
        const nextUrl = `https://${CONFIG.interTrigger}=${id}`;
        window.location.replace(nextUrl);
        return;
    }

    // --- STAGE 2: INTERMEDIATE DOMAIN ---
    if (url.includes(inter.domain)) {

        // Use the extracted key to capture the ID
        if (params.has(inter.param)) {
            localStorage.setItem("blaze_final_id", params.get(inter.param));
            return;
        }

        const savedId = localStorage.getItem("blaze_final_id");

        // --- STAGE 3: THE ARTICLE PAGE (The UI) ---
        if (savedId && !params.has(inter.param)) {
            const startUI = () => {
                if (document.getElementById('blaze-guard')) return;

                const shield = document.createElement('div');
                shield.id = 'blaze-guard';
                shield.style.cssText = `
                    position: fixed !important; top: 0; left: 0; width: 100%; height: 100%;
                    background: #000 !important; z-index: 2147483647 !important;
                    display: flex; align-items: center; justify-content: center;
                    font-family: sans-serif; color: white; text-align: center;
                `;

                shield.innerHTML = `
                    <div style="border: 2px solid #e74c3c; padding: 40px; border-radius: 20px; background: #111;">
                        <h2 style="color: #e74c3c; margin: 0;">LINK VERIFICATION</h2>
                        <div id="big-timer" style="font-size: 100px; font-weight: bold; margin: 10px 0;">${CONFIG.timer}</div>
                        <p style="color: #666;">You will be redirected to ${CONFIG.finalDomain} within ${CONFIG.timer} seconds</p>
                    </div>
                `;

                (document.body || document.documentElement).appendChild(shield);

                let timeLeft = CONFIG.timer;
                const ticker = setInterval(() => {
                    timeLeft--;
                    const display = document.getElementById('big-timer');
                    if (display) display.innerText = timeLeft;

                    if (timeLeft <= 0) {
                        clearInterval(ticker);
                        localStorage.removeItem("blaze_final_id");
                        window.location.href = `https://${CONFIG.finalDomain}/` + savedId;
                    }
                }, 1000);
            };

            if (document.documentElement) startUI();
            const obs = new MutationObserver(() => {
                if (!document.getElementById('blaze-guard')) startUI();
            });
            obs.observe(document.documentElement, { childList: true, subtree: true });
        }
    }
})();

