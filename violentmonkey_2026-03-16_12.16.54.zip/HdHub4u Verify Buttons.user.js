// ==UserScript==
// @name         HdHub4u Verify Buttons
// @namespace    https://github.com/BlazeFTL
// @description  Auto Click #verify_btn with specific text on selected domains
// @version      1.1
// @author       BlazeFTL
// @match        https://cryptonewz.one/*
// @match        https://inventoryidea.com/*
// @match        https://cryptoinsights.site/*
// @match        https://gadgetsweb.xyz/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const observer = new MutationObserver(() => {
        const btn = document.querySelector("#verify_btn");

        if (btn && btn.offsetParent !== null) {
            const btnText = btn.innerText.toLowerCase();
            const targetTexts = ["click to continue", "get links"];

            if (targetTexts.some(t => btnText.includes(t))) {
                btn.click();
            }
        }
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true
    });
})();
