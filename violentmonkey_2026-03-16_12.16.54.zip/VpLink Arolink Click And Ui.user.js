// ==UserScript==
// @name         VpLink Arolink Click And Ui
// @namespace    https://github.com/BlazeFTL
// @version      1.0
// @description  Persistent UI overlay with countdown for krishitalk.com
// @author       BlazeFTL
// @match        *://dharona.in/*
// @match        *://krishitalk.com/*
// @license      MIT
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const isKrishi = window.location.hostname.includes('krishitalk.com');

    // Inject CSS immediately at document-start to prevent flashing of page content
    if (isKrishi) {
        const style = document.createElement('style');
        style.innerHTML = `
            #blaze-guard {
                position: fixed !important;
                top: 0 !important;
                left: 0 !important;
                width: 100vw !important;
                height: 100vh !important;
                background: #000 !important;
                z-index: 2147483647 !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                font-family: sans-serif !important;
                color: white !important;
                text-align: center !important;
            }
            body { overflow: hidden !important; }
        `;
        document.documentElement.appendChild(style);
    }

    function autoClick() {
        const link = document.querySelector('a[href*="/readmore"], a[href*="/learn_more.php"]');
        if (link) {
            console.log("Auto clicking:", link.href);
            link.click();
        }
    }

    function startAutoClicker() {
        autoClick();
        const observer = new MutationObserver(() => autoClick());
        observer.observe(document.documentElement, { childList: true, subtree: true });
    }

    const init = () => {
        if (isKrishi) {
            if (document.getElementById('blaze-guard')) return;

            const shield = document.createElement('div');
            shield.id = 'blaze-guard';
            let timeLeft = 20;

            shield.innerHTML = `
                <div style="border:2px solid #e74c3c;padding:40px;border-radius:20px;background:#111;box-shadow: 0 0 20px rgba(231, 76, 60, 0.2);">
                    <h2 style="color:#e74c3c;margin:0;letter-spacing:2px;">LINK VERIFICATION</h2>
                    <div id="big-timer" style="font-size:100px;font-weight:bold;margin:10px 0;line-height:1;">${timeLeft}</div>
                    <p id="sub-text" style="color:#666;margin:0;">Processing request in ${timeLeft}s</p>
                </div>`;

            (document.body || document.documentElement).appendChild(shield);

            const ticker = setInterval(() => {
                timeLeft--;
                const display = document.getElementById('big-timer');
                const subText = document.getElementById('sub-text');

                if (display) display.innerText = timeLeft;
                if (subText) subText.innerText = `Processing request in ${timeLeft}s`;

                if (timeLeft <= 0) {
                    clearInterval(ticker);
                    // UI remains visible while the clicking logic starts
                    if (display) display.innerText = "DONE";
                    if (subText) subText.innerText = "Executing click...";
                    startAutoClicker();
                }
            }, 1000);
        } else {
            startAutoClicker();
        }
    };

    // Handle different loading states
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();

