// ==UserScript==
// @name         Auto-Redirect to IDM+ 1.1
// @namespace    https://github.com/BlazeFTL
// @description  Pass download links directly to IDM+ via Android Intent
// @version      1.1
// @author       BlazeFTL
// @match        *://*/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // List of common download extensions to intercept
    const downloadRegex = /\.(zip|rar|7z|mp4|mkv|pdf|bin|exe|apk|iso|tar|gz)$/i;

    document.addEventListener('click', function(e) {
        const link = e.target.closest('a');
        if (!link || !link.href) return;

        if (downloadRegex.test(link.href)) {
            e.preventDefault();
            e.stopPropagation();

            // Construct the Android Intent for IDM+
            // Replace 'idm.internet.download.manager.plus' if using a different version
            const idmIntent = `intent://${link.href.replace(/^https?:\/\//, '')}#Intent;scheme=http;package=idm.internet.download.manager.plut;end`;

            window.location.href = idmIntent;
        }
    }, true);
})();

