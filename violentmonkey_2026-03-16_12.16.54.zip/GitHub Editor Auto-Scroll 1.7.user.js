// ==UserScript==
// @name         GitHub Editor Auto-Scroll 1.7
// @namespace    https://github.com/BlazeFTL
// @description  Jumps to bottom of My-Filters editor ONLY if no specific line anchor (#L) is present. Supports SPA navigation.
// @version      1.7
// @author       BlazeFTL
// @match        https://github.com/BlazeFTL/My-Filters*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let lastUrl = location.href;

    const jumpToBottom = () => {
        // 1. Only trigger if on an edit page
        if (!window.location.pathname.includes('/edit/')) {
            return;
        }

        // 2. DO NOT trigger if a line anchor (e.g., #L2536) is present
        if (window.location.hash.match(/^#L\d+/)) {
            return;
        }

        // Target CodeMirror 6 (GitHub's modern editor) or legacy textarea
        const scroller = document.querySelector('.cm-scroller') ||
                         document.querySelector('.cm-content') ||
                         document.querySelector('textarea[name="value"]');

        if (scroller) {
            // Check if we've already jumped for this specific element instance
            if (scroller.dataset.hasJumped === "true") return;

            // Ensure the editor has content/height before jumping
            if (scroller.scrollHeight > 100) {
                scroller.focus();
                scroller.scrollTop = scroller.scrollHeight;

                // Move cursor to end if it's a standard textarea
                if (scroller.setSelectionRange && scroller.value) {
                    const len = scroller.value.length;
                    scroller.setSelectionRange(len, len);
                }

                scroller.dataset.hasJumped = "true";
            }
        }
    };

    // Use MutationObserver to detect when the editor is injected into the DOM
    const observer = new MutationObserver(() => {
        if (location.href !== lastUrl) {
            lastUrl = location.href;
            // Clear jump flags when navigating to a new URL within the SPA
            document.querySelectorAll('[data-has-jumped="true"]').forEach(el => {
                delete el.dataset.hasJumped;
            });
        }
        jumpToBottom();
    });

    // Start observing
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: false
    });

    // Initial check for direct page loads
    setTimeout(jumpToBottom, 1000);
})();
