// ==UserScript==
// @name         KatFile AutoClick
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Bypasses button click issues by submitting the form directly after captcha
// @author       BlazeFTL
// @match        *://katfile.com/*
// @match        *://katfile.*/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function () {
    'use strict';

    // Disable the site's ad-redirect interference
    window.download_click = true;
    window.open = function() { return null; };

    const waitForEl = (selector, cb) => {
        const el = document.querySelector(selector);
        if (el) return cb(el);
        const obs = new MutationObserver(() => {
            const el = document.querySelector(selector);
            if (el) {
                obs.disconnect();
                cb(el);
            }
        });
        obs.observe(document.documentElement, { childList: true, subtree: true });
    };

    // --- Captcha Detection ---
    function captchaSolved(callback) {
        let intervalId = setInterval(() => {
            try {
                // Check for Cloudflare Turnstile success token
                const turnstileRes = document.querySelector('[name="cf-turnstile-response"]');
                if (turnstileRes && turnstileRes.value.length > 10) {
                    clearInterval(intervalId);
                    callback();
                }
            } catch (e) {}
        }, 1000);
    }

    // --- Page 1: Auto-Timer ---
    const handlePage1 = () => {
        waitForEl('#m_fbtn1, #freebtn', (btn) => {
            if (typeof window.start_countdown === 'function') {
                window.start_countdown();
            } else {
                btn.click();
            }
            const timerCheck = setInterval(() => {
                const downloadBtn = document.querySelector('#freebtn');
                if (downloadBtn && !downloadBtn.disabled && downloadBtn.style.display !== 'none') {
                    clearInterval(timerCheck);
                    downloadBtn.click();
                }
            }, 1000);
        });
    };

    // --- Page 2: Direct Form Submission ---
    const handlePage2 = () => {
        // Look for the specific button from your screenshot
        const targetBtnSelector = 'button.btn.btn-primary.btn-lg.downloadbtn.ddddd';

        waitForEl(targetBtnSelector, (btn) => {
            console.log("Button detected. Waiting for captcha solve...");

            captchaSolved(() => {
                console.log("Captcha solved. Submitting form directly...");

                setTimeout(() => {
                    const form = btn.closest('form');
                    if (form) {
                        // We manually increment the ad cookie to mimic the site's own code
                        if (typeof $ !== 'undefined' && $.cookie) {
                            let count = parseInt($.cookie('ads') || 0);
                            $.cookie('ads', count + 1);
                        }

                        // Submit the form directly to bypass the broken button click
                        form.submit();
                    } else {
                        // If no form, try the button again as last resort
                        btn.click();
                    }
                }, 1000);
            });
        });
    };

    // --- Page 3: Final Link ---
    const handlePage3 = () => {
        waitForEl('#dlink', (btn) => {
            setTimeout(() => btn.click(), 500);
        });
    };

    // Initialize
    handlePage1();
    handlePage2();
    handlePage3();

})();

