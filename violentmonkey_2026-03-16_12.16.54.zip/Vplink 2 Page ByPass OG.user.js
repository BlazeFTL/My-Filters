// ==UserScript==
// @name         Vplink 2 Page ByPass OG
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Simplified config - Merge Path and Param for easier pasting
// @author       BlazeFTL
// @match        *://*/*
// @run-at       document-start
// @grant        none
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';

    // ================= CONFIGURATION AREA =================
    const CONFIG = {
        // Domains
        sourceDomain: 'newsfront.xyz',
        interDomain: 'sarkarijobcorner.com',
        finalDomain: 'vplink.in',

        // The key from the first URL (e.g., smartcation)
        sourceParam: 'smartcation',

        // Paste everything between the domain and the value here:
        // Example: newsfront.xyz/[PASTE_HERE]ronQV
        interPathWithParam: 'educatestudy/estudypost/?eduonline',

        // Settings
        timer: 20
    };
    // ======================================================

    // Internal Logic: Extract the key name from the path for the observer/capture
    const interParamKey = CONFIG.interPathWithParam.split('?')[1] || CONFIG.interPathWithParam;

    const url = window.location.href;
    const params = new URLSearchParams(window.location.search);

    // --- STAGE 1: SOURCE DOMAIN ---
    if (url.includes(CONFIG.sourceDomain) && params.has(CONFIG.sourceParam)) {
        const id = params.get(CONFIG.sourceParam);
        window.stop();

        // Build URL: https:// + Domain + / + PathWithParam + = + ID
        const nextUrl = `https://${CONFIG.interDomain}/${CONFIG.interPathWithParam}=${id}`;
        window.location.replace(nextUrl);
        return;
    }

    // --- STAGE 2: INTERMEDIATE DOMAIN ---
    if (url.includes(CONFIG.interDomain)) {

        // Use the extracted key to capture the ID
        if (params.has(interParamKey)) {
            localStorage.setItem("blaze_final_id", params.get(interParamKey));
            return;
        }

        const savedId = localStorage.getItem("blaze_final_id");

        // --- STAGE 3: THE ARTICLE PAGE (The UI) ---
        // If we have an ID and aren't on the capture URL, show the timer
        if (savedId && !params.has(interParamKey)) {
            const startUI = () => {
                if (document.getElementById('blaze-guard')) return;

                const shield = document.createElement('div');
                shield.id = 'blaze-guard';
                shield.style.cssText = `
                    position: fixed !important; top: 0; left: 0; width: 100%; height: 100%;
                    background: #000 !important; z-index: 2147483647 !important;
                    display: flex; align-items: center; justify-content: center;
                    font-family: sans-serif; color: white; text-align: center;
                `;

                shield.innerHTML = `
                    <div style="border: 2px solid #e74c3c; padding: 40px; border-radius: 20px; background: #111;">
                        <h2 style="color: #e74c3c; margin: 0;">LINK VERIFICATION</h2>
                        <div id="big-timer" style="font-size: 100px; font-weight: bold; margin: 10px 0;">${CONFIG.timer}</div>
                        <p style="color: #666;">You will be redirected to ${CONFIG.finalDomain} within ${CONFIG.timer} seconds</p>
                    </div>
                `;

                (document.body || document.documentElement).appendChild(shield);

                let timeLeft = CONFIG.timer;
                const ticker = setInterval(() => {
                    timeLeft--;
                    const display = document.getElementById('big-timer');
                    if (display) display.innerText = timeLeft;

                    if (timeLeft <= 0) {
                        clearInterval(ticker);
                        localStorage.removeItem("blaze_final_id");
                        window.location.href = `https://${CONFIG.finalDomain}/` + savedId;
                    }
                }, 1000);
            };

            if (document.documentElement) startUI();
            const obs = new MutationObserver(() => {
                if (!document.getElementById('blaze-guard')) startUI();
            });
            obs.observe(document.documentElement, { childList: true, subtree: true });
        }
    }
})();

