// ==UserScript==
// @name         Job Sites Countdown Auto Clicker
// @namespace    https://github.com/BlazeFTL
// @version      1.0.0
// @description  Clicks countdown/continue buttons when shown and bypasses tab switch detection.
// @match        https://apnahirework.com/*
// @match        https://*.apnahirework.com/*
// @match        https://jobsarkar.in/*
// @match        https://*.jobsarkar.in/*
// @match        https://pipefitter.in/*
// @match        https://*.pipefitter.in/*
// @match        https://entiredust.in/*
// @match        https://*.entiredust.in/*
// @match        https://dharona.in/*
// @match        https://*.dharona.in/*
// @match        https://krishitalk.com/*
// @match        https://*.krishitalk.com/*
// @match        https://newsfront.xyz/*
// @match        https://*.newsfront.xyz/*
// @match        https://naukaritimes24.in/*
// @match        https://*.naukaritimes24.in/*
// @match        https://sarkarijobcorner.com/*
// @match        https://*.sarkarijobcorner.com/*
// @run-at       document-start
// @grant        unsafeWindow
// ==/UserScript==

const win = typeof unsafeWindow === "undefined" ? globalThis : unsafeWindow;

const safe = {
    run(fn, spec = {}) {
        const { onError = console.error } = spec;
        const fail = (error) => { onError(error); };
        try {
            const result = fn();
            return typeof result?.then === "function" ? result.then(undefined, fail) : result;
        } catch (error) {
            fail(error);
        }
    },
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    },
};

const handle = {
    make(input = {}) {
        const { stop = () => { }, done = Promise.resolve(), applied = true } = input;
        let isStopped = false;
        return {
            done,
            applied,
            stop() {
                if (isStopped) return;
                isStopped = true;
                safe.run(stop);
            },
        };
    },
};

const ctx = {
    store: new Map(),
    of(name, init) {
        if (!this.store.has(name)) this.store.set(name, init ?? {});
        return this.store.get(name);
    },
};

const matcher = {
    value(actual, expected, { exact = false } = {}) {
        if (typeof expected === "function") return Boolean(expected(actual));
        if (typeof actual === "string" && expected instanceof RegExp) {
            expected.lastIndex = 0;
            return expected.test(actual);
        }
        if (!exact && typeof actual === "string" && typeof expected === "string") {
            return Boolean(expected) && actual.includes(expected);
        }
        return actual === expected;
    },
    is(node, selector) {
        return typeof node?.matches === "function" && node.matches(selector);
    },
    visibility(node, visible) {
        if (this.nil(visible)) return true;
        return node.checkVisibility({ visibilityProperty: true, opacityProperty: true }) === visible;
    },
    node(node, options) {
        if (this.nil(options)) return true;
        if (typeof options === "string") return this.is(node, options);
        const { is, not, visible, when } = options;
        const checks = [
            [!this.nil(is), () => !this.is(node, is)],
            [!this.nil(not), () => this.is(node, not)],
            [typeof visible === "boolean", () => !this.visibility(node, visible)],
            [!this.nil(when), () => !when(node)],
        ];
        return checks.every(([enabled, test]) => !enabled || !test());
    },
    listener({ type, target } = {}) {
        return (self, name) =>
            (matcher.nil(type) || matcher.value(name, type, { exact: true }))
            && matcher.node(self, target);
    },
    nil(value) {
        return value === null || value === undefined;
    },
};

const observer = {
    OPTIONS: { childList: true, subtree: true, attributes: true, characterData: true },
    callbacks: new Set(),
    mutations: new MutationObserver((records) => observer.executor(records)),
    running: false,
    queue: [],
    isScheduled: false,
    pending: new Set(),
    attached: new WeakSet(),

    drain() {
        for (const record of this.mutations.takeRecords()) this.queue.push(record);
    },
    executor(records) {
        for (const record of records) this.queue.push(record);
        this.schedule();
    },
    flush() {
        this.isScheduled = false;
        this.drain();
        const records = this.queue;
        this.queue = [];
        if (records.length === 0) return;
        for (const callback of this.callbacks) safe.run(() => callback(records));
        this.mutations.takeRecords();
    },
    schedule() {
        if (this.isScheduled) return;
        this.isScheduled = true;
        const run = () => { if (this.isScheduled) this.flush(); };
        requestAnimationFrame(run);
        setTimeout(run, 200);
    },
    observe() {
        if (this.running) return;
        this.running = true;
        this.mutations.observe(document.documentElement, this.OPTIONS);
        for (const root of this.pending) this.mutations.observe(root, this.OPTIONS);
        this.pending.clear();
    },
    attach(root) {
        if (this.attached.has(root)) return;
        this.attached.add(root);
        if (!this.running) {
            this.pending.add(root);
            return;
        }
        this.mutations.observe(root, this.OPTIONS);
        this.schedule();
    },
    change(callback) {
        this.observe();
        this.callbacks.add(callback);
        return handle.make({ stop: () => this.callbacks.delete(callback) });
    },
};

const proxy = {
    swap(owner, property, install) {
        const own = Object.getOwnPropertyDescriptor(owner, property);
        if (own && !own.configurable) return;
        install(own);
        return () => {
            if (own) Object.defineProperty(owner, property, own);
            else delete owner[property];
        };
    },

    wrap(owner, property, traps, label) {
        const target = owner[property];
        if (typeof target !== "function") {
            console.warn(`[hook.${label}] '${property}' is not a function`);
            return handle.make({ applied: false });
        }

        const proto = target.prototype;
        const isConstructor = Boolean(proto && proto.constructor === target);
        const ctorDesc = isConstructor ? Object.getOwnPropertyDescriptor(proto, "constructor") : undefined;

        const undo = proxy.swap(owner, property, (own) => {
            const wrapped = new Proxy(target, traps);
            proxy.conceal(wrapped, target);
            if (isConstructor) {
                Object.defineProperty(proto, "constructor", {
                    value: wrapped,
                    writable: true,
                    configurable: true,
                    enumerable: false,
                });
            }
            if (own && "value" in own) Object.defineProperty(owner, property, { ...own, value: wrapped });
            else owner[property] = wrapped;
        });

        if (!undo) {
            console.warn(`[hook.${label}] '${property}' is not configurable`);
            return handle.make({ applied: false });
        }

        return handle.make({
            stop: () => {
                undo();
                if (!isConstructor) return;
                if (ctorDesc) Object.defineProperty(proto, "constructor", ctorDesc);
                else delete proto.constructor;
            },
        });
    },

    conceal(fake, original) {
        const bag = ctx.of("conceal");
        bag.originals ??= new WeakMap();
        bag.originals.set(fake, bag.originals.get(original) ?? original);
        if (bag.patched) return;
        bag.patched = true;

        const proto = win.Function.prototype;
        const native = win.Function.prototype.toString;
        const toString = function () {
            return native.call(bag.originals.get(this) ?? this);
        };

        Object.defineProperties(toString, {
            name: { value: "toString", configurable: true },
            length: { value: 0, configurable: true },
        });

        bag.originals.set(toString, native);

        proxy.swap(proto, "toString", (own) => Object.defineProperty(proto, "toString", {
            configurable: true,
            enumerable: own?.enumerable ?? true,
            get: () => toString,
            set: () => { },
        }));
    },
};

const hook = {
    apply(owner, property, fn) {
        return proxy.wrap(owner, property, {
            apply: (target, self, args) => fn({
                target, self, args,
                call: (next = args) => Reflect.apply(target, self, next),
            }),
        }, "apply");
    },

    define(owner, property, input) {
        const orig = hook.base(owner, property);
        const { get, set } = input;
        const isConstant = "value" in input;
        const isCustom = isConstant || Boolean(get);

        const undo = proxy.swap(owner, property, () => Object.defineProperty(owner, property, {
            configurable: true,
            enumerable: orig.desc?.enumerable ?? true,
            get() {
                if (!isCustom) return orig.get(this);
                if (isConstant) return input.value;
                return get.call(this, () => orig.get(this), this);
            },
            set(value) {
                if (!set) { orig.set(this, value); return; }
                const setter = (...out) => orig.set(this, out.length > 0 ? out[0] : value);
                set.call(this, value, setter, this);
            },
        }));

        if (!undo) {
            console.warn(`[hook.define] '${property}' is not configurable`);
            return handle.make({ applied: false });
        }

        return handle.make({ stop: undo });
    },

    setter(owner, property, fn) {
        return hook.define(owner, property, { set: (value, setter, self) => fn(value, setter, self) });
    },

    constant(owner, property, value) {
        return hook.define(owner, property, { value });
    },

    base(owner, property) {
        let desc;
        for (let o = owner; o && !desc; o = Object.getPrototypeOf(o)) {
            desc = Object.getOwnPropertyDescriptor(o, property);
        }
        const store = new WeakMap();
        return {
            desc,
            get(self) {
                if (desc?.get) return desc.get.call(self);
                return store.has(self) ? store.get(self) : desc?.value;
            },
            set(self, value) {
                if (desc?.set) desc.set.call(self, value);
                else if (!desc?.get) store.set(self, value);
            },
        };
    },

    listener(input = {}) {
        const matches = matcher.listener(input);
        return hook.apply(win.EventTarget.prototype, "addEventListener", ({ self, args, call }) => {
            const [name] = args;
            if (!matches(self, name)) return call();
        });
    },
};

const shadow = {
    roots: new WeakMap(),
    watcher: undefined,

    of(host) {
        return host.shadowRoot || this.roots.get(host);
    },

    capture() {
        if (this.watcher) return this.watcher;
        this.watcher = hook.apply(win.Element.prototype, "attachShadow", ({ self, call }) => {
            const root = call();
            this.roots.set(self, root);
            observer.attach(root);
            return root;
        });
        return this.watcher;
    },

    *select(selector, root = document) {
        const pierce = function* (nodes, parts) {
            if (parts.length === 0) {
                yield* nodes;
                return;
            }
            const [part, ...rest] = parts;
            for (const host of nodes) {
                const inner = shadow.of(host);
                if (!inner) continue;
                observer.attach(inner);
                yield* pierce(inner.querySelectorAll(part), rest);
            }
        };

        if (!selector.includes(">>>")) {
            yield* root.querySelectorAll(selector);
            return;
        }

        shadow.capture();
        const [head, ...tail] = selector.split(">>>").map(part => part.trim());
        yield* pierce(root.querySelectorAll(head), tail);
    },
};

const dom = {
    watch(target, handler, spec = {}) {
        const { match, limit: max, root = document } = spec;
        let nodes;

        if (typeof target !== "string") {
            nodes = target instanceof Node ? [target] : [...target ?? []].filter(Boolean);
        }

        if (nodes?.length === 0) return handle.make({ applied: false });

        const limit = max ?? (nodes ? nodes.length : Infinity);
        const seen = new WeakSet();

        let handled = 0;
        let isStopped = false;
        let isRunning = false;
        let isDirty = false;

        const { promise: done, resolve: settle } = Promise.withResolvers();

        const visit = async (node) => {
            if (seen.has(node)) return;
            const result = await safe.run(() => handler(node));
            if (result?.stop === true) return watcher.stop();
            if (result?.continue === true) return;
            seen.add(node);
            if (++handled >= limit) watcher.stop();
        };

        const sweep = async () => {
            const found = this.select(target, { match, root });
            for (const node of found) {
                if (isStopped) break;
                await visit(node);
            }
        };

        const run = async () => {
            if (isStopped) return;
            if (isRunning) { isDirty = true; return; }
            isRunning = true;
            await safe.run(sweep);
            isRunning = false;
            if (isDirty) { isDirty = false; run(); }
        };

        const changes = observer.change(run);

        const watcher = handle.make({
            stop: () => {
                isStopped = true;
                changes.stop();
                settle();
            },
            done,
        });

        run();
        return watcher;
    },

    *select(target, spec = {}) {
        const { match, root = document } = spec;
        let nodes;

        if (typeof target === "string") nodes = shadow.select(target, root);
        else nodes = target instanceof Node ? [target] : [...target ?? []].filter(Boolean);

        for (const node of nodes) {
            if (node?.isConnected && matcher.node(node, match)) yield node;
        }
    },
};

const el = {
    click(target, spec = {}) {
        const { wait = 0, scroll = false, times = 1, event, limit = 1, match } = spec;
        const { behavior = "smooth", block = "center", inline = "center" } = scroll === true ? {} : scroll;
        const init = { bubbles: true, cancelable: true, composed: true, view: win, ...event };
        let remaining = limit;

        return dom.watch(target, async (node) => {
            if (wait > 0) {
                await safe.sleep(wait);
                if (!node.isConnected || !matcher.node(node, match)) return { continue: true };
            }

            if (scroll !== false) node.scrollIntoView({ behavior, block, inline });
            for (let i = 0; i < times; i++) node.dispatchEvent(new MouseEvent("click", init));

            return --remaining <= 0 ? { stop: true } : { continue: true };
        }, { match });
    },
};

hook.constant(document, "hidden", false);
hook.constant(document, "webkitHidden", false);
hook.constant(document, "visibilityState", "visible");
hook.constant(document, "webkitVisibilityState", "visible");
hook.apply(win.Document.prototype, "hasFocus", () => true);

for (const type of ["visibilitychange", "webkitvisibilitychange", "blur", "pagehide", "freeze"]) {
    hook.listener({ type });
}

hook.setter(document, "onvisibilitychange", () => { });
hook.setter(win, "onblur", () => { });
hook.setter(win, "onpagehide", () => { });

const BUTTONS = [
    ".start-countdown-btn",
    "#btn7 > .ce-blue.ce-btn",
    "#btn6",
    "#cross-snp2",
    "#tp-snp2",
];

for (const selector of BUTTONS) {
    el.click(selector, { wait: 300, limit: Infinity, match: { visible: true } });
}
