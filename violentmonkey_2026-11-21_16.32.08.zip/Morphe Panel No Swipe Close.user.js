// ==UserScript==
// @name         Morphe Panel No Swipe Close
// @namespace    ftl.morphe-panel-noswipe
// @version      1.1.0
// @description  Stops swipe-down-to-close on panels and remembers panel scroll position.
// @author       Hyperion
// @match        https://morphe-patches.software/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  const saved = new Map();
  const tops = new WeakMap();
  let panel = null;
  let backdrop = null;
  let lastKey = null;
  let restoring = false;
  let token = 0;

  const getKey = () => {
    if (!panel) return '';
    const t = panel.querySelector('#ap-name, .ap-name, .ap-title, h1, h2, h3');
    const title = t ? t.textContent.trim() : '';
    const mode = (window.__panel && window.__panel.mode) || '';
    return title || mode ? mode + '|' + title : '';
  };

  const selOf = el => {
    if (el === panel) return '';
    if (el.id) return '#' + CSS.escape(el.id);
    if (el.classList.length) return '.' + CSS.escape(el.classList[0]);
    return null;
  };

  const onScroll = e => {
    const el = e.target;
    if (!(el instanceof Element)) return;
    const prev = tops.get(el) || 0;
    tops.set(el, el.scrollTop);
    if (restoring || !panel || !panel.contains(el)) return;
    if (prev === el.scrollTop) return;
    const key = getKey();
    const sel = selOf(el);
    if (!key || sel === null) return;
    saved.set(key, { sel, top: el.scrollTop });
  };

  const cancel = e => {
    const t = e.target;
    if (restoring && panel && t && t.closest && t.closest('#app-panel')) {
      token++;
      restoring = false;
    }
  };

  const restore = key => {
    const s = saved.get(key);
    const id = ++token;
    if (!s || s.top <= 0) {
      restoring = false;
      return;
    }
    restoring = true;
    const t0 = performance.now();
    const done = () => setTimeout(() => {
      if (id === token) restoring = false;
    }, 200);
    const step = () => {
      if (id !== token) return;
      const el = s.sel ? panel.querySelector(s.sel) : panel;
      const timeout = performance.now() - t0 > 2500;
      if (el && el.clientHeight > 0 && (timeout || el.scrollHeight - el.clientHeight >= s.top - 1)) {
        el.scrollTop = s.top;
        if (timeout || Math.abs(el.scrollTop - s.top) < 2) return done();
      }
      if (timeout) {
        restoring = false;
        return;
      }
      requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };

  const check = force => {
    const key = getKey();
    if (!force && key === lastKey) return;
    lastKey = key;
    if (!key) {
      token++;
      restoring = false;
      return;
    }
    restore(key);
  };

  for (const type of ['touchstart', 'wheel', 'pointerdown']) {
    window.addEventListener(type, cancel, { capture: true, passive: true });
  }
  window.addEventListener('scroll', onScroll, { capture: true, passive: true });

  const types = [
    'touchstart', 'touchmove', 'touchend', 'touchcancel',
    'pointerdown', 'pointermove', 'pointerup', 'pointercancel',
    'mousedown', 'mousemove', 'mouseup'
  ];
  const block = e => {
    const t = e.target;
    if (t && t.closest && t.closest('#app-panel')) e.stopImmediatePropagation();
  };
  for (const type of types) {
    window.addEventListener(type, block, { capture: true, passive: true });
  }

  const init = () => {
    panel = document.getElementById('app-panel');
    backdrop = document.getElementById('app-panel-backdrop');
    if (!panel) return;
    new MutationObserver(() => check(false)).observe(panel, {
      childList: true,
      subtree: true,
      characterData: true
    });
    if (backdrop) {
      new MutationObserver(() => {
        if (backdrop.hidden) {
          lastKey = null;
          token++;
          restoring = false;
        } else {
          check(true);
        }
      }).observe(backdrop, { attributes: true, attributeFilter: ['hidden'] });
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
