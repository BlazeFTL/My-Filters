// ==UserScript==
// @name         Dead Domain Checker 3.2
// @namespace    https://github.com/BlazeFTL
// @version      3.2
// @description  Parallel HTTP/HTTPS liveness with abort-on-win, parking detection, redirect handling, timing.
// @match        *://example.com/*
// @author       BlazeFTL
// @license      MIT
// @grant        GM_addStyle
// @grant        GM_xmlhttpRequest
// @connect      *
// ==/UserScript==

(function () {
  'use strict';

  GM_addStyle(`
    #vmBox { position: fixed; top: 15px; right: 15px; width: 95%; max-width: 450px; background: #1a1a1a; color: #fff; border-radius: 12px; padding: 15px; z-index: 999999; font-family: 'Segoe UI', sans-serif; box-shadow: 0 8px 24px rgba(0,0,0,0.8); border: 1px solid #444; }
    #vmBox b { display: block; margin-bottom: 5px; font-size: 16px; color: #ddd; }
    #vmBox textarea { width: 100%; background: #000; color: #00ff00; border: 1px solid #555; resize: vertical; margin-top: 5px; margin-bottom: 10px; font-size: 15px; padding: 8px; box-sizing: border-box; border-radius: 4px; font-family: monospace; }
    #vmBox button { margin-top: 5px; margin-right: 6px; padding: 10px 16px; background: #333; color: #fff; border: 1px solid #666; cursor: pointer; border-radius: 6px; font-size: 14px; font-weight: bold; }
    #vmBox button:disabled { opacity: 0.3; cursor: not-allowed; }
    #vmBox .btn-paste { background: #663300; border-color: #884400; }
    #vmBox .btn-toggle { background: #222; border: 1px dashed #777; }
    #vmBox .btn-toggle.active { background: #004d40; border: 1px solid #00bfa5; color: #00ffcc; }
    #vmOut { margin: 10px 0; min-height: 80px; max-height: 250px; overflow: auto; white-space: pre-wrap; font-size: 13px; padding: 10px; background: #0a0a0a; border-radius: 4px; border-left: 4px solid #444; font-family: monospace; }
    #vmProgressWrap { margin: 8px 0; background: #000; border-radius: 4px; overflow: hidden; height: 22px; position: relative; border: 1px solid #555; }
    #vmProgressBar { height: 100%; width: 0%; background: #00ff00; transition: width 0.15s ease; }
    #vmProgressText { position: absolute; top: 0; left: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: bold; text-shadow: 0 1px 2px #000; }
    .dead { color: #ff5555; font-weight: bold; }
    .live { color: #55ff55; font-weight: bold; }
    .skip { color: #ffcc00; font-weight: bold; }
    .note { color: #bbb; }
    .reason { color: #888; font-weight: normal; font-size: 12px; }
    .slow { color: #ffaa33; }
    .output-section { margin-top: 15px; padding-top: 10px; border-top: 1px solid #333; }
  `);

  const box = document.createElement('div');
  box.id = 'vmBox';
  box.innerHTML = `
    <b>Domain Checker v3.2</b>
    <textarea id="vmInput" rows="4" placeholder="Paste Domains Here..."></textarea>
    <div>
      <button id="vmPaste" class="btn-paste">Paste Content</button>
      <button id="vmCheck">Check Domains</button>
      <button id="vmClear">Clear All</button>
    </div>
    <div id="vmProgressWrap" style="display:none;">
      <div id="vmProgressBar"></div>
      <div id="vmProgressText">0 / 0 (0%)</div>
    </div>
    <div id="vmOut" class="note">Idle.</div>
    <div><button id="vmSortToggle" class="btn-toggle">Sort A-Z: OFF</button></div>
    <div class="output-section">
        <b>Working Domains (Comma):</b>
        <textarea id="vmComma" rows="2" readonly></textarea>
        <button id="copyComma" disabled>Copy Comma</button>
    </div>
    <div class="output-section">
        <b>Working Domains (Pipe):</b>
        <textarea id="vmPipe" rows="2" readonly></textarea>
        <button id="copyPipe" disabled>Copy Pipe</button>
    </div>
  `;
  document.body.appendChild(box);

  const input = box.querySelector('#vmInput'), out = box.querySelector('#vmOut'),
        commaBox = box.querySelector('#vmComma'), pipeBox = box.querySelector('#vmPipe'),
        copyComma = box.querySelector('#copyComma'), copyPipe = box.querySelector('#copyPipe'),
        checkBtn = box.querySelector('#vmCheck'), clearBtn = box.querySelector('#vmClear'),
        pasteBtn = box.querySelector('#vmPaste'), sortToggle = box.querySelector('#vmSortToggle');
  const progressWrap = box.querySelector('#vmProgressWrap'),
        progressBar = box.querySelector('#vmProgressBar'),
        progressText = box.querySelector('#vmProgressText');

  let isSortEnabled = false, lastWorkingDomains = [];

  const updateOutputBoxes = () => {
    let list = [...lastWorkingDomains];
    if (isSortEnabled) list.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
    commaBox.value = list.join(',');
    pipeBox.value = list.join('|');
    copyComma.disabled = copyPipe.disabled = list.length === 0;
  };

  const setProgress = (done, total) => {
    const pct = total ? Math.round((done / total) * 100) : 0;
    progressBar.style.width = pct + '%';
    progressText.textContent = `${done} / ${total} (${pct}%)`;
  };

  // ============================================================
  // Response analysis
  // ============================================================
  const PARKING_HOSTS = ['sedoparking.com', 'afternic.com', 'hugedomains.com',
    'dan.com', 'bodis.com', 'parkingcrew.net', 'undeveloped.com',
    'domainmarket.com', 'buydomains.com', 'above.com'];

  const PARKING_PHRASES = [
    'this domain is for sale', 'this domain may be for sale',
    'this domain name is for sale', 'buy this domain',
    'domain is parked', 'this web page is parked',
    'the domain has expired', 'domain has expired',
    'this website is for sale', 'inquiries about this domain',
    'get this domain', 'make an offer on this domain',
  ];

  const DOWN_PHRASES = [
    "site can't be reached", 'site cannot be reached',
    'this site is not available', 'this site is no longer available',
    'account suspended', 'site has been suspended',
    'website expired', 'this website has been suspended',
    'this domain has been suspended', 'service unavailable',
  ];

  const analyzeResponse = (res, originalUrl) => {
    const { status, body, finalUrl } = res;
    const lower = body.toLowerCase();
    const size = body.length;

    let redirectNote = '';
    try {
      const finalHost = new URL(finalUrl).hostname.toLowerCase();
      const origHost  = new URL(originalUrl).hostname.toLowerCase();

      if (finalHost !== origHost) {
        // Only kill it if it redirects to a known parking service
        if (PARKING_HOSTS.some(p => finalHost.includes(p))) {
          return { alive: false, reason: `→ parking (${finalHost})` };
        }
        // Otherwise, note the redirect but let the final destination's content decide liveness
        redirectNote = ` (→ ${finalHost})`;
      }
    } catch { /* ignore */ }

    if (status === 0)   return { alive: false, reason: 'no response' };
    if (status === 401) return { alive: true,  reason: `HTTP 401 (auth)${redirectNote}` };
    if (status === 429) return { alive: true,  reason: `HTTP 429 (rate limit)${redirectNote}` };

    if (status === 403) {
      if (lower.includes('cloudflare') || lower.includes('just a moment') ||
          lower.includes('cf-browser-verification') || lower.includes('ddos-guard')) {
        return { alive: true, reason: `HTTP 403 (bot protection)${redirectNote}` };
      }
      return { alive: false, reason: `HTTP 403 (forbidden)${redirectNote}` };
    }
    if (status >= 400)  return { alive: false, reason: `HTTP ${status}${redirectNote}` };

    if (size < 100)     return { alive: false, reason: `empty body (${size}b)${redirectNote}` };

    for (const p of PARKING_PHRASES) if (lower.includes(p)) return { alive: false, reason: `parking page${redirectNote}` };
    if (size < 3000) {
      for (const p of DOWN_PHRASES) if (lower.includes(p)) return { alive: false, reason: `site-down page ("${p}")${redirectNote}` };
    }

    const titleM = body.match(/<title[^>]*>([^<]+)<\/title>/i);
    if (titleM) {
      const t = titleM[1].toLowerCase().trim();
      if (/^(404|not found|page not found|error 404|error: 404)/.test(t)) {
        return { alive: false, reason: `title says "${titleM[1].trim()}"${redirectNote}` };
      }
    }

    const visibleText = body
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    const hasTitle = titleM && titleM[1].trim().length > 0;
    if (size < 2000 && visibleText.length < 20 && !hasTitle) {
      return { alive: false, reason: `hollow shell (no content/title)${redirectNote}` };
    }

    return { alive: true, reason: `HTTP ${status} (${size}b)${redirectNote}` };
  };

  // ============================================================
  // Network: single GM request wrapper
  // ============================================================
  const fireRequest = (url, timeout) => {
    let handle;
    const promise = new Promise((resolve) => {
      handle = GM_xmlhttpRequest({
        method: 'GET',
        url,
        timeout,
        onload: (r) => resolve({
          reachable: true,
          status: r.status,
          body: (r.responseText || '').slice(0, 500000),
          finalUrl: r.finalUrl || url,
        }),
        onerror:  () => resolve({ reachable: false, status: 0, body: '', finalUrl: url }),
        ontimeout:() => resolve({ reachable: false, status: 0, body: '', finalUrl: url }),
        onabort:  () => resolve({ reachable: false, status: 0, body: '', finalUrl: url }),
      });
    });
    return { handle, promise };
  };

  const dnsResolves = (domain) => new Promise((resolve) => {
    GM_xmlhttpRequest({
      method: 'GET',
      url: `https://dns.google/resolve?name=${domain}&type=A`,
      timeout: 3000,
      onload: (r) => {
        try {
          const d = JSON.parse(r.responseText);
          resolve(d.Status === 0 && !!d.Answer);
        } catch { resolve(false); }
      },
      onerror: () => resolve(false),
      ontimeout: () => resolve(false),
    });
  });

  // ============================================================
  // Parallel race: HTTPS vs HTTP
  // ============================================================
  const PROBE_TIMEOUT = 5000;
  const HTTPS_GRACE   = 1500;
  const SLOW_THRESHOLD = 3000;

  const normalizeDomain = (raw) => {
    let d = raw.trim().toLowerCase();
    d = d.replace(/^https?:\/\//, '');
    d = d.replace(/\/.*$/, '');
    d = d.replace(/:\d+$/, '');
    return d;
  };

  const checkDomain = (domain) => new Promise((resolve) => {
    const urlHttps = `https://${domain}`;
    const urlHttp  = `http://${domain}`;
    const t0 = performance.now();
    const elapsed = () => Math.round(performance.now() - t0);

    let done = false;
    let httpsRes = null, httpRes = null;
    let httpsHandle = null, httpHandle = null;
    let graceTimer = null;

    const finalize = async (res, url, method) => {
      if (done) return;
      done = true;
      clearTimeout(graceTimer);
      try { httpsHandle && httpsHandle.abort(); } catch {}
      try { httpHandle && httpHandle.abort(); } catch {}

      const analysis = analyzeResponse(res, url);

      let dnsNote = '';
      if (!res.reachable) {
        const ok = await dnsResolves(domain);
        dnsNote = ok ? ' · DNS ok' : ' · DNS fails';
      }

      resolve({ ...analysis, ms: elapsed(), url, method, dnsNote });
    };

    const tryFinalize = () => {
      if (httpsRes && httpRes) {
        if (httpsRes.reachable) {
          const a = analyzeResponse(httpsRes, urlHttps);
          if (a.alive) return finalize(httpsRes, urlHttps, 'HTTPS');
        }
        if (httpRes.reachable) {
          const a = analyzeResponse(httpRes, urlHttp);
          if (a.alive) return finalize(httpRes, urlHttp, 'HTTP');
        }
        const pick = httpsRes.reachable ? httpsRes : httpRes;
        const url  = httpsRes.reachable ? urlHttps : urlHttp;
        return finalize(pick, url, httpsRes.reachable ? 'HTTPS' : 'HTTP');
      }

      if (httpRes && !httpsRes && httpRes.reachable) {
        const a = analyzeResponse(httpRes, urlHttp);
        if (a.alive && !graceTimer) {
          graceTimer = setTimeout(() => finalize(httpRes, urlHttp, 'HTTP'), HTTPS_GRACE);
        }
      }

      if (httpsRes && !httpRes && httpsRes.reachable) {
        const a = analyzeResponse(httpsRes, urlHttps);
        if (a.alive) return finalize(httpsRes, urlHttps, 'HTTPS');
      }
    };

    {
      const { handle, promise } = fireRequest(urlHttps, PROBE_TIMEOUT);
      httpsHandle = handle;
      promise.then(r => { httpsRes = r; tryFinalize(); });
    }
    {
      const { handle, promise } = fireRequest(urlHttp, PROBE_TIMEOUT);
      httpHandle = handle;
      promise.then(r => { httpRes = r; tryFinalize(); });
    }
  });

  // ============================================================
  // UI wiring
  // ============================================================
  checkBtn.onclick = async () => {
    const rawList = input.value.split(/[,\|\s\n]+/).map(s => s.trim()).filter(Boolean);
    if (!rawList.length) return;

    out.innerHTML = '';
    checkBtn.disabled = true;

    const total = rawList.length;
    let done = 0;
    const t0 = performance.now();
    progressWrap.style.display = 'block';
    setProgress(0, total);
    lastWorkingDomains = [];

    const lines = rawList.map((d) => {
      const span = document.createElement('div');
      span.className = 'note';
      span.textContent = `⏳ ${d}`;
      out.appendChild(span);
      return span;
    });

    let liveCount = 0, deadCount = 0;

    await Promise.all(rawList.map(async (raw, i) => {
      const span = lines[i];

      if (raw.includes('.*')) {
        span.className = 'skip';
        span.textContent = `⏭ ${raw} — wildcard`;
        lastWorkingDomains.push(raw);
        done++; setProgress(done, total); updateOutputBoxes();
        return;
      }

      const domain = normalizeDomain(raw);
      const result = await checkDomain(domain);

      const slowClass = result.ms >= SLOW_THRESHOLD ? 'slow' : 'reason';
      const meta = `<span class="${slowClass}">— ${result.reason} · ${result.ms}ms · ${result.method}${result.dnsNote}</span>`;

      if (result.alive) {
        liveCount++;
        span.className = 'live';
        span.innerHTML = `✅ ${raw} ${meta}`;
        lastWorkingDomains.push(raw);
      } else {
        deadCount++;
        span.className = 'dead';
        span.innerHTML = `❌ ${raw} ${meta}`;
      }

      done++;
      setProgress(done, total);
      updateOutputBoxes();
    }));

    const totalMs = Math.round(performance.now() - t0);
    const summary = document.createElement('div');
    summary.className = 'note';
    summary.style.marginBottom = '8px';
    summary.textContent = `Done in ${totalMs}ms — ✅ ${liveCount} live / ❌ ${deadCount} dead (of ${total})`;
    out.insertBefore(summary, out.firstChild);

    checkBtn.disabled = false;
  };

  sortToggle.onclick = () => {
    isSortEnabled = !isSortEnabled;
    sortToggle.textContent = `Sort A-Z: ${isSortEnabled ? 'ON' : 'OFF'}`;
    sortToggle.classList.toggle('active', isSortEnabled);
    updateOutputBoxes();
  };
  pasteBtn.onclick = async () => { try { input.value = await navigator.clipboard.readText(); } catch {} };
  clearBtn.onclick = () => {
    input.value = ''; out.textContent = 'Idle.';
    commaBox.value = pipeBox.value = '';
    lastWorkingDomains = [];
    progressWrap.style.display = 'none';
    setProgress(0, 0);
  };
  copyComma.onclick = () => navigator.clipboard.writeText(commaBox.value);
  copyPipe.onclick  = () => navigator.clipboard.writeText(pipeBox.value);
})();