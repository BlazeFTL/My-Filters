// ==UserScript==
// @name         pahe.ink new tab links
// @match        https://pahe.ink/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  const sel = 'a.shortc-button';
  const handler = e => {
    const a = e.target.closest && e.target.closest(sel);
    if (!a) return;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    e.stopImmediatePropagation();
  };
  ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'auxclick'].forEach(t =>
    window.addEventListener(t, handler, true)
  );
})();