// ==UserScript==
// @name         GitHub Branch Chips
// @namespace    blazeftl.github-branch-chips
// @version      1.0.3
// @description  One button per branch on GitHub repo pages for one-tap branch switching
// @match        https://github.com/*/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const BAR_ID = 'ftl-branch-chips';
  const STYLE_ID = 'ftl-branch-chips-style';
  const SEL_ID = 'ref-picker-repos-header-ref-selector';

  const css = `
#${BAR_ID} {
  display: flex;
  flex-wrap: nowrap;
  gap: 6px;
  overflow-x: auto;
  padding: 0;
  margin: 0;
  scrollbar-width: none;
  -webkit-overflow-scrolling: touch;
}
#${BAR_ID}::-webkit-scrollbar { display: none; }
#${BAR_ID} a {
  flex: 0 0 auto;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 12px;
  border: 1px solid var(--borderColor-default, #d1d9e0);
  border-radius: 999px;
  background: var(--bgColor-muted, #f6f8fa);
  color: var(--fgColor-default, #1f2328);
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  text-decoration: none;
}
#${BAR_ID} a:active { filter: brightness(0.95); }
#${BAR_ID} a[aria-current="true"] {
  background: var(--bgColor-accent-emphasis, #0969da);
  border-color: var(--bgColor-accent-emphasis, #0969da);
  color: var(--fgColor-onEmphasis, #fff);
}
`;

  let repoKey = '';
  let branches = [];
  let loading = false;
  let signature = '';

  function addStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = css;
    document.documentElement.appendChild(s);
  }

  function getRepo() {
    const m = location.pathname.match(/^\/([^/]+)\/([^/]+)(?:\/|$)/);
    return m ? { owner: m[1], repo: m[2] } : null;
  }

  function readCache(key) {
    try {
      const v = JSON.parse(sessionStorage.getItem('ftl-branches:' + key));
      return Array.isArray(v) ? v : [];
    } catch (e) {
      return [];
    }
  }

  function writeCache(key, list) {
    try {
      sessionStorage.setItem('ftl-branches:' + key, JSON.stringify(list));
    } catch (e) {}
  }

  async function fetchBranches(owner, repo) {
    const out = [];
    try {
      const res = await fetch(`/${owner}/${repo}/refs?type=branch&q=`, {
        credentials: 'same-origin',
        headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
      });
      if (res.ok) {
        const json = await res.json();
        if (Array.isArray(json.refs)) json.refs.forEach((n) => out.includes(n) || out.push(n));
      }
    } catch (e) {}
    try {
      const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/branches?per_page=100`);
      if (res.ok) {
        const json = await res.json();
        if (Array.isArray(json)) json.forEach((x) => out.includes(x.name) || out.push(x.name));
      }
    } catch (e) {}
    return out;
  }

  function load(owner, repo, key) {
    if (loading) return;
    loading = true;
    fetchBranches(owner, repo).then((list) => {
      loading = false;
      if (key !== repoKey) return;
      if (list.length) {
        branches = list;
        writeCache(key, list);
        signature = '';
        update();
      }
    });
  }

  function currentState(owner, repo, sel) {
    const m = location.pathname.match(/^\/[^/]+\/[^/]+\/(tree|blob)\/(.+?)\/?$/);
    if (m) {
      let rest;
      try {
        rest = decodeURIComponent(m[2]);
      } catch (e) {
        rest = m[2];
      }
      const hit = branches
        .filter((b) => rest === b || rest.startsWith(b + '/'))
        .sort((a, b) => b.length - a.length)[0];
      if (hit) return { type: m[1], current: hit, sub: rest.slice(hit.length) };
      return { type: m[1], current: '', sub: '' };
    }
    const t = sel.querySelector('.ref-selector-button-text-container');
    return { type: null, current: t ? t.textContent.trim() : '', sub: '' };
  }

  function buildBar(owner, repo, state) {
    const bar = document.createElement('div');
    bar.id = BAR_ID;
    for (const b of branches) {
      const a = document.createElement('a');
      const path = state.type
        ? `/${owner}/${repo}/${state.type}/${encodeURI(b)}${state.sub.split('/').map(encodeURIComponent).join('/')}`
        : `/${owner}/${repo}/tree/${encodeURI(b)}`;
      a.href = path;
      a.textContent = b;
      if (b === state.current) a.setAttribute('aria-current', 'true');
      bar.appendChild(a);
    }
    return bar;
  }

  function visibleBottom(el) {
    let max = 0;
    el.querySelectorAll('button, a, input').forEach((n) => {
      const r = n.getBoundingClientRect();
      if (r.width > 0 && r.height > 0 && r.bottom > max) max = r.bottom;
    });
    return max || el.getBoundingClientRect().bottom;
  }

  function update() {
    addStyle();
    const sel = document.getElementById(SEL_ID);
    const existing = document.getElementById(BAR_ID);
    const info = getRepo();
    if (!sel || !info) {
      if (existing) existing.remove();
      return;
    }

    const key = info.owner + '/' + info.repo;
    if (key !== repoKey) {
      repoKey = key;
      branches = readCache(key);
      signature = '';
      load(info.owner, info.repo, key);
    }
    if (!branches.length) return;

    const state = currentState(info.owner, info.repo, sel);
    const sig = key + '|' + location.pathname + '|' + state.current + '|' + branches.join(',');

    let row = sel.parentElement;
    while (row && !row.querySelector('a[href$="/branches"]')) row = row.parentElement;
    if (!row || !row.parentElement) return;
    const outer = row.parentElement;

    if (existing && sig === signature && existing.previousElementSibling === outer) return;

    signature = sig;
    if (existing) existing.remove();
    const bar = buildBar(info.owner, info.repo, state);
    outer.insertAdjacentElement('afterend', bar);

    requestAnimationFrame(() => {
      bar.style.marginTop = '0px';
      bar.style.marginBottom = '0px';
      const gapTop = bar.getBoundingClientRect().top - visibleBottom(outer);
      bar.style.marginTop = 8 - gapTop + 'px';
      const next = bar.nextElementSibling;
      if (next && next.getBoundingClientRect().height > 0) {
        const gapBottom = next.getBoundingClientRect().top - bar.getBoundingClientRect().bottom;
        bar.style.marginBottom = 10 - gapBottom + 'px';
      }
    });

    const active = bar.querySelector('[aria-current="true"]');
    if (active) bar.scrollLeft = Math.max(0, active.offsetLeft - 16);
  }

  let queued = false;
  function schedule() {
    if (queued) return;
    queued = true;
    requestAnimationFrame(() => {
      queued = false;
      update();
    });
  }

  addStyle();
  update();
  new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener('turbo:render', schedule);
  document.addEventListener('turbo:load', schedule);
})();
