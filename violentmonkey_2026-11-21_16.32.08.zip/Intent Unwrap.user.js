// ==UserScript==
// @name         Intent Unwrap
// @namespace    blazeftl
// @version      1.1
// @match        https://liteshort.com/*
// @match        https://*.portalresult.in/*
// @run-at       document-start
// @inject-into  page
// @grant        none
// ==/UserScript==

(function () {
  const UA = 'Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0';
  const spoof = (o, k, v) => {
    try {
      Object.defineProperty(o, k, { get: () => v, configurable: true });
    } catch (e) {}
  };
  const np = Object.getPrototypeOf(navigator);
  spoof(np, 'userAgent', UA);
  spoof(np, 'appVersion', '5.0 (X11)');
  spoof(np, 'platform', 'Linux x86_64');
  spoof(np, 'maxTouchPoints', 0);
  spoof(np, 'userAgentData', undefined);

  let done = false;
  const norm = (t) => t.replace(/\\\//g, '/').replace(/\\u0026/gi, '&').replace(/&amp;/g, '&');
  const conv = (raw) => {
    const u = norm(raw || '');
    if (!/^intent:/i.test(u)) return null;
    const m = u.match(/^intent:\/\/(.*?)#Intent;(.*)$/i);
    if (!m) return null;
    const s = (m[2].match(/(?:^|;)scheme=([^;]+)/i) || [])[1] || 'https';
    if (/^https?$/i.test(s)) return s + '://' + m[1];
    const fb = m[2].match(/(?:^|;)S\.browser_fallback_url=([^;]+)/i);
    return fb ? decodeURIComponent(fb[1]) : null;
  };
  const find = (t) => {
    const m = norm(t).match(/intent:\/\/[^\s"'<>\\]+#Intent;[^"'<>\s\\]*/i);
    return m ? conv(m[0]) : null;
  };
  const go = (url) => {
    if (!url || done) return;
    done = true;
    location.replace(url);
  };
  const scanNode = (n) => {
    if (n.nodeType !== 1) return;
    if (n.tagName === 'A' && /^intent:/i.test(n.getAttribute('href') || '')) return go(conv(n.getAttribute('href')));
    if (n.tagName === 'SCRIPT') return go(find(n.textContent || ''));
    const a = n.querySelector && n.querySelector('a[href^="intent:" i]');
    if (a) go(conv(a.getAttribute('href')));
  };
  new MutationObserver((ms) => {
    for (const m of ms) m.addedNodes.forEach(scanNode);
  }).observe(document, { childList: true, subtree: true });
  document.addEventListener('DOMContentLoaded', () => go(find(document.documentElement.innerHTML)));
  document.addEventListener(
    'click',
    (e) => {
      const a = e.target.closest && e.target.closest('a[href^="intent:" i], a[href^="market:" i]');
      if (a) {
        e.preventDefault();
        e.stopImmediatePropagation();
        go(conv(a.getAttribute('href')));
      }
    },
    true
  );
  const wo = window.open;
  window.open = function (u, ...r) {
    if (typeof u === 'string' && /^(intent|market):/i.test(u)) {
      go(conv(u));
      return null;
    }
    return wo.call(this, u, ...r);
  };
  if (window.navigation) {
    navigation.addEventListener('navigate', (e) => {
      const u = e.destination.url;
      if (/^(intent|market):/i.test(u)) {
        if (e.cancelable) e.preventDefault();
        go(conv(u));
      }
    });
  }
})();
