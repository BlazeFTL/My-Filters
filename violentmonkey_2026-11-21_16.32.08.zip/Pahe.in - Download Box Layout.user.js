// ==UserScript==
// @name         Pahe.in - Download Box Layout
// @namespace    github.com/BlazeFTL
// @version      1.0.0
// @description  Rebuilds Pahe download boxes into clean rows with aligned button grids. Pairs with Pahe.in - Modern Light UI.
// @author       BlazeFTL
// @match        *://pahe.ink/*
// @match        *://pahe.in/*
// @run-at       document-end
// @grant        GM_addStyle
// ==/UserScript==

(function () {
  'use strict';

  const css = `
    .pd-orig { display: none !important; }
    .pd { display: flex; flex-direction: column; }
    .pd-head { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; margin-bottom: 12px; }
    .pd-chip { background: linear-gradient(135deg, #2563eb, #7c3aed); color: #fff; font-weight: 700; font-size: 12px; letter-spacing: .02em; padding: 4px 12px; border-radius: 999px; }
    .pd-meta { background: #eef2f7; color: #64748b; font-weight: 600; font-size: 12px; padding: 4px 10px; border-radius: 999px; }
    .pd-note { background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; color: #64748b; font-size: 11.5px; font-weight: 500; line-height: 1.4; padding: 6px 10px; margin-bottom: 12px; word-break: break-word; }
    .pd-row + .pd-note { margin-top: 12px; }
    .pd-row + .pd-row { margin-top: 12px; padding-top: 12px; border-top: 1px dashed #e2e8f0; }
    .pd-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 8px; }
    .pd-title { color: #1e293b; font-weight: 700; font-size: 13px; line-height: 1.3; }
    .pd-size { background: #f1f5f9; color: #475569; font-weight: 600; font-size: 11.5px; border-radius: 6px; padding: 2px 8px; white-space: nowrap; }
    .pd-btns { display: grid; grid-template-columns: repeat(var(--c, 4), minmax(0, 1fr)); gap: 6px; }
    html body .pd-btns a.shortc-button,
    html body .pd-btns a.shortc-button:is(:link, :visited, :hover, :active, :focus) {
      display: flex !important; align-items: center; justify-content: center;
      width: 100%; min-width: 0 !important; height: 34px; margin: 0 !important; padding: 0 !important;
      border: 0 !important; border-radius: 10px !important; box-sizing: border-box;
      color: #fff !important; -webkit-text-fill-color: #fff !important;
      font-size: 12px !important; font-weight: 700 !important; letter-spacing: .03em; line-height: 1 !important;
      box-shadow: 0 2px 6px rgba(0,0,0,.14) !important; text-shadow: none !important; transition: transform .15s, filter .15s;
    }
    html body .pd-btns a.shortc-button:active { transform: scale(.94); }
    html body .pd-btns a.shortc-button.green { background: linear-gradient(135deg, #22c55e, #16a34a) !important; }
    html body .pd-btns a.shortc-button.red { background: linear-gradient(135deg, #f87171, #ef4444) !important; }
    html body .pd-btns a.shortc-button.orange { background: linear-gradient(135deg, #fbbf24, #f59e0b) !important; }
    html body .pd-btns a.shortc-button.blue { background: linear-gradient(135deg, #3b82f6, #2563eb) !important; }
    html body .pd-btns a.shortc-button.purple { background: linear-gradient(135deg, #a78bfa, #8b5cf6) !important; }
    html body .pd-btns a.shortc-button.black { background: linear-gradient(135deg, #475569, #334155) !important; }
    html body .pd-btns a.shortc-button.pink { background: linear-gradient(135deg, #f472b6, #ec4899) !important; }
  `;

  if (typeof GM_addStyle === 'function') {
    GM_addStyle(css);
  } else {
    const style = document.createElement('style');
    style.textContent = css;
    document.head.appendChild(style);
  }

  const clean = (t) => t.replace(/[\s\u00a0]+/g, ' ').trim();

  const make = (tag, cls, text) => {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  };

  function parse(inner) {
    const items = [];
    let cur = null;
    let heading = null;

    const flush = () => {
      if (!cur) return;
      if (cur.btns.length) items.push({ type: 'row', row: cur });
      else if (cur.label) items.push({ type: 'note', text: cur.label });
      cur = null;
    };

    const start = () => {
      if (!cur) {
        cur = { label: '', btns: [], heading, br: false };
        heading = null;
      }
    };

    for (const n of Array.from(inner.childNodes)) {
      if (n.nodeType === 3) {
        const t = clean(n.textContent);
        if (!t) continue;
        const last = items[items.length - 1];
        if (!cur && last && last.type === 'chip' && !last.meta) {
          last.meta = t.replace(/^\|\s*/, '');
          continue;
        }
        if (cur && cur.btns.length) flush();
        else if (cur && cur.br) flush();
        start();
        cur.label += (cur.label ? ' ' : '') + t;
        continue;
      }
      if (n.nodeType !== 1) continue;
      const tag = n.tagName;
      if (tag === 'I') continue;
      if (tag === 'BR') {
        if (cur && !cur.btns.length && cur.label) cur.br = true;
        continue;
      }
      if (tag === 'A') {
        start();
        cur.btns.push(n);
        continue;
      }
      if (tag === 'SPAN' && n.querySelector('b')) {
        flush();
        items.push({ type: 'chip', text: clean(n.textContent), meta: '' });
        continue;
      }
      if (tag === 'B') {
        flush();
        heading = clean(n.textContent);
        continue;
      }
      const t = clean(n.textContent);
      if (t) {
        if (cur && cur.btns.length) flush();
        start();
        cur.label += (cur.label ? ' ' : '') + t;
      }
    }
    flush();
    return items;
  }

  function build(items) {
    const root = make('div', 'pd');
    const chip = items.find((i) => i.type === 'chip');
    if (chip) {
      const head = make('div', 'pd-head');
      head.appendChild(make('span', 'pd-chip', chip.text));
      if (chip.meta) head.appendChild(make('span', 'pd-meta', chip.meta));
      root.appendChild(head);
    }
    for (const item of items) {
      if (item.type === 'note') {
        root.appendChild(make('div', 'pd-note', item.text));
      } else if (item.type === 'row') {
        const { label, btns, heading } = item.row;
        let title = '';
        let size = '';
        if (heading) {
          title = heading;
          size = label;
        } else if (label.includes('|')) {
          const idx = label.indexOf('|');
          title = clean(label.slice(0, idx));
          size = clean(label.slice(idx + 1));
        } else {
          title = label;
        }
        const row = make('div', 'pd-row');
        const top = make('div', 'pd-top');
        top.appendChild(make('span', 'pd-title', title));
        if (size) top.appendChild(make('span', 'pd-size', size));
        row.appendChild(top);
        const grid = make('div', 'pd-btns');
        grid.style.setProperty('--c', String(btns.length > 5 ? 4 : Math.max(4, btns.length)));
        btns.forEach((b) => grid.appendChild(b));
        row.appendChild(grid);
        root.appendChild(row);
      }
    }
    return root;
  }

  function process(box) {
    if (box.dataset.pd) return;
    const inner = box.querySelector('.box-inner-block');
    if (!inner) return;
    const items = parse(inner);
    if (!items.some((i) => i.type === 'row')) return;
    box.dataset.pd = '1';
    inner.classList.add('pd-orig');
    inner.insertAdjacentElement('afterend', build(items));
  }

  const run = () => document.querySelectorAll('.box.download').forEach(process);

  run();
  new MutationObserver(run).observe(document.body, { childList: true, subtree: true });
})();