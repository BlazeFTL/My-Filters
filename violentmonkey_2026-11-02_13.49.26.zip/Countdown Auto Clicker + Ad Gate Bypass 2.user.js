// ==UserScript==
// @name         Countdown Auto Clicker + Ad Gate Bypass 2
// @namespace    ftl.countdown-autoclick
// @version      2.3
// @description  Click #btn6/#btn7 after .countdown ends; click #startCountdownBtn when shown, then #cross-snp2 after countdown ends; click #tp-snp2 after #tp-time ends; on sarkarijobcorner.com set adcadg cookie, hide ad overlays and trigger the site's own IFRAME-focus check so its natural flow runs. Clicks are human-like. Works in background tabs.
// @match        *://*.pipefitter.in/*
// @match        *://*.entiredust.in/*
// @match        *://*.dharona.in/*
// @match        *://*.krishitalk.com/*
// @match        *://*.newsfront.xyz/*
// @match        *://*.naukaritimes24.in/*
// @match        *://*.sarkarijobcorner.com/*
// @run-at       document-start
// @noframes
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const POLL = 300;
  const GRACE = 8000;
  const TOUCH = navigator.maxTouchPoints > 0;

  const spoof = {
    hidden: false,
    webkitHidden: false,
    mozHidden: false,
    msHidden: false,
    visibilityState: 'visible',
    webkitVisibilityState: 'visible',
    mozVisibilityState: 'visible'
  };
  for (const k in spoof) {
    try {
      Object.defineProperty(document, k, { get: () => spoof[k], configurable: true });
    } catch (e) {}
  }
  try { document.hasFocus = () => true; } catch (e) {}

  const stop = e => e.stopImmediatePropagation();
  for (const n of ['visibilitychange', 'webkitvisibilitychange', 'mozvisibilitychange', 'freeze', 'resume']) {
    window.addEventListener(n, stop, true);
    document.addEventListener(n, stop, true);
  }
  window.addEventListener('blur', e => {
    const a = document.activeElement;
    if (e.target === window && !(a && a.tagName === 'IFRAME')) e.stopImmediatePropagation();
  }, true);
  document.addEventListener('blur', e => {
    if (e.target === document) e.stopImmediatePropagation();
  }, true);

  try {
    navigator.locks.request('ftl-keepalive', () => new Promise(() => {}));
  } catch (e) {}

  let worker = null;
  const pending = new Map();
  let seq = 0;
  try {
    const src = 'onmessage=e=>setTimeout(()=>postMessage(e.data.id),e.data.ms)';
    worker = new Worker(URL.createObjectURL(new Blob([src], { type: 'application/javascript' })));
    worker.onmessage = e => {
      const r = pending.get(e.data);
      if (r) {
        pending.delete(e.data);
        r();
      }
    };
    worker.onerror = () => {
      worker = null;
      pending.forEach(r => r());
      pending.clear();
    };
  } catch (e) {
    worker = null;
  }

  const $ = s => document.querySelector(s);
  const sleep = ms => worker
    ? new Promise(r => {
        const id = ++seq;
        pending.set(id, r);
        worker.postMessage({ id, ms });
      })
    : new Promise(r => setTimeout(r, ms));
  const rand = (a, b) => a + Math.random() * (b - a);
  const wait = (a, b) => sleep(rand(a, b));

  const visible = el => {
    if (!el || el.getClientRects().length === 0) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none';
  };

  let pid = 1;

  const sameTab = el => {
    const fix = a => {
      if (/^_blank$/i.test(a.getAttribute('target') || '')) a.setAttribute('target', '_self');
    };
    const up = el.closest && el.closest('a[target]');
    if (up) fix(up);
    if (el.querySelectorAll) el.querySelectorAll('a[target]').forEach(fix);
    const form = el.closest && el.closest('form[target]');
    if (form) fix(form);
    document.querySelectorAll('base[target]').forEach(fix);
  };

  let clickUntil = 0;
  let opened = false;
  const nativeOpen = window.open;
  window.open = function (url) {
    if (Date.now() >= clickUntil) return nativeOpen.apply(this, arguments);
    if (url && !opened && !/^about:blank$/i.test(String(url))) {
      opened = true;
      location.href = url;
    }
    return window;
  };

  const fire = (t, type, x, y, buttons) => {
    if (type === 'click') {
      sameTab(t);
      clickUntil = Date.now() + 2500;
      opened = false;
    }
    const ptr = type.startsWith('pointer') || type === 'click';
    const Ev = ptr ? PointerEvent : MouseEvent;
    t.dispatchEvent(new Ev(type, {
      bubbles: !/enter|leave/.test(type),
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: x + window.screenX,
      screenY: y + window.screenY,
      button: 0,
      buttons,
      detail: /^(mousedown|mouseup|click)$/.test(type) ? 1 : 0,
      pointerId: TOUCH ? pid : 1,
      pointerType: TOUCH ? 'touch' : 'mouse',
      isPrimary: true,
      width: TOUCH ? rand(14, 26) : 1,
      height: TOUCH ? rand(14, 26) : 1,
      pressure: buttons ? (TOUCH ? rand(0.3, 0.6) : 0.5) : 0
    }));
  };

  const touch = (t, type, x, y) => {
    if (!TOUCH) return;
    try {
      const p = new Touch({
        identifier: pid,
        target: t,
        clientX: x,
        clientY: y,
        screenX: x,
        screenY: y,
        pageX: x + window.scrollX,
        pageY: y + window.scrollY,
        radiusX: rand(6, 12),
        radiusY: rand(6, 12),
        force: rand(0.3, 0.7)
      });
      const end = type === 'touchend';
      t.dispatchEvent(new TouchEvent(type, {
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
        touches: end ? [] : [p],
        targetTouches: end ? [] : [p],
        changedTouches: [p]
      }));
    } catch (e) {}
  };

  const glide = async (x, y) => {
    const sx = rand(0, window.innerWidth);
    const sy = rand(0, window.innerHeight);
    const n = Math.floor(rand(6, 12));
    for (let i = 1; i <= n; i++) {
      const k = i / n;
      const e = k * k * (3 - 2 * k);
      const cx = sx + (x - sx) * e + rand(-5, 5) * (1 - k);
      const cy = sy + (y - sy) * e + rand(-5, 5) * (1 - k);
      const t = document.elementFromPoint(cx, cy) || document.body;
      fire(t, 'pointermove', cx, cy, 0);
      fire(t, 'mousemove', cx, cy, 0);
      await wait(8, 30);
    }
  };

  const humanScroll = async el => {
    const r = el.getBoundingClientRect();
    const dy = r.top + r.height / 2 - window.innerHeight * rand(0.35, 0.6);
    if (Math.abs(dy) > 4) {
      const n = Math.floor(rand(10, 18));
      let done = 0;
      for (let i = 1; i <= n; i++) {
        const k = i / n;
        const to = dy * (1 - Math.pow(1 - k, 3));
        window.scrollBy(0, to - done);
        done = to;
        await wait(12, 28);
      }
      await wait(150, 350);
    }
    const q = el.getBoundingClientRect();
    if (q.bottom < 0 || q.top > window.innerHeight) {
      el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'instant' });
    }
  };

  const tapTouch = async (el, t, x, y) => {
    pid++;
    fire(t, 'pointerover', x, y, 0);
    fire(t, 'pointerenter', x, y, 0);
    fire(t, 'pointerdown', x, y, 1);
    touch(t, 'touchstart', x, y);
    const hold = rand(70, 150);
    const steps = Math.floor(rand(1, 4));
    for (let i = 0; i < steps; i++) {
      await sleep(hold / steps);
      x += rand(-0.8, 0.8);
      y += rand(-0.8, 0.8);
      fire(t, 'pointermove', x, y, 1);
      touch(t, 'touchmove', x, y);
    }
    fire(t, 'pointerup', x, y, 0);
    fire(t, 'pointerout', x, y, 0);
    fire(t, 'pointerleave', x, y, 0);
    touch(t, 'touchend', x, y);
    await wait(4, 20);
    for (const type of ['mouseover', 'mouseenter', 'mousemove']) fire(t, type, x, y, 0);
    fire(t, 'mousedown', x, y, 1);
    try { el.focus({ preventScroll: true }); } catch (e) {}
    await wait(2, 10);
    fire(t, 'mouseup', x, y, 0);
    fire(t, 'click', x, y, 0);
  };

  const humanClick = async el => {
    sameTab(el);
    await humanScroll(el);
    await wait(150, 400);
    const r = el.getBoundingClientRect();
    const x = r.left + r.width * rand(0.25, 0.75);
    const y = r.top + r.height * rand(0.3, 0.7);
    const hit = document.elementFromPoint(x, y);
    const t = hit && el.contains(hit) ? hit : el;

    if (TOUCH) return tapTouch(el, t, x, y);

    await glide(x, y);
    for (const type of ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']) {
      fire(t, type, x, y, 0);
    }
    await wait(60, 220);
    fire(t, 'pointerdown', x, y, 1);
    fire(t, 'mousedown', x, y, 1);
    try { el.focus({ preventScroll: true }); } catch (e) {}
    await wait(50, 150);
    fire(t, 'pointerup', x, y, 0);
    fire(t, 'mouseup', x, y, 0);
    fire(t, 'click', x, y, 0);
  };

  const waitFor = async sel => {
    for (;;) {
      const el = $(sel);
      if (visible(el) && !el.disabled) return el;
      await sleep(POLL);
    }
  };

  const clickEl = async sel => {
    const el = await waitFor(sel);
    await wait(500, 1600);
    await humanClick(el);
    await wait(300, 700);
  };

  const isActive = el => {
    if (!visible(el)) return false;
    const nums = (el.textContent || '').match(/-?\d+/g);
    return !!nums && nums.some(n => parseInt(n, 10) > 0);
  };

  const waitCountdownDone = async (sel = '.countdown') => {
    const start = Date.now();
    let seen = false;
    for (;;) {
      const el = $(sel);
      if (el && isActive(el)) seen = true;
      else if (seen) return;
      else if (Date.now() - start > GRACE) return;
      await sleep(POLL);
    }
  };

  const focusFrame = () => {
    let f = document.getElementById('ftl-focus-frame');
    if (!f) {
      f = document.createElement('iframe');
      f.id = 'ftl-focus-frame';
      f.setAttribute('aria-hidden', 'true');
      f.style.cssText = 'position:fixed;left:0;top:0;width:1px;height:1px;opacity:0;border:0;pointer-events:none';
      (document.body || document.documentElement).appendChild(f);
    }
    try { f.focus(); } catch (e) {}
    try { f.contentWindow.focus(); } catch (e) {}
  };

  const triggerAdCheck = async () => {
    if (!$('#ggd-container')) return;
    const end = Date.now() + 60000;
    let n = 0;
    do {
      const a = document.activeElement;
      if (!a || a.tagName !== 'IFRAME') focusFrame();
      if (n++ % 4 === 0) {
        try { window.dispatchEvent(new FocusEvent('blur')); } catch (e) {}
      }
      await sleep(POLL);
    } while (Date.now() < end && !visible($('#btn6')));
  };

  if (/(?:^|\.)sarkarijobcorner\.com$/.test(location.hostname)) {
    const COOKIE_VALUE = 'insurance,online_colleges,study_abroad,finance,loan';

    if (!/(?:^|;\s*)adcadg=/.test(document.cookie)) {
      document.cookie = 'adcadg=' + COOKIE_VALUE + '; max-age=3600; path=/';
    }

    const style = document.createElement('style');
    style.textContent = '#ggd-container,#block-cont-1,#adOverlay{display:none!important}';
    (document.head || document.documentElement).appendChild(style);

    new MutationObserver(() => {
      document.querySelectorAll('#tp-time,.countdown').forEach(t => {
        if (t.style.display === 'none') t.style.removeProperty('display');
      });
    }).observe(document.documentElement, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ['style']
    });

    if (document.readyState === 'complete') triggerAdCheck();
    else window.addEventListener('load', triggerAdCheck, { once: true });
  }

  const taskButtons = async () => {
    await waitCountdownDone();
    await clickEl('#btn6');
    await clickEl('#btn7');
  };

  const taskStart = async () => {
    clickEl('#startCountdownBtn');
    await sleep(500);
    await waitCountdownDone();
    await clickEl('#cross-snp2');
  };

  const taskTp = async () => {
    await waitCountdownDone('#tp-time');
    await clickEl('#tp-snp2');
  };

  const run = () => {
    taskButtons();
    taskStart();
    taskTp();
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run, { once: true });
  } else {
    run();
  }
})();
