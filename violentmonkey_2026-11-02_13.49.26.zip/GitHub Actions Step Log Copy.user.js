// ==UserScript==
// @name         GitHub Actions Step Log Copy
// @namespace    blazeftl
// @version      1.0.2
// @description  Adds a copy button to each GitHub Actions job step that copies only that step's logs
// @match        https://github.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @connect      *
// @icon         https://github.githubassets.com/favicons/favicon.svg
// @run-at       document-idle
// @noframes
// ==/UserScript==

(() => {
  const CLS = 'ftl-copy-step';
  const NS = 'http://www.w3.org/2000/svg';
  const ICONS = {
    copy: [
      'M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z',
      'M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z'
    ],
    check: ['M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z'],
    x: ['M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z']
  };

  const style = document.createElement('style');
  style.textContent = `.${CLS}{display:inline-flex;align-items:center;justify-content:center;position:absolute;top:50%;transform:translateY(-50%);right:56px;z-index:2;min-width:32px;height:32px;margin:0;padding:0 6px;border:0;border-radius:6px;background:transparent;color:var(--fgColor-muted,#656d76);cursor:pointer;flex-shrink:0}.${CLS}:hover,.${CLS}:active{background:var(--bgColor-neutral-muted,#afb8c133)}.${CLS}[data-state=ok]{color:var(--fgColor-success,#1a7f37)}.${CLS}[data-state=err]{color:var(--fgColor-danger,#d1242f)}.${CLS}[data-state=busy]{opacity:.5}`;
  document.head.appendChild(style);

  const icon = k => {
    const s = document.createElementNS(NS, 'svg');
    s.setAttribute('viewBox', '0 0 16 16');
    s.setAttribute('width', '16');
    s.setAttribute('height', '16');
    s.setAttribute('fill', 'currentColor');
    s.setAttribute('aria-hidden', 'true');
    ICONS[k].forEach(d => {
      const p = document.createElementNS(NS, 'path');
      p.setAttribute('d', d);
      s.appendChild(p);
    });
    return s;
  };

  const wait = ms => new Promise(r => setTimeout(r, ms));

  const req = url => new Promise((res, rej) => {
    GM_xmlhttpRequest({
      method: 'GET',
      url,
      withCredentials: true,
      timeout: 30000,
      headers: { Accept: 'text/plain, */*' },
      onload: r => (r.status >= 200 && r.status < 300 ? res(r.responseText) : rej(new Error(r.status))),
      onerror: rej,
      ontimeout: rej
    });
  });

  const rowsText = root => {
    const out = [];
    root.querySelectorAll('*').forEach(el => {
      const c = el.children;
      if (c.length < 2) return;
      if (!/^\d+$/.test(c[0].textContent.trim())) return;
      out.push(Array.from(c).slice(1).map(x => x.textContent).join('').replace(/\s+$/, ''));
    });
    return out.join('\n');
  };

  const parse = raw => {
    const s = raw.trim();
    if (!s) return null;
    if (s[0] === '{' || s[0] === '[') return null;
    if (s[0] === '<') return rowsText(new DOMParser().parseFromString(s, 'text/html').body) || null;
    return s;
  };

  const clean = t =>
    t
      .replace(/\x1b\[[0-9;?]*[A-Za-z]/g, '')
      .replace(/\r/g, '')
      .split('\n')
      .map(l => l.replace(/^\uFEFF/, '').replace(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z ?/, ''))
      .filter(l => !/^##\[endgroup\]/.test(l))
      .map(l => l.replace(/^##\[group\]/, '▶ '))
      .join('\n')
      .trim();

  const scrape = async step => {
    const d = step.querySelector('details');
    const was = d ? d.open : true;
    if (d && !was) d.open = true;
    let t = '';
    for (let i = 0; i < 40; i++) {
      t = rowsText(step);
      if (t) break;
      await wait(250);
    }
    if (d && !was) d.open = false;
    return t;
  };

  const getLogs = async step => {
    const rel = step.getAttribute('data-log-url');
    if (rel) {
      try {
        const p = parse(await req(new URL(rel, location.href).href));
        if (p) {
          const c = clean(p);
          if (c) return c;
        }
      } catch {}
    }
    return clean(await scrape(step));
  };

  const put = async t => {
    try {
      GM_setClipboard(t, 'text');
      return;
    } catch {}
    try {
      await navigator.clipboard.writeText(t);
      return;
    } catch {}
    const a = document.createElement('textarea');
    a.value = t;
    a.style.cssText = 'position:fixed;opacity:0';
    document.body.appendChild(a);
    a.select();
    const ok = document.execCommand('copy');
    a.remove();
    if (!ok) throw new Error('copy failed');
  };

  const mk = step => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = CLS;
    b.title = 'Copy step logs';
    b.setAttribute('aria-label', 'Copy step logs');
    b.appendChild(icon('copy'));
    const set = (state, k) => {
      b.dataset.state = state;
      b.replaceChildren(icon(k));
    };
    b.addEventListener('pointerdown', e => e.stopPropagation());
    b.addEventListener('click', async e => {
      e.preventDefault();
      e.stopPropagation();
      if (b.dataset.state === 'busy') return;
      set('busy', 'copy');
      try {
        const body = await getLogs(step);
        if (!body) throw new Error('empty');
        const name = (step.getAttribute('data-name') || '').trim();
        await put(name ? name + '\n\n' + body : body);
        set('ok', 'check');
      } catch {
        set('err', 'x');
      }
      setTimeout(() => set('', 'copy'), 1500);
    });
    return b;
  };

  const DUR = /^(\d+h\s*)?(\d+m\s*)?\d+s$/;

  const place = (head, b) => {
    if (getComputedStyle(head).position === 'static') head.style.position = 'relative';
    let dur = null;
    head.querySelectorAll('*').forEach(el => {
      if (el === b || b.contains(el) || el.children.length) return;
      if (DUR.test(el.textContent.trim())) dur = el;
    });
    let right = 56;
    if (dur) {
      const dr = dur.getBoundingClientRect();
      if (dr.width) right = Math.max(0, Math.round(head.getBoundingClientRect().right - dr.left)) + 2;
    }
    b.style.right = right + 'px';
  };

  const inject = () => {
    document.querySelectorAll('check-step').forEach(step => {
      if (!step.getAttribute('data-log-url')) return;
      const head = step.querySelector('summary') || step.firstElementChild;
      if (!head) return;
      let b = head.querySelector('.' + CLS);
      if (!b) {
        b = mk(step);
        head.appendChild(b);
      }
      place(head, b);
    });
  };

  let q = false;
  new MutationObserver(() => {
    if (q) return;
    q = true;
    requestAnimationFrame(() => {
      q = false;
      inject();
    });
  }).observe(document.documentElement, { childList: true, subtree: true });
  window.addEventListener('resize', inject);
  inject();
})();
