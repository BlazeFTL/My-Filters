// ==UserScript==
// @name         Stylus HTML Extractor
// @namespace    ftl.stylus-html-extract
// @version      1.0.0
// @description  Copy or save page HTML without scripts, meta and noise, for Stylus userstyle work
// @match        *://*/*
// @run-at       document-idle
// @noframes
// @grant        GM_registerMenuCommand
// @grant        GM_setClipboard
// ==/UserScript==

(() => {
  'use strict';

  const FULL = { text: 500, attr: 300, data: 120, style: 400, collapse: Infinity, keep: 0, hints: 0, varRules: 120, varChars: 6000 };
  const LEAN = { text: 120, attr: 160, data: 60, style: 240, collapse: 6, keep: 3, hints: 8, varRules: 60, varChars: 2500 };

  const SKIP = new Set(['script', 'noscript', 'style', 'template', 'link', 'meta', 'base', 'head', 'title']);
  const VOID = new Set(['area', 'br', 'col', 'embed', 'hr', 'img', 'input', 'source', 'track', 'wbr']);
  const OPAQUE = new Set(['iframe', 'frame', 'video', 'audio', 'canvas', 'object', 'embed', 'textarea']);
  const URL_ATTRS = new Set(['href', 'src', 'action', 'poster', 'data', 'formaction', 'xlink:href']);
  const DROP = /^(on[a-z]+|srcset|sizes|nonce|integrity|crossorigin|loading|decoding|fetchpriority|referrerpolicy|jsaction|jscontroller|jsname|jsmodel|jslog|ping|autocomplete|spellcheck|autocapitalize|autocorrect|xmlns|xmlns:xlink)$/;
  const VALUE_OK = /^(button|submit|reset|checkbox|radio|image)$/;
  const KEEP_META = /^(theme-color|color-scheme)$/i;

  const cut = (s, n) => (s.length > n ? s.slice(0, n) + '…' : s);
  const flat = s => s.replace(/\s+/g, ' ').trim();
  const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const escA = s => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  const safe = s => s.replace(/-->/g, '--&gt;');
  const kb = n => (n / 1024).toFixed(1);
  const skip = n => SKIP.has(n.localName) || n.hasAttribute('data-sx-ui');

  const hash = str => {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
  };

  const shortUrl = v => {
    if (/^(javascript|data|blob):/i.test(v)) return v.slice(0, v.indexOf(':') + 1) + '…';
    return v.startsWith(location.origin) ? v.slice(location.origin.length) || '/' : v;
  };

  const attrString = (el, p) => {
    const tag = el.localName;
    const type = (el.getAttribute('type') || '').toLowerCase();
    let out = '';
    for (const a of Array.from(el.attributes)) {
      const n = a.name;
      if (DROP.test(n)) continue;
      if (n === 'value' && tag === 'input' && !VALUE_OK.test(type)) continue;
      let v = a.value;
      if (n === 'style') v = cut(flat(v), p.style);
      else if (n === 'class') v = cut(flat(v), 600);
      else if (n === 'id') v = cut(v, 160);
      else {
        if (URL_ATTRS.has(n)) v = shortUrl(v);
        v = cut(flat(v), n.startsWith('data-') ? p.data : p.attr);
      }
      out += v === '' ? ` ${n}` : ` ${n}="${escA(v)}"`;
    }
    return out;
  };

  const classes = (el, max) =>
    (el.getAttribute('class') || '').split(/\s+/).filter(Boolean).slice(0, max).map(c => '.' + c).join('');

  const label = el => `<${el.localName}${classes(el, 3)}>`;

  const path = el => {
    const parts = [];
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      parts.unshift(n.localName + (n.id ? '#' + n.id : '') + classes(n, 3));
    }
    return parts.join(' > ');
  };

  const makeSig = () => {
    const cache = new WeakMap();
    const fn = el => {
      let s = cache.get(el);
      if (s) return s;
      const kids = [];
      if (!OPAQUE.has(el.localName) && el.localName !== 'svg') {
        for (const c of el.children) if (!skip(c)) kids.push(fn(c));
      }
      const cls = (el.getAttribute('class') || '').split(/\s+/).filter(Boolean).sort().join('.');
      const id = (el.getAttribute('id') || '').replace(/\d+/g, '#');
      s = hash(`${el.localName}|${cls}|${id}|${el.getAttribute('role') || ''}|${kids.join(',')}`);
      cache.set(el, s);
      return s;
    };
    return fn;
  };

  const svgOut = (el, p, d, out, open) => {
    const pad = ' '.repeat(d);
    const syms = Array.from(el.querySelectorAll('symbol'));
    const inner = syms.length
      ? `<!-- sprite: ${syms.length} symbols: ${safe(syms.slice(0, 40).map(s => s.id).join(' '))} -->`
      : Array.from(el.querySelectorAll('use')).map(u => `<use${attrString(u, p)}></use>`).join('');
    out.push(`${pad}${open}${inner}</svg>`);
  };

  const emit = (el, p, d, out, sigOf) => {
    const tag = el.localName;
    const pad = ' '.repeat(d);
    const open = `<${tag}${attrString(el, p)}>`;
    if (VOID.has(tag)) return void out.push(pad + open);
    if (OPAQUE.has(tag)) return void out.push(`${pad}${open}</${tag}>`);
    if (tag === 'svg') return svgOut(el, p, d, out, open);
    const root = el.openOrClosedShadowRoot || el.shadowRoot;
    const kids = Array.from(el.childNodes).filter(
      n => (n.nodeType === 1 && !skip(n)) || (n.nodeType === 3 && n.nodeValue.trim())
    );
    if (!root && !kids.some(n => n.nodeType === 1)) {
      const t = flat(kids.map(n => n.nodeValue).join(' '));
      out.push(`${pad}${open}${esc(cut(t, p.text))}</${tag}>`);
      return;
    }
    out.push(pad + open);
    if (root) {
      out.push(`${pad} <!-- shadow-root -->`);
      walk(Array.from(root.childNodes), p, d + 2, out, sigOf);
      out.push(`${pad} <!-- /shadow-root -->`);
    }
    walk(kids, p, d + 1, out, sigOf);
    out.push(`${pad}</${tag}>`);
  };

  const walk = (nodes, p, d, out, sigOf) => {
    const pad = ' '.repeat(d);
    const dedupe = p.collapse < Infinity;
    const counts = new Map();
    if (dedupe) {
      for (const n of nodes) {
        if (n.nodeType === 1 && !skip(n)) {
          const s = sigOf(n);
          counts.set(s, (counts.get(s) || 0) + 1);
        }
      }
    }
    const seen = new Map();
    const omitted = new Map();
    for (const n of nodes) {
      if (n.nodeType === 3) {
        const t = flat(n.nodeValue);
        if (t) out.push(pad + esc(cut(t, p.text)));
        continue;
      }
      if (n.nodeType !== 1 || skip(n)) continue;
      if (dedupe) {
        const s = sigOf(n);
        const i = seen.get(s) || 0;
        seen.set(s, i + 1);
        if (counts.get(s) > p.collapse && i >= p.keep) {
          let o = omitted.get(s);
          if (!o) {
            const lab = label(n);
            o = {
              n: 0,
              hints: [],
              toString() {
                const h = this.hints.length ? `; text: ${this.hints.map(x => `"${x}"`).join(' | ')}` : '';
                return `${pad}<!-- +${this.n} more ${lab} omitted, same structure${h} -->`;
              }
            };
            omitted.set(s, o);
            out.push(o);
          }
          o.n++;
          const t = safe(cut(flat(n.textContent || ''), 24));
          if (t && o.hints.length < p.hints) o.hints.push(t);
          continue;
        }
      }
      emit(n, p, d, out, sigOf);
    }
  };

  const rootVars = p => {
    const vars = [];
    let blocked = 0;
    let sheets = 0;
    const match = sel => sel.split(',').some(s => /^\s*(:root|html|body)(?:[.#\[:][^\s>+~]*)?\s*$/.test(s));
    const walkRules = (rules, ctx) => {
      for (const r of Array.from(rules)) {
        if (vars.length >= p.varRules) return;
        if (r.selectorText !== undefined) {
          if (!match(r.selectorText)) continue;
          const d = [];
          for (let i = 0; i < r.style.length; i++) {
            const n = r.style[i];
            if (n.startsWith('--')) d.push(`${n}: ${cut(flat(r.style.getPropertyValue(n)), 80)}`);
          }
          if (d.length) vars.push(cut(`${ctx}${flat(r.selectorText)} { ${d.join('; ')} }`, p.varChars));
        } else if (r.cssRules) {
          const pre = flat(r.cssText.slice(0, r.cssText.indexOf('{')));
          if (/^@(-\w+-)?(keyframes|font-face|property|counter-style)/.test(pre)) continue;
          walkRules(r.cssRules, `${ctx}${pre} `);
        }
      }
    };
    const own = sh => {
      const n = sh.ownerNode;
      return n && n.nodeType === 1 && (n.classList.contains('stylus') || /^stylus-/.test(n.id || ''));
    };
    for (const sh of [...document.styleSheets, ...(document.adoptedStyleSheets || [])]) {
      if (own(sh)) continue;
      sheets++;
      try {
        walkRules(sh.cssRules, '');
      } catch {
        blocked++;
      }
    }
    return { vars, blocked, sheets };
  };

  const header = (p, picked) => {
    const doc = document.documentElement;
    const hs = getComputedStyle(doc);
    const bs = document.body ? getComputedStyle(document.body) : hs;
    const hosts = [];
    let shadows = 0;
    for (const e of document.querySelectorAll('*')) {
      if (e.openOrClosedShadowRoot || e.shadowRoot) {
        shadows++;
        if (hosts.length < 5) hosts.push(label(e));
      }
    }
    const { vars, blocked, sheets } = rootVars(p);
    const L = [
      `url: ${location.origin}${location.pathname}`,
      `scope: @-moz-document domain("${location.hostname}")`,
      `viewport: ${innerWidth}x${innerHeight} dpr=${devicePixelRatio} prefers-dark=${matchMedia('(prefers-color-scheme: dark)').matches}`,
      `html: color-scheme=${hs.colorScheme} bg=${hs.backgroundColor}`,
      `body: bg=${bs.backgroundColor} color=${bs.color} font=${cut(bs.fontFamily, 60)} ${bs.fontSize}`,
      `iframes: ${document.querySelectorAll('iframe').length}; shadow hosts: ${shadows}${hosts.length ? ' (' + hosts.join(', ') + ')' : ''}`,
      `stylesheets: ${sheets} (${blocked} cross-origin, unreadable)`
    ];
    if (picked) {
      L.push(
        `picked: ${path(picked)}`,
        `html tag: <html${attrString(doc, p)}>`,
        `body tag: <body${document.body ? attrString(document.body, p) : ''}>`
      );
    }
    if (vars.length) L.push('root css vars:', ...vars.map(v => '  ' + v));
    return `<!--\n${safe(L.join('\n'))}\n-->`;
  };

  const headLines = p => {
    const L = [];
    const t = flat(document.title || '');
    if (t) L.push(` <title>${esc(cut(t, 120))}</title>`);
    if (document.head) {
      for (const m of document.head.querySelectorAll('meta')) {
        if (KEEP_META.test(m.getAttribute('name') || '')) L.push(` <meta${attrString(m, p)}>`);
      }
    }
    return L;
  };

  const buildPage = p => {
    const sigOf = makeSig();
    const out = [header(p, null), `<html${attrString(document.documentElement, p)}>`, '<head>', ...headLines(p), '</head>'];
    if (document.body) emit(document.body, p, 0, out, sigOf);
    out.push('</html>');
    return out.join('\n');
  };

  const buildPicked = (el, p) => {
    const sigOf = makeSig();
    const out = [header(p, el)];
    emit(el, p, 0, out, sigOf);
    return out.join('\n');
  };

  let host, box, bar, info, row, toastEl, toastTimer, stopActive;

  const mk = (tag, css, text) => {
    const e = document.createElement(tag);
    e.style.cssText = css;
    if (text) e.textContent = text;
    return e;
  };

  const ui = () => {
    if (host && host.isConnected) return;
    host = mk('div', 'all:initial;position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483647;pointer-events:none');
    host.setAttribute('data-sx-ui', '');
    const sr = host.attachShadow({ mode: 'closed' });
    box = mk('div', 'position:fixed;display:none;box-sizing:border-box;border:2px solid #ff4d6d;background:rgba(255,77,109,.18);pointer-events:none');
    bar = mk('div', 'position:fixed;left:0;right:0;bottom:0;display:none;flex-direction:column;gap:6px;padding:8px;box-sizing:border-box;background:#111;color:#eee;font:13px/1.3 system-ui,sans-serif;pointer-events:auto');
    info = mk('div', 'white-space:nowrap;overflow:hidden;text-overflow:ellipsis');
    row = mk('div', 'display:flex;gap:6px');
    toastEl = mk('div', 'position:fixed;top:12px;left:50%;transform:translateX(-50%);display:none;max-width:90%;padding:8px 12px;border-radius:8px;background:#111;color:#fff;font:13px/1.3 system-ui,sans-serif;pointer-events:none;box-shadow:0 2px 10px rgba(0,0,0,.4)');
    bar.append(info, row);
    sr.append(box, bar, toastEl);
    document.documentElement.appendChild(host);
  };

  const toast = msg => {
    ui();
    toastEl.textContent = msg;
    toastEl.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (toastEl.style.display = 'none'), 3500);
  };

  const btn = (text, fn) => {
    const b = mk('button', 'flex:1;min-width:0;min-height:44px;border:0;border-radius:8px;background:#2b2b2b;color:#eee;font:inherit;font-size:13px;padding:0 2px');
    b.textContent = text;
    b.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      fn(b);
    });
    return b;
  };

  const deliver = (text, how, raw) => {
    const note = `${kb(text.length)} KB from ${kb(raw)} KB`;
    if (how === 'save') {
      try {
        const url = URL.createObjectURL(new Blob([text], { type: 'text/html' }));
        const a = document.createElement('a');
        a.href = url;
        a.download = `${location.hostname}-clean.html`;
        a.style.display = 'none';
        document.documentElement.appendChild(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 15000);
        toast(`Saved · ${note}`);
        return;
      } catch (e) {}
    }
    GM_setClipboard(text, 'text');
    toast(`Copied · ${note}`);
  };

  const run = (kind, how, p, el) => {
    try {
      const text = kind === 'page' ? buildPage(p) : buildPicked(el, p);
      const raw = (kind === 'page' ? document.documentElement : el).outerHTML.length;
      deliver(text, how, raw);
    } catch (err) {
      toast('Failed: ' + err.message);
    }
  };

  const startPick = () => {
    if (stopActive) stopActive();
    ui();
    let cur = null;
    let lean = false;
    const types = ['click', 'mousedown', 'mouseup', 'pointerdown', 'pointerup', 'touchstart', 'touchend', 'dblclick', 'auxclick'];

    const place = () => {
      if (!cur || !cur.isConnected) return;
      const r = cur.getBoundingClientRect();
      Object.assign(box.style, {
        display: 'block',
        left: r.left + 'px',
        top: r.top + 'px',
        width: r.width + 'px',
        height: r.height + 'px'
      });
      info.textContent = cut(path(cur).split(' > ').slice(-3).join(' > '), 100);
    };

    const guard = e => {
      if (e.composedPath().includes(host)) return;
      e.stopImmediatePropagation();
      if (e.type !== 'click') return;
      e.preventDefault();
      const t = e.composedPath()[0];
      if (t && t.nodeType === 1) {
        cur = t.closest('svg') || t;
        place();
      }
    };

    const stop = () => {
      types.forEach(t => window.removeEventListener(t, guard, true));
      window.removeEventListener('scroll', place, true);
      window.removeEventListener('resize', place, true);
      bar.style.display = 'none';
      box.style.display = 'none';
      stopActive = null;
    };

    const act = how => {
      if (!cur) return toast('Tap an element first');
      const el = cur;
      stop();
      run('picked', how, lean ? LEAN : FULL, el);
    };

    row.replaceChildren(
      btn('▲', () => {
        const up = cur && (cur.parentElement || cur.getRootNode().host);
        if (up) {
          cur = up;
          place();
        }
      }),
      btn('▼', () => {
        const k = cur && Array.from(cur.children).find(c => !skip(c));
        if (k) {
          cur = k;
          place();
        }
      }),
      btn('Fold', b => {
        lean = !lean;
        b.textContent = lean ? 'Fold ✓' : 'Fold';
      }),
      btn('Copy', () => act('copy')),
      btn('Save', () => act('save')),
      btn('✕', stop)
    );

    info.textContent = 'Tap an element on the page';
    bar.style.display = 'flex';
    types.forEach(t => window.addEventListener(t, guard, true));
    window.addEventListener('scroll', place, true);
    window.addEventListener('resize', place, true);
    stopActive = stop;
  };

  GM_registerMenuCommand('Copy page HTML (clean)', () => run('page', 'copy', FULL));
  GM_registerMenuCommand('Save page HTML (clean) as file', () => run('page', 'save', FULL));
  GM_registerMenuCommand('Copy page HTML (fold repeated items)', () => run('page', 'copy', LEAN));
  GM_registerMenuCommand('Pick element → copy / save', startPick);
})();
