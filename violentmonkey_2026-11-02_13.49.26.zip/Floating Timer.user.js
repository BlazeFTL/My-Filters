// ==UserScript==
// @name         Floating Timer
// @namespace    blazeftl
// @version      1.1
// @description  Small draggable window showing elapsed time since page load
// @match        *://*/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';
  if (window.top !== window.self) return;

  const el = (tag, css, text) => {
    const n = document.createElement(tag);
    if (css) n.style.cssText = css;
    if (text) n.textContent = text;
    return n;
  };

  const host = el('div', 'position:fixed;top:80px;right:12px;z-index:2147483647;');
  const root = host.attachShadow({ mode: 'closed' });

  const box = el('div', 'width:150px;background:#1e1e1e;color:#fff;border-radius:10px;box-shadow:0 4px 14px rgba(0,0,0,.45);font:13px system-ui,sans-serif;overflow:hidden;user-select:none;-webkit-user-select:none;');
  const bar = el('div', 'display:flex;align-items:center;justify-content:space-between;padding:6px 8px;background:#2d2d2d;cursor:move;touch-action:none;');
  const title = el('span', 'font-weight:600;', 'Elapsed');
  const barBtns = el('span', 'display:flex;gap:6px;');
  const btnMin = el('span', 'cursor:pointer;padding:0 4px;', '–');
  const btnClose = el('span', 'cursor:pointer;padding:0 4px;', '×');
  barBtns.append(btnMin, btnClose);
  bar.append(title, barBtns);

  const body = el('div', 'padding:8px;display:flex;flex-direction:column;gap:8px;');
  const display = el('div', 'font-size:28px;font-weight:700;text-align:center;font-variant-numeric:tabular-nums;', '00:00');
  const btnRow = el('div', 'display:flex;gap:6px;');
  const btnStyle = 'flex:1;padding:6px 0;border:0;border-radius:6px;color:#fff;font-size:13px;cursor:pointer;';
  const btnToggle = el('button', btnStyle + 'background:#f9a825;', 'Pause');
  const btnReset = el('button', btnStyle + 'background:#555;', 'Reset');
  btnRow.append(btnToggle, btnReset);

  body.append(display, btnRow);
  box.append(bar, body);
  root.append(box);
  document.documentElement.appendChild(host);

  let running = true;
  let base = 0;
  let startedAt = Date.now();

  const pad = n => String(n).padStart(2, '0');
  const fmt = ms => {
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    return (h ? pad(h) + ':' : '') + pad(m) + ':' + pad(s % 60);
  };

  const elapsed = () => base + (running ? Date.now() - startedAt : 0);
  const render = () => { display.textContent = fmt(elapsed()); };

  const tick = setInterval(render, 250);

  btnToggle.addEventListener('click', () => {
    if (running) {
      base = elapsed();
      running = false;
      btnToggle.textContent = 'Resume';
      btnToggle.style.background = '#2e7d32';
    } else {
      startedAt = Date.now();
      running = true;
      btnToggle.textContent = 'Pause';
      btnToggle.style.background = '#f9a825';
    }
    render();
  });

  btnReset.addEventListener('click', () => {
    base = 0;
    startedAt = Date.now();
    render();
  });

  btnMin.addEventListener('click', () => {
    const hidden = body.style.display === 'none';
    body.style.display = hidden ? 'flex' : 'none';
    btnMin.textContent = hidden ? '–' : '+';
  });

  btnClose.addEventListener('click', () => {
    clearInterval(tick);
    host.remove();
  });

  let drag = null;
  bar.addEventListener('pointerdown', e => {
    if (e.target === btnMin || e.target === btnClose) return;
    const r = host.getBoundingClientRect();
    host.style.left = r.left + 'px';
    host.style.top = r.top + 'px';
    host.style.right = 'auto';
    drag = { x: e.clientX - r.left, y: e.clientY - r.top };
    bar.setPointerCapture(e.pointerId);
  });
  bar.addEventListener('pointermove', e => {
    if (!drag) return;
    const x = Math.min(Math.max(0, e.clientX - drag.x), window.innerWidth - host.offsetWidth);
    const y = Math.min(Math.max(0, e.clientY - drag.y), window.innerHeight - host.offsetHeight);
    host.style.left = x + 'px';
    host.style.top = y + 'px';
  });
  const endDrag = e => {
    if (!drag) return;
    drag = null;
    try { bar.releasePointerCapture(e.pointerId); } catch (err) {}
  };
  bar.addEventListener('pointerup', endDrag);
  bar.addEventListener('pointercancel', endDrag);

  render();
})();
