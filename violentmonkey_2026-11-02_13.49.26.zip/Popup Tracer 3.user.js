// ==UserScript==
// @name         Popup Tracer 3
// @namespace    blazeftl
// @version      1.4.1
// @description  Logs every popup and popunder vector, traces the calling script, shows its code, defuses popups
// @author       BlazeFTL
// @match        *://*/*
// @run-at       document-start
// @inject-into  page
// @grant        unsafeWindow
// @grant        GM_openInTab
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @grant        GM_registerMenuCommand
// @grant        GM_getValue
// @grant        GM_setValue
// @connect      *
// ==/UserScript==

(()=>{
const W=typeof unsafeWindow!=='undefined'?unsafeWindow:window;
let TOP=false;try{TOP=W.top===W}catch{}
const FID=Math.random().toString(36).slice(2,7);
const OPEN=W.open,AEL=W.EventTarget.prototype.addEventListener,NTS=W.Function.prototype.toString;
let N=0,DN=0,lastE=null,lastT=0,raf=0,root=null,host=null,pend=false,moved=false,drag=null;
const done=new WeakSet,born=new WeakMap,dead=new WeakSet,dynOf=new WeakMap,fake=new WeakMap;
const refs=new Map,dyn=new Map,blobs=new Map;
let dynSz=0;
const FF=/Firefox/.test(navigator.userAgent);
const VER='1.4.1';
let lastV=null,errMsg='',lastTap='',tapAt=0,g=null,lastScroll=0,nPU=0,nCK=0,nTE=0,dbg='';
const NS=/^(_self|_parent|_top|)$/i;
const LT=new Set(['click','mousedown','mouseup','pointerdown','pointerup','touchstart','touchend','auxclick','keydown']);
const TINY=/(^|[,\s])(width|height)\s*=\s*[01](\D|$)|(left|top|screenx|screeny)\s*=\s*(-\d|\d{4,})/i;
const RX=/((?:blob:)?(?:https?|file):\/\/[^\s()]+?):(\d+):(\d+)/;
const GV=(k,d)=>{try{return GM_getValue(k,d)}catch{return d}};
const SV=(k,v)=>{try{GM_setValue(k,v)}catch{}};
const S=x=>{try{return x==null?'':String(x).slice(0,2000)}catch{return''}};
const SS=x=>{try{return String(x)}catch{return''}};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const abs=(w,u)=>{try{return new w.URL(u,w.document.baseURI).href}catch{return S(u)}};
const hostOf=u=>{try{return new URL(u).hostname}catch{return S(u)}};
const short=u=>{try{const x=new URL(u);return x.pathname.split('/').filter(Boolean).pop()||x.hostname}catch{return S(u)}};
const EV=()=>!!GV('evalTrace',true);
const lis=()=>!!Object.assign({listen:0},GV('chips',{})).listen;
try{Error.stackTraceLimit=Math.max(Error.stackTraceLimit||10,40)}catch{}

const DM=()=>+GV('defuse',0)||0;
const topHost=()=>{
  if(TOP)return W.location.hostname;
  try{const a=W.location.ancestorOrigins;if(a&&a.length)return new URL(a[a.length-1]).hostname}catch{}
  try{return new URL(document.referrer).hostname}catch{}
  return W.location.hostname
};
const site=h=>h.replace(/^www\./,'').split('.').slice(-2).join('.');
const third=(w,u)=>{
  if(!u||u==='about:blank')return true;
  try{
    const x=new w.URL(u,w.document.baseURI);
    if(!/^https?:$/.test(x.protocol))return true;
    return site(x.hostname)!==site(topHost())
  }catch{return true}
};
const dfz=(w,u)=>{const m=DM();return m===2||(m===1&&third(w,u))};
const ghost=()=>{
  const mk=()=>new Proxy(function(){},{
    get:(t,k)=>k==='closed'?false:k==='then'?undefined:k===Symbol.toPrimitive?()=>'':mk(),
    set:()=>true,apply:()=>mk(),construct:()=>mk(),has:()=>true
  });
  return new Proxy({},{get:(t,k)=>k==='closed'?false:k==='then'?undefined:k===Symbol.toPrimitive?()=>'':mk(),set:()=>true,has:()=>true})
};
const ovl=el=>{
  try{
    const w=el.ownerDocument.defaultView,cs=w.getComputedStyle(el),r=el.getBoundingClientRect();
    return /^(fixed|absolute)$/.test(cs.position)&&(+cs.opacity<=.05||cs.visibility==='hidden'||(r.width>=w.innerWidth*.6&&r.height>=w.innerHeight*.6))
  }catch{return false}
};

const parse=s=>{
  const out=[];
  for(const l of String(s).split('\n')){
    if(!l.trim()||l.includes('__ptr_'))continue;
    const f=(/^\s*at\s+(.*?)\s+\(/.exec(l)||/^([^@\s][^@]*)@/.exec(l)||[])[1]||'';
    let m=/ptr-script-(\d+)\.js:(\d+):(\d+)/.exec(l);
    if(m){out.push({u:'',l:+m[2],c:+m[3],f,t:'dyn',dn:+m[1]});continue}
    const at=l.indexOf('@');
    if(at>=0){
      const ps=l.slice(at+1).split(' > '),hm=/^(.*?) line (\d+)$/.exec(ps[0]);
      if(ps.length>1&&hm){
        const tm=/:(\d+):(\d+)$/.exec(ps[ps.length-1])||[];
        out.push({u:'',l:+tm[1]||0,c:+tm[2]||0,f,t:'eval',cu:hm[1],cl:+hm[2],cc:0});
        out.push({u:hm[1],l:+hm[2],c:0,f:'eval created here',t:'file',syn:1});
        continue
      }
    }
    m=/(?:\beval at\b|> (?:eval|Function))/.test(l)?RX.exec(l):null;
    if(m){
      const t=/<anonymous>:(\d+):(\d+)\)?\s*$/.exec(l)||/> (?:eval|Function):(\d+):(\d+)/.exec(l)||[];
      out.push({u:'',l:+t[1]||0,c:+t[2]||0,f,t:'eval',cu:m[1],cl:+m[2],cc:+m[3]});
      out.push({u:m[1],l:+m[2],c:+m[3],f:'eval created here',t:'file',syn:1});
      continue
    }
    m=RX.exec(l);
    if(m){out.push({u:m[1],l:+m[2],c:+m[3],f,t:'file'});continue}
    m=/((?:chrome|moz|safari-web)-extension:\/\/[^\s()]+?):(\d+):(\d+)/.exec(l);
    if(m){out.push({u:m[1],l:+m[2],c:+m[3],f,t:'ext'});continue}
    m=/(?:<anonymous>|VM\d+):(\d+):(\d+)/.exec(l);
    if(m)out.push({u:'',l:+m[1],c:+m[2],f,t:'anon'})
  }
  return out.slice(0,30)
};
const fromSite=cs=>{
  const u=S((cs.getScriptNameOrSourceURL&&cs.getScriptNameOrSourceURL())||(cs.getFileName&&cs.getFileName())||'');
  const isEval=!!(cs.isEval&&cs.isEval());
  const r={u,l:cs.getLineNumber()||0,c:cs.getColumnNumber()||0,f:S((cs.getFunctionName&&cs.getFunctionName())||''),t:'anon'};
  const d=/ptr-script-(\d+)\.js/.exec(u);
  if(d){r.t='dyn';r.dn=+d[1];r.u=''}
  else if(isEval){
    r.t='eval';r.u='';
    const m=RX.exec(S(cs.getEvalOrigin&&cs.getEvalOrigin()));
    if(m){r.cu=m[1];r.cl=+m[2];r.cc=+m[3]}
  }
  else if(/^(https?|file|blob):/.test(u))r.t='file';
  else if(/^(chrome|moz|safari-web)-extension:|^extension:/.test(u))r.t='ext';
  if(r.t!=='file'&&r.t!=='ext'){
    try{const fn=cs.getFunction&&cs.getFunction();if(typeof fn==='function')r.src=NTS.call(fn).slice(0,6000)}catch{}
  }
  return r
};
const __ptr_cap=()=>{
  let cs=null;
  const old=Error.prepareStackTrace;
  try{Error.prepareStackTrace=(_,c)=>c;cs=new Error().stack}catch{}
  try{Error.prepareStackTrace=old}catch{}
  if(!Array.isArray(cs))return parse(cs);
  const out=[];
  for(const c of cs){
    try{
      if(String(c).includes('__ptr_'))continue;
      const r=fromSite(c);
      out.push(r);
      if(r.t==='eval'&&r.cu)out.push({u:r.cu,l:r.cl,c:r.cc,f:'eval created here',t:'file',syn:1})
    }catch{}
  }
  return out.slice(0,30)
};
const __ptr_raw=()=>{try{return String(new Error().stack||'').split('\n').filter(l=>!l.includes('__ptr_')).join('\n').slice(0,1500)}catch{return''}};
const evi=w=>{try{const e=w.event;return e?{t:e.type,tr:e.isTrusted,tg:(e.target&&e.target.nodeName||'').toLowerCase()}:null}catch{return null}};
const ei=el=>{
  try{
    const h=el.outerHTML||'';
    const tag=(h.slice(0,h.indexOf('>')+1)||'<'+el.nodeName.toLowerCase()+'>').slice(0,400);
    const at=n=>el.getAttribute(n),id=at('id');
    return{tag,nd:[tag,at('href'),at('src'),at('action'),id&&'id="'+id+'"'].filter(x=>x&&x.length>4).map(x=>x.slice(0,300)),by:born.get(el)||null,ov:ovl(el)}
  }catch{return null}
};
const dtOf=e=>{
  const dt={};
  for(const f of[...e.fr,...(e.el&&e.el.by||[])]){
    if(f.t==='dyn'&&!dt[f.dn]){const x=dyn.get(f.dn);if(x)dt[f.dn]={x:x.text.slice(0,300000),fr:x.fr.slice(0,3)}}
  }
  return dt
};
const chain=fr=>{
  const out=[],seen=new Set();
  const walk=(a,d,ins)=>{
    for(const f of a){
      if(out.length>=30)return;
      const k=f.t+'|'+(f.dn||f.u||f.cu||'')+'|'+f.l+'|'+f.c;
      if(seen.has(k))continue;
      seen.add(k);
      out.push(ins?{...f,ins:1}:f);
      if(f.t==='dyn'&&d<3){const x=dyn.get(f.dn);if(x)walk(x.fr,d+1,1)}
    }
  };
  walk(fr,0,0);
  return out
};
const __ptr_rec=(w,k,d,el,pu,df,evo)=>{
  if(GV('pause',false))return null;
  const e={id:FID+'-'+(++N),t:Date.now(),k,d,fr:__ptr_cap(),ev:evo||evi(w),pu:pu||[],df:df?1:0,pg:'',el:null};
  try{e.pg=w.location.href}catch{}
  e.fr=chain(e.fr);
  e.fr.forEach(resolve);
  if(!e.fr.length)e.raw=__ptr_raw();
  if(el){e.el=ei(el);if(e.el&&e.el.by)e.el.by.forEach(resolve);if(TOP)refs.set(e.id,el)}
  const dt=dtOf(e);
  if(Object.keys(dt).length)e.dt=dt;
  if(TOP)add(e);else try{W.top.postMessage({__ptr:1,e},'*')}catch{}
  return e
};
const upd=e=>{if(TOP)sched();else try{W.top.postMessage({__ptr:2,id:e.id,pu:e.pu},'*')}catch{}};

const hook=(o,k,cb)=>{try{
  const d=Object.getOwnPropertyDescriptor(o,k);
  if(!d||typeof d.value!=='function')return;
  const orig=d.value,f=function __ptr_w(...a){return cb.call(this,orig,a)};
  fake.set(f,orig);
  Object.defineProperty(o,k,{...d,value:f})
}catch{}};
const hookG=(o,k,cb)=>{try{
  const d=Object.getOwnPropertyDescriptor(o,k);
  if(!d||!d.get)return;
  const g=d.get,f=function __ptr_g(){return cb.call(this,g.call(this))};
  fake.set(f,g);
  Object.defineProperty(o,k,{...d,get:f})
}catch{}};
const hookS=(o,k,cb)=>{try{
  const d=Object.getOwnPropertyDescriptor(o,k);
  if(!d||!d.set)return;
  const s=d.set,f=function __ptr_s(v){if(cb.call(this,v)===true)return;return s.call(this,v)};
  fake.set(f,s);
  Object.defineProperty(o,k,{...d,set:f})
}catch{}};

const __ptr_dynrec=(kind,text)=>{
  const id=++DN,fr=__ptr_cap(),f0=fr.find(f=>f.t==='file');
  const tx=text.slice(0,300000);
  dyn.set(id,{text:tx,kind,fr,cu:f0&&f0.u,cl:f0&&f0.l});
  dynSz+=tx.length;
  while(dyn.size>600||(dynSz>2e7&&dyn.size>1)){const k=dyn.keys().next().value;dynSz-=dyn.get(k).text.length;dyn.delete(k)}
  return id
};
const __ptr_fw=a=>{
  try{
    if(!a.length||DN>5000)return a;
    const b=Array.prototype.slice.call(a),body=SS(b[b.length-1]);
    const id=__ptr_dynrec('fn',`(function anonymous(${b.slice(0,-1).map(SS).join(',')}\n) {\n${body}\n})`);
    b[b.length-1]=body+'\n//# sourceURL=ptr-script-'+id+'.js';
    return b
  }catch{return a}
};
const __ptr_wr=s=>s.replace(/(<script\b([^>]*)>)([\s\S]*?)(<\/script)/gi,(m,o,at,b,c)=>{
  if(!b.trim()||/\bsrc\s*=/i.test(at))return m;
  const ty=/\btype\s*=\s*["']?([^"'\s>]*)/i.exec(at);
  if(ty&&ty[1]&&!/^(module|(text|application)\/(x-)?(java|ecma)script)$/i.test(ty[1]))return m;
  const id=__ptr_dynrec('script',b);
  return o+b+'\n//# sourceURL=ptr-script-'+id+'.js\n'+c
});
const resolve=f=>{
  if(f.t!=='eval'||f.dx)return;
  let n=0,hit=null;
  for(const r of[...dyn.values()].reverse()){
    if(r.kind==='script'||r.cu!==f.cu||r.cl!==f.cl)continue;
    const x=r.text.split('\n')[f.l-1];
    if(x!=null&&f.c<=x.length+1){n++;if(!hit)hit=r}
  }
  if(hit){f.dx=hit.text.slice(0,300000);f.dxn=n}
};
const __ptr_tag=n=>{
  try{
    if(!n||n.nodeName!=='SCRIPT'||dynOf.has(n)||n.src||n.getAttribute('src'))return;
    const ty=(n.getAttribute('type')||'').toLowerCase();
    if(ty&&!/^(module|(text|application)\/(x-)?(java|ecma)script)$/.test(ty))return;
    const tx=n.text;
    if(!tx||!tx.trim())return;
    const id=__ptr_dynrec('script',tx);
    dynOf.set(n,id);
    n.text=tx+'\n//# sourceURL=ptr-script-'+id+'.js'
  }catch{}
};
const __ptr_tagAny=n=>{
  try{
    if(!n)return;
    if(n.nodeType===11&&n.querySelectorAll)n.querySelectorAll('script').forEach(__ptr_tag);
    else __ptr_tag(n)
  }catch{}
};
const __ptr_tg=(w,el,v)=>{
  const t=S(v);
  if(NS.test(t))return false;
  const raw=el.getAttribute(/^form$/i.test(el.nodeName)?'action':'href')||'';
  const url=raw?abs(w,raw):'';
  const x=url?dfz(w,url):DM()===2;
  __ptr_rec(w,'target=',{tg:t,url},el,null,x);
  if(x){
    dead.add(el);
    try{const ev=w.event;if(ev&&ev.type==='click'&&!ev.defaultPrevented&&el.contains(ev.target))ev.preventDefault()}catch{}
  }
  return x
};

const install=w=>{
  if(done.has(w))return;
  done.add(w);
  try{
    const FP=w.Function.prototype,ots=FP.toString;
    const nts=function __ptr_ts(){return ots.call(fake.get(this)||this)};
    fake.set(nts,ots);
    FP.toString=nts;
    try{
      const F=w.Function;
      const P=new Proxy(F,{
        construct:function __ptr_c(t,a,nt){return Reflect.construct(t,__ptr_fw(a),nt===P?t:nt)},
        apply:function __ptr_c(t,th,a){return Reflect.apply(t,th,__ptr_fw(a))}
      });
      fake.set(P,F);
      w.Function=P;
      FP.constructor=P
    }catch{}
    const D=w.document;
    if(EV()){
      hook(w,'eval',function __ptr_c(o,a){
        if(typeof a[0]==='string'&&DN<=5000){const id=__ptr_dynrec('eval',a[0]);a=[a[0]+'\n//# sourceURL=ptr-script-'+id+'.js']}
        return o.apply(this,a)
      });
      ['setTimeout','setInterval'].forEach(k=>hook(w,k,function __ptr_c(o,a){
        if(typeof a[0]==='string'&&DN<=5000){try{const id=__ptr_dynrec('eval',a[0]);a=[a[0]+'\n//# sourceURL=ptr-script-'+id+'.js'].concat(Array.prototype.slice.call(a,1))}catch{}}
        return o.apply(this,a)
      }));
      ['write','writeln'].forEach(k=>hook(w.Document.prototype,k,function __ptr_c(o,a){
        try{if(DN<=5000)a=a.map(x=>typeof x==='string'&&/<script/i.test(x)?__ptr_wr(x):x)}catch{}
        return o.apply(this,a)
      }))
    }
    hook(w.URL,'createObjectURL',function __ptr_c(o,a){
      const u=o.apply(this,a);
      try{const b=a[0];if(b&&typeof b.text==='function'&&b.size<2e6&&!/^(image|video|audio)\//.test(b.type||'')){blobs.set(u,b);if(blobs.size>80)blobs.delete(blobs.keys().next().value)}}catch{}
      return u
    });

    hook(w,'open',function __ptr_c(o,a){
      const raw=S(a[0]),f=S(a[2]),pu=[],url=raw?abs(w,raw):'about:blank';
      if(TINY.test(f))pu.push('tiny or off-screen window');
      if(!raw||raw==='about:blank')pu.push('blank url filled after open');
      const x=dfz(w,url);
      const e=__ptr_rec(w,'open',{url,name:S(a[1]),feat:f},null,pu,x);
      if(e){lastE=e;lastT=Date.now()}
      if(x)return ghost();
      return o.apply(this,a)
    });
    ['focus','blur'].forEach(k=>hook(w,k,function __ptr_c(o,a){
      if(lastE&&Date.now()-lastT<3000){const p=k+'() right after open';if(!lastE.pu.includes(p)){lastE.pu.push(p);upd(lastE)}}
      return o.apply(this,a)
    }));
    hook(w.HTMLElement.prototype,'click',function __ptr_c(o,a){
      try{
        if(this instanceof w.HTMLAnchorElement){
          const t=this.getAttribute('target')||'',href=abs(w,this.getAttribute('href')||'');
          const x=dead.has(this)||(!NS.test(t)&&dfz(w,href));
          __ptr_rec(w,'a.click',{url:href,tg:t},this,null,x);
          if(x)return
        }else if(this.form){
          const t=this.getAttribute('formtarget')||this.form.getAttribute('target')||'';
          if(!NS.test(t)||dead.has(this.form)){
            const u=abs(w,this.form.getAttribute('action')||''),x=dead.has(this.form)||dfz(w,u);
            __ptr_rec(w,'form',{url:u,tg:t,fn:'click'},this.form,null,x);
            if(x)return
          }
        }
      }catch{}
      return o.apply(this,a)
    });
    hook(w.HTMLFormElement.prototype,'submit',function __ptr_c(o,a){
      try{
        const t=this.getAttribute('target')||'';
        if(!NS.test(t)||dead.has(this)){
          const u=abs(w,this.getAttribute('action')||''),x=dead.has(this)||dfz(w,u);
          __ptr_rec(w,'form',{url:u,tg:t,fn:'submit()'},this,null,x);
          if(x)return
        }
      }catch{}
      return o.apply(this,a)
    });
    hook(w.EventTarget.prototype,'dispatchEvent',function __ptr_c(o,a){
      try{
        if(a[0]&&a[0].type==='click'&&this instanceof w.HTMLAnchorElement){
          const t=this.getAttribute('target')||'',href=abs(w,this.getAttribute('href')||'');
          const x=dead.has(this)||(!NS.test(t)&&dfz(w,href));
          __ptr_rec(w,'dispatch click',{url:href,tg:t},this,null,x);
          if(x)return false
        }
      }catch{}
      return o.apply(this,a)
    });
    hook(w.Document.prototype,'createElement',function __ptr_c(o,a){
      const el=o.apply(this,a);
      try{if(/^(a|form|iframe|area)$/i.test(S(a[0])))born.set(el,__ptr_cap())}catch{}
      return el
    });
    hook(w.Element.prototype,'setAttribute',function __ptr_c(o,a){
      try{if(/^(a|form|area)$/i.test(this.nodeName)&&S(a[0]).toLowerCase()==='target'&&__ptr_tg(w,this,a[1]))return}catch{}
      return o.apply(this,a)
    });
    [w.HTMLAnchorElement,w.HTMLFormElement,w.HTMLAreaElement].forEach(C=>hookS(C&&C.prototype,'target',function __ptr_c(v){
      try{return __ptr_tg(w,this,v)}catch{return false}
    }));
    ['appendChild','insertBefore','replaceChild'].forEach(k=>hook(w.Node.prototype,k,function __ptr_c(o,a){__ptr_tagAny(a[0]);return o.apply(this,a)}));
    ['append','prepend','before','after','replaceWith'].forEach(k=>hook(w.Element.prototype,k,function __ptr_c(o,a){a.forEach(__ptr_tagAny);return o.apply(this,a)}));
    hook(w.Element.prototype,'insertAdjacentElement',function __ptr_c(o,a){__ptr_tagAny(a[1]);return o.apply(this,a)});
    hookG(w.HTMLIFrameElement.prototype,'contentWindow',function __ptr_c(v){try{if(v)install(v)}catch{}return v});
    hookG(w.HTMLIFrameElement.prototype,'contentDocument',function __ptr_c(v){try{if(v&&v.defaultView)install(v.defaultView)}catch{}return v});

    AEL.call(w,'click',function __ptr_h(ev){
      try{
        const a=ev.target&&ev.target.closest&&ev.target.closest('a[href],area[href]');
        if(!a)return;
        const href=abs(w,a.getAttribute('href')),t0=a.getAttribute('target')||'',m=DM();
        const x=dead.has(a)||(!NS.test(t0)&&(m===2||(m===1&&ovl(a)&&third(w,href))));
        if(x)ev.preventDefault();
        const evo={t:ev.type,tr:ev.isTrusted,tg:(ev.target.nodeName||'').toLowerCase()};
        const __ptr_t=()=>{try{const t=a.getAttribute('target')||'';if(x||!NS.test(t))__ptr_rec(w,'anchor',{url:href,tg:t||t0},a,null,x,evo)}catch{}};
        setTimeout(__ptr_t,0)
      }catch{}
    },true);
    AEL.call(w,'submit',function __ptr_h(ev){
      try{
        const f=ev.target,t=f.getAttribute('target')||'';
        if(!NS.test(t)||dead.has(f)){
          const u=abs(w,f.getAttribute('action')||''),x=dead.has(f)||dfz(w,u);
          if(x)ev.preventDefault();
          __ptr_rec(w,'form',{url:u,tg:t,fn:'submit event'},f,null,x)
        }
      }catch{}
    },true);
    if(w.navigation)AEL.call(w.navigation,'navigate',function __ptr_h(e){
      try{
        if(e.hashChange||e.userInitiated||e.destination.sameDocument)return;
        const u=e.destination.url,x=DM()>0&&e.cancelable&&third(w,u);
        __ptr_rec(w,'navigate',{url:u,nt:e.navigationType},null,null,x);
        if(x)e.preventDefault()
      }catch{}
    });
    const scan=()=>{try{D.querySelectorAll('base[target="_blank" i],meta[http-equiv="refresh" i]').forEach(el=>__ptr_rec(w,'static',{url:el.getAttribute('href')||el.getAttribute('content')||'',tg:el.getAttribute('target')||''},el))}catch{}};
    if(D.readyState==='loading')AEL.call(D,'DOMContentLoaded',scan,{once:true});else scan();

    hook(w.EventTarget.prototype,'addEventListener',function __ptr_c(o,a){
      try{
        const t=this;
        if(LT.has(a[0])&&(t===w||t===D||t===D.documentElement||t===D.body)&&lis())
          __ptr_rec(w,'listener',{ty:a[0],cap:a[2]===true||!!(a[2]&&a[2].capture),fn:S(a[1]&&a[1].name)})
      }catch{}
      return o.apply(this,a)
    });
  }catch{}
};

const KN={open:'window.open','a.click':'a.click()',anchor:'link click','dispatch click':'dispatchEvent click',form:'form submit','target=':'target set',navigate:'navigation',listener:'listener',static:'static markup'};
const GR={open:'open','a.click':'click',anchor:'click','dispatch click':'click',form:'form',navigate:'nav',listener:'listen','target=':'open',static:'misc'};
const GN=['open','click','form','nav','misc','listen'];
const TG={file:'script',dyn:'dynamic inline',eval:'eval code',ext:'extension',anon:'anonymous'};
const DL=['Defuse off','Defuse 3rd-party','Defuse all'];
const E=[],byId=new Map,expd=new Set,cache=new Map,codeBox=new Map;
const ON=Object.assign({open:1,click:1,form:1,nav:1,misc:1,listen:0},GV('chips',{}));
const POS=Object.assign({r:18,b:18},GV('pos',null)||{});
let SH=+GV('sheetH',0)||0,sv=null;
const DK=['padding-bottom','box-sizing','scroll-padding-bottom'];
const clampH=h=>Math.min(Math.max(140,W.innerHeight-70),Math.max(140,h));
const sheetH=()=>clampH(SH||Math.round(W.innerHeight*.5));
const q=s=>root&&root.querySelector(s);
const sched=()=>{if(raf)return;raf=requestAnimationFrame(()=>{raf=0;render()})};

const CSS=`
:host{--bg:#f6f7fa;--bg2:#fff;--bg3:#f7f8fb;--bd:#e3e6ee;--tx:#172033;--mt:#6b7589;--sb:#5f6a80;--ac:#2447c4;--acb:#eaf0ff;--acd:#c5d3fb;--cd:#f3f5f9}
*{box-sizing:border-box}
[hidden]{display:none!important}
button{font:inherit;cursor:pointer;color:inherit}
.wrap{position:fixed;right:18px;bottom:18px;z-index:2147483647;font:13px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--tx)}
#fab{display:flex;align-items:center;gap:9px;border:1px solid #dfe3ec;background:#fff;color:var(--tx);padding:8px 8px 8px 14px;border-radius:999px;box-shadow:0 4px 18px rgba(23,32,51,.10);font-weight:600;cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none}
#fab i{width:8px;height:8px;border-radius:50%;background:#2f9e6e}
#fab.paused i{background:#c9892b}
#fab b{min-width:24px;text-align:center;background:#2f5bea;color:#fff;border-radius:999px;padding:1px 8px;font-size:12px}
#fab.pulse{animation:pl .55s ease-out}
@keyframes pl{40%{box-shadow:0 0 0 7px rgba(47,91,234,.16)}}
@media (prefers-reduced-motion:reduce){#fab.pulse{animation:none}}
#panel{position:fixed;left:0;right:0;bottom:0;z-index:2147483647;display:flex;flex-direction:column;background:var(--bg);color:var(--tx);border-top:1px solid #dfe3ec;border-radius:14px 14px 0 0;box-shadow:0 -10px 36px rgba(23,32,51,.16);overflow:hidden;font:13px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
#grip,.top,.tools,.chips{background:#fff}
#grip{flex:none;display:flex;justify-content:center;padding:10px 0 8px;cursor:ns-resize;touch-action:none;user-select:none;-webkit-user-select:none}
#grip:before{content:"";width:46px;height:4px;border-radius:2px;background:#c3c9d6}
.top{flex:none;display:flex;align-items:center;gap:8px;padding:0 12px 8px}
.ttl{flex:1;display:flex;align-items:baseline;gap:8px;font-weight:700;font-size:15px;letter-spacing:-.01em;min-width:0;white-space:nowrap}
.ttl small{font-weight:500;font-size:11.5px;color:var(--mt);overflow:hidden;text-overflow:ellipsis;min-width:0}
.tools{flex:none;display:flex;gap:6px;overflow-x:auto;padding:0 12px 8px;scrollbar-width:none;touch-action:pan-x}
.tools::-webkit-scrollbar,.chips::-webkit-scrollbar{display:none}
.tb{flex:none;border:1px solid #dfe3ec;background:#fff;border-radius:8px;padding:4px 10px;font-size:12px;font-weight:600;color:#38435a;white-space:nowrap}
.tb:hover{background:#f1f3f8}
.tb.on{background:#172033;border-color:#172033;color:#fff}
.tb.x{font-size:17px;line-height:1;padding:2px 11px}
.chips{flex:none;display:flex;gap:6px;overflow-x:auto;padding:9px 12px;border-top:1px solid #e6e9f0;border-bottom:1px solid #e6e9f0;scrollbar-width:none;touch-action:pan-x}
.chip{flex:none;border:1px solid #dfe3ec;background:#fff;border-radius:999px;padding:2px 11px;font-size:12px;font-weight:600;color:#7a8498;white-space:nowrap}
.chip.on{background:#eaf0ff;border-color:#c5d3fb;color:#2447c4}
#list{flex:1;min-height:0;touch-action:pan-y;overscroll-behavior:contain;overflow:auto;padding:12px 12px calc(12px + env(safe-area-inset-bottom,0px));display:flex;flex-direction:column;gap:9px;scrollbar-width:thin}
.empty{margin:auto;text-align:center;color:#8791a5;padding:36px 12px}
.card{flex:none;position:relative;background:#fff;border:1px solid var(--bd);border-radius:10px;padding:10px 12px 10px 15px;overflow:hidden}
.card:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--c,#98a2b8)}
.card.open{--c:#2f5bea}
.card.click{--c:#0f8fb0}
.card.form{--c:#2f9e6e}
.card.nav{--c:#d6455d}
.card.misc{--c:#98a2b8}
.card.listen{--c:#c9892b}
.card:hover{border-color:#c9d2e6}
.row{display:flex;align-items:center;gap:7px;flex-wrap:wrap}
.hd,.url,.src{cursor:pointer}
.kind{font-weight:700;color:var(--tx)}
.pill{font-size:11px;font-weight:700;border-radius:999px;padding:1px 9px}
.pu{background:#d6455d;color:#fff}
.ov{background:#fdebd0;color:#8a5a14}
.df{background:#dff3e8;color:#1d6b49}
.tag{font-size:11px;color:var(--sb);background:#eef0f5;border-radius:5px;padding:1px 6px}
.time{margin-left:auto;font-size:11.5px;color:#8791a5;font-variant-numeric:tabular-nums}
.url{margin-top:6px;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;word-break:break-all;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-clamp:2;overflow:hidden}
.url.full{display:block;overflow:visible}
.src{margin-top:3px;font-size:12px;color:var(--mt);word-break:break-all}
.src b{color:var(--ac);font-weight:600}
.det{margin-top:10px;padding-top:10px;border-top:1px solid #edf0f5;display:flex;flex-direction:column;gap:8px}
.det h4{margin:2px 0 0;font-size:12px;font-weight:700;color:#38435a}
.kv{font-size:12px;color:#4a556b;word-break:break-all}
.kv b{color:var(--tx);margin-right:6px}
code.el,pre.code{display:block;margin:0;background:var(--cd);border:1px solid #e9edf4;border-radius:7px;padding:8px 9px;font:11.5px/1.5 ui-monospace,Menlo,Consolas,monospace;color:#38435a;word-break:break-all;white-space:pre-wrap}
pre.code{max-height:260px;overflow:auto}
pre.code i{color:#9aa3b5;font-style:normal;user-select:none}
pre.code mark{background:#fde68a;color:inherit;border-radius:2px}
.frw{display:flex;flex-direction:column;gap:4px}
.fr{display:flex;align-items:center;gap:7px;flex-wrap:wrap;padding:5px 8px;border-radius:7px;background:var(--bg3);border:1px solid #eef0f5}
.fr.main{background:var(--acb);border-color:var(--acd)}
.fn{font-weight:600;max-width:120px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.loc{font:11.5px ui-monospace,Menlo,Consolas,monospace;color:var(--ac);max-width:170px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sp{flex:1}
.mini{border:1px solid var(--acd);background:#fff;color:var(--ac);border-radius:6px;padding:2px 9px;font-size:11.5px;font-weight:600}
.mini:hover{background:var(--acb)}
button:focus-visible{outline:2px solid #2f5bea;outline-offset:2px}
.mt{margin-top:8px}
#viewer{position:fixed;inset:0;z-index:2147483647;display:flex;flex-direction:column;background:#fafbfc;color:#1f2937;font:13px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.vbar{display:flex;flex-direction:column;gap:8px;padding:12px 14px;background:#fff;border-bottom:1px solid #e6e9f0}
.vbar .tools{padding:0}
.vtt{display:flex;flex-direction:column;min-width:0}
.vtt b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.vtt span{color:var(--mt);font-size:12px}
#vscroll{flex:1;overflow:auto;-webkit-overflow-scrolling:touch}
.sn{margin:12px 14px 0;padding:10px 12px;background:var(--acb);border:1px solid var(--acd);border-radius:8px;font:12px ui-monospace,Menlo,monospace;color:#1e3a8a;word-break:break-all}
#vbody{margin:0;padding:12px 14px;font:12px/1.6 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-all;tab-size:2}
#vbody i{color:#9ca3af;font-style:normal;user-select:none}
#vbody .hit{background:#fef9c3}
#vbody mark{background:#fde047;color:#111;border-radius:2px}
`;

const canView=(e,f)=>f.t==='file'||(f.t==='dyn'&&!!(e.dt&&e.dt[f.dn]))||!!f.dx||!!f.src;
const flab=f=>{
  const p=f.l+':'+f.c;
  return f.t==='file'?short(f.u)+':'+p:f.t==='dyn'?'inline-script #'+f.dn+':'+p:f.t==='eval'?'eval/Function:'+p:f.t==='ext'?'extension:'+p:'anonymous:'+p
};
const frow=(e,s,i)=>{
  const f=(s==='by'?e.el.by:e.fr)[i],k=`${e.id}:${s}:${i}`,code=codeBox.get(k);
  const at=`data-a=src data-id=${e.id} data-s=${s} data-i=${i}`;
  const tg=f.syn?'decoded here':f.ins?'injector':f.t==='file'&&f.u===e.pg?'inline':TG[f.t]||'frame';
  return`<div class=frw><div class="fr${i===0?' main':''}"><span class=fn>${esc(f.f||'anonymous')}</span><span class=loc title="${esc(f.u||flab(f))}">${esc(flab(f))}</span><span class=tag>${esc(tg)}</span><span class=sp></span><button class=mini data-a=code data-id=${e.id} data-s=${s} data-i=${i}>${code!=null?'hide code':'code'}</button>${canView(e,f)?`${FF||f.t!=='file'?'':`<button class=mini ${at} data-m=vs>view-source</button>`}<button class=mini ${at} data-m=vw>${FF?'view source':'viewer'}</button>`:''}</div>${code!=null?`<pre class=code>${code}</pre>`:''}</div>`
};
const sum=(e,f)=>f.t==='eval'&&f.cu?`eval code, decoded at <b>${esc(short(f.cu))}:${esc(f.cl)}:${esc(f.cc)}</b>`:`<b>${esc(flab(f))}</b> ${f.t==='file'?(f.u===e.pg?'inline in page':esc(hostOf(f.u))):esc(TG[f.t]||'')}`;
const card=e=>{
  const g=GR[e.k],f=e.fr[0],x=`data-a=exp data-id=${e.id}`;
  let fm='';
  try{if(e.pg&&e.pg!==location.href)fm=hostOf(e.pg)}catch{}
  const U=e.d.url||(e.d.ty?e.d.ty+(e.d.cap?' (capture)':'')+(e.d.fn?' '+e.d.fn:''):'')||(e.d.tg?'target="'+e.d.tg+'"':'')||'(empty)';
  let h=`<div class="card ${g}"><div class="row hd" ${x}><span class=kind>${KN[e.k]}</span>${e.df?'<span class="pill df">defused</span>':''}${e.pu.length?'<span class="pill pu">popunder?</span>':''}${e.el&&e.el.ov?'<span class="pill ov">overlay?</span>':''}${fm?`<span class=tag>frame ${esc(fm)}</span>`:''}<span class=time>${new Date(+e.t).toLocaleTimeString([],{hour12:false})}</span></div>`;
  h+=`<div class="url${expd.has(e.id)?' full':''}" ${x}>${esc(U)}</div>`;
  h+=`<div class=src ${x}>${f?'from '+sum(e,f):'no script frame, native or user action'}</div>`;
  if(!expd.has(e.id)&&codeBox.has(`${e.id}:fr:0`))h+=`<pre class="code mt">${codeBox.get(`${e.id}:fr:0`)}</pre>`;
  if(!expd.has(e.id)&&f)h+=`<div class="row mt"><button class=mini data-a=quick data-id=${e.id}>Show code</button>${canView(e,f)?`<button class=mini data-a=qv data-id=${e.id}>${FF?'View source':'Viewer'}</button>`:''}</div>`;
  if(expd.has(e.id)){
    const t=e.ev?`${esc(e.ev.t)}, ${e.ev.tr?'real user gesture':'script-dispatched'}, on &lt;${esc(e.ev.tg)}&gt;`:'no event context (timer, async or page load)';
    h+=`<div class=det><div class=kv><b>Trigger</b>${t}</div>`;
    if(e.d.name||e.d.feat)h+=`<div class=kv><b>Window</b>name "${esc(e.d.name)}", features "${esc(e.d.feat)}"</div>`;
    if(e.d.tg)h+=`<div class=kv><b>Target</b>${esc(e.d.tg)}</div>`;
    if(e.pu.length)h+=`<div class=kv><b>Popunder signs</b>${esc(e.pu.join('; '))}</div>`;
    if(e.fr.length){const k0=`${e.id}:fr:0`;h+=`<div class=row><button class=mini data-a=code data-id=${e.id} data-s=fr data-i=0>${codeBox.has(k0)?'Hide triggering code':'Show triggering code'}</button></div>`}
    if(e.el){
      h+=`<h4>Element</h4><code class=el>${esc(e.el.tag)}</code><div class=row>`;
      if(!e.el.by)h+=`${FF?'':`<button class=mini data-a=el data-m=vs data-id=${e.id}>source</button>`}<button class=mini data-a=el data-m=vw data-id=${e.id}>${FF?'view source':'viewer'}</button>`;
      else h+='<span class=tag>created by script</span>';
      if(refs.has(e.id))h+=`<button class=mini data-a=el data-m=dom data-id=${e.id}>live DOM</button><button class=mini data-a=hl data-id=${e.id}>highlight</button>`;
      h+='</div>';
      if(e.el.by&&e.el.by.length)h+='<h4>Element created at</h4>'+e.el.by.map((_,i)=>frow(e,'by',i)).join('')
    }
    h+=`<h4>Call stack (${e.fr.length})</h4>`+(e.fr.length?e.fr.map((_,i)=>frow(e,'fr',i)).join(''):`<div class=kv>No frames parsed.</div>${e.raw?`<pre class=code>${esc(e.raw)}</pre>`:''}`);
    h+=`<div class=row><button class=mini data-a=cu data-id=${e.id}>copy url</button></div></div>`
  }
  return h+'</div>'
};

const dock=()=>{
  const pn=q('#panel'),de=document.documentElement;
  if(!pn||!de)return;
  if(pn.hidden){
    if(sv){DK.forEach(k=>{sv[k][0]?de.style.setProperty(k,sv[k][0],sv[k][1]):de.style.removeProperty(k)});sv=null}
    return
  }
  const h=sheetH();
  pn.style.height=h+'px';
  if(!sv){sv={};DK.forEach(k=>{sv[k]=[de.style.getPropertyValue(k),de.style.getPropertyPriority(k)]})}
  de.style.setProperty('padding-bottom',h+'px','important');
  de.style.setProperty('box-sizing','content-box','important');
  de.style.setProperty('scroll-padding-bottom',h+'px','important')
};
const render=()=>{
  if(!root)return;
  const pn=q('#panel'),c={};
  GN.forEach(g=>c[g]=0);
  E.forEach(e=>c[GR[e.k]]++);
  const vis=E.filter(e=>ON[GR[e.k]]);
  q('#cnt').textContent=vis.length;
  q('#fab').classList.toggle('paused',!!GV('pause',false));
  q('.wrap').hidden=!pn.hidden;
  dock();
  if(pn.hidden){place();return}
  const p=GV('pause',false),m=DM();
  status();
  q('#tools').innerHTML=`<button class="tb${p?' on':''}" data-a=tool data-t=pause>${p?'Resume':'Pause'}</button><button class="tb${m?' on':''}" data-a=tool data-t=defuse>${DL[m]}</button><button class="tb${EV()?' on':''}" data-a=tool data-t=evalt title="Reload the page to apply">Eval ${EV()?'on':'off'}</button><button class=tb data-a=tool data-t=copy>Copy</button><button class=tb data-a=tool data-t=clear>Clear</button>`;
  q('#chips').innerHTML=GN.map(g=>`<button class="chip${ON[g]?' on':''}" data-a=chip data-g=${g}>${g} ${c[g]}</button>`).join('');
  const l=q('#list'),st=l.scrollTop;
  l.innerHTML=vis.length?vis.slice(-150).reverse().map(e=>{try{return card(e)}catch{return''}}).join(''):'<div class=empty>No popup activity yet.<br>Interact with the page.</div>';
  l.scrollTop=st;
  l.querySelectorAll('pre.code').forEach(p=>{const m=p.querySelector('mark');if(m)p.scrollTop=Math.max(0,m.getBoundingClientRect().top-p.getBoundingClientRect().top+p.scrollTop-60)});
  place()
};
const status=()=>{
  const s=q('#sub'),pn=q('#panel');
  if(!s||!pn||pn.hidden)return;
  s.textContent=errMsg||`v${VER} ${location.hostname}, ${E.filter(e=>ON[GR[e.k]]).length} events${lastTap?' | tap '+lastTap:''} | pu${nPU} te${nTE} ck${nCK}${dbg?' | '+dbg:''}`
};
const place=()=>{
  const wp=q('.wrap');
  if(!wp||wp.hidden)return;
  const rc=wp.getBoundingClientRect();
  if(!rc.width)return;
  POS.r=Math.min(Math.max(0,POS.r),Math.max(0,W.innerWidth-rc.width));
  POS.b=Math.min(Math.max(0,POS.b),Math.max(0,W.innerHeight-rc.height));
  wp.style.right=POS.r+'px';
  wp.style.bottom=POS.b+'px'
};

const getText=u=>cache.has(u)?Promise.resolve(cache.get(u)):new Promise((ok,no)=>{
  const fin=t=>{cache.set(u,t);ok(t)};
  if(/^blob:/.test(u)&&blobs.has(u)){blobs.get(u).text().then(fin,no);return}
  if(/^(blob|data):/.test(u)){fetch(u).then(r=>r.text()).then(fin,no);return}
  GM_xmlhttpRequest({url:u.replace(/#.*$/,''),timeout:20000,onload:r=>r.responseText!=null&&r.responseText!==''?fin(r.responseText):no(),onerror:no,ontimeout:no})
});
const locate=(t,nd)=>{
  const lt=t.toLowerCase();
  for(const n of nd){
    const i=lt.indexOf(n.toLowerCase());
    if(i>=0){const p=t.lastIndexOf('\n',i-1);return{l:t.slice(0,i).split('\n').length,c:i-p,n:n.length}}
  }
  return null
};
const snip=(t,L,C,k=5)=>{
  const ls=t.split('\n'),x=ls[L-1]||'';
  if(x.length>400||(ls.length<2&&x.length>200)){
    const c=Math.max(0,C-1),a=Math.max(0,c-350);
    return`${a?'...':''}${esc(x.slice(a,c))}<mark>${esc(x.slice(c,c+40))}</mark>${esc(x.slice(c+40,c+450))}...`
  }
  const s=Math.max(0,L-k-1),e=Math.min(ls.length,L+k),w=String(e).length;
  let h='';
  for(let i=s;i<e;i++){const ln=ls[i].slice(0,500);h+=`<i>${String(i+1).padStart(w)}</i> ${i+1===L?`<mark>${esc(ln)}</mark>`:esc(ln)}\n`}
  return h
};
const frameCode=async(e,f,k)=>{
  try{
    if(f.t==='dyn'){
      const x=e.dt&&e.dt[f.dn];
      if(x)return(x.fr&&x.fr.length?`inserted by ${esc(x.fr.slice(0,3).map(flab).join(' < '))}\n\n`:'')+snip(String(x.x),f.l,f.c,k)
    }
    if(f.dx)return(f.dxn>1?`one of ${f.dxn} candidates, newest match\n\n`:'')+snip(String(f.dx),f.l,f.c,k);
    if(f.t==='file')return(f.syn&&!f.c?'creator line start (no column in this browser)\n\n':'')+snip(await getText(f.u),f.l,f.c);
    if(f.src)return esc(f.src)+(f.src.length>=6000?'\n...':'')
  }catch{return'Could not load source for this frame.'}
  return f.t==='eval'?'Source not captured. Turn Eval on and reload so eval, timer strings and document.write scripts get recorded.':'No source captured for this frame.'
};
const rows=(t,L,C,n)=>{
  const ls=t.split('\n'),big=ls.length>6000;
  let s=0,e=ls.length;
  if(big){s=L?Math.max(0,L-1501):0;e=Math.min(ls.length,s+3000)}
  const w=String(e).length;
  let h='';
  for(let i=s;i<e;i++){
    const x=ls[i];
    let c;
    if(i+1===L){const k=Math.max(0,(C||1)-1);c=`<span class=hit id=hit>${esc(x.slice(0,k))}<mark>${esc(x.slice(k,k+n))}</mark>${esc(x.slice(k+n))}</span>`}
    else c=esc(x);
    h+=`<i>${String(i+1).padStart(w)}</i>  ${c}\n`
  }
  const cl=L&&ls[L-1]&&ls[L-1].length>300?`<div class=sn>...${esc(ls[L-1].slice(Math.max(0,(C||1)-161),(C||1)+159))}...</div>`:'';
  return{h,big,cl}
};
const showViewer=(u,t,L,C,n)=>{
  mount();
  if(!root)return;
  lastV={u,t,L,C,n};
  const{h,big,cl}=rows(t,L,C,n);
  q('#vt').textContent=u;
  q('#vm').textContent=`line ${L||'-'}, col ${C||'-'}${big?', windowed':''}`;
  q('#vsn').innerHTML=cl;
  q('#vbody').innerHTML=h;
  q('#viewer').hidden=false;
  const hit=q('#hit');
  if(hit&&hit.scrollIntoView)hit.scrollIntoView({block:'center'});else q('#vscroll').scrollTop=0;
  setTimeout(()=>{const v=q('#viewer');if(v&&!v.hidden&&!v.offsetHeight){errMsg='Viewer could not render in this page';render()}},150)
};
const page=(u,t,L,C,n)=>{
  const{h,big,cl}=rows(t,L,C,n);
  return`<!doctype html><meta charset=utf-8><title>${esc(short(u))}${L?':'+L:''}</title><style>body{margin:0;background:#fafbfc;color:#1f2937}.bar{position:sticky;top:0;z-index:1;display:flex;flex-wrap:wrap;gap:6px 16px;justify-content:space-between;padding:10px 16px;background:#fff;border-bottom:1px solid #e5e7eb;font:13px system-ui,sans-serif;word-break:break-all}.bar span{color:#6b7280}.sn{margin:12px 16px 0;padding:10px 12px;background:#eaf0ff;border:1px solid #c5d3fb;border-radius:8px;font:12px ui-monospace,Menlo,monospace;color:#1e3a8a;word-break:break-all}pre{margin:0;padding:12px 16px;font:12.5px/1.6 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-all;tab-size:2}i{color:#9ca3af;font-style:normal;user-select:none}.hit{background:#fef9c3;scroll-margin-top:140px}mark{background:#fde047;color:#111;border-radius:2px}</style><div class=bar><b>${esc(u)}</b><span>line ${L||'-'}, col ${C||'-'}${big?', windowed':''}</span></div>${cl}<pre>${h}</pre>`
};
const openSrc=async(m,u,L,C,nd,text)=>{
  if(FF&&m==='vs')m='vw';
  let t=text;
  if(t==null){
    if(!/^(https?|blob|data):/.test(u))return;
    if(m==='vw')showViewer(u,'Loading...',0,0,0);
    try{t=await getText(u)}catch{}
  }
  let n=40;
  if(t!=null&&nd&&nd.length){const h=locate(t,nd);if(h){L=h.l;C=h.c;n=h.n}}
  if(m==='vs'){GM_openInTab('view-source:'+u.replace(/#.*$/,'')+(L?'#line'+L:''),{active:true});return}
  showViewer(u,t==null?'Could not load source (blocked or network error).':t,t==null?0:L,C,n)
};

const autoCode=e=>{
  const k=`${e.id}:fr:0`;
  if(!e.fr.length||codeBox.has(k))return;
  codeBox.set(k,'Loading...');render();
  frameCode(e,e.fr[0]).then(h=>{codeBox.set(k,h);render()},()=>{codeBox.set(k,'Could not load code.');render()})
};
const viewFrame=(e,f,m)=>{
  if(f.t==='file')return openSrc(m,f.u,f.l,f.c);
  const x=f.t==='dyn'&&e.dt&&e.dt[f.dn],t=x?String(x.x):f.dx||f.src;
  if(t)return openSrc('vw',f.t==='dyn'?'inline-script #'+f.dn:f.t==='eval'?'eval/Function code':'captured function source',f.t==='dyn'||f.dx?f.l:0,f.c,null,t)
};
const setOpen=v=>{
  mount();
  if(!root)return;
  const p=q('#panel'),se=document.scrollingElement||document.documentElement;
  if(p.hidden===!v)return;
  const at=v&&se.scrollTop+se.clientHeight>=se.scrollHeight-4;
  p.hidden=!v;
  render();
  if(at)se.scrollTop=se.scrollHeight
};
const toggle=()=>{mount();if(!root)return;setOpen(q('#panel').hidden)};
const onClick=ev=>{
  errMsg='';
  try{
    const r=onClick0(ev);
    if(r&&r.catch)r.catch(x=>{errMsg='Error: '+S(x&&x.message);render()})
  }catch(x){errMsg='Error: '+S(x&&x.message);render()}
};
const onClick0=ev=>{
  const b=ev.target.closest('[data-a]');
  if(!b)return;
  const d=b.dataset,e=byId.get(d.id);
  lastTap=d.a+(d.t?':'+d.t:'');
  if(d.id&&!e){lastTap+=' stale-id';render();return}
  switch(d.a){
    case'fab':if(!moved)toggle();break;
    case'exp':{const was=expd.has(d.id);was?expd.delete(d.id):expd.add(d.id);render();if(!was)autoCode(e);break}
    case'vclose':q('#viewer').hidden=true;break;
    case'vcopy':if(lastV)GM_setClipboard(lastV.t,'text');break;
    case'vtab':if(lastV)OPEN.call(W,URL.createObjectURL(new Blob([page(lastV.u,lastV.t,lastV.L,lastV.C,lastV.n)],{type:'text/html'}))+(lastV.L?'#hit':''),'_blank','noopener');break;
    case'quick':expd.add(d.id);render();autoCode(e);break;
    case'qv':if(e.fr[0])return viewFrame(e,e.fr[0],'vw');break;
    case'chip':ON[d.g]=ON[d.g]?0:1;SV('chips',ON);render();break;
    case'tool':
      if(d.t==='pause')SV('pause',!GV('pause',false));
      else if(d.t==='defuse')SV('defuse',(DM()+1)%3);
      else if(d.t==='evalt')SV('evalTrace',!EV());
      else if(d.t==='copy')GM_setClipboard(JSON.stringify(E,null,1),'text');
      else if(d.t==='clear'){E.length=0;byId.clear();refs.clear();expd.clear();codeBox.clear()}
      else if(d.t==='min')setOpen(false);
      render();break;
    case'code':{
      const k=`${d.id}:${d.s}:${d.i}`;
      if(codeBox.has(k)){codeBox.delete(k);render();break}
      const f=(d.s==='by'?e.el.by:e.fr)[+d.i];
      if(!f)break;
      codeBox.set(k,'Loading...');render();
      frameCode(e,f).then(h=>{codeBox.set(k,h);render()},()=>{codeBox.set(k,'Could not load code.');render()});
      break}
    case'src':{const f=(d.s==='by'?e.el.by:e.fr)[+d.i];if(f)return viewFrame(e,f,d.m);break}
    case'el':
      if(d.m==='dom'){
        const el=refs.get(d.id);
        if(el)return openSrc('vw',e.pg+' (live DOM)',0,0,e.el.nd,'<!DOCTYPE html>\n'+el.ownerDocument.documentElement.outerHTML.replace(/></g,'>\n<'))
      }else return openSrc(d.m,e.pg,0,0,e.el.nd);
      break;
    case'hl':{
      const el=refs.get(d.id);
      if(el&&el.isConnected){el.scrollIntoView({block:'center'});const o=el.style.outline;el.style.outline='3px solid #d6455d';setTimeout(()=>{el.style.outline=o},2200)}
      break}
    case'cu':GM_setClipboard(S(e.d.url),'text');break
  }
};
const mount=()=>{
  if(root)return;
  if(!document.documentElement){
    if(!pend){pend=true;AEL.call(W,'DOMContentLoaded',()=>{mount();sched()},{once:true})}
    return
  }
  host=document.createElement('div');
  host.style.cssText='all:initial';
  root=host.attachShadow({mode:'open'});
  let ad=false;
  try{if('adoptedStyleSheets' in root){const sh=new W.CSSStyleSheet();sh.replaceSync(CSS);root.adoptedStyleSheets=[sh];ad=true}}catch{}
  root.innerHTML=(ad?'':`<style>${CSS}</style>`)+`<div class=wrap><button id=fab data-a=fab><i></i>Popups <b id=cnt>0</b></button></div><div id=panel hidden><div id=grip></div><div class=top><div class=ttl>Popup Tracer<small id=sub></small></div><button class="tb x" data-a=tool data-t=min aria-label=Close>&times;</button></div><div class=tools id=tools></div><div class=chips id=chips></div><div id=list></div></div><div id=viewer hidden><div class=vbar><div class=vtt><b id=vt></b><span id=vm></span></div><div class=tools><button class=tb data-a=vtab>Open in tab</button><button class=tb data-a=vcopy>Copy</button><button class=tb data-a=vclose>Close</button></div></div><div id=vscroll><div id=vsn></div><pre id=vbody></pre></div></div>`;
  AEL.call(root,'scroll',function __ptr_h(){lastScroll=Date.now()},true);
  AEL.call(root,'click',function __ptr_h(ev){
    ev.stopPropagation();
    if(Date.now()-tapAt<700)return;
    const t=ev.target;
    if(t&&t.closest)onClick({target:t})
  });
  document.documentElement.appendChild(host);
  try{host.setAttribute('popover','manual');host.showPopover()}catch{}
  place()
};
const add=e=>{
  if(!e||!KN[e.k]||!Array.isArray(e.fr)||!Array.isArray(e.pu)||!e.d||typeof e.d!=='object')return;
  e.id=S(e.id).replace(/[^\w-]/g,'');
  if(!e.id||byId.has(e.id))return;
  E.push(e);byId.set(e.id,e);
  const f0=e.fr[0];
  if(f0&&(f0.t==='dyn'||f0.dx)){const k=`${e.id}:fr:0`;codeBox.set(k,'Loading...');frameCode(e,f0,20).then(h=>{codeBox.set(k,h);sched()},()=>{})}
  if(E.length>400){const x=E.shift();byId.delete(x.id);refs.delete(x.id);expd.delete(x.id)}
  if(!root&&ON[GR[e.k]])mount();
  sched();
  const f=q('#fab');
  if(f&&ON[GR[e.k]]){f.classList.remove('pulse');void f.offsetWidth;f.classList.add('pulse')}
};

const inUI=ev=>{try{return!!host&&ev.composedPath().includes(host)}catch{return false}};
const hitR=(el,x,y)=>{const r=el.getBoundingClientRect();return r.width>0&&r.height>0&&x>=r.left&&x<=r.right&&y>=r.top&&y<=r.bottom};
const inRect=(x,y)=>{
  if(!root)return false;
  try{for(const s of['#viewer:not([hidden])','#panel:not([hidden])','.wrap:not([hidden]) #fab']){const el=root.querySelector(s);if(el&&hitR(el,x,y))return true}}catch{}
  return false
};
const uiHit=(x,y)=>{
  if(!root)return null;
  try{
    const v=q('#viewer'),sc=v&&!v.hidden?v:root;
    let b=null;
    for(const el of sc.querySelectorAll('[data-a]')){
      if(!hitR(el,x,y))continue;
      const l=el.closest('#list');
      if(l&&!hitR(l,x,y))continue;
      b=el
    }
    return b
  }catch{return null}
};
const uiTarget=(ev,x,y)=>{
  try{
    const t=ev.composedPath()[0],b=t&&t!==host&&t.closest&&t.closest('[data-a]');
    if(b&&b.getRootNode()===root)return b
  }catch{}
  return uiHit(x,y)
};
const xy=ev=>{const p=(ev.touches&&ev.touches[0])||(ev.changedTouches&&ev.changedTouches[0])||ev;return[p.clientX,p.clientY]};
const isUI=ev=>{if(inUI(ev))return true;const[x,y]=xy(ev);return inRect(x,y)};
const startDrag=(k,x,y)=>{if(!drag){drag={k,x,y,r:POS.r,b:POS.b,h:sheetH()};moved=false}};
const moveDrag=(x,y)=>{
  if(!drag)return;
  const dx=x-drag.x,dy=y-drag.y;
  if(!moved&&Math.hypot(dx,dy)<6)return;
  moved=true;
  if(drag.k==='grip'){SH=clampH(Math.round(drag.h-dy));dock()}
  else{POS.r=drag.r-dx;POS.b=drag.b-dy;place()}
};
const endDrag=()=>{
  if(drag&&moved){
    if(drag.k==='grip')SV('sheetH',SH);else SV('pos',POS);
    setTimeout(()=>{moved=false},80)
  }
  drag=null
};
const grab=(ev,x,y)=>{
  let p=[];
  try{p=ev.composedPath()}catch{}
  const has=id=>p.some(n=>n&&n.nodeType===1&&n.getRootNode()===root&&n.id===id);
  const gr=root&&root.querySelector('#grip');
  if(has('grip')||(gr&&hitR(gr,x,y)))return'grip';
  if(has('fab'))return'fab';
  return''
};

if(TOP){
  const tap=(ev,x,y,was)=>{
    const mv=was||(g&&g.mv)||Date.now()-lastScroll<120;
    g=null;
    if(Date.now()-tapAt<350)return;
    tapAt=Date.now();
    if(mv){dbg='drag';status();return}
    const t=uiTarget(ev,x,y);
    dbg=`${x|0},${y|0}>${t?t.dataset.a:'none'}`;
    if(t)onClick({target:t});
    status()
  };
  ['pointerdown','pointermove','pointerup','pointercancel'].forEach(t=>AEL.call(W,t,function __ptr_h(ev){
    const ui=isUI(ev),[x,y]=xy(ev);
    if(t==='pointerdown'){if(ui){g={x,y,mv:false};const k=grab(ev,x,y);if(k)startDrag(k,x,y)}}
    else if(t==='pointermove'){moveDrag(x,y);if(g&&Math.hypot(x-g.x,y-g.y)>10)g.mv=true}
    else if(t==='pointerup'){
      if(ui){nPU++;const was=drag&&moved;endDrag();tap(ev,x,y,was)}else{endDrag();g=null}
    }
    else{endDrag();g=null}
    if(ui||drag)ev.stopImmediatePropagation()
  },true));
  ['touchstart','touchmove','touchend','touchcancel'].forEach(t=>AEL.call(W,t,function __ptr_h(ev){
    const ui=isUI(ev),[x,y]=xy(ev),has=!!((ev.touches&&ev.touches[0])||(ev.changedTouches&&ev.changedTouches[0]));
    if(t==='touchstart'){if(ui&&has){if(!g)g={x,y,mv:false};const k=grab(ev,x,y);if(k)startDrag(k,x,y)}}
    else if(t==='touchmove'){
      if(g&&has&&Math.hypot(x-g.x,y-g.y)>10)g.mv=true;
      if(drag&&has){moveDrag(x,y);if(ev.cancelable)ev.preventDefault()}
    }
    else if(t==='touchend'){
      if(ui){nTE++;const was=drag&&moved;endDrag();tap(ev,x,y,was)}else{endDrag();g=null}
    }
    else{endDrag();g=null}
    if(ui||drag)ev.stopImmediatePropagation()
  },{capture:true,passive:false}));
  ['mousedown','mouseup','dblclick','auxclick'].forEach(t=>AEL.call(W,t,function __ptr_h(ev){if(isUI(ev))ev.stopImmediatePropagation()},{capture:true,passive:true}));
  AEL.call(W,'click',function __ptr_h(ev){
    if(!isUI(ev))return;
    ev.stopImmediatePropagation();
    try{ev.preventDefault()}catch{}
    nCK++;
    if(Date.now()-tapAt<700)return;
    const[x,y]=xy(ev),t=uiTarget(ev,x,y);
    if(t)onClick({target:t});
    status()
  },true);
  AEL.call(W,'message',function __ptr_h(ev){
    const m=ev.data;
    if(!m||typeof m!=='object'||ev.source===W)return;
    if(m.__ptr===1)add(m.e);
    else if(m.__ptr===2){const e=byId.get(S(m.id));if(e&&Array.isArray(m.pu)){e.pu=m.pu.map(S);sched()}}
  });
  AEL.call(W,'keydown',function __ptr_h(ev){if(ev.altKey&&ev.shiftKey&&ev.code==='KeyP'){ev.preventDefault();toggle()}},true);
  AEL.call(W,'resize',()=>{place();dock()});
  const dump=async e=>{
    let o='// event: '+KN[e.k]+' '+S(e.d.url||'')+'\n// stack:\n'+e.fr.map(f=>'//   '+(f.ins?'(injector) ':'')+flab(f)+(f.u?' '+f.u:'')).join('\n')+'\n';
    for(const n of Object.keys(e.dt||{}))o+='\n// ===== inline-script #'+n+' =====\n'+e.dt[n].x+'\n';
    for(const f of e.fr)if(f.dx)o+='\n// ===== eval code =====\n'+f.dx+'\n';
    const f0=e.fr.find(f=>f.t==='file'&&f.u!==e.pg&&!f.syn);
    if(f0)try{o+='\n// ===== '+f0.u+' =====\n'+await getText(f0.u)+'\n'}catch{}
    return o
  };
  try{
    GM_registerMenuCommand('Toggle Popup Tracer',toggle);
    GM_registerMenuCommand('Popup Tracer: copy newest event scripts',()=>{const e=E[E.length-1];if(e)dump(e).then(t=>GM_setClipboard(t,'text'))});
    GM_registerMenuCommand('Popup Tracer: copy all events JSON',()=>GM_setClipboard(JSON.stringify(E,null,1),'text'))
  }catch{}
}
install(W);
})();
