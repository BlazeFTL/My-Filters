// ==UserScript==
// @name         Universal SetTimeout and Interval Logger 7
// @namespace    https://github.com/BlazeFTL
// @description  Logs setTimeout, setInterval and performance.now with call-site source, callback code and uBlock Origin filter suggestions.
// @version      2.0
// @author       BlazeFTL
// @match        *://*/*
// @run-at       document-start
// @grant        none
// @noframes
// ==/UserScript==

(function () {
    'use strict';

    const PREFS_KEY = '__timer_logger_prefs__';
    const LOGS_KEY = '__timer_logger_logs_v2__';
    const MAX_ENTRIES = 500;
    const SAMPLE_MS = 30;
    const NAMES = { T: 'Timeout', I: 'Interval', P: 'perf.now', N: 'Note' };
    const originalSetTimeout = window.setTimeout;
    const originalSetInterval = window.setInterval;
    const originalNow = typeof Performance === 'function' ? Performance.prototype.now : null;
    const nativeToString = Function.prototype.toString;
    const loadId = Date.now().toString(36);
    const timeFormat = new Intl.DateTimeFormat([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const store = (type) => ({
        get: (k) => { try { return window[type].getItem(k); } catch (e) { return null; } },
        set: (k, v) => { try { window[type].setItem(k, v); return true; } catch (e) { return false; } }
    });
    const local = store('localStorage');
    const session = store('sessionStorage');

    const prefs = Object.assign(
        { on: true, T: true, I: true, P: true, src: true, code: false, min: false, h: 0 },
        (() => { try { return JSON.parse(local.get(PREFS_KEY) || '{}') || {}; } catch (e) { return {}; } })()
    );
    const savePrefs = () => local.set(PREFS_KEY, JSON.stringify(prefs));

    const entries = [];
    const byKey = new Map();
    const byId = new Map();
    const calls = { T: 0, I: 0, P: 0 };
    const dirty = new Set();
    const srcCache = new Map();
    let seq = 0;
    let ui = null;
    let saveTimer = null;
    let flushTimer = null;
    let lastSample = 0;

    try {
        const saved = JSON.parse(session.get(LOGS_KEY) || '[]');
        if (Array.isArray(saved)) saved.forEach((e) => {
            if (!e || typeof e.id !== 'number' || !Array.isArray(e.s)) return;
            entries.push(e);
            byKey.set(e.k, e);
            byId.set(e.id, e);
            if (e.id > seq) seq = e.id;
        });
    } catch (e) {}

    const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const fmt = (n) => (n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'k' : String(n));
    const clock = (ms) => timeFormat.format(ms);

    const parseFrames = (stack) => {
        const out = [];
        String(stack || '').split('\n').forEach((raw) => {
            const line = raw.trim();
            const m = line.match(/^at\s+(?:(.*?)\s+\()?(.*?):(\d+):(\d+)\)?$/) || line.match(/^(.*?)@(.*?):(\d+):(\d+)$/);
            if (m) out.push({ fn: m[1] || '', url: m[2], line: +m[3], col: +m[4] });
        });
        return out;
    };

    const shortLoc = (f, page) => {
        let name = f[1];
        try {
            if (f[1].split('#')[0] === String(page).split('#')[0]) name = 'inline';
            else {
                const u = new URL(f[1]);
                name = u.pathname.split('/').filter(Boolean).pop() || u.hostname;
            }
        } catch (e) {}
        return `${name}:${f[2]}:${f[3]}`;
    };

    const SKIP = new Set(['function', 'return', 'undefined', 'document', 'window', 'length', 'arguments', 'typeof', 'setTimeout', 'setInterval', 'getElementById', 'querySelector', 'console', 'Object', 'Array', 'String', 'Number', 'Math', 'Date', 'throw', 'catch', 'while']);
    const longest = (list) => list.reduce((a, b) => (b.length > a.length ? b : a));
    const pickToken = (fn) => {
        const ids = (fn.match(/[A-Za-z_][A-Za-z0-9_]{5,}/g) || []).filter((t) => !SKIP.has(t));
        if (ids.length) return longest(ids).slice(0, 40);
        const runs = fn.match(/[^\s,"'`\\#\/]{4,}/g) || [];
        return runs.length ? longest(runs).slice(0, 40) : '';
    };

    const filterFor = (e) => {
        if ((e.ty !== 'T' && e.ty !== 'I') || !(e.d > 0)) return '';
        let host = '';
        try { host = new URL(e.h).hostname; } catch (err) { return ''; }
        return `${host}##+js(${e.ty === 'T' ? 'nano-stb' : 'nano-sib'}, ${pickToken(e.f)}, ${Math.round(e.d)})`;
    };

    const entryText = (e) => {
        if (e.ty === 'N') return `--- ${e.f} ---`;
        const f = e.s[0];
        const where = f ? `${f[1]}:${f[2]}:${f[3]}` : 'unknown source';
        const delay = e.ty === 'P' ? '' : ` | ${e.d}ms`;
        const code = e.f ? `\n  fn: ${e.f.replace(/\s+/g, ' ').slice(0, 300)}` : '';
        return `[${clock(e.b)}] ${NAMES[e.ty]}${delay} | x${e.n} | ${where}${code}`;
    };

    const copyText = async (s) => {
        try { await navigator.clipboard.writeText(s); return true; } catch (e) {}
        try {
            const ta = document.createElement('textarea');
            ta.value = s;
            ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
            document.documentElement.appendChild(ta);
            ta.select();
            const ok = document.execCommand('copy');
            ta.remove();
            return ok;
        } catch (e) { return false; }
    };

    const getSource = async (url) => {
        if (srcCache.has(url)) return srcCache.get(url);
        const r = await fetch(url, { cache: 'force-cache' });
        if (!r.ok) throw new Error(String(r.status));
        const t = await r.text();
        srcCache.set(url, t);
        return t;
    };

    const snippet = (text, line, col) => {
        const L = text.split('\n');
        const i = line - 1;
        if (i < 0 || i >= L.length) return esc(`Line ${line} not found in fetched source`);
        const cur = L[i];
        if (cur.length > 300) {
            const c = Math.max(0, col - 1);
            const s = Math.max(0, c - 160);
            return `<div class="l hit"><span class="ln">${line}:${col}</span>${s ? '…' : ''}${esc(cur.slice(s, c))}<mark>${esc(cur.slice(c, c + 40))}</mark>${esc(cur.slice(c + 40, c + 200))}…</div>`;
        }
        let h = '';
        for (let j = Math.max(0, i - 6); j <= Math.min(L.length - 1, i + 6); j++) {
            h += `<div class="l${j === i ? ' hit' : ''}"><span class="ln">${j + 1}</span>${esc(L[j].slice(0, 260))}</div>`;
        }
        return h;
    };

    const saveNow = () => {
        saveTimer = null;
        if (!session.set(LOGS_KEY, JSON.stringify(entries))) session.set(LOGS_KEY, JSON.stringify(entries.slice(0, 120)));
    };
    const scheduleSave = () => { if (!saveTimer) saveTimer = originalSetTimeout(saveNow, 1500); };
    const flush = () => {
        flushTimer = null;
        if (ui) ui.refresh(dirty);
        dirty.clear();
    };
    const scheduleFlush = () => { if (!flushTimer) flushTimer = originalSetTimeout(flush, 250); };

    const addEntry = (e) => {
        entries.unshift(e);
        byKey.set(e.k, e);
        byId.set(e.id, e);
        while (entries.length > MAX_ENTRIES) {
            const old = entries.pop();
            byKey.delete(old.k);
            byId.delete(old.id);
            if (ui) ui.drop(old.id);
        }
        if (ui) ui.add(e);
        scheduleFlush();
        scheduleSave();
    };

    const addNote = (text) => {
        const now = Date.now();
        addEntry({ id: ++seq, k: `N|${seq}`, ty: 'N', d: 0, f: text, s: [], n: 1, a: now, b: now, h: location.href });
    };

    const consoleLog = (e, fn, args) => {
        try {
            const f = e.s[0];
            console.groupCollapsed(`%c[${NAMES[e.ty]}]${e.ty === 'P' ? '' : ' ' + e.d + 'ms'} ${f ? shortLoc(f, e.h) : ''}`, 'color:#4f46e5;font-weight:600');
            if (fn) console.log('Function:', fn);
            if (args && args.length) console.log('Arguments:', args);
            console.log('Stack:\n' + e.s.map((x) => `${x[0] || '(anonymous)'} ${x[1]}:${x[2]}:${x[3]}`).join('\n'));
            console.groupEnd();
        } catch (err) {}
    };

    const record = (ty, delay, callback, args) => {
        if (ty !== 'P') calls[ty]++;
        const now = Date.now();
        const frames = parseFrames(new Error().stack).slice(2, 10);
        const top = frames[0];
        const topKey = top ? `${top.url}:${top.line}:${top.col}` : '';
        let fn = '';
        if (ty !== 'P') {
            try { fn = String(callback); } catch (err) { fn = '[unprintable callback]'; }
        }
        const d = ty === 'P' ? 0 : Number(delay) || 0;
        const key = ty === 'P'
            ? `${loadId}|P|${topKey}`
            : `${loadId}|${ty}|${d}|${topKey}|${fn.length}:${fn.slice(0, 80)}`;
        const found = byKey.get(key);
        if (found) {
            found.n++;
            found.b = now;
            dirty.add(found);
            scheduleFlush();
            scheduleSave();
            return;
        }
        const e = {
            id: ++seq, k: key, ty, d,
            f: fn.slice(0, 1200), c: fn.length > 1200,
            s: frames.map((x) => [x.fn, x.url, x.line, x.col]),
            n: 1, a: now, b: now, h: location.href
        };
        addEntry(e);
        consoleLog(e, fn, args);
    };

    const CSS = `
:host{all:initial}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
[hidden]{display:none!important}
button,input{font-family:inherit;font-size:inherit;color:inherit}
.sheet{position:fixed;left:0;right:0;bottom:0;z-index:2147483647;display:flex;flex-direction:column;background:#fff;color:#1b2333;font:13px/1.45 system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;border-radius:18px 18px 0 0;box-shadow:0 -1px 0 #e6e9f0,0 -14px 36px rgba(27,35,51,.13);overflow:hidden}
.grab{flex:none;display:flex;justify-content:center;padding:9px 0 5px;cursor:ns-resize;touch-action:none}
.grab i{width:38px;height:4px;border-radius:2px;background:#d5d9e3}
.head{flex:none;display:flex;align-items:center;gap:10px;padding:2px 14px 10px}
.title{flex:1;min-width:0}
.title b{display:block;font-size:16px;font-weight:700;letter-spacing:-.01em}
.title small{display:block;color:#6b7488;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sw{flex:none;display:flex;align-items:center;gap:8px;padding:0;border:0;background:none;color:#6b7488;font-size:12px;font-weight:700;cursor:pointer}
.sw[aria-checked=true]{color:#15803d}
.tr{position:relative;width:42px;height:24px;border-radius:12px;background:#d5d9e3;transition:background .2s}
.tr::after{content:'';position:absolute;top:3px;left:3px;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(27,35,51,.3);transition:transform .2s}
.sw[aria-checked=true] .tr{background:#22c55e}
.sw[aria-checked=true] .tr::after{transform:translateX(18px)}
.ib{flex:none;position:relative;width:32px;height:32px;border:0;border-radius:50%;background:#f3f5f9;cursor:pointer}
.ib::before{content:'';position:absolute;left:50%;top:50%;width:8px;height:8px;margin:-6px 0 0 -4px;border-right:2px solid #4b5468;border-bottom:2px solid #4b5468;transform:rotate(45deg)}
.min .ib::before{margin-top:-2px;transform:rotate(-135deg)}
.body{flex:1;min-height:0;display:flex;flex-direction:column}
.min .body{display:none}
.bar{flex:none;display:flex;align-items:center;gap:6px;padding:0 14px 8px;overflow-x:auto;scrollbar-width:none}
.bar::-webkit-scrollbar{display:none}
.chip{flex:none;display:flex;align-items:center;gap:6px;padding:6px 11px;border:1px solid #e6e9f0;border-radius:999px;background:#fff;color:#6b7488;font-size:12px;font-weight:600;white-space:nowrap;cursor:pointer}
.chip b{font-size:11px;font-weight:700;font-variant-numeric:tabular-nums;color:#9aa2b4}
.chip[data-ty=T].on{background:#eef3ff;border-color:#c5d6fb;color:#2458c9}
.chip[data-ty=I].on{background:#f3efff;border-color:#d8ccfb;color:#6a3fd1}
.chip[data-ty=P].on{background:#fff6e5;border-color:#f6d9a0;color:#a86400}
.chip[data-v].on{background:#1b2333;border-color:#1b2333;color:#fff}
.chip.on b{color:inherit;opacity:.7}
.sep{flex:none;width:1px;height:18px;margin:0 2px;background:#e6e9f0}
.tools{flex:none;display:flex;gap:6px;padding:0 14px 10px}
.tools input{flex:1;min-width:0;height:34px;padding:0 12px;border:1px solid transparent;border-radius:10px;background:#f3f5f9;outline:none}
.tools input:focus{background:#fff;border-color:#a5b4fc;box-shadow:0 0 0 3px rgba(99,102,241,.15)}
.btn{flex:none;height:34px;padding:0 12px;border:0;border-radius:10px;background:#f3f5f9;color:#2d3648;font-size:12px;font-weight:700;cursor:pointer}
.btn.p{background:#eef0ff;color:#4338ca}
.btn.d{background:#fdf0f0;color:#c62828}
.list{flex:1;min-height:0;overflow-y:auto;overflow-anchor:none;overscroll-behavior:contain;touch-action:pan-y;border-top:1px solid #eef0f5;background:#fff}
.list:empty::before{content:'Waiting for timers…';display:block;padding:32px 0;color:#9aa2b4;text-align:center}
.row{--c:#cbd5e1;padding:10px 14px 10px 12px;border-bottom:1px solid #eef0f5;border-left:3px solid var(--c)}
.row[data-ty=T]{--c:#2f6fed}
.row[data-ty=I]{--c:#7c4dff}
.row[data-ty=P]{--c:#e08a00}
.row.open{background:#fafbfe}
.row.note{padding:6px 14px;border-left:0;background:#f3f5f9;color:#8a93a6;font-size:11px;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.nm,.hide-T .row[data-ty=T],.hide-I .row[data-ty=I],.hide-P .row[data-ty=P]{display:none}
.top{display:flex;align-items:center;gap:8px;cursor:pointer}
.badge{color:var(--c);font-size:12px;font-weight:700}
.d{font-weight:600;font-variant-numeric:tabular-nums}
.n{padding:0 7px;border-radius:999px;background:#f3f5f9;color:#6b7488;font-size:11px;font-weight:700}
.n:empty{display:none}
.t{margin-left:auto;color:#9aa2b4;font-size:11px;font-variant-numeric:tabular-nums}
.src,.code,pre,.loc{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
.src,.code{display:none;cursor:pointer}
.show-src .src{display:block}
.show-code .code{display:-webkit-box}
.src{margin-top:5px;color:#3454d1;font-size:11px;word-break:break-all}
.code{margin-top:6px;padding:6px 8px;border-radius:8px;background:#f3f5f9;color:#4b5468;font-size:11px;word-break:break-all;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.detail{display:none;margin-top:8px;padding-top:4px;border-top:1px solid #eef0f5}
.open .detail{display:block}
.h{margin:10px 0 4px;color:#6b7488;font-size:12px;font-weight:700}
.frame{display:flex;align-items:center;gap:8px;padding:4px 0}
.tx{flex:1;min-width:0}
.fn{color:#1b2333;font-size:12px;font-weight:600;word-break:break-all}
.loc{color:#6b7488;font-size:10.5px;word-break:break-all}
.mini{flex:none;padding:5px 11px;border:0;border-radius:8px;background:#eef0ff;color:#4338ca;font-size:11px;font-weight:700;cursor:pointer}
pre{margin:4px 0 6px;padding:8px 10px;max-height:220px;overflow:auto;border:1px solid #e6e9f0;border-radius:10px;background:#f8f9fc;color:#2d3648;font-size:10.5px;line-height:1.5;white-space:pre;user-select:text;-webkit-user-select:text}
.l{min-width:max-content}
.hit{background:#fff3bf}
mark{background:#ffd43b;color:inherit}
.ln{display:inline-block;min-width:34px;margin-right:8px;color:#9aa2b4;text-align:right;user-select:none;-webkit-user-select:none}
.acts{display:flex;gap:6px;margin-top:10px}
.hint{margin-top:8px;color:#9aa2b4;font-size:11px}
`;

    const buildUI = () => {
        const host = document.createElement('div');
        host.id = 'timer-logger-host';
        host.style.cssText = 'all:initial';
        const root = host.attachShadow({ mode: 'open' });
        root.innerHTML = `<style>${CSS}</style>
<div class="sheet">
  <div class="grab"><i></i></div>
  <div class="head">
    <div class="title"><b>Timer Logger</b><small class="sub"></small></div>
    <button class="sw" role="switch" aria-label="Logging"><span class="sl"></span><span class="tr"></span></button>
    <button class="ib" aria-label="Collapse"></button>
  </div>
  <div class="body">
    <div class="bar">
      <button class="chip" data-ty="T">Timeout<b>0</b></button>
      <button class="chip" data-ty="I">Interval<b>0</b></button>
      <button class="chip" data-ty="P">perf.now<b>0</b></button>
      <span class="sep"></span>
      <button class="chip" data-v="src">Source</button>
      <button class="chip" data-v="code">Code</button>
    </div>
    <div class="tools">
      <input type="search" placeholder="Filter by code or file">
      <button class="btn" data-a="copy">Copy</button>
      <button class="btn p" data-a="ubo">uBO</button>
      <button class="btn d" data-a="clear">Clear</button>
    </div>
    <div class="list"></div>
  </div>
</div>`;

        const padStyle = document.createElement('style');
        const $ = (s) => root.querySelector(s);
        const sheet = $('.sheet');
        const grab = $('.grab');
        const list = $('.list');
        const input = $('input');
        const sw = $('.sw');
        const sub = $('.sub');
        const rows = new Map();
        const chipCount = {};
        root.querySelectorAll('.chip[data-ty]').forEach((c) => { chipCount[c.dataset.ty] = c.querySelector('b'); });

        const clamp = (h) => Math.max(160, Math.min(h, Math.round(window.innerHeight * 0.88)));
        let height = clamp(prefs.h || Math.round(window.innerHeight * 0.45));

        const matches = (e) => {
            const q = input.value.trim().toLowerCase();
            if (!q) return true;
            const hay = `${NAMES[e.ty]} ${e.d}ms ${e.f} ${e.s.map((x) => x[0] + ' ' + x[1]).join(' ')}`.toLowerCase();
            return hay.includes(q);
        };
        const visibleEntries = () => entries.filter((e) => (e.ty === 'N' || prefs[e.ty]) && matches(e));

        const applyPrefs = () => {
            sheet.classList.toggle('min', !!prefs.min);
            sheet.style.height = prefs.min ? '' : height + 'px';
            list.classList.toggle('show-src', !!prefs.src);
            list.classList.toggle('show-code', !!prefs.code);
            ['T', 'I', 'P'].forEach((t) => list.classList.toggle('hide-' + t, !prefs[t]));
            root.querySelectorAll('.chip[data-ty]').forEach((c) => c.classList.toggle('on', !!prefs[c.dataset.ty]));
            root.querySelectorAll('.chip[data-v]').forEach((c) => c.classList.toggle('on', !!prefs[c.dataset.v]));
            sw.setAttribute('aria-checked', prefs.on ? 'true' : 'false');
            sw.querySelector('.sl').textContent = prefs.on ? 'On' : 'Off';
        };

        const counters = () => {
            chipCount.T.textContent = fmt(calls.T);
            chipCount.I.textContent = fmt(calls.I);
            chipCount.P.textContent = fmt(calls.P);
            sub.textContent = `${fmt(calls.T + calls.I + calls.P)} calls on this page, ${entries.length} logged`;
        };

        const rowHtml = (e) => {
            if (e.ty === 'N') return esc(e.f);
            const f = e.s[0];
            return `<div class="top"><span class="badge">${NAMES[e.ty]}</span>${e.ty === 'P' ? '' : `<span class="d">${e.d}ms</span>`}<span class="n"></span><span class="t"></span></div>`
                + `<div class="src">${f ? esc(shortLoc(f, e.h)) : 'source unknown'}</div>`
                + (e.f ? `<div class="code">${esc(e.f.replace(/\s+/g, ' ').slice(0, 300))}</div>` : '')
                + '<div class="detail"></div>';
        };

        const detailHtml = (e) => {
            let h = '';
            if (e.s.length) {
                h += '<div class="h">Call site</div>';
                e.s.forEach((f, i) => {
                    h += `<div class="frame"><div class="tx"><div class="fn">${esc(f[0] || '(anonymous)')}</div><div class="loc">${esc(f[1])}:${f[2]}:${f[3]}</div></div><button class="mini" data-act="view" data-i="${i}">View</button></div><pre class="view" hidden></pre>`;
                });
            }
            if (e.f) h += `<div class="h">Callback code</div><pre>${esc(e.f)}${e.c ? '\n…' : ''}</pre>`;
            const flt = filterFor(e);
            if (flt) h += `<div class="h">uBlock Origin filter</div><pre>${esc(flt)}</pre>`;
            h += `<div class="acts"><button class="mini" data-act="copy">Copy entry</button>${flt ? '<button class="mini" data-act="copyflt">Copy filter</button>' : ''}</div>`;
            if (e.ty === 'P') h += `<div class="hint">perf.now is sampled, about one capture per ${SAMPLE_MS} ms.</div>`;
            return h;
        };

        const refreshRow = (e, row) => {
            if (e.ty === 'N') return;
            row.querySelector('.n').textContent = e.n > 1 ? '×' + fmt(e.n) : '';
            row.querySelector('.t').textContent = clock(e.b);
        };

        const makeRow = (e) => {
            const row = document.createElement('div');
            row.className = e.ty === 'N' ? 'row note' : 'row';
            row.dataset.id = e.id;
            row.dataset.ty = e.ty;
            row.innerHTML = rowHtml(e);
            rows.set(e.id, row);
            refreshRow(e, row);
            return row;
        };

        const flash = (b, text) => {
            if (!b.dataset.o) b.dataset.o = b.textContent;
            b.textContent = text;
            originalSetTimeout(() => { b.textContent = b.dataset.o; }, 1200);
        };

        const handleAct = async (b, e) => {
            const a = b.dataset.act;
            if (a === 'copy') flash(b, (await copyText(entryText(e))) ? 'Copied' : 'Failed');
            else if (a === 'copyflt') flash(b, (await copyText(filterFor(e))) ? 'Copied' : 'Failed');
            else if (a === 'view') {
                const pre = b.parentNode.nextElementSibling;
                if (!pre.hidden) { pre.hidden = true; b.textContent = 'View'; return; }
                const f = e.s[+b.dataset.i];
                pre.hidden = false;
                pre.textContent = 'Loading…';
                b.textContent = 'Hide';
                try { pre.innerHTML = snippet(await getSource(f[1]), f[2], f[3]); }
                catch (err) { pre.textContent = 'Source unavailable (blocked, cross-origin or not fetchable).'; }
            }
        };

        list.addEventListener('click', (ev) => {
            const row = ev.target.closest('.row');
            if (!row || row.classList.contains('note')) return;
            const e = byId.get(+row.dataset.id);
            if (!e) return;
            const act = ev.target.closest('[data-act]');
            if (act) { handleAct(act, e); return; }
            if (ev.target.closest('.top,.src,.code')) {
                const open = row.classList.toggle('open');
                const d = row.querySelector('.detail');
                if (open && !d.dataset.ready) { d.innerHTML = detailHtml(e); d.dataset.ready = '1'; }
            }
        });

        let drag = false;
        let y0 = 0;
        let h0 = 0;
        grab.addEventListener('pointerdown', (ev) => {
            if (prefs.min) return;
            drag = true;
            y0 = ev.clientY;
            h0 = sheet.offsetHeight;
            try { grab.setPointerCapture(ev.pointerId); } catch (err) {}
            ev.preventDefault();
        });
        grab.addEventListener('pointermove', (ev) => {
            if (!drag) return;
            height = clamp(h0 + y0 - ev.clientY);
            sheet.style.height = height + 'px';
        });
        const endDrag = () => {
            if (!drag) return;
            drag = false;
            prefs.h = height;
            savePrefs();
        };
        grab.addEventListener('pointerup', endDrag);
        grab.addEventListener('pointercancel', endDrag);
        window.addEventListener('resize', () => { height = clamp(height); applyPrefs(); });

        new ResizeObserver(() => {
            padStyle.textContent = `html{padding-bottom:${sheet.offsetHeight}px!important}`;
        }).observe(sheet);

        sw.onclick = () => {
            prefs.on = !prefs.on;
            savePrefs();
            if (prefs.on) addNote('Logging resumed · ' + location.href);
            applyPrefs();
        };
        $('.ib').onclick = () => { prefs.min = !prefs.min; savePrefs(); applyPrefs(); };
        root.querySelectorAll('.chip[data-ty]').forEach((c) => { c.onclick = () => { prefs[c.dataset.ty] = !prefs[c.dataset.ty]; savePrefs(); applyPrefs(); }; });
        root.querySelectorAll('.chip[data-v]').forEach((c) => { c.onclick = () => { prefs[c.dataset.v] = !prefs[c.dataset.v]; savePrefs(); applyPrefs(); }; });
        input.addEventListener('input', () => {
            entries.forEach((e) => {
                const r = rows.get(e.id);
                if (r) r.classList.toggle('nm', !matches(e));
            });
        });

        const copyBtn = $('[data-a=copy]');
        const uboBtn = $('[data-a=ubo]');
        copyBtn.onclick = async () => flash(copyBtn, (await copyText(visibleEntries().map(entryText).join('\n'))) ? 'Copied' : 'Failed');
        uboBtn.onclick = async () => {
            const lines = [...new Set(visibleEntries().map(filterFor).filter(Boolean))];
            flash(uboBtn, lines.length ? ((await copyText(lines.join('\n'))) ? `Copied ${lines.length}` : 'Failed') : 'None');
        };
        $('[data-a=clear]').onclick = () => {
            entries.length = 0;
            byKey.clear();
            byId.clear();
            rows.clear();
            dirty.clear();
            list.textContent = '';
            calls.T = calls.I = calls.P = 0;
            saveNow();
            counters();
        };

        return {
            host,
            padStyle,
            init() {
                entries.forEach((e) => list.appendChild(makeRow(e)));
                applyPrefs();
                counters();
            },
            add(e) {
                const row = makeRow(e);
                const y = list.scrollTop;
                list.insertBefore(row, list.firstChild);
                if (!matches(e)) row.classList.add('nm');
                const hgt = row.offsetHeight;
                if (y > 0 && hgt) list.scrollTop = y + hgt;
            },
            drop(id) {
                const r = rows.get(id);
                if (r) r.remove();
                rows.delete(id);
            },
            refresh(set) {
                set.forEach((e) => {
                    const r = rows.get(e.id);
                    if (r) refreshRow(e, r);
                });
                counters();
            }
        };
    };

    const mount = () => {
        if (ui) return;
        ui = buildUI();
        document.documentElement.append(ui.host, ui.padStyle);
        ui.init();
    };

    window.addEventListener('pagehide', saveNow);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') saveNow();
    });

    if (prefs.on) addNote('Page loaded · ' + location.href);

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
    else mount();

    const disguise = (wrapper, original) => {
        try {
            Object.defineProperty(wrapper, 'toString', { value: () => nativeToString.call(original), configurable: true, writable: true });
            Object.defineProperty(wrapper, 'name', { value: original.name, configurable: true });
        } catch (e) {}
        return wrapper;
    };

    window.setTimeout = disguise(function (callback, delay, ...args) {
        if (prefs.on && prefs.T) { try { record('T', delay, callback, args); } catch (e) {} }
        return originalSetTimeout.call(this, callback, delay, ...args);
    }, originalSetTimeout);

    window.setInterval = disguise(function (callback, delay, ...args) {
        if (prefs.on && prefs.I) { try { record('I', delay, callback, args); } catch (e) {} }
        return originalSetInterval.call(this, callback, delay, ...args);
    }, originalSetInterval);

    if (originalNow) {
        try {
            Object.defineProperty(Performance.prototype, 'now', {
                value: disguise(function () {
                    const v = originalNow.call(this);
                    if (prefs.on && prefs.P) {
                        calls.P++;
                        if (v - lastSample >= SAMPLE_MS) {
                            lastSample = v;
                            try { record('P', 0, null, []); } catch (e) {}
                        }
                    }
                    return v;
                }, originalNow),
                writable: true,
                configurable: true,
                enumerable: true
            });
        } catch (e) {}
    }
})();
