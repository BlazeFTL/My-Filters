// ==UserScript==
// @name         DODI Collapsible Lists
// @namespace    ftl.dodi-collapse
// @version      1.0.0
// @description  Collapses pinned post sections on dodi-repacks.site by default
// @match        https://dodi-repacks.site/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(() => {
  'use strict';
  document.querySelectorAll('article.sticky .entry-content').forEach(root => {
    let fold = null;
    for (const el of [...root.children]) {
      if (el.tagName === 'H1') {
        fold = document.createElement('details');
        fold.className = 'dd-fold';
        const summary = document.createElement('summary');
        el.replaceWith(fold);
        summary.append(el);
        fold.append(summary);
      } else if (!fold) {
        continue;
      } else if (el.tagName === 'HR') {
        el.remove();
      } else {
        fold.append(el);
      }
    }
    root.querySelectorAll('.dd-fold').forEach(f => {
      const n = f.querySelectorAll('li').length;
      if (!n) return;
      const badge = document.createElement('span');
      badge.className = 'dd-count';
      badge.textContent = n;
      f.querySelector('summary').append(badge);
    });
  });
})();
