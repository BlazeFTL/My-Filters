// ==UserScript==
// @name         Countdown Auto Clicker
// @namespace    ftl.countdown-autoclick
// @version      1.1
// @description  Click #btn6/#btn7 after .countdown ends; click #startCountdownBtn when shown, then #cross-snp2 after countdown ends
// @match        *://*/*
// @run-at       document-idle
// @noframes
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const POLL = 300;
  const GRACE = 5000;

  const $ = s => document.querySelector(s);
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  const visible = el => {
    if (!el || el.getClientRects().length === 0) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none';
  };

  const waitFor = async sel => {
    for (;;) {
      const el = $(sel);
      if (visible(el) && !el.disabled) return el;
      await sleep(POLL);
    }
  };

  const clickEl = async sel => {
    const el = await waitFor(sel);
    el.click();
    await sleep(POLL);
  };

  const isActive = el => {
    if (!visible(el)) return false;
    const nums = (el.textContent || '').match(/\d+/g);
    return !!nums && nums.some(n => parseInt(n, 10) > 0);
  };

  const waitCountdownDone = async () => {
    const start = Date.now();
    let seen = false;
    for (;;) {
      const el = $('.countdown');
      if (el && isActive(el)) seen = true;
      else if (seen) return;
      else if (Date.now() - start > GRACE) return;
      await sleep(POLL);
    }
  };

  const taskButtons = async () => {
    await waitCountdownDone();
    await clickEl('#btn6');
    await clickEl('#btn7');
  };

  const taskStart = async () => {
    await clickEl('#startCountdownBtn');
    await sleep(500);
    await waitCountdownDone();
    await clickEl('#cross-snp2');
  };

  taskButtons();
  taskStart();
})();
