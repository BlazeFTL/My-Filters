// ==UserScript==
// @name         Pahe Plus Adblock Hook 2
// @namespace    https://github.com/BlazeFTL
// @description  Bypasses adblock detection for pahe.plus by mocking fetch and resource performance entries.
// @version      1.1
// @author       BlazeFTL
// @match        *://*/*
// @license      MIT
// ==/UserScript==

(function() {
    'use strict';
    const H=/^https:\/\/(?:pagead2\.googlesyndication\.com\/pagead\/show_ads\.js|(?:securepubads\.g\.doubleclick\.net|www\.googletagservices\.com)\/tag\/js\/gpt\.js|s\.amazon-adsystem\.com\/aax2\/apstag\.js|www\.googleadservices\.com\/pagead\/conversion_async\.js)(?:[?#]|$)/,p=performance,m=new Map,st=setTimeout;
    p.getEntriesByName=new Proxy(p.getEntriesByName,{apply(f,t,a){const e=m.get(String(a[0]));return e&&(a[1]===undefined||a[1]==="resource")?[Object.assign({},e)]:Reflect.apply(f,t,a)}});
    window.fetch=new Proxy(window.fetch,{apply(f,t,a){const i=a[0],o=a[1]||{};let u,b=false;try{u=new URL(i&&i.url||String(i),location.href);b=H.test(u.href)&&String(o.method||i&&i.method||"GET").toUpperCase()==="GET"&&(o.mode||i&&i.mode)==="no-cors"}catch(e){}if(!b)return Reflect.apply(f,t,a);const s=p.now(),v=Object.assign({},o,{mode:"no-cors",credentials:"omit",cache:"no-store",signal:o.signal||i&&i.signal});return Reflect.apply(f,t,["https://www.gstatic.com/generate_204",v]).then(r=>new Promise((ok,no)=>st(()=>{if(v.signal&&v.signal.aborted)return no(v.signal.reason||new DOMException("Aborted","AbortError"));if(r.type!=="opaque")return no(new TypeError("Expected opaque response"));const e=p.now();if(u.pathname==="/tag/js/gpt.js")m.set(u.href,{name:u.href,entryType:"resource",initiatorType:"fetch",startTime:s,duration:e-s,fetchStart:s,responseStart:e-1,responseEnd:e,transferSize:33068,encodedBodySize:32768,decodedBodySize:32768});ok(r)},Math.max(0,80-(p.now()-s)))))}});
})();
