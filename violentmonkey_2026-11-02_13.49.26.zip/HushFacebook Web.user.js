// ==UserScript==
// @name        HushFacebook Web
// @namespace   https://github.com/SysAdminDoc/HushFacebookWeb
// @version     0.0.6
// @description Takes ads, suggested posts and Meta AI out of Facebook on the web, and adds download, privacy and playback controls.
// @author      SysAdminDoc
// @license     MIT
// @icon        data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAHSElEQVR4nNRaCWxURRj+5r3dlhaWLWjpwRlAMMghhwoCIeEw0eARi1diAjGKSAIGE4khmoI2xBBjDUY80IgxliNqPIIgYCDRxirUcFqIKdgWWtpC2y3tdne7+8Z/Xnf3HbvvvV1sgX5Jd2bezD/z/zP//88/M5XQzyGhn8Pl2GIjdxV2dxWBYS5n0jhwnk15gNNfX6SAnzFWjYhSXu/O+gYbWRg2YHaVha93FVPP68CYN/6Rm6j6sMw493Gw0vqSrE1AGgLkbbg2WZLkHZSd2WcznV5aqSiRFY2bPacdBRDMy5J8gHMUMKrluo5uZplxNER45AGzEAk2IEHawTkvEB0I2p6fnvRmlsWECt4oO8vIrw6FG4TOk9rEF+YWSxmbmb+hsxg6aCpE3iY/2HmFcl7LNTWnN6Geg/saMwfeHvNOcRXKC3SQq5S82hoyLRstD86SMGKIC5kupq9Ae0BBdVM3jEikz/XIKr0ZzR0RXGwJO9JHf72C10Zgt0EAxqS5ccVj3Dgh0Z4EA0KIoqncNJiEyhoZv50nRlqt6VXh3SyBPqJIOFYj4evjEdvxtYURvJoEIIyL58z86TApD1g2LfH7smkulO5rxdYKjy29YD6RnuGp6W7U1jbgz6vDbOnNvMaNmCtKNldIw7juz1QW+mjXd3fdcfgrPrehhy0CZ/Yh+M9hS3qtrGTHaJxDiVsQjGs2aBQgrm8WXiFVWPaTCi135EPHf7IVcPLJqeJ66VPdG3oQF0Ah/XIaQnXJThOpmkoaq5VAzh3pma5aSsj0M2grwKP7HIyLZCw7z6zYPAe47Ogd1lldZW5J0aMEVkacpPt0Nd9DG930sQNhz2HqSMaPvgdNAK5EJePWzR3GfvrhmVgw5y54cq0b5g6CA/Q2YMWP9s1iH3AQxAKjCobSH7D+uxDCEWOdSwa2PJaB1JD6+HEBaAFIf2ONtDQWA6aK6isKdh5Nfox9cZ4L4253cBcGGzCPr4uJzAJY6Xq6NiAY/PuNLJg9oTBuz4B0e3MeX1sBOMcqqfj3mhYFi7cGEeg2th1AUeihtZkYPdR+BXgq4+iqez0WGp7DsHCiRCGy8bss9dT1NnReKJYIX2Q4AenKuoZWHUoMHz+TieuGKRay5scsQBTMlEtnzmobWlBX32bbZmRhjuqtnJF8fHNZswFuNcOp7wO7fqzElu2HbNusf2Ex1q9cYtvGaAPmvJEJm2jUqmwPKWc0MqY/m7Tunjs8GHsv0kQiP/ovmgDC6JhTLIQU9jNuE8uIuuQT4vNzNMtjyNeOQCTYTfcLxKhEli+xBH7A+zAWcuovGUp/9uPdfV2YNv4+LBnjpv0CdDnAcbgqhKZ2ksEtqQIl608XjSopnAdS2JHTPA+s+bIDJ+u6UbZ6MOZPcOPguQgYhSGrF0vIzhiEDw758db3fhJC1gmRJBaSEA1TOdeJmaScFsz0RoiZF8x/u9aLqkaOh7YF0OIHJuRLKP4piPvHuVCyNAsFOTJWf3ENcoYbPfcqWh/xbVHdd2K3DjFjV8tcp9bOM2tPr0HovFCbkmWDsL8qgncOhjB7DN053S3jtUUu5A2W4aHtpGh7AI/PysTyeQOgUIQoulGSnch0c2Yqa7rn67B9a3CkD4S07XnviSCmjZJVtfmKgr+J+TIqLiiqYHv+iqgCn6eLzuxMhs9+D5MAWeq1irl/TQDO/Ya7lyTp5ZYgztZ0wg6xWCYZ/bm6TlxqDqrtzlyMYCYZ7CV6wsgbxPDSfBcKKdR4fq4LK2bLeGSqjBkjGd5cmoG9J8OYNFzGkIGk/SJGIV5j4+m8ED3rpKAiR86GsG4XQ0F7eUKd2MSYd5QlrViBsooQLtQ149QFPx6cM0Kd8do2jm2/hlF1WVFTgXr61hkib0QCtnX18DWQVsMX4FFeTQIwrpRT1RqDzXGTDUbLu/8IIFLbBcVXZ3D0gnkpd7Km8Enoa6+GKeQIQ7nmw5Q7h2PMbQxeYuzVxW50hbiaCvxwKqKq35RCqN+F3je0kWpRXC4Rr3G+49ND1+tDGq+Q1nGvGrzHOFM56P2yUKthdLw8UTIUK8uCuNoBdXYLvUw9N5xuUKieoZ5WYPOjbnR2RvDcp+2QZMnXmpcbv17XbIA+UJ+lzveSvVMWgjQSc8LPv/9EBoXbHNNHSup54W06eo7IAYaSgE/OkLFgvIxtv/jVXZloS/UvlwkeOmdV0zGorzTRWq7XkV4ui6JCer/co7rK946EsedoSF2tfK+Mlxe6VeZfKevAzooACSBVtn04zPDElCDAkFWXJ3PODlC2oA81yFAWP8LPC1cpvI2A0Pn9J0PqzFf+GxabbJPE+KLWj/JP2woQFwLYQdU35pk1KonIClcpvI0wWPVUR9LSw3clg7LCzLylADHkrGws5uKhW303uwGIv4nFP5CVoLT9k7xNliRwAnknb0NjETWcy3teRrITJlDXWdIJTq/eT2k1peW+grz/968G/QH9/r9V/gMAAP//pYGH9gAAAAZJREFUAwAvw2lxTudtWwAAAABJRU5ErkJggg==
// @homepageURL https://github.com/SysAdminDoc/HushFacebookWeb
// @supportURL  https://github.com/SysAdminDoc/HushFacebookWeb/issues
// @updateURL   https://github.com/SysAdminDoc/HushFacebookWeb/releases/latest/download/hushfacebook-web.meta.js
// @downloadURL https://github.com/SysAdminDoc/HushFacebookWeb/releases/latest/download/hushfacebook-web.user.js
// @match       https://www.facebook.com/*
// @match       https://web.facebook.com/*
// @match       https://*.apps.fbsbx.com/*
// @run-at      document-start
// @sandbox     raw
// @inject-into auto
// @grant       GM_getValue
// @grant       GM_setValue
// @grant       GM_deleteValue
// @grant       GM_addValueChangeListener
// @grant       GM_registerMenuCommand
// @grant       GM_download
// @grant       GM_xmlhttpRequest
// @grant       unsafeWindow
// @connect     fbcdn.net
// @connect     facebook.com
// ==/UserScript==

(() => {
  // src/core/bridge.js
  var HELLO_MAIN = "hushfacebook-web:hello-main";
  var HELLO_ISOLATED = "hushfacebook-web:hello-isolated";
  var STORAGE_REVISIONS_KEY = "hushfacebookWeb.storageRevisions";
  var STORAGE_REVISION_EPOCH_KEY = "__epoch";
  var STORAGE_REVISION_ORDER_KEY = "__order";
  var validStorageRevisions = (value) => {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const epoch = value[STORAGE_REVISION_EPOCH_KEY];
    const order = value[STORAGE_REVISION_ORDER_KEY];
    if (typeof epoch !== "string" || !epoch || !Number.isSafeInteger(order) || order < 0) return false;
    return Object.entries(value).every(([key, revision]) => key === STORAGE_REVISION_EPOCH_KEY ? typeof revision === "string" && revision.length > 0 : key === STORAGE_REVISION_ORDER_KEY ? Number.isSafeInteger(revision) && revision >= 0 : Number.isSafeInteger(revision) && revision >= 0 && revision <= order);
  };
  var storageRevisionEpoch = (value) => validStorageRevisions(value) && typeof value[STORAGE_REVISION_EPOCH_KEY] === "string" ? value[STORAGE_REVISION_EPOCH_KEY] : null;
  var channelNames = (secret) => ({ toIsolated: `hushfacebook-web:${secret}:in`, toMain: `hushfacebook-web:${secret}:out` });
  var TIMEOUT = 15e3;
  var BRIDGE_MAX_PENDING = 64;
  var BRIDGE_MAX_MESSAGE_BYTES = 1536 * 1024;
  var BRIDGE_MAX_VALUE_BYTES = 1024 * 1024;
  var DOWNLOAD_ANSWER_WITHIN = 6e4;
  var { stringify } = JSON;
  var Encoder = TextEncoder;
  var serializedBytes = (text) => {
    if (text.length > BRIDGE_MAX_MESSAGE_BYTES) return BRIDGE_MAX_MESSAGE_BYTES + 1;
    return new Encoder().encode(text).byteLength;
  };
  function connectBridge({
    doc = globalThis.document,
    win = globalThis,
    secret = win.crypto.randomUUID(),
    maxPending = BRIDGE_MAX_PENDING,
    maxMessageBytes = BRIDGE_MAX_MESSAGE_BYTES
  } = {}) {
    const { toIsolated, toMain } = channelNames(secret);
    const Custom = win.CustomEvent;
    const dispatch = win.EventTarget.prototype.dispatchEvent;
    const listen = win.EventTarget.prototype.addEventListener;
    const parse4 = win.JSON.parse;
    const pending = /* @__PURE__ */ new Map();
    const pushes = /* @__PURE__ */ new Map();
    let nextId = 0;
    let ready = false;
    const say = (type, detail) => dispatch.call(doc, new Custom(type, { detail }));
    const send = (waiting) => {
      if (waiting.sent) return;
      waiting.sent = true;
      try {
        say(toIsolated, waiting.message);
      } catch (error) {
        pending.delete(waiting.id);
        clearTimeout(waiting.timer);
        waiting.reject(error);
      }
    };
    listen.call(doc, toMain, (event) => {
      let message;
      try {
        message = parse4(event.detail);
      } catch {
        return;
      }
      if (message?.ready) {
        if (ready) return;
        ready = true;
        for (const waiting of pending.values()) send(waiting);
        return;
      }
      if (message?.id !== void 0) {
        const waiting = pending.get(message.id);
        if (!waiting) return;
        pending.delete(message.id);
        clearTimeout(waiting.timer);
        if (message.ok) waiting.resolve(message.result);
        else waiting.reject(new Error(message.error || "the extension could not do it"));
        return;
      }
      for (const listener of pushes.get(message?.push) ?? []) {
        try {
          listener(message.data, message.meta);
        } catch {
        }
      }
    });
    listen.call(doc, HELLO_ISOLATED, () => {
      if (!ready) say(HELLO_MAIN, secret);
    });
    say(HELLO_MAIN, secret);
    return {
      connected: () => ready,
      // Resolves with the isolated half's answer, or rejects with its error.
      request(type, payload, { timeout = TIMEOUT } = {}) {
        if (pending.size >= maxPending) return Promise.reject(new Error("too many extension requests are waiting"));
        const id = nextId++;
        let message;
        try {
          message = stringify({ id, type, payload });
        } catch {
          return Promise.reject(new Error("the extension request could not be encoded"));
        }
        if (message.length > maxMessageBytes || serializedBytes(message) > maxMessageBytes) {
          return Promise.reject(new Error("the extension request is too large"));
        }
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            pending.delete(id);
            reject(new Error("the extension did not answer"));
          }, timeout);
          const waiting = { id, resolve, reject, timer, sent: false, message };
          pending.set(id, waiting);
          if (ready) send(waiting);
        });
      },
      // Messages the extension sends on its own: 'storage' (changes from other tabs), 'open-settings'.
      on(push, listener) {
        pushes.set(push, [...pushes.get(push) ?? [], listener]);
        return () => pushes.set(push, (pushes.get(push) ?? []).filter((entry) => entry !== listener));
      }
    };
  }
  function createBridgeStorage(bridge, { log } = {}) {
    const data = /* @__PURE__ */ new Map();
    const pageLoadData = /* @__PURE__ */ new Map();
    const written = /* @__PURE__ */ new Set();
    const queuedWrites = /* @__PURE__ */ new Map();
    const remoteChanges = /* @__PURE__ */ new Map();
    const keyVersions = /* @__PURE__ */ new Map();
    const acceptedRevisions = /* @__PURE__ */ new Map();
    const appliedRevisions = /* @__PURE__ */ new Map();
    const retiredStorageEpochs = /* @__PURE__ */ new Set();
    const latestMutation = /* @__PURE__ */ new Map();
    const listeners = /* @__PURE__ */ new Map();
    const statusListeners = /* @__PURE__ */ new Set();
    const waiting = [];
    let loaded = false;
    let finishing = false;
    let revision = 0;
    let state = "loading";
    let lastError = null;
    let loadPromise = null;
    let nextMutation = 0;
    let revisionEpoch = 0;
    let storageEpoch = null;
    let loadPending = false;
    let storageFailureRevision = 0;
    const copy = (value) => value === void 0 ? void 0 : structuredClone(value);
    const same = (a, b) => stringify(a) === stringify(b);
    const tell = (key, value, source = "remote") => {
      for (const listener of listeners.get(key) ?? []) {
        try {
          listener(copy(value), { source });
        } catch (error) {
          log?.error("A storage listener failed", error);
        }
      }
    };
    const status = () => ({ state, error: lastError });
    const tellStatus = (listener) => {
      try {
        listener(status());
      } catch (error) {
        log?.error("A storage status listener failed", error);
      }
    };
    const setStatus = (next, error = null) => {
      state = next;
      lastError = error;
      for (const listener of statusListeners) tellStatus(listener);
    };
    const finish = () => {
      loaded = true;
      finishing = true;
      for (const run of waiting.splice(0)) {
        try {
          run();
        } catch (error) {
          log?.error("A storage ready listener failed", error);
        }
      }
      finishing = false;
      for (const { type, payload } of queuedWrites.values()) save(type, payload);
      queuedWrites.clear();
      written.clear();
      setStatus("ready");
    };
    const load = () => {
      if (state === "ready") return Promise.resolve(true);
      if (loadPromise && loadPending) return loadPromise;
      const recovering = loaded && state === "error";
      const startedAt = revision;
      const startedEpoch = revisionEpoch;
      const startedFailureRevision = storageFailureRevision;
      loadPending = true;
      setStatus("loading");
      loadPromise = bridge.request("storage:load").then((saved) => {
        if (storageFailureRevision !== startedFailureRevision) return false;
        const stored = { ...saved ?? {} };
        const savedRevisions = stored[STORAGE_REVISIONS_KEY];
        const savedRevisionsValid = validStorageRevisions(savedRevisions);
        const savedStorageEpoch = storageRevisionEpoch(savedRevisions);
        const uncontested = revisionEpoch === startedEpoch && revision === startedAt;
        delete stored[STORAGE_REVISIONS_KEY];
        if (uncontested && recovering && savedRevisionsValid && savedStorageEpoch) {
          if (storageEpoch && storageEpoch !== savedStorageEpoch) retiredStorageEpochs.add(storageEpoch);
          retiredStorageEpochs.delete(savedStorageEpoch);
          acceptedRevisions.clear();
          appliedRevisions.clear();
          revisionEpoch++;
          storageEpoch = savedStorageEpoch;
        }
        if (uncontested && savedRevisionsValid && (!storageEpoch || !savedStorageEpoch || storageEpoch === savedStorageEpoch)) {
          if (savedStorageEpoch) storageEpoch = savedStorageEpoch;
          for (const [key, value] of Object.entries(savedRevisions)) {
            if (key === STORAGE_REVISION_EPOCH_KEY || key === STORAGE_REVISION_ORDER_KEY) continue;
            if (Number.isSafeInteger(value) && value >= 0) {
              acceptedRevisions.set(key, Math.max(acceptedRevisions.get(key) ?? 0, value));
            }
          }
        }
        const snapshot = new Map(Object.entries(stored));
        const savedRevisionFor = (key) => savedRevisionsValid && Number.isSafeInteger(savedRevisions[key]) ? savedRevisions[key] : null;
        const newerRemote = (key) => {
          const change = remoteChanges.get(key);
          if (!change || change.revision <= startedAt || change.epoch !== revisionEpoch) return false;
          if (revisionEpoch !== startedEpoch) return true;
          const savedRevision = savedRevisionFor(key);
          if (Number.isSafeInteger(change.storageRevision)) {
            return savedRevision === null || change.storageRevision > savedRevision;
          }
          if (Number.isSafeInteger(change.barrier) && savedRevision !== null) return change.barrier >= savedRevision;
          return true;
        };
        pageLoadData.clear();
        for (const [key, value] of snapshot) pageLoadData.set(key, copy(value));
        for (const [key, change] of remoteChanges) {
          if (newerRemote(key)) pageLoadData.set(key, copy(change.value));
        }
        for (const key of data.keys()) {
          if (snapshot.has(key) || written.has(key) || newerRemote(key)) continue;
          data.delete(key);
          tell(key, void 0, "load");
        }
        for (const [key, value] of snapshot) {
          if (written.has(key) || newerRemote(key) || same(data.get(key), value)) continue;
          data.set(key, copy(value));
          tell(key, value, "load");
        }
        if (savedRevisionsValid && savedStorageEpoch === storageEpoch) {
          for (const key of snapshot.keys()) {
            if (written.has(key) || newerRemote(key)) continue;
            const savedRevision = savedRevisionFor(key);
            if (savedRevision !== null) appliedRevisions.set(key, savedRevision);
          }
        } else if (revisionEpoch !== startedEpoch) {
          for (const key of snapshot.keys()) {
            if (written.has(key) || newerRemote(key)) continue;
            const accepted = acceptedRevisions.get(key);
            if (Number.isSafeInteger(accepted)) appliedRevisions.set(key, accepted);
          }
        }
        finish();
        return true;
      }, (error) => {
        log?.error("The extension's saved settings couldn't be read", error);
        setStatus("error", error);
        return false;
      }).finally(() => {
        loadPending = false;
      });
      return loadPromise;
    };
    bridge.on("storage", (changes, meta) => {
      if (meta && Object.hasOwn(meta, "error")) {
        storageFailureRevision++;
        const error = new Error(String(meta.error) || "the browser could not verify a storage change");
        log?.error("A storage change couldn't be verified", error);
        setStatus("error", error);
        return;
      }
      const incoming = { ...changes ?? {} };
      if (meta?.snapshot) {
        for (const key of data.keys()) {
          if (!Object.hasOwn(incoming, key)) incoming[key] = null;
        }
      }
      const pushedEpoch = typeof meta?.epoch === "string" && meta.epoch ? meta.epoch : null;
      const pushedState = validStorageRevisions(meta?.state) && storageRevisionEpoch(meta.state) === pushedEpoch ? meta.state : null;
      const reactivatesPushedEpoch = pushedEpoch && meta?.reactivatedEpoch === pushedEpoch;
      if (pushedEpoch && retiredStorageEpochs.has(pushedEpoch) && !reactivatesPushedEpoch) return;
      if (pushedEpoch && storageEpoch && pushedEpoch !== storageEpoch && !meta?.resetRevisions) return;
      const changesEpoch = Boolean(meta?.resetRevisions && (!storageEpoch || pushedEpoch !== storageEpoch));
      if (changesEpoch || meta?.resetRevisions && pushedEpoch === storageEpoch) {
        if (reactivatesPushedEpoch) retiredStorageEpochs.delete(pushedEpoch);
        if (storageEpoch && storageEpoch !== pushedEpoch) retiredStorageEpochs.add(storageEpoch);
        acceptedRevisions.clear();
        appliedRevisions.clear();
        revisionEpoch++;
        storageEpoch = pushedEpoch;
      } else if (pushedEpoch) {
        storageEpoch = pushedEpoch;
      }
      const changedKeys = new Set(Object.keys(incoming));
      if (pushedState) {
        for (const [key, value] of Object.entries(pushedState)) {
          if (key === STORAGE_REVISION_EPOCH_KEY || key === STORAGE_REVISION_ORDER_KEY) continue;
          acceptedRevisions.set(key, Math.max(acceptedRevisions.get(key) ?? 0, value));
        }
        if (meta?.resetRevisions) {
          for (const [key, value] of acceptedRevisions) {
            if (data.has(key) && !changedKeys.has(key)) appliedRevisions.set(key, value);
          }
        }
      }
      for (const [key, value] of Object.entries(incoming)) {
        const next = value === void 0 || value === null ? void 0 : copy(value);
        const accepted = meta?.revisions?.[key];
        const barrier = meta?.barriers?.[key];
        if (Number.isSafeInteger(accepted) && accepted >= 0) {
          const floor = acceptedRevisions.get(key) ?? accepted;
          acceptedRevisions.set(key, Math.max(floor, accepted));
          if (accepted !== acceptedRevisions.get(key) || !meta?.snapshot && accepted <= (appliedRevisions.get(key) ?? 0)) continue;
          appliedRevisions.set(key, accepted);
        } else {
          if (Number.isSafeInteger(barrier) && barrier >= 0) {
            const floor = acceptedRevisions.get(key) ?? 0;
            if (barrier < floor) continue;
            acceptedRevisions.set(key, Math.max(floor, barrier));
            appliedRevisions.set(key, Math.max(appliedRevisions.get(key) ?? 0, barrier));
          }
          keyVersions.set(key, (keyVersions.get(key) ?? 0) + 1);
        }
        const ownEcho = written.has(key) && same(data.get(key), next);
        const newerRemote = (!loaded || loadPending) && !ownEcho;
        if (newerRemote) {
          remoteChanges.set(key, {
            revision: ++revision,
            epoch: revisionEpoch,
            storageRevision: Number.isSafeInteger(accepted) ? accepted : null,
            barrier: Number.isSafeInteger(barrier) ? barrier : null,
            value: next
          });
          queuedWrites.delete(key);
          written.delete(key);
        }
        if (same(data.get(key), next) && !newerRemote) continue;
        if (next === void 0) data.delete(key);
        else data.set(key, next);
        tell(key, next);
      }
    });
    void load();
    const save = (type, payload) => bridge.request(type, payload).catch((error) => log?.error("A setting couldn't be saved in the extension", error));
    const persist = (key, type, payload) => {
      if (!loaded || finishing) queuedWrites.set(key, { type, payload });
      else save(type, payload);
    };
    const commitMutation = (type, key, payload, { detailed = false } = {}) => {
      const order = ++nextMutation;
      const version2 = keyVersions.get(key) ?? 0;
      latestMutation.set(key, order);
      return bridge.request(type, payload).then((answer) => {
        const envelope = Boolean(
          answer && typeof answer === "object" && !Array.isArray(answer) && Object.hasOwn(answer, "value") && (Object.hasOwn(answer, "revision") || Object.hasOwn(answer, "committed") || Object.hasOwn(answer, "previous"))
        );
        const answerEpoch = typeof answer?.epoch === "string" && answer.epoch ? answer.epoch : null;
        const versioned = Boolean(
          envelope && answerEpoch && Number.isSafeInteger(answer?.revision) && answer.revision >= 0
        );
        const committed = envelope ? answer.value : answer;
        let superseded;
        if (versioned) {
          if (!storageEpoch) {
            revisionEpoch++;
            acceptedRevisions.clear();
            appliedRevisions.clear();
            storageEpoch = answerEpoch;
          }
          superseded = retiredStorageEpochs.has(answerEpoch) || storageEpoch !== answerEpoch;
          const answerState = validStorageRevisions(answer?.revisions) && storageRevisionEpoch(answer.revisions) === answerEpoch ? answer.revisions : null;
          if (!superseded && answerState) {
            for (const [name, accepted] of Object.entries(answerState)) {
              if (name === STORAGE_REVISION_EPOCH_KEY || name === STORAGE_REVISION_ORDER_KEY) continue;
              acceptedRevisions.set(name, Math.max(acceptedRevisions.get(name) ?? 0, accepted));
            }
          }
          if (!superseded) {
            acceptedRevisions.set(key, Math.max(acceptedRevisions.get(key) ?? 0, answer.revision));
            superseded = acceptedRevisions.get(key) !== answer.revision || (appliedRevisions.get(key) ?? 0) >= answer.revision;
          }
        } else {
          superseded = latestMutation.get(key) !== order || (keyVersions.get(key) ?? 0) > version2;
        }
        if (!superseded) {
          const next = committed === void 0 || committed === null ? void 0 : copy(committed);
          if (next === void 0) data.delete(key);
          else data.set(key, next);
          if (versioned) appliedRevisions.set(key, answer.revision);
          tell(key, next, "ack");
        }
        const value = superseded ? data.has(key) ? copy(data.get(key)) : void 0 : copy(committed);
        if (answer?.conflict === true) {
          const error = new Error("saved settings changed while their migration was being prepared");
          error.code = "STORAGE_MIGRATION_CONFLICT";
          error.current = copy(value);
          error.receipt = copy(answer.receipt);
          error.copyAll = answer.copyAll === true;
          throw error;
        }
        return detailed ? {
          value,
          previous: envelope ? copy(answer.previous) : void 0,
          completedBefore: envelope ? copy(answer.completedBefore) : void 0
        } : value;
      }, (error) => {
        log?.error("A setting couldn't be saved in the extension", error);
        throw error;
      });
    };
    return {
      kind: "extension",
      get: (key, fallback) => data.has(key) ? copy(data.get(key)) : fallback,
      getAtLoad: (key, fallback) => pageLoadData.has(key) ? copy(pageLoadData.get(key)) : fallback,
      status,
      onStatus(listener) {
        statusListeners.add(listener);
        tellStatus(listener);
        return () => statusListeners.delete(listener);
      },
      retry: load,
      mutate: (key, mutation) => commitMutation("storage:mutate", key, { key, mutation }),
      mutateDetailed: (key, mutation) => commitMutation("storage:mutate", key, { key, mutation }, { detailed: true }),
      migrate: (key, mutation, doneKey, receipt, options = {}) => commitMutation("storage:migrate", key, { key, mutation, doneKey, receipt, ...options }),
      migrateDetailed: (key, mutation, doneKey, receipt, options = {}) => commitMutation("storage:migrate", key, { key, mutation, doneKey, receipt, ...options }, { detailed: true }),
      set(key, value) {
        const stored = copy(value);
        written.add(key);
        if (stored === void 0) data.delete(key);
        else data.set(key, stored);
        persist(key, "storage:set", { key, value: stored ?? null });
      },
      remove(key) {
        written.add(key);
        data.delete(key);
        persist(key, "storage:remove", { key });
      },
      onChange(key, listener) {
        listeners.set(key, [...listeners.get(key) ?? [], listener]);
      },
      whenReady(run) {
        if (loaded) run();
        else waiting.push(run);
      }
    };
  }
  function stoppedBecause(reason) {
    const code = String(reason || "");
    if (!/^[A-Z_]+$/.test(code)) return code || "the download stopped";
    if (code === "FILE_NO_SPACE") return `the disk is full (${code})`;
    if (code.startsWith("NETWORK_")) return `the connection dropped (${code})`;
    if (code.startsWith("SERVER_")) return `Facebook's server stopped sending it (${code})`;
    if (code.startsWith("FILE_")) return `the browser couldn't write the file (${code})`;
    return `the browser stopped it (${code})`;
  }
  var bridgeDownload = (bridge, { makeKey = () => globalThis.crypto.randomUUID() } = {}) => ({ url: url2, name, onload, onerror, ontimeout }) => {
    const key = makeKey();
    let over2 = false;
    const cancel = () => bridge.request("download:cancel", { key }).catch(() => {
    });
    const end = (report) => {
      if (over2) return;
      over2 = true;
      stopListening();
      report?.();
    };
    const ended = ({ state, error } = {}) => {
      if (state === "complete") end(onload);
      else if (state === "interrupted") end(() => onerror?.({ error: stoppedBecause(error), final: true }));
    };
    const stopListening = bridge.on("download", (data) => {
      if (data?.key === key) ended(data);
    });
    bridge.request("download", { url: url2, name, key }, { timeout: DOWNLOAD_ANSWER_WITHIN }).then(ended, (error) => {
      if (over2) return;
      cancel();
      end(() => /did not answer/.test(error.message) ? ontimeout?.() : onerror?.({ error: error.message }));
    });
    return {
      abort() {
        if (over2) return;
        end(null);
        cancel();
      }
    };
  };

  // src/core/target.js
  var TARGET = true ? "userscript" : "userscript";
  var KEEPER = TARGET === "extension" ? "The extension" : "Your userscript manager";

  // src/core/extension.js
  var UPDATE_KEY = "extensionUpdate";
  var UPDATE_TOLD_KEY = "extensionUpdate.told";
  var RELEASES_PAGE = "https://github.com/SysAdminDoc/HushFacebookWeb/releases/latest";
  var UPDATE_STATES = /* @__PURE__ */ new Set(["current", "newer", "offline", "rate-limited", "failed"]);
  var CHECK_LASTS = 30 * 1e3;
  function availableUpdate(storage, current) {
    const record = storage.get(UPDATE_KEY, null);
    if (record?.newer !== true || typeof record.latest !== "string" || !/^\d+(\.\d+)*$/.test(record.latest)) return null;
    if (current !== void 0 && record.current !== current) return null;
    const url2 = typeof record.url === "string" && record.url.startsWith("https://github.com/SysAdminDoc/HushFacebookWeb/") ? record.url : RELEASES_PAGE;
    return { version: record.latest, url: url2 };
  }
  function updateStatus(storage, current, now = Date.now()) {
    const record = storage.get(UPDATE_KEY, null);
    const time = (value) => Number.isSafeInteger(value) && value >= 0 ? value : null;
    const update = availableUpdate(storage, current);
    if (!record || record.current !== current) return { state: "waiting", update, checking: false, checkedAt: null, triedAt: null, nextAt: null };
    const checking = time(record.checking);
    return {
      // A record from before the state was saved knew only whether a release was newer.
      state: UPDATE_STATES.has(record.state) ? record.state : update ? "newer" : "waiting",
      update,
      checking: checking !== null && checking <= now && now - checking < CHECK_LASTS,
      checkedAt: time(record.checkedAt),
      triedAt: time(record.triedAt),
      nextAt: time(record.nextAt)
    };
  }
  var host;
  function extensionHost({ log } = {}) {
    if (TARGET !== "extension") return null;
    if (!host) {
      const bridge = connectBridge();
      host = {
        bridge,
        storage: createBridgeStorage(bridge, { log }),
        download: bridgeDownload(bridge),
        onOpenSettings: (run) => bridge.on("open-settings", run),
        // { asked, nextAt }: asked is false when the last check was too recent or GitHub asked
        // for a pause, which nextAt ends.
        checkForUpdate: () => bridge.request("update:check", void 0, { timeout: 3e4 })
      };
    }
    return host;
  }

  // src/core/env.js
  function inPageRealm(unsafe2, marker = () => {
  }) {
    if (!unsafe2) return true;
    try {
      return marker.constructor === unsafe2.Function;
    } catch {
      return false;
    }
  }
  function accessFor(info2, pageRealm) {
    return !pageRealm || info2?.injectInto === "content" || info2?.sandboxMode === "dom" ? "content" : "page";
  }
  var version = true ? "0.0.6" : "dev";
  var info = typeof GM_info !== "undefined" ? GM_info : null;
  var unsafe = typeof unsafeWindow !== "undefined" ? unsafeWindow : null;
  var pageAccess = accessFor(info, inPageRealm(unsafe));
  var pageWindow = windowFor(unsafe, pageAccess, globalThis);
  function windowFor(unsafe2, access, own) {
    return unsafe2 && access === "page" ? unsafe2 : own;
  }
  function managerInfo() {
    if (extensionHost()) return { manager: "Browser extension", managerVersion: version, mode: "page", pageAccess };
    return {
      manager: info?.scriptHandler ?? "unknown",
      managerVersion: info?.version ?? "unknown",
      mode: info?.injectInto ?? info?.sandboxMode ?? "unknown",
      pageAccess
    };
  }
  function gmApi() {
    const extension = extensionHost();
    if (extension) return { download: extension.download, request: null };
    return {
      download: typeof GM_download === "function" ? GM_download : null,
      request: typeof GM_xmlhttpRequest === "function" ? GM_xmlhttpRequest : null
    };
  }
  function registerMenuCommand(label, handler) {
    const extension = extensionHost();
    if (extension) extension.onOpenSettings(handler);
    else if (typeof GM_registerMenuCommand === "function") GM_registerMenuCommand(label, handler);
  }
  function whenRootReady(fn, doc = globalThis.document) {
    if (!doc || doc.documentElement) return fn();
    const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
    const observer = new Observer(() => {
      if (!doc.documentElement) return;
      observer.disconnect();
      fn();
    });
    observer.observe(doc, { childList: true });
  }
  function whenBodyReady(fn, doc = globalThis.document) {
    if (doc.body) return fn();
    doc.addEventListener("DOMContentLoaded", () => {
      if (doc.body) fn();
    }, { once: true });
  }

  // src/core/log.js
  var LEVELS = ["debug", "info", "warn", "error"];
  function createLog({ capacity = 400, sink = globalThis.console, now = () => /* @__PURE__ */ new Date() } = {}) {
    const entries = [];
    const listeners = /* @__PURE__ */ new Set();
    function write(level, message, detail) {
      const entry = { time: now().toISOString(), level, message: String(message) };
      if (detail !== void 0) {
        entry.detail = describe(detail);
        entry.code = codeOf(detail);
      }
      entries.push(entry);
      if (entries.length > capacity) entries.shift();
      if (level !== "debug") sink?.[level]?.(`[HushFacebook Web] ${entry.message}`, ...detail === void 0 ? [] : [detail]);
      for (const listener of listeners) listener(entry);
      return entry;
    }
    const log = Object.fromEntries(LEVELS.map((level) => [level, (message, detail) => write(level, message, detail)]));
    log.entries = () => entries.slice();
    log.subscribe = (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    };
    return log;
  }
  function codeOf(detail) {
    let name;
    try {
      name = detail !== null && typeof detail === "object" ? detail.name : void 0;
    } catch {
    }
    return typeof name === "string" && /^[A-Z][A-Za-z]{0,39}$/.test(name) ? name : typeof detail;
  }
  function describe(detail) {
    if (detail instanceof Error) return `${detail.name}: ${detail.message}${detail.stack ? `
${detail.stack}` : ""}`;
    if (typeof detail === "string") return detail;
    try {
      return JSON.stringify(detail);
    } catch {
      return String(detail);
    }
  }

  // src/core/storage.js
  var sameStoredValue = (left, right) => {
    if (left === void 0 || right === void 0) return left === right;
    return JSON.stringify(left) === JSON.stringify(right);
  };
  function applyObjectMutation(current, mutation = {}) {
    const replacement = Object.hasOwn(mutation, "replace");
    if (replacement) return structuredClone(mutation.replace);
    if (Object.hasOwn(mutation, "union")) {
      if (!Array.isArray(mutation.union) || mutation.union.some((id) => typeof id !== "string")) {
        throw new TypeError("union mutations require string ids");
      }
      const existing = Array.isArray(current) ? current.filter((id) => typeof id === "string") : [];
      return [.../* @__PURE__ */ new Set([...structuredClone(existing), ...structuredClone(mutation.union)])];
    }
    const initial = current === void 0 && Object.hasOwn(mutation, "initialize") ? mutation.initialize : current;
    const next = initial && typeof initial === "object" && !Array.isArray(initial) ? structuredClone(initial) : {};
    const allowed = (name) => {
      const condition = mutation.conditions?.[name];
      if (!condition) return true;
      const exists = Object.hasOwn(initial ?? {}, name);
      return exists === condition.exists && (!exists || sameStoredValue(initial[name], condition.value));
    };
    for (const name of mutation.remove ?? []) {
      if (allowed(name)) delete next[name];
    }
    for (const [name, value] of Object.entries(mutation.set ?? {})) {
      if (allowed(name)) next[name] = structuredClone(value);
    }
    return next;
  }
  function mutateObjectDetailed(storage, key, mutation) {
    const previous = storage.get(key, void 0);
    const next = applyObjectMutation(previous, mutation);
    storage.set(key, next);
    return { value: structuredClone(next), previous: structuredClone(previous) };
  }
  function mutateObject(storage, key, mutation) {
    return mutateObjectDetailed(storage, key, mutation).value;
  }
  var keepsSettings = (storage) => storage.kind === "gm" || storage.kind === "extension";
  function createGmStorage({ log } = {}) {
    const extension = extensionHost({ log });
    if (extension) return extension.storage;
    if (typeof GM_getValue !== "function" || typeof GM_setValue !== "function") {
      return createLocalStorage();
    }
    const storage = {
      kind: "gm",
      get: (key, fallback) => GM_getValue(key, fallback),
      set: (key, value) => GM_setValue(key, value),
      remove: (key) => typeof GM_deleteValue === "function" ? GM_deleteValue(key) : GM_setValue(key, void 0),
      onChange(key, listener) {
        if (typeof GM_addValueChangeListener !== "function") return;
        GM_addValueChangeListener(key, (_name, _old, value, remote) => {
          if (remote) listener(value);
        });
      }
    };
    storage.mutate = (key, mutation) => mutateObject(storage, key, mutation);
    storage.mutateDetailed = (key, mutation) => mutateObjectDetailed(storage, key, mutation);
    return storage;
  }
  var UNKEPT_SETTINGS = "Your userscript manager doesn't give HushFacebook Web storage of its own, so your settings are kept in Facebook's page, which clears them within seconds. Tampermonkey and Violentmonkey keep them.";
  function createLocalStorage(prefix = "hfw:") {
    const storage = {
      kind: "localStorage",
      get(key, fallback) {
        try {
          const raw = localStorage.getItem(prefix + key);
          return raw === null ? fallback : JSON.parse(raw);
        } catch {
          return fallback;
        }
      },
      set: (key, value) => localStorage.setItem(prefix + key, JSON.stringify(value)),
      remove: (key) => localStorage.removeItem(prefix + key),
      onChange(key, listener) {
        addEventListener("storage", (event) => {
          if (event.key !== prefix + key) return;
          try {
            listener(event.newValue === null ? void 0 : JSON.parse(event.newValue));
          } catch {
            listener(void 0);
          }
        });
      }
    };
    storage.mutate = (key, mutation) => mutateObject(storage, key, mutation);
    storage.mutateDetailed = (key, mutation) => mutateObjectDetailed(storage, key, mutation);
    return storage;
  }

  // src/core/actions.js
  function createActions() {
    const byFeature = /* @__PURE__ */ new Map();
    const linkLists = /* @__PURE__ */ new Map();
    return {
      // The handle a feature gets as ctx.actions.
      for(featureId) {
        return {
          add(label, run) {
            const list = byFeature.get(featureId) ?? [];
            list.push({ label, run });
            byFeature.set(featureId, list);
          },
          links(get, empty) {
            linkLists.set(featureId, { get, empty });
          }
        };
      },
      links(featureId) {
        const found = linkLists.get(featureId);
        return found ? { items: found.get(), empty: found.empty } : null;
      },
      list(featureId) {
        return (byFeature.get(featureId) ?? []).map(({ label, run }, index) => ({ label: typeof label === "function" ? label() : label, run, index })).filter(({ label }) => label);
      }
    };
  }

  // src/core/i18n.js
  var PLAIN = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  var ACCENTED = "áḃçḋéḟĝĥîĵḱĺḿñöṕqŕšţûṽŵẍýžÁḂÇḊÉḞĜĤÎĴḰĹḾÑÖṔQŔŠŢÛṼŴẌÝŽ";
  var ACCENTS = new Map([...PLAIN].map((letter, index) => [letter, [...ACCENTED].at(index)]));
  var PADDING = "one two three four five six seven eight nine ten".split(" ");
  var PLACEHOLDER = /\{(\w+)\}/g;
  var accent = (text) => [...text].map((letter) => ACCENTS.get(letter) ?? letter).join("");
  function stretch(template) {
    const parts = template.split(/(\{\w+\})/);
    const length = parts.filter((part, index) => index % 2 === 0).join("").length;
    if (!length) return template;
    const wanted = length <= 10 ? length : Math.ceil(length * 0.4);
    const words = [];
    for (let i = 0; words.join(" ").length < wanted; i++) words.push(PADDING[i % PADDING.length]);
    return `[${parts.map((part, index) => index % 2 === 0 ? accent(part) : part).join("")} ${accent(words.join(" "))}]`;
  }
  var LANGUAGES = Object.freeze([
    Object.freeze({ value: "en", label: "English", lang: "en", dir: "ltr" }),
    Object.freeze({ value: "long-test", label: "Test: long text", lang: "en", dir: "ltr", test: true, transform: stretch }),
    Object.freeze({ value: "rtl-test", label: "Test: right to left", lang: "en", dir: "rtl", test: true })
  ]);
  var CATALOGS = {};
  var active = LANGUAGES[0];
  var language = () => active;
  function setLanguage(value) {
    const next = LANGUAGES.find((entry) => entry.value === value) ?? LANGUAGES[0];
    if (next === active) return false;
    active = next;
    return true;
  }
  function fill(template, vars) {
    if (!vars) return template;
    return template.replace(PLACEHOLDER, (match, name) => Object.hasOwn(vars, name) ? String(vars[name]) : match);
  }
  var english = (template, vars) => fill(template, vars);
  function t(template, vars) {
    if (typeof template !== "string" || template === "") return template;
    if (active.transform) return fill(active.transform(template), vars);
    const translated = CATALOGS[active.value]?.[template];
    return fill(typeof translated === "string" ? translated : template, vars);
  }
  function plural(count, one, other, vars) {
    const forms = CATALOGS[active.value]?.[other];
    const all = { count, ...vars };
    if (forms && typeof forms === "object" && !active.transform) {
      const form = forms[new Intl.PluralRules(active.lang).select(count)] ?? forms.other;
      if (typeof form === "string") return fill(form, all);
    }
    return t(count === 1 ? one : other, all);
  }

  // src/core/sha256.js
  var K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var rotr = (x, n) => x >>> n | x << 32 - n;
  function sha256Hex(text) {
    const bytes = new TextEncoder().encode(String(text));
    const data = new Uint8Array(Math.ceil((bytes.length + 9) / 64) * 64);
    data.set(bytes);
    data[bytes.length] = 128;
    const view2 = new DataView(data.buffer);
    const bits = bytes.length * 8;
    view2.setUint32(data.length - 8, Math.floor(bits / 4294967296));
    view2.setUint32(data.length - 4, bits >>> 0);
    const hash = new Uint32Array([1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225]);
    const w = new Uint32Array(64);
    for (let offset = 0; offset < data.length; offset += 64) {
      for (let i = 0; i < 16; i++) w[i] = view2.getUint32(offset + i * 4);
      for (let i = 16; i < 64; i++) {
        const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
        const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
      }
      let [a, b, c, d, e, f, g, h2] = hash;
      for (let i = 0; i < 64; i++) {
        const t1 = h2 + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + (e & f ^ ~e & g) + K[i] + w[i] >>> 0;
        const t2 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + (a & b ^ a & c ^ b & c) >>> 0;
        h2 = g;
        g = f;
        f = e;
        e = d + t1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = t1 + t2 >>> 0;
      }
      hash[0] += a;
      hash[1] += b;
      hash[2] += c;
      hash[3] += d;
      hash[4] += e;
      hash[5] += f;
      hash[6] += g;
      hash[7] += h2;
    }
    return [...hash].map((word) => word.toString(16).padStart(8, "0")).join("");
  }

  // src/core/settings.js
  var STORAGE_KEY = "settings";
  var REMOVED = /* @__PURE__ */ Symbol("removed");
  var EXPORT_SCHEMA = 1;
  var MAX_BACKUP_BYTES = 1024 * 1024;
  var isPromise = (value) => value && typeof value.then === "function";
  var isSettingsRecord = (value) => Boolean(value) && typeof value === "object" && !Array.isArray(value);
  function accountFromCookie(cookie) {
    const found = new Set([...String(cookie ?? "").matchAll(/(?:^|;\s*)c_user=(\d+)(?=;|$)/g)].map((match) => match[1]));
    return found.size === 1 ? [...found][0] : null;
  }
  function accountTag(account) {
    return sha256Hex(`HushFacebook Web account ${account}`).slice(0, 32);
  }
  function legacyAccountTag(account) {
    let hash = 2166136261;
    for (const char of String(account)) {
      hash ^= char.charCodeAt(0);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return hash.toString(36);
  }
  function storageKeyFor(account) {
    return account ? `${STORAGE_KEY}@${accountTag(account)}` : STORAGE_KEY;
  }
  function legacyStorageKeyFor(account) {
    return account ? `${STORAGE_KEY}@${legacyAccountTag(account)}` : null;
  }
  var CLAIM_PREFIX = "claimed-by-";
  var claimFor = (account) => `${CLAIM_PREFIX}${accountTag(account)}`;
  var MIGRATIONS = [
    {
      // In v0.0.1 Hide sponsored posts also took the ads out of search and Marketplace. Someone
      // who had it off keeps those ads now that each place has its own switch.
      id: "split-ad-switch",
      before: "0.0.2",
      run(raw) {
        if (raw.hideSponsoredPosts !== false) return;
        for (const key of ["hideSponsoredSearch", "hideSponsoredMarketplace"]) {
          if (!Object.hasOwn(raw, key)) raw[key] = false;
        }
      }
    }
  ];
  function olderThan(version2, before) {
    const parts = (text) => /^(\d+)\.(\d+)\.(\d+)/.exec(String(text ?? ""))?.slice(1).map(Number);
    const a = parts(version2);
    const b = parts(before);
    if (!a || !b) return false;
    for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] < b[i];
    return false;
  }
  var GLOBAL_SETTINGS = [
    { key: "paused", type: "toggle", default: false, label: "Pause HushFacebook Web" },
    { key: "ui.launcher", type: "toggle", default: true, label: "Show the settings button on Facebook" },
    { key: "ui.hiddenNote", type: "toggle", default: false, label: "Leave a note where a post was hidden" },
    { key: "ui.language", type: "select", default: "en", label: "Language", choices: LANGUAGES.map(({ value, label }) => ({ value, label })) }
  ];
  var KEPT_ON_RESET = Object.freeze(["ui.language"]);
  function buildSchema(features2) {
    const schema = /* @__PURE__ */ new Map();
    const add = (spec) => {
      if (schema.has(spec.key)) throw new Error(`Duplicate setting key: ${spec.key}`);
      schema.set(spec.key, spec);
    };
    for (const spec of GLOBAL_SETTINGS) add(spec);
    for (const feature of features2) {
      add({ key: feature.id, type: "toggle", default: feature.default === true, label: feature.title, featureId: feature.id });
      for (const option of feature.options ?? []) {
        add({ ...option, key: `${feature.id}.${option.key}`, featureId: feature.id });
      }
    }
    return schema;
  }
  function isValid(spec, value) {
    switch (spec.type) {
      case "toggle":
        return typeof value === "boolean";
      case "select":
        return spec.choices.some((choice) => choice.value === value);
      case "text":
        return typeof value === "string" && value.length <= (spec.maxLength ?? 2e4);
      case "number":
        return Number.isFinite(value) && value >= (spec.min ?? -Infinity) && value <= (spec.max ?? Infinity);
      default:
        return false;
    }
  }
  function createSettings({ storage, features: features2, log, version: version2 = "dev", account = null, migrations = MIGRATIONS, tabPaused = false }) {
    const schema = buildSchema(features2);
    const listeners = /* @__PURE__ */ new Set();
    const settingName = (key2) => {
      const spec2 = schema.get(key2);
      const feature = spec2.featureId && spec2.featureId !== key2 ? schema.get(spec2.featureId) : null;
      if (feature && spec2.label) return `${spec2.label} in ${feature.label}`;
      return feature?.label ?? spec2.label ?? key2;
    };
    const invalidBackupMessage = (keys, from) => {
      const which = keys.length === 1 ? `a value this version can't use for ${settingName(keys[0])}` : `values this version can't use for ${settingName(keys[0])} and ${keys.length - 1} more`;
      const newer = olderThan(version2, from) ? /^\d+\.\d+\.\d+/.exec(String(from))[0] : null;
      const update = newer ? `. It's from version ${newer}, so update HushFacebook Web and restore it again` : "";
      return `That backup has ${which}, so nothing changed${update}`;
    };
    const key = storageKeyFor(account);
    const doneKey = `${key}.migrated`;
    const legacyKey = legacyStorageKeyFor(account);
    const legacyDoneKey = legacyKey && `${legacyKey}.migrated`;
    const claim = account ? claimFor(account) : null;
    const isClaim = (id) => typeof id === "string" && id.startsWith(CLAIM_PREFIX);
    const migrationIds = (receipt) => receipt.filter((id) => typeof id === "string" && !isClaim(id));
    let ready = !storage.whenReady;
    let managerCopyRetry = null;
    let values = ready ? loadManagerSettings() : {};
    let pageLoadValues = ready ? structuredClone(values) : {};
    const drafts = new Map(managerCopyRetry?.drafts ?? []);
    const saveListeners = /* @__PURE__ */ new Set();
    let saveState = "idle";
    let saveError = null;
    let replacePending = false;
    let activeSave = null;
    let queuedWaiters = [];
    let pendingInternal = managerCopyRetry;
    let valueGeneration = 0;
    let reinitializeAccountOnWrite = false;
    let accountDeletionGeneration = -1;
    function accountSource(get2) {
      if (!legacyKey || !isSettingsRecord(get2(legacyKey, void 0))) return STORAGE_KEY;
      const receipt = get2(legacyDoneKey, void 0);
      const claims = Array.isArray(receipt) ? receipt.filter(isClaim) : [];
      return claims.every((id) => id === claim) ? legacyKey : STORAGE_KEY;
    }
    function claimLegacy(get2) {
      if (accountSource(get2) !== legacyKey) return;
      const receipt = get2(legacyDoneKey, void 0);
      if (Array.isArray(receipt) && receipt.includes(claim)) return;
      const failed = (error) => log?.error("Could not mark your old settings as copied", error);
      try {
        const saved = storage.mutate ? storage.mutate(legacyDoneKey, { union: [claim] }) : storage.set(legacyDoneKey, [...Array.isArray(receipt) ? receipt.filter((id) => typeof id === "string") : [], claim]);
        if (isPromise(saved)) saved.catch(failed);
      } catch (error) {
        failed(error);
      }
    }
    function read2(get2) {
      const own = get2(key, void 0);
      if (key === STORAGE_KEY) return isSettingsRecord(own) ? own : {};
      if (isSettingsRecord(own)) return own;
      return sanitize(get2(accountSource(get2), {}));
    }
    function migrationResult(raw, stored) {
      const done = Array.isArray(stored) ? [...new Set(stored.filter((id) => typeof id === "string"))] : [];
      const original = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
      const before = sanitize(original);
      const pending = migrations.filter((migration) => !done.includes(migration.id));
      if (!pending.length) return { original, before, after: before, done, pending, owners: {} };
      const next = { ...original };
      const owners = {};
      let previous = before;
      for (const migration of pending) {
        migration.run(next);
        const current = sanitize(next);
        for (const name of schema.keys()) {
          const previousHas = Object.hasOwn(previous, name);
          const currentHas = Object.hasOwn(current, name);
          if (previousHas !== currentHas || previousHas && JSON.stringify(previous[name]) !== JSON.stringify(current[name])) owners[name] = migration.id;
        }
        previous = current;
      }
      return { original, before, after: sanitize(next), done, pending, owners };
    }
    function migrationRecord(get2) {
      const own = get2(doneKey, void 0);
      const cleanOwn = Array.isArray(own) ? [...new Set(own.filter((id) => typeof id === "string"))] : own;
      if (key === STORAGE_KEY || get2(key, void 0) !== void 0) return cleanOwn;
      const shared = get2(`${accountSource(get2)}.migrated`, void 0);
      if (Array.isArray(own) || Array.isArray(shared)) {
        return [.../* @__PURE__ */ new Set([
          ...Array.isArray(cleanOwn) ? cleanOwn : [],
          ...Array.isArray(shared) ? migrationIds(shared) : []
        ])];
      }
      return cleanOwn ?? shared;
    }
    function persistMigrationReceipt(receipt) {
      if (!receipt) return void 0;
      return storage.mutate ? storage.mutate(doneKey, { union: structuredClone(receipt) }) : storage.set(doneKey, receipt);
    }
    function migrationDraftEntries(before, after) {
      const entries = [];
      for (const name of schema.keys()) {
        const beforeHas = Object.hasOwn(before, name);
        const afterHas = Object.hasOwn(after, name);
        if (beforeHas === afterHas && (!beforeHas || JSON.stringify(before[name]) === JSON.stringify(after[name]))) continue;
        entries.push([name, afterHas ? structuredClone(after[name]) : REMOVED]);
      }
      return entries;
    }
    function persistRecordMutation(mutation, message, onSaved) {
      const saved = () => onSaved?.();
      try {
        if (storage.mutate) {
          const result = storage.mutate(key, mutation);
          if (isPromise(result)) {
            const completed = result.then(saved);
            completed.catch((error) => log?.error(message, error));
            return completed;
          }
          const receipt2 = saved();
          if (isPromise(receipt2)) {
            receipt2.catch((error) => log?.error(message, error));
            return receipt2;
          }
          return true;
        }
        const current = storage.get(key, {});
        const next = Object.hasOwn(mutation, "replace") ? { ...mutation.replace } : { ...current, ...mutation.set };
        for (const name of mutation.remove ?? []) delete next[name];
        storage.set(key, next);
        const receipt = saved();
        if (isPromise(receipt)) {
          receipt.catch((error) => log?.error(message, error));
          return receipt;
        }
        return true;
      } catch (error) {
        log?.error(message, error);
        return false;
      }
    }
    function saveMigration({ original, before, after, done, pending }, valuesToSave = after, forceValues = false) {
      if (!pending.length && !forceValues) return { saved: true, retry: null };
      const set = {};
      for (const [name, value] of Object.entries(valuesToSave)) {
        if (forceValues || !Object.hasOwn(before, name) || JSON.stringify(before[name]) !== JSON.stringify(value)) set[name] = value;
      }
      const remove = Object.keys(original).filter((name) => !Object.hasOwn(valuesToSave, name));
      const saveReceipt = () => {
        if (pending.length) return persistMigrationReceipt([...done, ...pending.map((migration) => migration.id)]);
        return void 0;
      };
      const retry = { mutation: { set, remove }, onSaved: saveReceipt };
      if (Object.keys(set).length || remove.length) {
        return { saved: persistRecordMutation(retry.mutation, "Could not save a settings update", saveReceipt), retry };
      } else {
        try {
          const receipt = saveReceipt();
          if (isPromise(receipt)) {
            receipt.catch((error) => log?.error("Could not save a settings update", error));
            return { saved: receipt, retry };
          }
          return { saved: true, retry };
        } catch (error) {
          log?.error("Could not save a settings update", error);
          return { saved: false, retry };
        }
      }
    }
    function loadManagerSettings() {
      const inheritedShared = key !== STORAGE_KEY && storage.get(key, void 0) === void 0;
      const storedMigrations = migrationRecord(storage.get);
      const migration = migrationResult(read2(storage.get), storedMigrations);
      if (!inheritedShared) {
        const { saved: saved2, retry } = saveMigration(migration);
        if (saved2 === false) {
          const migrationDrafts = migrationDraftEntries(migration.before, migration.after);
          managerCopyRetry = { ...retry, fields: migrationDrafts.map(([name]) => name), drafts: migrationDrafts };
        }
        return saved2 === false || isPromise(saved2) ? migration.before : migration.after;
      }
      const receipt = migration.pending.length ? [...migration.done, ...migration.pending.map((item) => item.id)] : Array.isArray(storedMigrations) ? storedMigrations : null;
      const saveReceipt = () => {
        if (receipt) return persistMigrationReceipt(receipt);
        return void 0;
      };
      claimLegacy(storage.get);
      let saved;
      const mutation = { replace: migration.after };
      saved = persistRecordMutation(mutation, "Could not copy your settings to this account", saveReceipt);
      if (saved === false) {
        const migrationDrafts = migrationDraftEntries(migration.before, migration.after);
        managerCopyRetry = {
          mutation,
          onSaved: saveReceipt,
          fields: migrationDrafts.map(([name]) => name),
          drafts: migrationDrafts
        };
      }
      return saved === false || isPromise(saved) ? migration.before : migration.after;
    }
    function stageMigration(migration, { copyAll = false, receipt = null, source = STORAGE_KEY } = {}) {
      if (!migration.pending.length && !copyAll) return;
      const changed = new Set([...schema.keys()].filter((name) => !sameValue(savedValue(migration.after, name), savedValue(migration.before, name))));
      const set = {};
      const remove = Object.keys(migration.original).filter((name) => !Object.hasOwn(migration.after, name) && !changed.has(name));
      const conditions = {};
      const guard = {};
      const guarded = [];
      const migrationOwners = {};
      const migrationValues = {};
      const migrationValueOwners = {};
      const rawCondition = (name) => Object.hasOwn(migration.original, name) ? { exists: true, value: structuredClone(migration.original[name]) } : { exists: false };
      for (const name of schema.keys()) {
        if (drafts.has(name) && !replacePending) continue;
        guard[name] = rawCondition(name);
      }
      for (const name of changed) {
        const after = savedValue(migration.after, name);
        if (!drafts.has(name)) {
          conditions[name] = rawCondition(name);
          guarded.push(name);
          if (migration.owners?.[name]) migrationOwners[name] = migration.owners[name];
        }
        if (!drafts.has(name) || replacePending) {
          migrationValues[name] = after === REMOVED ? { exists: false } : { exists: true, value: structuredClone(after) };
          if (migration.owners?.[name]) migrationValueOwners[name] = migration.owners[name];
        }
      }
      const onSaved = () => {
        if (receipt) return persistMigrationReceipt(receipt);
        return void 0;
      };
      if (!copyAll && !migration.pending.length && !changed.size && !Object.keys(set).length && !remove.length) {
        try {
          onSaved();
        } catch (error) {
          log?.error(copyAll ? "Could not copy your settings to this account" : "Could not save a settings update", error);
        }
        return;
      }
      pendingInternal = {
        mutation: {
          ...copyAll ? { initialize: structuredClone(migration.before) } : {},
          set,
          remove,
          conditions,
          guard,
          guarded,
          migrationOwners
        },
        onSaved,
        receipt,
        fields: guarded,
        migrationValues,
        migrationValueOwners,
        copyAll,
        sourceKey: copyAll ? source : null,
        sourceDoneKey: copyAll ? `${source}.migrated` : null
      };
      for (const name of changed) {
        const wanted = savedValue(migration.after, name);
        if (!drafts.has(name)) {
          drafts.set(name, wanted === REMOVED ? REMOVED : structuredClone(wanted));
        }
      }
    }
    function stageAccountReinitialization() {
      if (!reinitializeAccountOnWrite || pendingInternal?.copyAll || activeSave?.internal?.copyAll) return;
      if (isSettingsRecord(storage.get(key, void 0))) {
        reinitializeAccountOnWrite = false;
        return;
      }
      const storedMigrations = migrationRecord(storage.get);
      const migration = migrationResult(read2(storage.get), storedMigrations);
      const receipt = migration.pending.length ? [...migration.done, ...migration.pending.map((item) => item.id)] : Array.isArray(storedMigrations) ? storedMigrations : null;
      claimLegacy(storage.get);
      stageMigration(migration, { copyAll: true, receipt, source: accountSource(storage.get) });
    }
    function loadSavedSettings() {
      ready = true;
      if (storage.getAtLoad) {
        const get2 = (name, fallback) => storage.getAtLoad(name, fallback);
        const inheritedShared = key !== STORAGE_KEY && get2(key, void 0) === void 0;
        const storedMigrations = migrationRecord(get2);
        const migration = migrationResult(read2(get2), storedMigrations);
        values = { ...migration.before };
        pageLoadValues = structuredClone(values);
        const receipt = migration.pending.length ? [...migration.done, ...migration.pending.map((item) => item.id)] : inheritedShared && Array.isArray(storedMigrations) ? storedMigrations : null;
        if (inheritedShared) claimLegacy(get2);
        stageMigration(migration, { copyAll: inheritedShared, receipt, source: accountSource(get2) });
      } else {
        values = loadManagerSettings();
        if (managerCopyRetry) pendingInternal = managerCopyRetry;
        pageLoadValues = structuredClone(values);
      }
      notify([...schema.keys()], true);
      flush();
    }
    function sanitize(raw) {
      const clean6 = {};
      if (!raw || typeof raw !== "object") return clean6;
      for (const [key2, value] of Object.entries(raw)) {
        const spec2 = schema.get(key2);
        if (spec2 && isValid(spec2, value) && value !== spec2.default) clean6[key2] = value;
      }
      return clean6;
    }
    const savedValue = (record, name) => Object.hasOwn(record, name) ? record[name] : REMOVED;
    const sameValue = (a, b) => a === REMOVED ? b === REMOVED : b !== REMOVED && JSON.stringify(a) === JSON.stringify(b);
    const shownValue = (name) => {
      const draft = drafts.get(name);
      return drafts.has(name) ? draft === REMOVED ? spec(name).default : draft : get(name);
    };
    const pendingKeys = () => [...drafts.keys()];
    const saveStatus = () => ({ state: saveState, error: saveError, pending: pendingKeys() });
    const tellSaveStatus = (listener) => {
      try {
        listener(saveStatus());
      } catch (error) {
        log?.error("A settings save listener failed", error);
      }
    };
    const setSaveStatus = (state, error = null) => {
      saveState = state;
      saveError = error;
      for (const listener of saveListeners) tellSaveStatus(listener);
    };
    const makeWaiter = ({ returnPrevious = false, fallbackPrevious } = {}) => {
      let resolve;
      let reject;
      const promise = new Promise((yes, no) => {
        resolve = yes;
        reject = no;
      });
      return {
        promise,
        resolve,
        reject,
        pending: true,
        exposed: false,
        returnPrevious,
        fallbackPrevious,
        value: void 0
      };
    };
    const resolveWaiters = (waiters, previous) => {
      for (const waiter of waiters) {
        waiter.pending = false;
        waiter.value = waiter.returnPrevious ? sanitize(previous === void 0 ? waiter.fallbackPrevious : previous) : void 0;
        waiter.resolve(waiter.value);
      }
    };
    const migrationPrevious = (raw, internal, completedBefore) => {
      if (!internal?.migrationValues || !Object.keys(internal.migrationValues).length) return raw;
      const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
      const guardMatches = Object.entries(internal.mutation?.guard ?? {}).every(([name, condition]) => {
        const exists = Object.hasOwn(source, name);
        return exists === condition.exists && (!exists || sameValue(source[name], condition.value));
      });
      if (!guardMatches) return raw;
      const next = sanitize(source);
      const completed = new Set(Array.isArray(completedBefore) ? completedBefore : []);
      for (const [name, wanted] of Object.entries(internal.migrationValues)) {
        const owner = internal.migrationValueOwners?.[name];
        if (owner && completed.has(owner)) continue;
        const condition = internal.mutation?.conditions?.[name];
        const exists = Object.hasOwn(source, name);
        if (condition && (exists !== condition.exists || exists && !sameValue(source[name], condition.value))) continue;
        if (wanted.exists) next[name] = structuredClone(wanted.value);
        else delete next[name];
      }
      return sanitize(next);
    };
    const rejectWaiters = (waiters, error) => {
      for (const waiter of waiters) {
        waiter.pending = false;
        if (waiter.exposed) waiter.reject(error);
      }
    };
    const changedKeys = (before, after) => [...schema.keys()].filter((name) => !sameValue(savedValue(before, name), savedValue(after, name)));
    const mutationFor = (sent, replace) => {
      const set = {};
      const remove = [];
      for (const [name, value] of sent) {
        if (value === REMOVED) remove.push(name);
        else set[name] = value;
      }
      if (replace) return { replace: set };
      return { set, remove };
    };
    const mergeMutation = (sent, replace, internal) => {
      const mutation = mutationFor(sent, replace);
      if (!internal) return mutation;
      if (replace) {
        return {
          ...mutation,
          ...internal.guard ? { guard: structuredClone(internal.guard) } : {}
        };
      }
      const set = { ...internal.set ?? {}, ...mutation.set };
      const remove = new Set(internal.remove ?? []);
      for (const name of Object.keys(mutation.set)) remove.delete(name);
      for (const name of mutation.remove) {
        delete set[name];
        remove.add(name);
      }
      return {
        ...Object.hasOwn(internal, "initialize") ? { initialize: structuredClone(internal.initialize) } : Object.hasOwn(internal, "replace") ? { initialize: structuredClone(internal.replace) } : {},
        set,
        remove: [...remove],
        ...internal.conditions ? { conditions: structuredClone(internal.conditions) } : {},
        ...internal.guard ? { guard: structuredClone(internal.guard) } : {},
        ...internal.guarded ? { guarded: structuredClone(internal.guarded) } : {},
        ...internal.migrationOwners ? { migrationOwners: structuredClone(internal.migrationOwners) } : {}
      };
    };
    const committedCandidate = (sent, replace) => {
      const next = replace ? {} : { ...values };
      for (const [name, value] of sent) {
        if (value === REMOVED) delete next[name];
        else next[name] = value;
      }
      return sanitize(next);
    };
    const settleSave = () => {
      if (activeSave || drafts.size || pendingInternal) return;
      setSaveStatus("idle");
      const waiters = queuedWaiters;
      queuedWaiters = [];
      resolveWaiters(waiters);
    };
    const supersededByAccountDeletion = (operation) => key !== STORAGE_KEY && reinitializeAccountOnWrite && accountDeletionGeneration > operation.generation;
    const retryMigrationConflict = (error, operation) => {
      if (error?.code !== "STORAGE_MIGRATION_CONFLICT" || !operation.internal) return false;
      const attempts = (operation.internal.conflicts ?? 0) + 1;
      if (attempts > 3) return false;
      const storageChangedLater = valueGeneration > operation.generation;
      const current = storageChangedLater ? read2(storage.get) : error.current;
      const currentReceipt = storageChangedLater ? migrationRecord(storage.get) : error.receipt;
      activeSave = null;
      for (const name of operation.internal.fields ?? []) {
        const sent = operation.sent.get(name);
        if (drafts.has(name) && sameValue(drafts.get(name), sent)) drafts.delete(name);
      }
      const before = values;
      values = sanitize(current);
      valueGeneration++;
      const changed = changedKeys(before, values);
      if (changed.length) notify(changed, true);
      const migration = migrationResult(current, currentReceipt);
      const receipt = migration.pending.length ? [...migration.done, ...migration.pending.map((item) => item.id)] : Array.isArray(currentReceipt) ? currentReceipt : null;
      pendingInternal = null;
      replacePending = operation.replace;
      stageMigration(migration, {
        copyAll: supersededByAccountDeletion(operation) || error.copyAll === true,
        receipt
      });
      if (pendingInternal) pendingInternal.conflicts = attempts;
      queuedWaiters = [...operation.waiters, ...queuedWaiters];
      setSaveStatus("saving");
      flush();
      return true;
    };
    const saveFailed = (error, operation) => {
      if (retryMigrationConflict(error, operation)) return;
      activeSave = null;
      if (operation.replace) replacePending = true;
      if (operation.internal) pendingInternal = operation.internal;
      log?.error("Could not save settings", error);
      setSaveStatus("error", error);
      rejectWaiters(operation.waiters, error);
      const blocked = queuedWaiters;
      queuedWaiters = [];
      rejectWaiters(blocked, error);
    };
    const finishSave = (raw, operation, previous, completedBefore) => {
      activeSave = null;
      const accountDeletedLater = supersededByAccountDeletion(operation);
      if (!accountDeletedLater && (operation.replace || operation.internal?.copyAll)) {
        reinitializeAccountOnWrite = false;
      }
      const before = values;
      if (!accountDeletedLater && valueGeneration === operation.ackGeneration) values = sanitize(raw);
      if (!replacePending) {
        for (const [name, sent] of operation.sent) {
          if (drafts.has(name) && sameValue(drafts.get(name), sent)) drafts.delete(name);
        }
      }
      const changed = changedKeys(before, values);
      if (changed.length) notify(changed);
      resolveWaiters(operation.waiters, migrationPrevious(previous, operation.internal, completedBefore));
      if (drafts.size) flush();
      else settleSave();
    };
    const receiptFailed = (error, raw, operation) => {
      activeSave = null;
      const accountDeletedLater = supersededByAccountDeletion(operation);
      const before = values;
      if (!accountDeletedLater && valueGeneration === operation.ackGeneration) values = sanitize(raw);
      for (const [name, sent] of operation.sent) {
        if (drafts.has(name) && sameValue(drafts.get(name), sent)) drafts.delete(name);
      }
      const changed = changedKeys(before, values);
      if (changed.length) notify(changed);
      pendingInternal = operation.internal && !accountDeletedLater ? {
        ...operation.internal,
        mutation: { set: {}, remove: [] },
        fields: [],
        receiptOnly: true
      } : null;
      log?.error("Could not save settings", error);
      setSaveStatus("error", error);
      rejectWaiters(operation.waiters, error);
      const blocked = queuedWaiters;
      queuedWaiters = [];
      rejectWaiters(blocked, error);
    };
    const saveSucceeded = (raw, operation, previous, completedBefore) => {
      operation.ackGeneration = valueGeneration;
      if (operation.atomicMigration) {
        finishSave(raw, operation, previous, completedBefore);
        return;
      }
      let recorded;
      try {
        recorded = operation.internal?.onSaved?.();
      } catch (error) {
        const exposed = operation.waiters.some((waiter) => waiter.exposed);
        receiptFailed(error, raw, operation);
        if (!exposed) throw error;
        return;
      }
      if (isPromise(recorded)) {
        activeSave = operation;
        setSaveStatus("saving");
        recorded.then(
          () => finishSave(raw, operation, previous, completedBefore),
          (error) => receiptFailed(error, raw, operation)
        );
        return;
      }
      finishSave(raw, operation, previous);
    };
    const discardOperation = (operation) => {
      for (const [name, sent] of operation.sent) {
        if (drafts.has(name) && sameValue(drafts.get(name), sent)) drafts.delete(name);
      }
      replacePending = false;
    };
    function flush() {
      if (activeSave) return;
      stageAccountReinitialization();
      if (!drafts.size && !pendingInternal) {
        settleSave();
        return void 0;
      }
      if (!ready) {
        setSaveStatus("saving");
        return;
      }
      const operation = {
        sent: new Map(drafts),
        replace: replacePending,
        waiters: queuedWaiters,
        internal: pendingInternal,
        generation: valueGeneration
      };
      for (const waiter of operation.waiters) {
        if (waiter.returnPrevious) waiter.fallbackPrevious = structuredClone(values);
      }
      queuedWaiters = [];
      replacePending = false;
      pendingInternal = null;
      const mutation = mergeMutation(operation.sent, operation.replace, operation.internal?.mutation);
      const candidate = committedCandidate(operation.sent, operation.replace);
      let result;
      if (operation.internal?.receiptOnly) {
        try {
          result = operation.internal.onSaved?.();
        } catch (error) {
          saveFailed(error, operation);
          const exposed = operation.waiters.some((waiter) => waiter.exposed);
          if (!exposed) throw error;
          return void 0;
        }
        if (!isPromise(result)) {
          operation.ackGeneration = valueGeneration;
          finishSave(values, operation);
          return void 0;
        }
        activeSave = operation;
        setSaveStatus("saving");
        result.then(
          () => {
            operation.ackGeneration = valueGeneration;
            finishSave(values, operation);
          },
          (error) => saveFailed(error, operation)
        );
        return void 0;
      }
      try {
        const wantsPrevious = operation.waiters.some((waiter) => waiter.returnPrevious);
        const accountWrite = key !== STORAGE_KEY;
        if ((accountWrite || operation.internal?.receipt || operation.internal?.copyAll) && storage.migrate) {
          operation.atomicMigration = true;
          operation.detailed = wantsPrevious && Boolean(storage.migrateDetailed);
          const migrationOptions = {
            sourceKey: operation.internal?.sourceKey ?? (accountWrite ? accountSource(storage.get) : void 0),
            sourceDoneKey: operation.internal?.sourceDoneKey ?? (accountWrite ? `${accountSource(storage.get)}.migrated` : void 0)
          };
          const atomicMutation = accountWrite && !Object.hasOwn(mutation, "initialize") ? { ...mutation, initialize: {} } : mutation;
          result = operation.detailed ? storage.migrateDetailed(key, atomicMutation, doneKey, operation.internal?.receipt ?? [], migrationOptions) : storage.migrate(key, atomicMutation, doneKey, operation.internal?.receipt ?? [], migrationOptions);
        } else if (wantsPrevious && storage.mutateDetailed) {
          operation.detailed = true;
          result = storage.mutateDetailed(key, mutation);
        } else {
          result = storage.mutate ? storage.mutate(key, mutation) : (storage.set(key, candidate), candidate);
        }
      } catch (error) {
        if (operation.internal) pendingInternal = operation.internal;
        discardOperation(operation);
        log?.error("Could not save settings", error);
        setSaveStatus("idle");
        const exposed = operation.waiters.some((waiter) => waiter.exposed);
        rejectWaiters(operation.waiters, error);
        if (exposed) return;
        throw error;
      }
      if (!isPromise(result)) {
        const committed = operation.detailed ? result.value : storage.mutate ? result : candidate;
        saveSucceeded(
          committed,
          operation,
          operation.detailed ? result.previous : void 0,
          operation.detailed ? result.completedBefore : void 0
        );
        return void 0;
      }
      activeSave = operation;
      setSaveStatus("saving");
      result.then(
        (committed) => saveSucceeded(
          operation.detailed ? committed.value : committed,
          operation,
          operation.detailed ? committed.previous : void 0,
          operation.detailed ? committed.completedBefore : void 0
        ),
        (error) => saveFailed(error, operation)
      );
    }
    function requestSave(options) {
      const waiter = makeWaiter(options);
      queuedWaiters.push(waiter);
      try {
        flush();
      } catch (error) {
        waiter.pending = false;
        throw error;
      }
      if (!waiter.pending) return waiter.value;
      waiter.exposed = true;
      return waiter.promise;
    }
    function retrySave() {
      if (pendingInternal?.conflicts) delete pendingInternal.conflicts;
      return requestSave();
    }
    function waitForActiveSave() {
      const waiter = makeWaiter();
      waiter.exposed = true;
      activeSave.waiters.push(waiter);
      return waiter.promise;
    }
    function queuePatch(next, keys) {
      stageAccountReinitialization();
      const internallyOwned = /* @__PURE__ */ new Set();
      for (const name of keys) {
        for (const internal of [pendingInternal, activeSave?.internal]) {
          const mutation = internal?.mutation;
          if (internal?.fields?.includes(name) || Object.hasOwn(mutation?.set ?? {}, name) || mutation?.remove?.includes(name) || Object.hasOwn(mutation ?? {}, "initialize") || Object.hasOwn(mutation ?? {}, "replace")) internallyOwned.add(name);
          if (internal?.mutation?.conditions) delete internal.mutation.conditions[name];
          if (internal?.mutation?.guard) delete internal.mutation.guard[name];
          if (internal?.mutation?.guarded) {
            internal.mutation.guarded = internal.mutation.guarded.filter((item) => item !== name);
          }
          if (internal?.mutation?.migrationOwners) delete internal.mutation.migrationOwners[name];
          if (internal?.fields) internal.fields = internal.fields.filter((item) => item !== name);
          if (internal?.migrationValues) delete internal.migrationValues[name];
          if (internal?.migrationValueOwners) delete internal.migrationValueOwners[name];
        }
      }
      const joinsActive = activeSave && keys.length > 0 && keys.every((name) => !internallyOwned.has(name) && !drafts.has(name) && activeSave.sent.has(name) && sameValue(savedValue(next, name), activeSave.sent.get(name)));
      if (joinsActive) return waitForActiveSave();
      const unchanged = [];
      let needsSave = false;
      for (const name of keys) {
        const wanted = savedValue(next, name);
        const inFlight = activeSave?.sent.has(name);
        if (ready && !inFlight && sameValue(wanted, savedValue(values, name))) {
          if (replacePending || internallyOwned.has(name)) {
            drafts.set(name, wanted === REMOVED ? REMOVED : structuredClone(wanted));
            needsSave = true;
          } else drafts.delete(name);
          unchanged.push(name);
        } else {
          drafts.set(name, wanted === REMOVED ? REMOVED : structuredClone(wanted));
          needsSave = true;
        }
      }
      if (unchanged.length) notify(unchanged);
      if (!needsSave) {
        if (pendingInternal) return requestSave();
        flush();
        return void 0;
      }
      return requestSave();
    }
    function queueReplace(next, options) {
      drafts.clear();
      for (const [name] of schema) {
        const wanted = savedValue(next, name);
        drafts.set(name, wanted === REMOVED ? REMOVED : structuredClone(wanted));
      }
      replacePending = true;
      return requestSave(options);
    }
    function notify(keys, remote = false) {
      for (const listener of listeners) {
        try {
          listener({ keys, remote });
        } catch (error) {
          log?.error("A settings listener failed", error);
        }
      }
    }
    function spec(key2) {
      const found = schema.get(key2);
      if (!found) throw new Error(`Unknown setting: ${key2}`);
      return found;
    }
    storage.onChange?.(key, (raw, change) => {
      valueGeneration++;
      const accountRecordMissing = key !== STORAGE_KEY && !isSettingsRecord(raw);
      if (accountRecordMissing) {
        reinitializeAccountOnWrite = true;
        accountDeletionGeneration = valueGeneration;
      } else if (key !== STORAGE_KEY) reinitializeAccountOnWrite = false;
      const incoming = accountRecordMissing ? read2(storage.get) : raw;
      if (!ready) {
        if (change?.source === "load") return;
        const before2 = values;
        values = sanitize(incoming);
        const changed2 = changedKeys(before2, values);
        if (changed2.length) notify(changed2, true);
        return;
      }
      const before = values;
      values = sanitize(incoming);
      const changed = changedKeys(before, values);
      if (changed.length) notify(changed, true);
    });
    if (!ready) storage.whenReady(loadSavedSettings);
    const startupStatus = () => {
      if (ready) return "ready";
      return storage.status?.().state === "error" ? "error" : "loading";
    };
    const startup = {
      status: startupStatus,
      onStatus(listener) {
        if (storage.onStatus) return storage.onStatus(() => listener(startupStatus()));
        listener(startupStatus());
        return () => {
        };
      },
      matchesAccount: (candidate) => candidate === account
    };
    function get(key2) {
      if (key2 === "paused" && tabPaused) return true;
      return Object.hasOwn(values, key2) ? values[key2] : spec(key2).default;
    }
    function pageLoadValue(key2) {
      return Object.hasOwn(pageLoadValues, key2) ? pageLoadValues[key2] : spec(key2).default;
    }
    return {
      schema,
      perAccount: key !== STORAGE_KEY,
      tabPaused,
      startup,
      // Runs once the saved choices are in: at once from a userscript manager, a few
      // milliseconds in from the extension's storage. For decisions made only as the page starts.
      whenLoaded: (run) => storage.whenReady ? storage.whenReady(run) : run(),
      get,
      display: shownValue,
      pageLoadValue,
      saveStatus,
      onSaveStatus(listener) {
        saveListeners.add(listener);
        tellSaveStatus(listener);
        return () => saveListeners.delete(listener);
      },
      retry: retrySave,
      set(key2, value) {
        const found = spec(key2);
        if (!isValid(found, value)) throw new TypeError(`Invalid value for ${key2}`);
        const next = { ...values };
        if (value === found.default) delete next[key2];
        else next[key2] = value;
        return queuePatch(next, [key2]);
      },
      setMany(entries) {
        const next = { ...values };
        const keys = [];
        for (const [name, value] of Object.entries(entries)) {
          const found = spec(name);
          if (!isValid(found, value)) throw new TypeError(`Invalid value for ${name}`);
          if (value === found.default) delete next[name];
          else next[name] = value;
          keys.push(name);
        }
        return queuePatch(next, keys);
      },
      // A feature runs only when it's switched on and the whole script isn't paused.
      enabled(featureId) {
        return ready && get("paused") !== true && get(featureId) === true;
      },
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      },
      snapshot: () => structuredClone(values),
      restore(snapshot) {
        return queueReplace(sanitize(snapshot));
      },
      reset() {
        const previous = structuredClone(values);
        const kept = Object.fromEntries(KEPT_ON_RESET.filter((key2) => Object.hasOwn(values, key2)).map((key2) => [key2, values[key2]]));
        return queueReplace(kept, { returnPrevious: true, fallbackPrevious: previous });
      },
      exportJson(now = /* @__PURE__ */ new Date()) {
        return JSON.stringify({ app: "HushFacebook Web", schema: EXPORT_SCHEMA, version: version2, exported: now.toISOString(), settings: values }, null, 2);
      },
      importJson(text) {
        if (typeof text !== "string") throw new TypeError("Choose a JSON settings file");
        if (text.length > MAX_BACKUP_BYTES || new TextEncoder().encode(text).length > MAX_BACKUP_BYTES) {
          throw new TypeError("Choose a settings file smaller than 1 MB");
        }
        const parsed = JSON.parse(text);
        const wrapped = parsed && typeof parsed === "object" && ["app", "schema", "settings"].some((key2) => Object.hasOwn(parsed, key2));
        if (wrapped && (parsed.app !== "HushFacebook Web" || parsed.schema !== EXPORT_SCHEMA)) {
          throw new TypeError("Choose a HushFacebook Web backup in format 1");
        }
        const incoming = wrapped ? parsed.settings : parsed;
        if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) {
          throw new TypeError("That file has no HushFacebook Web settings in it");
        }
        const changed = { ...incoming };
        for (const migration of migrations) {
          if (olderThan(parsed.version, migration.before)) migration.run(changed);
        }
        if (wrapped) {
          const invalid = Object.keys(changed).filter((key2) => schema.has(key2) && !isValid(schema.get(key2), changed[key2]));
          if (invalid.length > 0) throw new TypeError(invalidBackupMessage(invalid, parsed.version));
        }
        const applied = [];
        const skipped = [];
        const next = wrapped ? {} : { ...values };
        for (const [key2, value] of Object.entries(changed)) {
          const found = schema.get(key2);
          if (!found || !isValid(found, value)) {
            skipped.push(key2);
            continue;
          }
          if (value === found.default) delete next[key2];
          else next[key2] = value;
          applied.push(key2);
        }
        if (applied.length === 0 && skipped.length > 0) throw new TypeError("None of the settings in that file work in this version, so nothing changed");
        const saved = wrapped ? queueReplace(sanitize(next)) : queuePatch(sanitize(next), applied);
        const result = { applied, skipped };
        return isPromise(saved) ? saved.then(() => result) : result;
      }
    };
  }

  // src/core/seen-store.js
  var SEEN_KEY = "seenPosts";
  var CLEARED_KEY = "seenPostsCleared";
  var DAY = 24 * 60 * 60 * 1e3;
  var MAX_AGE = 30 * DAY;
  var MAX_ENTRIES = 5e3;
  var SAVE_DELAY = 3e3;
  function parse(raw, cleared = 0) {
    const entries = /* @__PURE__ */ new Map();
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return entries;
    for (const [id, at] of Object.entries(raw)) {
      if (id && Number.isFinite(at) && at > 0 && at >= cleared) entries.set(id, at);
    }
    return entries;
  }
  var clearedAt = (raw) => Number.isFinite(raw) && raw > 0 ? raw : 0;
  function createSeenStore({
    storage,
    log,
    now = Date.now,
    maxAge = MAX_AGE,
    maxEntries = MAX_ENTRIES,
    schedule = setTimeout,
    cancel = clearTimeout,
    every = setInterval
  } = {}) {
    let entries = /* @__PURE__ */ new Map();
    let cleared = 0;
    let timer = null;
    let ready = !storage?.whenReady;
    let savedBeforeReady = false;
    const waiting = [];
    const dropListeners = [];
    const tell = (listeners, what) => {
      for (const run of listeners) {
        try {
          run();
        } catch (error) {
          log?.error(`A seen-post ${what} listener failed`, error);
        }
      }
    };
    const read2 = () => {
      let trimmed = false;
      try {
        const get = storage?.getAtLoad ? storage.getAtLoad.bind(storage) : storage?.get?.bind(storage);
        cleared = Math.max(cleared, clearedAt(get?.(CLEARED_KEY, 0)));
        trimmed = merge(parse(get?.(SEEN_KEY, null), cleared));
      } catch (error) {
        log?.error("Couldn't read the seen posts list, starting a new one", error);
      }
      ready = true;
      if (savedBeforeReady) {
        savedBeforeReady = false;
        save();
      } else if (trimmed) later2();
      tell(waiting.splice(0), "ready");
    };
    function merge(saved) {
      for (const [id, at] of saved) {
        const mine = entries.get(id);
        if (mine === void 0 || at < mine) entries.set(id, at);
      }
      prune();
      for (const id of saved.keys()) if (!entries.has(id)) return true;
      return false;
    }
    function save() {
      timer = null;
      if (!ready) savedBeforeReady = true;
      try {
        storage?.set(SEEN_KEY, Object.fromEntries(entries));
      } catch (error) {
        log?.error("Couldn't save the seen posts list", error);
      }
    }
    if (storage?.whenReady) storage.whenReady(read2);
    else read2();
    function later2() {
      if (timer === null) timer = schedule(save, SAVE_DELAY);
    }
    function prune() {
      const before = entries.size;
      const cutoff = now() - maxAge;
      for (const [id, at] of entries) if (at < cutoff) entries.delete(id);
      if (entries.size > maxEntries) {
        const newest = [...entries].sort((a, b) => b[1] - a[1]).slice(0, maxEntries);
        entries = new Map(newest);
      }
      return before - entries.size;
    }
    const daily = every?.(() => {
      if (prune()) later2();
    }, DAY);
    daily?.unref?.();
    storage?.onChange?.(SEEN_KEY, (raw) => {
      if (merge(parse(raw, cleared))) later2();
    });
    storage?.onChange?.(CLEARED_KEY, (raw) => {
      const at = clearedAt(raw);
      if (at <= cleared) return;
      cleared = at;
      for (const [id, seen] of entries) if (seen < cleared) entries.delete(id);
      tell(dropListeners, "drop");
    });
    storage?.onAccountChange?.(() => {
      entries.clear();
      if (timer !== null) cancel(timer);
      timer = null;
      savedBeforeReady = false;
      tell(dropListeners, "drop");
    });
    return {
      // Remembers ids not already known, keeping the first time each was seen.
      add(ids) {
        let added = false;
        for (const id of [ids].flat()) {
          if (!id || entries.has(id)) continue;
          entries.set(id, now());
          added = true;
        }
        if (added) {
          if (entries.size > maxEntries) prune();
          later2();
        }
        return added;
      },
      // The ids first seen at or after from (ms), and before until.
      since(from, until = Infinity) {
        const ids = /* @__PURE__ */ new Set();
        for (const [id, at] of entries) if (at >= from && at < until) ids.add(id);
        return ids;
      },
      has: (id) => entries.has(id),
      size: () => entries.size,
      whenReady(run) {
        if (ready) run();
        else waiting.push(run);
      },
      // Runs when posts leave the list without this tab asking: another tab forgot it, or the
      // page changed accounts.
      onDrop: (run) => dropListeners.push(run),
      clear() {
        cleared = Math.max(now(), cleared);
        entries.clear();
        if (timer !== null) cancel(timer);
        try {
          storage?.set(CLEARED_KEY, cleared);
        } catch (error) {
          log?.error("Couldn't save when the seen posts list was forgotten", error);
        }
        save();
      },
      // Writes now instead of waiting, for when the page is going away.
      flush() {
        if (timer === null) return;
        cancel(timer);
        save();
      }
    };
  }

  // src/core/activity.js
  var SPEED_KEY = "keepSpeed.rate";
  var VOLUME_KEY = "keepVolume.state";
  var POSITIONS_KEY = "resumeVideos.positions";
  var WATCHED_KEY = "rememberWatched.list";
  var MAX_POSITIONS = 200;
  var SIGNED_OUT = "signed-out";
  var ACTIVITY_KEYS = Object.freeze([SEEN_KEY, CLEARED_KEY, SPEED_KEY, VOLUME_KEY, POSITIONS_KEY, WATCHED_KEY]);
  var ACTIVITY = new Set(ACTIVITY_KEYS);
  var ACCOUNT_CHANGED = "The Facebook account on this page changed, so seen posts and video spots stop saving here until you reload";
  var activityKeyFor = (key, account) => `${key}@${account ? accountTag(account) : SIGNED_OUT}`;
  var isRecord = (value) => Boolean(value) && typeof value === "object" && !Array.isArray(value);
  var stamp = (value) => Number.isFinite(value) && value > 0 ? value : 0;
  var spotOf = (spot) => isRecord(spot) && Number.isFinite(spot.t) && Number.isFinite(spot.d) && Number.isFinite(spot.at) ? { t: spot.t, d: spot.d, at: spot.at } : null;
  function mergeSeen({ mine, mineCleared, theirs, theirsCleared, now }) {
    const merged = /* @__PURE__ */ new Map();
    const cutoff = now - MAX_AGE;
    const add = (raw, cleared) => {
      if (!isRecord(raw)) return;
      for (const [id, at] of Object.entries(raw)) {
        if (!id || !Number.isFinite(at) || at <= 0 || at < cleared || at < cutoff) continue;
        const known = merged.get(id);
        if (known === void 0 || at < known) merged.set(id, at);
      }
    };
    add(mine, stamp(mineCleared));
    add(theirs, Math.max(stamp(theirsCleared), stamp(mineCleared)));
    return Object.fromEntries([...merged].sort((a, b) => b[1] - a[1]).slice(0, MAX_ENTRIES));
  }
  function mergePositions(mine, theirs) {
    const merged = /* @__PURE__ */ new Map();
    for (const raw of [theirs, mine]) {
      if (!isRecord(raw)) continue;
      for (const [id, value] of Object.entries(raw)) {
        const spot = spotOf(value);
        if (!id || !spot) continue;
        if (!merged.has(id) || spot.at >= merged.get(id).at) merged.set(id, spot);
      }
    }
    return Object.fromEntries([...merged].sort((a, b) => b[1].at - a[1].at).slice(0, MAX_POSITIONS));
  }
  function createActivityStorage({ storage, account = null, currentAccount = () => account, onSwitch, log, now = Date.now }) {
    const keyOf = (key) => ACTIVITY.has(key) ? activityKeyFor(key, account) : key;
    const listeners = /* @__PURE__ */ new Map();
    const resets = [];
    let switched = false;
    function check() {
      if (switched) return false;
      if ((currentAccount() ?? null) === (account ?? null)) return true;
      switched = true;
      log?.warn(ACCOUNT_CHANGED);
      for (const reset of resets) {
        try {
          reset();
        } catch (error) {
          log?.error("A store couldn't let go of the old account's activity", error);
        }
      }
      try {
        onSwitch?.();
      } catch (error) {
        log?.error("Couldn't say that the account changed", error);
      }
      return false;
    }
    const read2 = (method) => (key, fallback) => ACTIVITY.has(key) && !check() ? fallback : method(keyOf(key), fallback);
    const write = (method, refused) => (key, ...rest) => {
      if (ACTIVITY.has(key) && !check()) return refused;
      return method(keyOf(key), ...rest);
    };
    const scoped = {
      ...storage,
      get: read2(storage.get),
      set: write(storage.set),
      remove: write(storage.remove),
      onChange(key, listener) {
        if (!ACTIVITY.has(key)) return storage.onChange?.(key, listener);
        listeners.set(key, [...listeners.get(key) ?? [], listener]);
        return storage.onChange?.(keyOf(key), (...args) => {
          if (!switched) listener(...args);
        });
      },
      // For a store that keeps the list in memory: run once the page belongs to someone else.
      onAccountChange(reset) {
        if (switched) reset();
        else resets.push(reset);
      }
    };
    if (storage.getAtLoad) scoped.getAtLoad = read2(storage.getAtLoad);
    for (const name of ["mutate", "mutateDetailed", "migrate", "migrateDetailed"]) {
      if (storage[name]) scoped[name] = write(storage[name], Promise.resolve(void 0));
    }
    function watch({ router, doc }) {
      router?.subscribe?.(() => check());
      doc?.addEventListener?.("visibilitychange", () => {
        if (doc.visibilityState === "visible") check();
      });
    }
    const shared = (key) => storage.get(key, void 0);
    const own = (key) => storage.get(keyOf(key), void 0);
    const count = (value) => isRecord(value) ? Object.keys(value).length : 0;
    function legacy() {
      const from = Math.max(stamp(shared(CLEARED_KEY)), now() - MAX_AGE);
      const seen = Object.values(isRecord(shared(SEEN_KEY)) ? shared(SEEN_KEY) : {}).filter((at) => Number.isFinite(at) && at > 0 && at >= from).length;
      const found = {
        seen,
        spots: count(shared(POSITIONS_KEY)),
        speed: shared(SPEED_KEY) !== void 0,
        volume: shared(VOLUME_KEY) !== void 0
      };
      return found.seen || found.spots || found.speed || found.volume ? found : null;
    }
    function addLegacy() {
      if (!check()) throw new Error(ACCOUNT_CHANGED);
      if (storage.status && storage.status().state !== "ready") throw new Error("Saved activity hasn't loaded yet. Try again in a moment");
      const next = /* @__PURE__ */ new Map();
      if (count(shared(SEEN_KEY))) {
        next.set(SEEN_KEY, mergeSeen({ mine: own(SEEN_KEY), mineCleared: own(CLEARED_KEY), theirs: shared(SEEN_KEY), theirsCleared: shared(CLEARED_KEY), now: now() }));
      }
      if (count(shared(POSITIONS_KEY))) next.set(POSITIONS_KEY, mergePositions(own(POSITIONS_KEY), shared(POSITIONS_KEY)));
      for (const key of [SPEED_KEY, VOLUME_KEY]) {
        if (shared(key) !== void 0 && own(key) === void 0) next.set(key, shared(key));
      }
      for (const [key, value] of next) {
        storage.set(keyOf(key), value);
        for (const listener of listeners.get(key) ?? []) {
          try {
            listener(structuredClone(value), { source: "import" });
          } catch (error) {
            log?.error("A storage listener failed", error);
          }
        }
      }
      return next.size;
    }
    function clearLegacy() {
      const removed = /* @__PURE__ */ new Map();
      for (const key of ACTIVITY_KEYS) {
        const value = shared(key);
        if (value === void 0) continue;
        removed.set(key, value);
        storage.remove(key);
      }
      return () => {
        for (const [key, value] of removed) if (shared(key) === void 0) storage.set(key, value);
      };
    }
    return {
      storage: scoped,
      check,
      watch,
      switched: () => switched,
      perAccount: Boolean(account),
      legacy,
      addLegacy,
      clearLegacy
    };
  }

  // src/core/diagnostics.js
  var DECISIONS = 50;
  function postTag(id, salt = "") {
    if (id === null || id === void 0 || id === "") return "no id yet";
    let hash = 2166136261;
    for (const char of `${salt}${id}`) {
      hash ^= char.charCodeAt(0);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return `#${hash.toString(36).padStart(6, "0").slice(-6)}`;
  }
  function createDiagnostics({ now = () => Date.now() } = {}) {
    const rows = /* @__PURE__ */ new Map();
    const statuses = /* @__PURE__ */ new Map();
    const listeners = /* @__PURE__ */ new Set();
    const decisions = [];
    function changed() {
      for (const listener of listeners) {
        try {
          listener();
        } catch {
        }
      }
    }
    return {
      add(label, read2, { shareable = false } = {}) {
        rows.set(label, { read: read2, shareable: shareable === true });
        changed();
        return () => {
          rows.delete(label);
          changed();
        };
      },
      rows() {
        return [...rows].map(([label, { read: read2, shareable }]) => {
          let value;
          try {
            value = String(read2());
          } catch (error) {
            return { label, value: `unavailable (${error?.message ?? error})`, shareable: false };
          }
          return { label, value, shareable };
        });
      },
      // read() returns the line's text, or null for none.
      status(featureId, read2) {
        statuses.set(featureId, read2);
        changed();
      },
      statusOf(featureId) {
        const read2 = statuses.get(featureId);
        if (!read2) return null;
        try {
          const value = read2();
          return value === null || value === void 0 || value === "" ? null : String(value);
        } catch {
          return null;
        }
      },
      hasStatus: (featureId) => statuses.has(featureId),
      // layer: 'data' when it came out of Facebook's data, 'page' when it was hidden on the page.
      decide({ post, rule, signal, detail, layer }) {
        const text = (value) => value === null || value === void 0 ? "" : String(value);
        decisions.push({
          time: new Date(now()).toISOString().slice(11, 19),
          id: post === null || post === void 0 || post === "" ? null : String(post),
          post: postTag(post),
          rule: String(rule),
          signal: text(signal),
          detail: text(detail),
          layer: layer === "data" ? "data" : "page"
        });
        if (decisions.length > DECISIONS) decisions.splice(0, decisions.length - DECISIONS);
        changed();
      },
      // Oldest first.
      decisions: () => decisions.map((decision) => ({ ...decision })),
      changed,
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      }
    };
  }
  var hideListener = (diagnostics, idOf) => ({ element, reason, detail, signal }) => diagnostics.decide({ post: idOf(element).id, rule: reason, signal, detail, layer: "page" });
  var decisionLine = ({ time, layer, post, rule, signal, detail }) => `${time} ${layer.padEnd(4)} ${post} ${rule}${signal || detail ? `: ${signal || detail}` : ""}`;

  // src/core/dom/posts.js
  var CANDIDATE_SELECTOR = '[aria-posinset]:not([role]), [role="article"]';
  var ID_RUNGS = [
    { source: "permalink", re: /\/(?:posts|permalink)\/(pfbid0[A-Za-z0-9]+|\d+)/ },
    { source: "pfbid", re: /(pfbid0[A-Za-z0-9]+)/ },
    { source: "story_fbid", re: /[?&]story_fbid=(pfbid0[A-Za-z0-9]+|\d+)/ }
  ];
  var COMMENT_ID = /[?&](?:reply_comment_id|comment_id)=(\d+)/;
  var COMMENT_PARAM = /([?&])(?:reply_comment_id|comment_id)=\d+(&|$)/;
  var COMMENT_LABEL = /^(?:comment|reply) by /i;
  var FACEBOOK_LINK = /^(?:\/(?!\/)|\?|(?:https?:)?\/\/(?:(?:www|web|m|mbasic|[a-z]{2}-[a-z]{2})\.)?facebook\.com(?::443)?(?:\/|$))/i;
  var MESSAGE_REGION = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"]';
  var LOADING = '[role="progressbar"], [data-visualcompletion="loading-state"]';
  var ownerOf = (node) => node.closest(CANDIDATE_SELECTOR);
  function ownLinks(element) {
    return [...element.querySelectorAll("a[href]")].filter((a) => ownerOf(a) === element);
  }
  function withoutCommentParams(href) {
    let previous;
    do {
      previous = href;
      href = href.replace(COMMENT_PARAM, (match, lead, tail) => tail ? lead : "");
    } while (href !== previous);
    return href;
  }
  function postIdFromHrefs(hrefs) {
    const links = hrefs.filter((href) => FACEBOOK_LINK.test(href));
    const withoutComments = links.map(withoutCommentParams);
    for (const { source, re } of ID_RUNGS) {
      for (const href of withoutComments) {
        const found = href.match(re);
        if (found) return { id: found[1], source };
      }
    }
    for (const href of links) {
      const found = href.match(COMMENT_ID);
      if (found) return { id: found[1], source: "comment_id" };
    }
    return { id: null, source: null };
  }
  function idHrefs(element) {
    return ownLinks(element).filter((a) => {
      const region = a.closest(MESSAGE_REGION);
      return !region || !element.contains(region);
    }).map((a) => a.getAttribute("href"));
  }
  function postIdOf(element) {
    return postIdFromHrefs(idHrefs(element));
  }
  function isComment(element) {
    if (element.getAttribute("role") !== "article") return false;
    if (COMMENT_LABEL.test(element.getAttribute("aria-label") ?? "")) return true;
    return ownLinks(element).some((a) => COMMENT_ID.test(a.getAttribute("href")));
  }
  function classifyCandidate(element) {
    if (!element.isConnected) return { ok: false, reason: "detached", retry: false };
    if (element.parentElement && ownerOf(element.parentElement)) return { ok: false, reason: "nested", retry: false };
    if (element.closest("form")) return { ok: false, reason: "form", retry: false };
    if (isComment(element)) return { ok: false, reason: "comment", retry: false };
    const hasLinks = element.querySelector("a[href]") !== null;
    if (!hasLinks && element.querySelector(LOADING)) return { ok: false, reason: "loading", retry: true };
    if (!hasLinks && !element.textContent.trim() && !element.querySelector("img, video, svg")) return { ok: false, reason: "empty", retry: true };
    return { ok: true, kind: element.hasAttribute("aria-posinset") ? "feed" : "article" };
  }
  function createPostTracker({ doc = globalThis.document, log } = {}) {
    let processed = /* @__PURE__ */ new WeakSet();
    const live = /* @__PURE__ */ new Map();
    const listeners = { "post/add": /* @__PURE__ */ new Set(), "post/update": /* @__PURE__ */ new Set(), "post/remove": /* @__PURE__ */ new Set(), reset: /* @__PURE__ */ new Set() };
    let observer = null;
    function call(type, listener, payload) {
      try {
        listener(payload);
      } catch (error) {
        log?.error(`A ${type} listener failed`, error);
      }
    }
    function emit(type, payload) {
      for (const listener of listeners[type]) call(type, listener, payload);
    }
    function remove(element, post) {
      live.delete(element);
      processed.delete(element);
      emit("post/remove", post);
    }
    function recheck(element) {
      const post = live.get(element);
      const hrefs = idHrefs(element);
      const { id, source } = postIdFromHrefs(hrefs);
      if (id === post.id || id === null) return;
      if (post.id === null) {
        post.id = id;
        post.idSource = source;
        emit("post/update", post);
        return;
      }
      if (post.idSource === "comment_id" && source !== "comment_id" && hrefs.some((href) => href.includes(post.id))) {
        post.id = id;
        post.idSource = source;
        emit("post/update", post);
        return;
      }
      if (hrefs.some((href) => href.includes(post.id))) return;
      remove(element, post);
      add(element, post.kind);
    }
    function add(element, kind) {
      for (const inner of element.querySelectorAll(CANDIDATE_SELECTOR)) {
        const nested = live.get(inner);
        if (!nested) continue;
        remove(inner, nested);
        processed.add(inner);
      }
      const { id, source } = postIdOf(element);
      const post = { element, kind, id, idSource: source };
      processed.add(element);
      live.set(element, post);
      emit("post/add", post);
    }
    function consider(element) {
      if (processed.has(element)) {
        if (live.has(element)) recheck(element);
        return;
      }
      const verdict = classifyCandidate(element);
      if (verdict.ok) add(element, verdict.kind);
    }
    function collect(root, found) {
      if (root.nodeType !== 1) root = root.parentElement;
      if (!root?.isConnected) return;
      const owner = ownerOf(root);
      if (owner) found.add(owner);
      for (const element of root.querySelectorAll(CANDIDATE_SELECTOR)) found.add(element);
    }
    function scan(root) {
      const found = /* @__PURE__ */ new Set();
      collect(root, found);
      for (const element of found) consider(element);
    }
    function sweepRemovals() {
      if (!live.size) return;
      for (const [element, post] of [...live]) if (!element.isConnected) remove(element, post);
      if (!live.size) emit("reset", void 0);
    }
    function release(element, found) {
      const post = live.get(element);
      if (!post || element.matches(CANDIDATE_SELECTOR)) return;
      remove(element, post);
      for (const inner of element.querySelectorAll(CANDIDATE_SELECTOR)) {
        processed.delete(inner);
        found.add(inner);
      }
    }
    function onMutations(records) {
      let removals = false;
      const found = /* @__PURE__ */ new Set();
      for (const record of records) {
        if (record.removedNodes.length) removals = true;
        if (record.addedNodes.length) for (const node of record.addedNodes) collect(node, found);
        else if (record.type === "attributes") {
          release(record.target, found);
          collect(record.target, found);
        }
      }
      if (removals) sweepRemovals();
      for (const element of found) if (element.isConnected) consider(element);
    }
    function start() {
      if (observer) return;
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      observer = new Observer((records) => {
        try {
          onMutations(records);
        } catch (error) {
          log?.error("Reading new posts failed", error);
        }
      });
      const begin = () => {
        if (!observer) return;
        observer.observe(doc.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["href", "aria-posinset", "role"] });
        scan(doc.documentElement);
      };
      whenRootReady(begin, doc);
    }
    return {
      // type: 'post/add' | 'post/update' | 'post/remove' | 'reset'. Returns an unsubscribe.
      // A post/add listener that joins late hears about the posts already on the page first.
      on(type, listener) {
        if (!listeners[type]) throw new Error(`Unknown post event: ${type}`);
        listeners[type].add(listener);
        if (!observer) start();
        else if (type === "post/add") for (const post of [...live.values()]) call(type, listener, post);
        return () => listeners[type].delete(listener);
      },
      current: () => [...live.values()],
      // Stops watching and forgets every post. A later on() starts over and reports them again.
      stop() {
        observer?.disconnect();
        observer = null;
        live.clear();
        processed = /* @__PURE__ */ new WeakSet();
      }
    };
  }

  // src/core/dom/hide.js
  var MARK = "data-hfw-hide";
  var NOTE = "data-hfw-note";
  var HELD = "data-hfw-held";
  var HOLDER = `:has(> [${MARK}])`;
  var REPLACED = /* @__PURE__ */ new Set(["IMG", "VIDEO", "IFRAME", "CANVAS", "INPUT", "TEXTAREA", "SELECT", "OBJECT", "EMBED", "svg", "STYLE", "SCRIPT", "TEMPLATE", "LINK", "META"]);
  var BUTTON = ["role", "tabindex", "aria-label"];
  var FOCUSABLE = 'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"]), [contenteditable="true"]';
  function hideCss({ notes }) {
    if (!notes) return `${HOLDER} { display: none !important; }`;
    return [
      `${HOLDER} > :not([${MARK}]) { display: none !important; }`,
      `[${MARK}] > * { display: none !important; }`,
      // Loose text right inside the mark has no element to hide, so it shrinks to nothing.
      `[${MARK}] { font-size: 0 !important; }`,
      // Facebook's mark is a display:contents wrapper, which can't take focus.
      `[${MARK}] { display: block !important; border-radius: 6px; }`,
      `[${MARK}]::before { content: attr(${NOTE}); display: block; padding: 12px 16px; border: 1px solid #343745; border-radius: 6px; background: #171923; font: 600 13px/1.4 system-ui, sans-serif; color: #c4b0ff; cursor: pointer; }`,
      `[${MARK}]:hover::before { text-decoration: underline; }`,
      `[${MARK}]:focus-visible { outline: 2px solid #c4b0ff !important; outline-offset: 2px; }`,
      `[${HELD}] { display: block !important; }`
    ].join("\n");
  }
  var drawn = (element) => element.getClientRects().length > 0;
  function createHider({ doc = globalThis.document, posts, log, notesShown = () => true, onHide } = {}) {
    const counts = /* @__PURE__ */ new Map();
    const countedIds = /* @__PURE__ */ new Set();
    const countedElements = /* @__PURE__ */ new WeakSet();
    const revealed = /* @__PURE__ */ new WeakSet();
    const marks = /* @__PURE__ */ new WeakSet();
    const labels = /* @__PURE__ */ new WeakMap();
    const prior = /* @__PURE__ */ new WeakMap();
    const listeners = /* @__PURE__ */ new Set();
    let watching = false;
    let pressed = null;
    const markOf = (element) => [...element.children].find((child2) => child2.hasAttribute(MARK)) ?? null;
    function notify() {
      for (const listener of listeners) {
        try {
          listener();
        } catch (error) {
          log?.error("A hidden-post listener failed", error);
        }
      }
    }
    function asButton(marker) {
      if (!prior.has(marker)) prior.set(marker, BUTTON.map((name) => marker.getAttribute(name)));
      marker.setAttribute("role", "button");
      marker.setAttribute("tabindex", "0");
      marker.setAttribute("aria-label", marker.getAttribute(NOTE));
    }
    function notButton(marker) {
      const values = prior.get(marker);
      if (!values) return;
      prior.delete(marker);
      BUTTON.forEach((name, i) => values[i] === null ? marker.removeAttribute(name) : marker.setAttribute(name, values[i]));
    }
    function clear(element) {
      for (const child2 of element.children) {
        if (!child2.hasAttribute(MARK)) continue;
        notButton(child2);
        child2.removeAttribute(MARK);
        child2.removeAttribute(NOTE);
        labels.delete(child2);
      }
    }
    function write(marker, reasons) {
      marker.setAttribute(MARK, [...reasons.keys()].join(" "));
      marker.setAttribute(NOTE, `Hidden: ${reasons.values().next().value}. Show`);
      if (notesShown()) asButton(marker);
      else notButton(marker);
    }
    function reasonsOf(marker) {
      let reasons = labels.get(marker);
      if (!reasons) {
        reasons = new Map((marker.getAttribute(MARK) ?? "").split(/\s+/).filter(Boolean).map((reason) => [reason, reason]));
        labels.set(marker, reasons);
      }
      return reasons;
    }
    function unmark(marker, reason) {
      const reasons = reasonsOf(marker);
      if (!reasons.delete(reason)) return;
      if (reasons.size) write(marker, reasons);
      else if (marker.parentElement) clear(marker.parentElement);
    }
    function count(element, reason) {
      const id = postIdOf(element).id;
      const seen = countedElements.has(element) || id !== null && countedIds.has(id);
      countedElements.add(element);
      if (id !== null) countedIds.add(id);
      if (seen) return false;
      counts.set(reason, (counts.get(reason) ?? 0) + 1);
      return true;
    }
    function watchRecycling() {
      if (watching || !posts) return;
      watching = true;
      posts.on("post/remove", ({ element }) => {
        revealed.delete(element);
        countedElements.delete(element);
        if (element.isConnected) clear(element);
      });
    }
    const isNote = (target2) => Boolean(target2?.hasAttribute?.(MARK) && marks.has(target2) && notesShown() && target2.parentElement);
    function reveal(marker) {
      const post = marker.parentElement;
      const focused = doc.activeElement === marker;
      revealed.add(post);
      clear(post);
      if (!focused) return;
      for (const control of post.querySelectorAll(FOCUSABLE)) {
        if (!drawn(control)) continue;
        control.focus({ preventScroll: true });
        if (doc.activeElement === control) return;
      }
      const own = marker.getAttribute("tabindex");
      const release = () => {
        marker.removeAttribute(HELD);
        if (own === null) marker.removeAttribute("tabindex");
        else marker.setAttribute("tabindex", own);
      };
      marker.setAttribute(HELD, "");
      marker.setAttribute("tabindex", "-1");
      marker.focus({ preventScroll: true });
      if (doc.activeElement === marker) marker.addEventListener("blur", release, { once: true });
      else release();
    }
    function stop(event) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
    function onClick(event) {
      if (!isNote(event.target)) return;
      stop(event);
      reveal(event.target);
    }
    function onKeyDown(event) {
      if (event.key !== "Enter" && event.key !== " " || event.altKey || event.ctrlKey || event.metaKey || !isNote(event.target)) return;
      stop(event);
      if (event.key === "Enter") reveal(event.target);
      else pressed = event.target;
    }
    function onKeyUp(event) {
      if (event.key !== " " || pressed === null) return;
      const marker = pressed;
      pressed = null;
      if (event.target !== marker || !isNote(marker)) return;
      stop(event);
      reveal(marker);
    }
    doc.addEventListener("click", onClick, true);
    doc.addEventListener("keydown", onKeyDown, true);
    doc.addEventListener("keyup", onKeyUp, true);
    return {
      // Hides a post found by the post tracker. reason is what Diagnostics counts
      // ("Sponsored", "Filter"); detail narrows it in the note ("Filter: cats"). signal says
      // what matched, for the decision list only, when detail doesn't already say it.
      // Returns false when the post can't be marked or the person chose to see it.
      hide(element, reason, detail, signal) {
        if (revealed.has(element)) return false;
        const marker = markOf(element) ?? element.firstElementChild;
        if (!marker || REPLACED.has(marker.tagName)) return false;
        watchRecycling();
        const reasons = marker.hasAttribute(MARK) ? reasonsOf(marker) : /* @__PURE__ */ new Map();
        const fresh = !reasons.has(reason);
        reasons.set(reason, detail ? `${reason}: ${detail}` : reason);
        labels.set(marker, reasons);
        write(marker, reasons);
        marks.add(marker);
        if (count(element, reason)) notify();
        if (fresh && onHide) {
          try {
            onHide({ element, reason, detail, signal });
          } catch (error) {
            log?.error("Noting a hidden post failed", error);
          }
        }
        return true;
      },
      // Shows the post again. With a reason, takes only that one off, for a post that no longer
      // fits it: one still hidden for another reason stays hidden, under that one.
      show(element, reason) {
        if (reason === void 0) clear(element);
        else {
          const marker = markOf(element);
          if (marker) unmark(marker, reason);
        }
      },
      // Takes one reason off every post, for a feature that was just switched off.
      showAll(reason) {
        for (const marker of doc.querySelectorAll(`[${MARK}]`)) unmark(marker, reason);
      },
      // Makes each note a button again, or not, after pausing or the note setting changed.
      refresh() {
        const shown4 = notesShown();
        for (const marker of doc.querySelectorAll(`[${MARK}]`)) {
          if (!marks.has(marker)) continue;
          if (shown4) asButton(marker);
          else notButton(marker);
        }
      },
      isHidden: (element) => markOf(element) !== null,
      // Posts hidden since the page loaded, per reason.
      counts: () => Object.fromEntries(counts),
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      }
    };
  }

  // src/core/load-watchdog.js
  var TAB_PAUSE_KEY = "hfw:pausedTab";
  var LOAD_WAIT_MS = 2e4;
  var CONFIRM_MS = 3e3;
  function readTabPause(win) {
    try {
      return win.sessionStorage?.getItem(TAB_PAUSE_KEY) === "1";
    } catch {
      return false;
    }
  }
  function setTabPause(win, on) {
    if (on) win.sessionStorage.setItem(TAB_PAUSE_KEY, "1");
    else win.sessionStorage.removeItem(TAB_PAUSE_KEY);
  }
  var GROUP_PAGES = /* @__PURE__ */ new Set(["discover", "joins", "create", "notifications", "search", "category", "browse", "you"]);
  function feedKind(route) {
    if (route.permalink) return null;
    if (route.type === "home") return "home";
    const parts = new URL(route.href).pathname.split("/").filter(Boolean);
    return parts[0] === "groups" && parts.length === 2 && !GROUP_PAGES.has(parts[1]) ? "group" : null;
  }
  var shown = (element) => element.isConnected && (element.checkVisibility?.() ?? true);
  var LOADING2 = '[data-visualcompletion="loading-state"], [role="progressbar"]';
  var UNIT = '[aria-posinset], [role="article"]';
  var loadingSign = (element) => {
    if (element.matches('[data-visualcompletion="loading-state"]')) return true;
    const unit = element.closest(UNIT);
    return !unit?.querySelector("a[href]");
  };
  function stillLoading(doc, win) {
    const splash = doc.getElementById("splash-screen");
    if (splash && shown(splash)) return true;
    if ((win.scrollY || 0) >= win.innerHeight) return false;
    const scope = [...doc.querySelectorAll('[role="main"]')].find(shown) ?? doc;
    return [...scope.querySelectorAll(LOADING2)].some((card) => {
      if (!shown(card) || !loadingSign(card)) return false;
      const { top, bottom } = card.getBoundingClientRect();
      return top < win.innerHeight && bottom >= 0;
    });
  }
  function watchFeedLoads({ win, doc, router, signedIn, paused, onStuck, log, wait = LOAD_WAIT_MS }) {
    let timer = null;
    let fired = false;
    let state = "idle";
    const seconds = Math.round(wait / 1e3);
    const away = () => doc.hidden || win.navigator?.onLine === false;
    function arm() {
      win.clearTimeout(timer);
      timer = null;
      if (fired) return;
      if (!feedKind(router.current())) {
        state = "idle";
        return;
      }
      if (away()) {
        state = "held";
        return;
      }
      state = "waiting";
      timer = win.setTimeout(() => check(false), wait);
    }
    function check(second) {
      timer = null;
      const kind = feedKind(router.current());
      if (fired || !kind) return;
      if (away()) {
        state = "held";
        return;
      }
      if (!signedIn() || paused()) {
        state = "skipped";
        return;
      }
      if (!stillLoading(doc, win)) {
        state = "loaded";
        return;
      }
      if (!second) {
        timer = win.setTimeout(() => check(true), CONFIRM_MS);
        return;
      }
      fired = true;
      state = "stuck";
      const where = kind === "home" ? "Home" : "A group's feed";
      log?.warn(`${where} was still loading ${seconds} seconds after it opened`);
      onStuck(kind);
    }
    const follow = () => {
      if (fired) return;
      if (!away()) {
        if (state === "held") arm();
        return;
      }
      if (state !== "waiting") return;
      win.clearTimeout(timer);
      timer = null;
      state = "held";
    };
    doc.addEventListener("visibilitychange", follow);
    win.addEventListener("online", follow);
    win.addEventListener("offline", follow);
    router.subscribe(arm);
    if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", arm, { once: true });
    else arm();
    return {
      status: () => ({
        idle: "Not on a feed",
        waiting: `Checks the feed ${seconds} seconds after it opens`,
        held: "Waiting for the tab to be visible and online",
        skipped: "Not checked while signed out or paused",
        loaded: "Nothing was still loading",
        stuck: `Still loading ${seconds} seconds after the feed opened`
      })[state]
    };
  }

  // src/core/net/payload.js
  var DROP = /* @__PURE__ */ Symbol("hfw.drop");
  var GUARD = "for (;;);";
  function rulesFor(text, rules) {
    return rules.filter((rule) => !rule.markers || rule.markers.some((marker) => text.includes(marker)));
  }
  var FAILED = /* @__PURE__ */ Symbol("hfw.failed");
  function later(stage, effect) {
    if (stage) stage.defer(effect);
    else effect();
  }
  function applyRules(doc, rules, ctx, onError) {
    const effects = [];
    const undos = [];
    let current = null;
    const stage = {
      defer: (effect) => effects.push([current, effect]),
      undo: (restore) => undos.push([current, restore])
    };
    let changed = false;
    for (const rule of rules) {
      if (rule.observe) continue;
      current = rule;
      let result;
      try {
        result = rule.transform(doc, ctx, stage);
      } catch (error) {
        onError?.(rule, error);
        settle(undos.reverse(), onError);
        return FAILED;
      }
      if (result === DROP) {
        settle(effects, onError);
        return DROP;
      }
      if (result === true) changed = true;
    }
    settle(effects, onError);
    return changed;
  }
  function settle(steps, onError) {
    for (const [rule, step2] of steps) {
      try {
        step2();
      } catch (error) {
        onError?.(rule, error);
      }
    }
  }
  function observeRules(doc, rules, ctx, onError) {
    for (const rule of rules) {
      if (!rule.observe) continue;
      try {
        rule.transform(doc, ctx);
      } catch (error) {
        onError?.(rule, error);
      }
    }
  }
  function transformDocumentLine(line, allRules, ctx, onError, parse4 = JSON.parse) {
    const rules = rulesFor(line, allRules);
    if (!rules.length) return line;
    let prefix = "";
    let body = line;
    if (body.startsWith(GUARD)) {
      prefix = GUARD;
      body = body.slice(GUARD.length);
    }
    const first = body.trimStart()[0];
    if (first !== "{" && first !== "[") return line;
    let doc;
    try {
      doc = parse4(body);
    } catch {
      return line;
    }
    const result = applyRules(doc, rules, ctx, onError);
    if (result === DROP) return null;
    if (result === FAILED) {
      if (rules.some((rule) => rule.observe)) observeRules(parse4(body), rules, ctx, onError);
      return line;
    }
    observeRules(doc, rules, ctx, onError);
    return result ? prefix + JSON.stringify(doc) : line;
  }
  var LINE_LIMIT = 8 * 1024 * 1024;
  function createLineStream(transformLine, { limit = LINE_LIMIT, onBypass } = {}) {
    let pending = "";
    let passing = false;
    function emit(raw, newline) {
      if (raw.length > limit) {
        onBypass?.();
        return raw + newline;
      }
      const cr = raw.endsWith("\r") ? "\r" : "";
      const result = transformLine(cr ? raw.slice(0, -1) : raw);
      return result === null ? "" : result + cr + newline;
    }
    return {
      push(chunk) {
        let out = "";
        if (passing) {
          const end2 = chunk.indexOf("\n");
          if (end2 === -1) return chunk;
          passing = false;
          out = chunk.slice(0, end2 + 1);
          chunk = chunk.slice(end2 + 1);
        }
        const end = chunk.lastIndexOf("\n");
        if (end === -1) {
          pending += chunk;
        } else {
          const complete = pending + chunk.slice(0, end);
          pending = chunk.slice(end + 1);
          out += complete.split("\n").map((raw) => emit(raw, "\n")).join("");
        }
        if (pending.length > limit) {
          onBypass?.();
          out += pending;
          pending = "";
          passing = true;
        }
        return out;
      },
      // The end of the body. A stream isn't used again after it.
      flush() {
        const raw = pending;
        pending = "";
        return raw ? emit(raw, "") : "";
      },
      // How much of an unfinished line is held, in characters.
      get held() {
        return pending.length;
      }
    };
  }
  function friendlyNameOf(body, headers) {
    const header = headerValue(headers, "x-fb-friendly-name");
    if (header) return header;
    if (typeof body === "string") {
      if (!body.includes("fb_api_req_friendly_name")) return "";
      return new URLSearchParams(body).get("fb_api_req_friendly_name") ?? "";
    }
    if (body && typeof body.get === "function") return body.get("fb_api_req_friendly_name") ?? "";
    return "";
  }
  function headerValue(headers, name) {
    if (!headers) return "";
    if (typeof headers.get === "function") return headers.get(name) ?? "";
    if (Array.isArray(headers)) return headers.find(([key]) => key.toLowerCase() === name)?.[1] ?? "";
    for (const [key, value] of Object.entries(headers)) if (key.toLowerCase() === name) return value;
    return "";
  }

  // src/core/net/lightspeed.js
  var SHORT = /* @__PURE__ */ new Map([[9, 1], [10, 1], [14, 3]]);
  var WITH_BODY = /* @__PURE__ */ new Set([12, 13, 15]);
  var DATA = 13;
  function readFrames(bytes) {
    const frames = [];
    let at = 0;
    while (at < bytes.length) {
      const type = bytes[at];
      const size = SHORT.get(type);
      if (size) {
        if (at + size > bytes.length) return null;
        frames.push({ type, raw: bytes.subarray(at, at + size) });
        at += size;
        continue;
      }
      if (!WITH_BODY.has(type) || at + 6 > bytes.length) return null;
      const length = bytes[at + 3] | bytes[at + 4] << 8 | bytes[at + 5] << 16;
      if (at + 6 + length > bytes.length) return null;
      frames.push({ type, stream: bytes[at + 1] | bytes[at + 2] << 8, body: bytes.subarray(at + 6, at + 6 + length) });
      at += 6 + length;
    }
    return frames;
  }
  function writeFrames(frames) {
    const size = frames.reduce((sum, frame) => sum + (frame.raw ? frame.raw.length : 6 + frame.body.length), 0);
    const out = new Uint8Array(size);
    let at = 0;
    for (const frame of frames) {
      if (frame.raw) {
        out.set(frame.raw, at);
        at += frame.raw.length;
        continue;
      }
      const length = frame.body.length;
      out[at] = frame.type;
      out[at + 1] = frame.stream & 255;
      out[at + 2] = frame.stream >> 8 & 255;
      out[at + 3] = length & 255;
      out[at + 4] = length >> 8 & 255;
      out[at + 5] = length >> 16 & 255;
      out.set(frame.body, at + 6);
      at += 6 + length;
    }
    return out;
  }
  function frameJson(frame, decoder) {
    if (frame.type !== DATA || !frame.body || frame.body.length < 3 || frame.body[2] !== 123) return null;
    return decoder.decode(frame.body.subarray(2));
  }
  function withJson(frame, text, encoder) {
    const json = encoder.encode(text);
    const body = new Uint8Array(2 + json.length);
    body.set(frame.body.subarray(0, 2));
    body.set(json, 2);
    return { ...frame, body };
  }
  var BIG = "\0n:";
  var BIG_BACK = /"\\u0000n:(-?\d+)"/g;
  function protectBig(text) {
    let out = "";
    let last = 0;
    let at = 0;
    while (at < text.length) {
      const char = text[at];
      if (char === '"') {
        at++;
        while (at < text.length && text[at] !== '"') at += text[at] === "\\" ? 2 : 1;
        at++;
        continue;
      }
      if (char === "-" || char >= "0" && char <= "9") {
        let end = at + 1;
        while (end < text.length && "0123456789.eE+-".includes(text[end])) end++;
        const token = text.slice(at, end);
        if (/^-?\d{16,}$/.test(token) && !Number.isSafeInteger(Number(token))) {
          out += text.slice(last, at) + JSON.stringify(BIG + token);
          last = end;
        }
        at = end;
        continue;
      }
      at++;
    }
    return out + text.slice(last);
  }
  function writeJson(value) {
    return JSON.stringify(value).replace(BIG_BACK, "$1");
  }
  function readJson(text) {
    try {
      const value = JSON.parse(protectBig(text));
      return writeJson(value) === text ? value : null;
    } catch {
      return null;
    }
  }
  function readRequest(text) {
    const outer = readJson(text);
    if (!outer || typeof outer !== "object" || typeof outer.payload !== "string") return null;
    const payload = readJson(outer.payload);
    if (!payload || typeof payload !== "object") return null;
    return { outer, type: outer.type, payload };
  }
  function writeRequest(request) {
    return writeJson({ ...request.outer, payload: writeJson(request.payload) });
  }

  // src/core/net/websocket.js
  var LIGHTSPEED = /^wss:\/\/gateway\.facebook\.com\/ws\/lightspeed(?:[/?]|$)/;
  function bytesOf(data) {
    if (Object.prototype.toString.call(data) === "[object ArrayBuffer]") return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    return null;
  }
  function patchWebSocket(win, { log, startup }) {
    const rules = [];
    const failed = /* @__PURE__ */ new Set();
    const stats = { messages: 0, unreadable: 0 };
    const proto = win.WebSocket?.prototype;
    const original = proto?.send;
    const decoder = new (win.TextDecoder ?? TextDecoder)();
    const encoder = new (win.TextEncoder ?? TextEncoder)();
    const fail = (rule, error) => {
      if (failed.has(rule.id)) return;
      failed.add(rule.id);
      log.error(`Chat rule "${rule.id}" failed, so Facebook's message went out unchanged`, error);
    };
    function rewrite(bytes, active2) {
      const frames = readFrames(bytes);
      if (!frames) {
        stats.unreadable++;
        return null;
      }
      let changed = false;
      const out = frames.map((frame) => {
        const text = frameJson(frame, decoder);
        if (text === null) return frame;
        const request = readRequest(text);
        if (!request) {
          stats.unreadable++;
          return frame;
        }
        let edited = false;
        for (const rule of active2) {
          try {
            if (rule.edit(request)) edited = true;
          } catch (error) {
            fail(rule, error);
            return frame;
          }
        }
        if (!edited) return frame;
        changed = true;
        return withJson(frame, writeRequest(request), encoder);
      });
      return changed ? writeFrames(out) : null;
    }
    if (typeof original === "function") {
      proto.send = function send(data) {
        try {
          if (LIGHTSPEED.test(this.url)) {
            stats.messages++;
            const startupState = startup?.state?.() ?? "ready";
            const active2 = rules.filter((rule) => {
              try {
                return startupState === "ready" ? rule.enabled() : rule.startupPrivacy === true;
              } catch (error) {
                fail(rule, error);
                return false;
              }
            });
            const bytes = active2.length ? bytesOf(data) : null;
            const edited = bytes && rewrite(bytes, active2);
            if (edited) {
              const isBuffer = Object.prototype.toString.call(data) === "[object ArrayBuffer]";
              return original.call(this, isBuffer ? edited.buffer : edited);
            }
          }
        } catch (error) {
          log.error("Couldn't read a chat message, so it went out unchanged", error);
        }
        return original.apply(this, arguments);
      };
    }
    return {
      installed: typeof original === "function",
      stats,
      // rule: { id, enabled(), startupPrivacy?, edit(request) -> true when it changed request.payload }
      // request: { type, payload } with payload parsed (3: tasks, 4: one unqueued task).
      editChatRequests(rule) {
        rules.push(rule);
      }
    };
  }

  // src/core/net/hooks.js
  var INSTALLED = /* @__PURE__ */ Symbol.for("hushfacebook-web.net");
  var INLINE_JSON = Object.freeze({ transport: "json-parse", method: "", url: "", host: "", path: "", friendlyName: "" });
  var STARTUP_WAIT_MS = 16e3;
  var STARTUP_MAX_PENDING = 32;
  var STARTUP_MAX_BYTES = 256 * 1024;
  var FORM_MAX_BYTES = 64 * 1024;
  var FORM_WAIT_MS = 250;
  function describeRequest({ url: url2, method = "GET", body, headers, transport, base }) {
    let parsed;
    try {
      parsed = new URL(String(url2), base);
    } catch {
      parsed = null;
    }
    return {
      transport,
      method: String(method).toUpperCase(),
      url: parsed?.href ?? String(url2),
      host: parsed?.hostname ?? "",
      path: parsed?.pathname ?? "",
      friendlyName: friendlyNameOf(body, headers),
      body
    };
  }
  function bodyBytes(body) {
    if (body === void 0 || body === null) return 0;
    if (typeof body === "string") return new TextEncoder().encode(body).byteLength;
    const tag = Object.prototype.toString.call(body);
    if (tag === "[object URLSearchParams]") return new TextEncoder().encode(String(body)).byteLength;
    if (tag === "[object ArrayBuffer]") return body.byteLength;
    if (ArrayBuffer.isView(body)) return body.byteLength;
    if (tag === "[object Blob]" || tag === "[object File]") return body.size;
    if (tag !== "[object FormData]" || typeof body.entries !== "function") return null;
    let bytes = 1024;
    for (const [name, value] of body.entries()) {
      const size = typeof value === "string" ? new TextEncoder().encode(value).byteLength : Number.isFinite(value?.size) ? value.size : null;
      if (size === null) return null;
      const filename = typeof value === "string" ? "" : String(value?.name ?? "blob");
      const type = typeof value === "string" ? "" : String(value?.type ?? "");
      bytes += 1024 + size + new TextEncoder().encode(String(name)).byteLength * 3 + new TextEncoder().encode(filename).byteLength * 3 + new TextEncoder().encode(type).byteLength;
    }
    return bytes;
  }
  function snapshotXhrBody(body) {
    const tag = Object.prototype.toString.call(body);
    if (tag === "[object URLSearchParams]") return new body.constructor(String(body));
    if (tag === "[object ArrayBuffer]") return body.slice(0);
    if (ArrayBuffer.isView(body)) return body.buffer.slice(body.byteOffset, body.byteOffset + body.byteLength);
    if (tag !== "[object FormData]") return body;
    const copy = new body.constructor();
    for (const [name, value] of body.entries()) copy.append(name, value);
    return copy;
  }
  function isRequestInput(win, input) {
    if (typeof win.Request === "function" && input instanceof win.Request) return true;
    return Object.prototype.toString.call(input) === "[object Request]" && typeof input.clone === "function";
  }
  function requestFormType(win, input, init) {
    if (input.bodyUsed || init && Object.hasOwn(init, "body")) return "";
    if (["GET", "HEAD"].includes(String(init?.method ?? input.method).toUpperCase())) return "";
    let type;
    try {
      type = init && Object.hasOwn(init, "headers") ? new win.Headers(init.headers).get("content-type") : input.headers.get("content-type");
    } catch {
      return "";
    }
    const kind = String(type ?? "").toLowerCase();
    return kind.startsWith("application/x-www-form-urlencoded") || kind.startsWith("multipart/form-data") ? type : "";
  }
  function readRequestForm(win, request, type, signal) {
    return new Promise((resolve) => {
      let reader = null;
      let settled = false;
      const finish = (form) => {
        if (settled) return;
        settled = true;
        (win.clearTimeout ?? clearTimeout)(timer);
        signal?.removeEventListener?.("abort", stop);
        if (!form) reader?.cancel().catch(() => {
        });
        resolve(form);
      };
      const stop = () => finish(null);
      const timer = (win.setTimeout ?? setTimeout)(stop, FORM_WAIT_MS);
      if (signal?.aborted) return stop();
      signal?.addEventListener?.("abort", stop, { once: true });
      let copy;
      try {
        copy = request.clone();
      } catch {
        return stop();
      }
      const chunks = [];
      let bytes = 0;
      const parse4 = async () => {
        const all = new Uint8Array(bytes);
        let at = 0;
        for (const chunk of chunks) {
          all.set(chunk, at);
          at += chunk.byteLength;
        }
        const body = type.toLowerCase().startsWith("multipart/form-data") ? await new win.Response(all, { headers: { "content-type": type } }).formData() : new URLSearchParams(new TextDecoder().decode(all));
        finish({ body, bytes });
      };
      if (!copy.body) {
        copy.blob().then((blob) => {
          if (settled) return void 0;
          if (blob.size > FORM_MAX_BYTES) return stop();
          return blob.arrayBuffer().then((buffer) => {
            chunks.push(new Uint8Array(buffer));
            bytes = buffer.byteLength;
            return parse4();
          });
        }).catch(stop);
        return void 0;
      }
      reader = copy.body.getReader();
      const pump = () => reader.read().then(({ done, value }) => {
        if (settled) return void 0;
        if (done) return parse4();
        bytes += value.byteLength;
        if (bytes > FORM_MAX_BYTES) return stop();
        chunks.push(value);
        return pump();
      });
      pump().catch(stop);
    });
  }
  function abortReason(win, signal) {
    if (signal?.reason !== void 0) return signal.reason;
    if (typeof win.DOMException === "function") return new win.DOMException("The operation was aborted.", "AbortError");
    const error = new Error("The operation was aborted.");
    error.name = "AbortError";
    return error;
  }
  function createStartupGate(win, startup, log) {
    const waiting = /* @__PURE__ */ new Set();
    const waitMs = startup?.waitMs ?? STARTUP_WAIT_MS;
    const maxPending = startup?.maxPending ?? STARTUP_MAX_PENDING;
    const maxBytes = startup?.maxBytes ?? STARTUP_MAX_BYTES;
    let retainedBytes = 0;
    let closed = false;
    let accountConfirmed = false;
    let statusErrorLogged = false;
    const state = () => {
      if (closed) return "error";
      let phase = "ready";
      try {
        const reported = startup?.status?.();
        const value = typeof reported === "string" ? reported : reported?.state;
        if (value === "loading" || value === "error" || value === "ready") phase = value;
        if (!accountConfirmed && startup?.accountMatches?.() === false) return "error";
        if (phase === "ready") accountConfirmed = true;
        return phase;
      } catch (error) {
        if (!statusErrorLogged) {
          statusErrorLogged = true;
          log?.error("Saved privacy choices could not be checked, so recognized requests are held back", error);
        }
        return "error";
      }
    };
    const finish = (entry, outcome) => {
      if (!waiting.delete(entry)) return;
      retainedBytes -= entry.bytes;
      (win.clearTimeout ?? clearTimeout)(entry.timer);
      entry.signal?.removeEventListener?.("abort", entry.abort);
      if (outcome === "ready") entry.onReady();
      else if (outcome === "closed") entry.onClosed();
      else entry.onCancel?.();
    };
    const settle2 = () => {
      const phase = state();
      if (phase === "loading") return;
      for (const entry of [...waiting]) finish(entry, phase === "ready" ? "ready" : "closed");
    };
    let unsubscribe = () => {
    };
    try {
      unsubscribe = startup?.onStatus?.(settle2) ?? unsubscribe;
    } catch (error) {
      log?.error("Saved privacy choice updates could not be watched, so recognized requests are held back", error);
      closed = true;
    }
    const close = () => {
      if (closed) return;
      closed = true;
      for (const entry of [...waiting]) finish(entry, "closed");
      unsubscribe();
      win.removeEventListener?.("pagehide", onPageHide);
    };
    const onPageHide = (event) => {
      if (!event.persisted) close();
    };
    win.addEventListener?.("pagehide", onPageHide);
    return {
      state,
      defer({ bytes, signal, onReady, onClosed, onCancel }) {
        if (signal?.aborted) {
          onCancel?.();
          return null;
        }
        const phase = state();
        if (phase === "ready") {
          onReady();
          return null;
        }
        if (phase === "error" || bytes === null || bytes > maxBytes || waiting.size >= maxPending || retainedBytes + bytes > maxBytes) {
          onClosed();
          return null;
        }
        const entry = { bytes, signal, onReady, onClosed, onCancel, timer: null, abort: null };
        entry.abort = () => finish(entry, "cancel");
        entry.timer = (win.setTimeout ?? setTimeout)(() => finish(entry, "closed"), waitMs);
        signal?.addEventListener?.("abort", entry.abort, { once: true });
        waiting.add(entry);
        retainedBytes += bytes;
        return { cancel: entry.abort };
      },
      close,
      pending: () => waiting.size
    };
  }
  function installNetworkHooks({ win, log, startup }) {
    if (win[INSTALLED]) return win[INSTALLED];
    const requestRules = [];
    const responseRules = [];
    const failed = /* @__PURE__ */ new Set();
    const onError = (rule, error) => {
      if (failed.has(rule.id)) return;
      failed.add(rule.id);
      log.error(`Network rule "${rule.id}" failed, so Facebook got its original data`, error);
    };
    const matches = (rule, ctx) => {
      try {
        return rule.match(ctx);
      } catch (error) {
        onError(rule, error);
        return false;
      }
    };
    const active2 = (rules, ctx) => rules.filter((rule) => {
      try {
        return rule.enabled() && matches(rule, ctx);
      } catch (error) {
        onError(rule, error);
        return false;
      }
    });
    const blockingRule = (ctx) => active2(requestRules, ctx)[0];
    const startupRule = (ctx) => requestRules.find((rule) => rule.startupPrivacy === true && matches(rule, ctx));
    const fakeAnswer = (rule, ctx) => {
      try {
        return rule.fakeResponse?.(ctx) ?? "{}";
      } catch (error) {
        if (!failed.has(rule.id)) {
          failed.add(rule.id);
          log.error(`Network rule "${rule.id}" couldn't make its answer, so the page got an empty one`, error);
        }
        return "{}";
      }
    };
    const parse4 = win.JSON?.parse ?? JSON.parse;
    const handled = createHandledLines();
    const lineStats = { oversized: 0 };
    const lineStream = (rules, ctx) => createLineStream((line) => {
      const out = transformDocumentLine(line, rules, ctx, onError, parse4);
      const ran = rulesFor(line, rules);
      if (out !== null && ran.length) handled.add(out, ran);
      return out;
    }, {
      onBypass: () => {
        if (!lineStats.oversized++) log.warn("A Facebook answer was too long to filter as it arrived, so it went through as sent. Diagnostics counts them.", ctx.friendlyName || ctx.transport);
      }
    });
    const startupGate = createStartupGate(win, startup, log);
    patchFetch(win, { blockingRule, startupRule, startupGate, fakeAnswer, active: active2, responseRules, lineStream, log });
    patchXhr(win, { blockingRule, startupRule, startupGate, fakeAnswer, active: active2, responseRules, lineStream, log });
    patchBeacon(win, { blockingRule, startupRule, startupGate, fakeAnswer });
    patchJsonParse(win, { active: active2, responseRules, onError, handled });
    const sockets = patchWebSocket(win, { log, startup: startupGate });
    const api = {
      // The chat socket: see websocket.js. chatStats counts what it sent and couldn't read.
      editChatRequests: sockets.editChatRequests,
      chatStats: sockets.stats,
      lineStats,
      startupPending: startupGate.pending,
      startupState: startupGate.state,
      teardown: startupGate.close,
      // rule: { id, enabled(), match(ctx), fakeResponse?(ctx), startupPrivacy? }
      blockRequests(rule) {
        requestRules.push(rule);
      },
      // rule: { id, enabled(), match(ctx), markers?: string[], observe?, transform(doc, ctx, stage) }
      // ctx.transport is 'fetch', 'xhr' or 'json-parse' (inline page data). Anything a transform
      // keeps past the document goes through stage (see applyRules), so a document that fails
      // leaves no trace. An observe rule only reads, after the others, the data the page gets.
      transformResponses(rule) {
        responseRules.push(rule);
      }
    };
    Object.defineProperty(win, INSTALLED, { value: api });
    return api;
  }
  function patchFetch(win, { blockingRule, startupRule, startupGate, fakeAnswer, active: active2, responseRules, lineStream, log }) {
    const original = win.fetch;
    if (typeof original !== "function") return;
    win.fetch = function fetch(input, init) {
      const receiver = this;
      const args = arguments;
      const isRequest = isRequestInput(win, input);
      const ctx = describeRequest({
        transport: "fetch",
        url: isRequest ? input.url : input,
        method: init?.method ?? (isRequest ? input.method : "GET"),
        body: init?.body,
        headers: init?.headers ?? (isRequest ? input.headers : void 0),
        base: win.location.href
      });
      const route = (form) => routeFetch(win, {
        input,
        init,
        isRequest,
        form,
        startupRule,
        startupGate,
        original,
        receiver,
        args,
        ctx,
        blockingRule,
        fakeAnswer,
        active: active2,
        responseRules,
        lineStream,
        log
      });
      const formType = isRequest && !ctx.friendlyName ? requestFormType(win, input, init) : "";
      if (!formType) return route(null);
      return new win.Promise((resolve, reject) => {
        readRequestForm(win, input, formType, init?.signal ?? input.signal).then((form) => {
          if (form) {
            ctx.body = form.body;
            ctx.friendlyName = friendlyNameOf(form.body);
          }
          try {
            resolve(route(form));
          } catch (error) {
            reject(error);
          }
        });
      });
    };
  }
  function routeFetch(win, { input, init, isRequest, form, startupRule, startupGate, ...send }) {
    const { ctx } = send;
    if (startupGate.state() === "ready") return sendFetch(win, send);
    const pending = startupRule(ctx);
    if (!pending) return sendFetch(win, send);
    const queuedBody = init && Object.hasOwn(init, "body") ? init.body : isRequest && input.body ? input.body : void 0;
    const bytes = form ? form.bytes : bodyBytes(queuedBody);
    let request = null;
    if (bytes !== null && typeof win.Request === "function") {
      try {
        request = new win.Request(isRequest ? input : ctx.url, init);
      } catch (error) {
        return win.Promise.reject(error);
      }
    }
    const signal = request?.signal ?? init?.signal ?? (isRequest ? input.signal : null);
    const deferredCtx = { ...ctx, body: void 0 };
    if (!request) {
      if (signal?.aborted) return win.Promise.reject(abortReason(win, signal));
      return win.Promise.resolve(new win.Response(send.fakeAnswer(pending, deferredCtx), { status: 200 }));
    }
    return deferFetch(win, { ...send, request, bytes, signal, ctx: deferredCtx, pending, startupGate });
  }
  function sendFetch(win, { original, receiver, args, ctx, blockingRule, fakeAnswer, active: active2, responseRules, lineStream, log }) {
    const blocker = blockingRule(ctx);
    if (blocker) return win.Promise.resolve(new win.Response(fakeAnswer(blocker, ctx), { status: 200 }));
    const promise = original.apply(receiver, args);
    const rules = active2(responseRules, ctx);
    if (!rules.length) return promise;
    return promise.then((response) => {
      try {
        return rewriteFetchResponse(win, response, lineStream(rules, ctx));
      } catch (error) {
        log.error("Couldn't rewrite a fetch response, so it went through unchanged", error);
        return response;
      }
    });
  }
  function deferFetch(win, options) {
    const {
      original,
      receiver,
      request,
      bytes,
      signal,
      ctx,
      pending,
      startupGate,
      blockingRule,
      fakeAnswer,
      active: active2,
      responseRules,
      lineStream,
      log
    } = options;
    const fake = (rule) => new win.Response(fakeAnswer(rule, ctx), { status: 200 });
    return new win.Promise((resolve, reject) => {
      startupGate.defer({
        bytes,
        signal,
        onReady: () => {
          try {
            resolve(sendFetch(win, {
              original,
              receiver,
              args: [request],
              ctx,
              blockingRule,
              fakeAnswer,
              active: active2,
              responseRules,
              lineStream,
              log
            }));
          } catch (error) {
            reject(error);
          }
        },
        onClosed: () => resolve(fake(pending)),
        onCancel: () => reject(abortReason(win, signal))
      });
    });
  }
  function rewriteFetchResponse(win, response, stream) {
    if (!response.body || response.type === "opaque") return response;
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    const encoder = new TextEncoder();
    const body = new win.ReadableStream({
      async pull(controller) {
        for (; ; ) {
          const { done, value } = await reader.read();
          const text = done ? stream.push(decoder.decode()) + stream.flush() : stream.push(decoder.decode(value, { stream: true }));
          if (text) controller.enqueue(encoder.encode(text));
          if (done) {
            controller.close();
            return;
          }
          if (text) return;
        }
      },
      cancel: (reason) => reader.cancel(reason)
    });
    const headers = new win.Headers(response.headers);
    headers.delete("content-length");
    const rewritten = new win.Response(body, { status: response.status, statusText: response.statusText, headers });
    return keepResponseFacts(win, rewritten, { url: response.url, redirected: response.redirected, type: response.type });
  }
  function keepResponseFacts(win, response, facts) {
    const nativeClone = win.Response.prototype.clone;
    for (const [key, value] of Object.entries(facts)) Object.defineProperty(response, key, { value, configurable: true });
    Object.defineProperty(response, "clone", {
      configurable: true,
      writable: true,
      value: function clone() {
        return keepResponseFacts(win, nativeClone.call(this), facts);
      }
    });
    return response;
  }
  function patchXhr(win, { blockingRule, startupRule, startupGate, fakeAnswer, active: active2, responseRules, lineStream, log }) {
    const Xhr = win.XMLHttpRequest;
    if (typeof Xhr !== "function") return;
    const proto = Xhr.prototype;
    const { open, send, setRequestHeader, abort, getResponseHeader, getAllResponseHeaders, overrideMimeType } = proto;
    const textGetter = Object.getOwnPropertyDescriptor(proto, "responseText").get;
    const responseGetter = Object.getOwnPropertyDescriptor(proto, "response").get;
    const json = win.JSON ?? JSON;
    const jsonParse = json.parse;
    const parse4 = (text) => jsonParse.call(json, text);
    const state = /* @__PURE__ */ new WeakMap();
    const overrides = xhrOverrides();
    const quiet = /* @__PURE__ */ new WeakSet();
    const hush = (event) => {
      if (quiet.has(event.currentTarget)) event.stopImmediatePropagation();
    };
    const hushXhr = listenFirst(win, proto, Xhr, "loadstart", hush);
    listenFirst(win, win.XMLHttpRequestUpload?.prototype, win.XMLHttpRequestUpload, "loadstart", hush);
    const synthetic = (xhr) => state.get(xhr)?.synthetic === true;
    const inFlight = (entry) => Boolean(entry?.deferred || entry?.fake?.pending);
    const stop = (entry) => {
      if (!entry) return;
      entry.deferred?.cancel();
      entry.deferred = null;
      entry.fake?.cancel();
      entry.fake = null;
    };
    proto.open = function(method, url2) {
      const shown4 = this.readyState;
      const previous = state.get(this);
      const released = overrides.release(this);
      const silent = shown4 !== 1 && this.readyState === 1;
      const entry = {
        method,
        url: url2,
        async: arguments.length < 3 || Boolean(arguments[2]),
        headers: {},
        deferred: null,
        fake: null,
        sent: false,
        synthetic: false,
        uploading: false
      };
      state.set(this, entry);
      let result;
      try {
        result = open.apply(this, arguments);
      } catch (error) {
        if (state.get(this) === entry) {
          if (previous) state.set(this, previous);
          else state.delete(this);
          overrides.restore(this, released);
        }
        throw error;
      }
      stop(previous);
      hushXhr(this);
      if (silent) this.dispatchEvent(new win.Event("readystatechange"));
      return result;
    };
    const refuse = (name) => invalidState(win, `Failed to execute '${name}' on 'XMLHttpRequest': The object's state must be OPENED.`);
    proto.setRequestHeader = function(name, value) {
      const entry = state.get(this);
      if (entry?.synthetic && arguments.length >= 2) throw refuse("setRequestHeader");
      if (entry) entry.headers[String(name).toLowerCase()] = value;
      return setRequestHeader.apply(this, arguments);
    };
    const loadingOrDone = (xhr) => synthetic(xhr) && xhr.readyState >= 3;
    if (typeof overrideMimeType === "function") {
      proto.overrideMimeType = function() {
        if (loadingOrDone(this) && arguments.length >= 1) throw refuse("overrideMimeType");
        return overrideMimeType.apply(this, arguments);
      };
    }
    guardSetter(proto, "responseType", (xhr) => {
      if (loadingOrDone(xhr)) throw invalidState(win, "Failed to set the 'responseType' property on 'XMLHttpRequest': The response type cannot be set if the object's state is LOADING or DONE.");
    });
    guardSetter(proto, "withCredentials", (xhr) => {
      if (synthetic(xhr) && xhr.readyState !== 0) throw invalidState(win, "Failed to set the 'withCredentials' property on 'XMLHttpRequest': The value may only be set if the object's state is UNSENT or OPENED.");
    });
    const answered = (xhr) => synthetic(xhr) && xhr.status !== 0;
    if (typeof getResponseHeader === "function") {
      proto.getResponseHeader = function(name) {
        const value = getResponseHeader.apply(this, arguments);
        if (!synthetic(this)) return value;
        return answered(this) && String(name).toLowerCase() === "content-type" ? ANSWER_TYPE : null;
      };
    }
    if (typeof getAllResponseHeaders === "function") {
      proto.getAllResponseHeaders = function() {
        const value = getAllResponseHeaders.apply(this, arguments);
        if (!synthetic(this)) return value;
        return answered(this) ? `content-type: ${ANSWER_TYPE}\r
` : "";
      };
    }
    const sendQuietly = (xhr, body, uploadStarted) => {
      const upload = uploadStarted ? xhr.upload : null;
      quiet.add(xhr);
      if (upload) quiet.add(upload);
      try {
        return send.call(xhr, body);
      } finally {
        quiet.delete(xhr);
        if (upload) quiet.delete(upload);
      }
    };
    proto.send = function(body) {
      const entry = state.get(this);
      if (!entry) return send.apply(this, arguments);
      if (entry.sent) throw invalidState(win, "Failed to execute 'send' on 'XMLHttpRequest': The object's state must be OPENED.");
      entry.sent = true;
      const ctx = describeRequest({ transport: "xhr", url: entry.url, method: entry.method, body, headers: entry.headers, base: win.location.href });
      const xhr = this;
      const upload = entry.async ? uploadSize(entry.method, body) : null;
      const live = () => state.get(xhr) === entry && Boolean(entry.fake || entry.deferred);
      const announce = () => {
        entry.uploading = upload !== null;
        overrides.define(xhr, xhrResult(win, xhr, { readyState: 1, status: 0, statusText: "", url: "", text: null }));
        xhr.dispatchEvent(progressEvent(win, "loadstart"));
        if (entry.uploading && live()) xhr.upload?.dispatchEvent(progressEvent(win, "loadstart", 0, upload));
        return live();
      };
      const fakeSuccess = (text, synchronous = false) => {
        entry.fake?.cancel();
        entry.synthetic = true;
        entry.fake = fakeXhrSuccess(win, xhr, {
          url: ctx.url,
          text,
          parse: parse4,
          synchronous,
          overrides,
          // Read when it starts, after loadstart has said whether there's an upload.
          uploadBytes: () => entry.uploading ? upload : null,
          uploaded: () => {
            entry.uploading = false;
          }
        });
        return entry.fake;
      };
      const sendRequest = (requestBody, resumed) => {
        const blocker = blockingRule(ctx);
        if (blocker) {
          const fake = fakeSuccess(fakeAnswer(blocker, ctx), !entry.async);
          if (resumed || !entry.async || announce()) fake.start();
          return void 0;
        }
        entry.synthetic = false;
        overrides.release(xhr);
        const rules = active2(responseRules, ctx);
        if (rules.length) attachTextTransform(xhr, lineStream(rules, ctx), textGetter, responseGetter, overrides);
        return resumed ? sendQuietly(xhr, requestBody, entry.uploading) : send.call(xhr, requestBody);
      };
      if (startupGate.state() === "ready") return sendRequest(body, false);
      const pending = startupRule(ctx);
      if (!pending) return sendRequest(body, false);
      if (!entry.async) {
        fakeSuccess(fakeAnswer(pending, ctx), true).start();
        return void 0;
      }
      const bytes = bodyBytes(body);
      const queuedBody = bytes === null ? body : snapshotXhrBody(body);
      ctx.body = void 0;
      entry.synthetic = true;
      entry.deferred = { cancel() {
      } };
      if (!announce()) return void 0;
      const resume = () => {
        if (state.get(xhr) !== entry) return;
        entry.deferred = null;
        try {
          sendRequest(queuedBody, true);
        } catch (error) {
          log.error("A privacy request couldn't resume after saved settings loaded, so it stayed held back", error);
          fakeSuccess(fakeAnswer(pending, ctx)).start();
        }
      };
      const hold = () => {
        if (state.get(xhr) !== entry) return;
        entry.deferred = null;
        fakeSuccess(fakeAnswer(pending, ctx)).start();
      };
      entry.deferred = startupGate.defer({
        bytes,
        onReady: resume,
        onClosed: hold,
        onCancel: () => {
        }
      });
      return void 0;
    };
    if (typeof abort === "function") {
      proto.abort = function() {
        const entry = state.get(this);
        const wasInFlight = inFlight(entry);
        const uploading = wasInFlight && entry.uploading;
        stop(entry);
        overrides.release(this);
        const result = abort.apply(this, arguments);
        if (!entry?.synthetic) return result;
        entry.uploading = false;
        if (wasInFlight) {
          overrides.define(this, xhrResult(win, this, { readyState: 4, status: 0, statusText: "", url: "", text: null }));
          this.dispatchEvent(new win.Event("readystatechange"));
          if (uploading) {
            this.upload?.dispatchEvent(progressEvent(win, "abort"));
            this.upload?.dispatchEvent(progressEvent(win, "loadend"));
          }
          this.dispatchEvent(progressEvent(win, "abort"));
          this.dispatchEvent(progressEvent(win, "loadend"));
          if (state.get(this) !== entry) return result;
        }
        overrides.define(this, xhrResult(win, this, { readyState: 0, status: 0, statusText: "", url: "", text: null }));
        return result;
      };
    }
  }
  var ANSWER_TYPE = "text/plain;charset=UTF-8";
  function guardSetter(proto, key, check) {
    const descriptor = Object.getOwnPropertyDescriptor(proto, key);
    if (typeof descriptor?.set !== "function" || !descriptor.configurable) return;
    const set = descriptor.set;
    Object.defineProperty(proto, key, {
      ...descriptor,
      set(value) {
        check(this);
        set.call(this, value);
      }
    });
  }
  function listenFirst(win, proto, Target, type, listener) {
    const added = /* @__PURE__ */ new WeakSet();
    const add = win.EventTarget?.prototype.addEventListener ?? proto?.addEventListener;
    const ensure = (target2) => {
      if (added.has(target2) || !(target2 instanceof Target)) return;
      added.add(target2);
      add.call(target2, type, listener, true);
    };
    if (!proto || typeof Target !== "function" || typeof add !== "function") return () => {
    };
    const definable = (key) => Object.getOwnPropertyDescriptor(proto, key)?.configurable !== false;
    const listen = descriptorOf(proto, "addEventListener");
    if (typeof listen?.value === "function" && definable("addEventListener")) {
      Object.defineProperty(proto, "addEventListener", {
        ...listen,
        value: function addEventListener2(eventType) {
          if (eventType === type) ensure(this);
          return listen.value.apply(this, arguments);
        }
      });
    }
    const handler = descriptorOf(proto, `on${type}`);
    if (typeof handler?.set === "function" && definable(`on${type}`)) {
      Object.defineProperty(proto, `on${type}`, {
        ...handler,
        set(value) {
          ensure(this);
          handler.set.call(this, value);
        }
      });
    }
    return ensure;
  }
  function descriptorOf(object, key) {
    for (let current = object; current; current = Object.getPrototypeOf(current)) {
      const descriptor = Object.getOwnPropertyDescriptor(current, key);
      if (descriptor) return descriptor;
    }
    return void 0;
  }
  function uploadSize(method, body) {
    if (body === void 0 || body === null || ["GET", "HEAD"].includes(String(method).toUpperCase())) return null;
    if (Object.prototype.toString.call(body) === "[object FormData]") return null;
    return bodyBytes(body);
  }
  function progressEvent(win, type, loaded = 0, total = 0) {
    return new win.ProgressEvent(type, { lengthComputable: total !== 0, loaded, total });
  }
  function xhrOverrides() {
    const owned = /* @__PURE__ */ new WeakMap();
    return {
      define(xhr, getters) {
        let props = owned.get(xhr);
        if (!props) owned.set(xhr, props = /* @__PURE__ */ new Map());
        for (const [key, get] of Object.entries(getters)) {
          const current = Object.getOwnPropertyDescriptor(xhr, key);
          if (current && !current.configurable) continue;
          const mine = props.get(key);
          const previous = mine && current?.get === mine.get ? mine.previous : current;
          Object.defineProperty(xhr, key, { configurable: true, enumerable: true, get });
          props.set(key, { get, previous });
        }
      },
      release(xhr) {
        const props = owned.get(xhr);
        const removed = /* @__PURE__ */ new Map();
        if (!props) return removed;
        owned.delete(xhr);
        for (const [key, entry] of props) {
          if (Object.getOwnPropertyDescriptor(xhr, key)?.get !== entry.get) continue;
          if (entry.previous) Object.defineProperty(xhr, key, entry.previous);
          else delete xhr[key];
          removed.set(key, entry);
        }
        return removed;
      },
      // Puts back what release removed, for an open() that threw.
      restore(xhr, removed) {
        if (removed.size) this.define(xhr, Object.fromEntries([...removed].map(([key, { get }]) => [key, get])));
      }
    };
  }
  function invalidState(win, message) {
    return typeof win.DOMException === "function" ? new win.DOMException(message, "InvalidStateError") : Object.assign(new Error(message), { name: "InvalidStateError" });
  }
  function xhrResult(win, xhr, { readyState, status, statusText, url: url2, text, parse: parse4 }) {
    const textual = () => xhr.responseType === "" || xhr.responseType === "text";
    let typed = null;
    const typedResponse = () => {
      const type = xhr.responseType;
      if (typed?.type !== type) typed = { type, value: text === null ? null : decodeAs(win, type, text, parse4) };
      return typed.value;
    };
    return {
      readyState: () => readyState,
      status: () => status,
      statusText: () => statusText,
      responseURL: () => url2,
      responseText: () => {
        if (!textual()) {
          throw invalidState(win, `Failed to read the 'responseText' property from 'XMLHttpRequest': The value is only accessible if the object's 'responseType' is '' or 'text' (was '${xhr.responseType}').`);
        }
        return readyState < 3 ? "" : text ?? "";
      },
      response: () => {
        if (textual()) return readyState < 3 ? "" : text ?? "";
        return readyState < 4 ? null : typedResponse();
      }
    };
  }
  function decodeAs(win, type, text, parse4) {
    if (type === "json") {
      try {
        return parse4(text);
      } catch {
        return null;
      }
    }
    if (type === "arraybuffer" && typeof win.TextEncoder === "function") return new win.TextEncoder().encode(text).buffer;
    if (type === "blob" && typeof win.Blob === "function") return new win.Blob([text]);
    return null;
  }
  function attachTextTransform(xhr, stream, textGetter, responseGetter, overrides) {
    let seen = 0;
    let output = "";
    let flushed = false;
    let reading = false;
    const read2 = () => {
      if (reading) return textGetter.call(xhr);
      reading = true;
      try {
        const raw = textGetter.call(xhr);
        if (raw.length > seen) {
          output += stream.push(raw.slice(seen));
          seen = raw.length;
        }
        if (xhr.readyState === 4 && !flushed) {
          output += stream.flush();
          flushed = true;
        }
      } finally {
        reading = false;
      }
      return output;
    };
    const textual = () => xhr.responseType === "" || xhr.responseType === "text";
    overrides.define(xhr, {
      responseText: read2,
      response: () => !reading && textual() ? read2() : responseGetter.call(xhr)
    });
  }
  function fakeXhrSuccess(win, xhr, { url: url2, text, parse: parse4, synchronous, uploadBytes = () => null, uploaded = () => {
  }, overrides }) {
    let active2 = true;
    let timer = null;
    const bytes = bodyBytes(String(text));
    const show = (readyState) => overrides.define(xhr, xhrResult(win, xhr, { readyState, status: 200, statusText: "OK", url: url2, text, parse: parse4 }));
    const changed = () => {
      xhr.dispatchEvent(new win.Event("readystatechange"));
    };
    const fire = (target2, type, loaded, total) => {
      target2?.dispatchEvent(progressEvent(win, type, loaded, total));
    };
    const later2 = typeof win.queueMicrotask === "function" ? (step2) => win.queueMicrotask(step2) : (step2) => Promise.resolve().then(step2);
    const run = (steps, then) => {
      const next = (i) => {
        if (i === steps.length) return then();
        if (steps[i]() === false) return void 0;
        if (synchronous) return next(i + 1);
        later2(() => next(i + 1));
        return void 0;
      };
      next(0);
    };
    const done = [
      () => {
        fake.pending = false;
        show(4);
        changed();
        return active2;
      },
      () => fire(xhr, "load", bytes, 0),
      () => fire(xhr, "loadend", bytes, 0)
    ];
    const stagesFor = (upload) => {
      if (synchronous) return [done];
      const stages = [];
      if (upload !== null) {
        stages.push([
          () => {
            uploaded();
            fire(xhr.upload, "progress", upload, upload);
          },
          () => fire(xhr.upload, "load", upload, upload),
          () => fire(xhr.upload, "loadend", upload, upload)
        ]);
      }
      stages.push([() => {
        show(2);
        changed();
      }]);
      stages.push([() => {
        show(3);
        changed();
      }, () => fire(xhr, "progress", active2 ? bytes : 0, 0)]);
      stages.push(done);
      return stages;
    };
    const fake = {
      pending: true,
      start() {
        const stages = stagesFor(uploadBytes());
        const stage = (i) => {
          timer = null;
          if (!active2) return;
          run(stages[i], () => {
            if (active2 && i + 1 < stages.length) timer = win.setTimeout(() => stage(i + 1), 0);
          });
        };
        if (synchronous) stage(0);
        else timer = win.setTimeout(() => stage(0), 0);
      },
      cancel() {
        active2 = false;
        fake.pending = false;
        if (timer !== null) win.clearTimeout(timer);
        timer = null;
      }
    };
    return fake;
  }
  function patchJsonParse(win, { active: active2, responseRules, onError, handled }) {
    const json = win.JSON;
    const parse4 = json?.parse;
    if (typeof parse4 !== "function") return;
    json.parse = function(text, reviver) {
      const result = parse4.apply(this, arguments);
      if (typeof reviver === "function") return result;
      if (typeof text !== "string" || result === null || typeof result !== "object") return result;
      let candidates = rulesFor(text, responseRules);
      if (!candidates.length) return result;
      const done = handled?.get(text);
      if (done) candidates = candidates.filter((rule) => !done.has(rule));
      const rules = active2(candidates, INLINE_JSON);
      if (!rules.length) return result;
      const accepted = applyRules(result, rules, INLINE_JSON, onError) === FAILED ? parse4.apply(this, arguments) : result;
      observeRules(accepted, rules, INLINE_JSON, onError);
      return accepted;
    };
  }
  var GUARD2 = "for (;;);";
  var SAMPLES = 64;
  var ENDS = 160;
  function lineKey(line) {
    let text = line.trim();
    if (text.startsWith(GUARD2)) text = text.slice(GUARD2.length).trimStart();
    const n = text.length;
    if (n <= 2 * ENDS + SAMPLES) return text;
    let sample = "";
    for (let i = 1; i < SAMPLES; i++) sample += text[Math.floor(i * n / SAMPLES)];
    return `${n}:${text.slice(0, ENDS)}${sample}${text.slice(-ENDS)}`;
  }
  var BOX = /^\{"[^"\\]{1,32}":/;
  function unboxed(line) {
    const text = line.trim();
    const head = BOX.exec(text);
    return head && text.endsWith("}") ? text.slice(head[0].length, -1) : null;
  }
  function createHandledLines(limit = 64) {
    const lines2 = /* @__PURE__ */ new Map();
    const find = (line) => {
      const key = lineKey(line);
      if (lines2.has(key)) return key;
      const inner = unboxed(line);
      const boxed = inner === null ? null : lineKey(inner);
      return boxed !== null && lines2.has(boxed) ? boxed : void 0;
    };
    return {
      add(line, rules = []) {
        const key = lineKey(line);
        const done = lines2.get(key) ?? /* @__PURE__ */ new Set();
        for (const rule of rules) done.add(rule);
        lines2.delete(key);
        lines2.set(key, done);
        if (lines2.size > limit) lines2.delete(lines2.keys().next().value);
      },
      // The rules that already looked at this line, or at the line inside its box, or undefined.
      get: (line) => {
        const key = find(line);
        return key === void 0 ? void 0 : lines2.get(key);
      },
      has: (line) => find(line) !== void 0
    };
  }
  function patchBeacon(win, { blockingRule, startupRule, startupGate, fakeAnswer }) {
    const nav = win.navigator;
    const original = nav?.sendBeacon;
    if (typeof original !== "function") return;
    nav.sendBeacon = function sendBeacon(url2, data) {
      const ctx = describeRequest({ transport: "beacon", url: url2, method: "POST", body: data, base: win.location.href });
      const blocker = startupGate.state() === "ready" ? blockingRule(ctx) : startupRule(ctx);
      if (blocker) {
        fakeAnswer(blocker, ctx);
        return true;
      }
      return original.apply(this, arguments);
    };
  }

  // src/core/route.js
  var ROUTE_TYPES = {
    "": "home",
    "home.php": "home",
    marketplace: "marketplace",
    groups: "groups",
    watch: "watch",
    reel: "reel",
    reels: "reel",
    stories: "stories",
    messages: "messages",
    notifications: "notifications",
    search: "search",
    friends: "friends",
    gaming: "gaming",
    events: "events",
    photo: "photo",
    "photo.php": "photo",
    photos: "photo",
    "permalink.php": "post",
    "story.php": "post",
    "profile.php": "profile",
    settings: "settings",
    saved: "saved",
    hashtag: "hashtag",
    feeds: "feeds",
    bookmarks: "menu"
  };
  function parseRoute(href) {
    const url2 = new URL(href);
    const parts = url2.pathname.split("/").filter(Boolean);
    const type = ROUTE_TYPES[parts[0] ?? ""] ?? "profile";
    const permalink = /\/posts\/(?:\d+|pfbid0\w+)/.test(url2.pathname) || /^\/(?:permalink|story)\.php$/.test(url2.pathname) || /^\/groups\/[^/]+\/(?:posts|permalink)\/[^/]+/.test(url2.pathname) || url2.searchParams.has("multi_permalinks") || url2.searchParams.get("view") === "permalink";
    return { href: url2.href, type, permalink, path: url2.pathname, feed: url2.searchParams.get("sk") ?? "" };
  }
  function createRouter({ win, pageAccess: pageAccess2, log, pollMs = 500 }) {
    const listeners = /* @__PURE__ */ new Set();
    let current = parseRoute(win.location.href);
    const stamp2 = () => {
      const root = win.document?.documentElement;
      if (!root) return;
      root.dataset.hfwRoute = current.type;
      root.dataset.hfwPermalink = String(current.permalink);
    };
    const check = () => {
      if (win.location.href === current.href) return;
      current = parseRoute(win.location.href);
      stamp2();
      for (const listener of listeners) {
        try {
          listener(current);
        } catch (error) {
          log?.error("A page-change listener failed", error);
        }
      }
    };
    if (pageAccess2 === "page") {
      for (const name of ["pushState", "replaceState"]) {
        const original = win.history[name];
        win.history[name] = function() {
          const result = original.apply(this, arguments);
          check();
          return result;
        };
      }
      win.addEventListener("popstate", check);
    } else {
      win.setInterval(check, pollMs);
    }
    win.addEventListener("hashchange", check);
    whenRootReady(stamp2, win.document);
    return {
      current: () => current,
      subscribe(listener) {
        listeners.add(listener);
        return () => listeners.delete(listener);
      }
    };
  }

  // src/core/start-features.js
  function startFeatures({ features: features2, net, settings, log, unavailable, context, changed }) {
    for (const feature of features2) {
      if (feature.needsPage && !net) {
        unavailable.set(feature.id, "page");
        continue;
      }
      if (!feature.setup) continue;
      try {
        feature.setup({
          ...context(feature),
          net,
          settings,
          // A feature that stops working after setup says so, the same as one that couldn't start.
          markUnavailable: (reason = "failed") => {
            unavailable.set(feature.id, reason);
            changed?.();
          },
          enabled: () => settings.enabled(feature.id),
          option: (key) => settings.get(`${feature.id}.${key}`)
        });
      } catch (error) {
        unavailable.set(feature.id, "failed");
        log.error(`${feature.title} couldn't start`, error);
      }
    }
  }

  // src/core/modules.js
  function whenModule(win, name, callback, { log } = {}) {
    let asked = false;
    const ask = () => {
      if (asked || typeof win.requireLazy !== "function") return;
      asked = true;
      try {
        win.requireLazy([name], (exports) => {
          try {
            callback(exports);
          } catch (error) {
            log?.error(`Couldn't use Facebook's ${name}`, error);
          }
        });
      } catch (error) {
        log?.error(`Couldn't ask Facebook for ${name}`, error);
      }
    };
    ask();
    if (asked) return;
    win.document?.addEventListener("DOMContentLoaded", ask, { once: true });
    win.addEventListener?.("load", ask, { once: true });
  }
  var hooks = /* @__PURE__ */ new WeakMap();
  var factoryHooks = /* @__PURE__ */ new WeakMap();
  function afterModuleRuns(win, name, callback, { log } = {}) {
    let hook = hooks.get(win);
    if (!hook) {
      hook = { watchers: /* @__PURE__ */ new Map(), installed: false };
      hooks.set(win, hook);
      waitForDefiner(win, hook);
    }
    if (!hook.watchers.has(name)) hook.watchers.set(name, []);
    hook.watchers.get(name).push({ name, callback, log });
  }
  function waitForDefiner(win, hook) {
    if (wrapDefiner(win, hook)) return;
    let observer = null;
    const attempt2 = () => {
      if (wrapDefiner(win, hook)) observer?.disconnect();
    };
    if (typeof win.MutationObserver === "function" && win.document) {
      try {
        observer = new win.MutationObserver(attempt2);
        observer.observe(win.document, { childList: true, subtree: true });
      } catch {
        observer = null;
      }
    }
    win.document?.addEventListener("DOMContentLoaded", attempt2, { once: true });
    win.addEventListener?.("load", () => observer?.disconnect(), { once: true });
  }
  function wrapDefiner(win, hook) {
    if (hook.installed) return true;
    if (typeof win.__d !== "function") return false;
    const own = Object.getOwnPropertyDescriptor(win, "__d");
    if (own && !own.configurable) return false;
    const wrap = (delegate) => {
      if (typeof delegate !== "function") return delegate;
      return function __d(name, deps, factory) {
        const watchers = hook.watchers.get(name);
        if (!watchers || typeof factory !== "function") return delegate.apply(this, arguments);
        const args = Array.prototype.slice.call(arguments);
        args[2] = afterFactory(win, factory, watchers);
        return delegate.apply(this, args);
      };
    };
    let current = wrap(win.__d);
    Object.defineProperty(win, "__d", {
      configurable: true,
      enumerable: own ? own.enumerable : true,
      get: () => current,
      set: (next) => {
        if (next !== current) current = wrap(next);
      }
    });
    hook.installed = true;
    return true;
  }
  function afterFactory(win, factory, watchers) {
    if (factoryHooks.get(factory) === watchers) return factory;
    const wrapped = function() {
      const result = factory.apply(this, arguments);
      const exports = exportsOf(win, arguments);
      if (exports) {
        for (const { name, callback, log } of watchers) {
          try {
            callback(exports);
          } catch (error) {
            log?.error(`Couldn't use Facebook's ${name}`, error);
          }
        }
      }
      return result;
    };
    try {
      Object.defineProperty(wrapped, "length", { value: factory.length });
    } catch {
    }
    factoryHooks.set(wrapped, watchers);
    return wrapped;
  }
  function exportsOf(win, args) {
    for (const arg of args) {
      if (arg && typeof arg === "object" && arg !== win && arg.exports && typeof arg.exports === "object") return arg.exports;
    }
    return null;
  }

  // src/core/storage-report.js
  var MARK_PREFIX = "hfw:";
  var MONSTER = "WebStorageMonster";
  function stepAside(store, prefix = MARK_PREFIX) {
    const held = [];
    for (let i = store.length - 1; i >= 0; i--) {
      const key = store.key(i);
      if (typeof key === "string" && key.startsWith(prefix)) held.push([key, store.getItem(key)]);
    }
    for (const [key] of held) store.removeItem(key);
    return () => {
      for (const [key, value] of held) {
        try {
          store.setItem(key, value);
        } catch {
        }
      }
    };
  }
  function wrapReport(monster, { win, onReport } = {}) {
    const target2 = typeof monster?.cleanNow === "function" ? monster : monster?.default;
    const original = target2?.cleanNow;
    if (typeof original !== "function") return false;
    target2.cleanNow = function cleanNow(...args) {
      let restore;
      try {
        restore = stepAside(win.sessionStorage);
      } catch {
        restore = null;
      }
      try {
        return original.apply(this, args);
      } finally {
        restore?.();
        onReport?.();
      }
    };
    return true;
  }
  function keepOutOfStorageReport({ win, log, diagnostics }) {
    let state = "waiting";
    let reports = 0;
    whenModule(win, MONSTER, (monster) => {
      state = wrapReport(monster, { win, onReport: () => {
        reports++;
        diagnostics?.changed();
      } }) ? "wrapped" : "changed";
      if (state === "changed") log?.warn("Facebook's storage report has changed, so the names of this script's marks for the tab may be in it");
      diagnostics?.changed();
    }, { log });
    diagnostics?.add("Facebook's storage report", () => {
      if (state === "wrapped") return `This script's marks kept out of ${reports} report${reports === 1 ? "" : "s"}`;
      return state === "changed" ? "Changed, so the marks may be in it" : "Not loaded yet";
    });
  }

  // src/core/tasks.js
  var DAY2 = 24 * 60 * 60 * 1e3;
  var RECENT = 10 * 60 * 1e3;
  var TASKS_KEY = "tasks";
  var CHECK_KEY = "storageCheck";
  var MIRROR_KEY = "hfw:storageCheck";
  var asTable = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : {};
  var asRecord = (value) => value && typeof value === "object" && typeof value.token === "string" ? value : null;
  function attempt(read2, fallback) {
    try {
      return read2();
    } catch {
      return fallback;
    }
  }
  function createDailyTasks({ storage, log, now = () => Date.now() }) {
    const tasks = [];
    let ready = !storage.whenReady;
    let pending = false;
    const runDue = () => {
      if (!ready) {
        pending = true;
        return [];
      }
      let table;
      try {
        table = { ...asTable(storage.get(TASKS_KEY, {})) };
      } catch (error) {
        log?.error("Couldn't read when the daily jobs last ran", error);
        table = {};
      }
      const ran = [];
      for (const task of tasks) {
        const other = attempt(() => Number(task.lastSeen?.()) || 0, 0);
        const last = Math.max(Number(table[task.id]) || 0, other);
        if (now() - last < DAY2) continue;
        try {
          task.run();
        } catch (error) {
          log?.error(`The daily job "${task.id}" failed`, error);
        }
        table[task.id] = now();
        ran.push(task.id);
      }
      if (ran.length) {
        try {
          storage.set(TASKS_KEY, table);
        } catch (error) {
          log?.error("Couldn't note that the daily jobs ran", error);
        }
      }
      return ran;
    };
    const api = {
      // lastSeen: another record of the last run, used when the table itself was lost.
      add(id, run, { lastSeen } = {}) {
        tasks.push({ id, run, lastSeen });
      },
      // Runs every job that hasn't run in the last day. Returns the ids it ran.
      runDue
    };
    storage.whenReady?.(() => {
      ready = true;
      if (!pending) return;
      pending = false;
      runDue();
    });
    return api;
  }
  var MIRROR_DB = "hushfacebook-web";
  var MIRROR_STORE = "checks";
  function pageMirror(win = globalThis) {
    const idb = attempt(() => win.indexedDB, null);
    if (!idb || typeof idb.open !== "function") return null;
    let db = null;
    let known = false;
    let record = null;
    let pending = null;
    let settle2;
    const ready = new Promise((resolve) => {
      settle2 = resolve;
    });
    const write = (value) => {
      try {
        db.transaction(MIRROR_STORE, "readwrite").objectStore(MIRROR_STORE).put(value, MIRROR_KEY);
        return true;
      } catch {
        return false;
      }
    };
    const loaded = (value) => {
      known = true;
      record = pending ?? asRecord(value);
      if (pending) write(pending);
      pending = null;
      settle2();
    };
    try {
      const request = idb.open(MIRROR_DB, 1);
      request.onupgradeneeded = () => request.result.createObjectStore(MIRROR_STORE);
      request.onsuccess = () => {
        db = request.result;
        db.onversionchange = () => db.close();
        try {
          const read2 = db.transaction(MIRROR_STORE, "readonly").objectStore(MIRROR_STORE).get(MIRROR_KEY);
          read2.onsuccess = () => loaded(read2.result);
          read2.onerror = () => loaded(null);
        } catch {
          loaded(null);
        }
      };
      request.onerror = () => settle2();
    } catch {
      return null;
    }
    return {
      ready,
      get: () => known ? record : null,
      set(value) {
        if (!known) {
          pending = value;
          return true;
        }
        record = value;
        return write(value);
      }
    };
  }
  function whenMirrorReady(mirror, run, { wait = 3e4, setTimer = setTimeout } = {}) {
    let done = false;
    const go = () => {
      if (done) return;
      done = true;
      run();
    };
    if (!mirror?.ready) {
      go();
      return;
    }
    mirror.ready.then(go, go);
    setTimer(go, wait);
  }
  var randomToken = () => Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
  var day = (time) => new Date(time).toISOString().slice(0, 10);
  var STORAGE_FAILED = `${KEEPER}'s storage failed the daily check, so your settings may not be saving`;
  function checkStorage({ storage, mirror, now = Date.now(), token = randomToken() }) {
    let kept;
    try {
      kept = asRecord(storage.get(CHECK_KEY, null));
    } catch (error) {
      return { ok: false, at: now, cause: error, message: `${KEEPER}'s storage couldn't be read (${error?.message ?? error}), so your settings may not be saved.` };
    }
    const before = mirror?.get() ?? null;
    const earlier = before && !(now - Number(before.at) < RECENT);
    const lost = earlier && (!kept || kept.token !== before.token && !(Number(kept.at) > Number(before.at))) ? `${KEEPER} didn't keep what HushFacebook Web saved on ${day(before.at)}. If you didn't reinstall the script or clear its storage since then, your settings may not be saving.` : null;
    try {
      storage.set(CHECK_KEY, { token, at: now });
      const back = asRecord(storage.get(CHECK_KEY, null));
      if (!back || back.token !== token) {
        return { ok: false, at: now, message: `${KEEPER} didn't give back what HushFacebook Web just saved, so your settings may not be saving.` };
      }
    } catch (error) {
      return { ok: false, at: now, cause: error, message: `${KEEPER} wouldn't save (${error?.message ?? error}), so your settings may not be saving.` };
    }
    mirror?.set({ token, at: now });
    return lost ? { ok: false, at: now, message: lost } : { ok: true, at: now };
  }
  function scheduleStorageCheck({ tasks, storage, mirror, log, toast, diagnostics, now = () => Date.now() }) {
    let result = null;
    tasks.add(CHECK_KEY, () => {
      result = checkStorage({ storage, mirror, now: now() });
      if (!result.ok) {
        log?.error(result.cause ? STORAGE_FAILED : result.message, result.cause);
        toast?.(result.message, { tone: "error" });
      }
      diagnostics?.changed();
    }, { lastSeen: () => mirror?.get()?.at ?? 0 });
    diagnostics?.add("Storage check", () => {
      if (result) return result.ok ? `Passed ${new Date(result.at).toLocaleString()}` : `Failed: ${result.message}`;
      const kept = attempt(() => asRecord(storage.get(CHECK_KEY, null)), null);
      return kept ? `Last ran ${new Date(kept.at).toLocaleString()}, runs again within a day` : "Runs within a day";
    });
  }

  // src/core/style.js
  function renderFeatureCss(features2, settings, log, base = []) {
    const parts = [];
    if (settings.get("paused") !== true) {
      for (const part of base) {
        try {
          parts.push(`/* ${part.id} */
${part.css(settings.get)}`);
        } catch (error) {
          log?.error(`The ${part.id} styles couldn't be built`, error);
        }
      }
    }
    for (const feature of features2) {
      if (!feature.css || !settings.enabled(feature.id)) continue;
      try {
        parts.push(`/* ${feature.id} */
${typeof feature.css === "function" ? feature.css(settings.get) : feature.css}`);
      } catch (error) {
        log?.error(`${feature.title}: its styles couldn't be built`, error);
      }
    }
    return parts.join("\n");
  }
  function mountFeatureStyles({ features: features2, settings, log, doc = document, base = [] }) {
    const style = doc.createElement("style");
    style.dataset.hushfacebookWeb = "features";
    const render = () => {
      style.textContent = renderFeatureCss(features2, settings, log, base);
    };
    render();
    whenRootReady(() => (doc.head ?? doc.documentElement).append(style), doc);
    settings.subscribe(render);
    return style;
  }

  // src/core/json-walk.js
  var SKIP = /* @__PURE__ */ Symbol("hfw.skip");
  function walk(root, visit) {
    const stack = [root];
    while (stack.length) {
      const value = stack.pop();
      if (value === null || typeof value !== "object") continue;
      if (visit(value) === SKIP) continue;
      if (Array.isArray(value)) {
        for (let i = value.length - 1; i >= 0; i--) stack.push(value[i]);
      } else {
        for (const key in value) stack.push(value[key]);
      }
    }
  }

  // src/features/feed/feed-category.js
  var FEED_CATEGORIES = [
    "UNKNOWN",
    "ORGANIC",
    "ENGAGEMENT",
    "FIXED_POSITION",
    "PROMOTION",
    "SPONSORED",
    "END_OF_FEED_CONTENT",
    "FB_STORIES",
    "HIGH_VALUE_PROMOTION",
    "FB_STORIES_ENGAGEMENT",
    "SHOWCASE",
    "FB_SHORTS",
    "TRENDING",
    "ENGAGEMENT_QP",
    "MULTI_FB_STORIES_TRAY",
    "END_OF_FEED_REELS",
    "FB_SHORTS_FALLBACK",
    "FRIENDLY_FEED_MID_CARD",
    "FRIENDLY_FEED_PROMOTION",
    "INJECTED_STORY",
    "LIMITED_PERSONALIZATION_NOTICE"
  ];
  function readCategoryHash(postId, enc) {
    if (postId == null || typeof enc !== "string") return null;
    const base = sha256Hex(String(postId));
    return FEED_CATEGORIES.find((_, index) => sha256Hex(base + index) === enc) ?? null;
  }
  var isObject = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
  var read = /* @__PURE__ */ new WeakMap();
  function feedCategory(edge) {
    if (!isObject(edge)) return null;
    if (typeof edge.category === "string") return edge.category;
    const sensitive = edge.cat_sensitive;
    if (!isObject(sensitive)) return null;
    if (typeof sensitive.cat === "string") return sensitive.cat;
    if (!read.has(sensitive)) read.set(sensitive, readCategoryHash(edge.node?.post_id, sensitive.enc));
    return read.get(sensitive);
  }

  // src/features/feed/ad-markers.js
  var isObject2 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
  var LABEL_TYPENAME = "CometStorySponsoredLabelStrategy";
  var FOLLOW_TYPENAME = "CometFeedStoryFollowButtonStrategy";
  var JOIN_TYPENAME = "GroupJoinForumAction";
  var PYMK_TYPENAME = "PaginatedPeopleYouMayKnowFeedUnit";
  var GROUPS_TYPENAME = "GroupsYouShouldJoinFeedUnit";
  var HASHED = '"cat_sensitive":{"enc":"';
  var SUGGESTED = /* @__PURE__ */ new Set(["ENGAGEMENT", "ENGAGEMENT_QP"]);
  var PROMOTED = /* @__PURE__ */ new Set(["PROMOTION", "HIGH_VALUE_PROMOTION", "FRIENDLY_FEED_PROMOTION"]);
  function storyMatches(node, test) {
    let found = false;
    const shared = /* @__PURE__ */ new Set();
    walk(node, (value) => {
      if (found || shared.has(value)) return SKIP;
      if (value !== node && "node" in value && "cursor" in value) return SKIP;
      if (isObject2(value.attached_story)) shared.add(value.attached_story);
      if (test(value)) found = true;
      return void 0;
    });
    return found;
  }
  var storyHas = (node, typename) => storyMatches(node, (value) => value.__typename === typename);
  var hasSponsoredLabel = (node) => storyHas(node, LABEL_TYPENAME);
  function titleHas(node, typename) {
    const title = node?.comet_sections?.context_layout?.story?.comet_sections?.title;
    return isObject2(title) ? storyHas(title, typename) : storyHas(node, typename);
  }
  function groupInHref(href) {
    const match = /\/groups\/([^/?#]+)/.exec(String(href ?? ""));
    return match ? match[1].toLowerCase() : null;
  }
  function joinGroups(node) {
    const groups2 = /* @__PURE__ */ new Set();
    const title = node?.comet_sections?.context_layout?.story?.comet_sections?.title;
    storyMatches(isObject2(title) ? title : node, (value) => {
      if (value.__typename === JOIN_TYPENAME && value.group?.id != null) groups2.add(String(value.group.id).toLowerCase());
      return false;
    });
    for (const to of [node?.to, title?.story?.to]) {
      if (!isObject2(to) || to.__typename !== "Group") continue;
      if (to.id != null) groups2.add(String(to.id).toLowerCase());
      const name = groupInHref(to.url);
      if (name) groups2.add(name);
    }
    return groups2;
  }
  var isOwnGroupPost = (edge, node) => titleHas(node, JOIN_TYPENAME) && feedCategory(edge) === "ORGANIC";
  function ownGroupPosts(doc) {
    const posts = [];
    walk(doc, (value) => {
      if ("cursor" in value && isObject2(value.node) && isOwnGroupPost(value, value.node)) posts.push(joinGroups(value.node));
      return void 0;
    });
    return posts;
  }
  var FEEDS = {
    queries: /^(?:CometNewsFeedPaginationQuery|GroupsCometCrossGroupFeedPaginationQuery)$/,
    routes: (route) => route?.type === "home" || /^\/groups\/feed\/?$/.test(route?.path ?? "")
  };
  var FEEDS_AND_SEARCH = {
    queries: /^(?:CometNewsFeedPaginationQuery|GroupsCometCrossGroupFeedPaginationQuery|SearchCometResultsPaginatedResultsQuery)$/,
    routes: (route) => FEEDS.routes(route) || route?.type === "search"
  };
  var INSTREAM_ADS = {
    queries: /^useInstreamAdsHaloFetcherQuery$/,
    routes: () => false
  };
  var GENAI_TYPENAME = "CometFeedStoryGenAIContentTransparencyStrategy";
  var isAiLabel = (value) => isObject2(value) && value.__typename === GENAI_TYPENAME && (value.was_detected_as_ai_generated === true || value.was_self_disclosed_as_ai_generated === true || Boolean(value.ai_generated_detected_info?.gen_ai_transparency_type));
  function hasAiLabel(story) {
    if (!isObject2(story)) return false;
    const metadata = story.comet_sections?.context_layout?.story?.comet_sections?.metadata;
    const own = Array.isArray(metadata) ? metadata.some(isAiLabel) : storyMatches(story, isAiLabel);
    if (own) return true;
    const shared = story.comet_sections?.content?.story?.attached_story ?? story.attached_story;
    return shared !== story && isObject2(shared) && hasAiLabel(shared);
  }
  var SIDE_AD_TYPENAME = "AdsSideFeedUnit";
  var isSideAdUnit = (value) => isObject2(value) && value.__typename === SIDE_AD_TYPENAME;
  var storyOf = (edge, node) => isObject2(node) && node.__typename === "Story" ? node : edge.rendering_strategy?.view_model?.click_model?.story ?? edge.rendering_strategy?.view_model?.story ?? null;
  var AD_MARKERS = [
    {
      id: "category",
      feature: "hideSponsoredPosts",
      surface: "news feed (older shape)",
      seen: "not yet",
      text: ['"SPONSORED"'],
      match: (edge) => edge.category === "SPONSORED",
      action: "drop-node"
    },
    {
      id: "cat_sensitive",
      feature: "hideSponsoredPosts",
      surface: "news feed",
      seen: "2026-10-10: on every feed edge, cat null on organic stories",
      text: ['"SPONSORED"'],
      match: (edge) => isObject2(edge.cat_sensitive) && edge.cat_sensitive.cat === "SPONSORED",
      action: "drop-node"
    },
    {
      id: "sponsored_data",
      feature: "hideSponsoredPosts",
      surface: "news feed (older shape)",
      seen: "not yet",
      text: ['"sponsored_data":{'],
      match: (edge, node) => isObject2(node) && node.sponsored_data != null,
      action: "drop-node"
    },
    {
      id: "th_dat_spo",
      feature: "hideSponsoredPosts",
      surface: "news feed",
      seen: "2026-10-10: null on every organic feed story, set inside a search ad",
      text: ['"th_dat_spo":{'],
      match: (edge, node) => isObject2(node) && node.th_dat_spo != null,
      action: "drop-node"
    },
    {
      id: "sponsored label",
      feature: "hideSponsoredPosts",
      surface: "news feed",
      seen: '2026-10-10: the "Ad" label section of a search ad',
      text: [`"${LABEL_TYPENAME}"`],
      // Only on real edges (with a cursor): a wrapper holding an ad deep inside isn't an ad.
      match: (edge, node) => isObject2(node) && "cursor" in edge && hasSponsoredLabel(node),
      action: "drop-node"
    },
    // After the rows above, which name the drop when they see it too.
    {
      id: "sponsored category",
      feature: "hideSponsoredPosts",
      surface: "news feed (Facebook's category for the edge)",
      seen: "2026-10-22: 41 hashed SPONSORED stories and 2 plain ones in 250 Home answers, every one caught by th_dat_spo or cat_sensitive as well",
      text: [HASHED, '"SPONSORED"'],
      match: (edge, node) => isObject2(node) && feedCategory(edge) === "SPONSORED",
      action: "drop-node"
    },
    {
      id: "AdsSideFeedUnit",
      feature: "hideSponsoredPosts",
      surface: "Home's right column (the Sponsored box)",
      seen: "2026-10-21: inline CometRightSideHeaderCardsQuery data on every Home load, the Sponsored box first in viewer.auxColumnUnits.nodes with two ads, Friend requests after it",
      text: [`"${SIDE_AD_TYPENAME}"`],
      kind: "object",
      match: (value) => Array.isArray(value.nodes) && value.nodes.some(isSideAdUnit),
      action: "drop-items",
      list: "nodes",
      drop: isSideAdUnit
    },
    {
      id: "MarketplaceFeedAdStory",
      feature: "hideSponsoredMarketplace",
      surface: "Marketplace",
      seen: "2026-10-10: 8 ad cards pruned in the page, grid intact",
      text: ['"MarketplaceFeedAdStory"'],
      match: (edge, node) => isObject2(node) && node.__typename === "MarketplaceFeedAdStory",
      action: "drop-node"
    },
    {
      id: "SEARCH_ADS",
      feature: "hideSponsoredSearch",
      surface: "search results",
      seen: "2026-10-10: the ad result pruned with its story",
      text: ['"SEARCH_ADS"'],
      match: (edge, node) => isObject2(node) && node.role === "SEARCH_ADS",
      action: "drop-node"
    },
    {
      id: "instream_video_ad_breaks_comet",
      feature: "hideSponsoredReels",
      surface: "videos and reels in the feed, search, Marketplace and video pages (the ad break schedule)",
      seen: "2026-10-10: each video part comes as {id, instream_extra_config, instream_video_ad_breaks_comet}, in feed pages, video containers, Marketplace, search and inline page data; filled with MID_ROLL breaks (60 s, 120 s) on longer videos and null on the rest",
      text: ['"instream_video_ad_breaks_comet":{'],
      kind: "object",
      match: (value) => {
        const schedule = value.instream_video_ad_breaks_comet;
        return isObject2(schedule) && ("mid_rolls" in schedule || "pre_roll" in schedule);
      },
      action: "empty-list",
      empty: { instream_video_ad_breaks_comet: null }
    },
    {
      id: "instream_video_ad_breaks",
      feature: "hideSponsoredReels",
      surface: "videos and reels (the ads fetched for a break)",
      seen: "2026-10-11: useInstreamAdsHaloFetcherQuery sent {scrubber: {instream_video_ad_breaks: [], post_roll_ad_break: null}} for all 31 videos and reels the test account opened; a filled answer not seen yet. Both keys only ever came in that answer",
      text: ['"instream_video_ad_breaks":[{', '"post_roll_ad_break":{'],
      scope: INSTREAM_ADS,
      kind: "object",
      match: (value) => "instream_video_ad_breaks" in value && "post_roll_ad_break" in value && (Array.isArray(value.instream_video_ad_breaks) && value.instream_video_ad_breaks.length > 0 || isObject2(value.post_roll_ad_break)),
      action: "empty-list",
      empty: { instream_video_ad_breaks: [], post_roll_ad_break: null }
    },
    {
      id: "reels_showcase",
      feature: "hideReelsInFeed",
      surface: "news feed and groups feed (rows of reels)",
      seen: "2026-10-11: a Home inline Relay response carries a ShowcaseFeedUnit with SHOWCASE_SHORT_VIDEO and six ShowcaseShortVideoAttachment items; its page markup has not been captured",
      text: ['"ShowcaseFeedUnit"'],
      scope: FEEDS,
      kind: "object",
      match: (value) => value.__typename === "ShowcaseFeedUnit" && value.showcase_story_type === "SHOWCASE_SHORT_VIDEO" && Array.isArray(value.showcase_item) && value.showcase_item.length > 0,
      action: "empty-list",
      empty: { showcase_item: [] }
    },
    // Before follow_button and group_join: the group row's cards carry Join buttons too, and the
    // first row that matches names the drop.
    {
      id: "people_you_may_know",
      feature: "hideSuggestedPosts",
      surface: "news feed (the People you may know row)",
      seen: '2026-10-21: 6 in two Home scrolls, each the first edge of a feed page, titled "People you may know" with 7 people; none in 84 units on 2026-10-11 or 140 posts on 2026-10-22',
      text: [`"${PYMK_TYPENAME}"`],
      scope: FEEDS,
      match: (edge, node) => isObject2(node) && "cursor" in edge && node.__typename === PYMK_TYPENAME,
      action: "drop-node"
    },
    {
      id: "group_suggestions",
      feature: "hideSuggestedPosts",
      surface: "news feed (the Your group suggestions row)",
      seen: '2026-10-21: 15 in three Home scrolls, each the first edge of a feed page, titled "Your group suggestions" with 20 groups',
      text: [`"${GROUPS_TYPENAME}"`],
      scope: FEEDS,
      match: (edge, node) => isObject2(node) && "cursor" in edge && node.__typename === GROUPS_TYPENAME,
      action: "drop-node"
    },
    {
      id: "follow_button",
      feature: "hideSuggestedPosts",
      surface: "news feed and groups feed (Pages and people you don't follow)",
      seen: '2026-10-11: 36 of 137 captured Home stories, always in the title section, drawn as "Name · Follow"',
      text: [`"${FOLLOW_TYPENAME}"`],
      scope: FEEDS,
      match: (edge, node) => isObject2(node) && "cursor" in edge && titleHas(node, FOLLOW_TYPENAME),
      action: "drop-node"
    },
    {
      id: "group_join",
      feature: "hideSuggestedPosts",
      surface: "news feed and groups feed (groups you aren't in)",
      seen: '2026-10-11: 17 of 137 captured Home stories, always in the title section, drawn as "Group · Join"; 2026-10-22: one ORGANIC story in 250 Home answers carried it too, and stays',
      text: [`"${JOIN_TYPENAME}"`],
      scope: FEEDS,
      match: (edge, node) => isObject2(node) && "cursor" in edge && titleHas(node, JOIN_TYPENAME) && !isOwnGroupPost(edge, node),
      action: "drop-node"
    },
    {
      id: "suggested category",
      feature: "hideSuggestedPosts",
      surface: "news feed (Facebook's category for the edge)",
      seen: "2026-10-22: 269 hashed ENGAGEMENT stories in 250 Home answers, 267 with a Follow or Join button and 2 people's photo posts with neither; ENGAGEMENT_QP plain on every People you may know and group suggestions row",
      text: [HASHED, '"ENGAGEMENT"', '"ENGAGEMENT_QP"'],
      scope: FEEDS,
      match: (edge, node) => isObject2(node) && SUGGESTED.has(feedCategory(edge)),
      action: "drop-node"
    },
    {
      id: "genai_label",
      feature: "hideAiPosts",
      surface: "news feed, groups feed and search results (posts labeled as made with AI)",
      seen: "2026-10-11: 5 labeled stories, 1 on Home, 1 in the groups feed and 3 in search results, all detected rather than disclosed",
      text: [`"${GENAI_TYPENAME}"`],
      scope: FEEDS_AND_SEARCH,
      match: (edge, node) => "cursor" in edge && hasAiLabel(storyOf(edge, node)),
      action: "drop-node"
    },
    {
      id: "promotion category",
      feature: "hidePromotions",
      surface: "news feed (Facebook's category for the edge: its own promotions)",
      seen: "not yet: none in 250 Home answers on 2026-10-22",
      text: [HASHED, '"PROMOTION"', '"HIGH_VALUE_PROMOTION"', '"FRIENDLY_FEED_PROMOTION"'],
      scope: FEEDS,
      match: (edge, node) => isObject2(node) && PROMOTED.has(feedCategory(edge)),
      action: "drop-node"
    }
  ];
  var DROPPED_BY = { "drop-node": ["node", "rendering_strategy"] };
  var textOf = (rows) => [...new Set(rows.flatMap((row) => row.text))];
  var AD_MARKER_TEXT = textOf(AD_MARKERS);
  function markersFor(feature) {
    const rows = AD_MARKERS.filter((row) => row.feature === feature);
    return { rows, text: textOf(rows) };
  }
  function adMarkerFor(value, rows = AD_MARKERS) {
    if (!isObject2(value)) return null;
    const edge = "node" in value;
    return rows.find((row) => (row.kind ?? "edge") === "edge" ? edge && row.match(value, value.node) : row.match(value)) ?? null;
  }
  function inScope(row, ctx, route) {
    if (!row.scope) return true;
    if (ctx?.transport === "json-parse") return Boolean(route && row.scope.routes(route()));
    return row.scope.queries.test(ctx?.friendlyName ?? "");
  }
  var matchId = (value) => value.node?.post_id ?? value.node?.id ?? value.id ?? null;
  function adRule(feature, enabled, onPrune, { route, diagnostics, reason } = {}) {
    const { rows, text } = markersFor(feature);
    const noting = Boolean(diagnostics && reason);
    return {
      id: feature,
      enabled,
      markers: text,
      match: (ctx) => ctx.transport === "json-parse" || ctx.path.startsWith("/api/graphql"),
      transform(doc, ctx, stage) {
        const active2 = rows.filter((row) => inScope(row, ctx, route));
        if (!active2.length) return false;
        const decisions = [];
        const report = noting ? (row, value) => decisions.push({ post: matchId(value), rule: reason, signal: row.id, layer: "data" }) : void 0;
        const fired = pruneAds(doc, active2, report);
        if (!fired.length) return false;
        later(stage, () => {
          for (const decision of decisions) diagnostics.decide(decision);
          onPrune?.(fired);
        });
        return true;
      }
    };
  }
  function ownGroupsRule(id, enabled, onPost, { route } = {}) {
    return {
      id,
      enabled,
      observe: true,
      markers: [`"${JOIN_TYPENAME}"`],
      match: (ctx) => ctx.transport === "json-parse" || ctx.path.startsWith("/api/graphql"),
      transform(doc, ctx) {
        if (inScope({ scope: FEEDS }, ctx, route)) for (const groups2 of ownGroupPosts(doc)) onPost(groups2);
        return false;
      }
    };
  }
  function pruneAds(doc, rows = AD_MARKERS, report) {
    const fired = [];
    walk(doc, (value) => {
      const row = adMarkerFor(value, rows);
      if (!row) return void 0;
      report?.(row, value);
      if (row.action === "empty-list") {
        for (const [key, empty] of Object.entries(row.empty)) if (key in value) value[key] = Array.isArray(empty) ? [] : empty;
      } else if (row.action === "drop-items") {
        value[row.list] = value[row.list].filter((item) => !row.drop(item));
      } else {
        for (const key of DROPPED_BY[row.action]) delete value[key];
      }
      fired.push(row.id);
      return SKIP;
    });
    return fired;
  }

  // src/core/dom/visible-text.js
  var INVISIBLE = /[\u061C\u115F\u1160\u200B-\u200F\u202A-\u202E\u2060-\u2069\u3164\uFEFF\uFFA0]|\u034F|\u17B4|\u17B5|[\u180B-\u180F]|[\uFE00-\uFE0F]/g;
  function normalizeText(value) {
    return String(value ?? "").replace(INVISIBLE, "").replace(/\u00A0/g, " ").replace(/\s+/g, " ").trim();
  }
  var viewOf = (element) => element.ownerDocument?.defaultView ?? globalThis;
  function isHidden(element, boundary = null) {
    const view2 = viewOf(element);
    const stop = boundary?.parentElement ?? null;
    for (let current = element; current && current !== stop; current = current.parentElement) {
      if (current.hidden || current.getAttribute?.("aria-hidden") === "true") return true;
      const style = view2.getComputedStyle?.(current);
      if (style) {
        if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return true;
        if (Number.parseFloat(style.opacity || "1") <= 0.01) return true;
        if (style.fontSize && Number.parseFloat(style.fontSize) <= 0) return true;
      }
      if (current === boundary) break;
    }
    return false;
  }
  function hasBox(rect) {
    return Boolean(rect && rect.width > 0 && rect.height > 0);
  }
  function visibleText(element, accept = null) {
    const walker = element.ownerDocument.createTreeWalker(
      element,
      4
      /* NodeFilter.SHOW_TEXT */
    );
    const hidden = /* @__PURE__ */ new Map();
    let text = "";
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const parent = node.parentElement;
      if (!hidden.has(parent)) hidden.set(parent, isHidden(parent, element) || accept !== null && !accept(parent));
      if (!hidden.get(parent)) text += node.nodeValue;
    }
    return text;
  }
  function ownText(element) {
    let text = "";
    for (const node of element.childNodes) if (node.nodeType === 3) text += node.nodeValue;
    return text;
  }

  // src/core/dom/label-cache.js
  var MAX_TEXT = 40;
  function createLabelCache({ doc = globalThis.document, max = 500 } = {}) {
    const texts = /* @__PURE__ */ new Map();
    let observer = null;
    function record(element) {
      if (!element.id) return;
      const text = normalizeText(element.textContent);
      if (!text || text.length > MAX_TEXT) return;
      texts.delete(element.id);
      texts.set(element.id, text);
      if (texts.size > max) texts.delete(texts.keys().next().value);
    }
    function capture(node) {
      if (node?.nodeType !== 1) return;
      record(node);
      for (const element of node.querySelectorAll("[id]")) record(element);
    }
    return {
      capture,
      get: (id) => texts.get(id) ?? null,
      get size() {
        return texts.size;
      },
      start() {
        if (observer) return;
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        observer = new Observer((records) => {
          for (const entry of records) for (const node of entry.addedNodes) capture(node);
        });
        const begin = () => {
          if (!observer) return;
          observer.observe(doc.documentElement, { childList: true, subtree: true });
          capture(doc.documentElement);
        };
        whenRootReady(begin, doc);
      },
      stop() {
        observer?.disconnect();
        observer = null;
      }
    };
  }

  // src/features/feed/sponsored-dom.js
  var AD_LABELS = /* @__PURE__ */ new Map([
    ["ad", "Ad"],
    ["advertiser link", "Ad"],
    ["paid", "Ad"],
    ["paid partnership", "Ad"],
    ["sponsored", "Sponsored"]
  ]);
  function adLabel(value) {
    const key = normalizeText(value).replace(/^[·•]\s*/, "").replace(/\s*[·•]$/, "").toLowerCase();
    return AD_LABELS.has(key) ? key : null;
  }
  var HEADER_EXCLUSIONS = [
    "story_message",
    "title",
    "description",
    "like_button",
    "comment_button",
    "share_button"
  ].map((role) => `[data-ad-rendering-role="${role}"]`).join(", ") + ', [data-ad-rendering-role^="cta"]';
  var BODY_START = '[data-ad-rendering-role="story_message"], [data-ad-rendering-role="title"], video, img[src]';
  var NOT_A_LABEL = 'h1, h2, h3, h4, h5, h6, [role="heading"], [data-ad-rendering-role="profile_name"]';
  var CTA = '[data-ad-rendering-role^="cta"]';
  var MAX_LABEL = 24;
  var MAX_SOURCE = 400;
  var ownerOf2 = (element) => element.closest(CANDIDATE_SELECTOR);
  var namesSomeone = (element) => Boolean(element?.closest(NOT_A_LABEL) || element?.querySelector?.(NOT_A_LABEL));
  var within = (element, post, selector) => {
    const found = element.closest(selector);
    return Boolean(found && post.contains(found));
  };
  function headerTest(post) {
    const postRect = post.getBoundingClientRect();
    const layout = hasBox(postRect);
    const bodyStart = post.querySelector(BODY_START);
    const headerBottom = postRect.top + Math.min(230, Math.max(115, postRect.height * 0.28));
    return (element) => {
      if (ownerOf2(element) !== post || within(element, post, HEADER_EXCLUSIONS)) return false;
      if (layout) {
        const rect = element.getBoundingClientRect();
        if (hasBox(rect)) {
          return rect.top >= postRect.top - 4 && rect.top <= headerBottom && rect.left >= postRect.left - 8 && rect.right <= postRect.right + 8;
        }
      }
      return !bodyStart || Boolean(element.compareDocumentPosition(bodyStart) & 4) || element.contains(bodyStart);
    };
  }
  var styleOf = (element) => element.ownerDocument.defaultView.getComputedStyle(element);
  function glyphRecords(container, { layout, accept = null }) {
    const box2 = layout ? container.getBoundingClientRect() : null;
    const records = [];
    for (const leaf of [...container.querySelectorAll("span, div")].slice(0, 180)) {
      if (leaf.children.length) continue;
      const text = ownText(leaf);
      if (!text || text.length > 3 || isHidden(leaf, container) || accept && !accept(leaf)) continue;
      const style = styleOf(leaf);
      if (style.position === "absolute" || style.position === "fixed") continue;
      const order = Number.parseFloat(style.order);
      const record = { text, left: Number.NaN, top: Number.NaN, order: Number.isFinite(order) ? order : null };
      if (layout) {
        const rect = [...leaf.getClientRects()].find((r) => hasBox(r) && r.right >= box2.left - 2 && r.left <= box2.right + 2 && r.bottom >= box2.top - 2 && r.top <= box2.bottom + 2);
        if (!rect) continue;
        record.left = rect.left;
        record.top = rect.top;
      }
      records.push(record);
      if (records.length > 40) break;
    }
    return records;
  }
  function glyphStrings(records) {
    const strings = /* @__PURE__ */ new Set();
    const joined = (list, key) => normalizeText(list.slice().sort((a, b) => a[key] - b[key]).map((r) => r.text).join(""));
    const reorders = (list) => list.length >= 2 && new Set(list.map((r) => r.order)).size >= 2;
    const rows = [];
    for (const record of records.filter((r) => Number.isFinite(r.left) && Number.isFinite(r.top))) {
      let row = rows.find((candidate) => Math.abs(candidate.top - record.top) <= 3);
      if (!row) rows.push(row = { top: record.top, records: [] });
      row.records.push(record);
    }
    for (const row of rows) {
      strings.add(joined(row.records, "left"));
      const ordered2 = row.records.filter((r) => r.order !== null);
      if (reorders(ordered2)) strings.add(joined(ordered2, "order"));
    }
    const ordered = records.filter((r) => r.order !== null);
    if (reorders(ordered)) strings.add(joined(ordered, "order"));
    return [...strings].filter(Boolean);
  }
  function isScrambled(element) {
    const style = styleOf(element);
    if (element.children.length < 2 || element.children.length > 96) return false;
    return style.display === "flex" || style.display === "inline-flex" || [...element.children].some((child2) => /(?:^|;)\s*order\s*:/i.test(child2.getAttribute("style") ?? ""));
  }
  function decodeGlyphs(container, layout) {
    const accept = (leaf) => !leaf.closest(NOT_A_LABEL);
    return glyphStrings(glyphRecords(container, { layout, accept })).map(adLabel).find(Boolean) ?? null;
  }
  var MAX_USE_LINKS = 16;
  var useTarget = (use) => {
    const ref = use.getAttribute("href") ?? use.getAttribute("xlink:href") ?? "";
    return ref.startsWith("#") ? ref.slice(1) : null;
  };
  function referencedTexts(use, doc, labelCache) {
    const values = [];
    const seen = /* @__PURE__ */ new Set();
    let ids = [useTarget(use)];
    for (let link = 0; link < MAX_USE_LINKS && ids.length; link++) {
      const next = [];
      for (const id of ids) {
        if (!id || seen.has(id)) continue;
        seen.add(id);
        const target2 = doc.getElementById(id);
        if (!target2) {
          values.push(labelCache?.get(id));
          continue;
        }
        for (const source of link ? [target2] : [target2, target2.nextElementSibling]) {
          if (source && !namesSomeone(source)) values.push(source.textContent);
        }
        if (namesSomeone(target2)) continue;
        const inner = target2.localName === "use" ? [target2] : [...target2.querySelectorAll("use")].slice(0, 8);
        next.push(...inner.map(useTarget));
      }
      ids = next;
    }
    return values;
  }
  function readsAsLabel(element) {
    const values = [element.getAttribute("aria-label"), element.getAttribute("title"), element.innerText, element.textContent];
    return values.map(adLabel).find(Boolean) ?? null;
  }
  function isAdsAboutLink(href, depth = 0) {
    let url2;
    try {
      url2 = new URL(String(href ?? "").replace(/&amp;/g, "&"), "https://www.facebook.com/");
    } catch {
      return false;
    }
    const host2 = url2.hostname.toLowerCase();
    if (host2 !== "facebook.com" && !host2.endsWith(".facebook.com")) return false;
    if (/^\/ads\/about\/?$/.test(url2.pathname)) return true;
    return url2.pathname === "/l.php" && depth < 2 && isAdsAboutLink(url2.searchParams.get("u"), depth + 1);
  }
  var GROUP_PAGES2 = /* @__PURE__ */ new Set(["category", "create", "discover", "feed", "for_you", "joins", "notifications", "search"]);
  function isGroupLink(href) {
    try {
      const match = new URL(href, "https://www.facebook.com/").pathname.match(/^\/groups\/([^/?#]+)/i);
      return Boolean(match && !GROUP_PAGES2.has(match[1].toLowerCase()));
    } catch {
      return false;
    }
  }
  function readAdSignals(post, { labelCache } = {}) {
    const doc = post.ownerDocument;
    const layout = hasBox(post.getBoundingClientRect());
    const inHeader = headerTest(post);
    const visible = (element) => !isHidden(element, post) && (!layout || hasBox(element.getBoundingClientRect()));
    const cta = [...post.querySelectorAll(CTA)].find((element) => ownerOf2(element) === post) ?? null;
    const groupOrigin = [...post.querySelectorAll("a[href]")].some((a) => inHeader(a) && isGroupLink(a.getAttribute("href")));
    const corroborated = Boolean(cta) && !groupOrigin;
    const found = (signal, label) => ({ signal, label: AD_LABELS.get(label), corroborated });
    const headerText = (holder) => inHeader(holder) && !within(holder, post, NOT_A_LABEL);
    for (const element of [...post.querySelectorAll("span, div")].slice(0, 260)) {
      if (!inHeader(element) || within(element, post, NOT_A_LABEL) || !visible(element)) continue;
      if (element.textContent.length > MAX_SOURCE) continue;
      const values = [ownText(element), element.children.length ? visibleText(element, headerText) : element.textContent];
      for (const value of values) {
        const text = normalizeText(value);
        if (text && text.length <= MAX_LABEL && adLabel(text)) return found("header label", adLabel(text));
      }
    }
    for (const element of post.querySelectorAll("[aria-labelledby]")) {
      if (!inHeader(element)) continue;
      for (const id of normalizeText(element.getAttribute("aria-labelledby")).split(" ")) {
        const target2 = id && doc.getElementById(id);
        if (namesSomeone(target2)) continue;
        const label = target2 ? readsAsLabel(target2) ?? (isScrambled(target2) ? decodeGlyphs(target2, layout) : null) : adLabel(labelCache?.get(id));
        if (label) return found("labelledby", label);
      }
    }
    for (const svg of post.querySelectorAll("svg")) {
      if (!inHeader(svg)) continue;
      const values = [...svg.querySelectorAll("text")].map((text) => text.textContent);
      for (const use of svg.querySelectorAll("use")) values.push(...referencedTexts(use, doc, labelCache));
      const label = values.map(adLabel).find(Boolean);
      if (label) return found("svg", label);
    }
    for (const element of [...post.querySelectorAll("span, div")].slice(0, 260)) {
      if (!inHeader(element) || within(element, post, NOT_A_LABEL) || !isScrambled(element) || isHidden(element, post)) continue;
      const label = decodeGlyphs(element, layout);
      if (label) return found("glyph order", label);
    }
    for (const a of post.querySelectorAll("a[href]")) {
      if (inHeader(a) && isAdsAboutLink(a.getAttribute("href"))) return { signal: "ads link", label: "Ad", corroborated };
    }
    return corroborated ? { adButton: true } : null;
  }
  function watchSponsoredPosts({ posts, hider, enabled, labelCache, onAd, onAdButton, schedule = setTimeout, cancel = clearTimeout }) {
    const RETRIES2 = [300, 1200, 3e3];
    const timers = /* @__PURE__ */ new Map();
    const settled = /* @__PURE__ */ new WeakSet();
    function forget(element) {
      for (const timer of timers.get(element) ?? []) cancel(timer);
      timers.delete(element);
      settled.delete(element);
    }
    function check(element) {
      if (!enabled() || settled.has(element) || !element.isConnected) return;
      const result = readAdSignals(element, { labelCache });
      if (result?.signal) {
        settled.add(element);
        for (const timer of timers.get(element) ?? []) cancel(timer);
        timers.delete(element);
        if (hider.hide(element, "Sponsored", void 0, result.signal)) onAd?.(result, element);
        return;
      }
      if (result?.adButton && !timers.get(element)?.length) onAdButton?.(element);
    }
    function track({ element }) {
      forget(element);
      timers.set(element, RETRIES2.map((delay) => schedule(() => {
        timers.get(element)?.shift();
        check(element);
      }, delay)));
      check(element);
    }
    const stops = [
      posts.on("post/add", track),
      posts.on("post/update", ({ element }) => check(element)),
      posts.on("post/remove", ({ element }) => forget(element))
    ];
    return {
      check,
      // A fresh look at every post, after the switch comes back on.
      recheckAll() {
        for (const post of posts.current()) track(post);
      },
      stop() {
        for (const stop of stops) stop();
        for (const element of [...timers.keys()]) forget(element);
      }
    };
  }

  // src/features/feed/sponsored-column.js
  var COLUMN_AD_MARK = "data-hfw-column-ad";
  var COLUMN_AD_CSS = `[${COLUMN_AD_MARK}] { display: none !important; }`;
  var COLUMN = '[role="complementary"]';
  var HEADING = 'h1, h2, h3, h4, h5, h6, [role="heading"]';
  var hasAdMenu = (element) => [...element.querySelectorAll('[role="button"][aria-label]')].some((button) => /sponsored content$/i.test(normalizeText(button.getAttribute("aria-label"))));
  function intoFacebook(href) {
    let url2;
    try {
      url2 = new URL(href, "https://www.facebook.com/");
    } catch {
      return false;
    }
    const host2 = url2.hostname.toLowerCase();
    return (host2 === "facebook.com" || host2.endsWith(".facebook.com")) && url2.pathname !== "/l.php";
  }
  function linksPastAds(block2) {
    for (const a of block2.querySelectorAll("a[href]")) {
      if (!intoFacebook(a.getAttribute("href"))) continue;
      let inAd = false;
      for (let up = a; up && up !== block2; up = up.parentElement) {
        if (hasAdMenu(up)) {
          inAd = true;
          break;
        }
      }
      if (!inAd) return true;
    }
    return false;
  }
  var holdsAnotherHeading = (block2, heading) => [...block2.querySelectorAll(HEADING)].some((other) => other !== heading && !heading.contains(other) && !other.contains(heading));
  function columnAdBoxes(doc) {
    const boxes = [];
    for (const column of doc.querySelectorAll(COLUMN)) {
      for (const heading of column.querySelectorAll(HEADING)) {
        if (!adLabel(heading.textContent)) continue;
        let box2 = heading;
        for (let parent = box2.parentElement; parent && parent !== column; parent = parent.parentElement) {
          if (holdsAnotherHeading(parent, heading) || linksPastAds(parent)) break;
          box2 = parent;
        }
        if (box2 !== heading) boxes.push(box2);
      }
    }
    return boxes;
  }
  function touchesColumn(records) {
    for (const record of records) {
      const target2 = record.target.nodeType === 1 ? record.target : record.target.parentElement;
      if (target2?.closest(COLUMN)) return true;
      for (const node of record.addedNodes) {
        if (node.nodeType === 1 && (node.matches(COLUMN) || node.querySelector(COLUMN))) return true;
      }
    }
    return false;
  }
  function watchColumnAds({ doc, enabled, onAd }) {
    const told = /* @__PURE__ */ new WeakSet();
    const check = () => {
      if (!enabled()) return;
      const boxes = columnAdBoxes(doc);
      for (const marked of doc.querySelectorAll(`[${COLUMN_AD_MARK}]`)) {
        if (!boxes.includes(marked)) marked.removeAttribute(COLUMN_AD_MARK);
      }
      for (const box2 of boxes) {
        if (!box2.hasAttribute(COLUMN_AD_MARK)) box2.setAttribute(COLUMN_AD_MARK, "");
        if (told.has(box2)) continue;
        told.add(box2);
        onAd?.(box2);
      }
    };
    const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
    const observer = new Observer((records) => {
      if (touchesColumn(records)) check();
    });
    whenRootReady(() => {
      observer.observe(doc.documentElement, { childList: true, subtree: true });
      check();
    }, doc);
    return {
      check,
      stop: () => observer.disconnect()
    };
  }

  // src/features/feed/hide-sponsored-posts.js
  var ROWS_PER_SIGNAL_SHOWN = 5;
  var UNREAD_BUTTONS_BEFORE_WARNING = 3;
  function summary(counts) {
    const parts = [...counts].slice(0, ROWS_PER_SIGNAL_SHOWN).map(([name, n]) => `${name} ${n}`);
    return parts.length ? parts.join(", ") : "None yet";
  }
  var hide_sponsored_posts_default = {
    id: "hideSponsoredPosts",
    section: "feed",
    android: "Hide sponsored posts",
    title: "Hide sponsored posts",
    description: "Removes ads from the news feed and Home's right column before Facebook draws them, and hides any that get drawn anyway.",
    default: true,
    css: () => COLUMN_AD_CSS,
    setup({ doc, net, posts, hider, log, settings, diagnostics, enabled }) {
      const data = /* @__PURE__ */ new Map();
      const page = /* @__PURE__ */ new Map();
      const unread = /* @__PURE__ */ new WeakSet();
      let unreadCount = 0;
      let warnedPast = false;
      let warnedUnread = false;
      const changed = () => diagnostics?.changed();
      const hiddenOnPage = (signal, corroborated, expected = false) => {
        page.set(signal, (page.get(signal) ?? 0) + 1);
        if (net && !expected && !warnedPast) {
          warnedPast = true;
          log.warn(`An ad got past the data rules and was hidden on the page instead (${signal}${corroborated ? ", with an ad button" : ""}). The data rules may need an update.`);
        }
        changed();
      };
      if (net) {
        net.transformResponses(adRule("hideSponsoredPosts", enabled, (fired) => {
          for (const id of fired) data.set(id, (data.get(id) ?? 0) + 1);
          changed();
        }, { diagnostics, reason: "Sponsored" }));
      }
      diagnostics?.add("Ads taken out of the data", () => net ? summary(data) : "Off: the script can't reach the page's data", { shareable: true });
      diagnostics?.add("Ads hidden on the page", () => summary(page), { shareable: true });
      const column = doc ? watchColumnAds({ doc, enabled, onAd: () => hiddenOnPage("right column", false, true) }) : null;
      if (!posts || !hider) {
        settings?.subscribe(() => column?.check());
        return;
      }
      const labelCache = createLabelCache({ doc });
      if (enabled()) labelCache.start();
      let postLabelsRead = 0;
      const watcher = watchSponsoredPosts({
        posts,
        hider,
        enabled,
        labelCache,
        onAd({ signal, corroborated }) {
          postLabelsRead++;
          hiddenOnPage(signal, corroborated);
        },
        onAdButton(element) {
          if (unread.has(element)) return;
          unread.add(element);
          unreadCount++;
          if (!warnedUnread && unreadCount >= UNREAD_BUTTONS_BEFORE_WARNING && postLabelsRead === 0) {
            warnedUnread = true;
            log.warn(`${unreadCount} posts had an ad button but no ad label the script could read. Facebook may have changed how it marks ads.`);
          }
          changed();
        }
      });
      let on = enabled();
      settings.subscribe(() => {
        if (enabled() === on) return;
        on = enabled();
        if (on) {
          labelCache.start();
          watcher.recheckAll();
          column?.check();
        } else {
          labelCache.stop();
          hider.showAll("Sponsored");
        }
      });
      diagnostics?.add("Posts with an ad button and no readable label", () => String(unreadCount));
    }
  };

  // src/core/dom/post-checks.js
  var RETRIES = [300, 1200, 3e3];
  function watchPostChecks({ posts, enabled, check, retries = RETRIES, schedule = setTimeout, cancel = clearTimeout }) {
    const timers = /* @__PURE__ */ new Map();
    const done = /* @__PURE__ */ new WeakSet();
    function forget(element) {
      for (const timer of timers.get(element) ?? []) cancel(timer);
      timers.delete(element);
      done.delete(element);
    }
    function run(element) {
      if (!enabled() || done.has(element) || !element.isConnected) return;
      if (!check(element)) return;
      done.add(element);
      for (const timer of timers.get(element) ?? []) cancel(timer);
      timers.delete(element);
    }
    function track({ element }) {
      forget(element);
      timers.set(element, retries.map((delay) => schedule(() => {
        timers.get(element)?.shift();
        run(element);
      }, delay)));
      run(element);
    }
    const stops = [
      posts.on("post/add", track),
      posts.on("post/update", ({ element }) => run(element)),
      posts.on("post/remove", ({ element }) => forget(element))
    ];
    return {
      // A fresh look at every post, after the switch comes back on.
      recheckAll() {
        for (const post of posts.current()) track(post);
      },
      stop() {
        for (const stop of stops) stop();
        for (const element of [...timers.keys()]) forget(element);
      }
    };
  }

  // src/features/feed/hide-suggested-posts.js
  var BUTTONS = /* @__PURE__ */ new Map([["follow", "Follow"], ["join", "Join"]]);
  var OWN_GROUPS_KEPT = 200;
  var authorHeading = (post) => [...post.querySelectorAll('h2, h3, h4, [role="heading"]')].find((h2) => h2.closest(CANDIDATE_SELECTOR) === post) ?? null;
  function suggestionButton(post) {
    const heading = authorHeading(post);
    if (!heading) return null;
    for (const button of heading.querySelectorAll('[role="button"], button')) {
      const name = BUTTONS.get(normalizeText(visibleText(button)).toLowerCase());
      if (name) return name;
    }
    return null;
  }
  function headingGroups(post) {
    const heading = authorHeading(post);
    if (!heading) return [];
    return [...heading.querySelectorAll("a[href]")].map((a) => groupInHref(a.getAttribute("href"))).filter(Boolean);
  }
  var tally = (map, key) => map.set(key, (map.get(key) ?? 0) + 1);
  var summary2 = (map) => map.size ? [...map].map(([name, n]) => `${name} ${n}`).join(", ") : "None yet";
  var hide_suggested_posts_default = {
    id: "hideSuggestedPosts",
    section: "feed",
    android: "Hide suggested and promoted posts",
    title: "Hide suggested posts",
    description: "Hides posts from Pages, people and groups you don't follow that Facebook mixes into Home and your groups feed, plus the People you may know and group suggestion rows on Home.",
    default: true,
    setup({ net, router, posts, hider, settings, diagnostics, enabled }) {
      const data = /* @__PURE__ */ new Map();
      const page = /* @__PURE__ */ new Map();
      const ownGroups = /* @__PURE__ */ new Set();
      const own = { data: 0, page: 0 };
      const changed = () => diagnostics?.changed();
      const route = () => router?.current();
      if (net) {
        net.transformResponses(adRule("hideSuggestedPosts", enabled, (fired) => {
          for (const id of fired) tally(data, id);
          changed();
        }, { route, diagnostics, reason: "Suggested" }));
        net.transformResponses(ownGroupsRule("hideSuggestedPosts-own-groups", enabled, (groups2) => {
          own.data++;
          for (const group of groups2) {
            ownGroups.delete(group);
            ownGroups.add(group);
          }
          while (ownGroups.size > OWN_GROUPS_KEPT) ownGroups.delete(ownGroups.values().next().value);
          changed();
        }, { route }));
      }
      diagnostics?.add("Suggested posts taken out of the data", () => net ? summary2(data) : "Off: the script can't reach the page's data", { shareable: true });
      diagnostics?.add("Suggested posts hidden on the page", () => summary2(page), { shareable: true });
      diagnostics?.add("Posts from your groups kept despite a Join button", () => `${own.data} in the data, ${own.page} on the page`, { shareable: true });
      if (!posts || !hider) return;
      const watcher = watchPostChecks({
        posts,
        enabled,
        check(element) {
          if (!FEEDS.routes(route())) return true;
          const button = suggestionButton(element);
          if (!button) return false;
          if (button === "Join" && headingGroups(element).some((group) => ownGroups.has(group))) {
            own.page++;
            changed();
            return true;
          }
          if (hider.hide(element, "Suggested")) {
            tally(page, button);
            changed();
          }
          return true;
        }
      });
      let on = enabled();
      settings.subscribe(() => {
        if (enabled() === on) return;
        on = enabled();
        if (on) watcher.recheckAll();
        else hider.showAll("Suggested");
      });
    }
  };

  // src/features/feed/hide-reels-in-feed.js
  var REEL_LINK = 'a[href*="/reel/"]';
  var NOT_A_ROW = '[data-focus-target="stories_tray"], [role="region"], [role="dialog"], [role="complementary"], [role="navigation"]';
  var MIN_REELS = 2;
  var reelIdOf = (href) => href?.match(/\/reels?\/(\d+)/)?.[1] ?? null;
  var REELS_TAB = /^(?:https?:\/\/[^/]+)?\/reels?\/?(?:[?#]|$)/;
  function reelUnit(unit) {
    if (!unit.matches("[aria-posinset]") || unit.parentElement?.closest(CANDIDATE_SELECTOR)) return null;
    const reels = /* @__PURE__ */ new Set();
    for (const a of unit.querySelectorAll("a[href]")) {
      const href = a.getAttribute("href");
      const id = reelIdOf(href);
      if (id) reels.add(id);
      else if (!REELS_TAB.test(href)) return null;
    }
    return reels.size >= MIN_REELS ? unit : null;
  }
  function reelRowOf(link) {
    const unit = link.closest(CANDIDATE_SELECTOR);
    if (unit) return reelUnit(unit);
    for (let row = link; row?.parentElement; row = row.parentElement) {
      if (row.matches(CANDIDATE_SELECTOR) || row.matches(NOT_A_ROW)) return null;
      const list = row.parentElement;
      const besidePosts = [...list.children].some((sibling) => sibling !== row && sibling.querySelector(CANDIDATE_SELECTOR));
      if (!besidePosts) continue;
      if (row.querySelector(CANDIDATE_SELECTOR) || row.querySelector(NOT_A_ROW)) return null;
      const reels = new Set([...row.querySelectorAll(REEL_LINK)].map((a) => reelIdOf(a.getAttribute("href"))).filter(Boolean));
      return reels.size >= MIN_REELS ? row : null;
    }
    return null;
  }
  var hide_reels_in_feed_default = {
    id: "hideReelsInFeed",
    section: "feed",
    android: "Hide Reels in the feed",
    title: "Hide reel rows in the feed",
    description: "Hides the rows of reels Facebook puts between posts on Home and in your groups feed. Reels your friends post stay.",
    default: false,
    setup({ net, doc, win, router, hider, log, settings, diagnostics, enabled }) {
      let dataHidden = 0;
      if (net) {
        net.transformResponses(adRule("hideReelsInFeed", enabled, (fired) => {
          dataHidden += fired.length;
          diagnostics?.changed();
        }, { route: () => router?.current(), diagnostics, reason: "Reels" }));
      }
      diagnostics?.add("Reel rows taken out of the data", () => net ? String(dataHidden) : "Off: the script can't reach the page's data");
      if (!hider || !doc) return;
      let hidden = 0;
      let queued = false;
      const hiddenRows = /* @__PURE__ */ new Set();
      const onHome = () => router?.current()?.type === "home";
      const stillRow = (row) => [...row.querySelectorAll(REEL_LINK)].some((link) => reelRowOf(link) === row);
      function sweep(root = doc.body) {
        if (!enabled() || !onHome() || !root) return;
        for (const row of hiddenRows) {
          if (row.isConnected && stillRow(row)) continue;
          hiddenRows.delete(row);
          if (row.isConnected) hider.show(row, "Reels");
        }
        const rows = /* @__PURE__ */ new Set();
        for (const link of root.querySelectorAll(REEL_LINK)) {
          const row = reelRowOf(link);
          if (row && !hider.isHidden(row)) rows.add(row);
        }
        for (const row of rows) {
          if (hider.hide(row, "Reels")) {
            hiddenRows.add(row);
            hidden++;
            diagnostics?.changed();
          }
        }
      }
      function schedule() {
        if (queued) return;
        queued = true;
        (win ?? globalThis).setTimeout(() => {
          queued = false;
          try {
            sweep();
          } catch (error) {
            log?.error("Looking for reel rows failed", error);
          }
        }, 250);
      }
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      const observer = new Observer((records) => {
        for (const record of records) {
          if (hiddenRows.size && [...hiddenRows].some((row) => row.contains(record.target))) {
            schedule();
            return;
          }
          for (const node of record.addedNodes) {
            if (node.nodeType === 1 && (node.matches(REEL_LINK) || node.querySelector(REEL_LINK))) {
              schedule();
              return;
            }
          }
        }
      });
      const begin = () => {
        observer.observe(doc.body, { childList: true, subtree: true });
        schedule();
      };
      whenBodyReady(begin, doc);
      let on = enabled();
      settings.subscribe(() => {
        if (enabled() === on) return;
        on = enabled();
        if (on) schedule();
        else {
          hiddenRows.clear();
          hider.showAll("Reels");
        }
      });
      router?.subscribe(() => schedule());
      diagnostics?.add("Reel rows hidden", () => String(hidden));
    }
  };

  // src/features/feed/hide-stories-tray.js
  var HOME = 'html[data-hfw-route="home"]';
  var TRAY = '[data-focus-target="stories_tray"]';
  var POSTS = '[aria-posinset], [role="article"]';
  var COMPOSER_MARK = "data-hfw-composer";
  var TRAY_SELECTORS = [
    `${HOME} ${TRAY}`,
    // The innermost data-virtualized block around the tray, so its space goes too. Never one
    // that also holds a post.
    `${HOME} [data-virtualized]:has(${TRAY}):not(:has([data-virtualized] ${TRAY}, ${POSTS}))`
  ];
  var COMPOSER_SELECTORS = [
    `${HOME} [role="region"][aria-label="Create a post"]`,
    `${HOME} [${COMPOSER_MARK}]`
  ];
  function composerBlock(doc) {
    const tray = doc.querySelector(TRAY);
    if (!tray) return null;
    for (let block2 = tray; block2.parentElement; block2 = block2.parentElement) {
      const column = block2.parentElement;
      if (column === doc.body || column.matches('[role="main"]')) return null;
      if (!column.querySelector(POSTS)) continue;
      const before = block2.previousElementSibling;
      if (!before || before.matches('[role="banner"], [role="navigation"]')) return null;
      if (before.querySelector(`${TRAY}, ${POSTS}, [role="banner"], [role="navigation"]`)) return null;
      return before.querySelector('[role="button"]') ? before : null;
    }
    return null;
  }
  var hide_stories_tray_default = {
    id: "hideStoriesTray",
    section: "feed",
    android: "Hide Stories tray",
    title: "Hide Stories tray",
    description: "Takes the Stories row off the top of Home. Stories still open from a friend's profile or a link.",
    default: false,
    options: [
      { key: "composer", type: "toggle", label: `Also hide the "What's on your mind?" box`, default: true }
    ],
    css: (get) => {
      const selectors = [...TRAY_SELECTORS, ...get("hideStoriesTray.composer") ? COMPOSER_SELECTORS : []];
      return `${selectors.join(",\n")} { display: none !important; }`;
    },
    setup({ doc, win, log, option, enabled }) {
      if (!doc) return;
      let queued = false;
      let marked = null;
      const mark = () => {
        queued = false;
        if (!enabled() || !option("composer")) return;
        try {
          const block2 = composerBlock(doc);
          if (!block2) return;
          block2.setAttribute(COMPOSER_MARK, "");
          marked = block2;
        } catch (error) {
          log?.error("Looking for the What's on your mind box failed", error);
        }
      };
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      const observer = new Observer(() => {
        if (queued || marked?.isConnected) return;
        queued = true;
        (win ?? globalThis).setTimeout(mark, 200);
      });
      const begin = () => {
        observer.observe(doc.body, { childList: true, subtree: true });
        mark();
      };
      whenBodyReady(begin, doc);
    }
  };

  // node_modules/re2js/build/index.js
  var RE2Flags = class RE2Flags2 {
    static FOLD_CASE = 1;
    static LITERAL = 2;
    static CLASS_NL = 4;
    static DOT_NL = 8;
    static ONE_LINE = 16;
    static NON_GREEDY = 32;
    static PERL_X = 64;
    static UNICODE_GROUPS = 128;
    static WAS_DOLLAR = 256;
    static LOOKBEHIND = 512;
    static MATCH_NL = RE2Flags2.CLASS_NL | RE2Flags2.DOT_NL;
    static PERL = RE2Flags2.CLASS_NL | RE2Flags2.ONE_LINE | RE2Flags2.PERL_X | RE2Flags2.UNICODE_GROUPS;
    static POSIX = 0;
    static UNANCHORED = 0;
    static ANCHOR_START = 1;
    static ANCHOR_BOTH = 2;
  };
  var PublicFlags = {
    CASE_INSENSITIVE: 1,
    DOTALL: 2,
    MULTILINE: 4,
    DISABLE_UNICODE_GROUPS: 8,
    LONGEST_MATCH: 16,
    LOOKBEHINDS: 512
  };
  var ASCII_SIZE = 128;
  var ASCII_TO_UPPER = new Int32Array(ASCII_SIZE);
  var ASCII_TO_LOWER = new Int32Array(ASCII_SIZE);
  var MAX_BMP = 65535;
  for (let i = 0; i < ASCII_SIZE; i++) {
    if (i >= 97 && i <= 122) ASCII_TO_UPPER[i] = i - 32;
    else ASCII_TO_UPPER[i] = i;
    if (i >= 65 && i <= 90) ASCII_TO_LOWER[i] = i + 32;
    else ASCII_TO_LOWER[i] = i;
  }
  var Codepoint = class {
    static CODES = Object.freeze({
      "\x07": 7,
      "\b": 8,
      "	": 9,
      "\n": 10,
      "\v": 11,
      "\f": 12,
      "\r": 13,
      " ": 32,
      '"': 34,
      $: 36,
      "&": 38,
      "'": 39,
      "(": 40,
      ")": 41,
      "*": 42,
      "+": 43,
      "-": 45,
      ".": 46,
      0: 48,
      1: 49,
      2: 50,
      3: 51,
      4: 52,
      5: 53,
      6: 54,
      7: 55,
      8: 56,
      9: 57,
      ":": 58,
      "<": 60,
      ">": 62,
      "?": 63,
      A: 65,
      B: 66,
      C: 67,
      F: 70,
      P: 80,
      Q: 81,
      U: 85,
      Z: 90,
      "[": 91,
      "\\": 92,
      "]": 93,
      "^": 94,
      _: 95,
      "`": 96,
      a: 97,
      b: 98,
      f: 102,
      i: 105,
      m: 109,
      n: 110,
      r: 114,
      s: 115,
      t: 116,
      v: 118,
      x: 120,
      z: 122,
      "{": 123,
      "|": 124,
      "}": 125
    });
    static toUpperCase(codepoint) {
      if (codepoint < ASCII_SIZE) return ASCII_TO_UPPER[codepoint];
      const s = String.fromCodePoint(codepoint).toUpperCase();
      const expectedLen = s.codePointAt(0) > MAX_BMP ? 2 : 1;
      if (s.length > expectedLen) return codepoint;
      const sOrigin = String.fromCodePoint(s.codePointAt(0)).toLowerCase();
      const originExpectedLen = sOrigin.codePointAt(0) > MAX_BMP ? 2 : 1;
      if (sOrigin.length > originExpectedLen || sOrigin.codePointAt(0) !== codepoint) return codepoint;
      return s.codePointAt(0);
    }
    static toLowerCase(codepoint) {
      if (codepoint < ASCII_SIZE) return ASCII_TO_LOWER[codepoint];
      const s = String.fromCodePoint(codepoint).toLowerCase();
      const expectedLen = s.codePointAt(0) > MAX_BMP ? 2 : 1;
      if (s.length > expectedLen) return codepoint;
      const sOrigin = String.fromCodePoint(s.codePointAt(0)).toUpperCase();
      const originExpectedLen = sOrigin.codePointAt(0) > MAX_BMP ? 2 : 1;
      if (sOrigin.length > originExpectedLen || sOrigin.codePointAt(0) !== codepoint) return codepoint;
      return s.codePointAt(0);
    }
  };
  var UnicodeRangeTable = class {
    /**
    * @param {Uint32Array | number[]} data
    * @param {boolean} isStride1
    */
    constructor(data, isStride1 = false) {
      this.data = data;
      this.isStride1 = isStride1;
      this.SIZE = isStride1 ? 2 : 3;
    }
    getLo(index) {
      return this.data[index * this.SIZE];
    }
    getHi(index) {
      return this.data[index * this.SIZE + 1];
    }
    getStride(index) {
      return this.isStride1 ? 1 : this.data[index * this.SIZE + 2];
    }
    get length() {
      return this.data.length / this.SIZE;
    }
  };
  var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-";
  var B64_MAP = /* @__PURE__ */ new Uint8Array(256);
  for (let i = 0; i < 64; i++) B64_MAP[B64.charCodeAt(i)] = i;
  var decodeVLQ = (str) => {
    const res = [];
    let value = 0;
    let shift = 0;
    for (let i = 0; i < str.length; i++) {
      const digit = B64_MAP[str.charCodeAt(i)];
      value |= (digit & 31) << shift;
      if ((digit & 32) === 0) {
        res.push(value);
        value = 0;
        shift = 0;
      } else shift += 5;
    }
    return res;
  };
  var decodeRanges = (str, isStride1) => {
    const res = decodeVLQ(str);
    const numRanges = isStride1 ? res.length / 2 : res.length / 3;
    const out = new Uint32Array(numRanges * 3);
    let current = 0;
    let resIdx = 0;
    for (let i = 0; i < numRanges; i++) {
      current += res[resIdx++];
      out[i * 3] = current;
      current += res[resIdx++];
      out[i * 3 + 1] = current;
      out[i * 3 + 2] = isStride1 ? 1 : res[resIdx++];
    }
    return out;
  };
  var decodeOrbit = (str) => {
    const res = decodeVLQ(str);
    const map = /* @__PURE__ */ new Map();
    let currentKey = 0;
    for (let i = 0; i < res.length; i += 2) {
      currentKey += res[i];
      const zz = res[i + 1];
      const delta = zz >>> 1 ^ -(zz & 1);
      map.set(currentKey, currentKey + delta);
    }
    return map;
  };
  var LazyMap = class {
    constructor(initializer) {
      this.initializer = initializer;
      this.cache = /* @__PURE__ */ new Map();
    }
    has(key) {
      return key in this.initializer;
    }
    get(key) {
      if (this.cache.has(key)) return this.cache.get(key);
      const fn = this.initializer[key];
      const val = fn ? fn() : null;
      this.cache.set(key, val);
      return val;
    }
  };
  var UnicodeTables = class {
    static _CASE_ORBIT = null;
    static get CASE_ORBIT() {
      if (!this._CASE_ORBIT) this._CASE_ORBIT = decodeOrbit("rCgCIgCY+rQI4QiCuuBLgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCCgCBgCBgCBgCBgCBgCBgCB+7OB-BB-BB-BB-BB-BBskQB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BC-BB-BB-BB-BB-BB-BB-BByHBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBxHBCBBBCBBBCBBB3SBmMBkNBCBBBCBBB8MBCBBB6MB6MBCBBC+EB0MB2MBCBBB6MB+MBiGBmNBiNBCBBBmKBikzCBmNBqNBkIBsNBCBBBCBBBCBBB0NBCBBB0NDCBBB0NBCBBByNByNBCBBBCBBB2NBCBBDCBBCwDFCBCBDBCBCBDBCBCBDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB9EBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCCBCBDBCBBBhGBvDBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBjICCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBH2iVBCBBBlKBwiVB+jVB+jVBCBBBlMBqEBuEBCBBBCBBBCBBBCBBBCBBB+hVB4hVB8hVBjNB7MC5MB5MCzMC1MB+0yCE5MB20yCC9MBu2yCBwyyCBo0yCChNBlNBo0yCBu-UBi0yCDlNC6-UBpNDrNIu+UDzNCm0yCBzNE0yyCBzNBpEBxNBxNBtEG1NLqxyCBkxyCnFoFrBCBBBCBBDCBBEkIBkIBkICoHHsCCqCBqCBqCCgEC+DB+DBmkOBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCC+BBgCBgCBgCBgCBgCBgCBgCBgCBrCBpCBpCBpCBmjOB-BB8BB-BB-BBgEB-BB-BByBBqgOBsDB-BBtwBB-BB-BB-BBsBBgDBCB-BB-BB-BBeB-BB-BB61OB-BB-BB-DB9DB9DBQB7DBmCE9CBrDBPBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBrFB-EBOBnHB3FB-FCCBBBNBCBBCjIBjIBjIBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgFBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB8kMB-BB6kMB-BB-BB-BB-BB-BB-BB-BB-BB-BBokMB-BB-BBkkMBkkMB-BB-BB-BB-BB-BB-BB-BB4jMB-BB-BB-BB-BB-BB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EB-EBCBBBCBoiMBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBJCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBeBCBBBCBBBCBBBCBBBCBBBCBBBCBBBdBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBCgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDL-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-C64CgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOBgmOCgmOGgmODg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FBg8FDg8FBg8FBg8FhVg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBg9rCBQBQBQBQBQBQDPBPBPBPBPBPjkC7mMB5mMBnmMBjmMBCBlmMB3lMBpiMBk8kCBCBBG-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FB-7FD-7FB-7FB-7F6FoglCEsuHRwjlCyDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCB0DBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBG1DD97OCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQDPBPBPBPBPBPEQCQCQCQCPCPCPCPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPB0EB0EBsFBsFBsFBsFBoGBoGBgIBgIBgHBgHB8HB8HDQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQBQBQBQBQBQBQBPBPBPBPBPBPBPBPBQBQCSFPBPBzEBzEBRCxnOFSFrFBrFBrFBrFBREQBQClkOFPBPBnGBnGFQBQCljOCODPBPB-GB-GBNHSF-HB-HB7HB7HBRqJ53OE9tQBrmQH4Bc3BSgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBgBBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfBfECBByZ0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BB0BBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzBBzB34BgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDBgDB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CB-CBCBBBt-UBruHBt+UB1iVBviVBCBBBCBBBCBBB3hVB5-UB9hVB7hVCCBBCCBBI9jVB9jVBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBICBBBCBBECBBN-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOB-lOC-lOG-lOzoeCBBBCBBBCBBBCBBBCBBBCBl8kCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBTCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBnECBBBCBBBCBBBCBBBCBBBCBBBCBBDCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBKCBBBCBBBnglCBCBBBCBBBCBBBCBBBCBBECBBBvyyCDCBBBCBBBgDCCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBn0yCB90yCB10yCBh0yCBn0yCCjxyCBzyyCBpxyCBg6BBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBB-CBl0yCBvjlCBCBBBCBBBt2yCBCBBBCBBBCBBBCBBBCBBBCBBBCBBBCBBBhkzCZCBB9a-5Bd-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCB-8rCm6TCBB7gBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCH-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BmlBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvChDwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCBwCFvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvCBvC1DuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCBuCCuCBuCBuCBuCBuCBuCBuCCuCBuCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCBtCCtCBtCBtCBtCBtCBtCBtCCtCBtCk2BgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEBgEO-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-DB-D+CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCL-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-B74CgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhrVgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCBgCB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BB-BhB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BB2BD1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BB1BtxekCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBkCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjCBjC");
      return this._CASE_ORBIT;
    }
    static _Print = null;
    static get Print() {
      if (!this._Print) this._Print = new UnicodeRangeTable(decodeRanges("hB9CBjBLBCpWBDFBFGBCCCBSBCsMBClBBDxBBDCBC2BBJaBFFBSVBC-FBCvBBD6BBDkDBP6BBDwBBDOBCbBDCCBJBGfBIqCBCgFBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYBDCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPBLCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGBCCBCHBDBBDVBCGBCBBCEBDIBDBBDCBICBFBBCEBDRBLBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBGMBCCBCWBCPBDIBCCBCDBIBBCCBCBBDDBDJBIVBCCBCWBCJBCEBDIBCCBCDBIBBGCBCDBDJBCCBNMBCCBCyBBCCBCFBFPBDZBCCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBN5BBFcBmBBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDBhBnCBCjBBFmBBCjBBCOBCMBmBlGBCGGD4LBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBH1CBDFBD-TBCbBE4CBIVBKXBKTBNMBCCBCBBN9CBDJBHJBHNBCKBH4CBIqBBGlCBLeBCLBFLBFEEBoBBDEBMrBBFZBHKBE9BBDgCBCcBDKBHJBHNBDtBBDLBVsCBClFBJ7BBEOBE9BBGqBBDKBJqBBG1QBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBSXBJuBBSBBDaBCMBEhBBPgBBQrEBF5UBXKBWz4BBD9LBGsBBCGGD3BBIBBPXBKGBCGBCGBCGBCGBCGBCGBCGBC9DBjBZBC4CBN1GBbPBC+BBC1CBDmDBGqBBC9CBC1CBKvBBCszcBE2BBK7KBV3FBJ8GBV7BBEJBH3BBJlCBJLBHzDBMdBEtCBCKBFgBBC2BBKNBDJBDmDBZbBLFBDFBDFBKGBCGBC7BBF9DBDJBHj9KBNWBFwBBloItLBDpDBnBGBNEBGZBCEBCCCBCCBCCBoUBhBpBBHyBBCSBCDBFEBCmEBF9FBEFBDFBDFBDCBEGBCGBOBBDLBCZBCSBCBBCOBDNBjB6DBGCBFsBBE3CBCMBEwBwBBsBBjEcBEwBBQbBFjBBKdBGqBBGdBCkBBFNBrB9EBDJBHjBBFjBBFnBBJzBBMLBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBCnCBJIBxBSBCBBGgBBEaBGaBnB3BBFTBDxBBCBBGHBCCBCcBDCBFJBIIBI-BBhBmBBFLBK1BBEcBDaBGZBIDBNGBxCoCB4ByBBOyBBItBBJJBHlBBEcBJBBxGeBCpBBCCBDBBRFBJIBiBtBBJpBBXZBnBbBVWBKtCBFjBBK9BBCEBOYBIJBH0BBCRBJmBBK-CBCTBMRBCuBB-BGBCCCBCBCOBCKBH6BBGJBHDBCHBDBBDVBCGBCBBCEBCJBDBBDCBDHHGGBDGBEEBMJBCDDClBBCJBCDDCDBCJBCBBJBBe7CBCEBfnCBJJBnF1BBDlBBjBkCBMJBHMBU5BBHJBHTBdaBDOBFWB6F7BBlDyCBNHBDDDBGBCBBCdBCBBDLBKJBnCHBDtBBDKBcnCBJyCBOoCBIJB3CHB5ChBBPJBHIBCsBBCNBLcBEfBDVBCNBqCGBCBBCrBBECCBCCBHBJJBHFBCBBCkBBCBBCFBIJBHrBBFJB3HYBIQBCoBBEcB2CQQBwBBO6cBnDuDBCEBMjGBtyCiDBOvhBBRVBL68DBGmSB61G5BBn2B4RBIeBCJBFwCBCJBHdBDFBLlCBLJBCGBCUBGSBxN5BBnG6CBGYBDYBtBqCBF4BBIQBhCEBMGBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBDDBh7D8HBEzNBHWBQQBQtBBDWBKzDB9B1HBLmBBDpCBJvDBWlCB7DTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBD9VBQEBCOBxiBeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBENBDJBFBBhKeBS5BBGxOxOBoBB3GqBBFhGhGBdBCVBJBBhHGBCDBCBBCOBCkGBDPBqBrCBFJBFBByYjCBtC8BBjGDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBBvIrBBFjDBNOBDOBCOBCkBBLtFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBmgB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIBnkzVvHB", false));
      return this._Print;
    }
    static CATEGORIES = new LazyMap({
      C: () => new UnicodeRangeTable(decodeRanges("AfBgDgBBOrWrWBHHBCBICCVuMuMnBBBzBBBE4B4BBGBcDBHQBXhGhGxBBB8BBBmDNB8BBByBBBQddBCCMEBhBGBsCiFiFJBBDBBXIICCBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBPMMBEB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKMMBDBbEByBPBDBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCB-FCBHBBHBBHBBECBIIIBLBDBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIB-BGGBLBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMBxhBPBXJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBF-6DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBrCHBxDUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIlkzVBxHvw-FB", false)),
      Cc: () => new UnicodeRangeTable(decodeRanges("AfgDgB", true)),
      Cf: () => new UnicodeRangeTable(decodeRanges("tFzqBzqBBEBXhGhGyBhMhMBxCxCs5D9-B9-BBDBbEByBEBCJBw03B6H6HBBBimEQQj7IPBhjiBDBwmFHBn0rYffB+CB", false)),
      Cn: () => new UnicodeRangeTable(decodeRanges("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBDBvzIBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-BB---BBB---BBB", false)),
      Co: () => new UnicodeRangeTable(decodeRanges("gg4B-nGh4hc9--BD9--B", true)),
      Cs: () => new UnicodeRangeTable(decodeRanges("gg2B--B", true)),
      L: () => new UnicodeRangeTable(decodeRanges("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICCiEEBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoCaBFDBuBqBBkBBBCiDBCQQBIIBLLBBBDRRCdBe4CBMZZBfBKBBFGGBUBFKKEYYBXBIKBGXBCGBRpBB7B1BBETTIJBQPBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNGB7BBBCCCBDBCXBCCCBIBCBBKDDBDBCWWBCBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNSSBkBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBkBFFkC4CBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBzC+C+CBtBBSHB3BdBOBBLrBBbjBBqBCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBhC1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBF1B1BB8zC8zCBjHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBxC2O2OBrBrBBDBGBBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBReBDlCByBIBDmDBDxCBVQBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBdRRBDBCJBLEBCoBBYCBCHBVWBEEEBwBBCEEBDDBDBDCCZCBDKBICBNFBDFBDFBKGBCGBCqBBCNBHyDBej9KBNWBFwBBloItLBDpDBnBGBNEBGCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBxB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOjBBnBbBKWB7HpBBHBBRFB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB1D-BBgBHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBqBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBGjCjCBLBhCBBCPPBNNB0mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBn7F0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFBmI9BBzEsBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCCBCBBCGBDEBKBBhHGBCDBCBBCOBCkGB8BjCBI1lB1lBBCBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB", false)),
      LC: () => new UnicodeRangeTable(decodeRanges("hCZBHZB7BLLBVBCeBCiGBCDBFvGBDZBhGDBDBBECBCHHCCBCCCBSBCyCBCqEBJlFBClBBKoBB44ClBBCGGDqBBDCBhV1CBDFBjkCKBGqBBDCBhCrBBgCMBChBBmD1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGBmIFFDJBCEEBDBHGCBCBCFBFDDBCBGEBF1B1BB8zC8zCB6DBDmDBHDBEBBNlBBCGGzoetBBTbBnEtCBCWBEDBCsCBZBBE2Z2ZBpBBGIBIvCBh6TGBNEBqgBZBHZBmlBvCBhDjBBFjBB1DKBCOBCGBCBBCKBCOBCGBCBBk2ByBBOyBB+CVBLVB74C-BBhrV-BBhBYBDYBtpZ0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BJBCTBHFB2uCjCB", false)),
      Ll: () => new UnicodeRangeTable(decodeRanges("hDZB7BqBqBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDZBiGCCEEEBBBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBDCB5XFBjkCIBC2D2DBqBBgCMBChBBnD0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBBzIEEBEEcKFDBBJDBF2B2Bs1CvBBCEEBGCFCCBCCBEBGiDCBIICFFNlBBCGG0oesBCUaCoEMCBBBC+BCBGBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCbEE2ZqBBGIBIvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFB4vChBB", false)),
      Lm: () => new UnicodeRangeTable(decodeRanges("wVRBFLBPEBICCmEGG-OnHnHlFBBuIBBFgBgBKEEhFoFoF1mBgEgE2R72B72BsDkTkTxOFBvF+BBOjBjBBjBByVOORMBg-CBByHgGgG2OsBsBBDBGiDiDB+C+CBBB34bjnBjnBBEBvIzDzDdBB6DIBxCYYpDDBEBB2OXXqEtDtDWBBoDDBKngVngVuBBBh-BFBCpBBCIB0sBhBhB2K04D04DnrTDB9PCBpBBBnRMBhCBBCPPB9-P9-PBCBCGBCBByhM9BBqGGBud0Q0QsSAB", false)),
      Lo: () => new UnicodeRangeTable(decodeRanges("qFQQhIFFBCBxGBB7ZaBFDBuBfBCJBkBBBCiDBCZZBLLBBBDRRCdBe4CBMZZBfBWVBrBYBIKBGXBCGBRoBB8B1BBETTIJBROBFHBDBBDVBCGBCEEBCBERROBBCCBPBBLJJBEBFBBDVBCGBCBBCBBCBBgBDBCUUBBBRIBCCBCVBCGBCBBCEBETTQBBYMMBGBDBBDVBCGBCBBCEBEffBCCBBBQSSCFBECBCDBEBBCCCBEEBEEBBBELBX1B1BBGBCCBCWBCPBEbbBBBCBBDBBfFFBGBCCBCWBCJBCEBEffBBBCBBQBBSIBCCBCoBBDRRGCBJCBZFBGRBEXBCIBCDDBFB7BvBBCBBNFB8BBBCCCBDBCXBCCCBIBCBBKDDBDBYDBhBgCgCBGBCjBBcEB0DqBBVRRBEBFDBEEEBIIBBBFMBNyDyDBnKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPByDrTBDQBCZBGqCBHHBIRBOSBPRBPMBCCBQzBBpBkCkCBhBBC0BBIEBDhBBCGGBkCBLeByBdBDEBMrBBFZB3BWBK0BBxFuBBSHB3BdBOBBLrBBbjBBqBCBLdByDDBCFBCBBE7hB7hBBCB4-C3BBZWBKGBCGBCGBCGBCGBCGBCGBCGBoR2B2BF1CBJCCB4CBFGGBpBBC9CBSfBxBPBhQ-tGBhC0wUBC2jBBkCnBBJrIBFPBLBBjCyByBBkCBqFoDoDEGBCCBCDBCWBezBBPxBB-BFBECCBMMBaBLWBacBIuBBuBEBDIBLEBCoBBYCBCHBVPBCFBEEEBwBBCEEBDDBDBDCCZBBEKBIPPBEBDFBDFBKGBCGByEiBBej9KBNWBFwBBloItLBDpDBkCCCBIBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBqDJBCsBBDeBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmMcBEwBBwBfBOTBCHBHlBBLdBDjBBFHBhEtCBjDnBBJzBB9CzBBN2JBKVBLHB5EFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCQQBCBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4FjBBnBDBCxJxJBoBBHBBRCBCBB5BcBLJJBUBrBRBvBUBcWBN0BB6BBBDOOBrBBhBYBbjBBeDDJiBBENNBuBBPDBWCCkBRBCYBUBBgCGBCCCBCBCOBCJBIuBBnBHBDBBDVBCGBCBBCEBETTNEBfJBCDDClBBCaaCtBtBBzBBTDBVCBfvBBVBBC5F5FBtBBqBDBlBvBBV8B8BBpBBOoCoCBZBmBGB6FrBB0GHBDDDBGBCBBCXBQCC-CHBDmBBRCCdLLBmBBIWWMtBBUTTBnCBoGgBBgBIBCkBBSyByBBcBxDGBCBBClBBWaaBEBCBBCfBPYYBnBBCBBlISBQCCBLBChBB9DwCwCB4cBnHjGBtyCgDBQvhBBSFBa68DBGmSB61GdBj3B4RBIeBSuCBSdBTvBB0BUBGSB0NnBB2MqCBGwFwFB0mHBqBfBiDyDBuwIiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBxzI2P2PBrBBiBiKiKBcBTrBBlPaBmHdBDwGwGBdBCCBCBBCGBDEBKiHiHBFBCDBCBBCOBCkGB8pBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQBlqE-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB", false)),
      Lt: () => new UnicodeRangeTable(decodeRanges("lOGDnB2sH2sHBGBJHBJHBNQQwBAB", false)),
      Lu: () => new UnicodeRangeTable(decodeRanges("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBG+B+B9zCvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBB", false)),
      M: () => new UnicodeRangeTable(decodeRanges("gYvDB0IGBoIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCgBB3BCBCRBCGBLBBeCB5BCCBFBDBBDCBKLLBbbDCB5BCCBDBFBBDCBEffBEEMCB5BCCBGBCCBCCBVBBXFBCCB5BCCBFBDBBDCBICBLBBf8B8BBDBECBCDBKpBpBBDB4BCCBFBCCBCDBIBBMBBeCB5BCCBFBCCBCDBIBBMBBQNNBCB4BBBCGBCCBCDBKLLBeeBBBnCFFBEBCCCBGBTBB+BDDBFBNHBjDDDBHBMGBqCBBcECFBByBTBCBBGKBCjBBKlDlDBSBYDBFCBCCBDGBEDBOLBCLLBCBgWCBzdDBdCBeBBfBBhCfBKuBuBBBBC2D2DBjBjB3DLBFLB8GEB6BJBCcBDxBxBBsBBDLBVEBwBQBnBIBNCBfMB5BNBxBTB5ECBCUBFHHDCBnG-BBxWgBB--CCBuEhDhDBeBrRFBqDBB1udDBCJBhBBBxCBBxIEEFYYBDBF0C0CBzBzBBQBbRBOnBnBBGBaMBtBDBwBNBlBkCkCBMBNJJBuBuBBBBzBCCBBBDBBGBBCqBqBBDBGBBtHHBCBBx5TiXiXBOBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB7DCB2BOBqBDDBLLBCBuBKBI+B+BBBBlBNBRBBtBNNBBBxBNBJDBCBB9CLBHDD+ELBWDB4BBBCGBDBBDCBKLLBDDBFBEEBkCIBCDDCDBCEBCPPBzCzCBQBYyCyCBSBsHGBDIBcBBzCQBrDMBmDOBhIOB2HFBCBBDDBCCCBuEuEBFBDGBEddBIBpBGBCDBJKKBJBvBPBnGHBoGHBCHBzCVBCNB7DFBECCBCCBFBCjCjCBDBCBBCEB8KDBKBBCxBxBBFBEEBYmnFmnFHOBpmLRBhuCEB8BGB5gBCCB1BBIDByCMMBslTslTBizEizEBsBBDWB-QEBEFBJHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB", false)),
      Mc: () => new UnicodeRangeTable(decodeRanges("joC4B4BDCBJDBCBBzBBB7BCBHBBDBBLsBsB7BCBjC7B7BBBBJCCB2B2BB7B7BCHHBDDBLLnDBBCBBECBCCBLqBqBBBB+BDB+BBB7BCCBDBDBBCBBKBBdPPB7B7BBBBGCBCCBLrBrBBsCsCBBBHHBTBBrKBBgCsFsFBFFHDDBaaBLLBBBDGBWBBDFBDLLBBB5zBffiEIIBGBCBB7KDBDCBFBBCFBhHBB7BCCKCCBJJBEByExBxBGCCBDBCBB+BffFBBD9B9BDCBCEEBxBxBBGBJBBsFWW35EBB0-dBBD5C5CBzBzBBOBvEBBwBxBxBBFFBDDBBBvDBBDBBZuBuBCuDuDDBBGuHuHBCCBCCBCC0gZCCgEuBuBBBBFBB0DZZB8B8BxBCBKBBO+C+CBBBEBBCrFrFBBBgBBB7BBBCDBDBBDCBKLLB1C1CBBBIDDCDBCBBCmDmDBBBJBBErDrDBBBHCCBCBDuHuHBBBHDBDyDyDBBBJBBCuDuDCBBHoDoDCBBFmImIBBBK4H4HBEBCBBFDDCvEvEBBBJDBF1C1CeBB-BqGqGECCoGPPrDIID2G2GBDBFBBC-K-KBNNxBBBJBBCpvQpvQBBBlxD2BBpDBB0rYBBHFB", false)),
      Me: () => new UnicodeRangeTable(decodeRanges("okBBB1xF-wB-wBBCBCCBsshBCB", false)),
      Mn: () => new UnicodeRangeTable(decodeRanges("gYvDB0IEBqIsBBCCCBCCBCCpCKBxBUBRmDmDBFBDFBDBBCDBkBffBZB8CKB7BIBKZZBCBCIBCCBCEBsBCB8BIBrBXBCfB4BCCFHBFEEBFBLBBe7B7BFDBJVVBbbDBB6BFFBFFBDDBBBEffBEEMBB6BFFBDBCBBFVVBXXBEBC7B7BDCCBCBJIIBMMBff+BNNzBEE4BCCBBBGCBCDBIBBMBBe7B7BDHHGBBVBBdBB6BBBFDBJVVBeepCIIBBBC7C7CDGBNHBjDDDBHBMGBqCBBcEC4BNBCEBCBBGKBCjBBKnDnDBCBCFBCBBDBBaBBFCBRDBODDBHHQgWgWBBBzdCBeBBfBBfBBhCBBCGBJDDBJBKuBuBBBBC2D2DBjBjB3DCBFBBKHHBBB8GBBD7B7BCGBCCCDHBHJBDxBxBBMBCeBDLBVDBxBCCBDBCGGpBIBNBBhBDBDBBCCB5BCCBEECCB7BHBDBB5ECBCMBCGBFHHEBBnG-BBxWMBFEEBKB--CCBuEhDhDBeBrRDBsDBB1udFFBIBhBBBxCBBxIEEFaaBGG4EBBbRBOnBnBBGBaKBvBCBxBDDBCBDBBoBkCkCBEBDBBDBBNJJwB0B0BCCBDBBGBBCrBrBBJJvHDDFx5Tx5TiXPBRPBuejHjH2EEBn0BCBCBBGDBpBCBFmFmFB+R+RBCBiCEB+JBBuCFBnCKByBDB8D3B3BBNBqBDDBLLBBByBDBDBBI+B+BBBBlBEBCHB-BNNB1B1BBHBLDBDgDgDBBBDCCBHHD+E+EEHBWBB6BBBEmBmBBFBEEBnCFBOECPBB2CHBDCBCYY1CFBCFFBCCBvHvHBCBHBBCBBcBB2CHBDCCBrDrDCDDBEBCmDmDCDDBCBCEBkIIBCBBhIBBCFFxEDBDBBFhBhBBIBpBFBDDBJKKBEBDCBvBMBCBBnGCCBBBCqGqGBFBCFBCzCzCBUBDGBCBBCBB7DFBECCBCCBFBCpCpCBEEC8K8KBMMB1B1BBDBGCCYmnFmnFHOBpmLLBECBhuCEB8BGB5gBgCgCBCByC5lT5lTBizEizEBsBBDWBhRCBSHBDGBfDB1ECB89B2BBFxBBJPPXEBCOBxqBGBCQBDGBCBBCEBlDhFhFBFB4L+B+BBCB9PDB-HBB0HDDIBBG7O7OBFBuDGB29lYvHB", false)),
      N: () => new UnicodeRangeTable(decodeRanges("wBJB5DBBGDDBBBitBJBnEJBnGJB9MJB3DJBFFBtDJB3DJB3DJBDFBvDMB0DJBJGBoDJBpDGBISBuDJBhDJB3DJBnCTBtIJBnCJBwWTBybCBwHJBHJBXJBtJJBhEKBmFJBHJB3FJB3CJBnEJBHJB3gBEEBEBHJBnGyBBDEB3W7BBvCVB3TdBqrBqYqYaIBPCB4KDBrEJBfHBCOBhBJBoBOBh7cJB9FJBhKFB7EJBnBJBnGJBXJB3CJB3MJB34UJBuPsBBN4BBSBB2KaBlBDBeJJnEEBrGJBvdHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBxBJBHJB3IeB-EJBrBDBxDGBnEdBhEJB9BJBxEJBITB8HJB3KJB3DJB3LJBnDJBHTBtCLBlNSB+CJB3UJB3CcBkHJBnCJB3BJBnLJBnDUBshBuDBimPJBnpCJB3CJBnEJBCGBvQJBnIWB+KCB6nXJBnuBTBNTBtDYB2iBxBBhqCJBnNJB3PJB4HJBtWIBhEJB4Y6BBCCBCDBtCsBBCOBjeMBk3CJB", false)),
      Nd: () => new UnicodeRangeTable(decodeRanges("wBJnxBJnEJnGJ9MJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJ3DJhDJ3DJnCJ3IJnCJn6BJnBJtJJhEJnFJHJ3FJ3CJnEJHJnuiBJnVJnBJnGJXJ3CJ3MJ34UJnsBJnkCJHJ9YJhEJ9BJxEJ3IJ3KJ3DJ3LJnDJHTtCJnNJnDJ3UJ3CJ3HJnCJ3BJnLJ3uQJnpCJ3CJnEJ3QJ37XJ12CxBhqCJnNJ3PJ4HJ2aJ30EJ", true)),
      Nl: () => new UnicodeRangeTable(decodeRanges("u3FCBwzCiBBDDB-zDaaBHBPCBs1dJBxyW0BBtOJJnEEBrhIuDBm8SCB", false)),
      No: () => new UnicodeRangeTable(decodeRanges("yFBBGDDBBB2pCFB5LFB5DCBmEGB6GGBSIByNJB2hBTB0jBJBhP20B20BEFBHJBnGPBqB3W3WB6BBvCVB3TdBqrB1kB1kBBCBrEJBfHBCOBhBJBoBOBxrdFBymWsBBiCDBSBB2KaBlBDB1pBHBaGBoBIBsCEBXFBhFBBDPBDtBBhCIB1BBBfCBsCEBpDHBZHBqBGBrKFBhLeB-EJBrBDBxDGBnETB8LTBmqBBBvNIBobSB0aUBn8SGB-YWBqhZTBNTBtDYBvqFIBid6BBCCBCDBtCsBBCOBjeMB", false)),
      P: () => new UnicodeRangeTable(decodeRanges("hBCBCFBCDBLBBEBBbCBCccCkBkBGEELBBEEE-VJJzOFBqBBB0BCCDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCmBmBBCBoCrCrCBDBFBBwDFBsFlTlTBHB4EuTuTtBBBvCCBoCBB+ECBCCBmBKB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBM9Z9ZBWBJTBCMBCLBfBBPBB6TDBeBB+hBNBwCBBgBJB0MVBgCDBhBBB8XDBCBBxDwEwEBtBBCfBDLBkNCBFJBDLBRNNjD7C7CjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HzqUzqUBxGxGBIBXiBBCNBCFFCBB2ECBCFBCDBLBBEBBbCBCccCCCBFB7MCB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDByO-J-JjBlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB", false)),
      Pc: () => new UnicodeRangeTable(decodeRanges("-Cg-Hg-HBUU-u3BBBZCBwHAB", false)),
      Pd: () => new UnicodeRangeTable(decodeRanges("tB9qB9qB0BiyDiyDmgBqgCqgCBEBiwDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J", false)),
      Pe: () => new UnicodeRangeTable(decodeRanges("pB0B0BgB+1D+1DC-6B-6BqtC4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECtBGCtNICEGCDBB-ozB6G6GeOCESSCCCrF0B0BgBGD", false)),
      Pf: () => new UnicodeRangeTable(decodeRanges("7F+6H+6HEddpuDCCFDDQEE", false)),
      Pi: () => new UnicodeRangeTable(decodeRanges("rFt7Ht7HDBBDaapuDCCFDDQEE", false)),
      Po: () => new UnicodeRangeTable(decodeRanges("hBCBCCBDECBLLBEEBcclCGGPBBI-V-VJzOzOBEBqB3B3BDDDtBBBVBBCBBOCCBBBrCDBnDsBsBBMBqHCB3BOBgBmImIBLLtE5D5D6DnMnMNwLwL7CLLBpFpFBNBCxDxDrCEBFBBwDFBsFlTlTBHBmY9D9DBBBoCBB+ECBCCBmBFBCDB6JBB5GBBhEGBCFBhFBBLGBdCB9DDB8BEB-BBBhCHBMjajaBJJBGBJIBDDBDCBEKBCCCBIB7kDDBCBBxDwEwEBFFBBBDDDBHBCBBCDDBLLBDBCJBDDBCCCBLBDCBtNCB6B+F+FjgdBBuICBkDLL0DFB9LDB3CBBpBCBCyByBBwBwBiDMBRBB9DDB-DBBRBB6HlxUlxUBFBDXXVBBDDBECBCDBICBHCCB2E2EBBBCCBDECBLLBEEBcclBDDB7M7MBBB9UxBxB-MoXoXoGgBgBxIIBnBxDxDBFBjCGB6CDB0ZlElEBDBtBDB+FGBuDBBCDB-DDBxBBBwCDBFOOCCB5CFBsDrJrJBCCBzDzDBDBLBBCpDpD7HWBqDCBdMBtCjEjEBBB9HpIpIBBB8E9C9CBGB0CCBCEB+CJB4GgDgDBDBrBBBmUBBrCMBwFxjBxjBBDB97CBB8zOBBmEiCiCBDBJpRpRBBBoJDBoK9lT9lTovHEB07C-a-aBAB", false)),
      Ps: () => new UnicodeRangeTable(decodeRanges("oBzBzBgB-1D-1DC-6B-6B-rCEEnB4B4BQ7T7TCff-hBMCxChBhBCGC1MUChCCCiBmhBmhBCECaTTCECtNICEGCDipzBipzB4GeeCMCESSCCCrFzBzBgBEEDAB", false)),
      S: () => new UnicodeRangeTable(decodeRanges("kBHHRCBgBCCcCCkBEBCBBDCCBCBDEEfgBgBrODBNNBGGBCCCBPB2DPPBxDxDsErIrIBBB3DCBDDDBvGvGLUUB4H4HIBBpEqLqLBHHB2H2H-DjEjEBGBlEwGwGqBmGmGiGCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WuLuLlL+E+EBgBBiLJBKIBhiBCCBBBMCBOCBOCBOBBmCOOoBCBOCBUhBB-BBBCDBCBBLCCBBBGFBCECFMMBFFBDBGDBC7B7BBFFB2LBFcBD+HBXKByCtCBXnTBtBwBBDeBLyMBX+BBFfBD1LBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBB8CBB0HBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BB6RWBKBBoDBB+EDBLDB+RCBiHPPB+9T+9TpEgBBuLPBhCBB3BHBtBDBjDCCBBBD7E7EHRRBBBgBCCcCCiEGBCGBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSmWmWBiKiKBGBnjC2kC2kCBbBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQQBgDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBrbaagBaagBaagBaagBaa9B-PB4BDBzBHBCNBCBBp2BwNwNttCEE+DiOiOBvIvIBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB", false)),
      Sc: () => new UnicodeRangeTable(decodeRanges("kB+D+DBCBqnB8D8DzPBBzPBBI2H2HoImSmS8sClmClmCBgBB37hBkuVkuVtD7E7E8GBBEBB3-HDB-4wBxtCxtC", false)),
      Sk: () => new UnicodeRangeTable(decodeRanges("+CCCoCHHFEEqQDBNNBGGBCCCBPB2DPPBjoBjoB15FCCBBBMCBOCBOCBOBB9kEBBkzdWBKBBoDBBxePPBniUniUBPB8bCCjF4g9B4g9BBDB", false)),
      Sm: () => new UnicodeRangeTable(decodeRanges("rBRRBBB+BCCuBFFmBgBgB-XwQwQBBB8xGOOoBCBOCBsEoBoBBDBHlClCBDBGBBFGDIgBgBBDDCgBgBBqIBhBBB7CffBXBpBFB2OKK3BHBwDxKxKBDBDeBLPBhIiEBX+BBFfBDhIBxBUBDFB9+zB5Z5ZCCBlFRRBBB+BCCkEHHBCBitDBBhrwBx+Bx+BagBgBagBgBagBgBagBgBat5Ft5FB-uC-uCBHB", false)),
      So: () => new UnicodeRangeTable(decodeRanges("mFDDFCCyerIrIBgEgEBvGvGLUUB4H4HkQ2L2LjEFBClElEwGqBqBoMCBQCCBBBDFBVECmEHBCFBCBBGDBmGBBxXJB0WzWzW+EhBBiLJBKIBksBBBCDBCBBLCCBHHBEBCECFMMBPPCBBC7B7BBKKBDBDDBCBBCBBCGBCeBDBBCCCBdBtIHBFTBDGBDwCBCdBanBBHnCBXKByCtCBX2FBCIBC1BBJuDBC3HBtBrBBhC-HBhQvBBWBBHmBBDpEBmHFBmLBBvBZBC4CBN1GBbPBFOOBNNWBBHBBxKBBFJBhBlBBKRRBdBMdBJQQBeBLmBBQ-JBhuG-BBx0V2BBibDBLBBC+R+RBBBqqUPBuLPBhCBB3BHBuBCBlPEEFBBOBB6JIB6BQBDCBCMBEwBwBBrBB7zBBBwSpgBpgBBGBnjC2kC2kCBGBFQBr6SDBG3qU3qUk7DvHBLCBEzNBHWBQPBhDzDB9B1HBLmBBD7BBGCBXBBIdBF8BBWhCBE7F7FB1CBqlB-PB4BDBzBHBCNBCBBp2B96C96CiEyWyWBqBBFjDBNOBDOBCOBCkBBYgFB5BcBOrBBFIBIBBPFB7E6HBG4WBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBB-B3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBC7CBLAB", false)),
      Z: () => new UnicodeRangeTable(decodeRanges("gBgEgEgvFgsCgsCBJBeBBGwBwBh9DAB", false)),
      Zl: () => new UnicodeRangeTable(decodeRanges("ohIA", true)),
      Zp: () => new UnicodeRangeTable(decodeRanges("phIA", true)),
      Zs: () => new UnicodeRangeTable(decodeRanges("gBgEgEgvFgsCgsCBJBlBwBwBh9DAB", false)),
      ASCII_Hex_Digit: () => new UnicodeRangeTable(decodeRanges("wBJIFbF", true)),
      Alphabetic: () => new UnicodeRangeTable(decodeRanges("hCZBHZBwBLLFGGBVBCeBCpOBFLBPEBICC3CeeBQBCBBDDBCHHCCBCCCBSBCyCBCqEBJlFBClBBDHHBnBBoBNBCCCBCCBCCJaBFDBeKBG3BBCGBPlDBCHBFHBFCBLCBDRRBuBBOkDBZgBBKBBFGGBWBDSBUYBIKBGXBCGBIJJBoBBLLBEGBHrCBCPBCCBFOBOSBCHBDBBDVBCGBCEEBCBEHBDBBDBBCJJFBBCEBNBBLFFBBBCFBFBBDVBCGBCBBCBBCBBFEBFBBDBBFIIBCBCSSBEBMCBCIBCCBCVBCGBCBBCEBEIBCCBCBBEQQBCBWDBFCBCHBDBBDVBCGBCBBCEBEHBDBBDBBKBBFBBCEBORRBCCBEBECBCDBEBBCCCBEEBEEBBBELBFEBECBCCBEHHpBMBCCBCWBCPBEHBCCBCCBJBBCCBCBBDDBdDBCHBCCBCWBCJBCEBEHBCCBCCBJBBGCBCDBOCBNMBCCBCoBBDHBCCBCCBCGGBCBIEBXFBCCBCRBEXBCIBCDDBFBJFBCCCBGBTBBO5BBGGBH0B0BBECBDBCXBCCCBRBCCBDEBCHHPDBhBgCgCBGBCjBBFSBFPBCjBBkC2BBCDDBDBR-BBLDBDlBBCGGDqBBCsKBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBmBPBR1CBDFBErTBDQBCZBGqCBEKBITBMUBNTBNMBCCBCBBNzBBDSBPFFkC4CBIqBBGlCBLeBCLBFIBYdBDEBMrBBFZB3BbBF+BBDTBzBYYBMMBBByBzBBCOBCHB0BpBBDDBLrBBCKBP2BBXCBLjBBDKBGqBBDCBqBDBCFBCBBEGGB+FBUhBBM1IBDFBDlBBDFBDHBCGCBdBD0BBCGBCEEBBBCGBEDBDFBFMBGCBCGB1DOORMBmDFFDJBCEEBDBHGCBCBCKBDDBGEBFSSBnBBuZzBB34BkHBHDBEBBNlBBCGGD3BBIRRBVBKGBCGBCGBCGBCGBCGBCGBCGBCfBwB2O2OBBBaIBIEBDEBF1CBHCBC5CBCDBGqBBC9CBSfBxBPBhQ-tGBhCs0VBkCtBBDsIBEPBLBBVuBBGHBEwDBoBIBDmDBDxCBVUBCgBBZzBBNjCBCtBtBBEBECCBBBLgBBGiBBOcBEyBBCLBQRRBOBLEBC2BBKNBTWBEkCBCCCZCBDPBDDBMFBDFBDFBKGBCGBCqBBCNBH6DBWj9KBNWBFwBBloItLBDpDBnBGBNEBGLBCMBCEBCCCBCCBCCBqDBiBqLBT-BBD1BBpBLB1DEBCmEBlBZBHZBM4CBEFBDFBDFBDCBkBLBCZBCSBCBBCOBDNBjB6DBmC0BBsIcBEwBBwBfBOdBGqBBGdBDjBBFHBCEBrB9EBTjBBFjBBFnBBJzBBNKBCOBCGBCBBCKBCOBCGBCBBEzBBN2JBKVBLHBZFBCpBBCIBmCFBDCCBqBBCBBEDDBVBLWBKeBiCSBCBBLVBLZBHZBnB3BBHBBhCDBCBBGHBCCBCcBrBcBEcBkBHBCbBc1BBLVBLSBORBvDoCB4ByBBOyBBOnBBjBbBEGGBVB7HpBBCBBEBBRFBzBCBEcBLJJBUBrBRBvBUBcWBKlCBsBEBL4BBKOOBXBYyBBSDBJiBBEKKB+BBCDBKBBLCCkBRBChBBDHHBCB-BGBCCCBCBCOBCJBI4BBYDBCHBDBBDVBCGBCBBCEBEHBDBBDBBEHHGGBdJBCDDClBBCJBCDDCDBCBBECCtBhCBCCBCDBVCBfhCBDBBC5F5FB0BBDGBaFBjB+BBCEE8B1BBDoCoCBZBDNBWGB6F4BBoD-BBgBHBDDDBGBCBBCdBCBBDBBDDB+CHBDtBBDFBCCCBccBxBBDJBSnCBGTTBnCBoDHB5CgBBgBIBCsBBCGBCyByBBcBDVBCNBqCGBCBBCrBBECCBCCBBBCDDBZZBEBCBBCkBBCBBCDBCYYBqBBlIWBKQBCoBBECBwDwCwCB4cBnDuDBSjGBtyCgDBQvhBBSFBa68DBGmSB61GuBBy2B4RBIeBSuCBSdBTvBBRDBgBUBGSBxNsBB0G-BBhBYBDYBtBqCBF4BBIQBhCBBCNNBFBK1mHBqBfBiDyDB+vIDBCGBCBBCiJBQeeBBBDPPBCBJrMBloCqDBGMBEIBIJBFi7Fi7FBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDYBCYBCeBCYBCeBCYBCeBCYBCeBCYBCHB15BeBHFB2GGBCQBDGBCBBCEBG9BBiBxDxDBrBBLGBRiKiKBcBTrBBlPbBlHdBDwGwGBdBCVBJBBhHGBCDBCBBCOBCkGB8BjCBEEE1lBDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1TZBHZBHZB3zD-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB", false)),
      Dash: () => new UnicodeRangeTable(decodeRanges("tB9qB9qB0BiyDiyDmgBqgCqgCBEB+BoBoBQnMnMlgDDDgBBBFdd-NUUwDxszBxszBBmBmBLqFqFhzD-J-J", false)),
      Emoji: () => new UnicodeRangeTable(decodeRanges("jBHHGJBwDFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDrGrGhFBBNBBPDDBIBsCZBCBBYVVDIBWBBvFhBBDvDBDBBCCBDyCBDCBCmIBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDDBEJBECCBEEDJBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB", false)),
      Emoji_Component: () => new UnicodeRangeTable(decodeRanges("jBHHGJB0+H2G2Gsp3B3+8B3+8BBYB8PEBxtBDBtzhY-CB", false)),
      Emoji_Modifier: () => new UnicodeRangeTable(decodeRanges("7-8DE", true)),
      Emoji_Modifier_Base: () => new UnicodeRangeTable(decodeRanges("9wJ8G8GRDB4jzD9B9BBBBDDDBBB2DBBDKBWSBEFFBBBCCBICCZqGqGBFFWFFBvFvFBBBEEB0CRRBBBKMMgSDDJHBHKKBIBDCB5B+B+BBCCBCCSCBCMBmHCBrBIB", false)),
      Emoji_Presentation: () => new UnicodeRangeTable(decodeRanges("64IBBuGDBEDDqQBBWBBzBLBsBUUOJJBSSBGGBJJGWWIBBCFFDIIFBBdkBkBCFFBBBC+B+BBBBZPP8aBB0BFFvlxDrGrG-FDDBIBsCZBCZZVDDBDBCCBWBBvFgBBNIBClCBCVBNqBBFEBNQBEEEBlCBCCCB5FBD+BBODBCXBTbbBOO3C0CBxBlCBHEEBBBDDBEDBMBBIIBkHLBF8I8IBtBBCJBC4FBxDMBEKBE4BBCFFBOBDLBFJB", false)),
      Extended_Pictographic: () => new UnicodeRangeTable(decodeRanges("pFFFu8HNN5GXX7CFBQBBwLBBNnFnFaKBFCBoGoHoHBLLK7B7BBCBCEBKGDBDDFDDCBBDIEBJJBBBGCCGLBMBBDCCBCCTDDBTTBEBCCCBEEBGGDBBFBBMBBGBBDGGBECBVVBGGBEBCDBDFFDDDBEBCDDCCCHEEHLLBQQDFFCFFBBBCMMBxBxBBBBKeP1LBBwOCBUBB0BFF7mBNN6SCCrrvDoBoBBCBlDLBQBBQPPBmBmBBIBxDBBNBBPDDBIBU3BBcOBLVVDIBCDBKWBH7FBDvDBDBBCCBDyCBDCBCDBG9HBC+BBMFBCXBIBBDHBNDDBCBDFFBOOBDDJBBKGGBBBNCBJCBDCCFHHEHHB0CBxBlCBGHBDQBECCBEBDMB7GlBBNDB5BHBLFBpBHBfBBNDBDNBKmBBNuBBCJBC4FB5CHBPxEBhI9fB", false)),
      Hex_Digit: () => new UnicodeRangeTable(decodeRanges("wBJIFbFq1-BJIFbF", true)),
      Lowercase: () => new UnicodeRangeTable(decodeRanges("hDZBwBLLFlBlBBWBCHBC2BCBQCBuBCDECBBBDCCDEEBFFDEEBBBDDDCCCDCCBCCDEECDDBDDBBBHGDCOCBSCBDDCEEC4BCBFBDDDBCCFICBjCBDiBBIBBfEBhDsBsBCEEDDBTccBhBBCBBECBCWCBDBCGDB0B0BBuBBCgBCK0BCDMCBgDCxBoBBo6CqBBCDB5XFBjkCIBC2D2DB+FBiC0ECBHBCgDCBHBJFBLHBJHBJFBLHBJHBJNBDHBJHBJHBJEBCBBHEEBBBCBBJDBDBBJHBLCBCBB6DOORMBuDEEBEEcKFDBBJDBFiBiBBOBFsasaBYBn6BvBBCEEBGCFCCBCCBGBEiDCBIICFFNlBBCGG0oesBCUaCBBBmEMCBBBC8BCBIBCCCDICFCCDCCBBBCSCGGGCMCFCCDOCWDBCCCBBB2ZqBBCNBHvCBh6TGBNEBqhBZBumBnBBpEjBB8EKBCOBCGBCBBkODDBBBCpBBCIBmoByBB+DVB75CfBhsVfB8BYBnqZZBbGBCRBbZBbDBCCCBFBCKBbZBbZBbZBbZBbZBbZBbZBbZBbbBdYBCFBbYBCFBbYBCFBbYBCFBbYBCFBC15B15BBIBCTBHFBmI9BB1lChBB", false)),
      Math: () => new UnicodeRangeTable(decodeRanges("rBRRBBBgBeeCuBuBFmBmBgB5W5WBBBDbbBDDBBBwQCBuwGccBBBMEEOPPBCBWEBMEBiCMBFEEBFFBDBTFFDJBCDDBEBHEEBDDBCCBBBCFBENBClClCBWBCFBCBBFBBFfBCHHBPPBqIBJDBVBB7CffBZBCZZMGB+NBBNJBFFBFBBDBBEEBPCCDFBMHBGBB6BCCeDBKCBxK-BBhI-PBxBUBDFB9+zB4Z4ZBEBCjFjFRCBeCCeCCkEHHBCBitDBBhrwBwoBwoBBzCBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBBhwFDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB-uCIB", false)),
      Quotation_Mark: () => new UnicodeRangeTable(decodeRanges("iBFFkEQQ96HHBaBBowDqOqOBCBOCBixzBDB+FFF7CBB", false)),
      Terminal_Punctuation: () => new UnicodeRangeTable(decodeRanges("hBLLCMMBEE-ZJJiQ6B6BpCPPCCB1FsBsBBJBCsHsHB3B3BBEBCHBgBmImIB1nB1nBBtFtFFFB4JBB2YHBmY9D9DBBBoCBB+ECBEoBoBBCBDBB7JBBjLDBjFBBLBBCCBeCB8FEB-BBBldYYBKKBBBwlDCBzJOOFLLCBBEBBtNBB8ndBBuICBkHEB-LBB3CBBgD4E4EBBB0ECBgERRB6H6HnxUDDB6B6BBBBCDBqFLLCMMBEEiCDD7hBxBxBnkBoGoG3JBB5EFBlCFB6CDB5dEBtBDB+FGBxDDBgECBiEBBHRRB5C5CBDBtDrJrJB2D2DBBBNBBnLDBEOBqDBB6HCBmQCC8HBB4CBBFBB-MCBuBmUmUBrCrCBspBspBBDB6vRBBmEiCiCBBBLqRqRBoJoJBnwTnwTovHDB", false)),
      Uppercase: () => new UnicodeRangeTable(decodeRanges("hCZBmDWBCGBiB2BCDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIJDCMCDQCDDDCCBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBDDBBBEWCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBpCDBNDBNDBNEBMDBnIFFECBDCBDEEBDBHGCBCBDDBLBBGbbBOBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoqZZBbZBbZBbCCBGDBDDBCBCHBbZBbBBCDBDHBCGBcBBCDBCEBCEEBFBcZBbZBbZBbZBbZBbZBfYBiBYBiBYBiBYBiBYBiB2pE2pEBgBBvgCZBHZBHZB", false)),
      White_Space: () => new UnicodeRangeTable(decodeRanges("JEBTlDlDbgvFgvFgsCKBeBBGwBwBh9DAB", false))
    });
    static SCRIPTS = new LazyMap({
      Adlam: () => new UnicodeRangeTable(decodeRanges("go6DrCFJFB", true)),
      Ahom: () => new UnicodeRangeTable(decodeRanges("g4lCaDOFW", true)),
      Anatolian_Hieroglyphs: () => new UnicodeRangeTable(decodeRanges("ggxCmS", true)),
      Arabic: () => new UnicodeRangeTable(decodeRanges("gwBEBCFBCNBCCBCfBCJBMZBCrDBChBBxCvBBxHhBBGqCBCcBxy8BtPBDvEBhBPBxDEBCmEBk7DeBkCFBJIBiBFBh43BDBCaBCBBCDDCJBCDBCCCHFFCECBBBCBBCDDCICBCCDDBCGBCDBCDBCCCBIBCQBGCBCEBCQB1BBB", false)),
      Armenian: () => new UnicodeRangeTable(decodeRanges("xpBlBDxBDCks9BE", true)),
      Avestan: () => new UnicodeRangeTable(decodeRanges("g4iC1BEG", true)),
      Balinese: () => new UnicodeRangeTable(decodeRanges("g4GsCCxB", true)),
      Bamum: () => new UnicodeRangeTable(decodeRanges("g1pB3CpowB4R", true)),
      Bassa_Vah: () => new UnicodeRangeTable(decodeRanges("w26CdDF", true)),
      Batak: () => new UnicodeRangeTable(decodeRanges("g+GzBJD", true)),
      Bengali: () => new UnicodeRangeTable(decodeRanges("gsCDBCHBDBBDVBCGBCEEBCBDIBDBBDDBJFFBCCBDBDYB", false)),
      Beria_Erfe: () => new UnicodeRangeTable(decodeRanges("g17CYDY", true)),
      Bhaiksuki: () => new UnicodeRangeTable(decodeRanges("ggnCICsBCNLc", true)),
      Bopomofo: () => new UnicodeRangeTable(decodeRanges("qXB6wLqBxDf", true)),
      Brahmi: () => new UnicodeRangeTable(decodeRanges("ggkCtCFjBKA", true)),
      Braille: () => new UnicodeRangeTable(decodeRanges("ggK-H", true)),
      Buginese: () => new UnicodeRangeTable(decodeRanges("gwGbDB", true)),
      Buhid: () => new UnicodeRangeTable(decodeRanges("g6FT", true)),
      Canadian_Aboriginal: () => new UnicodeRangeTable(decodeRanges("ggF-TxRlC7tgCP", true)),
      Carian: () => new UnicodeRangeTable(decodeRanges("g1gCwB", true)),
      Caucasian_Albanian: () => new UnicodeRangeTable(decodeRanges("wphCzBMA", true)),
      Chakma: () => new UnicodeRangeTable(decodeRanges("gokC0BCR", true)),
      Cham: () => new UnicodeRangeTable(decodeRanges("gwqB2BKNDJDD", true)),
      Cherokee: () => new UnicodeRangeTable(decodeRanges("g9E1CDFz7lBvC", true)),
      Chorasmian: () => new UnicodeRangeTable(decodeRanges("w9jCb", true)),
      Common: () => new UnicodeRangeTable(decodeRanges("AgCBbFBbuBBCOBCEBYgBgBiOmBBGEBDTB1DKKHCC+THHPEEhB9E9ElQiEiEB6mB6mB2MDBjJwvBwvBBBBoCBBsGBBCumBumBOIIBCBCFBCCBDmYmYBKBD2CBCKBEKBCOBShBB-BlBBCCBDFBCaBCQBqBCBF5UBXKBW-cBhIzTBDpEBhQ9CBzMUBCCCBXBQHBFDB8CBBE7C7CB0E0EBOBhBlBBKxBxBB+BBgBwCBwB5C5CBmFBhuG-BBhoWhBBnDCBmFJB1HhFhFsMPPBzuUzuUBxGxGBIBXiBBCSBCDB0ECCBeBbFBbKBLuBuBBhChCBFBCGBLEBjICBFsBBEIBxCMB0BsBBlHaBltuBDB96D8HBEzNBHWBQQBgDzDB9B1HBLmBBD9BBEQBJBBIdBF8BB2GTBNTBN2CBKYBoE0CBCmCBCBBDDDBDDBCBCLBCCCBFBCgCBCDBDHBCGBCbBCDBCEBCEEBFBCzKBDjJBDxBByjFjCBtC8BBjWrBBFjDBNOBDOBCOBCkBBLtFB5BZBCBBOrBBFIBIBBPFB7E4eBEQBEMBE5GBHLBFQQBKBF3BBJJBHnBBJdBDLBFBBPIBoB3KBJNBDMBEKBE4BBCFFBOBDLBFJBIyEBCmDBnghYffB+CB", false)),
      Coptic: () => new UnicodeRangeTable(decodeRanges("ifNxkKzDGG", true)),
      Cuneiform: () => new UnicodeRangeTable(decodeRanges("ggoC5cnDuDCEMjG", true)),
      Cypriot: () => new UnicodeRangeTable(decodeRanges("ggiCFBDCCBqBBCBBEDD", false)),
      Cypro_Minoan: () => new UnicodeRangeTable(decodeRanges("w8rCiD", true)),
      Cyrillic: () => new UnicodeRangeTable(decodeRanges("ggBkEBDoFBx6FKBhFtCtCojEfBhie-CBv8VBBhw4B9BBiBAB", false)),
      Deseret: () => new UnicodeRangeTable(decodeRanges("gghCvC", true)),
      Devanagari: () => new UnicodeRangeTable(decodeRanges("goCwCFODZh7nBfhwcJ", true)),
      Dives_Akuru: () => new UnicodeRangeTable(decodeRanges("gomCGBDDDBGBCBBCdBCBBDLBKJB", false)),
      Dogra: () => new UnicodeRangeTable(decodeRanges("ggmC7B", true)),
      Duployan: () => new UnicodeRangeTable(decodeRanges("ggvDqDGMEIIJDD", true)),
      Egyptian_Hieroglyphs: () => new UnicodeRangeTable(decodeRanges("ggsC1iBL68D", true)),
      Elbasan: () => new UnicodeRangeTable(decodeRanges("gohCnB", true)),
      Elymaic: () => new UnicodeRangeTable(decodeRanges("g-jCW", true)),
      Ethiopic: () => new UnicodeRangeTable(decodeRanges("gwEoCBCDBDGBCCCBCBDoBBCDBDgBBCDBDGBCCCBCBDOBC4BBCDBDiCBDfBEZBnvGWBKGBCGBCGBCGBCGBCGBCGBCGBjpfFBDFBDFBKGBCGBylvCGBCDBCBBCOB", false)),
      Garay: () => new UnicodeRangeTable(decodeRanges("gqjClBEcJB", true)),
      Georgian: () => new UnicodeRangeTable(decodeRanges("glElBBCGGDqBBCDBx8CqBBDCBhiElBBCGG", false)),
      Glagolitic: () => new UnicodeRangeTable(decodeRanges("ggL-Ch9sDGCQDGCBCE", true)),
      Gothic: () => new UnicodeRangeTable(decodeRanges("w5gCa", true)),
      Grantha: () => new UnicodeRangeTable(decodeRanges("g4kCDBCHBDBBDVBCGBCBBCEBDIBDBBDCBDHHGGBDGBEEB", false)),
      Greek: () => new UnicodeRangeTable(decodeRanges("wbDBCCBDDBCFFCCCBBBCCCBSBC+BBPPBnpGEBzBEBFEB1ChKhKBUBDFBDlBBDFBDHBCGCBdBD0BBCOBCNBDFBCSBDCBCIBoJ-xiB-xiB7uVuCBSgj0Bgj0BBkCB", false)),
      Gujarati: () => new UnicodeRangeTable(decodeRanges("h0CCBCIBCCBCVBCGBCBBCEBDJBCCBCCBDQQBCBDLBIGB", false)),
      Gunjala_Gondi: () => new UnicodeRangeTable(decodeRanges("grnCFCBCkBCBCFIJ", true)),
      Gurmukhi: () => new UnicodeRangeTable(decodeRanges("hwCCBCFBFBBDVBCGBCBBCBBCBBDCCBDBFBBDCBEIIBCBCIIBPB", false)),
      Gurung_Khema: () => new UnicodeRangeTable(decodeRanges("go4C5B", true)),
      Han: () => new UnicodeRangeTable(decodeRanges("g0LZBC4CBN1GBwBCCaIBPDBle-tGBhC-vUBhoWtLBDpDBpodBBNGBqgkB-2pBBhB9oEBDt0FBDwpHBQtTBjtC9QBjvBq6EBGppIB", false)),
      Hangul: () => new UnicodeRangeTable(decodeRanges("goE-HvxHBiI9CyDeiCei3dckUj9KNWFwBl9JeEFDFDFDC", true)),
      Hanifi_Rohingya: () => new UnicodeRangeTable(decodeRanges("gojCnBJJ", true)),
      Hanunoo: () => new UnicodeRangeTable(decodeRanges("g5FU", true)),
      Hatran: () => new UnicodeRangeTable(decodeRanges("gniCSCBGE", true)),
      Hebrew: () => new UnicodeRangeTable(decodeRanges("xsB2BBJaBFFBpp9BZBCEBCCCBCCBCCBIB", false)),
      Hiragana: () => new UnicodeRangeTable(decodeRanges("hiM1CBHCBi7-C+IBTeeBBBulQAB", false)),
      Imperial_Aramaic: () => new UnicodeRangeTable(decodeRanges("giiCVCI", true)),
      Inherited: () => new UnicodeRangeTable(decodeRanges("gYvDB2IBBlOKBbhXhXBCB8qEtBBDLBlPCBCMBCGBFHHEBBnG-BBtQBBjGgBB65DDBsDBBmrzBPBRNBwejHjH7iEl+uBl+uBBsBBDWBhRCBSHBDGBfDBz6rYvHB", false)),
      Inscriptional_Pahlavi: () => new UnicodeRangeTable(decodeRanges("g7iCSGH", true)),
      Inscriptional_Parthian: () => new UnicodeRangeTable(decodeRanges("g6iCVDH", true)),
      Javanese: () => new UnicodeRangeTable(decodeRanges("gsqBtCDJFB", true)),
      Kaithi: () => new UnicodeRangeTable(decodeRanges("gkkCiCLA", true)),
      Kannada: () => new UnicodeRangeTable(decodeRanges("gkDMCCCWCJCEDICCCDIBGCCDDJCC", true)),
      Katakana: () => new UnicodeRangeTable(decodeRanges("hlM5CBDCBxHPBxGuBBC3CBvgzBJBCsBBzisBDBCGBCBBCgJgJBBBzBPPBCB", false)),
      Kawi: () => new UnicodeRangeTable(decodeRanges("g4nCQCoBEc", true)),
      Kayah_Li: () => new UnicodeRangeTable(decodeRanges("goqBtBCA", true)),
      Kharoshthi: () => new UnicodeRangeTable(decodeRanges("gwiCDCBGHCCCcDCFJII", true)),
      Khitan_Small_Script: () => new UnicodeRangeTable(decodeRanges("k-7C84G84GB0OBqBAB", false)),
      Khmer: () => new UnicodeRangeTable(decodeRanges("g8F9CDJHJnPf", true)),
      Khojki: () => new UnicodeRangeTable(decodeRanges("gwkCRCuB", true)),
      Khudawadi: () => new UnicodeRangeTable(decodeRanges("w1kC6BGJ", true)),
      Kirat_Rai: () => new UnicodeRangeTable(decodeRanges("gq7C5B", true)),
      Lao: () => new UnicodeRangeTable(decodeRanges("h0DBBCCCBDBCXBCCCBVBDEBCCCBFBCJBDDB", false)),
      Latin: () => new UnicodeRangeTable(decodeRanges("hCZBHZBwBQQGWBCeBCgOBoBEB8wGlBBHwBBGDBGMBClCBiC-HByLOORMBuEBBHccSoBB42CfBj1elDBExCBVOBxZqBBCIBCDB38TGB7gBZBHZBmhCFBCpBBCIBm61BeBHFB", false)),
      Lepcha: () => new UnicodeRangeTable(decodeRanges("ggH3BEOEC", true)),
      Limbu: () => new UnicodeRangeTable(decodeRanges("goGeBCLBFLBFEEBKB", false)),
      Linear_A: () => new UnicodeRangeTable(decodeRanges("gwhC2JKVLH", true)),
      Linear_B: () => new UnicodeRangeTable(decodeRanges("gggCLCZCSCBCODNjB6D", true)),
      Lisu: () => new UnicodeRangeTable(decodeRanges("wmpBvBx1eA", true)),
      Lycian: () => new UnicodeRangeTable(decodeRanges("g0gCc", true)),
      Lydian: () => new UnicodeRangeTable(decodeRanges("gpiCZGA", true)),
      Mahajani: () => new UnicodeRangeTable(decodeRanges("wqkCmB", true)),
      Makasar: () => new UnicodeRangeTable(decodeRanges("g3nCY", true)),
      Malayalam: () => new UnicodeRangeTable(decodeRanges("goDMCCCyBCCCFFPDZ", true)),
      Mandaic: () => new UnicodeRangeTable(decodeRanges("giCbDA", true)),
      Manichaean: () => new UnicodeRangeTable(decodeRanges("g2iCmBFL", true)),
      Marchen: () => new UnicodeRangeTable(decodeRanges("wjnCfDVCN", true)),
      Masaram_Gondi: () => new UnicodeRangeTable(decodeRanges("gonCGBCBBCrBBECCBCCBHBJJB", false)),
      Medefaidrin: () => new UnicodeRangeTable(decodeRanges("gy7C6C", true)),
      Meetei_Mayek: () => new UnicodeRangeTable(decodeRanges("g3qBWqGtBDJ", true)),
      Mende_Kikakui: () => new UnicodeRangeTable(decodeRanges("gg6DkGDP", true)),
      Meroitic_Cursive: () => new UnicodeRangeTable(decodeRanges("gtiCXFTDtB", true)),
      Meroitic_Hieroglyphs: () => new UnicodeRangeTable(decodeRanges("gsiCf", true)),
      Miao: () => new UnicodeRangeTable(decodeRanges("g47CqCF4BIQ", true)),
      Modi: () => new UnicodeRangeTable(decodeRanges("gwlCkCMJ", true)),
      Mongolian: () => new UnicodeRangeTable(decodeRanges("ggGBBDCCBSBH4CBIqBB2t-BMB", false)),
      Mro: () => new UnicodeRangeTable(decodeRanges("gy6CeCJFB", true)),
      Multani: () => new UnicodeRangeTable(decodeRanges("g0kCGBCCCBCBCOBCKB", false)),
      Myanmar: () => new UnicodeRangeTable(decodeRanges("ggE-EhqmBeiDfxibT", true)),
      Nabataean: () => new UnicodeRangeTable(decodeRanges("gkiCeJI", true)),
      Nag_Mundari: () => new UnicodeRangeTable(decodeRanges("wm5DpB", true)),
      Nandinagari: () => new UnicodeRangeTable(decodeRanges("gtmCHDtBDK", true)),
      New_Tai_Lue: () => new UnicodeRangeTable(decodeRanges("gsGrBFZHKEB", true)),
      Newa: () => new UnicodeRangeTable(decodeRanges("gglC7CCE", true)),
      Nko: () => new UnicodeRangeTable(decodeRanges("g+B6BDC", true)),
      Nushu: () => new UnicodeRangeTable(decodeRanges("h-7CvsQvsQBqMB", false)),
      Nyiakeng_Puachue_Hmong: () => new UnicodeRangeTable(decodeRanges("go4DsBENDJFB", true)),
      Ogham: () => new UnicodeRangeTable(decodeRanges("g0Fc", true)),
      Ol_Chiki: () => new UnicodeRangeTable(decodeRanges("wiHvB", true)),
      Ol_Onal: () => new UnicodeRangeTable(decodeRanges("wu5DqBFA", true)),
      Old_Hungarian: () => new UnicodeRangeTable(decodeRanges("gkjCyBOyBIF", true)),
      Old_Italic: () => new UnicodeRangeTable(decodeRanges("g4gCjBKC", true)),
      Old_North_Arabian: () => new UnicodeRangeTable(decodeRanges("g0iCf", true)),
      Old_Permic: () => new UnicodeRangeTable(decodeRanges("w6gCqB", true)),
      Old_Persian: () => new UnicodeRangeTable(decodeRanges("g9gCjBFN", true)),
      Old_Sogdian: () => new UnicodeRangeTable(decodeRanges("g4jCnB", true)),
      Old_South_Arabian: () => new UnicodeRangeTable(decodeRanges("gziCf", true)),
      Old_Turkic: () => new UnicodeRangeTable(decodeRanges("ggjCoC", true)),
      Old_Uyghur: () => new UnicodeRangeTable(decodeRanges("w7jCZ", true)),
      Oriya: () => new UnicodeRangeTable(decodeRanges("h4CCCHDBDVCGCBCEDIDBDCICFBCEDR", true)),
      Osage: () => new UnicodeRangeTable(decodeRanges("wlhCjBFjB", true)),
      Osmanya: () => new UnicodeRangeTable(decodeRanges("gkhCdDJ", true)),
      Pahawh_Hmong: () => new UnicodeRangeTable(decodeRanges("g46ClCLJCGCUGS", true)),
      Palmyrene: () => new UnicodeRangeTable(decodeRanges("gjiCf", true)),
      Pau_Cin_Hau: () => new UnicodeRangeTable(decodeRanges("g2mC4B", true)),
      Phags_Pa: () => new UnicodeRangeTable(decodeRanges("giqB3B", true)),
      Phoenician: () => new UnicodeRangeTable(decodeRanges("goiCbEA", true)),
      Psalter_Pahlavi: () => new UnicodeRangeTable(decodeRanges("g8iCRIDNG", true)),
      Rejang: () => new UnicodeRangeTable(decodeRanges("wpqBjBMA", true)),
      Runic: () => new UnicodeRangeTable(decodeRanges("g1FqCEK", true)),
      Samaritan: () => new UnicodeRangeTable(decodeRanges("ggCtBDO", true)),
      Saurashtra: () => new UnicodeRangeTable(decodeRanges("gkqBlCJL", true)),
      Sharada: () => new UnicodeRangeTable(decodeRanges("gskC-ChsCH", true)),
      Shavian: () => new UnicodeRangeTable(decodeRanges("wihCvB", true)),
      Siddham: () => new UnicodeRangeTable(decodeRanges("gslC1BDlB", true)),
      Sidetic: () => new UnicodeRangeTable(decodeRanges("gqiCZ", true)),
      SignWriting: () => new UnicodeRangeTable(decodeRanges("gg2DrUQECO", true)),
      Sinhala: () => new UnicodeRangeTable(decodeRanges("hsDCBCRBEXBCIBCDDBFBEFFBEBCCCBGBHJBDCBt-gCTB", false)),
      Sogdian: () => new UnicodeRangeTable(decodeRanges("w5jCpB", true)),
      Sora_Sompeng: () => new UnicodeRangeTable(decodeRanges("wmkCYIJ", true)),
      Soyombo: () => new UnicodeRangeTable(decodeRanges("wymCyC", true)),
      Sundanese: () => new UnicodeRangeTable(decodeRanges("g8G-BhIH", true)),
      Sunuwar: () => new UnicodeRangeTable(decodeRanges("g+mChBPJ", true)),
      Syloti_Nagri: () => new UnicodeRangeTable(decodeRanges("ggqBsB", true)),
      Syriac: () => new UnicodeRangeTable(decodeRanges("g4BNC7BDCxIK", true)),
      Tagalog: () => new UnicodeRangeTable(decodeRanges("g4FVKA", true)),
      Tagbanwa: () => new UnicodeRangeTable(decodeRanges("g7FMCCCB", true)),
      Tai_Le: () => new UnicodeRangeTable(decodeRanges("wqGdDE", true)),
      Tai_Tham: () => new UnicodeRangeTable(decodeRanges("gxG+BCcDKHJHN", true)),
      Tai_Viet: () => new UnicodeRangeTable(decodeRanges("g0qBiCZE", true)),
      Tai_Yo: () => new UnicodeRangeTable(decodeRanges("g25DeCVJB", true)),
      Takri: () => new UnicodeRangeTable(decodeRanges("g0lC5BHJ", true)),
      Tamil: () => new UnicodeRangeTable(decodeRanges("i8CBBCFBECBCDBEBBCCCBEEBEEBBBELBFEBECBCDBDHHPUBm+kCxBBOAB", false)),
      Tangsa: () => new UnicodeRangeTable(decodeRanges("wz6CuCCJ", true)),
      Tangut: () => new UnicodeRangeTable(decodeRanges("g-7CgBgBB+3GBhQeBiDyDB", false)),
      Telugu: () => new UnicodeRangeTable(decodeRanges("ggDMCCCWCPDICCCDIBCCCBDDDJII", true)),
      Thaana: () => new UnicodeRangeTable(decodeRanges("g8BxB", true)),
      Thai: () => new UnicodeRangeTable(decodeRanges("hwD5BGb", true)),
      Tibetan: () => new UnicodeRangeTable(decodeRanges("g4DnCCjBFmBCjBCOCGFB", true)),
      Tifinagh: () => new UnicodeRangeTable(decodeRanges("wpL3BIBPA", true)),
      Tirhuta: () => new UnicodeRangeTable(decodeRanges("gklCnCJJ", true)),
      Todhri: () => new UnicodeRangeTable(decodeRanges("guhCzB", true)),
      Tolong_Siki: () => new UnicodeRangeTable(decodeRanges("wtnCrBFJ", true)),
      Toto: () => new UnicodeRangeTable(decodeRanges("w04De", true)),
      Tulu_Tigalari: () => new UnicodeRangeTable(decodeRanges("g8kCJBCDDClBBCJBCDDCDBCJBCBBJBB", false)),
      Ugaritic: () => new UnicodeRangeTable(decodeRanges("g8gCdCA", true)),
      Unknown: () => new UnicodeRangeTable(decodeRanges("4bBBHDBICCVuMuMnBBBzBBBE4B4BBGBcDBHKBvI9B9BBmDmDBMB8BBByBBBQddBCCMEBjBEBuHJJBDDBXXICCBBBFBBKBBDBBFHBCDBDGGBaaBEEHDBDBBXIIDGDBCCGDBDBBECBCGBFCCBFBSJBEKKEXXIDDGBBLIEBCCBNBFBBNGBIEEJBBDBBXIIDGGBKKBDDBEEBFBEDBDGGBTTBIBDHHBBBEFFBBBDCCDCBDCBECBNDBGCBEFFBCCBEBCNBWEBOEEYRRBKKEFFBFBDEEDBBFBBLGBXEEYLLGBBKEEFGBDEBEFFBLLELBOEE0BEEHDBRBBbEETCBZKKCBBICBCDBHCCJFBLBBELB7BDBekBBDCCGZZCYYBGGCIILBBFfBpClBlBBCBoBlBlBQOOBjBBnGCCBDBCBB6LFFBIICFFBqBqBFBBiBFFBIICFFBQQ6BFFBkCkCBhBhBBBBbFB3CBBHBB+UCB6CGBXIBZIBVLBOEEDLB-CBBLFBLFBbFB6CGBsBEBnCJBgBNNBCBNDBCCBrBBBGKBtBDBbFBMCB-BBBiCeeBMMBEBLFBPBBvBBBNTBuCnFnFBGB9BCBQCB-BEBsBBBMHBsBEB3QBBHBBnBBBHBBJGCgBBB2BQQPBBHUUBEEKmDmDNBBcOOBBBjBNBiBOBtEDB7UVBMUB14BBB-LEBuBCCBDBCBB5BGBDNBZIBI4BI-DhBBb6C6CBKB3GZBxC3C3CBoDoDBDBsB-C-C3CIBxBuzcuzcBBB4BIB9KTB5FHB+GTB9BCBLFB5BHBnCHBNFB1DKBfCBvCMMBCBiB4B4BBHBPBBLBBoDXBdJBHBBHBBHIBIII9BDB-DBBLFBl9KLBYDByBjoIBvLBBrDlBBILBGEBbGGCGDrUfBrBFB0BUUFDBGoEoEBCC-FCBHBBHBBHBBECBIIIBIBGBBNbbUDDQBBPhBB8DEBEDBuBCB5COOBBBCuBBvBhEBeCByBOBdDBlBIBfEBsBEBfmBmBBCBPpBB-EBBLFBlBDBlBDBpBHB1BKBNQQIDDMQQIDDBBB1BLB4JIBXJBJXBHrBrBKkCBHBBCtBtBDCBCBBYpCpCBGBKvBBUDDBDBiBCBcEBclBB5BDBVBBzBDDBDBJEEeBBEDBLGBKGBhCfBoBDBNIB3BCBeBBcEBbGBFLBIvCBqC2BB0BMB0BGBvBHBLFBnBCBeHBDvGBgBrBrBEBBDPBHHBKgBBvBHBrBVBblBBdTBYIBvCDBlBIBlCJBCBBaGBLFB2BTTBGBoBIBhDVVBJBTwBwBB8BBICCFQQMFB8BEBLFBFJJBDDBXXIDDGLLBDDBEEBCCBEBCEBIBBICBGKBLCCBCCnBLLCBBCFFLDDBGBDcB9CGGBcBpCHBLlFB3BBBnBhBBmCKBLFBOSB7BFBLFBVbBcBBQDBY4FB9BjDB0CLBJBBCBBJDDfDDBNNBHBLlCBJBBvBBBMaBpCHB0CMBqCGBL1CBJ3CBjBNBLFBKuBuBPJBeCBhBBBXPPBnCBIDDtBCBCDDKHBLFBHDDmBDDHGBLFBtBDBL1HBaGBSqBqBBBBe0CBCOBzBMB8clDBwDGGBJBlGryCBkDMB3iBJB88DEBoS41GB7Bl2BB6RGBgBLLBCByCLLBEBfBBHJBnCJBLIIWEBUvNB7BlGB8CEBaBBarBBsCDB6BGBS-BBGKBIIB3mHoBBhBgDB0D8vIBFIIDkJkJBNBCcBEBBCNBFHBtMjoCBsDEBOCBKGBLBBJ76DB+HCB1NFBYOBSOBvBBBYIB1D7BB3HJBoBBBjGUBnC5DBVLBVLB4CIBamEB2CoCoCDBBCBBDBBFNNCIIiCFFBJJIddFGGCCBI1K1KBlJlJB-V-VBNBGQQBuiBBgBFBH0GBISSBIIDGGBDB-BgBBCvDBuBCBPBBLDBD-JBgBQB7BEBCvOBrB1GBsBDBC-FBgBXXBGBD-GBIFFDQQmGBBRoBBtCDBLDBDwYBlCrCB+BhGBFccDCCBCCLFFCCCBEBCDBCECEDDCBBCICDCCBFFIKFCLLSEBEGGSzBBDtIBtBDBlDLBQBBQQQmBJBvF3BBeMBtBDBKGBDNBH5EB6eCBSCBOCB7GFBNDBCOBNDB5BHBLFBpBHBfBBNDBDNBKmBB5KHBPBBOCBMCB6BCCBCBRBBNDBLGB0EoDoDBjgBBh3pBfB-oEBBv0FBBypHOBvThtCB-QhvBBs6EEBrpIm8yVBCdBhD-DBxHvw-FB", false)),
      Vai: () => new UnicodeRangeTable(decodeRanges("gopBrJ", true)),
      Vithkuqi: () => new UnicodeRangeTable(decodeRanges("wrhCKCOCGCBCKCOCGCB", true)),
      Wancho: () => new UnicodeRangeTable(decodeRanges("g24D5BGA", true)),
      Warang_Citi: () => new UnicodeRangeTable(decodeRanges("glmCyCNA", true)),
      Yezidi: () => new UnicodeRangeTable(decodeRanges("g0jCpBCCDB", true)),
      Yi: () => new UnicodeRangeTable(decodeRanges("ggoBskBE2B", true)),
      Zanabazar_Square: () => new UnicodeRangeTable(decodeRanges("gwmCnC", true))
    });
    static FOLD_CATEGORIES = new LazyMap({
      L: () => new UnicodeRangeTable(decodeRanges("laA", true)),
      LC: () => new UnicodeRangeTable(decodeRanges("laA", true)),
      Ll: () => new UnicodeRangeTable(decodeRanges("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGC3HrBrBCEEJHHCCBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHxC9zC9zCBuBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB", false)),
      Lt: () => new UnicodeRangeTable(decodeRanges("kOCCBCCBCClBCCtsHHBJHBJHBMQQwBAB", false)),
      Lu: () => new UnicodeRangeTable(decodeRanges("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpL2B2Bs1CvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB", false)),
      M: () => new UnicodeRangeTable(decodeRanges("5cgBgBlgHAB", false)),
      Mn: () => new UnicodeRangeTable(decodeRanges("5cgBgBlgHAB", false)),
      Emoji: () => new UnicodeRangeTable(decodeRanges("8mJA", true)),
      Extended_Pictographic: () => new UnicodeRangeTable(decodeRanges("8mJA", true)),
      Lowercase: () => new UnicodeRangeTable(decodeRanges("hCZBmDWBCGBiBuBCEECDOCDuBCBECEBBCCCBCCBBBDDBCBBCCBEBBCBBCECBCCDCCBCCBBBCCCBEEIBBCBBCBBCOCDQCDBBCCCBBBC4BCIBBCBBDCCBCBCGCiJCCEJJHCCBBBCCCBCCBPBCIBkBJJCUCGDDCBBDyBBxBgBCK2BCBMCD+CCDlBBq6ClBBCGGzW1CB0kCHHBpBBDCBhK0ECKgDCKHBJFBLHBJHBJFBMGCJHBZHBJHBJHBJEBMEBMDBNEBMEBqJEEBHHuBPBUzZzZBYBx5BvBBxBCCBBBDGCBCBCDDJCBCgDCJCCFuqeuqeCqBCUaCoEMCE8BCLECBICFCCDCCEUCBDBCEBCOCBCBCCCBQCZs5Vs5VBYBmmBnBBpEjBB9EKBCOBCGBCBBr3ByBB+EVB75CfBhsVfBhCYBoyehBB", false)),
      Math: () => new UnicodeRangeTable(decodeRanges("ycGDCHHFMMDDDCHHFAB", false)),
      Uppercase: () => new UnicodeRangeTable(decodeRanges("hDZB7BqBqBBWBCHBCuBCEECDOCDsBCDECBBBDCCDEEGDDECBDDDCCCDFFDEECDDECCGBBCBBCBBCOCBSCDBBCEECkBCEQCJDDBCCFICBEBCBBCCCBEEBCCBCBCEBDCCBDDIDDCBBEFBGLLBnFnFsBCCEEEBBBvBDBCdBCBBECBCWCBDBCGD1BvBBCgBCK0BCDMCBgDCyBlBBq6CqBBDCB5XFBjkCIBCvHvHERRzD0ECGGGC8CCBHBJFBLHBJHBJFBMGCJHBJNBzBBBNSSBPPBEEpLiBiBBOBFsasaBYBn6BvBBCEEBGCHDDLiDCJCCFNNBkBBCGG0oesBCUaCoEMCE8BCLCCDICFFFCBBDSCMOCFCCDOCb9a9advCBi8UZBumBnBBpEjBB8EKBCOBCGBCBBk4ByBB+DVB75CfBhsVfB8BYBvyehBB", false))
    });
    static FOLD_SCRIPT = new LazyMap({
      Common: () => new UnicodeRangeTable(decodeRanges("8cgBgB", false)),
      Greek: () => new UnicodeRangeTable(decodeRanges("1FwUwU", false)),
      Inherited: () => new UnicodeRangeTable(decodeRanges("5cgBgBlgHAB", false))
    });
  };
  var Unicode = class Unicode2 {
    static MAX_RUNE = 1114111;
    static RUNE_ERROR = 65533;
    static isUnsearchable(r) {
      return r === Unicode2.RUNE_ERROR || r >= Unicode2.MIN_HIGH_SURROGATE && r <= Unicode2.MAX_LOW_SURROGATE;
    }
    static MAX_ASCII = 127;
    static MAX_LATIN1 = 255;
    static MAX_BMP = 65535;
    static MIN_FOLD = 65;
    static MAX_FOLD = 125251;
    static MIN_HIGH_SURROGATE = 55296;
    static MAX_HIGH_SURROGATE = 56319;
    static MIN_LOW_SURROGATE = 56320;
    static MAX_LOW_SURROGATE = 57343;
    static MIN_SUPPLEMENTARY_CODE_POINT = 65536;
    static is32(ranges, r) {
      let lo = 0;
      let hi = ranges.length;
      while (lo < hi) {
        const m = lo + Math.floor((hi - lo) / 2);
        const rlo = ranges.getLo(m);
        const rhi = ranges.getHi(m);
        if (rlo <= r && r <= rhi) {
          const stride = ranges.getStride(m);
          return (r - rlo) % stride === 0;
        }
        if (r < rlo) hi = m;
        else lo = m + 1;
      }
      return false;
    }
    static is(ranges, r) {
      if (r <= Unicode2.MAX_LATIN1) {
        for (let i = 0; i < ranges.length; i++) {
          if (r > ranges.getHi(i)) continue;
          const rlo = ranges.getLo(i);
          if (r < rlo) return false;
          const stride = ranges.getStride(i);
          return (r - rlo) % stride === 0;
        }
        return false;
      }
      return ranges.length > 0 && r >= ranges.getLo(0) && Unicode2.is32(ranges, r);
    }
    static isPrint(r) {
      if (r <= Unicode2.MAX_LATIN1) return r >= 32 && r < Unicode2.MAX_ASCII || r >= 161 && r !== 173;
      return Unicode2.is(UnicodeTables.Print, r);
    }
    static simpleFold(r) {
      if (UnicodeTables.CASE_ORBIT.has(r)) return UnicodeTables.CASE_ORBIT.get(r);
      if (r <= Unicode2.MAX_ASCII) {
        const l = Codepoint.toLowerCase(r);
        return l !== r ? l : Codepoint.toUpperCase(r);
      }
      return r;
    }
    static equalsIgnoreCase(r1, r2) {
      if (r1 === r2) return true;
      if (r1 < 0 || r2 < 0) return false;
      if (r1 <= Unicode2.MAX_ASCII && r2 <= Unicode2.MAX_ASCII) {
        if (65 <= r1 && r1 <= 90) r1 |= 32;
        if (65 <= r2 && r2 <= 90) r2 |= 32;
        return r1 === r2;
      }
      for (let r = Unicode2.simpleFold(r1); r !== r1; r = Unicode2.simpleFold(r)) if (r === r2) return true;
      return false;
    }
  };
  var FAST_PATH_TABLE_SIZE = 256;
  var WORD_RUNE_TABLE = new Uint8Array(FAST_PATH_TABLE_SIZE);
  for (let i = 0; i < FAST_PATH_TABLE_SIZE; i++) WORD_RUNE_TABLE[i] = 97 <= i && i <= 122 || 65 <= i && i <= 90 || 48 <= i && i <= 57 || i === 95 ? 1 : 0;
  var cachedNativeEncoder = null;
  var cachedNativeDecoder = null;
  var Utils = class Utils2 {
    static METACHARACTERS = "\\.+*?()|[]{}^$";
    static EMPTY_BEGIN_LINE = 1;
    static EMPTY_END_LINE = 2;
    static EMPTY_BEGIN_TEXT = 4;
    static EMPTY_END_TEXT = 8;
    static EMPTY_WORD_BOUNDARY = 16;
    static EMPTY_NO_WORD_BOUNDARY = 32;
    static EMPTY_ALL = -1;
    static emptyInts() {
      return [];
    }
    static isByteArray(input) {
      return Array.isArray(input) || Object.prototype.toString.call(input) === "[object Uint8Array]";
    }
    static isalnum(c) {
      return Codepoint.CODES["0"] <= c && c <= Codepoint.CODES["9"] || Codepoint.CODES["a"] <= c && c <= Codepoint.CODES["z"] || Codepoint.CODES["A"] <= c && c <= Codepoint.CODES["Z"];
    }
    static unhex(c) {
      if (Codepoint.CODES["0"] <= c && c <= Codepoint.CODES["9"]) return c - Codepoint.CODES["0"];
      if (Codepoint.CODES["a"] <= c && c <= Codepoint.CODES["f"]) return c - Codepoint.CODES["a"] + 10;
      if (Codepoint.CODES["A"] <= c && c <= Codepoint.CODES["F"]) return c - Codepoint.CODES["A"] + 10;
      return -1;
    }
    static escapeRune(rune) {
      let out = "";
      if (Unicode.isPrint(rune)) {
        if (Utils2.METACHARACTERS.indexOf(String.fromCodePoint(rune)) >= 0) out += "\\";
        out += String.fromCodePoint(rune);
      } else switch (rune) {
        case Codepoint.CODES['"']:
          out += '\\"';
          break;
        case Codepoint.CODES["\\"]:
          out += "\\\\";
          break;
        case Codepoint.CODES["	"]:
          out += "\\t";
          break;
        case Codepoint.CODES["\n"]:
          out += "\\n";
          break;
        case Codepoint.CODES["\r"]:
          out += "\\r";
          break;
        case Codepoint.CODES["\b"]:
          out += "\\b";
          break;
        case Codepoint.CODES["\f"]:
          out += "\\f";
          break;
        default: {
          let s = rune.toString(16);
          if (rune < 256) {
            out += "\\x";
            if (s.length === 1) out += "0";
            out += s;
          } else out += `\\x{${s}}`;
          break;
        }
      }
      return out;
    }
    static stringToRunes(str) {
      const string = String(str);
      const runes = [];
      let i = 0;
      while (i < string.length) {
        const cp = string.codePointAt(i);
        runes.push(cp);
        i += cp > Unicode.MAX_BMP ? 2 : 1;
      }
      return new Int32Array(runes);
    }
    static runeToString(r) {
      return String.fromCodePoint(r);
    }
    static isWordRune(r) {
      return r < FAST_PATH_TABLE_SIZE ? WORD_RUNE_TABLE[r] === 1 : false;
    }
    static emptyOpContext(r1, r2) {
      let op = 0;
      if (r1 < 0) op |= Utils2.EMPTY_BEGIN_TEXT | Utils2.EMPTY_BEGIN_LINE;
      if (r1 === 10) op |= Utils2.EMPTY_BEGIN_LINE;
      if (r2 < 0) op |= Utils2.EMPTY_END_TEXT | Utils2.EMPTY_END_LINE;
      if (r2 === 10) op |= Utils2.EMPTY_END_LINE;
      if (Utils2.isWordRune(r1) !== Utils2.isWordRune(r2)) op |= Utils2.EMPTY_WORD_BOUNDARY;
      else op |= Utils2.EMPTY_NO_WORD_BOUNDARY;
      return op;
    }
    /**
    * Returns a string that quotes all regular expression metacharacters inside the argument text;
    * the returned string is a regular expression matching the literal text. For example,
    * {@code quoteMeta("[foo]").equals("\\[foo\\]")}.
    * @param {string} str
    * @returns {string}
    */
    static quoteMeta(str) {
      return str.split("").map((s) => {
        if (Utils2.METACHARACTERS.indexOf(s) >= 0) return `\\${s}`;
        return s;
      }).join("");
    }
    static charCount(codePoint) {
      return codePoint > Unicode.MAX_BMP ? 2 : 1;
    }
    /**
    * High-speed conversion from TypedArrays to standard JS Arrays.
    * Bypasses the expensive Symbol.iterator overhead of Array.from()
    */
    static toArray(typedArray) {
      const len = typedArray.length;
      const res = new Array(len);
      for (let i = 0; i < len; i++) res[i] = typedArray[i];
      return res;
    }
    static stringToUtf8ByteArray(str) {
      if (globalThis.TextEncoder) {
        if (!cachedNativeEncoder) cachedNativeEncoder = new TextEncoder();
        return cachedNativeEncoder.encode(str);
      } else {
        let out = [], p = 0;
        for (let i = 0; i < str.length; i++) {
          let c = str.charCodeAt(i);
          if (c < 128) out[p++] = c;
          else if (c < 2048) {
            out[p++] = c >> 6 | 192;
            out[p++] = c & 63 | 128;
          } else if ((c & 64512) === Unicode.MIN_HIGH_SURROGATE && i + 1 < str.length && (str.charCodeAt(i + 1) & 64512) === Unicode.MIN_LOW_SURROGATE) {
            c = Unicode.MIN_SUPPLEMENTARY_CODE_POINT + ((c & 1023) << 10) + (str.charCodeAt(++i) & 1023);
            out[p++] = c >> 18 | 240;
            out[p++] = c >> 12 & 63 | 128;
            out[p++] = c >> 6 & 63 | 128;
            out[p++] = c & 63 | 128;
          } else {
            out[p++] = c >> 12 | 224;
            out[p++] = c >> 6 & 63 | 128;
            out[p++] = c & 63 | 128;
          }
        }
        return out;
      }
    }
    static utf8ByteArrayToString(bytes) {
      if (globalThis.TextDecoder) {
        if (!cachedNativeDecoder) cachedNativeDecoder = new TextDecoder("utf-8");
        const view2 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
        return cachedNativeDecoder.decode(view2);
      } else {
        let out = [], pos = 0, c = 0;
        while (pos < bytes.length) {
          let c1 = bytes[pos++];
          if (c1 < 128) out[c++] = String.fromCharCode(c1);
          else if (c1 > 191 && c1 < 224) {
            let c2 = bytes[pos++];
            out[c++] = String.fromCharCode((c1 & 31) << 6 | c2 & 63);
          } else if (c1 > 239 && c1 < 365) {
            let c2 = bytes[pos++];
            let c3 = bytes[pos++];
            let c4 = bytes[pos++];
            let u = ((c1 & 7) << 18 | (c2 & 63) << 12 | (c3 & 63) << 6 | c4 & 63) - Unicode.MIN_SUPPLEMENTARY_CODE_POINT;
            out[c++] = String.fromCharCode(Unicode.MIN_HIGH_SURROGATE + (u >> 10));
            out[c++] = String.fromCharCode(Unicode.MIN_LOW_SURROGATE + (u & 1023));
          } else {
            let c2 = bytes[pos++];
            let c3 = bytes[pos++];
            out[c++] = String.fromCharCode((c1 & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
          }
        }
        return out.join("");
      }
    }
  };
  var createEnum = (values = [], initNum = 0) => {
    const enumObject = /* @__PURE__ */ Object.create(null);
    for (let i = 0; i < values.length; i++) {
      const val = values[i];
      const keyVal = initNum + i;
      enumObject[val] = keyVal;
      enumObject[keyVal] = val;
    }
    return Object.freeze(enumObject);
  };
  var MatcherInputBase = class MatcherInputBase2 {
    static Encoding = createEnum(["UTF_16", "UTF_8"]);
    getEncoding() {
      throw Error("not implemented");
    }
    /** @returns {string} */
    asCharSequence() {
      throw Error("not implemented");
    }
    /** @returns {Uint8Array|number[]|null} */
    asBytes() {
      throw Error("not implemented");
    }
    /** @returns {number} */
    length() {
      throw Error("not implemented");
    }
    /**
    *
    * @returns {boolean}
    */
    isUTF8Encoding() {
      return this.getEncoding() === MatcherInputBase2.Encoding.UTF_8;
    }
    /**
    *
    * @returns {boolean}
    */
    isUTF16Encoding() {
      return this.getEncoding() === MatcherInputBase2.Encoding.UTF_16;
    }
  };
  var Utf8MatcherInput = class extends MatcherInputBase {
    /** @param {Uint8Array|number[]|null} bytes */
    constructor(bytes = null) {
      super();
      this.bytes = bytes;
    }
    getEncoding() {
      return MatcherInputBase.Encoding.UTF_8;
    }
    /**
    *
    * @returns {string}
    */
    asCharSequence() {
      return Utils.utf8ByteArrayToString(this.bytes);
    }
    /**
    *
    * @returns {Uint8Array|number[]|null}
    */
    asBytes() {
      return this.bytes;
    }
    /**
    *
    * @returns {number}
    */
    length() {
      return this.bytes.length;
    }
  };
  var Utf16MatcherInput = class extends MatcherInputBase {
    /** @param {string|null} charSequence */
    constructor(charSequence = null) {
      super();
      this.charSequence = charSequence;
    }
    getEncoding() {
      return MatcherInputBase.Encoding.UTF_16;
    }
    /**
    *
    * @returns {string}
    */
    asCharSequence() {
      return this.charSequence;
    }
    /**
    *
    * @returns {number[]}
    */
    asBytes() {
      return Utils.stringToUtf8ByteArray(this.charSequence.toString());
    }
    /**
    *
    * @returns {number}
    */
    length() {
      return this.charSequence.length;
    }
  };
  var MatcherInput = class {
    /**
    * Return the MatcherInput for UTF_16 encoding.
    * @returns {Utf16MatcherInput}
    */
    static utf16(charSequence) {
      return new Utf16MatcherInput(charSequence);
    }
    /**
    * Return the MatcherInput for UTF_8 encoding.
    * @returns {Utf8MatcherInput}
    */
    static utf8(input) {
      if (Utils.isByteArray(input)) return new Utf8MatcherInput(input);
      return new Utf8MatcherInput(Utils.stringToUtf8ByteArray(input));
    }
  };
  var MachineInputBase = class {
    static EOF() {
      return -8;
    }
    constructor() {
      this.start = 0;
      this.end = 0;
    }
    canCheckPrefix() {
      return true;
    }
    endPos() {
      return this.end - this.start;
    }
    hasString() {
      return false;
    }
    hasAnyString() {
      return false;
    }
    prefixLength() {
      return 0;
    }
  };
  var MachineUTF8Input = class MachineUTF8Input2 extends MachineInputBase {
    static RUNE_ERROR_STEP = Unicode.RUNE_ERROR << 3 | 1;
    constructor(bytes, start = 0, end = bytes.length) {
      super();
      this.bytes = bytes;
      this.start = start;
      this.end = end;
    }
    hasString(prefilter, pos) {
      const target2 = prefilter.bytes;
      if (target2.length === 0) return true;
      const idx = this.indexOf(this.bytes, target2, this.start + pos);
      return idx !== -1 && idx <= this.end - target2.length;
    }
    hasAnyString(prefilter, pos) {
      return prefilter.automaton8().searchUTF8(this.bytes, this.start + pos, this.end);
    }
    step(pos) {
      pos += this.start;
      if (pos >= this.end) return MachineInputBase.EOF();
      const c = this.bytes[pos] & 255;
      if (c < 128) return c << 3 | 1;
      let size;
      let rune;
      let lo = 128;
      let hi = 191;
      if (c >= 194 && c <= 223) {
        size = 2;
        rune = c & 31;
      } else if (c >= 224 && c <= 239) {
        size = 3;
        rune = c & 15;
        if (c === 224) lo = 160;
        else if (c === 237) hi = 159;
      } else if (c >= 240 && c <= 244) {
        size = 4;
        rune = c & 7;
        if (c === 240) lo = 144;
        else if (c === 244) hi = 143;
      } else return MachineUTF8Input2.RUNE_ERROR_STEP;
      if (pos + size > this.end) return MachineUTF8Input2.RUNE_ERROR_STEP;
      const c1 = this.bytes[pos + 1] & 255;
      if (c1 < lo || c1 > hi) return MachineUTF8Input2.RUNE_ERROR_STEP;
      rune = rune << 6 | c1 & 63;
      if (size > 2) {
        const c2 = this.bytes[pos + 2] & 255;
        if ((c2 & 192) !== 128) return MachineUTF8Input2.RUNE_ERROR_STEP;
        rune = rune << 6 | c2 & 63;
        if (size > 3) {
          const c3 = this.bytes[pos + 3] & 255;
          if ((c3 & 192) !== 128) return MachineUTF8Input2.RUNE_ERROR_STEP;
          rune = rune << 6 | c3 & 63;
        }
      }
      return rune << 3 | size;
    }
    index(re2, pos) {
      pos += this.start;
      const i = this.indexOf(this.bytes, re2.prefixUTF8, pos);
      return i < 0 ? i : i - pos;
    }
    context(pos) {
      pos += this.start;
      let r1 = -1;
      if (pos > this.start && pos <= this.end) {
        let start = pos - 1;
        r1 = this.bytes[start--];
        if (r1 >= 128) {
          let lim = pos - 4;
          if (lim < this.start) lim = this.start;
          while (start >= lim && (this.bytes[start] & 192) === 128) start--;
          if (start < this.start) start = this.start;
          const r = this.step(start - this.start);
          r1 = start + (r & 7) === pos ? r >> 3 : Unicode.RUNE_ERROR;
        }
      }
      const r2 = pos < this.end ? this.step(pos - this.start) >> 3 : -1;
      return Utils.emptyOpContext(r1, r2);
    }
    indexOf(source, target2, fromIndex = 0) {
      let targetLength = target2.length;
      if (targetLength === 0) return fromIndex <= this.end ? fromIndex : -1;
      const firstByte = target2[0];
      let limit = this.end - targetLength;
      const hasNativeIndexOf = typeof source.indexOf === "function";
      let i = fromIndex;
      while (i <= limit) {
        if (hasNativeIndexOf) {
          i = source.indexOf(firstByte, i);
          if (i === -1 || i > limit) return -1;
        } else {
          while (i <= limit && source[i] !== firstByte) i++;
          if (i > limit) return -1;
        }
        let match = true;
        for (let j = 1; j < targetLength; j++) if (source[i + j] !== target2[j]) {
          match = false;
          break;
        }
        if (match) return i;
        i++;
      }
      return -1;
    }
    prefixLength(re2) {
      return re2.prefixUTF8.length;
    }
  };
  var MachineUTF16Input = class extends MachineInputBase {
    constructor(charSequence, start = 0, end = charSequence.length) {
      super();
      this.charSequence = charSequence;
      this.start = start;
      this.end = end;
    }
    hasString(prefilter, pos) {
      const idx = this.charSequence.indexOf(prefilter.str, this.start + pos);
      return idx !== -1 && idx <= this.end - prefilter.str.length;
    }
    hasAnyString(prefilter, pos) {
      return prefilter.automaton16().searchUTF16(this.charSequence, this.start + pos, this.end);
    }
    step(pos) {
      pos += this.start;
      if (pos >= this.end) return MachineInputBase.EOF();
      const c1 = this.charSequence.charCodeAt(pos);
      if (c1 < Unicode.MIN_HIGH_SURROGATE || c1 > Unicode.MAX_HIGH_SURROGATE || pos + 1 >= this.end) return c1 << 3 | 1;
      const c2 = this.charSequence.charCodeAt(pos + 1);
      if (c2 >= Unicode.MIN_LOW_SURROGATE && c2 <= Unicode.MAX_LOW_SURROGATE) return (c1 - Unicode.MIN_HIGH_SURROGATE) * 1024 + (c2 - Unicode.MIN_LOW_SURROGATE) + Unicode.MIN_SUPPLEMENTARY_CODE_POINT << 3 | 2;
      return c1 << 3 | 1;
    }
    index(re2, pos) {
      pos += this.start;
      const i = this.charSequence.indexOf(re2.prefix, pos);
      if (i < 0 || i > this.end - re2.prefix.length) return -1;
      return i - pos;
    }
    context(pos) {
      pos += this.start;
      const r1 = pos > this.start && pos <= this.end ? this.charSequence.charCodeAt(pos - 1) : -1;
      const r2 = pos < this.end ? this.charSequence.charCodeAt(pos) : -1;
      return Utils.emptyOpContext(r1, r2);
    }
    prefixLength(re2) {
      return re2.prefix.length;
    }
  };
  var MachineInput = class {
    static fromUTF8(bytes, start = 0, end = bytes.length) {
      return new MachineUTF8Input(bytes, start, end);
    }
    static fromUTF16(charSequence, start = 0, end = charSequence.length) {
      return new MachineUTF16Input(charSequence, start, end);
    }
  };
  var RE2JSException = class extends Error {
    /** @param {string} message */
    constructor(message) {
      super(message);
      this.name = "RE2JSException";
    }
  };
  var RE2JSSyntaxException = class extends RE2JSException {
    /**
    * @param {string} error
    * @param {string|null} [input=null]
    */
    constructor(error, input = null) {
      let message = `error parsing regexp: ${error}`;
      if (input) message += `: \`${input}\``;
      super(message);
      this.name = "RE2JSSyntaxException";
      this.message = message;
      this.error = error;
      this.input = input;
    }
    /**
    * Retrieves the description of the error.
    * @returns {string}
    */
    getDescription() {
      return this.error;
    }
    /**
    * Retrieves the erroneous regular-expression pattern.
    * @returns {string|null}
    */
    getPattern() {
      return this.input;
    }
  };
  var RE2JSCompileException = class extends RE2JSException {
    /** @param {string} message */
    constructor(message) {
      super(message);
      this.name = "RE2JSCompileException";
    }
  };
  var RE2JSGroupException = class extends RE2JSException {
    /** @param {string} message */
    constructor(message) {
      super(message);
      this.name = "RE2JSGroupException";
    }
  };
  var RE2JSFlagsException = class extends RE2JSException {
    /** @param {string} message */
    constructor(message) {
      super(message);
      this.name = "RE2JSFlagsException";
    }
  };
  var RE2JSInternalException = class extends RE2JSException {
    /** @param {string} message */
    constructor(message) {
      super(message);
      this.name = "RE2JSInternalException";
    }
  };
  var Matcher = class Matcher2 {
    /**
    * V8 and WebKit have historical hard limits on the number of arguments
    * that can be passed to a function. We cap replacer arguments to prevent
    * Call Stack Overflow (DoS) vulnerabilities on massive ASTs.
    */
    static MAX_REPLACER_ARGS = 65535;
    /**
    * Quotes '\' and '$' in {@code s}, so that the returned string could be used in
    * {@link #appendReplacement} as a literal replacement of {@code s}.
    *
    * @param {string} str the string to be quoted
    * @param {boolean} [javaMode=false] whether the replacement will be used in javaMode
    * @returns {string} the quoted string
    */
    static quoteReplacement(str, javaMode = false) {
      if (javaMode) {
        if (str.indexOf("\\") < 0 && str.indexOf("$") < 0) return str;
        return str.split("").map((s) => {
          const c = s.codePointAt(0);
          if (c === Codepoint.CODES["\\"] || c === Codepoint.CODES["$"]) return `\\${s}`;
          return s;
        }).join("");
      }
      if (str.indexOf("$") < 0) return str;
      return str.split("").map((s) => {
        if (s.codePointAt(0) === Codepoint.CODES["$"]) return "$$";
        return s;
      }).join("");
    }
    /**
    *
    * @param {import('./index.js').RE2JS} pattern
    * @param {string|number[]|Uint8Array|MatcherInputBase} input
    */
    constructor(pattern, input) {
      if (pattern === null) throw new Error("pattern is null");
      this.patternInput = pattern;
      const re2 = this.patternInput.re2();
      this.patternGroupCount = re2.numberOfCapturingGroups();
      this.groups = [];
      this.namedGroups = re2.namedGroups;
      this.hasNamedGroups = Object.keys(this.namedGroups).length > 0;
      this.numberOfInstructions = re2.numberOfInstructions();
      this.lookbehindState = null;
      if (input instanceof MatcherInputBase) this.resetMatcherInput(input);
      else if (Utils.isByteArray(input)) this.resetMatcherInput(MatcherInput.utf8(input));
      else this.resetMatcherInput(MatcherInput.utf16(input));
    }
    /**
    * Returns the {@code RE2JS} associated with this {@code Matcher}.
    * @returns {import('./index.js').RE2JS}
    */
    pattern() {
      return this.patternInput;
    }
    /**
    * Resets the {@code Matcher}, rewinding input and discarding any match information.
    *
    * @returns {Matcher} the {@code Matcher} itself, for chained method calls
    */
    reset() {
      this.matcherInputLength = this.matcherInput.length();
      this.appendPos = 0;
      this.hasMatch = false;
      this.hasGroups = false;
      this.anchorFlag = 0;
      return this;
    }
    /**
    * Resets the {@code Matcher} and changes the input.
    * @param {string|number[]|Uint8Array|MatcherInputBase} input
    * @returns {Matcher} the {@code Matcher} itself, for chained method calls
    */
    resetMatcherInput(input) {
      if (input === null) throw new Error("input is null");
      if (!(input instanceof MatcherInputBase)) {
        if (Utils.isByteArray(input)) input = MatcherInput.utf8(input);
        else input = MatcherInput.utf16(input);
      }
      this.matcherInput = input;
      if (this.lookbehindState !== null) this.lookbehindState.reset();
      else this.lookbehindState = this.patternInput.re2().createLookbehindState();
      this.reset();
      return this;
    }
    /**
    * Returns the start of the named group of the most recent match, or -1 if the group was not
    * matched.
    * @param {string|number} [group=0]
    * @returns {number}
    */
    start(group = 0) {
      if (typeof group === "string") {
        const groupInt = this.namedGroups[group];
        if (!Number.isFinite(groupInt)) throw new RE2JSGroupException(`group '${group}' not found`);
        group = groupInt;
      }
      this.loadGroup(group);
      return this.groups[2 * group];
    }
    /**
    * Returns the end of the named group of the most recent match, or -1 if the group was not
    * matched.
    * @param {string|number} [group=0]
    * @returns {number}
    */
    end(group = 0) {
      if (typeof group === "string") {
        const groupInt = this.namedGroups[group];
        if (!Number.isFinite(groupInt)) throw new RE2JSGroupException(`group '${group}' not found`);
        group = groupInt;
      }
      this.loadGroup(group);
      return this.groups[2 * group + 1];
    }
    /**
    * Returns the program size of this pattern.
    *
    * <p>
    * Similar to the C++ implementation, the program size is a very approximate measure of a regexp's
    * "cost". Larger numbers are more expensive than smaller numbers.
    * </p>
    *
    * @returns {number} the program size of this pattern
    */
    programSize() {
      return this.numberOfInstructions;
    }
    /**
    * Returns the named group of the most recent match, or {@code null} if the group was not matched.
    * @param {string|number} [group=0]
    * @returns {string|null}
    */
    group(group = 0) {
      if (typeof group === "string") {
        const groupInt = this.namedGroups[group];
        if (!Number.isFinite(groupInt)) throw new RE2JSGroupException(`group '${group}' not found`);
        group = groupInt;
      }
      const start = this.start(group);
      const end = this.end(group);
      if (start < 0 && end < 0) return null;
      return this.substring(start, end);
    }
    /**
    * Returns a dictionary map of all named capturing groups and their matched values.
    * If a group was not matched, its value will be `null`.
    * @returns {Record<string, string|null>}
    */
    getNamedGroups() {
      if (!this.hasMatch) throw new RE2JSGroupException("perhaps no match attempted");
      const result = /* @__PURE__ */ Object.create(null);
      for (const name of Object.keys(this.namedGroups)) result[name] = this.group(name);
      return result;
    }
    /**
    * Returns the number of subgroups in this pattern.
    *
    * @returns {number} the number of subgroups; the overall match (group 0) does not count
    */
    groupCount() {
      return this.patternGroupCount;
    }
    /**
    * Helper: finds subgroup information if needed for group.
    * @param {number} group
    * @private
    */
    loadGroup(group) {
      if (!Number.isInteger(group) || group < 0 || group > this.patternGroupCount) throw new RE2JSGroupException(`Group index out of bounds: ${group}`);
      if (!this.hasMatch) throw new RE2JSGroupException("perhaps no match attempted");
      if (group === 0 || this.hasGroups) return;
      const end = this.matcherInputLength;
      const res = this.patternInput.re2().matchMachineInput(this.matcherInput, this.groups[0], end, this.anchorFlag, 1 + this.patternGroupCount, this.lookbehindState);
      if (!res[0]) throw new RE2JSGroupException("inconsistency in matching group data");
      this.groups = res[1];
      this.hasGroups = true;
    }
    /**
    * Matches the entire input against the pattern (anchored start and end). If there is a match,
    * {@code matches} sets the match state to describe it.
    *
    * @returns {boolean} true if the entire input matches the pattern
    */
    matches() {
      return this.genMatch(0, RE2Flags.ANCHOR_BOTH);
    }
    /**
    * Matches the beginning of input against the pattern (anchored start). If there is a match,
    * {@code lookingAt} sets the match state to describe it.
    *
    * @returns {boolean} true if the beginning of the input matches the pattern
    */
    lookingAt() {
      return this.genMatch(0, RE2Flags.ANCHOR_START);
    }
    /**
    * Matches the input against the pattern (unanchored), starting at a specified position. If there
    * is a match, {@code find} sets the match state to describe it.
    *
    * @param {number|null} [start=null] the input position where the search begins
    * @returns {boolean} if it finds a match
    * @throws IndexOutOfBoundsException if start is not a valid input position
    */
    find(start = null) {
      if (start !== null) {
        if (!Number.isInteger(start) || start < 0 || start > this.matcherInputLength) throw new RE2JSGroupException(`start index out of bounds: ${start}`);
        this.reset();
        return this.genMatch(start, 0);
      }
      start = 0;
      if (this.hasMatch) {
        start = this.groups[1];
        if (this.groups[0] === this.groups[1]) {
          const r = (this.matcherInput.isUTF16Encoding() ? MachineInput.fromUTF16(this.matcherInput.asCharSequence(), 0, this.matcherInputLength) : MachineInput.fromUTF8(this.matcherInput.asBytes(), 0, this.matcherInputLength)).step(start);
          if (r < 0) start++;
          else start += r & 7;
        }
      }
      return this.genMatch(start, RE2Flags.UNANCHORED);
    }
    /**
    * Helper: does match starting at start, with RE2 anchor flag.
    * @param {number} startByte
    * @param {number} anchor
    * @returns {boolean}
    * @private
    */
    genMatch(startByte, anchor) {
      const res = this.patternInput.re2().matchMachineInput(this.matcherInput, startByte, this.matcherInputLength, anchor, 1, this.lookbehindState);
      if (!res[0]) {
        this.hasMatch = false;
        return false;
      }
      this.groups = res[1];
      this.hasMatch = true;
      this.hasGroups = this.patternGroupCount === 0;
      this.anchorFlag = anchor;
      return true;
    }
    /**
    * Helper: return substring for [start, end).
    * @param {number} start
    * @param {number} end
    * @returns {string}
    */
    substring(start, end) {
      if (this.matcherInput.isUTF8Encoding()) return Utils.utf8ByteArrayToString(this.matcherInput.asBytes().slice(start, end));
      return this.matcherInput.asCharSequence().substring(start, end).toString();
    }
    /**
    * Helper for Pattern: return input length.
    * @returns {number}
    */
    inputLength() {
      return this.matcherInputLength;
    }
    /**
    * Appends to result two strings: the text from the append position up to the beginning of the
    * most recent match, and then the replacement with submatch groups substituted for references to
    * them. It advances the append position to where the most recent match ended.
    *
    * By default the replacement is expanded as by String.prototype.replace (see
    * appendReplacementInternalJs). In Java mode it follows re2j / java.util.regex: $n takes as
    * many digits as still form a valid group number, ${name} is a named group, and a backslash
    * escapes the next character (so "\\$" in a JS string literal inserts a literal $).
    *
    * @param {string} replacement the replacement string
    * @param {boolean} [javaMode=false] activate java mode (different behaviour for capture groups and special characters)
    * @returns {string}
    * @throws IllegalStateException if there was no most recent match
    * @throws IndexOutOfBoundsException in Java mode, if replacement refers to an invalid group
    * @private
    */
    appendReplacement(replacement, javaMode = false) {
      let res = "";
      const s = this.start();
      const e = this.end();
      if (this.appendPos < s) res += this.substring(this.appendPos, s);
      this.appendPos = e;
      res += javaMode ? this.appendReplacementInternalJava(replacement) : this.appendReplacementInternalJs(replacement);
      return res;
    }
    /**
    * @param {string} replacement - the replacement string
    * @returns {string}
    * @private
    */
    appendReplacementInternalJava(replacement) {
      let res = "";
      let last = 0;
      const m = replacement.length;
      let i = 0;
      while (i < m) {
        const cCode = replacement.codePointAt(i);
        if (cCode === Codepoint.CODES["\\"]) {
          if (last < i) res += replacement.substring(last, i);
          i++;
          if (i >= m) throw new RE2JSGroupException("character to be escaped is missing");
          last = i;
          i++;
          continue;
        }
        if (cCode === Codepoint.CODES["$"]) {
          if (last < i) res += replacement.substring(last, i);
          if (i + 1 >= m) throw new RE2JSGroupException("Illegal group reference: group index is missing");
          const nextCode = replacement.codePointAt(i + 1);
          if (Codepoint.CODES["0"] <= nextCode && nextCode <= Codepoint.CODES["9"]) {
            let n = nextCode - Codepoint.CODES["0"];
            let j = i + 2;
            for (; j < m; j++) {
              const digit = replacement.codePointAt(j);
              if (digit < Codepoint.CODES["0"] || digit > Codepoint.CODES["9"] || n * 10 + digit - Codepoint.CODES["0"] > this.patternGroupCount) break;
              n = n * 10 + digit - Codepoint.CODES["0"];
            }
            if (n > this.patternGroupCount) throw new RE2JSGroupException(`n > number of groups: ${n}`);
            const group = this.group(n);
            if (group !== null) res += group;
            i = j;
            last = i;
          } else if (nextCode === Codepoint.CODES["{"]) {
            let j = i + 2;
            while (j < m && replacement.codePointAt(j) !== Codepoint.CODES["}"]) j++;
            if (j >= m) throw new RE2JSGroupException("named capture group is missing trailing '}'");
            const groupName = replacement.substring(i + 2, j);
            const groupVal = this.group(groupName);
            if (groupVal !== null) res += groupVal;
            i = j + 1;
            last = i;
          } else throw new RE2JSGroupException("Illegal group reference");
          continue;
        }
        i++;
      }
      if (last < m) res += replacement.substring(last, m);
      return res;
    }
    /**
    * Expands |replacement| for the current match by the rules of String.prototype.replace
    * (ECMAScript GetSubstitution): $$ is "$", $& the match, $` the text before it, $' the text
    * after it, $n and $nn a group (two digits only when they form a valid group number, so with
    * one group "$10" is group 1 then "0"; an unmatched group is empty), and $<name> a named group
    * (empty when no such group), only when the pattern has named groups. Anything else, such as
    * "$0" or "$<" without a closing ">", is kept as is.
    * @param {string} replacement - the replacement string
    * @returns {string}
    * @private
    */
    appendReplacementInternalJs(replacement) {
      const isDigit = (c) => c >= 48 && c <= 57;
      const groupCount = this.patternGroupCount;
      let res = "";
      let i = 0;
      while (i < replacement.length) {
        const dollar = replacement.indexOf("$", i);
        if (dollar < 0) break;
        res += replacement.substring(i, dollar);
        i = dollar;
        const c = replacement.charCodeAt(i + 1);
        if (c === Codepoint.CODES["$"]) {
          res += "$";
          i += 2;
        } else if (c === Codepoint.CODES["&"]) {
          res += this.group(0);
          i += 2;
        } else if (c === Codepoint.CODES["`"]) {
          res += this.substring(0, this.start(0));
          i += 2;
        } else if (c === Codepoint.CODES["'"]) {
          res += this.substring(this.end(0), this.matcherInputLength);
          i += 2;
        } else if (isDigit(c)) {
          let digits = 1;
          let index = c - 48;
          const c2 = replacement.charCodeAt(i + 2);
          if (isDigit(c2) && index * 10 + c2 - 48 <= groupCount) {
            digits = 2;
            index = index * 10 + c2 - 48;
          }
          if (index >= 1 && index <= groupCount) {
            const group = this.group(index);
            if (group !== null) res += group;
          } else res += replacement.substring(i, i + 1 + digits);
          i += 1 + digits;
        } else if (c === Codepoint.CODES["<"] && this.hasNamedGroups) {
          const gt = replacement.indexOf(">", i + 2);
          if (gt < 0) {
            res += "$<";
            i += 2;
          } else {
            const name = replacement.substring(i + 2, gt);
            if (Object.prototype.hasOwnProperty.call(this.namedGroups, name)) {
              const group = this.group(name);
              if (group !== null) res += group;
            }
            i = gt + 1;
          }
        } else {
          res += "$";
          i += 1;
        }
      }
      return res + replacement.substring(i);
    }
    /**
    * Return the substring of the input from the append position to the end of the
    * input.
    * @returns {string}
    */
    appendTail() {
      return this.substring(this.appendPos, this.matcherInputLength);
    }
    /**
    * Returns the input with all matches replaced by {@code replacement}, interpreted as for
    * {@code appendReplacement}.
    *
    * @param {string|((...args: any[]) => string)} replacement - the replacement string or a replacer function
    * @param {boolean} [javaMode=false] - activate java mode (different behaviour for capture groups and special characters)
    * @returns {string} the input string with the matches replaced
    * @throws IndexOutOfBoundsException if replacement refers to an invalid group and javaMode is true
    */
    replaceAll(replacement, javaMode = false) {
      return this.replace(replacement, true, javaMode);
    }
    /**
    * Returns the input with the first match replaced by {@code replacement}, interpreted as for
    * {@code appendReplacement}.
    *
    * @param {string|((...args: any[]) => string)} replacement - the replacement string or a replacer function
    * @param {boolean} [javaMode=false] - activate java mode (different behaviour for capture groups and special characters)
    * @returns {string} the input string with the first match replaced
    * @throws IndexOutOfBoundsException if replacement refers to an invalid group and javaMode is true
    */
    replaceFirst(replacement, javaMode = false) {
      return this.replace(replacement, false, javaMode);
    }
    /**
    * Helper: replaceAll/replaceFirst hybrid.
    * @param {string|((...args: any[]) => string)} replacement - the replacement string or a replacer function
    * @param {boolean} [all=true] - replace all matches
    * @param {boolean} [javaMode=false] - activate java mode (different behaviour for capture groups and special characters)
    * @returns {string}
    * @private
    */
    replace(replacement, all = true, javaMode = false) {
      let res = "";
      this.reset();
      const isFunc = typeof replacement === "function";
      let originalInput = null;
      if (isFunc) {
        if (this.groupCount() >= Matcher2.MAX_REPLACER_ARGS) throw new RE2JSGroupException("Too many capture groups to safely invoke replacer function");
        originalInput = this.matcherInput.isUTF8Encoding() ? this.matcherInput.asBytes() : this.matcherInput.asCharSequence();
      }
      while (this.find()) {
        res += isFunc ? this.appendReplacementFunc(replacement, originalInput) : this.appendReplacement(replacement, javaMode);
        if (!all) break;
      }
      res += this.appendTail();
      return res;
    }
    /**
    * Evaluates a replacer function for the current match and appends the result,
    * along with any un-matched preceding text, advancing the append position.
    * @param {Function} replacer - the replacer function
    * @param {string|Uint8Array|number[]} originalInput - the cached original input reference
    * @returns {string} the evaluated string to append
    * @private
    */
    appendReplacementFunc(replacer, originalInput) {
      let res = "";
      const s = this.start();
      const e = this.end();
      if (this.appendPos < s) res += this.substring(this.appendPos, s);
      this.appendPos = e;
      const args = this.matchArray();
      args.push(s, originalInput);
      if (this.hasNamedGroups) args.push(this.namedGroupsObject());
      res += String(replacer(...args));
      return res;
    }
    /**
    * The match and its groups, as the elements of a JS RegExpExecArray: undefined for a group that
    * did not take part in the match. Used by exec(), matchAll() and replacer functions.
    * @returns {Array<string|undefined>}
    * @private
    */
    matchArray() {
      const result = [this.group(0)];
      for (let i = 1; i <= this.patternGroupCount; i++) {
        const group = this.group(i);
        result.push(group === null ? void 0 : group);
      }
      return result;
    }
    /**
    * The named groups, as the groups property of a JS RegExpExecArray: an object without a
    * prototype mapping each name to its group (undefined when it did not take part in the match),
    * or undefined when the pattern has no named groups.
    * @returns {Record<string, string|undefined>|undefined}
    * @private
    */
    namedGroupsObject() {
      if (!this.hasNamedGroups) return;
      const result = this.getNamedGroups();
      for (const name in result) if (result[name] === null) result[name] = void 0;
      return result;
    }
  };
  var Inst = class Inst2 {
    static ALT = 1;
    static ALT_MATCH = 2;
    static CAPTURE = 3;
    static EMPTY_WIDTH = 4;
    static FAIL = 5;
    static MATCH = 6;
    static NOP = 7;
    static RUNE = 8;
    static RUNE1 = 9;
    static RUNE_ANY = 10;
    static RUNE_ANY_NOT_NL = 11;
    static LB_WRITE = 12;
    static LB_CHECK = 13;
    static isRuneOp(op) {
      return Inst2.RUNE <= op && op <= Inst2.RUNE_ANY_NOT_NL;
    }
    static escapeRunes(runes) {
      let out = '"';
      for (let rune of runes) out += Utils.escapeRune(rune);
      out += '"';
      return out;
    }
    constructor(op) {
      this.op = op;
      this.out = 0;
      this.arg = 0;
      this.runes = /* @__PURE__ */ new Int32Array(0);
      this.next = null;
    }
    matchRune(r) {
      if (this.runes.length === 1) {
        const r0 = this.runes[0];
        if ((this.arg & RE2Flags.FOLD_CASE) !== 0) return Unicode.equalsIgnoreCase(r0, r);
        return r === r0;
      }
      const len = this.runes.length;
      if (len === 0) return false;
      if (len === 2 || len === 4 || len === 6 || len === 8) {
        for (let j = 0; j < len; j += 2) {
          if (r < this.runes[j]) return false;
          if (r <= this.runes[j + 1]) return true;
        }
        return false;
      }
      let base = 0;
      let n = len >> 1;
      while (n > 1) {
        const half = n >> 1;
        base += this.runes[base + half << 1] <= r ? half : 0;
        n -= half;
      }
      base += this.runes[base << 1] <= r ? 1 : 0;
      const m = base - 1;
      return m >= 0 && r <= this.runes[m << 1 | 1];
    }
    matchRunePos(r) {
      if (this.runes.length === 1) {
        const r0 = this.runes[0];
        if ((this.arg & RE2Flags.FOLD_CASE) !== 0) return Unicode.equalsIgnoreCase(r0, r) ? 0 : -1;
        return r === r0 ? 0 : -1;
      }
      const len = this.runes.length;
      if (len === 0) return -1;
      if (len === 2 || len === 4 || len === 6 || len === 8) {
        for (let j = 0; j < len; j += 2) {
          if (r < this.runes[j]) return -1;
          if (r <= this.runes[j + 1]) return Math.floor(j / 2);
        }
        return -1;
      }
      let base = 0;
      let n = len >> 1;
      while (n > 1) {
        const half = n >> 1;
        base += this.runes[base + half << 1] <= r ? half : 0;
        n -= half;
      }
      base += this.runes[base << 1] <= r ? 1 : 0;
      const m = base - 1;
      return m >= 0 && r <= this.runes[m << 1 | 1] ? m : -1;
    }
    /**
    *
    * @returns {string}
    */
    toString() {
      switch (this.op) {
        case Inst2.ALT:
          return `alt -> ${this.out}, ${this.arg}`;
        case Inst2.ALT_MATCH:
          return `altmatch -> ${this.out}, ${this.arg}`;
        case Inst2.CAPTURE:
          return `cap ${this.arg} -> ${this.out}`;
        case Inst2.EMPTY_WIDTH:
          return `empty ${this.arg} -> ${this.out}`;
        case Inst2.MATCH:
          return `match${this.arg !== 0 ? ` ${this.arg}` : ""}`;
        case Inst2.FAIL:
          return "fail";
        case Inst2.NOP:
          return `nop -> ${this.out}`;
        case Inst2.LB_WRITE:
          return `lbwrite ${this.arg} -> ${this.out}`;
        case Inst2.LB_CHECK:
          return `lbcheck ${this.arg} -> ${this.out}`;
        case Inst2.RUNE:
          if (this.runes === null) return "rune <null>";
          return [
            "rune ",
            Inst2.escapeRunes(this.runes),
            (this.arg & RE2Flags.FOLD_CASE) !== 0 ? "/i" : "",
            " -> ",
            this.out
          ].join("");
        case Inst2.RUNE1:
          return `rune1 ${Inst2.escapeRunes(this.runes)} -> ${this.out}`;
        case Inst2.RUNE_ANY:
          return `any -> ${this.out}`;
        case Inst2.RUNE_ANY_NOT_NL:
          return `anynotnl -> ${this.out}`;
        default:
          throw new Error("unhandled case in Inst.toString");
      }
    }
  };
  var Queue = class Queue2 {
    constructor(numInst) {
      this.sparse = new Int32Array(numInst);
      this.densePcs = new Int32Array(numInst);
      this.denseCaps = null;
      this.size = 0;
      this.ncap = 0;
      this.mainThreads = 0;
    }
    static INITIAL_THREADS = 32;
    init(ncap) {
      this.ncap = ncap;
      const needed = Math.min(this.densePcs.length, Queue2.INITIAL_THREADS) * ncap;
      if (!this.denseCaps || this.denseCaps.length < needed) this.denseCaps = new Int32Array(needed);
    }
    growCaps(needed) {
      const limit = this.densePcs.length * this.ncap;
      const grown = new Int32Array(Math.min(limit, Math.max(needed, 2 * this.denseCaps.length)));
      grown.set(this.denseCaps);
      this.denseCaps = grown;
    }
    contains(pc) {
      const j = this.sparse[pc];
      return j < this.size && this.densePcs[j] === pc;
    }
    isEmpty() {
      return this.size === 0;
    }
    add(pc) {
      const j = this.size++;
      this.sparse[pc] = j;
      this.densePcs[j] = pc;
      return j;
    }
    clear() {
      this.size = 0;
      this.mainThreads = 0;
    }
    toString() {
      let out = "{";
      for (let i = 0; i < this.size; i++) {
        if (i !== 0) out += ", ";
        out += this.densePcs[i];
      }
      out += "}";
      return out;
    }
  };
  var LookbehindState = class {
    constructor(prog) {
      this.pos = -1;
      this.pcs = new Int32Array(prog.numInst());
      this.size = 0;
      this.lbTable = new Int32Array(prog.numLb + 1);
    }
    reset() {
      this.pos = -1;
      this.size = 0;
    }
  };
  var Machine = class Machine2 {
    static fromRE2(re2) {
      const m = new Machine2();
      m.prog = re2.prog;
      m.re2 = re2;
      m.q0 = new Queue(m.prog.numInst());
      m.q1 = new Queue(m.prog.numInst());
      m.addStack = new Int32Array(2 * (m.prog.numInst() + 1));
      m.matched = false;
      m.matchcap = new Int32Array(m.prog.numCap < 2 ? 2 : m.prog.numCap);
      m.ncap = 0;
      return m;
    }
    constructor() {
      this.prog = null;
      this.re2 = null;
      this.q0 = null;
      this.q1 = null;
      this.addStack = null;
      this.matched = false;
      this.matchcap = null;
      this.ncap = 0;
      this.lbTable = null;
    }
    init(ncap) {
      this.ncap = ncap;
      if (ncap > this.matchcap.length) this.matchcap = new Int32Array(ncap).fill(-1);
      else this.matchcap.fill(-1);
      this.q0.init(ncap);
      this.q1.init(ncap);
      if (this.prog.numLb > 0) {
        if (!this.lbTable || this.lbTable.length < this.prog.numLb + 1) this.lbTable = new Int32Array(this.prog.numLb + 1);
        this.lbTable.fill(-1);
      }
    }
    submatches() {
      if (this.ncap === 0) return Utils.emptyInts();
      return Utils.toArray(this.matchcap.subarray(0, this.ncap));
    }
    match(input, pos, anchor, lbState = null) {
      const startCond = this.re2.cond;
      if (startCond === Utils.EMPTY_ALL) return false;
      if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return false;
      this.matched = false;
      this.matchcap.fill(-1);
      const hasLookbehinds = this.prog.numLb > 0;
      const matchStartPos = pos;
      let currentPos = pos;
      let resumeLookbehinds = false;
      if (hasLookbehinds) {
        if (lbState !== null && lbState.pos >= 0 && lbState.pos <= pos) {
          currentPos = lbState.pos;
          resumeLookbehinds = true;
        } else currentPos = 0;
      }
      let saveLookbehinds = hasLookbehinds && lbState !== null;
      let runq = this.q0;
      let nextq = this.q1;
      let r = input.step(currentPos);
      let rune = r >> 3;
      let width = r & 7;
      let rune1 = -1;
      let width1 = 0;
      if (r !== MachineInputBase.EOF()) {
        r = input.step(currentPos + width);
        rune1 = r >> 3;
        width1 = r & 7;
      }
      let flag;
      if (currentPos === 0) flag = Utils.emptyOpContext(-1, rune);
      else flag = input.context(currentPos);
      if (hasLookbehinds) {
        if (resumeLookbehinds) this.restoreLookbehinds(lbState, runq, flag);
        else this.spawnLookbehinds(runq, currentPos, flag);
      }
      while (true) {
        if (runq.mainThreads === 0) {
          if ((startCond & Utils.EMPTY_BEGIN_TEXT) !== 0 && currentPos !== 0) break;
          if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && currentPos !== 0) break;
          if (this.matched) break;
          if (this.prog.numLb === 0 && runq.isEmpty() && !(this.re2.prefix.length === 0) && rune1 !== this.re2.prefixRune && input.canCheckPrefix()) {
            const advance = input.index(this.re2, currentPos);
            if (advance < 0) break;
            currentPos += advance;
            r = input.step(currentPos);
            rune = r >> 3;
            width = r & 7;
            r = input.step(currentPos + width);
            rune1 = r >> 3;
            width1 = r & 7;
            flag = input.context(currentPos);
          }
        }
        if (currentPos >= matchStartPos) {
          if (saveLookbehinds) {
            this.saveLookbehinds(lbState, runq, currentPos);
            saveLookbehinds = false;
          }
          if (!this.matched && (currentPos === 0 || anchor === RE2Flags.UNANCHORED)) {
            if (this.ncap > 0) this.matchcap[0] = currentPos;
            this.add(runq, this.prog.start, currentPos, this.matchcap, 0, flag);
          }
        }
        const nextPos = currentPos + width;
        flag = input.context(nextPos);
        this.step(runq, nextq, currentPos, nextPos, rune, flag, anchor, currentPos === input.endPos());
        if (width === 0) break;
        if (this.ncap === 0 && this.matched) break;
        currentPos += width;
        rune = rune1;
        width = width1;
        if (rune !== -1) {
          r = input.step(currentPos + width);
          rune1 = r >> 3;
          width1 = r & 7;
        }
        const tmpq = runq;
        runq = nextq;
        nextq = tmpq;
      }
      runq.clear();
      nextq.clear();
      return this.matched;
    }
    matchSet(input, pos, anchor) {
      const startCond = this.re2.cond;
      if (startCond === Utils.EMPTY_ALL) return [];
      if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return [];
      let currentPos = this.prog.numLb > 0 ? 0 : pos;
      let matchStartPos = pos;
      let runq = this.q0;
      let nextq = this.q1;
      let r = input.step(currentPos);
      let rune = r >> 3;
      let width = r & 7;
      let rune1 = -1;
      let width1 = 0;
      if (r !== MachineInputBase.EOF()) {
        r = input.step(currentPos + width);
        rune1 = r >> 3;
        width1 = r & 7;
      }
      let flag = currentPos === 0 ? Utils.emptyOpContext(-1, rune) : input.context(currentPos);
      const matches = /* @__PURE__ */ new Set();
      if (this.prog.numLb > 0) this.spawnLookbehinds(runq, currentPos, flag);
      while (true) {
        if (runq.mainThreads === 0) {
          if ((startCond & Utils.EMPTY_BEGIN_TEXT) !== 0 && currentPos !== 0) break;
          if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && currentPos !== 0) break;
        }
        if (currentPos === 0 || anchor === RE2Flags.UNANCHORED) {
          if (currentPos >= matchStartPos) this.add(runq, this.prog.start, currentPos, this.matchcap, 0, flag);
        }
        const nextPos = currentPos + width;
        flag = input.context(nextPos);
        for (let j = 0; j < runq.size; j++) {
          const pc = runq.densePcs[j];
          const i = this.prog.inst[pc];
          const capOffset = j * this.ncap;
          let add = false;
          switch (i.op) {
            case Inst.MATCH:
              if (anchor === RE2Flags.ANCHOR_BOTH && currentPos !== input.endPos()) break;
              matches.add(i.arg);
              break;
            case Inst.RUNE:
              add = i.matchRune(rune);
              break;
            case Inst.RUNE1:
              add = rune === i.runes[0];
              break;
            case Inst.RUNE_ANY:
              add = true;
              break;
            case Inst.RUNE_ANY_NOT_NL:
              add = rune !== 10;
              break;
            default:
              continue;
          }
          if (add) this.add(nextq, i.out, nextPos, runq.denseCaps, capOffset, flag);
        }
        runq.clear();
        if (width === 0) break;
        currentPos += width;
        rune = rune1;
        width = width1;
        if (rune !== -1) {
          r = input.step(currentPos + width);
          rune1 = r >> 3;
          width1 = r & 7;
        }
        const tmpq = runq;
        runq = nextq;
        nextq = tmpq;
      }
      nextq.clear();
      return Array.from(matches).sort((a, b) => a - b);
    }
    step(runq, nextq, pos, nextPos, c, nextCond, anchor, atEnd) {
      const longest = this.re2.longest;
      for (let j = 0; j < runq.size; j++) {
        const pc = runq.densePcs[j];
        const capOffset = j * this.ncap;
        if (longest && this.matched && this.ncap > 0 && this.matchcap[0] < runq.denseCaps[capOffset]) continue;
        const i = this.prog.inst[pc];
        let add = false;
        switch (i.op) {
          case Inst.MATCH:
            if (anchor === RE2Flags.ANCHOR_BOTH && !atEnd) break;
            if (this.ncap > 0 && (!longest || !this.matched || this.matchcap[1] < pos)) {
              runq.denseCaps[capOffset + 1] = pos;
              for (let k = 0; k < this.ncap; k++) this.matchcap[k] = runq.denseCaps[capOffset + k];
            }
            if (!longest) runq.size = 0;
            this.matched = true;
            break;
          case Inst.RUNE:
            add = i.matchRune(c);
            break;
          case Inst.RUNE1:
            add = c === i.runes[0];
            break;
          case Inst.RUNE_ANY:
            add = true;
            break;
          case Inst.RUNE_ANY_NOT_NL:
            add = c !== 10;
            break;
          default:
            continue;
        }
        if (add) this.add(nextq, i.out, nextPos, runq.denseCaps, capOffset, nextCond);
      }
      runq.clear();
    }
    spawnLookbehinds(q, pos, flag) {
      for (let i = 0; i < this.prog.lbStarts.length; i++) this.add(q, this.prog.lbStarts[i], pos, this.matchcap, 0, flag);
    }
    restoreLookbehinds(lbState, q, flag) {
      this.lbTable.set(lbState.lbTable);
      for (let j = 0; j < lbState.size; j++) this.add(q, lbState.pcs[j], lbState.pos, this.matchcap, 0, flag);
    }
    saveLookbehinds(lbState, q, pos) {
      let size = 0;
      for (let j = 0; j < q.size; j++) {
        const pc = q.densePcs[j];
        if (this.prog.lbInst[pc] === 1 && Inst.isRuneOp(this.prog.inst[pc].op)) lbState.pcs[size++] = pc;
      }
      lbState.size = size;
      lbState.pos = pos;
      lbState.lbTable.set(this.lbTable);
    }
    add(q, pc, pos, capArray, capOffset, cond) {
      const stk = this.addStack;
      let nstk = 0;
      for (; ; ) {
        while (pc !== 0 && !q.contains(pc)) {
          const d = q.add(pc);
          const inst = this.prog.inst[pc];
          switch (inst.op) {
            case Inst.FAIL:
              pc = 0;
              break;
            case Inst.ALT:
            case Inst.ALT_MATCH:
              stk[nstk++] = inst.arg;
              stk[nstk++] = 0;
              pc = inst.out;
              break;
            case Inst.EMPTY_WIDTH:
              pc = (inst.arg & ~cond) === 0 ? inst.out : 0;
              break;
            case Inst.NOP:
              pc = inst.out;
              break;
            case Inst.CAPTURE:
              if (inst.arg < this.ncap) {
                stk[nstk++] = -inst.arg - 1;
                stk[nstk++] = capArray[capOffset + inst.arg];
                capArray[capOffset + inst.arg] = pos;
              }
              pc = inst.out;
              break;
            case Inst.LB_WRITE:
              this.lbTable[Math.abs(inst.arg)] = pos;
              pc = inst.out;
              break;
            case Inst.LB_CHECK:
              if (inst.arg > 0) pc = this.lbTable[inst.arg] === pos ? inst.out : 0;
              else pc = this.lbTable[-inst.arg] !== pos ? inst.out : 0;
              break;
            case Inst.MATCH:
            case Inst.RUNE:
            case Inst.RUNE1:
            case Inst.RUNE_ANY:
            case Inst.RUNE_ANY_NOT_NL:
              if (this.prog.lbInst[pc] === 0) q.mainThreads++;
              if (this.ncap > 0) {
                const destOffset = d * this.ncap;
                if (destOffset + this.ncap > q.denseCaps.length) q.growCaps(destOffset + this.ncap);
                for (let c = 0; c < this.ncap; c++) q.denseCaps[destOffset + c] = capArray[capOffset + c];
              }
              pc = 0;
              break;
            default:
              throw new RE2JSInternalException("unhandled");
          }
        }
        if (nstk === 0) return;
        nstk -= 2;
        const entry = stk[nstk];
        if (entry < 0) {
          capArray[capOffset - entry - 1] = stk[nstk + 1];
          pc = 0;
        } else pc = entry;
      }
    }
  };
  var hashState = (pcs, flag, ids) => {
    let h2 = -2128831035;
    for (let i = 0; i < pcs.length; i++) {
      h2 ^= pcs[i];
      h2 = Math.imul(h2, 16777619);
    }
    h2 ^= flag;
    h2 = Math.imul(h2, 16777619);
    for (let i = 0; i < ids.length; i++) {
      h2 ^= ids[i];
      h2 = Math.imul(h2, 16777619);
    }
    return h2;
  };
  var arraysEqual = (a, b) => {
    if (a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  };
  var isState = (state, pcs, flag, ids) => state.flag === flag && arraysEqual(state.nfaStates, pcs) && arraysEqual(state.matchIDs, ids);
  var NO_IDS = [];
  var END_TEXT = -1;
  var DFAState = class {
    constructor(nfaStates, flag, matchIDs) {
      this.nfaStates = nfaStates;
      this.flag = flag;
      this.isMatch = (flag & DFA.FLAG_MATCH) !== 0;
      this.matchIDs = matchIDs;
      this.next = null;
      this.nextAnchored = null;
    }
  };
  var DFA = class DFA2 {
    static FLAG_EMPTY_MASK = 255;
    static FLAG_MATCH = 256;
    static FLAG_LAST_WORD = 512;
    static FLAG_NEED_SHIFT = 16;
    static STATE_OVERHEAD = 150;
    static ARRAY_OVERHEAD = 40;
    static ELEMENT_SIZE = 8;
    static TABLE_OVERHEAD = 48;
    static PROGRESS_PER_STATE = 10;
    constructor(prog, maxMem = 8388608) {
      this.prog = prog;
      this.maxMem = maxMem;
      this.stateCache = /* @__PURE__ */ new Map();
      this.stateCount = 0;
      this.startStates = /* @__PURE__ */ new Map();
      this.failed = false;
      for (let pc = 0; pc < prog.numInst(); pc++) {
        const op = prog.getInst(pc).op;
        if (op === Inst.LB_WRITE || op === Inst.LB_CHECK) {
          this.failed = true;
          break;
        }
      }
      this.computeRuneClasses();
      this.stateBudget = maxMem;
      this.memBudget = maxMem;
    }
    computeRuneClasses() {
      const bounds = /* @__PURE__ */ new Set();
      const addRange = (lo, hi) => {
        bounds.add(lo);
        bounds.add(hi + 1);
      };
      for (let pc = 0; pc < this.prog.numInst(); pc++) {
        const inst = this.prog.getInst(pc);
        switch (inst.op) {
          case Inst.RUNE:
          case Inst.RUNE1:
            if (inst.runes.length === 1) {
              addRange(inst.runes[0], inst.runes[0]);
              if ((inst.arg & RE2Flags.FOLD_CASE) !== 0) for (let f = Unicode.simpleFold(inst.runes[0]); f !== inst.runes[0]; f = Unicode.simpleFold(f)) addRange(f, f);
            } else for (let j = 0; j < inst.runes.length; j += 2) addRange(inst.runes[j], inst.runes[j + 1]);
            break;
          case Inst.RUNE_ANY_NOT_NL:
            addRange(10, 10);
            break;
          case Inst.EMPTY_WIDTH:
            if ((inst.arg & (Utils.EMPTY_BEGIN_LINE | Utils.EMPTY_END_LINE)) !== 0) addRange(10, 10);
            if ((inst.arg & (Utils.EMPTY_WORD_BOUNDARY | Utils.EMPTY_NO_WORD_BOUNDARY)) !== 0) {
              addRange(48, 57);
              addRange(65, 90);
              addRange(95, 95);
              addRange(97, 122);
            }
        }
      }
      bounds.delete(0);
      this.classBounds = Int32Array.from(bounds).sort();
      this.numClasses = this.classBounds.length + 1;
      const latin1Class = new Int32Array(Unicode.MAX_LATIN1 + 1);
      for (let r = 0; r <= Unicode.MAX_LATIN1; r++) latin1Class[r] = this.searchClass(r);
      this.latin1Class = latin1Class;
    }
    runeClass(r) {
      if (r <= Unicode.MAX_LATIN1) return this.latin1Class[r];
      return this.searchClass(r);
    }
    searchClass(r) {
      const bounds = this.classBounds;
      let lo = 0;
      let hi = bounds.length;
      while (lo < hi) {
        const mid = lo + hi >> 1;
        if (bounds[mid] <= r) lo = mid + 1;
        else hi = mid;
      }
      return lo;
    }
    closure(pcs, flag) {
      const closure = /* @__PURE__ */ new Set();
      const stack = Array.from(pcs);
      let needflags = 0;
      while (stack.length > 0) {
        const pc = stack.pop();
        if (pc === 0 || closure.has(pc)) continue;
        closure.add(pc);
        const inst = this.prog.getInst(pc);
        switch (inst.op) {
          case Inst.ALT:
          case Inst.ALT_MATCH:
            stack.push(inst.out);
            stack.push(inst.arg);
            break;
          case Inst.NOP:
          case Inst.CAPTURE:
            stack.push(inst.out);
            break;
          case Inst.EMPTY_WIDTH:
            needflags |= inst.arg;
            if ((inst.arg & ~flag) === 0) stack.push(inst.out);
        }
      }
      return {
        pcs: Array.from(closure).sort((a, b) => a - b),
        needflags
      };
    }
    getState(pcs, flag, ids) {
      const hash = hashState(pcs, flag, ids);
      const cached = this.stateCache.get(hash);
      if (cached instanceof DFAState) {
        if (isState(cached, pcs, flag, ids)) return cached;
      } else if (cached !== void 0) {
        for (let i = 0; i < cached.length; i++) if (isState(cached[i], pcs, flag, ids)) return cached[i];
      }
      const cost = DFA2.stateCost(pcs, ids);
      if (this.memBudget < cost) return null;
      this.memBudget -= cost;
      const state = new DFAState(pcs, flag, ids);
      if (cached === void 0) this.stateCache.set(hash, state);
      else if (cached instanceof DFAState) this.stateCache.set(hash, [cached, state]);
      else cached.push(state);
      this.stateCount++;
      return state;
    }
    static stateCost(pcs, ids) {
      const idsCost = ids.length === 0 ? 0 : DFA2.ARRAY_OVERHEAD + DFA2.ELEMENT_SIZE * ids.length;
      return DFA2.STATE_OVERHEAD + DFA2.ELEMENT_SIZE * pcs.length + idsCost;
    }
    *cachedStates() {
      for (const cached of this.stateCache.values()) if (cached instanceof DFAState) yield cached;
      else yield* cached;
    }
    makeState(pcs, flag, ids) {
      const closure = this.closure(pcs, flag & DFA2.FLAG_EMPTY_MASK);
      let stateFlag = flag;
      if (closure.needflags === 0) stateFlag &= DFA2.FLAG_MATCH;
      stateFlag |= closure.needflags << DFA2.FLAG_NEED_SHIFT;
      return this.getState(closure.pcs, stateFlag, ids);
    }
    allocTable(state, anchor) {
      const size = this.numClasses + 1;
      const cost = DFA2.TABLE_OVERHEAD + DFA2.ELEMENT_SIZE * size;
      if (this.memBudget < cost) return null;
      this.memBudget -= cost;
      const table = new Array(size).fill(null);
      if (anchor === RE2Flags.UNANCHORED) state.next = table;
      else state.nextAnchored = table;
      return table;
    }
    clearCache() {
      this.stateCache.clear();
      this.stateCount = 0;
      this.startStates.clear();
      this.memBudget = this.stateBudget;
    }
    resetCache(current) {
      this.clearCache();
      return this.getState(current.nfaStates, current.flag, current.matchIDs);
    }
    step(state, cls, rune, anchor) {
      let table = anchor === RE2Flags.UNANCHORED ? state.next : state.nextAnchored;
      if (table !== null) {
        const cached = table[cls];
        if (cached !== null) return cached;
      } else {
        table = this.allocTable(state, anchor);
        if (table === null) return null;
      }
      const needflag = state.flag >>> DFA2.FLAG_NEED_SHIFT;
      const oldbeforeflag = state.flag & DFA2.FLAG_EMPTY_MASK;
      let beforeflag = oldbeforeflag;
      let afterflag = 0;
      if (rune === 10) {
        beforeflag |= Utils.EMPTY_END_LINE;
        afterflag |= Utils.EMPTY_BEGIN_LINE;
      }
      if (rune === END_TEXT) beforeflag |= Utils.EMPTY_END_LINE | Utils.EMPTY_END_TEXT;
      const islastword = (state.flag & DFA2.FLAG_LAST_WORD) !== 0;
      const isword = rune !== END_TEXT && Utils.isWordRune(rune);
      beforeflag |= isword === islastword ? Utils.EMPTY_NO_WORD_BOUNDARY : Utils.EMPTY_WORD_BOUNDARY;
      let pcs = state.nfaStates;
      if ((beforeflag & ~oldbeforeflag & needflag) !== 0) pcs = this.closure(pcs, beforeflag).pcs;
      const nextPCs = [];
      let ismatch = false;
      let ids = NO_IDS;
      for (let i = 0; i < pcs.length; i++) {
        const inst = this.prog.getInst(pcs[i]);
        if (inst.op === Inst.MATCH) {
          if (!ismatch) {
            ismatch = true;
            ids = [];
          }
          ids.push(inst.arg);
        } else if (rune !== END_TEXT && Inst.isRuneOp(inst.op) && inst.matchRune(rune)) nextPCs.push(inst.out);
      }
      if (ids.length > 1) ids.sort((a, b) => a - b);
      if (anchor === RE2Flags.UNANCHORED && rune !== END_TEXT) nextPCs.push(this.prog.start);
      let flag = afterflag;
      if (ismatch) flag |= DFA2.FLAG_MATCH;
      if (isword) flag |= DFA2.FLAG_LAST_WORD;
      const nextState = this.makeState(nextPCs, flag, ids);
      if (nextState === null) return null;
      table[cls] = nextState;
      return nextState;
    }
    start(input, pos) {
      const context = input.context(pos);
      let flags;
      if ((context & Utils.EMPTY_BEGIN_TEXT) !== 0) flags = Utils.EMPTY_BEGIN_TEXT | Utils.EMPTY_BEGIN_LINE;
      else if ((context & Utils.EMPTY_BEGIN_LINE) !== 0) flags = Utils.EMPTY_BEGIN_LINE;
      else {
        const r = input.step(pos);
        const nextIsWord = r >= 0 && Utils.isWordRune(r >> 3);
        flags = (context & Utils.EMPTY_WORD_BOUNDARY) !== 0 !== nextIsWord ? DFA2.FLAG_LAST_WORD : 0;
      }
      let state = this.startStates.get(flags);
      if (state === void 0) {
        state = this.makeState([this.prog.start], flags, NO_IDS);
        if (state === null) {
          this.clearCache();
          state = this.makeState([this.prog.start], flags, NO_IDS);
          if (state === null) return null;
        }
        this.startStates.set(flags, state);
      }
      return state;
    }
    stepOrReset(state, cls, rune, anchor, pos, search) {
      let next = this.step(state, cls, rune, anchor);
      if (next !== null) return next;
      if (search.resetPos >= 0 && pos - search.resetPos < DFA2.PROGRESS_PER_STATE * this.stateCount) return null;
      search.resetPos = pos;
      const restored = this.resetCache(state);
      if (restored === null) return null;
      next = this.step(restored, cls, rune, anchor);
      return next;
    }
    run(input, pos, anchor, state, onMatch) {
      const endPos = input.endPos();
      const latin1Class = this.latin1Class;
      const unanchored = anchor === RE2Flags.UNANCHORED;
      const search = { resetPos: -1 };
      let i = pos;
      while (i < endPos) {
        const r = input.step(i);
        const rune = r >> 3;
        const width = r & 7;
        if (width === 0) break;
        const cls = rune <= Unicode.MAX_LATIN1 ? latin1Class[rune] : this.runeClass(rune);
        let next = unanchored && state.next !== null ? state.next[cls] : null;
        if (next === null) {
          next = this.stepOrReset(state, cls, rune, anchor, i, search);
          if (next === null) return null;
        }
        state = next;
        if (state.isMatch && onMatch(state, false)) return true;
        if (!unanchored && state.nfaStates.length === 0) return false;
        i += width;
      }
      state = this.stepOrReset(state, this.numClasses, END_TEXT, anchor, i, search);
      if (state === null) return null;
      return state.isMatch && onMatch(state, true);
    }
    match(input, pos, anchor) {
      if (this.failed) return null;
      if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return false;
      const startState = this.start(input, pos);
      if (startState === null) return null;
      return this.run(input, pos, anchor, startState, (state, atEnd) => anchor !== RE2Flags.ANCHOR_BOTH || atEnd);
    }
    matchSet(input, pos, anchor) {
      if (this.failed) return null;
      if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return [];
      const startState = this.start(input, pos);
      if (startState === null) return null;
      const matches = /* @__PURE__ */ new Set();
      const collect = (state, atEnd) => {
        if (anchor !== RE2Flags.ANCHOR_BOTH || atEnd) for (let k = 0; k < state.matchIDs.length; k++) matches.add(state.matchIDs[k]);
        return false;
      };
      if (this.run(input, pos, anchor, startState, collect) === null) return null;
      return Array.from(matches).sort((a, b) => a - b);
    }
  };
  var VISITED_BITS = 32;
  var MAX_BACKTRACK_PROG = 500;
  var INITIAL_JOB_CAPACITY = 256;
  var MAX_BACKTRACK_VECTOR = 262144;
  var BitState = class {
    constructor() {
      this.end = 0;
      this.cap = /* @__PURE__ */ new Int32Array(0);
      this.matchcap = /* @__PURE__ */ new Int32Array(0);
      this.ncap = 0;
      this.jobPc = new Int32Array(INITIAL_JOB_CAPACITY);
      this.jobArg = new Uint8Array(INITIAL_JOB_CAPACITY);
      this.jobPos = new Int32Array(INITIAL_JOB_CAPACITY);
      this.jobLen = 0;
      this.visited = /* @__PURE__ */ new Uint32Array(0);
    }
    reset(prog, end, ncap) {
      this.end = end;
      this.jobLen = 0;
      this.ncap = ncap;
      const visitedSize = prog.numInst() * (end + 1) + VISITED_BITS - 1 >>> 5;
      if (this.visited.length < visitedSize) this.visited = new Uint32Array(visitedSize);
      else this.visited.fill(0, 0, visitedSize);
      if (this.cap.length < ncap) this.cap = new Int32Array(ncap).fill(-1);
      else this.cap.fill(-1, 0, ncap);
      if (this.matchcap.length < ncap) this.matchcap = new Int32Array(ncap).fill(-1);
      else this.matchcap.fill(-1, 0, ncap);
    }
    shouldVisit(pc, pos) {
      const n = pc * (this.end + 1) + pos;
      const idx = n >>> 5;
      const mask = 1 << (n & 31);
      if ((this.visited[idx] & mask) !== 0) return false;
      this.visited[idx] |= mask;
      return true;
    }
    push(re2, pc, pos, arg) {
      if (re2.prog.getInst(pc).op !== Inst.FAIL && (arg || this.shouldVisit(pc, pos))) {
        if (this.jobLen >= this.jobPc.length) {
          const newSize = this.jobPc.length * 2;
          const newPc = new Int32Array(newSize);
          newPc.set(this.jobPc);
          this.jobPc = newPc;
          const newArg = new Uint8Array(newSize);
          newArg.set(this.jobArg);
          this.jobArg = newArg;
          const newPos = new Int32Array(newSize);
          newPos.set(this.jobPos);
          this.jobPos = newPos;
        }
        this.jobPc[this.jobLen] = pc;
        this.jobArg[this.jobLen] = arg ? 1 : 0;
        this.jobPos[this.jobLen] = pos;
        this.jobLen++;
      }
    }
    tryBacktrack(re2, input, pc, pos, anchor) {
      const longest = re2.longest;
      this.push(re2, pc, pos, false);
      while (this.jobLen > 0) {
        this.jobLen--;
        let currentPc = this.jobPc[this.jobLen];
        let arg = this.jobArg[this.jobLen] === 1;
        let currentPos = this.jobPos[this.jobLen];
        let skipShouldVisit = true;
        while (true) {
          if (!skipShouldVisit) {
            if (!this.shouldVisit(currentPc, currentPos)) break;
          }
          skipShouldVisit = false;
          const inst = re2.prog.getInst(currentPc);
          switch (inst.op) {
            case Inst.FAIL:
              break;
            case Inst.ALT:
              if (arg) {
                arg = false;
                currentPc = inst.arg;
                continue;
              } else {
                this.push(re2, currentPc, currentPos, true);
                currentPc = inst.out;
                continue;
              }
            case Inst.ALT_MATCH: {
              const outInst = re2.prog.getInst(inst.out);
              if (Inst.isRuneOp(outInst.op)) {
                this.push(re2, inst.arg, currentPos, false);
                currentPc = inst.arg;
                currentPos = this.end;
                continue;
              }
              this.push(re2, inst.out, this.end, false);
              currentPc = inst.out;
              continue;
            }
            case Inst.RUNE: {
              const r = input.step(currentPos);
              if (r === MachineInputBase.EOF()) break;
              if (!inst.matchRune(r >> 3)) break;
              currentPos += r & 7;
              currentPc = inst.out;
              continue;
            }
            case Inst.RUNE1: {
              const r = input.step(currentPos);
              if (r === MachineInputBase.EOF()) break;
              if (r >> 3 !== inst.runes[0]) break;
              currentPos += r & 7;
              currentPc = inst.out;
              continue;
            }
            case Inst.RUNE_ANY_NOT_NL: {
              const r = input.step(currentPos);
              if (r === MachineInputBase.EOF()) break;
              if (r >> 3 === 10) break;
              currentPos += r & 7;
              currentPc = inst.out;
              continue;
            }
            case Inst.RUNE_ANY: {
              const r = input.step(currentPos);
              if (r === MachineInputBase.EOF()) break;
              currentPos += r & 7;
              currentPc = inst.out;
              continue;
            }
            case Inst.CAPTURE:
              if (arg) {
                this.cap[inst.arg] = currentPos;
                break;
              } else {
                if (inst.arg < this.ncap) {
                  this.push(re2, currentPc, this.cap[inst.arg], true);
                  this.cap[inst.arg] = currentPos;
                }
                currentPc = inst.out;
                continue;
              }
            case Inst.EMPTY_WIDTH: {
              const flag = input.context(currentPos);
              if ((inst.arg & ~flag) !== 0) break;
              currentPc = inst.out;
              continue;
            }
            case Inst.NOP:
              currentPc = inst.out;
              continue;
            case Inst.MATCH: {
              if (anchor === RE2Flags.ANCHOR_BOTH && currentPos !== this.end) break;
              if (this.ncap === 0) return true;
              if (this.ncap > 1) this.cap[1] = currentPos;
              const old = this.matchcap[1];
              if (old === -1 || longest && currentPos > 0 && currentPos > old) this.matchcap.set(this.cap);
              if (!longest) return true;
              if (currentPos === this.end) return true;
              break;
            }
            case Inst.LB_WRITE:
            case Inst.LB_CHECK:
              throw new RE2JSInternalException("Backtracker cannot evaluate Lookbehind instructions");
            default:
              throw new RE2JSInternalException("bad inst");
          }
          break;
        }
      }
      return longest && this.matchcap.length > 1 && this.matchcap[1] >= 0;
    }
  };
  var bitStatePool = [];
  var Backtracker = class Backtracker2 {
    static shouldBacktrack(prog) {
      return prog.numInst() <= MAX_BACKTRACK_PROG;
    }
    static maxBitStateLen(prog) {
      if (!Backtracker2.shouldBacktrack(prog)) return 0;
      return Math.floor(MAX_BACKTRACK_VECTOR / prog.numInst());
    }
    static execute(re2, input, pos, anchor, ncap) {
      const startCond = re2.cond;
      if (startCond === Utils.EMPTY_ALL) return null;
      if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return null;
      if ((startCond & Utils.EMPTY_BEGIN_TEXT) !== 0 && pos !== 0) return null;
      const b = bitStatePool.length > 0 ? bitStatePool.pop() : new BitState();
      const end = input.endPos();
      b.reset(re2.prog, end, ncap);
      let matched = false;
      if ((startCond & Utils.EMPTY_BEGIN_TEXT) !== 0 || anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) {
        if (b.ncap > 0) b.cap[0] = pos;
        if (b.tryBacktrack(re2, input, re2.prog.start, pos, anchor)) matched = true;
      } else {
        let width = -1;
        for (; pos <= end && width !== 0; pos += width) {
          if (re2.prefix.length > 0) {
            const advance = input.index(re2, pos);
            if (advance < 0) break;
            pos += advance;
          }
          if (b.ncap > 0) b.cap[0] = pos;
          if (b.tryBacktrack(re2, input, re2.prog.start, pos, anchor)) {
            matched = true;
            break;
          }
          const r = input.step(pos);
          width = r === MachineInputBase.EOF() ? 0 : r & 7;
        }
      }
      if (!matched) {
        bitStatePool.push(b);
        return null;
      }
      const result = ncap === 0 ? [] : Utils.toArray(b.matchcap.subarray(0, ncap));
      bitStatePool.push(b);
      return result;
    }
  };
  var QueueOnePass = class {
    constructor(size) {
      this.sparse = new Uint32Array(size);
      this.dense = new Uint32Array(size);
      this.size = 0;
      this.nextIndex = 0;
    }
    empty() {
      return this.nextIndex >= this.size;
    }
    next() {
      return this.dense[this.nextIndex++];
    }
    clear() {
      this.size = 0;
      this.nextIndex = 0;
    }
    contains(u) {
      return u < this.sparse.length && this.sparse[u] < this.size && this.dense[this.sparse[u]] === u;
    }
    insert(u) {
      if (!this.contains(u)) this.insertNew(u);
    }
    insertNew(u) {
      if (u >= this.sparse.length) return;
      this.sparse[u] = this.size;
      this.dense[this.size] = u;
      this.size++;
    }
  };
  var mergeRuneSets = (leftRunes, rightRunes, leftPC, rightPC) => {
    const leftLen = leftRunes.length;
    const rightLen = rightRunes.length;
    let lx = 0, rx = 0;
    const merged = [];
    const next = [];
    let ok = true;
    let ix = -1;
    const extend = (isLeft) => {
      const newArray = isLeft ? leftRunes : rightRunes;
      const low = isLeft ? lx : rx;
      const pc = isLeft ? leftPC : rightPC;
      if (ix > 0 && newArray[low] <= merged[ix]) return false;
      merged.push(newArray[low], newArray[low + 1]);
      if (isLeft) lx += 2;
      else rx += 2;
      ix += 2;
      next.push(pc);
      return true;
    };
    while (lx < leftLen || rx < rightLen) {
      if (rx >= rightLen) ok = extend(true);
      else if (lx >= leftLen) ok = extend(false);
      else if (rightRunes[rx] < leftRunes[lx]) ok = extend(false);
      else ok = extend(true);
      if (!ok) return null;
    }
    return {
      merged,
      next
    };
  };
  var OnePassProg = class {
    constructor(prog) {
      this.start = prog.start;
      this.numCap = prog.numCap;
      this.inst = new Array(prog.inst.length);
      for (let i = 0; i < prog.inst.length; i++) {
        const orig = prog.inst[i];
        const inst = new Inst(orig.op);
        inst.out = orig.out;
        inst.arg = orig.arg;
        inst.runes = orig.runes ? new Int32Array(orig.runes) : /* @__PURE__ */ new Int32Array(0);
        inst.next = null;
        this.inst[i] = inst;
      }
    }
  };
  var onePassCopy = (prog) => {
    const p = new OnePassProg(prog);
    for (let pc = 0; pc < p.inst.length; pc++) {
      const inst = p.inst[pc];
      if (inst.op !== Inst.ALT && inst.op !== Inst.ALT_MATCH) continue;
      let pAOther = "out";
      let pAAlt = "arg";
      let instAlt = p.inst[inst[pAAlt]];
      if (instAlt.op !== Inst.ALT && instAlt.op !== Inst.ALT_MATCH) {
        pAOther = "arg";
        pAAlt = "out";
        instAlt = p.inst[inst[pAAlt]];
        if (instAlt.op !== Inst.ALT && instAlt.op !== Inst.ALT_MATCH) continue;
      }
      const instOther = p.inst[inst[pAOther]];
      if (instOther.op === Inst.ALT || instOther.op === Inst.ALT_MATCH) continue;
      let pBAlt = "out";
      let pBOther = "arg";
      let patch = false;
      if (instAlt.out === pc) patch = true;
      else if (instAlt.arg === pc) {
        patch = true;
        pBAlt = "arg";
        pBOther = "out";
      }
      if (patch) instAlt[pBAlt] = inst[pAOther];
      if (inst[pAOther] === instAlt[pBAlt]) inst[pAAlt] = instAlt[pBOther];
    }
    return p;
  };
  var makeOnePass = (p) => {
    if (p.inst.length >= 1e3) return null;
    const instQueue = new QueueOnePass(p.inst.length);
    const visitQueue = new QueueOnePass(p.inst.length);
    const onePassRunes = new Array(p.inst.length);
    const m = new Array(p.inst.length).fill(false);
    const check = (pc) => {
      let ok = true;
      const inst = p.inst[pc];
      if (visitQueue.contains(pc)) return true;
      visitQueue.insert(pc);
      switch (inst.op) {
        case Inst.ALT:
        case Inst.ALT_MATCH: {
          ok = check(inst.out) && check(inst.arg);
          let matchOut = m[inst.out];
          let matchArg = m[inst.arg];
          if (matchOut && matchArg) return false;
          if (matchArg) {
            const tempOut = inst.out;
            inst.out = inst.arg;
            inst.arg = tempOut;
            const tempMatch = matchOut;
            matchOut = matchArg;
            matchArg = tempMatch;
          }
          if (matchOut) {
            m[pc] = true;
            inst.op = Inst.ALT_MATCH;
          }
          const leftRunes = onePassRunes[inst.out] || [];
          const rightRunes = onePassRunes[inst.arg] || [];
          const mergeRes = mergeRuneSets(leftRunes, rightRunes, inst.out, inst.arg);
          if (!mergeRes) return false;
          onePassRunes[pc] = new Int32Array(mergeRes.merged);
          inst.next = new Uint32Array(mergeRes.next);
          break;
        }
        case Inst.CAPTURE:
        case Inst.EMPTY_WIDTH:
        case Inst.NOP:
          ok = check(inst.out);
          m[pc] = m[inst.out];
          onePassRunes[pc] = onePassRunes[inst.out] ? new Int32Array(onePassRunes[inst.out]) : /* @__PURE__ */ new Int32Array(0);
          inst.next = new Uint32Array(Math.floor(onePassRunes[pc].length / 2) + 1).fill(inst.out);
          break;
        case Inst.MATCH:
        case Inst.FAIL:
          m[pc] = inst.op === Inst.MATCH;
          break;
        case Inst.RUNE: {
          m[pc] = false;
          if (inst.next && inst.next.length > 0) break;
          instQueue.insert(inst.out);
          if (!inst.runes || inst.runes.length === 0) {
            onePassRunes[pc] = /* @__PURE__ */ new Int32Array(0);
            inst.next = new Uint32Array([inst.out]);
            break;
          }
          let runes = [];
          if (inst.runes.length === 1 && (inst.arg & RE2Flags.FOLD_CASE) !== 0) {
            const r0 = inst.runes[0];
            runes.push(r0, r0);
            for (let r1 = Unicode.simpleFold(r0); r1 !== r0; r1 = Unicode.simpleFold(r1)) runes.push(r1, r1);
            runes.sort((a, b) => a - b);
          } else for (let j = 0; j < inst.runes.length; j++) runes.push(inst.runes[j]);
          onePassRunes[pc] = new Int32Array(runes);
          inst.next = new Uint32Array(Math.floor(runes.length / 2) + 1).fill(inst.out);
          inst.op = Inst.RUNE;
          break;
        }
        case Inst.RUNE1: {
          m[pc] = false;
          if (inst.next && inst.next.length > 0) break;
          instQueue.insert(inst.out);
          let runes = [];
          if ((inst.arg & RE2Flags.FOLD_CASE) !== 0) {
            const r0 = inst.runes[0];
            runes.push(r0, r0);
            for (let r1 = Unicode.simpleFold(r0); r1 !== r0; r1 = Unicode.simpleFold(r1)) runes.push(r1, r1);
            runes.sort((a, b) => a - b);
          } else runes.push(inst.runes[0], inst.runes[0]);
          onePassRunes[pc] = new Int32Array(runes);
          inst.next = new Uint32Array(Math.floor(runes.length / 2) + 1).fill(inst.out);
          inst.op = Inst.RUNE;
          break;
        }
        case Inst.RUNE_ANY:
          m[pc] = false;
          if (inst.next && inst.next.length > 0) break;
          instQueue.insert(inst.out);
          onePassRunes[pc] = new Int32Array([0, Unicode.MAX_RUNE]);
          inst.next = new Uint32Array([inst.out]);
          break;
        case Inst.RUNE_ANY_NOT_NL:
          m[pc] = false;
          if (inst.next && inst.next.length > 0) break;
          instQueue.insert(inst.out);
          onePassRunes[pc] = new Int32Array([
            0,
            9,
            11,
            Unicode.MAX_RUNE
          ]);
          inst.next = new Uint32Array(Math.floor(onePassRunes[pc].length / 2) + 1).fill(inst.out);
      }
      return ok;
    };
    instQueue.clear();
    instQueue.insert(p.start);
    while (!instQueue.empty()) {
      visitQueue.clear();
      if (!check(instQueue.next())) return null;
    }
    for (let i = 0; i < p.inst.length; i++) if (onePassRunes[i]) p.inst[i].runes = onePassRunes[i];
    return p;
  };
  var cleanupOnePass = (p, original) => {
    for (let ix = 0; ix < original.inst.length; ix++) {
      const instOriginal = original.inst[ix];
      switch (instOriginal.op) {
        case Inst.ALT:
        case Inst.ALT_MATCH:
        case Inst.RUNE:
          break;
        case Inst.CAPTURE:
        case Inst.EMPTY_WIDTH:
        case Inst.NOP:
        case Inst.MATCH:
        case Inst.FAIL:
          p.inst[ix].next = null;
          break;
        case Inst.RUNE1:
        case Inst.RUNE_ANY:
        case Inst.RUNE_ANY_NOT_NL:
          p.inst[ix].next = null;
          p.inst[ix].op = instOriginal.op;
          p.inst[ix].runes = instOriginal.runes ? new Int32Array(instOriginal.runes) : /* @__PURE__ */ new Int32Array(0);
      }
    }
  };
  var OnePass = class OnePass2 {
    static compile(prog) {
      if (prog.start === 0) return null;
      if (prog.numLb > 0) return null;
      const startInst = prog.inst[prog.start];
      if (startInst.op !== Inst.EMPTY_WIDTH || (startInst.arg & Utils.EMPTY_BEGIN_TEXT) === 0) return null;
      let hasAlt = false;
      for (let i = 0; i < prog.inst.length; i++) if (prog.inst[i].op === Inst.ALT || prog.inst[i].op === Inst.ALT_MATCH) {
        hasAlt = true;
        break;
      }
      for (let i = 0; i < prog.inst.length; i++) {
        const inst = prog.inst[i];
        const opOut = prog.inst[inst.out].op;
        switch (inst.op) {
          case Inst.ALT:
          case Inst.ALT_MATCH:
            if (opOut === Inst.MATCH || prog.inst[inst.arg].op === Inst.MATCH) return null;
            break;
          case Inst.EMPTY_WIDTH:
            if (opOut === Inst.MATCH) {
              if ((inst.arg & Utils.EMPTY_END_TEXT) === Utils.EMPTY_END_TEXT) continue;
              return null;
            }
            break;
          default:
            if (opOut === Inst.MATCH && hasAlt) return null;
        }
      }
      let p = onePassCopy(prog);
      p = makeOnePass(p);
      if (p !== null) cleanupOnePass(p, prog);
      return p;
    }
    static next(inst, r) {
      const nextIdx = inst.matchRunePos(r);
      if (nextIdx >= 0) return inst.next[nextIdx];
      if (inst.op === Inst.ALT_MATCH) return inst.out;
      return 0;
    }
    static execute(re2, input, pos, anchor, ncap) {
      const onepass = re2.onepass;
      if (!onepass) return null;
      const matchcap = new Int32Array(ncap).fill(-1);
      let matched = false;
      let r = input.step(pos);
      let rune = r >> 3;
      let width = r & 7;
      let r1 = MachineInputBase.EOF();
      let rune1 = -1;
      let width1 = 0;
      if (r !== MachineInputBase.EOF()) {
        r1 = input.step(pos + width);
        if (r1 !== MachineInputBase.EOF()) {
          rune1 = r1 >> 3;
          width1 = r1 & 7;
        }
      }
      let flag = pos === 0 ? Utils.emptyOpContext(-1, rune) : input.context(pos);
      let pc = onepass.start;
      let inst;
      while (true) {
        inst = onepass.inst[pc];
        pc = inst.out;
        switch (inst.op) {
          case Inst.MATCH:
            if (anchor === RE2Flags.ANCHOR_BOTH && pos !== input.endPos()) return null;
            matched = true;
            if (matchcap.length > 0) {
              matchcap[0] = 0;
              matchcap[1] = pos;
            }
            return ncap === 0 ? [] : Utils.toArray(matchcap);
          case Inst.RUNE:
            if (!inst.matchRune(rune)) return null;
            break;
          case Inst.RUNE1:
            if (rune !== inst.runes[0]) return null;
            break;
          case Inst.RUNE_ANY:
            break;
          case Inst.RUNE_ANY_NOT_NL:
            if (rune === 10) return null;
            break;
          case Inst.ALT:
          case Inst.ALT_MATCH:
            pc = OnePass2.next(inst, rune);
            continue;
          case Inst.FAIL:
            return null;
          case Inst.NOP:
            continue;
          case Inst.EMPTY_WIDTH:
            if ((inst.arg & ~flag) !== 0) return null;
            continue;
          case Inst.CAPTURE:
            if (inst.arg < matchcap.length) matchcap[inst.arg] = pos;
            continue;
          default:
            throw new RE2JSInternalException("bad inst");
        }
        if (width === 0) break;
        flag = Utils.emptyOpContext(rune, rune1);
        pos += width;
        rune = rune1;
        width = width1;
        if (rune !== -1) {
          r1 = input.step(pos + width);
          if (r1 !== MachineInputBase.EOF()) {
            rune1 = r1 >> 3;
            width1 = r1 & 7;
          } else {
            rune1 = -1;
            width1 = 0;
          }
        }
      }
      if (!matched) return null;
      return ncap === 0 ? [] : Utils.toArray(matchcap);
    }
  };
  var Regexp = class Regexp2 {
    static Op = createEnum([
      "NO_MATCH",
      "EMPTY_MATCH",
      "LITERAL",
      "CHAR_CLASS",
      "ANY_CHAR_NOT_NL",
      "ANY_CHAR",
      "BEGIN_LINE",
      "END_LINE",
      "BEGIN_TEXT",
      "END_TEXT",
      "WORD_BOUNDARY",
      "NO_WORD_BOUNDARY",
      "CAPTURE",
      "STAR",
      "PLUS",
      "QUEST",
      "REPEAT",
      "CONCAT",
      "ALTERNATE",
      "PLB",
      "NLB",
      "LEFT_PAREN",
      "VERTICAL_BAR"
    ]);
    static isPseudoOp(op) {
      return op >= Regexp2.Op.LEFT_PAREN;
    }
    static emptySubs() {
      return [];
    }
    static quoteIfHyphen(rune) {
      if (rune === Codepoint.CODES["-"]) return "\\";
      return "";
    }
    static fromRegexp(re) {
      const regex = new Regexp2(re.op);
      regex.flags = re.flags;
      regex.subs = re.subs;
      regex.runes = re.runes;
      regex.cap = re.cap;
      regex.min = re.min;
      regex.max = re.max;
      regex.name = re.name;
      regex.namedGroups = re.namedGroups;
      regex.lb = re.lb;
      return regex;
    }
    constructor(op) {
      this.op = op;
      this.flags = 0;
      this.subs = Regexp2.emptySubs();
      this.runes = /* @__PURE__ */ new Int32Array(0);
      this.min = 0;
      this.max = 0;
      this.cap = 0;
      this.name = null;
      this.namedGroups = /* @__PURE__ */ Object.create(null);
      this.lb = 0;
    }
    reinit() {
      this.flags = 0;
      this.subs = Regexp2.emptySubs();
      this.runes = /* @__PURE__ */ new Int32Array(0);
      this.cap = 0;
      this.min = 0;
      this.max = 0;
      this.name = null;
      this.namedGroups = /* @__PURE__ */ Object.create(null);
      this.lb = 0;
    }
    toString() {
      return this.appendTo();
    }
    appendTo() {
      let out = "";
      switch (this.op) {
        case Regexp2.Op.NO_MATCH:
          out += "[^\\x00-\\x{10FFFF}]";
          break;
        case Regexp2.Op.EMPTY_MATCH:
          out += "(?:)";
          break;
        case Regexp2.Op.STAR:
        case Regexp2.Op.PLUS:
        case Regexp2.Op.QUEST:
        case Regexp2.Op.REPEAT: {
          const sub = this.subs[0];
          if (sub.op > Regexp2.Op.CAPTURE || sub.op === Regexp2.Op.LITERAL && sub.runes.length > 1) out += `(?:${sub.appendTo()})`;
          else out += sub.appendTo();
          switch (this.op) {
            case Regexp2.Op.STAR:
              out += "*";
              break;
            case Regexp2.Op.PLUS:
              out += "+";
              break;
            case Regexp2.Op.QUEST:
              out += "?";
              break;
            case Regexp2.Op.REPEAT:
              out += `{${this.min}`;
              if (this.min !== this.max) {
                out += ",";
                if (this.max >= 0) out += this.max;
              }
              out += "}";
          }
          if ((this.flags & RE2Flags.NON_GREEDY) !== 0) out += "?";
          break;
        }
        case Regexp2.Op.CONCAT:
          for (let sub of this.subs) if (sub.op === Regexp2.Op.ALTERNATE) out += `(?:${sub.appendTo()})`;
          else out += sub.appendTo();
          break;
        case Regexp2.Op.ALTERNATE: {
          let sep = "";
          for (let sub of this.subs) {
            out += sep;
            sep = "|";
            out += sub.appendTo();
          }
          break;
        }
        case Regexp2.Op.LITERAL:
          if ((this.flags & RE2Flags.FOLD_CASE) !== 0) out += "(?i:";
          for (let rune of this.runes) out += Utils.escapeRune(rune);
          if ((this.flags & RE2Flags.FOLD_CASE) !== 0) out += ")";
          break;
        case Regexp2.Op.ANY_CHAR_NOT_NL:
          out += "(?-s:.)";
          break;
        case Regexp2.Op.ANY_CHAR:
          out += "(?s:.)";
          break;
        case Regexp2.Op.PLB:
          out += `(?<=${this.subs[0].appendTo()})`;
          break;
        case Regexp2.Op.NLB:
          out += `(?<!${this.subs[0].appendTo()})`;
          break;
        case Regexp2.Op.CAPTURE:
          if (this.name === null || this.name.length === 0) out += "(";
          else out += `(?P<${this.name}>`;
          if (this.subs[0].op !== Regexp2.Op.EMPTY_MATCH) out += this.subs[0].appendTo();
          out += ")";
          break;
        case Regexp2.Op.BEGIN_TEXT:
          out += "\\A";
          break;
        case Regexp2.Op.END_TEXT:
          if ((this.flags & RE2Flags.WAS_DOLLAR) !== 0) out += "(?-m:$)";
          else out += "\\z";
          break;
        case Regexp2.Op.BEGIN_LINE:
          out += "^";
          break;
        case Regexp2.Op.END_LINE:
          out += "$";
          break;
        case Regexp2.Op.WORD_BOUNDARY:
          out += "\\b";
          break;
        case Regexp2.Op.NO_WORD_BOUNDARY:
          out += "\\B";
          break;
        case Regexp2.Op.CHAR_CLASS:
          if (this.runes.length % 2 !== 0) {
            out += "[invalid char class]";
            break;
          }
          out += "[";
          if (this.runes.length === 0) out += "^\\x00-\\x{10FFFF}";
          else if (this.runes[0] === 0 && this.runes[this.runes.length - 1] === Unicode.MAX_RUNE) {
            out += "^";
            for (let i = 1; i < this.runes.length - 1; i += 2) {
              const lo = this.runes[i] + 1;
              const hi = this.runes[i + 1] - 1;
              out += Regexp2.quoteIfHyphen(lo);
              out += Utils.escapeRune(lo);
              if (lo !== hi) {
                out += "-";
                out += Regexp2.quoteIfHyphen(hi);
                out += Utils.escapeRune(hi);
              }
            }
          } else for (let i = 0; i < this.runes.length; i += 2) {
            const lo = this.runes[i];
            const hi = this.runes[i + 1];
            out += Regexp2.quoteIfHyphen(lo);
            out += Utils.escapeRune(lo);
            if (lo !== hi) {
              out += "-";
              out += Regexp2.quoteIfHyphen(hi);
              out += Utils.escapeRune(hi);
            }
          }
          out += "]";
          break;
        default:
          out += this.op;
      }
      return out;
    }
    maxCap() {
      let m = 0;
      if (this.op === Regexp2.Op.CAPTURE) m = this.cap;
      if (this.subs !== null) for (let sub of this.subs) {
        const n = sub.maxCap();
        if (m < n) m = n;
      }
      return m;
    }
    equals(that) {
      if (!(that !== null && that instanceof Regexp2)) return false;
      if (this.op !== that.op) return false;
      switch (this.op) {
        case Regexp2.Op.END_TEXT:
          if ((this.flags & RE2Flags.WAS_DOLLAR) !== (that.flags & RE2Flags.WAS_DOLLAR)) return false;
          break;
        case Regexp2.Op.LITERAL:
        case Regexp2.Op.CHAR_CLASS:
          if ((this.flags & RE2Flags.FOLD_CASE) !== (that.flags & RE2Flags.FOLD_CASE)) return false;
          if (this.runes === null && that.runes === null) break;
          if (this.runes === null || that.runes === null) return false;
          if (this.runes.length !== that.runes.length) return false;
          for (let i = 0; i < this.runes.length; i++) if (this.runes[i] !== that.runes[i]) return false;
          break;
        case Regexp2.Op.ALTERNATE:
        case Regexp2.Op.CONCAT:
          if (this.subs.length !== that.subs.length) return false;
          for (let i = 0; i < this.subs.length; ++i) if (!this.subs[i].equals(that.subs[i])) return false;
          break;
        case Regexp2.Op.STAR:
        case Regexp2.Op.PLUS:
        case Regexp2.Op.QUEST:
          if ((this.flags & RE2Flags.NON_GREEDY) !== (that.flags & RE2Flags.NON_GREEDY) || !this.subs[0].equals(that.subs[0])) return false;
          break;
        case Regexp2.Op.REPEAT:
          if ((this.flags & RE2Flags.NON_GREEDY) !== (that.flags & RE2Flags.NON_GREEDY) || this.min !== that.min || this.max !== that.max || !this.subs[0].equals(that.subs[0])) return false;
          break;
        case Regexp2.Op.CAPTURE:
          if (this.cap !== that.cap || (this.name === null ? that.name !== null : this.name !== that.name) || !this.subs[0].equals(that.subs[0])) return false;
          break;
        case Regexp2.Op.PLB:
        case Regexp2.Op.NLB:
          if (this.lb !== that.lb || !this.subs[0].equals(that.subs[0])) return false;
      }
      return true;
    }
  };
  var RegexpWalker = class {
    static walk(root, handler) {
      const stack = [];
      let re = root;
      let result;
      for (; ; ) {
        if (re.subs.length === 0) result = handler.leaf(re);
        else {
          const state = handler.enter(re);
          if (state.result === void 0) {
            stack.push({
              re,
              state,
              i: 0
            });
            re = re.subs[0];
            continue;
          }
          result = state.result;
        }
        for (; ; ) {
          if (stack.length === 0) return result;
          const frame = stack[stack.length - 1];
          handler.child(frame.re, frame.state, result, frame.i);
          frame.i++;
          if (frame.state.result === void 0 && frame.i < frame.re.subs.length) {
            re = frame.re.subs[frame.i];
            break;
          }
          stack.pop();
          result = frame.state.result !== void 0 ? frame.state.result : handler.leave(frame.re, frame.state);
        }
      }
    }
  };
  var AhoCorasick = class {
    constructor(words, alphabetSize) {
      const edges = /* @__PURE__ */ new Map();
      const parent = [0];
      const unit = [0];
      const depth = [0];
      const terminal = [0];
      for (const word of words) {
        let node = 0;
        for (let i = 0; i < word.length; i++) {
          const key = node * alphabetSize + word[i];
          let child2 = edges.get(key);
          if (child2 === void 0) {
            child2 = parent.length;
            edges.set(key, child2);
            parent.push(node);
            unit.push(word[i]);
            depth.push(depth[node] + 1);
            terminal.push(0);
          }
          node = child2;
        }
        terminal[node] = 1;
      }
      const numNodes = parent.length;
      const children2 = new Int32Array(numNodes - 1);
      for (let c = 1; c < numNodes; c++) children2[c - 1] = c;
      children2.sort((a, b) => parent[a] - parent[b] || unit[a] - unit[b]);
      const childStart = new Int32Array(numNodes + 1);
      for (let c = 1; c < numNodes; c++) childStart[parent[c] + 1]++;
      for (let n = 0; n < numNodes; n++) childStart[n + 1] += childStart[n];
      const childUnit = new Int32Array(numNodes - 1);
      for (let k = 0; k < children2.length; k++) childUnit[k] = unit[children2[k]];
      this.childStart = childStart;
      this.childUnit = childUnit;
      this.childNode = children2;
      const byDepth = new Int32Array(numNodes);
      for (let n = 0; n < numNodes; n++) byDepth[n] = n;
      byDepth.sort((a, b) => depth[a] - depth[b]);
      const fail = new Int32Array(numNodes);
      const match = Uint8Array.from(terminal);
      for (let k = 1; k < numNodes; k++) {
        const c = byDepth[k];
        const p = parent[c];
        if (p !== 0) {
          let f = fail[p];
          let next = this.next(f, unit[c]);
          while (next < 0 && f !== 0) {
            f = fail[f];
            next = this.next(f, unit[c]);
          }
          fail[c] = next >= 0 ? next : 0;
        }
        match[c] |= match[fail[c]];
      }
      this.fail = fail;
      this.match = match;
    }
    next(node, u) {
      let lo = this.childStart[node];
      let hi = this.childStart[node + 1];
      const units = this.childUnit;
      while (lo < hi) {
        const mid = lo + hi >> 1;
        const m = units[mid];
        if (m === u) return this.childNode[mid];
        if (m < u) lo = mid + 1;
        else hi = mid;
      }
      return -1;
    }
    advance(node, u) {
      for (; ; ) {
        const next = this.next(node, u);
        if (next >= 0) return next;
        if (node === 0) return 0;
        node = this.fail[node];
      }
    }
    searchUTF16(charSeq, start, end) {
      let node = 0;
      for (let i = start; i < end; i++) {
        node = this.advance(node, charSeq.charCodeAt(i));
        if (this.match[node] === 1) return true;
      }
      return false;
    }
    searchUTF8(bytes, start, end) {
      let node = 0;
      for (let i = start; i < end; i++) {
        node = this.advance(node, bytes[i]);
        if (this.match[node] === 1) return true;
      }
      return false;
    }
  };
  var Prefilter = class Prefilter2 {
    static Type = {
      NONE: 0,
      EXACT: 1,
      AND: 2,
      OR: 3
    };
    static MAX_SCANS = 32;
    static MAX_AC_UNITS = 1 << 18;
    constructor(type) {
      this.type = type;
      this.subs = [];
      this.str = "";
      this.bytes = null;
      this.cost = type === Prefilter2.Type.EXACT ? 1 : 0;
      this.allExact = false;
      this.ac16 = null;
      this.ac8 = null;
    }
    automaton16() {
      if (this.ac16 === null) {
        const words = this.subs.map((s) => {
          const arr = new Array(s.str.length);
          for (let i = 0; i < s.str.length; i++) arr[i] = s.str.charCodeAt(i);
          return arr;
        });
        this.ac16 = new AhoCorasick(words, 65536);
      }
      return this.ac16;
    }
    automaton8() {
      if (this.ac8 === null) this.ac8 = new AhoCorasick(this.subs.map((s) => s.bytes), 256);
      return this.ac8;
    }
    eval(input, pos) {
      switch (this.type) {
        case Prefilter2.Type.NONE:
          return true;
        case Prefilter2.Type.EXACT:
          return input.hasString(this, pos);
        case Prefilter2.Type.AND:
          for (let i = 0; i < this.subs.length; i++) if (!this.subs[i].eval(input, pos)) return false;
          return true;
        case Prefilter2.Type.OR:
          if (this.allExact) return input.hasAnyString(this, pos);
          for (let i = 0; i < this.subs.length; i++) if (this.subs[i].eval(input, pos)) return true;
          return false;
        default:
          return true;
      }
    }
  };
  var PrefilterTree = class PrefilterTree2 {
    static build(re) {
      if (!re) return new Prefilter(Prefilter.Type.NONE);
      return RegexpWalker.walk(re, PrefilterTree2.WALKER);
    }
    static WALKER = {
      leaf: (re) => PrefilterTree2.leaf(re),
      enter: (re) => PrefilterTree2.enter(re),
      child: (re, state, result) => PrefilterTree2.child(re, state, result),
      leave: (re, state) => PrefilterTree2.leave(re, state)
    };
    static leaf(re) {
      if (re.op !== Regexp.Op.LITERAL) return new Prefilter(Prefilter.Type.NONE);
      if (re.runes.length === 0 || (re.flags & RE2Flags.FOLD_CASE) !== 0) return new Prefilter(Prefilter.Type.NONE);
      let str = "";
      for (let i = 0; i < re.runes.length; i++) {
        if (Unicode.isUnsearchable(re.runes[i])) return new Prefilter(Prefilter.Type.NONE);
        str += String.fromCodePoint(re.runes[i]);
      }
      const pf = new Prefilter(Prefilter.Type.EXACT);
      pf.str = str;
      pf.bytes = Utils.stringToUtf8ByteArray(pf.str);
      return pf;
    }
    static enter(re) {
      switch (re.op) {
        case Regexp.Op.CAPTURE:
        case Regexp.Op.PLUS:
          return { sub: null };
        case Regexp.Op.REPEAT:
          if (re.min >= 1) return { sub: null };
          return { result: new Prefilter(Prefilter.Type.NONE) };
        case Regexp.Op.CONCAT:
          return {
            pf: new Prefilter(Prefilter.Type.AND),
            subs: []
          };
        case Regexp.Op.ALTERNATE:
          return {
            pf: new Prefilter(Prefilter.Type.OR),
            subs: []
          };
        default:
          return { result: new Prefilter(Prefilter.Type.NONE) };
      }
    }
    static child(re, state, s) {
      if (state.subs === void 0) {
        state.sub = s;
        return;
      }
      if (state.pf.type === Prefilter.Type.AND) {
        if (s.type === Prefilter.Type.NONE) return;
        if (s.type === Prefilter.Type.AND) {
          for (let j = 0; j < s.subs.length; j++) state.subs.push(s.subs[j]);
          return;
        }
        state.subs.push(s);
        return;
      }
      if (s.type === Prefilter.Type.NONE) {
        state.result = new Prefilter(Prefilter.Type.NONE);
        return;
      }
      if (s.type === Prefilter.Type.OR) {
        for (let j = 0; j < s.subs.length; j++) state.subs.push(s.subs[j]);
        return;
      }
      state.subs.push(s);
    }
    static leave(re, state) {
      if (state.subs === void 0) return state.sub;
      const pf = state.pf;
      const seen = /* @__PURE__ */ new Set();
      const subs = [];
      for (const sub of state.subs) {
        if (sub.type === Prefilter.Type.EXACT) {
          if (seen.has(sub.str)) continue;
          seen.add(sub.str);
        }
        subs.push(sub);
      }
      if (pf.type === Prefilter.Type.AND) {
        const kept = [];
        let cost2 = 0;
        for (const sub of subs) {
          if (cost2 + sub.cost > Prefilter.MAX_SCANS) continue;
          kept.push(sub);
          cost2 += sub.cost;
        }
        if (kept.length === 0) return new Prefilter(Prefilter.Type.NONE);
        if (kept.length === 1) return kept[0];
        pf.subs = kept;
        pf.cost = cost2;
        return pf;
      }
      if (subs.length === 0) return new Prefilter(Prefilter.Type.NONE);
      if (subs.length === 1) return subs[0];
      pf.subs = subs;
      let allExact = true;
      let cost = 0;
      let units = 0;
      for (const sub of subs) {
        if (sub.type !== Prefilter.Type.EXACT) allExact = false;
        else units += sub.bytes.length;
        cost += sub.cost;
      }
      if (allExact) {
        if (units > Prefilter.MAX_AC_UNITS) return new Prefilter(Prefilter.Type.NONE);
        pf.allExact = true;
        pf.cost = 1;
        return pf;
      }
      if (cost > Prefilter.MAX_SCANS) return new Prefilter(Prefilter.Type.NONE);
      pf.cost = cost;
      return pf;
    }
  };
  var PatchList = class {
    /**
    * @param {number} head - Encoded pointer to the start of the patch list.
    * @param {number} tail - Encoded pointer to the end of the patch list.
    */
    constructor(head = 0, tail = 0) {
      this.head = head;
      this.tail = tail;
    }
  };
  var Prog = class {
    constructor() {
      this.inst = [];
      this.start = 0;
      this.numCap = 2;
      this.lbStarts = [];
      this.numLb = 0;
      this.lbInst = null;
    }
    getInst(pc) {
      return this.inst[pc];
    }
    numInst() {
      return this.inst.length;
    }
    addInst(op) {
      this.inst.push(new Inst(op));
    }
    markLookbehindInsts() {
      const lbInst = new Uint8Array(this.inst.length);
      const pending = this.lbStarts.slice();
      while (pending.length > 0) {
        const pc = pending.pop();
        if (pc === 0 || lbInst[pc] === 1) continue;
        lbInst[pc] = 1;
        const i = this.inst[pc];
        switch (i.op) {
          case Inst.ALT:
          case Inst.ALT_MATCH:
            pending.push(i.out, i.arg);
            break;
          case Inst.MATCH:
          case Inst.FAIL:
            break;
          default:
            pending.push(i.out);
        }
      }
      this.lbInst = lbInst;
    }
    skipNop(pc) {
      let i = this.inst[pc];
      while (i.op === Inst.NOP || i.op === Inst.CAPTURE) {
        i = this.inst[pc];
        pc = i.out;
      }
      return i;
    }
    /** @returns {[boolean, string]} */
    prefix() {
      let prefix = "";
      let i = this.skipNop(this.start);
      if (!Inst.isRuneOp(i.op) || i.runes.length !== 1) return [i.op === Inst.MATCH, prefix];
      while (Inst.isRuneOp(i.op) && i.runes.length === 1 && (i.arg & RE2Flags.FOLD_CASE) === 0 && !Unicode.isUnsearchable(i.runes[0])) {
        prefix += String.fromCodePoint(i.runes[0]);
        i = this.skipNop(i.out);
      }
      return [i.op === Inst.MATCH, prefix];
    }
    startCond() {
      let flag = 0;
      let pc = this.start;
      loop: for (; ; ) {
        const i = this.inst[pc];
        switch (i.op) {
          case Inst.EMPTY_WIDTH:
            flag |= i.arg;
            break;
          case Inst.FAIL:
            return -1;
          case Inst.CAPTURE:
          case Inst.NOP:
            break;
          default:
            break loop;
        }
        pc = i.out;
      }
      return flag;
    }
    patch(l, val) {
      let head = l.head;
      while (head !== 0) {
        const i = this.inst[head >> 1];
        if ((head & 1) === 0) {
          head = i.out;
          i.out = val;
        } else {
          head = i.arg;
          i.arg = val;
        }
      }
    }
    append(l1, l2) {
      if (l1.head === 0) return l2;
      if (l2.head === 0) return l1;
      const i = this.inst[l1.tail >> 1];
      if ((l1.tail & 1) === 0) i.out = l2.head;
      else i.arg = l2.head;
      return new PatchList(l1.head, l2.tail);
    }
    /**
    *
    * @returns {string}
    */
    toString() {
      let out = "";
      for (let pc = 0; pc < this.inst.length; pc++) {
        const len = out.length;
        out += pc;
        if (pc === this.start) out += "*";
        out += "        ".substring(out.length - len);
        out += this.inst[pc];
        out += "\n";
      }
      return out;
    }
  };
  var ANY_RUNE_NOT_NL = new Int32Array([
    0,
    Codepoint.CODES["\n"] - 1,
    Codepoint.CODES["\n"] + 1,
    Unicode.MAX_RUNE
  ]);
  var ANY_RUNE = new Int32Array([0, Unicode.MAX_RUNE]);
  var Frag = class {
    constructor(i = 0, out = new PatchList(), nullable = false) {
      this.i = i;
      this.out = out;
      this.nullable = nullable;
    }
  };
  var Compiler = class Compiler2 {
    static compileRegexp(re) {
      const c = new Compiler2();
      const f = c.compile(re);
      c.prog.patch(f.out, c.newInst(Inst.MATCH).i);
      c.prog.start = f.i;
      c.prog.markLookbehindInsts();
      return c.prog;
    }
    static compileSet(regexps) {
      const c = new Compiler2();
      if (regexps.length === 0) {
        c.prog.start = c.newInst(Inst.FAIL).i;
        c.prog.markLookbehindInsts();
        return c.prog;
      }
      let starts = [];
      for (let i = 0; i < regexps.length; i++) {
        c.lbOffset = c.prog.numLb;
        const f = c.compile(regexps[i]);
        const m = c.newInst(Inst.MATCH);
        c.prog.getInst(m.i).arg = i;
        c.prog.patch(f.out, m.i);
        starts.push(f.i);
      }
      let start = starts[0];
      for (let i = 1; i < starts.length; i++) {
        const f = c.newInst(Inst.ALT);
        const inst = c.prog.getInst(f.i);
        inst.out = start;
        inst.arg = starts[i];
        start = f.i;
      }
      c.prog.start = start;
      c.prog.markLookbehindInsts();
      return c.prog;
    }
    constructor() {
      this.prog = new Prog();
      this.newInst(Inst.FAIL);
      this.lbOffset = 0;
      this.runeCache = /* @__PURE__ */ new Map();
      this.walker = {
        leaf: (re) => this.leaf(re),
        enter: (re) => this.enter(re),
        child: (re, state, result) => this.child(re, state, result),
        leave: (re, state) => this.leave(re, state)
      };
    }
    newInst(op) {
      this.prog.addInst(op);
      return new Frag(this.prog.numInst() - 1, new PatchList(), true);
    }
    nop() {
      const f = this.newInst(Inst.NOP);
      f.out = new PatchList(f.i << 1, f.i << 1);
      return f;
    }
    fail() {
      return new Frag();
    }
    cap(arg) {
      const f = this.newInst(Inst.CAPTURE);
      f.out = new PatchList(f.i << 1, f.i << 1);
      this.prog.getInst(f.i).arg = arg;
      if (this.prog.numCap < arg + 1) this.prog.numCap = arg + 1;
      return f;
    }
    cat(f1, f2) {
      if (f1.i === 0 || f2.i === 0) {
        this.prog.patch(f1.out, 0);
        this.prog.patch(f2.out, 0);
        return this.fail();
      }
      this.prog.patch(f1.out, f2.i);
      return new Frag(f1.i, f2.out, f1.nullable && f2.nullable);
    }
    alt(f1, f2) {
      if (f1.i === 0) return f2;
      if (f2.i === 0) return f1;
      const f = this.newInst(Inst.ALT);
      const i = this.prog.getInst(f.i);
      i.out = f1.i;
      i.arg = f2.i;
      f.out = this.prog.append(f1.out, f2.out);
      f.nullable = f1.nullable || f2.nullable;
      return f;
    }
    loop(f1, nongreedy) {
      const f = this.newInst(Inst.ALT);
      const i = this.prog.getInst(f.i);
      if (nongreedy) {
        i.arg = f1.i;
        f.out = new PatchList(f.i << 1, f.i << 1);
      } else {
        i.out = f1.i;
        f.out = new PatchList(f.i << 1 | 1, f.i << 1 | 1);
      }
      this.prog.patch(f1.out, f.i);
      return f;
    }
    quest(f1, nongreedy) {
      if (f1.i === 0) return this.nop();
      const f = this.newInst(Inst.ALT);
      const i = this.prog.getInst(f.i);
      if (nongreedy) {
        i.arg = f1.i;
        f.out = new PatchList(f.i << 1, f.i << 1);
      } else {
        i.out = f1.i;
        f.out = new PatchList(f.i << 1 | 1, f.i << 1 | 1);
      }
      f.out = this.prog.append(f.out, f1.out);
      return f;
    }
    star(f1, nongreedy) {
      if (f1.i === 0) return this.nop();
      if (f1.nullable) return this.quest(this.plus(f1, nongreedy), nongreedy);
      return this.loop(f1, nongreedy);
    }
    plus(f1, nongreedy) {
      if (f1.i === 0) return this.fail();
      return new Frag(f1.i, this.loop(f1, nongreedy).out, f1.nullable);
    }
    empty(op) {
      const f = this.newInst(Inst.EMPTY_WIDTH);
      this.prog.getInst(f.i).arg = op;
      f.out = new PatchList(f.i << 1, f.i << 1);
      return f;
    }
    rune(runes, flags) {
      const f = this.newInst(Inst.RUNE);
      f.nullable = false;
      const i = this.prog.getInst(f.i);
      i.runes = runes;
      flags &= RE2Flags.FOLD_CASE;
      if (runes.length !== 1 || Unicode.simpleFold(runes[0]) === runes[0]) flags &= ~RE2Flags.FOLD_CASE;
      i.arg = flags;
      f.out = new PatchList(f.i << 1, f.i << 1);
      if ((flags & RE2Flags.FOLD_CASE) === 0 && runes.length === 1 || runes.length === 2 && runes[0] === runes[1]) i.op = Inst.RUNE1;
      else if (runes.length === 2 && runes[0] === 0 && runes[1] === Unicode.MAX_RUNE) i.op = Inst.RUNE_ANY;
      else if (runes.length === 4 && runes[0] === 0 && runes[1] === Codepoint.CODES["\n"] - 1 && runes[2] === Codepoint.CODES["\n"] + 1 && runes[3] === Unicode.MAX_RUNE) i.op = Inst.RUNE_ANY_NOT_NL;
      return f;
    }
    lookBehind(a, parsedLb) {
      const lb = Math.sign(parsedLb) * (Math.abs(parsedLb) + this.lbOffset);
      const id = this.newInst(Inst.LB_WRITE);
      this.prog.getInst(id.i).arg = lb;
      const any = this.rune(ANY_RUNE, 0);
      const dotStar = this.star(any, true);
      const lbAutomaton = this.cat(dotStar, a);
      this.prog.patch(lbAutomaton.out, id.i);
      const checkId = this.newInst(Inst.LB_CHECK);
      this.prog.getInst(checkId.i).arg = lb;
      this.prog.lbStarts.push(lbAutomaton.i);
      if (Math.abs(lb) > this.prog.numLb) this.prog.numLb = Math.abs(lb);
      checkId.out = new PatchList(checkId.i << 1, checkId.i << 1);
      return checkId;
    }
    compile(re) {
      return RegexpWalker.walk(re, this.walker);
    }
    leaf(re) {
      switch (re.op) {
        case Regexp.Op.NO_MATCH:
          return this.fail();
        case Regexp.Op.EMPTY_MATCH:
          return this.nop();
        case Regexp.Op.LITERAL: {
          if (re.runes.length === 0) return this.nop();
          let f = null;
          for (let r of re.runes) {
            let singleRune = this.runeCache.get(r);
            if (singleRune === void 0) {
              singleRune = new Int32Array([r]);
              this.runeCache.set(r, singleRune);
            }
            const f1 = this.rune(singleRune, re.flags);
            f = f === null ? f1 : this.cat(f, f1);
          }
          return f;
        }
        case Regexp.Op.CHAR_CLASS:
          return this.rune(re.runes, re.flags);
        case Regexp.Op.ANY_CHAR_NOT_NL:
          return this.rune(ANY_RUNE_NOT_NL, 0);
        case Regexp.Op.ANY_CHAR:
          return this.rune(ANY_RUNE, 0);
        case Regexp.Op.BEGIN_LINE:
          return this.empty(Utils.EMPTY_BEGIN_LINE);
        case Regexp.Op.END_LINE:
          return this.empty(Utils.EMPTY_END_LINE);
        case Regexp.Op.BEGIN_TEXT:
          return this.empty(Utils.EMPTY_BEGIN_TEXT);
        case Regexp.Op.END_TEXT:
          return this.empty(Utils.EMPTY_END_TEXT);
        case Regexp.Op.WORD_BOUNDARY:
          return this.empty(Utils.EMPTY_WORD_BOUNDARY);
        case Regexp.Op.NO_WORD_BOUNDARY:
          return this.empty(Utils.EMPTY_NO_WORD_BOUNDARY);
        case Regexp.Op.CONCAT:
        case Regexp.Op.ALTERNATE:
          return this.nop();
        default:
          throw new RE2JSCompileException("regexp: unhandled case in compile");
      }
    }
    enter(re) {
      switch (re.op) {
        case Regexp.Op.PLB:
        case Regexp.Op.NLB:
        case Regexp.Op.STAR:
        case Regexp.Op.PLUS:
        case Regexp.Op.QUEST:
          return { sub: null };
        case Regexp.Op.CAPTURE:
          return {
            bra: this.cap(re.cap << 1),
            sub: null
          };
        case Regexp.Op.CONCAT:
        case Regexp.Op.ALTERNATE:
          return { f: null };
        default:
          throw new RE2JSCompileException("regexp: unhandled case in compile");
      }
    }
    child(re, state, f1) {
      if (re.op === Regexp.Op.CONCAT) state.f = state.f === null ? f1 : this.cat(state.f, f1);
      else if (re.op === Regexp.Op.ALTERNATE) state.f = state.f === null ? f1 : this.alt(state.f, f1);
      else state.sub = f1;
    }
    leave(re, state) {
      switch (re.op) {
        case Regexp.Op.PLB:
        case Regexp.Op.NLB:
          return this.lookBehind(state.sub, re.lb);
        case Regexp.Op.CAPTURE: {
          const ket = this.cap(re.cap << 1 | 1);
          return this.cat(this.cat(state.bra, state.sub), ket);
        }
        case Regexp.Op.STAR:
          return this.star(state.sub, (re.flags & RE2Flags.NON_GREEDY) !== 0);
        case Regexp.Op.PLUS:
          return this.plus(state.sub, (re.flags & RE2Flags.NON_GREEDY) !== 0);
        case Regexp.Op.QUEST:
          return this.quest(state.sub, (re.flags & RE2Flags.NON_GREEDY) !== 0);
        case Regexp.Op.CONCAT:
        case Regexp.Op.ALTERNATE:
          return state.f;
        default:
          throw new RE2JSCompileException("regexp: unhandled case in compile");
      }
    }
  };
  var Simplify = class Simplify2 {
    static simplify(re) {
      if (re === null) return null;
      return RegexpWalker.walk(re, Simplify2.WALKER);
    }
    static WALKER = {
      leaf: (re) => Simplify2.leaf(re),
      enter: (re) => Simplify2.enter(re),
      child: (re, state, result, i) => Simplify2.child(re, state, result, i),
      leave: (re, state) => Simplify2.leave(re, state)
    };
    static leaf(re) {
      if (re.op === Regexp.Op.CHAR_CLASS) {
        if (re.runes === null) return re;
        if (re.runes.length === 0) return new Regexp(Regexp.Op.NO_MATCH);
        if (re.runes.length === 2 && re.runes[0] === 0 && re.runes[1] === Unicode.MAX_RUNE) return new Regexp(Regexp.Op.ANY_CHAR);
        if (re.runes.length === 4 && re.runes[0] === 0 && re.runes[1] === Codepoint.CODES["\n"] - 1 && re.runes[2] === Codepoint.CODES["\n"] + 1 && re.runes[3] === Unicode.MAX_RUNE) return new Regexp(Regexp.Op.ANY_CHAR_NOT_NL);
      }
      return re;
    }
    static enter(re) {
      switch (re.op) {
        case Regexp.Op.PLB:
        case Regexp.Op.NLB:
        case Regexp.Op.CAPTURE:
        case Regexp.Op.STAR:
        case Regexp.Op.PLUS:
        case Regexp.Op.QUEST:
          return { sub: null };
        case Regexp.Op.CONCAT:
        case Regexp.Op.ALTERNATE:
          return {
            subs: [],
            changed: false
          };
        case Regexp.Op.REPEAT:
          if (re.min === 0 && re.max === 0) return { result: new Regexp(Regexp.Op.EMPTY_MATCH) };
          return { sub: null };
        default:
          return { result: re };
      }
    }
    static child(re, state, nsub, i) {
      if (state.subs === void 0) {
        state.sub = nsub;
        return;
      }
      if (nsub !== re.subs[i]) state.changed = true;
      if (re.op === Regexp.Op.CONCAT) {
        if (nsub.op === Regexp.Op.NO_MATCH) {
          state.result = new Regexp(Regexp.Op.NO_MATCH);
          return;
        }
        if (nsub.op === Regexp.Op.EMPTY_MATCH) {
          state.changed = true;
          return;
        }
        if (nsub.op === Regexp.Op.CONCAT) {
          state.changed = true;
          for (let j = 0; j < nsub.subs.length; j++) state.subs.push(nsub.subs[j]);
          return;
        }
      } else {
        if (nsub.op === Regexp.Op.NO_MATCH) {
          state.changed = true;
          return;
        }
        if (nsub.op === Regexp.Op.ALTERNATE) {
          state.changed = true;
          for (let j = 0; j < nsub.subs.length; j++) state.subs.push(nsub.subs[j]);
          return;
        }
      }
      state.subs.push(nsub);
    }
    static leave(re, state) {
      switch (re.op) {
        case Regexp.Op.PLB:
        case Regexp.Op.NLB:
        case Regexp.Op.CAPTURE: {
          const sub = state.sub;
          if (sub !== re.subs[0]) {
            const nre = Regexp.fromRegexp(re);
            nre.runes = /* @__PURE__ */ new Int32Array(0);
            nre.subs = [sub];
            return nre;
          }
          return re;
        }
        case Regexp.Op.CONCAT:
        case Regexp.Op.ALTERNATE:
          if (state.changed) {
            const newSubs = state.subs;
            if (newSubs.length === 0) return new Regexp(re.op === Regexp.Op.CONCAT ? Regexp.Op.EMPTY_MATCH : Regexp.Op.NO_MATCH);
            if (newSubs.length === 1) return newSubs[0];
            const nre = Regexp.fromRegexp(re);
            nre.runes = /* @__PURE__ */ new Int32Array(0);
            nre.subs = newSubs;
            return nre;
          }
          return re;
        case Regexp.Op.STAR:
        case Regexp.Op.PLUS:
        case Regexp.Op.QUEST:
          return Simplify2.simplify1(re.op, re.flags, state.sub, re);
        case Regexp.Op.REPEAT:
          return Simplify2.simplifyRepeat(re, state.sub);
        default:
          return re;
      }
    }
    static simplifyRepeat(re, sub) {
      if (re.max === -1) {
        if (re.min === 0) return Simplify2.simplify1(Regexp.Op.STAR, re.flags, sub, null);
        if (re.min === 1) return Simplify2.simplify1(Regexp.Op.PLUS, re.flags, sub, null);
        const subs = [];
        for (let i = 0; i < re.min - 1; i++) subs.push(sub);
        subs.push(Simplify2.simplify1(Regexp.Op.PLUS, re.flags, sub, null));
        return Simplify2.concat(subs);
      }
      if (re.min === 1 && re.max === 1) return sub;
      let prefixSubs = null;
      if (re.min > 0) {
        prefixSubs = [];
        for (let i = 0; i < re.min; i++) prefixSubs.push(sub);
      }
      if (re.max > re.min) {
        let suffix = Simplify2.simplify1(Regexp.Op.QUEST, re.flags, sub, null);
        for (let i = re.min + 1; i < re.max; i++) suffix = Simplify2.simplify1(Regexp.Op.QUEST, re.flags, Simplify2.concat([sub, suffix]), null);
        if (prefixSubs === null) return suffix;
        prefixSubs.push(suffix);
      }
      if (prefixSubs !== null) return Simplify2.concat(prefixSubs);
      return new Regexp(Regexp.Op.NO_MATCH);
    }
    static concat(subs) {
      const newSubs = [];
      for (let i = 0; i < subs.length; i++) {
        const sub = subs[i];
        if (sub.op === Regexp.Op.NO_MATCH) return new Regexp(Regexp.Op.NO_MATCH);
        if (sub.op === Regexp.Op.EMPTY_MATCH) continue;
        if (sub.op === Regexp.Op.CONCAT) {
          for (let j = 0; j < sub.subs.length; j++) newSubs.push(sub.subs[j]);
          continue;
        }
        newSubs.push(sub);
      }
      if (newSubs.length === 0) return new Regexp(Regexp.Op.EMPTY_MATCH);
      if (newSubs.length === 1) return newSubs[0];
      const nre = new Regexp(Regexp.Op.CONCAT);
      nre.subs = newSubs;
      return nre;
    }
    static simplify1(op, flags, sub, re) {
      if (sub.op === Regexp.Op.EMPTY_MATCH) return sub;
      if (sub.op === Regexp.Op.NO_MATCH) {
        if (op === Regexp.Op.PLUS) return sub;
        return new Regexp(Regexp.Op.EMPTY_MATCH);
      }
      if (op === sub.op && (flags & RE2Flags.NON_GREEDY) === (sub.flags & RE2Flags.NON_GREEDY)) return sub;
      if (re !== null && re.op === op && (re.flags & RE2Flags.NON_GREEDY) === (flags & RE2Flags.NON_GREEDY) && sub === re.subs[0]) return re;
      const nre = new Regexp(op);
      nre.flags = flags;
      nre.subs = [sub];
      return nre;
    }
  };
  var CharGroup = class {
    constructor(sign, cls) {
      this.sign = sign;
      this.cls = cls;
    }
  };
  var code1 = [48, 57];
  var code2 = [
    9,
    10,
    12,
    13,
    32,
    32
  ];
  var code3 = [
    48,
    57,
    65,
    90,
    95,
    95,
    97,
    122
  ];
  var PERL_GROUPS = /* @__PURE__ */ new Map([
    ["\\d", new CharGroup(1, code1)],
    ["\\D", new CharGroup(-1, code1)],
    ["\\s", new CharGroup(1, code2)],
    ["\\S", new CharGroup(-1, code2)],
    ["\\w", new CharGroup(1, code3)],
    ["\\W", new CharGroup(-1, code3)]
  ]);
  var code4 = [
    48,
    57,
    65,
    90,
    97,
    122
  ];
  var code5 = [
    65,
    90,
    97,
    122
  ];
  var code6 = [0, 127];
  var code7 = [
    9,
    9,
    32,
    32
  ];
  var code8 = [
    0,
    31,
    127,
    127
  ];
  var code9 = [48, 57];
  var code10 = [33, 126];
  var code11 = [97, 122];
  var code12 = [32, 126];
  var code13 = [
    33,
    47,
    58,
    64,
    91,
    96,
    123,
    126
  ];
  var code14 = [
    9,
    13,
    32,
    32
  ];
  var code15 = [65, 90];
  var code16 = [
    48,
    57,
    65,
    90,
    95,
    95,
    97,
    122
  ];
  var code17 = [
    48,
    57,
    65,
    70,
    97,
    102
  ];
  var POSIX_GROUPS = /* @__PURE__ */ new Map([
    ["[:alnum:]", new CharGroup(1, code4)],
    ["[:^alnum:]", new CharGroup(-1, code4)],
    ["[:alpha:]", new CharGroup(1, code5)],
    ["[:^alpha:]", new CharGroup(-1, code5)],
    ["[:ascii:]", new CharGroup(1, code6)],
    ["[:^ascii:]", new CharGroup(-1, code6)],
    ["[:blank:]", new CharGroup(1, code7)],
    ["[:^blank:]", new CharGroup(-1, code7)],
    ["[:cntrl:]", new CharGroup(1, code8)],
    ["[:^cntrl:]", new CharGroup(-1, code8)],
    ["[:digit:]", new CharGroup(1, code9)],
    ["[:^digit:]", new CharGroup(-1, code9)],
    ["[:graph:]", new CharGroup(1, code10)],
    ["[:^graph:]", new CharGroup(-1, code10)],
    ["[:lower:]", new CharGroup(1, code11)],
    ["[:^lower:]", new CharGroup(-1, code11)],
    ["[:print:]", new CharGroup(1, code12)],
    ["[:^print:]", new CharGroup(-1, code12)],
    ["[:punct:]", new CharGroup(1, code13)],
    ["[:^punct:]", new CharGroup(-1, code13)],
    ["[:space:]", new CharGroup(1, code14)],
    ["[:^space:]", new CharGroup(-1, code14)],
    ["[:upper:]", new CharGroup(1, code15)],
    ["[:^upper:]", new CharGroup(-1, code15)],
    ["[:word:]", new CharGroup(1, code16)],
    ["[:^word:]", new CharGroup(-1, code16)],
    ["[:xdigit:]", new CharGroup(1, code17)],
    ["[:^xdigit:]", new CharGroup(-1, code17)]
  ]);
  var CharClass = class CharClass2 {
    static charClassToString(r, len) {
      let result = "[";
      for (let i = 0; i < len; i += 2) {
        if (i > 0) result += " ";
        const lo = r[i];
        const hi = r[i + 1];
        if (lo === hi) result += `0x${lo.toString(16)}`;
        else result += `0x${lo.toString(16)}-0x${hi.toString(16)}`;
      }
      result += "]";
      return result;
    }
    static sortRanges(array, len) {
      const n = len >> 1;
      const order = new Array(n);
      for (let i = 0; i < n; i++) order[i] = i;
      order.sort((a, b) => array[2 * a] - array[2 * b] || array[2 * b + 1] - array[2 * a + 1]);
      const sorted = array.slice(0, len);
      for (let i = 0; i < n; i++) {
        array[2 * i] = sorted[2 * order[i]];
        array[2 * i + 1] = sorted[2 * order[i] + 1];
      }
    }
    /**
    * @param {number[]|Int32Array} [r]
    */
    constructor(r = Utils.emptyInts()) {
      this.r = r;
      this.len = r.length;
    }
    toArray() {
      if (this.r instanceof Int32Array) return this.len === this.r.length ? this.r : this.r.subarray(0, this.len);
      return new Int32Array(this.len === this.r.length ? this.r : this.r.slice(0, this.len));
    }
    toGrowableArray() {
      if (Array.isArray(this.r)) {
        this.r.length = this.len;
        return this.r;
      }
      return Array.from(this.r.subarray(0, this.len));
    }
    cleanClass() {
      if (this.len < 4) return this;
      CharClass2.sortRanges(this.r, this.len);
      let w = 2;
      for (let i = 2; i < this.len; i += 2) {
        const lo = this.r[i];
        const hi = this.r[i + 1];
        if (lo <= this.r[w - 1] + 1) {
          if (hi > this.r[w - 1]) this.r[w - 1] = hi;
          continue;
        }
        this.r[w] = lo;
        this.r[w + 1] = hi;
        w += 2;
      }
      this.len = w;
      return this;
    }
    appendLiteral(x, flags) {
      return (flags & RE2Flags.FOLD_CASE) !== 0 ? this.appendFoldedRange(x, x) : this.appendRange(x, x);
    }
    appendRange(lo, hi) {
      if (this.len > 0) {
        for (let i = 2; i <= 4; i += 2) if (this.len >= i) {
          const rlo = this.r[this.len - i];
          const rhi = this.r[this.len - i + 1];
          if (lo <= rhi + 1 && rlo <= hi + 1) {
            if (lo < rlo) this.r[this.len - i] = lo;
            if (hi > rhi) this.r[this.len - i + 1] = hi;
            return this;
          }
        }
      }
      this.r[this.len++] = lo;
      this.r[this.len++] = hi;
      return this;
    }
    appendFoldedRange(lo, hi) {
      if (lo <= Unicode.MIN_FOLD && hi >= Unicode.MAX_FOLD) return this.appendRange(lo, hi);
      if (hi < Unicode.MIN_FOLD || lo > Unicode.MAX_FOLD) return this.appendRange(lo, hi);
      if (lo < Unicode.MIN_FOLD) {
        this.appendRange(lo, Unicode.MIN_FOLD - 1);
        lo = Unicode.MIN_FOLD;
      }
      if (hi > Unicode.MAX_FOLD) {
        this.appendRange(Unicode.MAX_FOLD + 1, hi);
        hi = Unicode.MAX_FOLD;
      }
      for (let c = lo; c <= hi; c++) {
        this.appendRange(c, c);
        for (let f = Unicode.simpleFold(c); f !== c; f = Unicode.simpleFold(f)) this.appendRange(f, f);
      }
      return this;
    }
    appendClass(x) {
      for (let i = 0; i < x.length; i += 2) this.appendRange(x[i], x[i + 1]);
      return this;
    }
    appendFoldedClass(x) {
      for (let i = 0; i < x.length; i += 2) this.appendFoldedRange(x[i], x[i + 1]);
      return this;
    }
    appendNegatedClass(x) {
      let nextLo = 0;
      for (let i = 0; i < x.length; i += 2) {
        const lo = x[i];
        const hi = x[i + 1];
        if (nextLo <= lo - 1) this.appendRange(nextLo, lo - 1);
        nextLo = hi + 1;
      }
      if (nextLo <= Unicode.MAX_RUNE) this.appendRange(nextLo, Unicode.MAX_RUNE);
      return this;
    }
    appendTable(table) {
      for (let i = 0; i < table.length; ++i) {
        const lo = table.getLo(i);
        const hi = table.getHi(i);
        const stride = table.getStride(i);
        if (stride === 1) {
          this.appendRange(lo, hi);
          continue;
        }
        for (let c = lo; c <= hi; c += stride) this.appendRange(c, c);
      }
      return this;
    }
    appendNegatedTable(table) {
      let nextLo = 0;
      for (let i = 0; i < table.length; ++i) {
        const lo = table.getLo(i);
        const hi = table.getHi(i);
        const stride = table.getStride(i);
        if (stride === 1) {
          if (nextLo <= lo - 1) this.appendRange(nextLo, lo - 1);
          nextLo = hi + 1;
          continue;
        }
        for (let c = lo; c <= hi; c += stride) {
          if (nextLo <= c - 1) this.appendRange(nextLo, c - 1);
          nextLo = c + 1;
        }
      }
      if (nextLo <= Unicode.MAX_RUNE) this.appendRange(nextLo, Unicode.MAX_RUNE);
      return this;
    }
    appendTableWithSign(table, sign) {
      return sign < 0 ? this.appendNegatedTable(table) : this.appendTable(table);
    }
    negateClass() {
      let nextLo = 0;
      let w = 0;
      for (let i = 0; i < this.len; i += 2) {
        const lo = this.r[i];
        const hi = this.r[i + 1];
        if (nextLo <= lo - 1) {
          this.r[w] = nextLo;
          this.r[w + 1] = lo - 1;
          w += 2;
        }
        nextLo = hi + 1;
      }
      this.len = w;
      if (nextLo <= Unicode.MAX_RUNE) {
        this.r[this.len++] = nextLo;
        this.r[this.len++] = Unicode.MAX_RUNE;
      }
      return this;
    }
    appendClassWithSign(x, sign) {
      return sign < 0 ? this.appendNegatedClass(x) : this.appendClass(x);
    }
    appendGroup(g, foldCase) {
      let cls = g.cls;
      if (foldCase) cls = new CharClass2().appendFoldedClass(cls).cleanClass().toArray();
      return this.appendClassWithSign(cls, g.sign);
    }
    toString() {
      return CharClass2.charClassToString(this.r, this.len);
    }
  };
  var StringIterator = class {
    constructor(str) {
      this.str = str;
      this.position = 0;
    }
    pos() {
      return this.position;
    }
    rewindTo(pos) {
      this.position = pos;
    }
    more() {
      return this.position < this.str.length;
    }
    peek() {
      return this.str.codePointAt(this.position);
    }
    skip(n) {
      this.position += n;
    }
    skipString(s) {
      this.position += s.length;
    }
    pop() {
      const r = this.str.codePointAt(this.position);
      this.position += Utils.charCount(r);
      return r;
    }
    lookingAt(s) {
      return this.str.startsWith(s, this.position);
    }
    rest() {
      return this.str.substring(this.position);
    }
    from(beforePos) {
      return this.str.substring(beforePos, this.position);
    }
    toString() {
      return this.rest();
    }
  };
  var Parser = class Parser2 {
    static ERR_INTERNAL_ERROR = "regexp/syntax: internal error";
    static ERR_INVALID_CHAR_RANGE = "invalid character class range";
    static ERR_INVALID_ESCAPE = "invalid escape sequence";
    static ERR_INVALID_NAMED_CAPTURE = "invalid named capture";
    static ERR_INVALID_PERL_OP = "invalid or unsupported Perl syntax";
    static ERR_INVALID_REPEAT_OP = "invalid nested repetition operator";
    static ERR_INVALID_REPEAT_SIZE = "invalid repeat count";
    static ERR_MISSING_BRACKET = "missing closing ]";
    static ERR_MISSING_PAREN = "missing closing )";
    static ERR_MISSING_REPEAT_ARGUMENT = "missing argument to repetition operator";
    static ERR_TRAILING_BACKSLASH = "trailing backslash at end of expression";
    static ERR_DUPLICATE_NAMED_CAPTURE = "duplicate capture group name";
    static ERR_UNEXPECTED_PAREN = "unexpected )";
    static ERR_NESTING_DEPTH = "expression nests too deeply";
    static ERR_LARGE = "expression too large";
    static ERR_INVALID_CAPTURE_IN_LOOKBEHIND = "invalid capture in lookbehind";
    static MAX_HEIGHT = 1e3;
    static MAX_SIZE = 1398101;
    static MAX_RUNES = 33554432;
    static ANY_TABLE = new UnicodeRangeTable(new Uint32Array([
      0,
      Unicode.MAX_RUNE,
      1
    ]));
    static ASCII_TABLE = new UnicodeRangeTable(new Uint32Array([
      0,
      127,
      1
    ]));
    static ASCII_FOLD_TABLE = new UnicodeRangeTable(new Uint32Array([
      0,
      127,
      1,
      383,
      383,
      1,
      8490,
      8490,
      1
    ]));
    static unicodeTable(name) {
      if (name === "Any") return {
        tab: Parser2.ANY_TABLE,
        fold: Parser2.ANY_TABLE,
        sign: 1
      };
      if (name === "Ascii") return {
        tab: Parser2.ASCII_TABLE,
        fold: Parser2.ASCII_FOLD_TABLE,
        sign: 1
      };
      if (name === "Assigned") return {
        tab: UnicodeTables.CATEGORIES.get("Cn"),
        fold: UnicodeTables.CATEGORIES.get("Cn"),
        sign: -1
      };
      if (name === "Lc") return {
        tab: UnicodeTables.CATEGORIES.get("LC"),
        fold: UnicodeTables.FOLD_CATEGORIES.get("LC"),
        sign: 1
      };
      if (UnicodeTables.CATEGORIES.has(name)) return {
        tab: UnicodeTables.CATEGORIES.get(name),
        fold: UnicodeTables.FOLD_CATEGORIES.get(name),
        sign: 1
      };
      if (UnicodeTables.SCRIPTS.has(name)) return {
        tab: UnicodeTables.SCRIPTS.get(name),
        fold: UnicodeTables.FOLD_SCRIPT.get(name),
        sign: 1
      };
      return null;
    }
    static minFoldRune(r) {
      if (r < Unicode.MIN_FOLD || r > Unicode.MAX_FOLD) return r;
      let min = r;
      const r0 = r;
      for (r = Unicode.simpleFold(r); r !== r0; r = Unicode.simpleFold(r)) if (min > r) min = r;
      return min;
    }
    static leadingRegexp(re) {
      if (re.op === Regexp.Op.EMPTY_MATCH) return null;
      if (re.op === Regexp.Op.CONCAT && re.subs.length > 0) {
        const sub = re.subs[0];
        if (sub.op === Regexp.Op.EMPTY_MATCH) return null;
        return sub;
      }
      return re;
    }
    static literalRegexp(s, flags) {
      const re = new Regexp(Regexp.Op.LITERAL);
      re.flags = flags;
      re.runes = Utils.stringToRunes(s);
      return re;
    }
    /**
    * Parse regular expression pattern {@code pattern} with mode flags {@code flags}.
    * @param {string} pattern
    * @param {number} flags
    */
    static parse(pattern, flags) {
      return new Parser2(pattern, flags).parseInternal();
    }
    static parseRepeat(t2) {
      const start = t2.pos();
      if (!t2.more() || !t2.lookingAt("{")) return -1;
      t2.skip(1);
      const min = Parser2.parseInt(t2);
      if (min === -1) return -1;
      if (!t2.more()) return -1;
      let max;
      if (!t2.lookingAt(",")) max = min;
      else {
        t2.skip(1);
        if (!t2.more()) return -1;
        if (t2.lookingAt("}")) max = -1;
        else if ((max = Parser2.parseInt(t2)) === -1) return -1;
      }
      if (!t2.more() || !t2.lookingAt("}")) return -1;
      t2.skip(1);
      if (min < 0 || min > 1e3 || max === -2 || max > 1e3 || max >= 0 && min > max) throw new RE2JSSyntaxException(Parser2.ERR_INVALID_REPEAT_SIZE, t2.from(start));
      return min << 16 | max & Unicode.MAX_BMP;
    }
    static isValidCaptureName(name) {
      if (name.length === 0) return false;
      for (let i = 0; i < name.length; i++) {
        const c = name.codePointAt(i);
        if (c !== Codepoint.CODES["_"] && !Utils.isalnum(c)) return false;
      }
      return true;
    }
    static parseInt(t2) {
      const start = t2.pos();
      while (t2.more() && t2.peek() >= Codepoint.CODES["0"] && t2.peek() <= Codepoint.CODES["9"]) t2.skip(1);
      const n = t2.from(start);
      if (n.length === 0 || n.length > 1 && n.codePointAt(0) === Codepoint.CODES["0"]) return -1;
      if (n.length > 8) return -2;
      return parseInt(n, 10);
    }
    static isCharClass(re) {
      return re.op === Regexp.Op.LITERAL && re.runes.length === 1 || re.op === Regexp.Op.CHAR_CLASS || re.op === Regexp.Op.ANY_CHAR_NOT_NL || re.op === Regexp.Op.ANY_CHAR;
    }
    static matchRune(re, r) {
      switch (re.op) {
        case Regexp.Op.LITERAL:
          return re.runes.length === 1 && re.runes[0] === r;
        case Regexp.Op.CHAR_CLASS:
          for (let i = 0; i < re.runes.length; i += 2) if (re.runes[i] <= r && r <= re.runes[i + 1]) return true;
          return false;
        case Regexp.Op.ANY_CHAR_NOT_NL:
          return r !== Codepoint.CODES["\n"];
        case Regexp.Op.ANY_CHAR:
          return true;
      }
      return false;
    }
    static mergeCharClass(dst, src) {
      switch (dst.op) {
        case Regexp.Op.ANY_CHAR:
          break;
        case Regexp.Op.ANY_CHAR_NOT_NL:
          if (Parser2.matchRune(src, Codepoint.CODES["\n"])) dst.op = Regexp.Op.ANY_CHAR;
          break;
        case Regexp.Op.CHAR_CLASS: {
          const cc = new CharClass(Array.isArray(dst.runes) ? dst.runes : Array.from(dst.runes));
          if (src.op === Regexp.Op.LITERAL) cc.appendLiteral(src.runes[0], src.flags);
          else cc.appendClass(src.runes);
          dst.runes = cc.toGrowableArray();
          break;
        }
        case Regexp.Op.LITERAL:
          if (src.runes[0] === dst.runes[0] && src.flags === dst.flags) break;
          dst.op = Regexp.Op.CHAR_CLASS;
          dst.runes = new CharClass().appendLiteral(dst.runes[0], dst.flags).appendLiteral(src.runes[0], src.flags).toGrowableArray();
      }
    }
    static parseEscape(t2) {
      const startPos = t2.pos();
      t2.skip(1);
      if (!t2.more()) throw new RE2JSSyntaxException(Parser2.ERR_TRAILING_BACKSLASH);
      let c = t2.pop();
      bigswitch: switch (c) {
        case Codepoint.CODES["1"]:
        case Codepoint.CODES["2"]:
        case Codepoint.CODES["3"]:
        case Codepoint.CODES["4"]:
        case Codepoint.CODES["5"]:
        case Codepoint.CODES["6"]:
        case Codepoint.CODES["7"]:
          if (!t2.more() || t2.peek() < Codepoint.CODES["0"] || t2.peek() > Codepoint.CODES["7"]) break;
        case Codepoint.CODES["0"]: {
          let r = c - Codepoint.CODES["0"];
          for (let i = 1; i < 3; i++) {
            if (!t2.more() || t2.peek() < Codepoint.CODES["0"] || t2.peek() > Codepoint.CODES["7"]) break;
            r = r * 8 + t2.peek() - Codepoint.CODES["0"];
            t2.skip(1);
          }
          return r;
        }
        case Codepoint.CODES["x"]: {
          if (!t2.more()) break;
          c = t2.pop();
          if (c === Codepoint.CODES["{"]) {
            let nhex = 0;
            let r = 0;
            while (true) {
              if (!t2.more()) break bigswitch;
              c = t2.pop();
              if (c === Codepoint.CODES["}"]) break;
              const v = Utils.unhex(c);
              if (v < 0) break bigswitch;
              r = r * 16 + v;
              if (r > Unicode.MAX_RUNE) break bigswitch;
              nhex++;
            }
            if (nhex === 0) break bigswitch;
            return r;
          }
          const x = Utils.unhex(c);
          if (!t2.more()) break;
          c = t2.pop();
          const y = Utils.unhex(c);
          if (x < 0 || y < 0) break;
          return x * 16 + y;
        }
        case Codepoint.CODES["a"]:
          return Codepoint.CODES["\x07"];
        case Codepoint.CODES["f"]:
          return Codepoint.CODES["\f"];
        case Codepoint.CODES["n"]:
          return Codepoint.CODES["\n"];
        case Codepoint.CODES["r"]:
          return Codepoint.CODES["\r"];
        case Codepoint.CODES["t"]:
          return Codepoint.CODES["	"];
        case Codepoint.CODES["v"]:
          return Codepoint.CODES["\v"];
        default:
          if (c <= Unicode.MAX_ASCII && !Utils.isalnum(c)) return c;
      }
      throw new RE2JSSyntaxException(Parser2.ERR_INVALID_ESCAPE, t2.from(startPos));
    }
    static parseClassChar(t2, wholeClassPos) {
      if (!t2.more()) throw new RE2JSSyntaxException(Parser2.ERR_MISSING_BRACKET, t2.from(wholeClassPos));
      if (t2.lookingAt("\\")) return Parser2.parseEscape(t2);
      return t2.pop();
    }
    static hasCapture(re) {
      if (re === null) return false;
      if (re.op === Regexp.Op.CAPTURE) return true;
      if (re.subs) {
        for (let sub of re.subs) if (Parser2.hasCapture(sub)) return true;
      }
      return false;
    }
    constructor(wholeRegexp, flags = 0) {
      this.wholeRegexp = wholeRegexp;
      this.flags = flags;
      this.numCap = 0;
      this.namedGroups = /* @__PURE__ */ Object.create(null);
      this.stack = [];
      this.free = null;
      this.numRegexp = 0;
      this.numRunes = 0;
      this.repeats = 0;
      this.height = null;
      this.size = null;
      this.nlb = 0;
    }
    newRegexp(op) {
      let re = this.free;
      if (re !== null && re.subs !== null && re.subs.length > 0) {
        this.free = re.subs[0];
        re.reinit();
        re.op = op;
      } else {
        re = new Regexp(op);
        this.numRegexp += 1;
      }
      return re;
    }
    reuse(re) {
      if (this.height !== null && this.height.has(re)) this.height.delete(re);
      if (re.subs !== null && re.subs.length > 0) re.subs[0] = this.free;
      this.free = re;
    }
    checkLimits(re) {
      if (this.numRunes > Parser2.MAX_RUNES) throw new RE2JSSyntaxException(Parser2.ERR_LARGE);
      this.checkSize(re);
      this.checkHeight(re);
    }
    checkSize(re) {
      if (this.size === null) {
        if (this.repeats === 0) this.repeats = 1;
        if (re.op === Regexp.Op.REPEAT) {
          let n = re.max;
          if (n === -1) n = re.min;
          if (n <= 0) n = 1;
          if (n > Math.floor(Parser2.MAX_SIZE / this.repeats)) this.repeats = Parser2.MAX_SIZE;
          else this.repeats *= n;
        }
        if (this.numRegexp < Math.floor(Parser2.MAX_SIZE / this.repeats)) return;
        this.size = /* @__PURE__ */ new Map();
        for (let reEx of this.stack) this.checkSize(reEx);
      }
      if (this.calcSize(re, true) > Parser2.MAX_SIZE) throw new RE2JSSyntaxException(Parser2.ERR_LARGE);
    }
    calcSize(re, force = false) {
      if (!force && this.size !== null) {
        if (this.size.has(re)) return this.size.get(re);
      }
      let size = 0;
      switch (re.op) {
        case Regexp.Op.LITERAL:
          size = re.runes.length;
          break;
        case Regexp.Op.PLB:
        case Regexp.Op.NLB:
        case Regexp.Op.CAPTURE:
        case Regexp.Op.STAR:
          size = 2 + this.calcSize(re.subs[0]);
          break;
        case Regexp.Op.PLUS:
        case Regexp.Op.QUEST:
          size = 1 + this.calcSize(re.subs[0]);
          break;
        case Regexp.Op.CONCAT:
          for (let sub of re.subs) size = size + this.calcSize(sub);
          break;
        case Regexp.Op.ALTERNATE:
          for (let sub of re.subs) size = size + this.calcSize(sub);
          if (re.subs.length > 1) size = size + re.subs.length - 1;
          break;
        case Regexp.Op.REPEAT: {
          let sub = this.calcSize(re.subs[0]);
          if (re.max === -1) {
            if (re.min === 0) size = 2 + sub;
            else size = 1 + re.min * sub;
            break;
          }
          size = re.max * sub + (re.max - re.min);
          break;
        }
      }
      size = Math.max(1, size);
      if (this.size === null) this.size = /* @__PURE__ */ new Map();
      this.size.set(re, size);
      return size;
    }
    checkHeight(re) {
      if (this.numRegexp < Parser2.MAX_HEIGHT) return;
      if (this.height === null) {
        this.height = /* @__PURE__ */ new Map();
        for (let reEx of this.stack) this.checkHeight(reEx);
      }
      if (this.calcHeight(re, true) > Parser2.MAX_HEIGHT) throw new RE2JSSyntaxException(Parser2.ERR_NESTING_DEPTH);
    }
    calcHeight(re, force = false) {
      if (!force && this.height !== null) {
        if (this.height.has(re)) return this.height.get(re);
      }
      let h2 = 1;
      for (let sub of re.subs) {
        const hsub = this.calcHeight(sub);
        if (h2 < 1 + hsub) h2 = 1 + hsub;
      }
      if (this.height === null) this.height = /* @__PURE__ */ new Map();
      this.height.set(re, h2);
      return h2;
    }
    pop() {
      return this.stack.pop();
    }
    popToPseudo() {
      const n = this.stack.length;
      let i = n;
      while (i > 0 && !Regexp.isPseudoOp(this.stack[i - 1].op)) i--;
      return this.stack.splice(i, n - i);
    }
    push(re) {
      this.numRunes += re.runes.length;
      if (re.op === Regexp.Op.CHAR_CLASS && re.runes.length === 2 && re.runes[0] === re.runes[1]) {
        if (this.maybeConcat(re.runes[0], this.flags & ~RE2Flags.FOLD_CASE)) return null;
        re.op = Regexp.Op.LITERAL;
        re.runes = [re.runes[0]];
        re.flags = this.flags & ~RE2Flags.FOLD_CASE;
      } else if (re.op === Regexp.Op.CHAR_CLASS && re.runes.length === 4 && re.runes[0] === re.runes[1] && re.runes[2] === re.runes[3] && Unicode.simpleFold(re.runes[0]) === re.runes[2] && Unicode.simpleFold(re.runes[2]) === re.runes[0] || re.op === Regexp.Op.CHAR_CLASS && re.runes.length === 2 && re.runes[0] + 1 === re.runes[1] && Unicode.simpleFold(re.runes[0]) === re.runes[1] && Unicode.simpleFold(re.runes[1]) === re.runes[0]) {
        if (this.maybeConcat(re.runes[0], this.flags | RE2Flags.FOLD_CASE)) return null;
        re.op = Regexp.Op.LITERAL;
        re.runes = [re.runes[0]];
        re.flags = this.flags | RE2Flags.FOLD_CASE;
      } else this.maybeConcat(-1, 0);
      this.stack.push(re);
      this.checkLimits(re);
      return re;
    }
    maybeConcat(r, flags) {
      const n = this.stack.length;
      if (n < 2) return false;
      const re1 = this.stack[n - 1];
      const re2 = this.stack[n - 2];
      if (re1.op !== Regexp.Op.LITERAL || re2.op !== Regexp.Op.LITERAL || (re1.flags & RE2Flags.FOLD_CASE) !== (re2.flags & RE2Flags.FOLD_CASE)) return false;
      if (!Array.isArray(re2.runes)) re2.runes = Array.from(re2.runes);
      for (let i = 0; i < re1.runes.length; i++) re2.runes.push(re1.runes[i]);
      if (r >= 0) {
        re1.runes = [r];
        re1.flags = flags;
        return true;
      }
      this.pop();
      this.reuse(re1);
      return false;
    }
    newLiteral(r, flags) {
      const re = this.newRegexp(Regexp.Op.LITERAL);
      re.flags = flags;
      if ((flags & RE2Flags.FOLD_CASE) !== 0) r = Parser2.minFoldRune(r);
      re.runes = [r];
      return re;
    }
    literal(r) {
      this.push(this.newLiteral(r, this.flags));
    }
    op(op) {
      const re = this.newRegexp(op);
      re.flags = this.flags;
      return this.push(re);
    }
    repeat(op, min, max, beforePos, t2, lastRepeatPos) {
      let flags = this.flags;
      if ((flags & RE2Flags.PERL_X) !== 0) {
        if (t2.more() && t2.lookingAt("?")) {
          t2.skip(1);
          flags ^= RE2Flags.NON_GREEDY;
        }
        if (lastRepeatPos !== -1) throw new RE2JSSyntaxException(Parser2.ERR_INVALID_REPEAT_OP, t2.from(lastRepeatPos));
      }
      const n = this.stack.length;
      if (n === 0) throw new RE2JSSyntaxException(Parser2.ERR_MISSING_REPEAT_ARGUMENT, t2.from(beforePos));
      const sub = this.stack[n - 1];
      if (Regexp.isPseudoOp(sub.op)) throw new RE2JSSyntaxException(Parser2.ERR_MISSING_REPEAT_ARGUMENT, t2.from(beforePos));
      const re = this.newRegexp(op);
      re.min = min;
      re.max = max;
      re.flags = flags;
      re.subs = [sub];
      this.stack[n - 1] = re;
      this.checkLimits(re);
      if (op === Regexp.Op.REPEAT && (min >= 2 || max >= 2) && !this.repeatIsValid(re, 1e3)) throw new RE2JSSyntaxException(Parser2.ERR_INVALID_REPEAT_SIZE, t2.from(beforePos));
    }
    repeatIsValid(re, n) {
      if (re.op === Regexp.Op.REPEAT) {
        let m = re.max;
        if (m === 0) return true;
        if (m < 0) m = re.min;
        if (m > n) return false;
        if (m > 0) n = Math.trunc(n / m);
      }
      for (let sub of re.subs) if (!this.repeatIsValid(sub, n)) return false;
      return true;
    }
    concat() {
      this.maybeConcat(-1, 0);
      const subs = this.popToPseudo();
      if (subs.length === 0) return this.push(this.newRegexp(Regexp.Op.EMPTY_MATCH));
      return this.push(this.collapse(subs, Regexp.Op.CONCAT));
    }
    alternate() {
      const subs = this.popToPseudo();
      if (subs.length > 0) this.cleanAlt(subs[subs.length - 1]);
      if (subs.length === 0) return this.push(this.newRegexp(Regexp.Op.NO_MATCH));
      return this.push(this.collapse(subs, Regexp.Op.ALTERNATE));
    }
    cleanAlt(re) {
      if (re.op === Regexp.Op.CHAR_CLASS) {
        re.runes = new CharClass(Array.from(re.runes)).cleanClass().toArray();
        if (re.runes.length === 2 && re.runes[0] === 0 && re.runes[1] === Unicode.MAX_RUNE) {
          re.runes = /* @__PURE__ */ new Int32Array(0);
          re.op = Regexp.Op.ANY_CHAR;
        } else if (re.runes.length === 4 && re.runes[0] === 0 && re.runes[1] === Codepoint.CODES["\n"] - 1 && re.runes[2] === Codepoint.CODES["\n"] + 1 && re.runes[3] === Unicode.MAX_RUNE) {
          re.runes = /* @__PURE__ */ new Int32Array(0);
          re.op = Regexp.Op.ANY_CHAR_NOT_NL;
        }
      }
    }
    collapse(subs, op) {
      if (subs.length === 1) return subs[0];
      let len = 0;
      for (let sub of subs) len += sub.op === op ? sub.subs.length : 1;
      let newsubs = new Array(len).fill(null);
      let i = 0;
      for (let sub of subs) if (sub.op === op) {
        for (let j = 0; j < sub.subs.length; j++) newsubs[i++] = sub.subs[j];
        this.reuse(sub);
      } else newsubs[i++] = sub;
      let re = this.newRegexp(op);
      re.subs = newsubs;
      if (op === Regexp.Op.ALTERNATE) {
        re.subs = this.factor(re.subs);
        if (re.subs.length === 1) {
          const old = re;
          re = re.subs[0];
          this.reuse(old);
        }
      }
      return re;
    }
    factor(array) {
      if (array.length < 2) return array;
      let s = 0;
      let lensub = array.length;
      let lenout = 0;
      let str = null;
      let strlen = 0;
      let strflags = 0;
      let start = 0;
      for (let i = 0; i <= lensub; i++) {
        let istr = null;
        let istrlen = 0;
        let iflags = 0;
        if (i < lensub) {
          let re = array[s + i];
          if (re.op === Regexp.Op.CONCAT && re.subs.length > 0) re = re.subs[0];
          if (re.op === Regexp.Op.LITERAL) {
            istr = re.runes;
            istrlen = re.runes.length;
            iflags = re.flags & RE2Flags.FOLD_CASE;
          }
          if (iflags === strflags) {
            let same = 0;
            while (same < strlen && same < istrlen && str[same] === istr[same]) same++;
            if (same > 0) {
              strlen = same;
              continue;
            }
          }
        }
        if (i === start) {
        } else if (i === start + 1) array[lenout++] = array[s + start];
        else {
          const prefix = this.newRegexp(Regexp.Op.LITERAL);
          prefix.flags = strflags;
          prefix.runes = str.slice(0, strlen);
          for (let j = start; j < i; j++) {
            array[s + j] = this.removeLeadingString(array[s + j], strlen);
            this.checkLimits(array[s + j]);
          }
          const suffix = this.collapse(array.slice(s + start, s + i), Regexp.Op.ALTERNATE);
          const re = this.newRegexp(Regexp.Op.CONCAT);
          re.subs = [prefix, suffix];
          array[lenout++] = re;
        }
        start = i;
        str = istr;
        strlen = istrlen;
        strflags = iflags;
      }
      lensub = lenout;
      s = 0;
      start = 0;
      lenout = 0;
      let first = null;
      for (let i = 0; i <= lensub; i++) {
        let ifirst = null;
        if (i < lensub) {
          ifirst = Parser2.leadingRegexp(array[s + i]);
          if (first !== null && first.equals(ifirst) && (Parser2.isCharClass(first) || first.op === Regexp.Op.REPEAT && first.min === first.max && Parser2.isCharClass(first.subs[0]))) continue;
        }
        if (i === start) {
        } else if (i === start + 1) array[lenout++] = array[s + start];
        else {
          const prefix = first;
          for (let j = start; j < i; j++) {
            const reuse = j !== start;
            array[s + j] = this.removeLeadingRegexp(array[s + j], reuse);
            this.checkLimits(array[s + j]);
          }
          const suffix = this.collapse(array.slice(s + start, s + i), Regexp.Op.ALTERNATE);
          const re = this.newRegexp(Regexp.Op.CONCAT);
          re.subs = [prefix, suffix];
          array[lenout++] = re;
        }
        start = i;
        first = ifirst;
      }
      lensub = lenout;
      s = 0;
      start = 0;
      lenout = 0;
      for (let i = 0; i <= lensub; i++) {
        if (i < lensub && Parser2.isCharClass(array[s + i])) continue;
        if (i === start) {
        } else if (i === start + 1) array[lenout++] = array[s + start];
        else {
          let max = start;
          for (let j = start + 1; j < i; j++) {
            const subMax = array[s + max];
            const subJ = array[s + j];
            if (subMax.op < subJ.op || subMax.op === subJ.op && (subMax.runes !== null ? subMax.runes.length : 0) < (subJ.runes !== null ? subJ.runes.length : 0)) max = j;
          }
          const tmp = array[s + start];
          array[s + start] = array[s + max];
          array[s + max] = tmp;
          for (let j = start + 1; j < i; j++) {
            Parser2.mergeCharClass(array[s + start], array[s + j]);
            this.reuse(array[s + j]);
          }
          this.cleanAlt(array[s + start]);
          array[lenout++] = array[s + start];
        }
        if (i < lensub) array[lenout++] = array[s + i];
        start = i + 1;
      }
      lensub = lenout;
      s = 0;
      start = 0;
      lenout = 0;
      for (let i = 0; i < lensub; ++i) {
        if (i + 1 < lensub && array[s + i].op === Regexp.Op.EMPTY_MATCH && array[s + i + 1].op === Regexp.Op.EMPTY_MATCH) continue;
        array[lenout++] = array[s + i];
      }
      lensub = lenout;
      s = 0;
      return array.slice(s, lensub);
    }
    removeLeadingString(re, n) {
      if (re.op === Regexp.Op.CONCAT && re.subs.length > 0) {
        const sub = this.removeLeadingString(re.subs[0], n);
        re.subs[0] = sub;
        if (sub.op === Regexp.Op.EMPTY_MATCH) {
          this.reuse(sub);
          switch (re.subs.length) {
            case 0:
            case 1:
              re.op = Regexp.Op.EMPTY_MATCH;
              re.subs = Regexp.emptySubs();
              break;
            case 2: {
              const old = re;
              re = re.subs[1];
              this.reuse(old);
              break;
            }
            default:
              re.subs = re.subs.slice(1, re.subs.length);
          }
        }
        return re;
      }
      if (re.op === Regexp.Op.LITERAL) {
        re.runes = re.runes.slice(n, re.runes.length);
        if (re.runes.length === 0) re.op = Regexp.Op.EMPTY_MATCH;
      }
      return re;
    }
    removeLeadingRegexp(re, reuse) {
      if (re.op === Regexp.Op.CONCAT && re.subs.length > 0) {
        if (reuse) this.reuse(re.subs[0]);
        re.subs = re.subs.slice(1, re.subs.length);
        switch (re.subs.length) {
          case 0:
            re.op = Regexp.Op.EMPTY_MATCH;
            re.subs = Regexp.emptySubs();
            break;
          case 1: {
            const old = re;
            re = re.subs[0];
            this.reuse(old);
            break;
          }
        }
        return re;
      }
      if (reuse) this.reuse(re);
      return this.newRegexp(Regexp.Op.EMPTY_MATCH);
    }
    parseInternal() {
      if ((this.flags & RE2Flags.LITERAL) !== 0) return Parser2.literalRegexp(this.wholeRegexp, this.flags);
      let lastRepeatPos = -1;
      let min = -1;
      let max = -1;
      const t2 = new StringIterator(this.wholeRegexp);
      while (t2.more()) {
        let repeatPos = -1;
        bigswitch: switch (t2.peek()) {
          case Codepoint.CODES["("]:
            if ((this.flags & RE2Flags.LOOKBEHIND) !== 0) {
              if (t2.lookingAt("(?<=")) {
                this.parsePosLookBehind();
                t2.skip(4);
                break;
              }
              if (t2.lookingAt("(?<!")) {
                this.parseNegLookBehind();
                t2.skip(4);
                break;
              }
            }
            if ((this.flags & RE2Flags.PERL_X) !== 0 && t2.lookingAt("(?")) {
              this.parsePerlFlags(t2);
              break;
            }
            this.op(Regexp.Op.LEFT_PAREN).cap = ++this.numCap;
            t2.skip(1);
            break;
          case Codepoint.CODES["|"]:
            this.parseVerticalBar();
            t2.skip(1);
            break;
          case Codepoint.CODES[")"]:
            this.parseRightParen();
            t2.skip(1);
            break;
          case Codepoint.CODES["^"]:
            if ((this.flags & RE2Flags.ONE_LINE) !== 0) this.op(Regexp.Op.BEGIN_TEXT);
            else this.op(Regexp.Op.BEGIN_LINE);
            t2.skip(1);
            break;
          case Codepoint.CODES["$"]:
            if ((this.flags & RE2Flags.ONE_LINE) !== 0) this.op(Regexp.Op.END_TEXT).flags |= RE2Flags.WAS_DOLLAR;
            else this.op(Regexp.Op.END_LINE);
            t2.skip(1);
            break;
          case Codepoint.CODES["."]:
            if ((this.flags & RE2Flags.DOT_NL) !== 0) this.op(Regexp.Op.ANY_CHAR);
            else this.op(Regexp.Op.ANY_CHAR_NOT_NL);
            t2.skip(1);
            break;
          case Codepoint.CODES["["]:
            this.parseClass(t2);
            break;
          case Codepoint.CODES["*"]:
          case Codepoint.CODES["+"]:
          case Codepoint.CODES["?"]: {
            repeatPos = t2.pos();
            let op = null;
            switch (t2.pop()) {
              case Codepoint.CODES["*"]:
                op = Regexp.Op.STAR;
                break;
              case Codepoint.CODES["+"]:
                op = Regexp.Op.PLUS;
                break;
              case Codepoint.CODES["?"]:
                op = Regexp.Op.QUEST;
            }
            this.repeat(op, min, max, repeatPos, t2, lastRepeatPos);
            break;
          }
          case Codepoint.CODES["{"]: {
            const before = t2.pos();
            const minMax = Parser2.parseRepeat(t2);
            if (minMax < 0) {
              t2.rewindTo(before);
              this.literal(t2.pop());
              break;
            }
            repeatPos = before;
            min = minMax >> 16;
            max = (minMax & Unicode.MAX_BMP) << 16 >> 16;
            this.repeat(Regexp.Op.REPEAT, min, max, repeatPos, t2, lastRepeatPos);
            break;
          }
          case Codepoint.CODES["\\"]: {
            const savedPos = t2.pos();
            t2.skip(1);
            if ((this.flags & RE2Flags.PERL_X) !== 0 && t2.more()) switch (t2.pop()) {
              case Codepoint.CODES["A"]:
                this.op(Regexp.Op.BEGIN_TEXT);
                break bigswitch;
              case Codepoint.CODES["b"]:
                this.op(Regexp.Op.WORD_BOUNDARY);
                break bigswitch;
              case Codepoint.CODES["B"]:
                this.op(Regexp.Op.NO_WORD_BOUNDARY);
                break bigswitch;
              case Codepoint.CODES["C"]:
                throw new RE2JSSyntaxException(Parser2.ERR_INVALID_ESCAPE, "\\C");
              case Codepoint.CODES["Q"]: {
                let lit = t2.rest();
                const i = lit.indexOf("\\E");
                if (i >= 0) {
                  lit = lit.substring(0, i);
                  t2.skipString(lit);
                  t2.skipString("\\E");
                } else t2.skipString(lit);
                let j = 0;
                while (j < lit.length) {
                  const codepoint = lit.codePointAt(j);
                  this.literal(codepoint);
                  j += Utils.charCount(codepoint);
                }
                break bigswitch;
              }
              case Codepoint.CODES["z"]:
                this.op(Regexp.Op.END_TEXT);
                break bigswitch;
              default:
                t2.rewindTo(savedPos);
            }
            else t2.rewindTo(savedPos);
            const re = this.newRegexp(Regexp.Op.CHAR_CLASS);
            re.flags = this.flags;
            if (t2.lookingAt("\\p") || t2.lookingAt("\\P")) {
              const cc2 = new CharClass();
              if (this.parseUnicodeClass(t2, cc2)) {
                re.runes = cc2.toArray();
                this.push(re);
                break bigswitch;
              }
            }
            const cc = new CharClass();
            if (this.parsePerlClassEscape(t2, cc)) {
              re.runes = cc.toArray();
              this.push(re);
              break bigswitch;
            }
            t2.rewindTo(savedPos);
            this.reuse(re);
            this.literal(Parser2.parseEscape(t2));
            break;
          }
          default:
            this.literal(t2.pop());
        }
        lastRepeatPos = repeatPos;
      }
      this.concat();
      if (this.swapVerticalBar()) this.pop();
      this.alternate();
      if (this.stack.length !== 1) throw new RE2JSSyntaxException(Parser2.ERR_MISSING_PAREN, this.wholeRegexp);
      this.stack[0].namedGroups = this.namedGroups;
      return this.stack[0];
    }
    parsePerlFlags(t2) {
      const startPos = t2.pos();
      const s = t2.rest();
      if (s.startsWith("(?P<") || s.startsWith("(?<")) {
        const begin = s.charAt(2) === "P" ? 4 : 3;
        const end = s.indexOf(">");
        if (end < 0) throw new RE2JSSyntaxException(Parser2.ERR_INVALID_NAMED_CAPTURE, s);
        const name = s.substring(begin, end);
        t2.skipString(name);
        t2.skip(begin + 1);
        if (!Parser2.isValidCaptureName(name)) throw new RE2JSSyntaxException(Parser2.ERR_INVALID_NAMED_CAPTURE, s.substring(0, end + 1));
        const re = this.op(Regexp.Op.LEFT_PAREN);
        re.cap = ++this.numCap;
        if (this.namedGroups[name]) throw new RE2JSSyntaxException(Parser2.ERR_DUPLICATE_NAMED_CAPTURE, name);
        this.namedGroups[name] = this.numCap;
        re.name = name;
        return;
      }
      t2.skip(2);
      let flags = this.flags;
      let sign = 1;
      let sawFlag = false;
      loop: while (t2.more()) {
        const c = t2.pop();
        switch (c) {
          case Codepoint.CODES["i"]:
            flags |= RE2Flags.FOLD_CASE;
            sawFlag = true;
            break;
          case Codepoint.CODES["m"]:
            flags &= ~RE2Flags.ONE_LINE;
            sawFlag = true;
            break;
          case Codepoint.CODES["s"]:
            flags |= RE2Flags.DOT_NL;
            sawFlag = true;
            break;
          case Codepoint.CODES["U"]:
            flags |= RE2Flags.NON_GREEDY;
            sawFlag = true;
            break;
          case Codepoint.CODES["-"]:
            if (sign < 0) break loop;
            sign = -1;
            flags = ~flags;
            sawFlag = false;
            break;
          case Codepoint.CODES[":"]:
          case Codepoint.CODES[")"]:
            if (sign < 0) {
              if (!sawFlag) break loop;
              flags = ~flags;
            }
            if (c === Codepoint.CODES[":"]) this.op(Regexp.Op.LEFT_PAREN);
            this.flags = flags;
            return;
          default:
            break loop;
        }
      }
      throw new RE2JSSyntaxException(Parser2.ERR_INVALID_PERL_OP, t2.from(startPos));
    }
    parsePosLookBehind() {
      const re = this.newRegexp(Regexp.Op.LEFT_PAREN);
      re.flags = this.flags;
      re.lb = ++this.nlb;
      return this.push(re);
    }
    parseNegLookBehind() {
      const re = this.newRegexp(Regexp.Op.LEFT_PAREN);
      re.flags = this.flags;
      re.lb = -++this.nlb;
      return this.push(re);
    }
    parseVerticalBar() {
      this.concat();
      if (!this.swapVerticalBar()) this.op(Regexp.Op.VERTICAL_BAR);
    }
    swapVerticalBar() {
      const n = this.stack.length;
      if (n >= 3 && this.stack[n - 2].op === Regexp.Op.VERTICAL_BAR && Parser2.isCharClass(this.stack[n - 1]) && Parser2.isCharClass(this.stack[n - 3])) {
        let re1 = this.stack[n - 1];
        let re3 = this.stack[n - 3];
        if (re1.op > re3.op) {
          const tmp = re3;
          re3 = re1;
          re1 = tmp;
          this.stack[n - 3] = re3;
        }
        Parser2.mergeCharClass(re3, re1);
        this.reuse(re1);
        this.pop();
        return true;
      }
      if (n >= 2) {
        const re1 = this.stack[n - 1];
        const re2 = this.stack[n - 2];
        if (re2.op === Regexp.Op.VERTICAL_BAR) {
          if (n >= 3) this.cleanAlt(this.stack[n - 3]);
          this.stack[n - 2] = re1;
          this.stack[n - 1] = re2;
          return true;
        }
      }
      return false;
    }
    parseRightParen() {
      this.concat();
      if (this.swapVerticalBar()) this.pop();
      this.alternate();
      if (this.stack.length < 2) throw new RE2JSSyntaxException(Parser2.ERR_UNEXPECTED_PAREN, this.wholeRegexp);
      const re1 = this.pop();
      const re2 = this.pop();
      if (re2.op !== Regexp.Op.LEFT_PAREN) throw new RE2JSSyntaxException(Parser2.ERR_UNEXPECTED_PAREN, this.wholeRegexp);
      this.flags = re2.flags;
      if (re2.lb !== 0) {
        if (Parser2.hasCapture(re1)) throw new RE2JSSyntaxException(Parser2.ERR_INVALID_CAPTURE_IN_LOOKBEHIND, this.wholeRegexp);
        if (re2.lb > 0) re2.op = Regexp.Op.PLB;
        else re2.op = Regexp.Op.NLB;
        re2.subs = [re1];
        this.push(re2);
        return;
      }
      if (re2.cap === 0) this.push(re1);
      else {
        re2.op = Regexp.Op.CAPTURE;
        re2.subs = [re1];
        this.push(re2);
      }
    }
    parsePerlClassEscape(t2, cc) {
      const beforePos = t2.pos();
      if ((this.flags & RE2Flags.PERL_X) === 0 || !t2.more() || t2.pop() !== Codepoint.CODES["\\"] || !t2.more()) return false;
      t2.pop();
      const p = t2.from(beforePos);
      const g = PERL_GROUPS.has(p) ? PERL_GROUPS.get(p) : null;
      if (g === null) return false;
      cc.appendGroup(g, (this.flags & RE2Flags.FOLD_CASE) !== 0);
      return true;
    }
    parseNamedClass(t2, cc) {
      const cls = t2.rest();
      const i = cls.indexOf(":]");
      if (i < 0) return false;
      const name = cls.substring(0, i + 2);
      t2.skipString(name);
      const g = POSIX_GROUPS.has(name) ? POSIX_GROUPS.get(name) : null;
      if (g === null) throw new RE2JSSyntaxException(Parser2.ERR_INVALID_CHAR_RANGE, name);
      cc.appendGroup(g, (this.flags & RE2Flags.FOLD_CASE) !== 0);
      return true;
    }
    parseUnicodeClass(t2, cc) {
      const startPos = t2.pos();
      if ((this.flags & RE2Flags.UNICODE_GROUPS) === 0 || !t2.lookingAt("\\p") && !t2.lookingAt("\\P")) return false;
      t2.skip(1);
      let sign = 1;
      let c = t2.pop();
      if (c === Codepoint.CODES["P"]) sign = -1;
      if (!t2.more()) {
        t2.rewindTo(startPos);
        throw new RE2JSSyntaxException(Parser2.ERR_INVALID_CHAR_RANGE, t2.rest());
      }
      c = t2.pop();
      let name;
      if (c !== Codepoint.CODES["{"]) name = Utils.runeToString(c);
      else {
        const rest = t2.rest();
        const end = rest.indexOf("}");
        if (end < 0) {
          t2.rewindTo(startPos);
          throw new RE2JSSyntaxException(Parser2.ERR_INVALID_CHAR_RANGE, t2.rest());
        }
        name = rest.substring(0, end);
        t2.skipString(name);
        t2.skip(1);
      }
      if (!(name.length === 0) && name.codePointAt(0) === Codepoint.CODES["^"]) {
        sign = 0 - sign;
        name = name.substring(1);
      }
      const pair = Parser2.unicodeTable(name);
      if (pair === null) throw new RE2JSSyntaxException(Parser2.ERR_INVALID_CHAR_RANGE, t2.from(startPos));
      if (pair.sign < 0) sign = 0 - sign;
      const tab = pair.tab;
      const fold3 = pair.fold;
      if ((this.flags & RE2Flags.FOLD_CASE) === 0 || fold3 === null) cc.appendTableWithSign(tab, sign);
      else {
        const tmp = new CharClass().appendTable(tab).appendTable(fold3).cleanClass().toArray();
        cc.appendClassWithSign(Array.from(tmp), sign);
      }
      return true;
    }
    parseClass(t2) {
      const startPos = t2.pos();
      t2.skip(1);
      const re = this.newRegexp(Regexp.Op.CHAR_CLASS);
      re.flags = this.flags;
      const cc = new CharClass();
      let sign = 1;
      if (t2.more() && t2.lookingAt("^")) {
        sign = -1;
        t2.skip(1);
        if ((this.flags & RE2Flags.CLASS_NL) === 0) cc.appendRange(Codepoint.CODES["\n"], Codepoint.CODES["\n"]);
      }
      let first = true;
      while (!t2.more() || t2.peek() !== Codepoint.CODES["]"] || first) {
        if (t2.more() && t2.lookingAt("-") && (this.flags & RE2Flags.PERL_X) === 0 && !first) {
          const s = t2.rest();
          if (s === "-" || !s.startsWith("-]")) {
            t2.rewindTo(startPos);
            throw new RE2JSSyntaxException(Parser2.ERR_INVALID_CHAR_RANGE, t2.rest());
          }
        }
        first = false;
        const beforePos = t2.pos();
        if (t2.lookingAt("[:")) {
          if (this.parseNamedClass(t2, cc)) continue;
          t2.rewindTo(beforePos);
        }
        if (this.parseUnicodeClass(t2, cc)) continue;
        if (this.parsePerlClassEscape(t2, cc)) continue;
        t2.rewindTo(beforePos);
        const lo = Parser2.parseClassChar(t2, startPos);
        let hi = lo;
        if (t2.more() && t2.lookingAt("-")) {
          t2.skip(1);
          if (t2.more() && t2.lookingAt("]")) t2.skip(-1);
          else {
            hi = Parser2.parseClassChar(t2, startPos);
            if (hi < lo) throw new RE2JSSyntaxException(Parser2.ERR_INVALID_CHAR_RANGE, t2.from(beforePos));
          }
        }
        if ((this.flags & RE2Flags.FOLD_CASE) === 0) cc.appendRange(lo, hi);
        else cc.appendFoldedRange(lo, hi);
      }
      t2.skip(1);
      cc.cleanClass();
      if (sign < 0) cc.negateClass();
      re.runes = cc.toArray();
      this.push(re);
    }
  };
  var RE2 = class RE22 {
    static initTest(expr) {
      const re2 = RE22.compile(expr);
      const res = new RE22(re2.expr, re2.prog, re2.numSubexp, re2.longest);
      res.cond = re2.cond;
      res.prefix = re2.prefix;
      res.prefixUTF8 = re2.prefixUTF8;
      res.prefixComplete = re2.prefixComplete;
      res.prefixRune = re2.prefixRune;
      res.prefilter = re2.prefilter;
      res.namedGroups = re2.namedGroups;
      return res;
    }
    /**
    * Parses a regular expression and returns, if successful, an {@code RE2} instance that can be
    * used to match against text.
    *
    * When matching against text, the regexp returns a match that begins as early as possible in the
    * input (leftmost), and among those it chooses the one that a backtracking search would have
    * found first. This so-called leftmost-first matching is the same semantics that Perl, Python,
    * and other implementations use, although this package implements it without the expense of
    * backtracking. For POSIX leftmost-longest matching, see {@link #compilePOSIX}.
    */
    static compile(expr) {
      return RE22.compileImpl(expr, RE2Flags.PERL, false);
    }
    /**
    * {@code compilePOSIX} is like {@link #compile} but restricts the regular expression to POSIX ERE
    * (egrep) syntax and changes the match semantics to leftmost-longest.
    *
    * That is, when matching against text, the regexp returns a match that begins as early as
    * possible in the input (leftmost), and among those it chooses a match that is as long as
    * possible. This so-called leftmost-longest matching is the same semantics that early regular
    * expression implementations used and that POSIX specifies.
    *
    * However, there can be multiple leftmost-longest matches, with different submatch choices, and
    * here this package diverges from POSIX. Among the possible leftmost-longest matches, this
    * package chooses the one that a backtracking search would have found first, while POSIX
    * specifies that the match be chosen to maximize the length of the first subexpression, then the
    * second, and so on from left to right. The POSIX rule is computationally prohibitive and not
    * even well-defined. See http://swtch.com/~rsc/regexp/regexp2.html#posix
    */
    static compilePOSIX(expr) {
      return RE22.compileImpl(expr, RE2Flags.POSIX, true);
    }
    static compileImpl(expr, mode, longest) {
      let re = Parser.parse(expr, mode);
      const maxCap = re.maxCap();
      const namedGroups = re.namedGroups;
      re = Simplify.simplify(re);
      const prefilter = PrefilterTree.build(re);
      const prog = Compiler.compileRegexp(re);
      const re2 = new RE22(expr, prog, maxCap, longest);
      re2.prefilter = prefilter.type === Prefilter.Type.NONE ? null : prefilter;
      const [prefixCompl, prefixStr] = prog.prefix();
      re2.prefixComplete = prefixCompl;
      re2.prefix = prefixStr;
      re2.prefixUTF8 = Utils.stringToUtf8ByteArray(re2.prefix);
      if (re2.prefix.length > 0) re2.prefixRune = re2.prefix.codePointAt(0);
      re2.namedGroups = namedGroups;
      return re2;
    }
    /**
    * Returns true iff textual regular expression {@code pattern} matches string {@code s}.
    *
    * More complicated queries need to use {@link #compile} and the full {@code RE2} interface.
    */
    static match(pattern, s) {
      return RE22.compile(pattern).match(s);
    }
    constructor(expr, prog, numSubexp = 0, longest = 0) {
      this.expr = expr;
      this.prog = prog;
      this.numSubexp = numSubexp;
      this.longest = longest;
      this.cond = prog.startCond();
      this.prefix = null;
      this.prefixUTF8 = null;
      this.prefixComplete = false;
      this.prefixRune = 0;
      this.namedGroups = /* @__PURE__ */ Object.create(null);
      this.machinePool = [];
      this.lazyDFA = null;
      this.onepass = OnePass.compile(this.prog);
      this.prefilter = null;
    }
    get dfa() {
      if (this.lazyDFA === null) this.lazyDFA = new DFA(this.prog);
      return this.lazyDFA;
    }
    matchPrefixComplete(input, pos, anchor, ncap) {
      if ((anchor === RE2Flags.ANCHOR_START || anchor === RE2Flags.ANCHOR_BOTH) && pos !== 0) return null;
      let matchStart = -1;
      let matchEnd = -1;
      const pLen = input.prefixLength(this);
      if (anchor === RE2Flags.UNANCHORED) {
        const idx = input.index(this, pos);
        if (idx < 0) return null;
        matchStart = pos + idx;
        matchEnd = matchStart + pLen;
      } else if (anchor === RE2Flags.ANCHOR_BOTH) {
        if (input.endPos() !== pLen) return null;
        if (input.index(this, 0) !== 0) return null;
        matchStart = 0;
        matchEnd = pLen;
      } else if (anchor === RE2Flags.ANCHOR_START) {
        if (input.index(this, 0) !== 0) return null;
        matchStart = 0;
        matchEnd = pLen;
      }
      if (matchStart < 0) return null;
      if (ncap > 0) {
        const matchcap = new Int32Array(ncap).fill(-1);
        matchcap[0] = matchStart;
        matchcap[1] = matchEnd;
        return Array.from(matchcap);
      }
      return [];
    }
    createLookbehindState() {
      return this.prog.numLb > 0 ? new LookbehindState(this.prog) : null;
    }
    executeEngine(input, pos, anchor, ncap, lbState = null) {
      if (this.prefixComplete && (ncap === 0 || this.numSubexp === 0)) return this.matchPrefixComplete(input, pos, anchor, ncap);
      if (this.prefilter !== null && anchor === RE2Flags.UNANCHORED) {
        if (!this.prefilter.eval(input, pos)) return null;
      }
      if (this.onepass !== null) return OnePass.execute(this, input, pos, anchor, ncap);
      if (ncap > 0) {
        if (this.prog.numLb === 0 && input.endPos() <= Backtracker.maxBitStateLen(this.prog)) return Backtracker.execute(this, input, pos, anchor, ncap);
        return this.doExecuteNFA(input, pos, anchor, ncap, lbState);
      }
      if (this.prog.numLb === 0) {
        const dfaResult = this.dfa.match(input, pos, anchor);
        if (dfaResult !== null) return dfaResult ? [] : null;
        if (input.endPos() <= Backtracker.maxBitStateLen(this.prog)) return Backtracker.execute(this, input, pos, anchor, ncap);
      }
      return this.doExecuteNFA(input, pos, anchor, ncap, lbState);
    }
    /**
    * Returns the number of parenthesized subexpressions in this regular expression.
    */
    numberOfCapturingGroups() {
      return this.numSubexp;
    }
    /**
    * Returns the number of instructions in this compiled regular expression program.
    */
    numberOfInstructions() {
      return this.prog.numInst();
    }
    get() {
      return this.machinePool.length > 0 ? this.machinePool.pop() : null;
    }
    reset() {
      this.machinePool.length = 0;
    }
    put(m) {
      this.machinePool.push(m);
    }
    toString() {
      return this.expr;
    }
    doExecuteNFA(input, pos, anchor, ncap, lbState = null) {
      let m = this.get();
      if (!m) m = Machine.fromRE2(this);
      m.init(ncap);
      const cap = m.match(input, pos, anchor, lbState) ? m.submatches() : null;
      this.put(m);
      return cap;
    }
    match(s) {
      return this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, 0) !== null;
    }
    /**
    * Matches the regular expression against input starting at position start and ending at position
    * end, with the given anchoring. Records the submatch boundaries in group, which is [start, end)
    * pairs of byte offsets. The number of boundaries needed is inferred from the size of the group
    * array. It is most efficient not to ask for submatch boundaries.
    *
    * @param input the input byte array
    * @param start the beginning position in the input
    * @param end the end position in the input
    * @param anchor the anchoring flag (UNANCHORED, ANCHOR_START, ANCHOR_BOTH)
    * @param group the array to fill with submatch positions
    * @param ngroup the number of array pairs to fill in
    * @param lbState optional state carried between successive matches over the same input (see
    *   createLookbehindState); omit it to evaluate lookbehinds from the beginning of the input
    * @returns true if a match was found
    */
    matchWithGroup(input, start, end, anchor, ngroup, lbState = null) {
      if (!(input instanceof MatcherInputBase)) {
        if (Utils.isByteArray(input)) input = MatcherInput.utf8(input);
        else input = MatcherInput.utf16(input);
      }
      return this.matchMachineInput(input, start, end, anchor, ngroup, lbState);
    }
    matchMachineInput(input, start, end, anchor, ngroup, lbState = null) {
      if (start > end) return [false, null];
      const machineInput = input.isUTF16Encoding() ? MachineInput.fromUTF16(input.asCharSequence(), 0, end) : MachineInput.fromUTF8(input.asBytes(), 0, end);
      const groupMatch = this.executeEngine(machineInput, start, anchor, 2 * ngroup, lbState);
      if (groupMatch === null) return [false, null];
      return [true, groupMatch];
    }
    /**
    * Returns true iff this regexp matches the UTF-8 byte array {@code b}.
    */
    matchUTF8(b) {
      return this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, 0) !== null;
    }
    /**
    * Returns a copy of {@code src} in which all matches for this regexp have been replaced by
    * {@code repl}. No support is provided for expressions (e.g. {@code \1} or {@code $1}) in the
    * replacement string.
    */
    replaceAll(src, repl) {
      return this.replaceAllFunc(src, () => repl, 2 * src.length + 1);
    }
    /**
    * Returns a copy of {@code src} in which only the first match for this regexp has been replaced
    * by {@code repl}. No support is provided for expressions (e.g. {@code \1} or {@code $1}) in the
    * replacement string.
    */
    replaceFirst(src, repl) {
      return this.replaceAllFunc(src, () => repl, 1);
    }
    /**
    * Returns a copy of {@code src} in which at most {@code maxReplaces} matches for this regexp have
    * been replaced by the return value of of function {@code repl} (whose first argument is the
    * matched string). No support is provided for expressions (e.g. {@code \1} or {@code $1}) in the
    * replacement string.
    */
    replaceAllFunc(src, replFunc, maxReplaces) {
      let lastMatchEnd = 0;
      let searchPos = 0;
      let out = "";
      const input = MachineInput.fromUTF16(src);
      const lbState = this.createLookbehindState();
      let numReplaces = 0;
      while (searchPos <= src.length) {
        const a = this.executeEngine(input, searchPos, RE2Flags.UNANCHORED, 2, lbState);
        if (a === null || a.length === 0) break;
        out += src.substring(lastMatchEnd, a[0]);
        if (a[1] > lastMatchEnd || a[0] === 0) {
          out += replFunc(src.substring(a[0], a[1]));
          numReplaces++;
        }
        lastMatchEnd = a[1];
        const width = input.step(searchPos) & 7;
        if (searchPos + width > a[1]) searchPos += width;
        else if (searchPos + 1 > a[1]) searchPos++;
        else searchPos = a[1];
        if (numReplaces >= maxReplaces) break;
      }
      out += src.substring(lastMatchEnd);
      return out;
    }
    pad(a) {
      if (a === null) return null;
      let n = (1 + this.numSubexp) * 2;
      if (a.length < n) {
        let a2 = new Array(n).fill(-1);
        for (let i = 0; i < a.length; i++) a2[i] = a[i];
        a = a2;
      }
      return a;
    }
    allMatches(input, n, deliverFun = (v) => v) {
      let result = [];
      const end = input.endPos();
      if (n < 0) n = end + 1;
      let pos = 0;
      let i = 0;
      let prevMatchEnd = -1;
      const lbState = this.createLookbehindState();
      while (i < n && pos <= end) {
        const matches = this.executeEngine(input, pos, RE2Flags.UNANCHORED, this.prog.numCap, lbState);
        if (matches === null || matches.length === 0) break;
        let accept = true;
        if (matches[1] === pos) {
          if (matches[0] === prevMatchEnd) accept = false;
          const r = input.step(pos);
          if (r < 0) pos = end + 1;
          else pos += r & 7;
        } else pos = matches[1];
        prevMatchEnd = matches[1];
        if (accept) {
          result.push(deliverFun(this.pad(matches)));
          i++;
        }
      }
      return result;
    }
    /**
    * Returns an array holding the text of the leftmost match in {@code b} of this regular
    * expression.
    *
    * A return value of null indicates no match.
    */
    findUTF8(b) {
      const a = this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, 2);
      if (a === null) return null;
      return b.slice(a[0], a[1]);
    }
    /**
    * Returns a two-element array of integers defining the location of the leftmost match in
    * {@code b} of this regular expression. The match itself is at {@code b[loc[0]...loc[1]]}.
    *
    * A return value of null indicates no match.
    */
    findUTF8Index(b) {
      const a = this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, 2);
      if (a === null) return null;
      return a.slice(0, 2);
    }
    /**
    * Returns a string holding the text of the leftmost match in {@code s} of this regular
    * expression.
    *
    * If there is no match, the return value is an empty string, but it will also be empty if the
    * regular expression successfully matches an empty string. Use {@link #findIndex} or
    * {@link #findSubmatch} if it is necessary to distinguish these cases.
    */
    find(s) {
      const a = this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, 2);
      if (a === null) return "";
      return s.substring(a[0], a[1]);
    }
    /**
    * Returns a two-element array of integers defining the location of the leftmost match in
    * {@code s} of this regular expression. The match itself is at
    * {@code s.substring(loc[0], loc[1])}.
    *
    * A return value of null indicates no match.
    */
    findIndex(s) {
      return this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, 2);
    }
    /**
    * Returns an array of arrays the text of the leftmost match of the regular expression in
    * {@code b} and the matches, if any, of its subexpressions, as defined by the <a
    * href='#submatch'>Submatch</a> description above.
    *
    * A return value of null indicates no match.
    */
    findUTF8Submatch(b) {
      const a = this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, this.prog.numCap);
      if (a === null) return null;
      const ret = new Array(1 + this.numSubexp).fill(null);
      for (let i = 0; i < ret.length; i++) if (2 * i < a.length && a[2 * i] >= 0) ret[i] = b.slice(a[2 * i], a[2 * i + 1]);
      return ret;
    }
    /**
    * Returns an array holding the index pairs identifying the leftmost match of this regular
    * expression in {@code b} and the matches, if any, of its subexpressions, as defined by the the
    * <a href='#submatch'>Submatch</a> and <a href='#index'>Index</a> descriptions above.
    *
    * A return value of null indicates no match.
    */
    findUTF8SubmatchIndex(b) {
      return this.pad(this.executeEngine(MachineInput.fromUTF8(b), 0, RE2Flags.UNANCHORED, this.prog.numCap));
    }
    /**
    * Returns an array of strings holding the text of the leftmost match of the regular expression in
    * {@code s} and the matches, if any, of its subexpressions, as defined by the <a
    * href='#submatch'>Submatch</a> description above.
    *
    * A return value of null indicates no match.
    */
    findSubmatch(s) {
      const a = this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, this.prog.numCap);
      if (a === null) return null;
      const ret = new Array(1 + this.numSubexp).fill(null);
      for (let i = 0; i < ret.length; i++) if (2 * i < a.length && a[2 * i] >= 0) ret[i] = s.substring(a[2 * i], a[2 * i + 1]);
      return ret;
    }
    /**
    * Returns an array holding the index pairs identifying the leftmost match of this regular
    * expression in {@code s} and the matches, if any, of its subexpressions, as defined by the <a
    * href='#submatch'>Submatch</a> description above.
    *
    * A return value of null indicates no match.
    */
    findSubmatchIndex(s) {
      return this.pad(this.executeEngine(MachineInput.fromUTF16(s), 0, RE2Flags.UNANCHORED, this.prog.numCap));
    }
    /**
    * {@code findAllUTF8()} is the <a href='#all'>All</a> version of {@link #findUTF8}; it returns a
    * list of up to {@code n} successive matches of the expression, as defined by the <a
    * href='#all'>All</a> description above.
    *
    * A return value of null indicates no match.
    *
    * TODO(adonovan): think about defining a byte slice view class, like a read-only Go slice backed
    * by |b|.
    */
    findAllUTF8(b, n) {
      const result = this.allMatches(MachineInput.fromUTF8(b), n, (match) => b.slice(match[0], match[1]));
      if (result.length === 0) return null;
      return result;
    }
    /**
    * {@code findAllUTF8Index} is the <a href='#all'>All</a> version of {@link #findUTF8Index}; it
    * returns a list of up to {@code n} successive matches of the expression, as defined by the <a
    * href='#all'>All</a> description above.
    *
    * A return value of null indicates no match.
    */
    findAllUTF8Index(b, n) {
      const result = this.allMatches(MachineInput.fromUTF8(b), n, (match) => match.slice(0, 2));
      if (result.length === 0) return null;
      return result;
    }
    /**
    * {@code findAll} is the <a href='#all'>All</a> version of {@link #find}; it returns a list of up
    * to {@code n} successive matches of the expression, as defined by the <a href='#all'>All</a>
    * description above.
    *
    * A return value of null indicates no match.
    */
    findAll(s, n) {
      const result = this.allMatches(MachineInput.fromUTF16(s), n, (match) => s.substring(match[0], match[1]));
      if (result.length === 0) return null;
      return result;
    }
    /**
    * {@code findAllIndex} is the <a href='#all'>All</a> version of {@link #findIndex}; it returns a
    * list of up to {@code n} successive matches of the expression, as defined by the <a
    * href='#all'>All</a> description above.
    *
    * A return value of null indicates no match.
    */
    findAllIndex(s, n) {
      const result = this.allMatches(MachineInput.fromUTF16(s), n, (match) => match.slice(0, 2));
      if (result.length === 0) return null;
      return result;
    }
    /**
    * {@code findAllUTF8Submatch} is the <a href='#all'>All</a> version of {@link #findUTF8Submatch};
    * it returns a list of up to {@code n} successive matches of the expression, as defined by the <a
    * href='#all'>All</a> description above.
    *
    * A return value of null indicates no match.
    */
    findAllUTF8Submatch(b, n) {
      const result = this.allMatches(MachineInput.fromUTF8(b), n, (match) => {
        let slice2 = new Array(match.length / 2 | 0).fill(null);
        for (let j = 0; j < slice2.length; j++) if (match[2 * j] >= 0) slice2[j] = b.slice(match[2 * j], match[2 * j + 1]);
        return slice2;
      });
      if (result.length === 0) return null;
      return result;
    }
    /**
    * {@code findAllUTF8SubmatchIndex} is the <a href='#all'>All</a> version of
    * {@link #findUTF8SubmatchIndex}; it returns a list of up to {@code n} successive matches of the
    * expression, as defined by the <a href='#all'>All</a> description above.
    *
    * A return value of null indicates no match.
    */
    findAllUTF8SubmatchIndex(b, n) {
      const result = this.allMatches(MachineInput.fromUTF8(b), n);
      if (result.length === 0) return null;
      return result;
    }
    /**
    * {@code findAllSubmatch} is the <a href='#all'>All</a> version of {@link #findSubmatch}; it
    * returns a list of up to {@code n} successive matches of the expression, as defined by the <a
    * href='#all'>All</a> description above.
    *
    * A return value of null indicates no match.
    */
    findAllSubmatch(s, n) {
      const result = this.allMatches(MachineInput.fromUTF16(s), n, (match) => {
        let slice2 = new Array(match.length / 2 | 0).fill(null);
        for (let j = 0; j < slice2.length; j++) if (match[2 * j] >= 0) slice2[j] = s.substring(match[2 * j], match[2 * j + 1]);
        return slice2;
      });
      if (result.length === 0) return null;
      return result;
    }
    /**
    * {@code findAllSubmatchIndex} is the <a href='#all'>All</a> version of
    * {@link #findSubmatchIndex}; it returns a list of up to {@code n} successive matches of the
    * expression, as defined by the <a href='#all'>All</a> description above.
    *
    * A return value of null indicates no match.
    */
    findAllSubmatchIndex(s, n) {
      const result = this.allMatches(MachineInput.fromUTF16(s), n);
      if (result.length === 0) return null;
      return result;
    }
  };
  var RE2Set = class RE2Set2 {
    /** @type {number} */
    static UNANCHORED = RE2Flags.UNANCHORED;
    /** @type {number} */
    static ANCHOR_START = RE2Flags.ANCHOR_START;
    /** @type {number} */
    static ANCHOR_BOTH = RE2Flags.ANCHOR_BOTH;
    /**
    * Constructs a new RE2Set with the specified anchor mode and flags.
    * @param {number} [anchor=RE2Set.UNANCHORED] - The anchoring mode (e.g., RE2Set.UNANCHORED).
    * @param {number} [flags=0] - The public flags to apply to all patterns in the set.
    * @param {number} [maxMem=8388608] - The maximum memory in bytes to use for the DFA (default 8MB).
    */
    constructor(anchor = RE2Set2.UNANCHORED, flags = 0, maxMem = 8388608) {
      this.anchor = anchor;
      this.jsFlags = flags;
      this.maxMem = maxMem;
      let re2Flags = RE2Flags.PERL;
      if ((flags & PublicFlags.DISABLE_UNICODE_GROUPS) !== 0) re2Flags &= ~RE2Flags.UNICODE_GROUPS;
      if ((flags & PublicFlags.LOOKBEHINDS) !== 0) re2Flags |= RE2Flags.LOOKBEHIND;
      this.re2Flags = re2Flags;
      this.regexps = [];
      this.prog = null;
      this.dfa = null;
      this.dummyRe2 = null;
    }
    /**
    * Adds a new regular expression pattern to the set.
    * Patterns cannot be added after the set has been compiled.
    * @param {string} pattern - The regular expression pattern to add.
    * @returns {number} The integer index assigned to the added pattern.
    * @throws {RE2JSCompileException} If patterns are added after compilation.
    */
    add(pattern) {
      if (this.prog) throw new RE2JSCompileException("Cannot add patterns after compile");
      let fregex = pattern;
      if ((this.jsFlags & PublicFlags.CASE_INSENSITIVE) !== 0) fregex = `(?i)${fregex}`;
      if ((this.jsFlags & PublicFlags.DOTALL) !== 0) fregex = `(?s)${fregex}`;
      if ((this.jsFlags & PublicFlags.MULTILINE) !== 0) fregex = `(?m)${fregex}`;
      const re = Parser.parse(fregex, this.re2Flags);
      this.regexps.push(Simplify.simplify(re));
      return this.regexps.length - 1;
    }
    /**
    * Compiles the added patterns into a single state machine.
    * This is automatically called on the first match if not called explicitly.
    * @returns {void}
    */
    compile() {
      if (this.prog) return;
      const prog = Compiler.compileSet(this.regexps);
      if (prog.numInst() > Parser.MAX_SIZE) throw new RE2JSCompileException(`${Parser.ERR_LARGE}: the set compiles to ${prog.numInst()} instructions, more than ${Parser.MAX_SIZE}`);
      this.prog = prog;
      this.dfa = new DFA(this.prog, this.maxMem);
      this.dummyRe2 = {
        prog: this.prog,
        cond: this.prog.startCond(),
        prefix: "",
        prefixRune: 0,
        longest: false
      };
    }
    /**
    * Matches the input against the compiled set of regular expressions.
    * @param {string|number[]|Uint8Array} input - The input string or UTF-8 byte array to match against.
    * @returns {number[]} An array of indices representing the patterns that successfully matched the input.
    */
    match(input) {
      if (!this.prog) this.compile();
      const machineInput = Utils.isByteArray(input) ? MachineInput.fromUTF8(input) : MachineInput.fromUTF16(input);
      let internalAnchor = RE2Flags.UNANCHORED;
      if (this.anchor === RE2Set2.ANCHOR_START) internalAnchor = RE2Flags.ANCHOR_START;
      else if (this.anchor === RE2Set2.ANCHOR_BOTH) internalAnchor = RE2Flags.ANCHOR_BOTH;
      const dfaResult = this.dfa.matchSet(machineInput, 0, internalAnchor);
      if (dfaResult !== null) return dfaResult;
      const machine = Machine.fromRE2(this.dummyRe2);
      machine.init(0);
      return machine.matchSet(machineInput, 0, internalAnchor);
    }
  };
  var TranslateRegExpString = class TranslateRegExpString2 {
    static isHexadecimal(ch) {
      return "0" <= ch && ch <= "9" || "A" <= ch && ch <= "F" || "a" <= ch && ch <= "f";
    }
    static translate(data) {
      let prefixFlags = "";
      if (data instanceof RegExp) {
        if (data.ignoreCase) prefixFlags += "i";
        if (data.multiline) prefixFlags += "m";
        if (data.dotAll) prefixFlags += "s";
        data = data.source;
      }
      if (typeof data !== "string") return data;
      let result = "";
      let changed = false;
      let size = data.length;
      if (size === 0) {
        result = "(?:)";
        changed = true;
      }
      let inCharClass = false;
      let i = 0;
      while (i < size) {
        let ch = data[i];
        if (ch === "\\") {
          if (i + 1 < size) {
            ch = data[i + 1];
            switch (ch) {
              case "\\":
                result += "\\\\";
                i += 2;
                continue;
              case "c":
                if (i + 2 < size) {
                  let code = data[i + 2].charCodeAt(0);
                  if (code >= 65 && code <= 90 || code >= 97 && code <= 122) {
                    let val = code % 32;
                    result += "\\x";
                    result += (val >> 4).toString(16).toUpperCase();
                    result += (val & 15).toString(16).toUpperCase();
                    i += 3;
                    changed = true;
                    continue;
                  }
                }
                result += "c";
                i += 2;
                changed = true;
                continue;
              case "u":
                if (i + 2 < size) {
                  if (data[i + 2] === "{") {
                    let j = i + 3;
                    let hasHex = false;
                    let closed = false;
                    while (j < size) {
                      const hexChar = data[j];
                      if (hexChar === "}") {
                        closed = true;
                        break;
                      }
                      if (!TranslateRegExpString2.isHexadecimal(hexChar)) break;
                      hasHex = true;
                      j++;
                    }
                    if (closed && hasHex) {
                      result += "\\x";
                      i += 2;
                      changed = true;
                      continue;
                    }
                  } else if (i + 5 < size) {
                    let isHex4 = true;
                    for (let j = 0; j < 4; j++) if (!TranslateRegExpString2.isHexadecimal(data[i + 2 + j])) {
                      isHex4 = false;
                      break;
                    }
                    if (isHex4) {
                      result += "\\x{" + data.substring(i + 2, i + 6) + "}";
                      i += 6;
                      changed = true;
                      continue;
                    }
                  }
                }
                result += "u";
                i += 2;
                changed = true;
                continue;
              case "x": {
                let isValidHex = false;
                if (i + 2 < size && data[i + 2] === "{") {
                  let j = i + 3;
                  let hasHex = false;
                  let closed = false;
                  while (j < size) {
                    const hexChar = data[j];
                    if (hexChar === "}") {
                      closed = true;
                      break;
                    }
                    if (!TranslateRegExpString2.isHexadecimal(hexChar)) break;
                    hasHex = true;
                    j++;
                  }
                  if (closed && hasHex) isValidHex = true;
                } else if (i + 3 < size && TranslateRegExpString2.isHexadecimal(data[i + 2]) && TranslateRegExpString2.isHexadecimal(data[i + 3])) isValidHex = true;
                if (isValidHex) {
                  result += "\\x";
                  i += 2;
                } else {
                  result += "x";
                  i += 2;
                  changed = true;
                }
                continue;
              }
              case "n":
              case "r":
              case "t":
              case "a":
              case "f":
              case "v":
              case "d":
              case "D":
              case "s":
              case "S":
              case "w":
              case "W":
              case "b":
              case "B":
              case "p":
              case "P":
              case "A":
              case "z":
              case "Q":
              case "E":
              case "0":
              case "1":
              case "2":
              case "3":
              case "4":
              case "5":
              case "6":
              case "7":
                result += "\\" + ch;
                i += 2;
                continue;
              default: {
                let cp2 = data.codePointAt(i + 1);
                if (cp2 >= 48 && cp2 <= 57 || cp2 >= 65 && cp2 <= 90 || cp2 >= 97 && cp2 <= 122) {
                  let symSize2 = Utils.charCount(cp2);
                  result += data.substring(i + 1, i + 1 + symSize2);
                  i += symSize2 + 1;
                  changed = true;
                } else {
                  result += "\\";
                  let symSize2 = Utils.charCount(cp2);
                  result += data.substring(i + 1, i + 1 + symSize2);
                  i += symSize2 + 1;
                }
                continue;
              }
            }
          }
        } else if (ch === "/") {
          result += "\\/";
          i += 1;
          changed = true;
          continue;
        } else if (ch === "[") {
          if (!inCharClass && data[i + 1] === "]") {
            result += "[^\\x00-\\x{10FFFF}]";
            i += 2;
            changed = true;
            continue;
          }
          if (!inCharClass && data[i + 1] === "^" && data[i + 2] === "]") {
            result += "[\\x00-\\x{10FFFF}]";
            i += 3;
            changed = true;
            continue;
          }
          inCharClass = true;
        } else if (ch === "]") inCharClass = false;
        else if (!inCharClass && ch === "(" && i + 2 < size && data[i + 1] === "?" && data[i + 2] === "<") {
          if (i + 3 < size && !"=!>)".includes(data[i + 3])) {
            result += "(?P<";
            i += 3;
            changed = true;
            continue;
          }
        }
        let cp = data.codePointAt(i);
        let symSize = Utils.charCount(cp);
        result += data.substring(i, i + symSize);
        i += symSize;
      }
      const finalResult = changed ? result : data;
      if (prefixFlags.length > 0) return `(?${prefixFlags})${finalResult}`;
      return finalResult;
    }
  };
  var execResult = (m, input) => {
    const result = m.matchArray();
    result.index = m.start(0);
    result.input = input;
    result.groups = m.namedGroupsObject();
    return result;
  };
  var RE2JS = class RE2JS2 {
    /**
    * Flag: case insensitive matching.
    */
    static CASE_INSENSITIVE = PublicFlags.CASE_INSENSITIVE;
    /**
    * Flag: dot ({@code .}) matches all characters, including newline.
    */
    static DOTALL = PublicFlags.DOTALL;
    /**
    * Flag: multiline matching: {@code ^} and {@code $} match at beginning and end of line, not just
    * beginning and end of input.
    */
    static MULTILINE = PublicFlags.MULTILINE;
    /**
    * Flag: Unicode groups (e.g. {@code \p\ Greek\} ) will be syntax errors.
    */
    static DISABLE_UNICODE_GROUPS = PublicFlags.DISABLE_UNICODE_GROUPS;
    /**
    * Flag: matches longest possible string.
    */
    static LONGEST_MATCH = PublicFlags.LONGEST_MATCH;
    /**
    * Flag: enable linear-time captureless lookbehinds.
    */
    static LOOKBEHINDS = PublicFlags.LOOKBEHINDS;
    /**
    * Returns a literal pattern string for the specified string.
    *
    * This method produces a string that can be used to create a <code>RE2JS</code> that would
    * match the string <code>s</code> as if it were a literal pattern.
    *
    * Metacharacters or escape sequences in the input sequence will be given no special meaning.
    *
    * @param {string} str The string to be literalized
    * @returns {string} A literal string replacement
    */
    static quote(str) {
      return Utils.quoteMeta(str);
    }
    /**
    * Quotes '\' and '$' in {@code str}, so that the returned string could be used in
    * replacement methods as a literal replacement of {@code str}.
    *
    * This is a convenience delegation to {@link Matcher.quoteReplacement}.
    *
    * @param {string} str the string to be quoted
    * @param {boolean} [javaMode=false] whether the replacement will be used in javaMode
    * @returns {string} the quoted string
    */
    static quoteReplacement(str, javaMode = false) {
      return Matcher.quoteReplacement(str, javaMode);
    }
    /**
    * Translates a given regular expression string to ensure compatibility with RE2JS.
    *
    * This function preprocesses the input regex string by applying necessary transformations,
    * such as escaping special characters (e.g., `/`), converting named capture groups to
    * RE2JS-compatible syntax, and handling Unicode sequences properly. It ensures that the
    * resulting regex is safe and properly formatted before compilation.
    *
    * @param {string|RegExp} expr - The regular expression string to be translated.
    * @returns {string} - The transformed regular expression string, ready for compilation.
    */
    static translateRegExp(expr) {
      return TranslateRegExpString.translate(expr);
    }
    /**
    * Helper: create new RE2JS with given regex and flags. Flregex is the regex with flags applied.
    * @param {string} regex
    * @param {number} [flags=0]
    * @returns {RE2JS}
    */
    static compile(regex, flags = 0) {
      let fregex = regex;
      if ((flags & RE2JS2.CASE_INSENSITIVE) !== 0) fregex = `(?i)${fregex}`;
      if ((flags & RE2JS2.DOTALL) !== 0) fregex = `(?s)${fregex}`;
      if ((flags & RE2JS2.MULTILINE) !== 0) fregex = `(?m)${fregex}`;
      if ((flags & ~(RE2JS2.MULTILINE | RE2JS2.DOTALL | RE2JS2.CASE_INSENSITIVE | RE2JS2.DISABLE_UNICODE_GROUPS | RE2JS2.LONGEST_MATCH | RE2JS2.LOOKBEHINDS)) !== 0) throw new RE2JSFlagsException("Flags should only be a combination of MULTILINE, DOTALL, CASE_INSENSITIVE, DISABLE_UNICODE_GROUPS, LONGEST_MATCH, LOOKBEHINDS");
      let re2Flags = RE2Flags.PERL;
      if ((flags & RE2JS2.DISABLE_UNICODE_GROUPS) !== 0) re2Flags &= ~RE2Flags.UNICODE_GROUPS;
      if ((flags & RE2JS2.LOOKBEHINDS) !== 0) re2Flags |= RE2Flags.LOOKBEHIND;
      const p = new RE2JS2(regex, flags);
      p.re2Input = RE2.compileImpl(fregex, re2Flags, (flags & RE2JS2.LONGEST_MATCH) !== 0);
      return p;
    }
    /**
    * Matches a string against a regular expression.
    *
    * @param {string} regex the regular expression
    * @param {string|number[]|Uint8Array} input the input
    * @returns {boolean} true if the regular expression matches the entire input
    * @throws RE2JSSyntaxException if the regular expression is malformed
    */
    static matches(regex, input) {
      return RE2JS2.compile(regex).testExact(input);
    }
    /**
    * This is visible for testing.
    * @private
    */
    static initTest(pattern, flags, re2) {
      if (pattern == null) throw new Error("pattern is null");
      if (re2 == null) throw new Error("re2 is null");
      const p = new RE2JS2(pattern, flags);
      p.re2Input = re2;
      return p;
    }
    /**
    *
    * @param {string} pattern
    * @param {number} flags
    */
    constructor(pattern, flags) {
      this.patternInput = pattern;
      this.flagsInput = flags;
      this.re2Input = null;
    }
    /**
    * Releases memory used by internal caches associated with this pattern. Does not change the
    * observable behaviour. Useful for tests that detect memory leaks via allocation tracking.
    */
    reset() {
      this.re2Input.reset();
    }
    /**
    * Returns the flags used in the constructor.
    * @returns {number}
    */
    flags() {
      return this.flagsInput;
    }
    /**
    * Returns the pattern used in the constructor.
    * @returns {string}
    */
    pattern() {
      return this.patternInput;
    }
    re2() {
      return this.re2Input;
    }
    /**
    * Matches a string against a regular expression.
    *
    * @param {string|number[]|Uint8Array} input the input
    * @returns {boolean} true if the regular expression matches the entire input
    */
    matches(input) {
      return this.testExact(input);
    }
    /**
    * Creates a new {@code Matcher} matching the pattern against the input.
    *
    * @param {string|number[]|Uint8Array|MatcherInputBase} input the input string
    * @returns {Matcher}
    */
    matcher(input) {
      if (Utils.isByteArray(input)) input = MatcherInput.utf8(input);
      return new Matcher(this, input);
    }
    /**
    * Tests whether the regular expression matches any part of the input string.
    * Performance Note: This method is highly optimized. Because it only returns
    * a boolean and does not extract capture groups, it bypasses the `Matcher` overhead
    * and guarantees execution on the high-speed DFA engine whenever possible.
    *
    * @param {string|number[]|Uint8Array} input - The input string or UTF-8 byte array to test against.
    * @returns {boolean} `true` if the pattern is found anywhere in the input, `false` otherwise.
    */
    test(input) {
      if (Utils.isByteArray(input)) return this.re2Input.matchUTF8(input);
      return this.re2Input.match(input);
    }
    /**
    * Tests whether the regular expression matches the ENTIRE input string.
    * * **Performance Note:** This operates identically to `.matches()`, but is significantly
    * faster because it does not request capture group data. By requesting 0 capture groups,
    * it securely routes execution through the DFA fast-path.
    *
    * @param {string|number[]|Uint8Array} input - The input string or UTF-8 byte array to test against.
    * @returns {boolean} `true` if the exact input string fully matches the pattern, `false` otherwise.
    */
    testExact(input) {
      const machineInput = Utils.isByteArray(input) ? MachineInput.fromUTF8(input) : MachineInput.fromUTF16(input);
      return this.re2Input.executeEngine(machineInput, 0, RE2Flags.ANCHOR_BOTH, 0) !== null;
    }
    /**
    * Executes a search for a match in a specified string.
    * Returns a result array, or null if no match is found.
    * The returned array perfectly mirrors standard JavaScript `RegExpExecArray`,
    * including `.index`, `.input`, and `.groups` properties.
    *
    * @param {string|number[]|Uint8Array} input the input string or byte array
    * @returns {Array|null} the match array with index, input, and groups properties, or null
    */
    exec(input) {
      const m = this.matcher(input);
      return m.find() ? execResult(m, input) : null;
    }
    /**
    * Splits input around instances of the regular expression. It returns an array giving the strings
    * that occur before, between, and after instances of the regular expression.
    *
    * If {@code limit <= 0}, there is no limit on the size of the returned array. If
    * {@code limit == 0}, empty strings that would occur at the end of the array are omitted. If
    * {@code limit > 0}, at most limit strings are returned. The final string contains the remainder
    * of the input, possibly including additional matches of the pattern.
    *
    * @param {string} input the input string to be split
    * @param {number} [limit=0] the limit
    * @returns {string[]} the split strings
    */
    split(input, limit = 0) {
      const m = this.matcher(input);
      const result = [];
      let emptiesSkipped = 0;
      let last = 0;
      while (m.find()) {
        if (last === 0 && m.end() === 0) {
          last = m.end();
          continue;
        }
        if (limit > 0 && result.length === limit - 1) break;
        if (last === m.start()) {
          if (limit === 0) {
            emptiesSkipped += 1;
            last = m.end();
            continue;
          }
        } else while (emptiesSkipped > 0) {
          result.push("");
          emptiesSkipped -= 1;
        }
        result.push(m.substring(last, m.start()));
        last = m.end();
      }
      if (limit === 0 && last !== m.inputLength()) {
        while (emptiesSkipped > 0) {
          result.push("");
          emptiesSkipped -= 1;
        }
        result.push(m.substring(last, m.inputLength()));
      }
      if (limit !== 0 || result.length === 0 && !(last === m.inputLength() && last > 0)) result.push(m.substring(last, m.inputLength()));
      return result;
    }
    /**
    * Returns an iterator of all results matching a string against the regular expression,
    * including capturing groups.
    *
    * @param {string|number[]|Uint8Array} input the input string or byte array
    * @returns {IterableIterator<RegExpMatchArray>}
    */
    *matchAll(input) {
      const m = this.matcher(input);
      while (m.find()) yield execResult(m, input);
    }
    /**
    *
    * @returns {string}
    */
    toString() {
      return this.patternInput;
    }
    /**
    * Returns the program size of this pattern.
    *
    * <p>
    * Similar to the C++ implementation, the program size is a very approximate measure of a regexp's
    * "cost". Larger numbers are more expensive than smaller numbers.
    * </p>
    *
    * @returns {number} the program size of this pattern
    */
    programSize() {
      return this.re2Input.numberOfInstructions();
    }
    /**
    * Returns the number of capturing groups in this matcher's pattern. Group zero denotes the entire
    * pattern and is excluded from this count.
    *
    * @returns {number} the number of capturing groups in this pattern
    */
    groupCount() {
      return this.re2Input.numberOfCapturingGroups();
    }
    /**
    * Return a map of the capturing groups in this matcher's pattern, where key is the name and value
    * is the index of the group in the pattern.
    * @returns {Record<string, number>}
    */
    namedGroups() {
      return this.re2Input.namedGroups;
    }
    /**
    *
    * @param {*} other
    * @returns {boolean}
    */
    equals(other) {
      if (this === other) return true;
      if (other === null || this.constructor !== other.constructor) return false;
      return this.flagsInput === other.flagsInput && this.patternInput === other.patternInput;
    }
  };

  // src/core/filters/engine.js
  var WORD = "[\\p{L}\\p{N}_]";
  var SPECIAL = /[.*+?^${}()|[\]\\]/g;
  var RE_FLAGS = RE2JS.CASE_INSENSITIVE | RE2JS.LOOKBEHINDS;
  var NAMED_BACKREF = /(?:^|[^\\])(?:\\\\)*\\k</;
  function reasonFor(message) {
    const detail = String(message).replace(/^error parsing regexp: /, "");
    if (/Perl syntax: `\(\?[=!]/.test(detail)) return "looks ahead";
    if (/escape sequence: `\\[1-9]/.test(detail)) return "refers back to a group";
    if (detail.startsWith("invalid capture in lookbehind")) return "has a group inside a look-behind";
    if (/character class range: `\\[pP]/.test(detail)) return "uses an unknown \\p{...} name";
    if (/repeat count: `\{[^`]*\d{4}/.test(detail)) return "repeats more than 1000 times";
    return "isn't a valid pattern";
  }
  function regexFor(source) {
    if (NAMED_BACKREF.test(source)) throw new Error("refers back to a group");
    try {
      return RE2JS.compile(RE2JS.translateRegExp(source), RE_FLAGS);
    } catch (error) {
      throw new Error(reasonFor(error.message), { cause: error });
    }
  }
  function phraseRegex(phrase) {
    const body = phrase.split(" ").map((word) => word.replace(SPECIAL, "\\$&")).join("\\s+");
    return new RegExp(`(?<!${WORD})${body}(?!${WORD})`, "iu");
  }
  function compileFilters(text) {
    const rules = [];
    const errors = [];
    String(text ?? "").split(/\r?\n/).forEach((raw, index) => {
      const line = normalizeText(raw);
      if (!line || line === "#" || line.startsWith("# ")) return;
      if (/^re:/i.test(line)) {
        const source = line.slice(3).trim();
        if (!source) return;
        try {
          rules.push({ line: index + 1, phrase: line, re: regexFor(source) });
        } catch (error) {
          const message = error.cause?.message ?? error.message;
          errors.push({ line: index + 1, phrase: line, reason: error.message, message });
        }
        return;
      }
      rules.push({ line: index + 1, phrase: line, re: phraseRegex(line) });
    });
    return { rules, errors };
  }
  function firstMatch(rules, values) {
    if (!rules.length) return null;
    const clean6 = values.filter(Boolean).map(normalizeText);
    for (const rule of rules) {
      for (const value of clean6) if (rule.re.test(value)) return rule;
    }
    return null;
  }
  function matchingRules(rules, values) {
    if (!rules.length) return [];
    const clean6 = values.filter(Boolean).map(normalizeText);
    return rules.filter((rule) => clean6.some((value) => rule.re.test(value)));
  }
  function filterCache() {
    let text = null;
    let compiled = { rules: [], errors: [] };
    return (next) => {
      if (next !== text) {
        text = next;
        compiled = compileFilters(next);
      }
      return compiled;
    };
  }

  // src/core/filters/lists.js
  var nameKey = (value) => normalizeText(value).normalize("NFC").toLowerCase();
  function lines(text) {
    const out = [];
    String(text ?? "").split(/\r?\n/).forEach((raw, index) => {
      const line = normalizeText(raw);
      if (!line || line === "#" || line.startsWith("# ")) return;
      out.push({ line: index + 1, phrase: line });
    });
    return out;
  }
  var compileNames = (text) => lines(text).map((entry) => ({ ...entry, key: nameKey(entry.phrase) }));
  function siteKey(phrase) {
    const value = phrase.trim().replace(/^\*\./, "");
    if (!value || /\s/.test(value)) return null;
    let host2;
    try {
      host2 = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(value) ? value : `https://${value}`).hostname;
    } catch {
      return null;
    }
    host2 = host2.replace(/\.$/, "").replace(/^www\./, "");
    if (!host2.includes(".") || host2.startsWith("[") || /^[\d.]+$/.test(host2)) return null;
    return host2;
  }
  function compileSites(text) {
    const sites = [];
    const errors = [];
    for (const entry of lines(text)) {
      const key = siteKey(entry.phrase);
      if (key) sites.push({ ...entry, key });
      else errors.push({ ...entry, reason: "isn't a site name" });
    }
    return { sites, errors };
  }
  var siteMatches = (host2, key) => host2 === key || host2.endsWith(`.${key}`);
  var matchingNames = (entries, authors) => {
    if (!entries.length) return [];
    const keys = new Set(authors.map(nameKey));
    return entries.filter((entry) => keys.has(entry.key));
  };
  var matchingSites = (entries, hosts) => {
    if (!entries.length) return [];
    const clean6 = hosts.map((host2) => String(host2).toLowerCase());
    return entries.filter((entry) => clean6.some((host2) => siteMatches(host2, entry.key)));
  };

  // src/core/url.js
  var SHIM_HOSTS = /* @__PURE__ */ new Set(["l.facebook.com", "lm.facebook.com", "l.messenger.com"]);
  var ANY_HOST = /* @__PURE__ */ new Set([
    "fbclid",
    "mibextid",
    "fb_action_ids",
    "fb_action_types",
    "fb_ref",
    "fb_source",
    "action_object_map",
    "action_type_map",
    "action_ref_map"
  ]);
  var FACEBOOK_ONLY = /* @__PURE__ */ new Set([
    "sfnsn",
    "extid",
    "rdid",
    "share_url",
    "__tn__",
    "__so__",
    "__rv__",
    "_ft_",
    "refsrc",
    "fref",
    "refid",
    "pnref",
    "ls_ref",
    "hc_ref",
    "hc_location",
    "dti",
    "acontext",
    "action_history",
    "video_source",
    "comment_tracking",
    "m_entstream_source",
    "idorvanity",
    "paipv",
    "wtsid",
    "_rdr",
    "_rdc",
    "rdr",
    "rdc",
    "referral_story_type",
    "gd_impression_id",
    "external_ref",
    "store_visit_source"
  ]);
  var FACEBOOK_INDEXED = /^__(?:cft|xts)__\[\d+\]$/;
  function isFacebookHost(host2) {
    return /(^|\.)(facebook\.com|fb\.com|messenger\.com)$/i.test(host2) || /^(fb\.watch|fb\.me)$/i.test(host2);
  }
  function isCdnHost(host2) {
    return /(^|\.)fbcdn\.net$/i.test(host2);
  }
  function parse2(href, base) {
    try {
      const url2 = new URL(href, base);
      return url2.protocol === "http:" || url2.protocol === "https:" ? url2 : null;
    } catch {
      return null;
    }
  }
  function decode(text) {
    try {
      return decodeURIComponent(text.replace(/\+/g, " "));
    } catch {
      return text;
    }
  }
  function isTracking(key, value, facebook) {
    if (ANY_HOST.has(key)) return true;
    if (!facebook) return false;
    return FACEBOOK_ONLY.has(key) || FACEBOOK_INDEXED.test(key) || key === "ref" && value === "share";
  }
  function isOutbound(href) {
    const url2 = parse2(href);
    return Boolean(url2) && !isFacebookHost(url2.hostname) && !isCdnHost(url2.hostname);
  }
  function unshim(href, base) {
    const url2 = parse2(href, base);
    if (!url2) return null;
    const isShim = SHIM_HOSTS.has(url2.hostname) || isFacebookHost(url2.hostname) && url2.pathname === "/l.php";
    if (!isShim) return null;
    const target2 = parse2(url2.searchParams.get("u") ?? "");
    return target2 ? target2.href : null;
  }
  function stripTracking(href, facebook) {
    const hashAt = href.indexOf("#");
    const head = hashAt === -1 ? href : href.slice(0, hashAt);
    const hash = hashAt === -1 ? "" : href.slice(hashAt);
    const queryAt = head.indexOf("?");
    if (queryAt === -1) return href;
    let removed = false;
    const kept = head.slice(queryAt + 1).split("&").filter((part) => {
      if (!part) return false;
      const eq = part.indexOf("=");
      const key = decode(eq === -1 ? part : part.slice(0, eq));
      const value = eq === -1 ? "" : decode(part.slice(eq + 1));
      if (!isTracking(key, value, facebook)) return true;
      removed = true;
      return false;
    });
    if (!removed) return href;
    return head.slice(0, queryAt) + (kept.length ? `?${kept.join("&")}` : "") + hash;
  }
  function cleanUrl(href, { unwrap = true, base } = {}) {
    const current = unwrap && unshim(href, base) || href;
    const url2 = parse2(current, base);
    if (!url2 || isCdnHost(url2.hostname)) return current;
    return stripTracking(current, isFacebookHost(url2.hostname));
  }
  function cleanCopiedText(text) {
    if (typeof text !== "string") return text;
    const trimmed = text.trim();
    if (!/^https?:\/\/\S+$/i.test(trimmed)) return text;
    const cleaned = cleanUrl(trimmed);
    return cleaned === trimmed ? text : cleaned;
  }

  // src/core/filters/story.js
  var TEXT_HOLDERS = /* @__PURE__ */ new Set(["message", "title", "description", "title_with_entities"]);
  var LINK_KEYS = /* @__PURE__ */ new Set(["external_url", "url"]);
  var SKIP_KEYS = /* @__PURE__ */ new Set(["feedback", "comments_disabled_notice_renderer", "easy_hide_button_story", "tracking", "encrypted_tracking"]);
  var KINDS = /* @__PURE__ */ new Map([
    ["StoryAttachmentPhotoStyleRenderer", "photo"],
    ["StoryAttachmentAlbumStyleRenderer", "photo"],
    ["StoryAttachmentAlbumFrameStyleRenderer", "photo"],
    ["StoryAttachmentUnifiedLightweightVideoStyleRenderer", "video"],
    ["StoryAttachmentFBReelsStyleRenderer", "video"],
    ["StoryAttachmentVideoStyleRenderer", "video"],
    ["StoryAttachmentShareStyleRenderer", "link"]
  ]);
  var MAX_DEPTH = 40;
  function hostOf(href) {
    const target2 = unshim(href) ?? href;
    if (!isOutbound(target2)) return null;
    try {
      return new URL(target2).hostname.replace(/^www\./, "");
    } catch {
      return null;
    }
  }
  function storyFields(node) {
    const text = /* @__PURE__ */ new Set();
    const authors = /* @__PURE__ */ new Set();
    const alt = /* @__PURE__ */ new Set();
    const sites = /* @__PURE__ */ new Set();
    const kinds = /* @__PURE__ */ new Set();
    (function visit(value, key, parentKey, depth) {
      if (!value || typeof value !== "object" || depth > MAX_DEPTH) return;
      if (Array.isArray(value)) {
        for (const item of value) visit(item, key, parentKey, depth + 1);
        return;
      }
      if (TEXT_HOLDERS.has(key) && typeof value.text === "string") text.add(value.text);
      if ((key === "actors" || key === "to") && typeof value.name === "string") authors.add(value.name);
      if (typeof value.accessibility_caption === "string") alt.add(value.accessibility_caption);
      if (KINDS.has(value.__typename)) kinds.add(KINDS.get(value.__typename));
      if (key === "attached_story") kinds.add("shared");
      if (value.__typename === "Video" && (value.broadcast_status === "LIVE" || value.is_live_streaming === true || value.is_video_broadcast === true)) kinds.add("live");
      if (key === "text_format_metadata" && (value.background_color || value.preset_id || value.background_image)) kinds.add("colored");
      for (const [childKey, child2] of Object.entries(value)) {
        if (SKIP_KEYS.has(childKey)) continue;
        if (typeof child2 === "string") {
          if (LINK_KEYS.has(childKey) && /^https?:/i.test(child2)) {
            const host2 = hostOf(child2);
            if (host2) sites.add(host2);
          }
          continue;
        }
        visit(child2, childKey, key, depth + 1);
      }
    })(node, null, null, 0);
    return { text: [...text], authors: [...authors], alt: [...alt], sites: [...sites], kinds };
  }

  // src/core/filters/page.js
  var TEXT = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"], [data-ad-rendering-role="title"], [data-ad-rendering-role="description"]';
  var MESSAGE = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"]';
  var COMMENTS = '[role="article"][aria-label]';
  var PHOTO = 'a[href*="/photo"] img, a[href*="/photos/"] img';
  var VIDEO = 'video, a[href*="/reel/"], a[href*="/watch/"], a[href*="/videos/"]';
  var HEADER = '[data-ad-rendering-role="profile_name"]';
  var PAST_LIVE = 'a[href*="/watch/live/"]';
  var liveBadge = (element) => !element.firstElementChild && element.textContent.trim() === "LIVE" && !element.closest(MESSAGE);
  var inComment = (element, post) => {
    const comment = element.closest(COMMENTS);
    return Boolean(comment && comment !== post && post.contains(comment));
  };
  function postFields(post) {
    const own = (selector) => [...post.querySelectorAll(selector)].filter((element) => !inComment(element, post));
    const text = own(TEXT).map((element) => visibleText(element)).filter(Boolean);
    const authors = own('h2 a, h3 a, h4 a, [role="heading"] a').map((a) => normalizeText(a.textContent)).filter(Boolean);
    const alt = own("img[alt]").map((img) => img.getAttribute("alt")).filter((value) => value && value.length > 3);
    const links = own("a[href]");
    const sites = [...new Set(links.map((a) => hostOf(a.href || a.getAttribute("href"))).filter(Boolean))];
    const kinds = /* @__PURE__ */ new Set();
    if (own(PHOTO).length) kinds.add("photo");
    if (own(VIDEO).length) kinds.add("video");
    if (links.some((a) => hostOf(a.href || a.getAttribute("href")) && !a.closest(MESSAGE))) kinds.add("link");
    if (own(HEADER).length > 1) kinds.add("shared");
    const badge = () => [...post.querySelectorAll("span, div")].some((element) => liveBadge(element) && !inComment(element, post));
    if (own(PAST_LIVE).length || own("video").length && badge()) kinds.add("live");
    return { text, authors, alt, sites, kinds };
  }

  // src/core/css-text.js
  var DECLARATION = /^[ \t]*-?[a-z][a-z-]*[ \t]*:[ \t]*[^:;{}\n]+;[ \t]*$/m;
  var PSEUDO = /^[ \t]*[^\s:]*:(?:(?:has|not|is|where|nth-child)\(|(?:first|last)-child\b)/im;
  function hasRule(text) {
    let start = 0;
    for (let i = 0; i < text.length; i += 1) {
      const char = text[i];
      if (char === "\n" || char === "}") start = i + 1;
      if (char !== "{") continue;
      const selector = /\S/.test(text.slice(start, i));
      let colon = false;
      let j = i + 1;
      start = j;
      for (; j < text.length && text[j] !== "{" && text[j] !== "}"; j += 1) {
        if (text[j] === ":") colon = true;
        else if (text[j] === "\n") start = j + 1;
      }
      if (selector && colon && text[j] === "}") return true;
      i = j - 1;
    }
    return false;
  }
  function looksLikeCss(text) {
    const value = String(text ?? "");
    return hasRule(value) || DECLARATION.test(value) || PSEUDO.test(value);
  }

  // src/features/feed/filters.js
  var CSS_WARNING = "Those filter lines look like CSS. Hide posts by words matches words in posts, so put CSS in Custom CSS under Appearance instead.";
  var CSS_WARNED_KEY = "hidePostsByWords.cssWarned";
  var SKIP_WARNED_KEY = "hidePostsByWords.skipWarned";
  var SITES_WARNED_KEY = "hidePostsByWords.sitesWarned";
  function skipNotice(errors) {
    if (errors.length === 1) return t("Filter line {line} is skipped because it {reason}.", { line: errors[0].line, reason: t(errors[0].reason) });
    const lines2 = errors.map((error) => error.line);
    const named2 = lines2.length > 4 ? [...lines2.slice(0, 3), t("{count} more", { count: lines2.length - 3 })] : lines2;
    return t("Filter lines {lines} and {last} are skipped. Diagnostics says why.", { lines: named2.slice(0, -1).join(", "), last: named2.at(-1) });
  }
  function siteNotice(errors) {
    if (errors.length === 1) return t("Line {line} of the {list} list isn't a site name, so it's skipped.", { line: errors[0].line, list: t(errors[0].list) });
    return t("{count} lines in your site lists aren't site names, so they're skipped. Diagnostics names them.", { count: errors.length });
  }
  var plainLines = (text) => String(text ?? "").split(/\r?\n/).filter((line) => !/^\s*(?:re:|#(?:\s|$))/i.test(line)).join("\n");
  function fingerprint(text) {
    let hash = 2166136261;
    for (let i = 0; i < text.length; i += 1) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619) >>> 0;
    return `${text.length}:${hash.toString(16)}`;
  }
  var KINDS2 = [
    { key: "photos", kind: "photo", label: "photo posts" },
    { key: "videos", kind: "video", label: "video posts" },
    { key: "links", kind: "link", label: "link posts" },
    { key: "colored", kind: "colored", label: "colored background posts" },
    { key: "shared", kind: "shared", label: "shared posts" },
    { key: "live", kind: "live", label: "live videos" }
  ];
  var FILTERED = {
    queries: /^(?:CometNewsFeedPaginationQuery|GroupsCometCrossGroupFeedPaginationQuery|GroupsCometFeedRegularStoriesPaginationQuery)$/,
    routes: (route) => Boolean(route) && !route.permalink && (route.type === "home" || route.type === "groups")
  };
  var valuesOf = (fields2) => [...fields2.text, ...fields2.authors, ...fields2.alt, ...fields2.sites];
  var lineId = (list, entry) => `${list === "words" ? "" : `${list} `}line ${entry.line}`;
  var shown2 = ({ showPeople = [], showSites = [] }, fields2) => matchingNames(showPeople, fields2.authors).length > 0 || matchingSites(showSites, fields2.sites).length > 0;
  function filterVerdict(filter, fields2) {
    if (shown2(filter, fields2)) return null;
    const { rules, kinds, people = [], sites = [] } = filter;
    for (const { kind, label } of KINDS2) if (kinds.has(kind) && fields2.kinds.has(kind)) return label;
    const match = matchingNames(people, fields2.authors)[0] ?? matchingSites(sites, fields2.sites)[0] ?? firstMatch(rules, valuesOf(fields2));
    return match?.phrase ?? null;
  }
  function filterMatches(filter, fields2) {
    if (shown2(filter, fields2)) return [];
    const { rules, kinds, people = [], sites = [] } = filter;
    return [
      ...KINDS2.filter(({ kind }) => kinds.has(kind) && fields2.kinds.has(kind)).map(({ label }) => label),
      ...matchingNames(people, fields2.authors).map((entry) => lineId("people", entry)),
      ...matchingSites(sites, fields2.sites).map((entry) => lineId("sites", entry)),
      ...matchingRules(rules, valuesOf(fields2)).map((rule) => lineId("words", rule))
    ];
  }
  var phrasesOf = ({ rules, people = [], sites = [] }) => new Map([
    ...rules.map((rule) => [lineId("words", rule), rule.phrase]),
    ...people.map((entry) => [lineId("people", entry), entry.phrase]),
    ...sites.map((entry) => [lineId("sites", entry), entry.phrase])
  ]);
  function eachStory(doc, visit) {
    walk(doc, (value) => {
      if (Array.isArray(value) || !("cursor" in value) || !value.node || typeof value.node !== "object") return void 0;
      if (value.node.__typename !== "Story" && !value.node.__isFeedUnit) return void 0;
      visit(value);
      return SKIP;
    });
  }
  function pruneFiltered(doc, filter, report) {
    const hits = [];
    eachStory(doc, (edge) => {
      const reason = filterVerdict(filter, storyFields(edge.node));
      if (reason === null) return;
      report?.(edge.node, reason);
      delete edge.node;
      delete edge.rendering_strategy;
      hits.push(reason);
    });
    return hits;
  }
  function previewFiltered(doc, filter, see) {
    eachStory(doc, (edge) => see(edge.node.post_id ?? edge.node.id ?? null, filterMatches(filter, storyFields(edge.node))));
  }
  var PREVIEW_LIMIT = 1e3;
  function createPreviewTally(limit = PREVIEW_LIMIT) {
    const posts = /* @__PURE__ */ new Map();
    return {
      see(key, matches) {
        let ids = posts.get(key);
        if (!ids) {
          if (posts.size >= limit) return;
          ids = /* @__PURE__ */ new Set();
          posts.set(key, ids);
        }
        for (const id of matches) ids.add(id);
      },
      clear: () => posts.clear(),
      size: () => posts.size,
      summary() {
        const counts = /* @__PURE__ */ new Map();
        let matched = 0;
        for (const ids of posts.values()) {
          if (ids.size) matched += 1;
          for (const id of ids) counts.set(id, (counts.get(id) ?? 0) + 1);
        }
        return { checked: posts.size, full: posts.size >= limit, matched, counts: [...counts].sort((a, b) => b[1] - a[1]) };
      }
    };
  }
  var FUSE_MIN = 6;
  var FUSE_SHARE = 0.8;
  var FUSE_WINDOW = 200;
  var FUSE_KEPT_KEY = "hidePostsByWords.fuseKept";
  var FUSE_KEPT_LIMIT = 50;
  var fusible = (id) => /^(?:sites )?line \d+$/.test(id);
  function createFilterFuse({ min = FUSE_MIN, share = FUSE_SHARE, kept = () => false, window = FUSE_WINDOW } = {}) {
    const layers = { data: createPreviewTally(window), page: createPreviewTally(window) };
    const paused = /* @__PURE__ */ new Map();
    return {
      paused,
      counting: (layer) => layers[layer].size() < window,
      see(layer, key, matches) {
        layers[layer].see(key, matches.filter(fusible));
      },
      // Pauses each line that now matches too much on one layer, and returns the ids it paused.
      trip() {
        const fresh = [];
        for (const [layer, tally4] of Object.entries(layers)) {
          const { checked, counts } = tally4.summary();
          if (checked < min) continue;
          for (const [id, matched] of counts) {
            if (matched < checked * share || paused.has(id) || kept(id)) continue;
            paused.set(id, { layer, matched, checked });
            fresh.push(id);
          }
        }
        return fresh;
      },
      clear() {
        layers.data.clear();
        layers.page.clear();
        paused.clear();
      }
    };
  }
  function fuseNotice(id, phrase, { matched, checked }) {
    const line = Number(id.match(/\d+$/)[0]);
    const values = { line, phrase: shortPhrase(phrase), matched, checked };
    return id.startsWith("sites ") ? t(`Line {line} of your site list, "{phrase}", matched {matched} of the {checked} posts here, so it's paused on this page.`, values) : t(`Filter line {line}, "{phrase}", matched {matched} of the {checked} posts here, so it's paused on this page.`, values);
  }
  function fuseReport(paused) {
    if (!paused.size) return "None";
    return [...paused].map(([id, { layer, matched, checked }]) => `${id} (${layer}: ${matched} of ${checked})`).join(", ");
  }
  var MAX_NAMED = 8;
  var shortPhrase = (phrase) => phrase.length > 30 ? `${phrase.slice(0, 29)}...` : phrase;
  var STORIES = ["story", "stories"];
  var POSTS2 = ["post", "posts"];
  function layerText(summary4, [one, many], phraseOf) {
    if (!summary4.checked) return `no ${many} checked yet`;
    const checked = summary4.full ? `${summary4.checked}+ ${many}` : `${summary4.checked} ${summary4.checked === 1 ? one : many}`;
    if (!summary4.matched) return `no matches in ${checked}`;
    const named2 = summary4.counts.slice(0, MAX_NAMED).map(([id, n]) => {
      const phrase = phraseOf(id);
      return phrase ? `${id} "${shortPhrase(phrase)}" ${n}` : `${id} ${n}`;
    });
    const more = summary4.counts.length > MAX_NAMED ? `, and ${summary4.counts.length - MAX_NAMED} more` : "";
    return `${summary4.matched} of ${checked} ${summary4.matched === 1 ? "matches" : "match"} (${named2.join(", ")}${more})`;
  }
  function previewStatus({ data, page, filter, active: active2 }) {
    if (!active2) return "Preview is on. Add a line to a list or turn on a kind of post to see what it would hide.";
    const phrases = phrasesOf(filter);
    const phraseOf = (id) => phrases.get(id) ?? null;
    const parts = [];
    if (data) parts.push(`In Facebook's data, ${layerText(data, STORIES, phraseOf)}.`);
    if (page) parts.push(`On the page, ${layerText(page, POSTS2, phraseOf)}.`);
    const seen = (data?.checked ?? 0) + (page?.checked ?? 0);
    const matched = (data?.matched ?? 0) + (page?.matched ?? 0);
    const next = !seen ? "Open Home or a group and scroll a little." : matched ? "Turn Preview off to hide them." : "";
    return ["Preview is on, so nothing is hidden.", ...parts, next].filter(Boolean).join(" ");
  }
  function previewReport({ data, page }) {
    const none = () => null;
    return [data ? `data: ${layerText(data, STORIES, none)}` : null, page ? `page: ${layerText(page, POSTS2, none)}` : null].filter(Boolean).join(", ");
  }
  var OPTIONS = [
    { key: "words", type: "text", label: "One word, name or site per line. Start a line with re: to use a regular expression.", default: "", maxLength: 2e4 },
    { key: "people", type: "text", label: "Hide posts by these people, Pages or groups. One name per line, written the way Facebook shows it. A name only matches who posted, and names aren't unique, so it hides everyone who goes by it.", default: "", maxLength: 2e4 },
    { key: "sites", type: "text", label: "Hide posts that link to these sites. One site per line, like news.example. Its subdomains count too.", default: "", maxLength: 2e4 },
    { key: "showPeople", type: "text", label: "Always show posts by these people, Pages or groups, even when something here would hide them. One name per line.", default: "", maxLength: 2e4 },
    { key: "showSites", type: "text", label: "Always show posts that link to these sites, even when something here would hide them. One site per line.", default: "", maxLength: 2e4 },
    ...KINDS2.map(({ key, label }) => ({ key, type: "toggle", label: `Hide all ${label}`, default: false })),
    { key: "preview", type: "toggle", label: "Preview: count what each line would hide, and hide nothing", default: false }
  ];
  var tally2 = (map, key) => map.set(key, (map.get(key) ?? 0) + 1);
  function memo(build) {
    let text = null;
    let value = null;
    return (next) => {
      if (next !== text) {
        text = next;
        value = build(next);
      }
      return value;
    };
  }
  var summary3 = (map) => map.size ? [...map].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, n]) => `${name} ${n}`).join(", ") : "None yet";
  var filters_default = {
    id: "hidePostsByWords",
    section: "feed",
    android: "Hide posts by words",
    title: "Hide posts by words",
    description: "Hides posts that mention the words, people, Pages or sites you list, on Home and in groups. Posts you open by their link always show.",
    default: false,
    options: OPTIONS,
    setup({ net, router, posts, hider, log, toast, storage, settings, diagnostics, actions, enabled, option }) {
      const compile = filterCache();
      const warned = /* @__PURE__ */ new Set();
      let checked = null;
      let checkedSites = null;
      const checkSites = () => {
        const text = JSON.stringify([option("sites") ?? "", option("showSites") ?? ""]);
        if (text === checkedSites) return;
        checkedSites = text;
        const { siteErrors } = current();
        const print = fingerprint(text);
        if (!siteErrors.length || storage?.get(SITES_WARNED_KEY, null) === print) return;
        storage?.set(SITES_WARNED_KEY, print);
        toast?.(siteNotice(siteErrors), { tone: "error" });
      };
      const checkList = () => {
        if (!enabled()) return;
        checkSites();
        const words = option("words") ?? "";
        if (words === checked) return;
        checked = words;
        const print = fingerprint(words);
        const { errors } = current();
        if (errors.length && storage?.get(SKIP_WARNED_KEY, null) !== print) {
          storage?.set(SKIP_WARNED_KEY, print);
          toast?.(skipNotice(errors), { tone: "error" });
        }
        if (!looksLikeCss(plainLines(words))) return;
        if (storage?.get(CSS_WARNED_KEY, null) === print) return;
        storage?.set(CSS_WARNED_KEY, print);
        log?.warn(CSS_WARNING);
        toast?.(t(CSS_WARNING), { tone: "error" });
      };
      const hits = /* @__PURE__ */ new Map();
      const route = () => router?.current();
      const changed = () => diagnostics?.changed();
      const lists = {
        people: memo(compileNames),
        showPeople: memo(compileNames),
        sites: memo(compileSites),
        showSites: memo(compileSites)
      };
      function current() {
        const { rules, errors } = compile(option("words") ?? "");
        for (const error of errors) {
          if (warned.has(error.phrase)) continue;
          warned.add(error.phrase);
          log?.warn(`Filter line ${error.line} is skipped because it ${error.reason}. It stays in your list as you wrote it`, error.message);
        }
        const sites = lists.sites(option("sites") ?? "");
        const showSites = lists.showSites(option("showSites") ?? "");
        const siteErrors = [...sites.errors.map((error) => ({ ...error, list: "sites" })), ...showSites.errors.map((error) => ({ ...error, list: "always-show sites" }))];
        for (const error of siteErrors) {
          const seen = `${error.list}
${error.phrase}`;
          if (warned.has(seen)) continue;
          warned.add(seen);
          log?.warn(`Line ${error.line} of the ${error.list} list is skipped because it ${error.reason}`);
        }
        const kinds = new Set(KINDS2.filter(({ key }) => option(key) === true).map(({ kind }) => kind));
        return {
          rules,
          kinds,
          errors,
          siteErrors,
          people: lists.people(option("people") ?? ""),
          sites: sites.sites,
          showPeople: lists.showPeople(option("showPeople") ?? ""),
          showSites: showSites.sites
        };
      }
      const active2 = (filter) => filter.rules.length > 0 || filter.kinds.size > 0 || filter.people.length > 0 || filter.sites.length > 0;
      const previewing = () => option("preview") === true;
      const preview = { data: net ? createPreviewTally() : null, page: posts && hider ? createPreviewTally() : null };
      const summaries = () => ({ data: preview.data?.summary() ?? null, page: preview.page?.summary() ?? null });
      const keptHere = /* @__PURE__ */ new Set();
      const keptPrints = () => {
        const saved = storage?.get(FUSE_KEPT_KEY, []);
        return Array.isArray(saved) ? saved : [];
      };
      const printOf = (id, phrase = phrasesOf(current()).get(id)) => phrase === void 0 ? null : fingerprint(`${id.startsWith("sites ") ? "sites" : "words"}
${phrase}`);
      const fuse = createFilterFuse({
        kept: (id) => {
          const print = printOf(id);
          return print !== null && (keptHere.has(print) || keptPrints().includes(print));
        }
      });
      const fusing = (filter) => filter.rules.length > 0 || filter.sites.length > 0;
      const unpaused = (filter) => fuse.paused.size ? {
        ...filter,
        rules: filter.rules.filter((rule) => !fuse.paused.has(lineId("words", rule))),
        sites: filter.sites.filter((entry) => !fuse.paused.has(lineId("sites", entry)))
      } : filter;
      const pageOf = (now = route()) => now ? `${now.type}:${now.path}:${now.feed}` : "";
      let fusePage = null;
      const fuseHere = () => {
        const now = route();
        if (!FILTERED.routes(now) || pageOf(now) === fusePage) return;
        fusePage = pageOf(now);
        fuse.clear();
      };
      const pausedHere = () => fuse.paused.size > 0 && pageOf() === fusePage;
      const tripHere = () => {
        const fresh = fuse.trip();
        const phrases = phrasesOf(current());
        for (const id of fresh) {
          const phrase = phrases.get(id) ?? "";
          Object.assign(fuse.paused.get(id), { phrase, print: printOf(id, phrase) });
        }
        return fresh;
      };
      let recheck = null;
      function keep(print) {
        if (print === null) return;
        keptHere.add(print);
        storage?.set(FUSE_KEPT_KEY, [...keptPrints().filter((saved) => saved !== print), print].slice(-FUSE_KEPT_LIMIT));
        for (const [id, entry] of fuse.paused) {
          if (entry.print === print) fuse.paused.delete(id);
        }
        recheck?.();
        changed();
      }
      function tripped(ids) {
        for (const id of ids) {
          const counts = fuse.paused.get(id);
          if (!counts) continue;
          log?.warn(`Filter ${id} matched ${counts.matched} of ${counts.checked} posts on this page (${counts.layer}), so it's paused here`);
          toast?.(fuseNotice(id, counts.phrase, counts), { tone: "error", duration: 15e3, actions: [{ label: "Keep hiding", run: () => keep(counts.print) }] });
        }
        recheck?.();
        changed();
      }
      if (net) {
        const scope = { scope: FILTERED };
        const markers = ['"__isFeedUnit"'];
        const match = (ctx) => ctx.transport === "json-parse" || ctx.path.startsWith("/api/graphql");
        net.transformResponses({
          id: "hidePostsByWords",
          enabled,
          markers,
          match,
          transform(doc, ctx, stage) {
            if (previewing() || !inScope(scope, ctx, route)) return false;
            const filter = current();
            if (!active2(filter)) return false;
            if (fusing(filter)) {
              fuseHere();
              if (fuse.counting("data")) {
                previewFiltered(doc, filter, (id, matches) => {
                  if (id !== null) fuse.see("data", String(id), matches);
                });
                const fresh = tripHere();
                if (fresh.length) {
                  stage?.undo(() => {
                    for (const id of fresh) fuse.paused.delete(id);
                  });
                  later(stage, () => tripped(fresh));
                }
              }
            }
            const live = unpaused(filter);
            if (!active2(live)) return false;
            const decisions = [];
            const reasons = pruneFiltered(doc, live, (story, reason) => decisions.push({ post: story.post_id ?? story.id, rule: "Filter", detail: reason, layer: "data" }));
            if (!reasons.length) return false;
            later(stage, () => {
              for (const decision of decisions) diagnostics?.decide(decision);
              for (const reason of reasons) tally2(hits, reason);
              changed();
            });
            return true;
          }
        });
        net.transformResponses({
          id: "hidePostsByWords.preview",
          enabled: () => enabled() && previewing(),
          markers,
          match,
          observe: true,
          transform(doc, ctx) {
            if (!previewing() || !inScope(scope, ctx, route)) return false;
            const filter = current();
            if (!active2(filter)) return false;
            previewFiltered(doc, filter, (id, matches) => {
              if (id !== null) preview.data.see(String(id), matches);
            });
            changed();
            return false;
          }
        });
      }
      checkList();
      settings?.subscribe(checkList);
      diagnostics?.add("Posts hidden by your filters", () => summary3(hits));
      diagnostics?.add("Filter lines that aren't valid", () => {
        const { errors, siteErrors } = current();
        const named2 = [...errors.map((error) => `line ${error.line} (${error.reason})`), ...siteErrors.map((error) => `${error.list} line ${error.line} (${error.reason})`)];
        return named2.length ? named2.join(", ") : "None";
      });
      diagnostics?.add("Filter preview", () => enabled() && previewing() ? previewReport(summaries()) || "Nothing to count here" : "Off", { shareable: true });
      diagnostics?.add("Filter lines paused on this page", () => pausedHere() ? fuseReport(fuse.paused) : "None", { shareable: true });
      actions?.add(() => enabled() && pausedHere() ? "Keep hiding the paused lines" : "", () => {
        for (const { print } of [...fuse.paused.values()]) keep(print);
      });
      diagnostics?.status?.("hidePostsByWords", () => {
        if (!enabled()) return null;
        if (!previewing()) {
          if (!pausedHere()) return null;
          const named2 = [...fuse.paused].map(([id, { phrase }]) => `${id} "${shortPhrase(phrase)}"`);
          return `Paused on this page because it matched almost every post: ${named2.join(", ")}. Choose Keep hiding to hide by it anyway, or edit the line. Posts it hid before the pause come back on a reload.`;
        }
        const filter = current();
        return previewStatus({ ...summaries(), filter, active: active2(filter) });
      });
      const state = () => JSON.stringify([enabled(), ...OPTIONS.map(({ key }) => option(key))]);
      let last = state();
      settings?.subscribe(() => {
        const next = state();
        if (next === last) return;
        last = next;
        preview.data?.clear();
        preview.page?.clear();
        fuse.clear();
        recheck?.();
        changed();
      });
      if (!posts || !hider) return;
      const pageKeys2 = /* @__PURE__ */ new WeakMap();
      let nextKey = 0;
      const keyOf = (element) => {
        if (!pageKeys2.has(element)) pageKeys2.set(element, ++nextKey);
        return pageKeys2.get(element);
      };
      const watcher = watchPostChecks({
        posts,
        enabled,
        check(element) {
          if (!FILTERED.routes(route())) return true;
          const filter = current();
          if (!active2(filter)) return true;
          if (previewing()) {
            preview.page.see(keyOf(element), filterMatches(filter, postFields(element)));
            changed();
            return false;
          }
          const fields2 = postFields(element);
          if (fusing(filter)) {
            fuseHere();
            if (fuse.counting("page")) {
              fuse.see("page", keyOf(element), filterMatches(filter, fields2));
              const fresh = tripHere();
              if (fresh.length) queueMicrotask(() => tripped(fresh));
            }
          }
          const reason = filterVerdict(unpaused(filter), fields2);
          if (reason === null) return false;
          if (hider.hide(element, "Filter", reason)) {
            tally2(hits, reason);
            changed();
          }
          return true;
        }
      });
      recheck = () => {
        hider.showAll("Filter");
        if (enabled()) watcher.recheckAll();
      };
    }
  };

  // src/core/dom/seen-watch.js
  var SEEN_AFTER_MS = 1e3;
  var THRESHOLDS = Array.from({ length: 51 }, (_, i) => i / 50);
  function halfShown(entry, screenHeight) {
    if (!entry.isIntersecting) return false;
    const shown4 = entry.intersectionRect.height;
    const tall = entry.boundingClientRect.height;
    const screen = entry.rootBounds?.height || screenHeight;
    return shown4 > 0 && shown4 >= Math.min(tall, screen) / 2;
  }
  function watchSeen({ posts, win, active: active2, onSeen, snapshot, minMs = SEEN_AFTER_MS, now = () => win.performance.now() }) {
    const Observer = win?.IntersectionObserver;
    if (!posts || typeof Observer !== "function") return { stop() {
    }, flush() {
    }, update() {
    } };
    const doc = win.document;
    const since = /* @__PURE__ */ new Map();
    const showing = /* @__PURE__ */ new Set();
    const records = /* @__PURE__ */ new Map();
    const counts = () => active2() && doc?.visibilityState !== "hidden";
    let counting = counts();
    function leave(element, ending = false) {
      const shown4 = since.get(element);
      since.delete(element);
      if (shown4 === void 0 || !ending && !counts() || now() - shown4.start < minMs) return;
      const post = records.get(element);
      if (post) onSeen(post, shown4.taken);
    }
    function start(element) {
      const post = records.get(element);
      since.set(element, { start: now(), taken: post && snapshot ? snapshot(post) : void 0 });
    }
    const observer = new Observer((entries) => {
      for (const entry of entries) {
        if (halfShown(entry, win.innerHeight)) {
          showing.add(entry.target);
          if (!since.has(entry.target) && counts()) start(entry.target);
        } else {
          showing.delete(entry.target);
          leave(entry.target);
        }
      }
    }, { threshold: THRESHOLDS });
    function add(post) {
      records.set(post.element, post);
      observer.observe(post.element);
    }
    function remove({ element }) {
      leave(element);
      showing.delete(element);
      records.delete(element);
      observer.unobserve(element);
    }
    function flush() {
      for (const element of [...since.keys()]) leave(element, true);
    }
    function update() {
      const next = counts();
      if (next === counting) return;
      counting = next;
      if (!next) flush();
      else for (const element of showing) if (!since.has(element)) start(element);
    }
    const stops = [
      posts.on("post/add", add),
      posts.on("post/remove", remove),
      posts.on("reset", () => {
        since.clear();
        showing.clear();
        records.clear();
      })
    ];
    win.addEventListener?.("pagehide", flush);
    doc?.addEventListener?.("visibilitychange", update);
    return {
      flush,
      update,
      stop() {
        for (const stop of stops) stop();
        observer.disconnect();
        win.removeEventListener?.("pagehide", flush);
        doc?.removeEventListener?.("visibilitychange", update);
        since.clear();
        showing.clear();
        records.clear();
      }
    };
  }

  // src/core/seen-keys.js
  var TEXT_LENGTH = 48;
  var MIN_LETTERS = 24;
  var MEDIA_LINKS = [
    /[?&]fbid=(\d{6,})/,
    /\/photos\/[^/?#]+\/(\d{6,})/,
    /\/reels?\/(\d{6,})/,
    /\/videos\/(?:[^/?#]+\/)?(\d{6,})/,
    /\/watch\/?\?(?:[^#]*&)?v=(\d{6,})/
  ];
  var MEDIA_TYPES = /* @__PURE__ */ new Set(["Photo", "Video"]);
  var MESSAGE2 = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"]';
  var TITLE = '[data-ad-rendering-role="title"]';
  var HEADINGS = 'h1, h2, h3, h4, h5, h6, [role="heading"]';
  var COMMENTS2 = '[role="article"][aria-label]';
  var SKIP_KEYS2 = /* @__PURE__ */ new Set(["feedback", "comments_disabled_notice_renderer", "tracking", "encrypted_tracking"]);
  function fnv(text, seed) {
    let hash = seed >>> 0;
    for (let i = 0; i < text.length; i++) {
      hash ^= text.charCodeAt(i);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return hash.toString(36);
  }
  var squash = (text) => normalizeText(text).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
  function textKey(text) {
    const letters = squash(text);
    if (letters.length < MIN_LETTERS) return null;
    const start = letters.slice(0, TEXT_LENGTH);
    return `t:${fnv(start, 2166136261)}${fnv(start, 3735928559)}`;
  }
  function mediaIdOf(href) {
    for (const re of MEDIA_LINKS) {
      const found = String(href ?? "").match(re);
      if (found) return found[1];
    }
    return null;
  }
  function pageKeys(post) {
    const keys = /* @__PURE__ */ new Set();
    for (const a of ownLinks(post)) {
      if (a.closest(MESSAGE2) || a.closest(HEADINGS)) continue;
      const id = mediaIdOf(a.getAttribute("href"));
      if (id) keys.add(`m:${id}`);
    }
    const first = (selector) => [...post.querySelectorAll(selector)].find((element) => {
      const comment = element.closest(COMMENTS2);
      return !comment || comment === post || !post.contains(comment);
    });
    const holder = first(MESSAGE2) ?? first(TITLE);
    if (holder) {
      const text = visibleText(holder, (element) => !element.closest('[role="button"]'));
      const key = textKey(text);
      if (key) keys.add(key);
    }
    return [...keys];
  }
  var textOf2 = (holder) => typeof holder?.text === "string" && holder.text ? holder.text : null;
  var messageOf = (story) => textOf2(story?.message) ?? textOf2(story?.comet_sections?.message?.story?.message) ?? textOf2(story?.comet_sections?.message_container?.story?.message);
  function storyText(node) {
    const content = node?.comet_sections?.content?.story ?? node;
    const own = messageOf(content) ?? messageOf(node);
    if (own) return own;
    const shared = messageOf(content?.attached_story) ?? messageOf(node?.attached_story);
    if (shared) return shared;
    return storyFields({ attachments: content?.attachments ?? node?.attachments }).text[0] ?? null;
  }
  function storyKeys(node) {
    const keys = /* @__PURE__ */ new Set();
    (function visit(value, depth, attached) {
      if (!value || typeof value !== "object" || depth > 40) return;
      if (Array.isArray(value)) {
        for (const item of value) visit(item, depth + 1, attached);
        return;
      }
      if (attached && MEDIA_TYPES.has(value.__typename) && typeof value.id === "string" && /^\d{6,}$/.test(value.id)) keys.add(`m:${value.id}`);
      for (const [key2, child2] of Object.entries(value)) {
        if (!SKIP_KEYS2.has(key2)) visit(child2, depth + 1, attached || key2 === "attachments");
      }
    })(node, 0, false);
    const key = textKey(storyText(node));
    if (key) keys.add(key);
    return [...keys];
  }

  // src/features/feed/hide-seen-posts.js
  var DAY3 = 24 * 60 * 60 * 1e3;
  var DAYS = [1, 3, 7, 30];
  var SHOW_KEY = "hfw.showSeen";
  var matchedBy = (key) => key.startsWith("m:") ? "same photo or video" : "same text";
  function pruneSeen(doc, isSeen, report) {
    let dropped = 0;
    walk(doc, (value) => {
      if (Array.isArray(value) || !("cursor" in value) || !value.node || typeof value.node !== "object") return void 0;
      if (value.node.__typename !== "Story" && !value.node.__isFeedUnit) return void 0;
      const key = storyKeys(value.node).find(isSeen);
      if (key === void 0) return SKIP;
      report?.(value.node, key);
      delete value.node;
      delete value.rendering_strategy;
      dropped++;
      return SKIP;
    });
    return dropped;
  }
  function tabFlag(win) {
    return {
      get() {
        try {
          return win?.sessionStorage?.getItem(SHOW_KEY) === "1";
        } catch {
          return false;
        }
      },
      set(on) {
        try {
          if (on) win.sessionStorage.setItem(SHOW_KEY, "1");
          else win.sessionStorage.removeItem(SHOW_KEY);
        } catch {
        }
      }
    };
  }
  var hide_seen_posts_default = {
    id: "hideSeenPosts",
    section: "feed",
    android: "Hide seen posts",
    title: "Hide seen posts",
    description: "Hides posts on Home and in your groups feed that you've already scrolled past. A post counts as seen after a second on screen, and it's recognized by its photo or video, or by its first words.",
    default: false,
    options: [
      {
        key: "days",
        type: "select",
        label: "Keep seen posts hidden for",
        default: 7,
        choices: DAYS.map((n) => ({ value: n, label: n === 1 ? "1 day" : `${n} days` }))
      }
    ],
    setup({ win, net, router, posts, hider, storage, actions, diagnostics, settings, log, enabled, option, now = Date.now }) {
      const store = createSeenStore({ storage, log, now });
      const flag = tabFlag(win);
      const route = () => router?.current();
      const changed = () => diagnostics?.changed();
      const days = () => DAYS.includes(Number(option("days"))) ? Number(option("days")) : 7;
      let showing = flag.get();
      let before = /* @__PURE__ */ new Set();
      let until = now();
      const refresh = (moment = now()) => {
        until = moment;
        before = store.since(now() - days() * DAY3, until);
      };
      refresh();
      const isSeen = (key) => before.has(key);
      const hiding = () => enabled() && !showing && before.size > 0;
      let dropped = 0;
      let hidden = 0;
      if (net) {
        const scope = { scope: FILTERED };
        net.transformResponses({
          id: "hideSeenPosts",
          enabled: hiding,
          markers: ['"__isFeedUnit"'],
          match: (ctx) => ctx.transport === "json-parse" || ctx.path.startsWith("/api/graphql"),
          transform(doc, ctx, stage) {
            if (!inScope(scope, ctx, route)) return false;
            const decisions = [];
            const count = pruneSeen(doc, isSeen, (story, key) => decisions.push({ post: story.post_id ?? story.id, rule: "Seen", signal: matchedBy(key), layer: "data" }));
            if (!count) return false;
            later(stage, () => {
              for (const decision of decisions) diagnostics?.decide(decision);
              dropped += count;
              changed();
            });
            return true;
          }
        });
      }
      diagnostics?.add("Seen posts remembered", () => String(store.size()));
      diagnostics?.add("Seen posts hidden", () => {
        if (showing) return "None: showing them in this tab";
        return net ? `${dropped} taken out of the data, ${hidden} hidden on the page` : `${hidden} hidden on the page`;
      });
      let watcher = null;
      let seenWatch = null;
      if (posts && win) {
        seenWatch = watchSeen({
          posts,
          win,
          active: () => enabled() && FILTERED.routes(route()),
          now,
          // Read when the post starts showing, in case Facebook puts another story in its place.
          snapshot: (post) => pageKeys(post.element),
          onSeen(post, keys) {
            if (store.add(keys?.length ? keys : pageKeys(post.element))) changed();
          }
        });
        win.addEventListener?.("pagehide", () => store.flush());
      }
      if (posts && hider) {
        watcher = watchPostChecks({
          posts,
          enabled: hiding,
          check(element) {
            if (!FILTERED.routes(route())) return true;
            const key = pageKeys(element).find(isSeen);
            if (key === void 0) return false;
            if (hider.hide(element, "Seen", void 0, matchedBy(key))) {
              hidden++;
              changed();
            }
            return true;
          }
        });
      }
      let inFeed = FILTERED.routes(route());
      router?.subscribe?.((current) => {
        seenWatch?.update();
        const inside2 = FILTERED.routes(current);
        if (inside2 && !inFeed) {
          refresh();
          if (hiding()) watcher?.recheckAll();
        }
        inFeed = inside2;
      });
      actions?.add(() => showing ? "Hide seen posts again" : "Show seen posts in this tab", () => {
        showing = !showing;
        flag.set(showing);
        if (showing) {
          hider?.showAll("Seen");
        } else {
          refresh();
          watcher?.recheckAll();
        }
        changed();
      });
      actions?.add("Forget all seen posts", () => {
        store.clear();
        before = /* @__PURE__ */ new Set();
        hider?.showAll("Seen");
        changed();
      });
      const state = () => JSON.stringify([enabled(), days()]);
      let last = state();
      settings?.subscribe(() => {
        seenWatch?.update();
        const next = state();
        if (next === last) return;
        last = next;
        refresh(until);
        hider?.showAll("Seen");
        if (hiding()) watcher?.recheckAll();
      });
      if (storage?.whenReady) {
        store.whenReady(() => {
          refresh(until);
          if (hiding()) watcher?.recheckAll();
        });
      }
      store.onDrop(() => {
        refresh(until);
        hider?.showAll("Seen");
        if (hiding()) watcher?.recheckAll();
        changed();
      });
    }
  };

  // src/features/feed/hide-ai-posts.js
  var hide_ai_posts_default = {
    id: "hideAiPosts",
    section: "feed",
    android: "Hide AI-detected posts",
    title: "Hide AI-detected posts",
    description: "Hides posts Facebook labels as made with AI, and shares of them, from Home, your groups feed and search results. It goes by the AI info label, whether Facebook detected it or the author added it.",
    default: false,
    needsPage: true,
    setup({ net, router, diagnostics, enabled }) {
      let dropped = 0;
      if (net) {
        net.transformResponses(adRule("hideAiPosts", enabled, (fired) => {
          dropped += fired.length;
          diagnostics?.changed();
        }, { route: () => router?.current(), diagnostics, reason: "AI label" }));
      }
      diagnostics?.add("AI-labeled posts taken out of the data", () => net ? String(dropped) : "Off: the script can't reach the page's data");
    }
  };

  // src/features/feed/post-dates.js
  var DATE_MARK = "data-hfw-post-date";
  var MARKERS = ['"comet_sections"'];
  var MAX_REMEMBERED = 4e3;
  var MESSAGE3 = '[data-ad-rendering-role="story_message"], [data-ad-preview="message"]';
  var HEADINGS2 = 'h1, h2, h3, h4, h5, h6, [role="heading"]';
  var POST_DATES_CSS = `[${DATE_MARK}] { margin-inline-start: 0.25em; white-space: nowrap; }`;
  var RELATIVE_FOR = 7 * 24 * 60 * 60;
  var shownAsRelative = (seconds, now = Date.now() / 1e3) => now - seconds < RELATIVE_FOR;
  function indexTimes(data, remember2) {
    let found = 0;
    (function visit(value, depth) {
      if (!value || typeof value !== "object" || depth > 80) return;
      if (Array.isArray(value)) {
        for (const item of value) visit(item, depth + 1);
        return;
      }
      if (Number.isFinite(value.creation_time) && value.creation_time > 0 && value.comet_sections && typeof value.comet_sections === "object") {
        for (const key of storyKeys(value)) remember2(key, value.creation_time);
        found++;
        return;
      }
      for (const child2 of Object.values(value)) visit(child2, depth + 1);
    })(data, 0);
    return found;
  }
  function createTimeBook({ max = MAX_REMEMBERED } = {}) {
    const times = /* @__PURE__ */ new Map();
    const shared = /* @__PURE__ */ new Map();
    const gone = /* @__PURE__ */ new Map();
    const add = (map, key, value) => {
      map.delete(key);
      map.set(key, value);
      if (map.size <= max) return null;
      const [oldest, time] = map.entries().next().value;
      map.delete(oldest);
      return [oldest, time];
    };
    return {
      remember(key, seconds) {
        if (shared.has(key)) {
          add(shared, key, true);
          return;
        }
        const before = times.has(key) ? times.get(key) : gone.get(key);
        gone.delete(key);
        if (before !== void 0 && before !== seconds) {
          times.delete(key);
          add(shared, key, true);
          return;
        }
        const dropped = add(times, key, seconds);
        if (dropped) add(gone, ...dropped);
      },
      // A post's time, by its first key that has one: a photo or video first, then its words.
      timeOf: (keys) => keys.map((key) => shared.has(key) ? null : times.get(key)).find((seconds) => typeof seconds === "number") ?? null
    };
  }
  function timeLinkOf(post) {
    return ownLinks(post).find((a) => a.hasAttribute("target") && !a.hasAttribute("rel") && !a.hasAttribute("aria-label") && !a.closest(MESSAGE3) && !a.closest(HEADINGS2) && !a.closest("object")) ?? null;
  }
  var ROW_LEVELS = 5;
  function dateSpot(link) {
    const view2 = link.ownerDocument?.defaultView;
    let item = link;
    for (let i = 0; i < ROW_LEVELS; i++) {
      const parent = item.parentElement;
      if (!parent || parent.matches('[aria-posinset], [role="article"]')) break;
      const display = view2?.getComputedStyle ? view2.getComputedStyle(parent).display : "";
      if (display === "flex" || display === "inline-flex") return item;
      item = parent;
    }
    return link;
  }
  function formatTime(seconds, lang) {
    const when = new Date(seconds * 1e3);
    try {
      return new Intl.DateTimeFormat(lang || void 0, { dateStyle: "medium", timeStyle: "short" }).format(when);
    } catch {
      return when.toLocaleString();
    }
  }
  function showDate(doc, post, seconds, lang = doc.documentElement?.lang, now = Date.now() / 1e3) {
    const link = timeLinkOf(post);
    const spot = link ? dateSpot(link) : null;
    const relative = seconds !== null && shownAsRelative(seconds, now);
    for (const old of post.querySelectorAll(`[${DATE_MARK}]`)) {
      if (old.previousElementSibling !== spot || !relative) old.remove();
    }
    if (seconds !== null && !relative) return true;
    if (!spot || seconds === null) return false;
    const value = String(seconds);
    const next = spot.nextElementSibling;
    if (next?.hasAttribute(DATE_MARK)) {
      if (next.getAttribute(DATE_MARK) !== value) {
        next.setAttribute(DATE_MARK, value);
        next.textContent = `· ${formatTime(seconds, lang)}`;
      }
      return true;
    }
    const span = doc.createElement("span");
    span.setAttribute(DATE_MARK, value);
    span.textContent = `· ${formatTime(seconds, lang)}`;
    spot.after(span);
    return true;
  }
  var post_dates_default = {
    id: "keepPostDates",
    section: "feed",
    android: "Keep post dates",
    title: "Show full post dates",
    description: `Each post shows the day and time it went up next to Facebook's short "3h" or "2d", so you don't have to point at it to find out.`,
    default: false,
    needsPage: true,
    css: POST_DATES_CSS,
    setup({ doc, net, posts, enabled, settings, diagnostics, now = () => Date.now() / 1e3 }) {
      const book = createTimeBook();
      net.transformResponses({
        id: "keepPostDates",
        enabled,
        markers: MARKERS,
        // Facebook parses its feed answers and the page's inline data with JSON.parse, so this
        // sees every story. It only reads.
        match: (ctx) => ctx.transport === "json-parse",
        observe: true,
        transform(data) {
          indexTimes(data, book.remember);
          return false;
        }
      });
      let shown4 = 0;
      const check = (element) => {
        const had = Boolean(element.querySelector(`[${DATE_MARK}]`));
        const done = showDate(doc, element, book.timeOf(pageKeys(element)), void 0, now());
        if (done && !had) {
          shown4++;
          diagnostics?.changed();
        }
        return done;
      };
      if (posts) {
        const watcher = watchPostChecks({ posts, enabled, check });
        posts.on("post/update", ({ element }) => {
          if (enabled()) check(element);
        });
        let on = enabled();
        settings?.subscribe(() => {
          if (enabled() === on) return;
          on = enabled();
          if (on) watcher.recheckAll();
          else for (const mark of doc.querySelectorAll(`[${DATE_MARK}]`)) mark.remove();
        });
      }
      diagnostics?.add("Post dates shown", () => String(shown4));
    }
  };

  // src/features/feed/keep-feed-place.js
  var CONSTANTS = "CometFeedStalenessConstantsEntryPointVariables";
  var ROUTES = "CometReturnToFeedRouteUtils";
  var LIMITS = ["FEED_STALE_TIMEOUT", "FEED_VISIBILITY_TIMEOUT", "FEED_STALE_PUSH_VIEW_TIMEOUT"];
  var NEVER = 2 ** 31 - 1;
  function holdLimits(exports, enabled) {
    if (!exports || typeof exports !== "object") return 0;
    let held = 0;
    for (const key of LIMITS) {
      const own = Object.getOwnPropertyDescriptor(exports, key);
      if (!own || !("value" in own) || !own.configurable || typeof own.value !== "number") continue;
      let value = own.value;
      Object.defineProperty(exports, key, {
        configurable: true,
        enumerable: own.enumerable,
        get: () => enabled() && typeof value === "number" ? NEVER : value,
        set: (next) => {
          value = next;
        }
      });
      held++;
    }
    return held;
  }
  function holdRouteCheck(exports, enabled) {
    const own = exports && typeof exports === "object" ? Object.getOwnPropertyDescriptor(exports, "isRouteEligible") : null;
    if (!own || typeof own.value !== "function" || !(own.writable || own.configurable)) return false;
    const original = own.value;
    const held = function isRouteEligible(...args) {
      return enabled() ? false : original.apply(this, args);
    };
    Object.defineProperty(exports, "isRouteEligible", { ...own, value: held });
    return true;
  }
  var WAITING = "Facebook's code isn't loaded yet";
  var keep_feed_place_default = {
    id: "keepFeedPlace",
    section: "feed",
    android: "Block background-return feed refresh",
    title: "Keep your place in the feed",
    description: "Facebook reloads Home from the top when you come back after a couple of minutes in another tab, or ten minutes away from the computer. After half an hour away it also moves you from a group, Marketplace or search to Home. With this on, you stay where you were.",
    default: false,
    needsPage: true,
    setup({ win, settings, enabled, diagnostics, log, markUnavailable }) {
      const state = { home: WAITING, pages: WAITING };
      let started = false;
      const start = () => {
        if (started || !enabled()) return;
        started = true;
        afterModuleRuns(win, CONSTANTS, (exports) => {
          const held = holdLimits(exports, enabled);
          state.home = held === LIMITS.length ? "held" : `${held} of ${LIMITS.length} limits held, Facebook's code has changed`;
          if (!held) {
            log?.warn("Keep your place in the feed couldn't find Facebook's feed refresh limits. Facebook's code has changed.");
            markUnavailable?.();
          }
          diagnostics?.changed();
        }, { log });
        whenModule(win, ROUTES, (exports) => {
          const held = holdRouteCheck(exports, enabled);
          state.pages = held ? "held" : "not held, Facebook's code has changed";
          if (!held) log?.warn("Keep your place in the feed couldn't find Facebook's return to Home check. Facebook's code has changed.");
          diagnostics?.changed();
        }, { log });
      };
      start();
      settings?.subscribe(start);
      diagnostics?.add("Return refresh on Home", () => started ? state.home : "switch off");
      diagnostics?.add("Return to Home from other pages", () => started ? state.pages : "switch off");
    }
  };

  // src/features/feed/hide-follow-buttons.js
  var MARK2 = "data-hfw-follow";
  var DELAY = 150;
  var MAX_VERB = 24;
  var MAX_HOLDER = 40;
  var SCOPE = '[aria-posinset], [role="article"]';
  var NAMES = "a, h2, h3, h4, strong";
  var HIDE_FOLLOW_CSS = `[${MARK2}] { display: none !important; }`;
  var clean = (text) => (text ?? "").replace(/\s+/g, " ").trim();
  var fold = (text) => clean(text).toLowerCase();
  function labelName(button) {
    const text = fold(button.textContent);
    const label = fold(button.getAttribute("aria-label"));
    if (!text || text.length > MAX_VERB || label === text || !label.includes(text)) return "";
    return clean(label.replace(text, ""));
  }
  function namedIn(scope, name, button) {
    if (name.length < 2) return false;
    const words = ` ${name} `;
    for (const node of scope.querySelectorAll(NAMES)) {
      if (node.contains(button)) continue;
      const shown4 = fold(node.textContent);
      if (shown4.length >= 2 && words.includes(` ${shown4} `)) return true;
    }
    return false;
  }
  function followAfter(dot) {
    if (clean(dot.textContent) !== "·") return null;
    const holder = dot.parentElement?.parentElement;
    if (!holder || clean(holder.textContent).length > MAX_HOLDER) return null;
    const button = [...holder.querySelectorAll('div[role="button"][aria-label]')].find((candidate) => !candidate.contains(dot));
    if (!button || holder.querySelector("a")) return null;
    const scope = holder.closest(SCOPE);
    if (!scope || !namedIn(scope, labelName(button), button)) return null;
    return holder;
  }
  function markFollowButtons(doc) {
    let marked = 0;
    for (const dot of doc.querySelectorAll('span[aria-hidden="true"]')) {
      const holder = followAfter(dot);
      if (!holder || holder.hasAttribute(MARK2)) continue;
      holder.setAttribute(MARK2, "");
      marked++;
    }
    return marked;
  }
  function createFollowHider({ doc, enabled, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    let timer = null;
    let marked = 0;
    const sync = () => {
      timer = null;
      if (enabled()) marked += markFollowButtons(doc);
    };
    const schedule = () => {
      timer ??= setTimer(sync, DELAY);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      marked: () => marked
    };
  }
  var hide_follow_buttons_default = {
    id: "hideFollowButtons",
    section: "feed",
    android: "Hide Follow and Join buttons",
    title: "Hide Follow and Join buttons",
    description: "Takes the Follow and Join buttons off the names in posts from people, pages and groups you don't follow, so a post's header shows just who wrote it.",
    default: false,
    css: HIDE_FOLLOW_CSS,
    setup({ doc, settings, diagnostics, enabled }) {
      const hider = createFollowHider({ doc, enabled });
      const begin = () => hider.start();
      whenBodyReady(begin, doc);
      settings?.subscribe(() => hider.schedule());
      diagnostics?.add("Follow buttons hidden", () => String(hider.marked()));
    }
  };

  // src/features/feed/hide-counts.js
  var MARK3 = "data-hfw-count";
  var DELAY2 = 150;
  var ICON = 'i[data-visualcompletion="css-img"]';
  var COUNT = new RegExp("^(?:[^\\p{Nd}\\s.,]{1,5}\\s)?\\p{Nd}[\\p{Nd}\\s.,'\\u066B\\u066C]*(?:[^\\p{Nd}\\s.,\\u066B\\u066C]{1,5}\\.?)?$", "u");
  var DIGIT = new RegExp("\\p{Nd}", "u");
  var AWAY = '[role="banner"], [role="navigation"]';
  var ROW_BUTTONS = [3, 5];
  var ROW_DEPTH = 2;
  var PICTURE = 'i, svg, img, video, canvas, [style*="background-image"]';
  var REACTION = 'img[src^="data:image/"], img[src*="/rsrc.php/"]';
  var BAR_BUTTONS = [4, 6];
  var BAR_DEPTH = 4;
  var CARD_LEVELS = 8;
  var PAGE = '[role="banner"], [role="navigation"], [role="main"], [role="complementary"], [aria-posinset]';
  var KINDS3 = [
    { kind: "post", option: "posts", label: "Hide counts on posts" },
    { kind: "preview", option: "preview", label: "Hide the reaction preview on posts" },
    { kind: "comment", option: "comments", label: "Hide the reaction preview on comments" },
    { kind: "reel", option: "reels", label: "Hide counts on reels" }
  ];
  function countsCss(get) {
    const shown4 = KINDS3.filter(({ option }) => get(`hideCounts.${option}`)).map(({ kind }) => `[${MARK3}="${kind}"]`);
    return shown4.length ? `${shown4.join(",\n")} { display: none !important; }` : "";
  }
  var clean2 = (text) => (text ?? "").replace(new RegExp("\\p{Cf}", "gu"), "").replace(/\s+/g, " ").trim();
  function holderOf(node, stop) {
    let holder = node;
    while (holder.parentElement && holder.parentElement !== stop && clean2(holder.parentElement.textContent) === clean2(holder.textContent) && !holder.parentElement.querySelector(PICTURE)) {
      holder = holder.parentElement;
    }
    return holder;
  }
  var alone = (node) => [...node.parentElement.childNodes].every((child2) => child2 === node || child2.nodeType !== 1 && !clean2(child2.textContent));
  function soleHolder(node, stop) {
    let holder = node;
    for (let depth = 0; depth < 2 && holder.parentElement && holder.parentElement !== stop && alone(holder); depth++) {
      holder = holder.parentElement;
    }
    return holder;
  }
  function inButtonRow(button) {
    let node = button.parentElement;
    for (let depth = 0; node && depth < ROW_DEPTH; depth++, node = node.parentElement) {
      const buttons = new Set([...node.querySelectorAll(ICON)].map((icon2) => icon2.closest('[role="button"]')).filter(Boolean));
      if (buttons.size >= ROW_BUTTONS[0] && buttons.size <= ROW_BUTTONS[1]) return !(node.parentElement ?? node).querySelector("video");
    }
    return false;
  }
  var svgButtons = (node) => new Set([...node.querySelectorAll("svg")].map((svg) => svg.closest('[role="button"]')).filter(Boolean));
  function inReelBar(button) {
    let bar = button.parentElement;
    for (let depth = 0; bar; depth++, bar = bar.parentElement) {
      if (depth === BAR_DEPTH || bar.querySelector("video")) return false;
      const size = svgButtons(bar).size;
      if (size >= BAR_BUTTONS[0] && size <= BAR_BUTTONS[1]) break;
    }
    let card = bar?.parentElement;
    for (let level = 0; card && level < CARD_LEVELS; level++, card = card.parentElement) {
      const videos = card.querySelectorAll("video").length;
      if (videos) return videos === 1 && !card.querySelector(PAGE);
    }
    return false;
  }
  function reactionButton(button) {
    if (!DIGIT.test(button.getAttribute("aria-label") ?? "") || clean2(button.textContent)) return false;
    const pictures = [...button.querySelectorAll("img")];
    return pictures.length > 0 && pictures.length <= 3 && pictures.every((img) => img.matches(REACTION)) && !button.querySelector('i, svg, a, [role="button"]');
  }
  function tally3(doc) {
    const found = { post: 0, preview: 0, comment: 0, reel: 0 };
    for (const node of doc.querySelectorAll(`[${MARK3}]`)) found[node.getAttribute(MARK3)]++;
    return found;
  }
  var countsIn = (button) => [...button.querySelectorAll("span")].filter((span) => !span.children.length && COUNT.test(clean2(span.textContent)));
  function markCounts(doc) {
    const wanted = /* @__PURE__ */ new Map();
    const buttons = new Set([...doc.querySelectorAll(ICON)].map((icon2) => icon2.closest('[role="button"]')).filter(Boolean));
    for (const button of buttons) {
      if (button.closest(AWAY)) continue;
      const counts = countsIn(button);
      if (!counts.length || !inButtonRow(button)) continue;
      for (const count of counts) wanted.set(holderOf(count, button), "post");
    }
    for (const button of svgButtons(doc)) {
      if (!COUNT.test(clean2(button.textContent)) || !inReelBar(button)) continue;
      for (const count of countsIn(button)) wanted.set(holderOf(count, button), "reel");
    }
    for (const bar of doc.querySelectorAll('[role="toolbar"]')) {
      const choices = [...bar.querySelectorAll('[role="button"]')];
      if (!choices.length || !choices.every(reactionButton) || bar.closest(AWAY)) continue;
      wanted.set(soleHolder(bar, null), "preview");
    }
    for (const button of doc.querySelectorAll('[role="article"][aria-label] [role="button"][aria-label]')) {
      if (button.closest('[role="toolbar"]') || !reactionButton(button)) continue;
      wanted.set(soleHolder(button, button.closest('[role="article"]')), "comment");
    }
    for (const node of doc.querySelectorAll(`[${MARK3}]`)) if (!wanted.has(node)) node.removeAttribute(MARK3);
    for (const [node, kind] of wanted) if (node.getAttribute(MARK3) !== kind) node.setAttribute(MARK3, kind);
    return tally3(doc);
  }
  function createCountHider({ doc, enabled, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    let timer = null;
    const sync = () => {
      timer = null;
      if (enabled()) markCounts(doc);
    };
    const schedule = () => {
      timer ??= setTimer(sync, DELAY2);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      marked: () => tally3(doc)
    };
  }
  var hide_counts_default = {
    id: "hideCounts",
    section: "feed",
    android: "Hide counts on posts",
    title: "Hide counts",
    description: "Takes the numbers off the Like, Comment and Share buttons under posts and beside reels, along with a post's reaction pictures and the reactions on comments, so you read without the tallies. The buttons keep working and your own reaction still shows.",
    default: false,
    options: KINDS3.map(({ option, label }) => ({ key: option, type: "toggle", label, default: true })),
    css: countsCss,
    setup({ doc, settings, diagnostics, enabled }) {
      const hider = createCountHider({ doc, enabled });
      whenBodyReady(() => hider.start(), doc);
      settings?.subscribe(() => hider.schedule());
      diagnostics?.add("Post and reel counts hidden", () => {
        const { post, preview, comment, reel } = hider.marked();
        return `posts ${post}, previews ${preview}, comments ${comment}, reels ${reel}`;
      }, { shareable: true });
    }
  };

  // src/features/feed/expand-long-posts.js
  var DELAY3 = 150;
  var MAX_WORDS = 24;
  var SCOPE2 = '[aria-posinset], [role="article"]';
  var CANDIDATES = ['[aria-posinset] div[role="button"]:not([aria-label])', '[role="article"] div[role="button"]:not([aria-label])'].join(", ");
  var NEAR = "600px 0px";
  var clean3 = (text) => (text ?? "").replace(/\s+/g, " ").trim();
  function isSeeMore(button) {
    const words = clean3(button.textContent);
    if (!words || words.length > MAX_WORDS || button.querySelector("a, img, svg") || !button.closest(SCOPE2)) return false;
    const block2 = button.parentElement;
    if (!block2 || block2.lastElementChild !== button) return false;
    let before = "";
    for (let node = button.previousSibling; node; node = node.previousSibling) before = node.textContent + before;
    const text = before.trimEnd();
    return text.endsWith("…") || text.endsWith("...");
  }
  function createExpander({ doc, enabled, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    const watched = /* @__PURE__ */ new Set();
    const clicked = /* @__PURE__ */ new WeakSet();
    let opened = 0;
    let timer = null;
    const Observer = doc.defaultView?.IntersectionObserver ?? globalThis.IntersectionObserver;
    const open = (button) => {
      if (!enabled() || !button.isConnected || !isSeeMore(button)) return;
      clicked.add(button);
      opened++;
      button.click();
    };
    const near = Observer ? new Observer((entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting || !watched.has(entry.target)) continue;
        stopWatching(entry.target);
        open(entry.target);
      }
    }, { rootMargin: NEAR }) : null;
    function stopWatching(button) {
      near.unobserve(button);
      watched.delete(button);
    }
    const sync = () => {
      timer = null;
      for (const button of watched) if (!button.isConnected) stopWatching(button);
      if (!enabled()) return;
      for (const button of doc.querySelectorAll(CANDIDATES)) {
        if (watched.has(button) || clicked.has(button) || !isSeeMore(button)) continue;
        if (!near) {
          open(button);
          continue;
        }
        watched.add(button);
        near.observe(button);
      }
    };
    const schedule = () => {
      timer ??= setTimer(sync, DELAY3);
    };
    return {
      start() {
        const Mutations = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Mutations(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      opened: () => opened
    };
  }
  var expand_long_posts_default = {
    id: "expandLongPosts",
    section: "feed",
    android: "Expand long posts",
    title: "Expand long posts",
    description: 'Long posts and comments open in full as you scroll to them, instead of stopping at "See more".',
    default: false,
    setup({ doc, settings, diagnostics, enabled }) {
      const expander = createExpander({ doc, enabled });
      const begin = () => expander.start();
      whenBodyReady(begin, doc);
      settings?.subscribe(() => expander.schedule());
      diagnostics?.add("Long posts opened", () => String(expander.opened()));
    }
  };

  // src/features/reels/no-watch-history.js
  var HISTORY_MUTATIONS = /* @__PURE__ */ new Set(["FBUnifiedVideoSeenStateMutation"]);
  var EMPTY_SUCCESS = '{"data":{},"errors":[]}';
  var no_watch_history_default = {
    id: "noWatchHistory",
    section: "reels",
    android: "Don't send reel watch history",
    title: "Don't send watch history",
    description: "Facebook isn't told which reels and videos you've watched, so they don't shape what it shows you next. Ones you've already seen can come around again.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let held = 0;
      net.blockRequests({
        id: "noWatchHistory",
        startupPrivacy: true,
        enabled,
        match: (ctx) => HISTORY_MUTATIONS.has(ctx.friendlyName),
        fakeResponse: () => {
          held++;
          diagnostics?.changed();
          return EMPTY_SUCCESS;
        }
      });
      diagnostics?.add("Watch reports held back", () => String(held));
    }
  };

  // src/features/privacy/usage-logs.js
  var LOG_PATHS = /* @__PURE__ */ new Set(["/ajax/bnzai"]);
  var LOG_MUTATIONS = /* @__PURE__ */ new Set(["FBScreenTimeLogger_syncMutation"]);
  var EMPTY_ANSWER = 'for (;;);{"__ar":1,"payload":null}';
  var facebookHost = (host2) => host2 === "facebook.com" || host2.endsWith(".facebook.com");
  var isTimeReport = (ctx) => LOG_MUTATIONS.has(ctx.friendlyName);
  var isUsageLog = (ctx) => facebookHost(ctx.host ?? "") && (LOG_PATHS.has(ctx.path) || isTimeReport(ctx));
  var usage_logs_default = {
    id: "holdBackLogs",
    section: "privacy",
    android: "Hold back analytics uploads",
    title: "Hold back usage logs",
    description: "Facebook's site keeps a log of what you look at and click, and sends it in batches as you go, along with how long you've been on the site. With this on, neither leaves your browser, so Facebook's count of your time on Facebook won't take in time spent in this browser. Nothing else is held back.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let held = 0;
      let times = 0;
      net.blockRequests({
        id: "holdBackLogs",
        startupPrivacy: true,
        enabled,
        match: isUsageLog,
        fakeResponse: (ctx) => {
          diagnostics?.changed();
          if (isTimeReport(ctx)) {
            times++;
            return EMPTY_SUCCESS;
          }
          held++;
          return EMPTY_ANSWER;
        }
      });
      diagnostics?.add("Usage log batches held back", () => String(held));
      diagnostics?.add("Time on site reports held back", () => String(times));
    }
  };

  // src/features/reels/hide-sponsored-reels.js
  var hide_sponsored_reels_default = {
    id: "hideSponsoredReels",
    section: "reels",
    android: "Hide sponsored reels",
    title: "Hide sponsored reels",
    description: "Drops the ad breaks Facebook schedules inside videos and reels.",
    default: true,
    needsPage: true,
    // Only the count goes to Diagnostics. A cleared schedule isn't a hidden post, and the same
    // video comes back in answer after answer, so on the decision list it would push every real
    // decision off within a few minutes of scrolling video.
    setup({ net, enabled, diagnostics }) {
      let breaks = 0;
      net.transformResponses(adRule("hideSponsoredReels", enabled, (ids) => {
        breaks += ids.length;
        diagnostics?.changed();
      }));
      diagnostics?.add("Videos cleared of ad breaks", () => String(breaks));
    }
  };

  // src/features/reels/clean-up-reels.js
  var MARK4 = "data-hfw-reel";
  var DELAY4 = 150;
  var CLEAN_REELS_CSS = (get) => [
    get("cleanUpReels.follow") ? `[${MARK4}="follow"] { display: none !important; }` : "",
    get("cleanUpReels.audio") ? `[${MARK4}="audio"] { display: none !important; }` : "",
    // Only where there's a pointer to hover with. On a touch screen the caption stays.
    get("cleanUpReels.caption") ? `@media (hover: hover) {
[${MARK4}="overlay"] { transition: opacity 0.2s ease; }
[${MARK4}="player"]:not(:hover) [${MARK4}="overlay"] { opacity: 0 !important; }
}` : ""
  ].filter(Boolean).join("\n");
  var clean4 = (text) => (text ?? "").replace(/\s+/g, " ").trim();
  var VIDEO_LEVELS = 3;
  function playerOf(heading) {
    const group = heading.closest('[role="group"]');
    if (!group) return null;
    let node = group.parentElement;
    for (let level = 0; node && level < VIDEO_LEVELS; level++, node = node.parentElement) {
      if (node.querySelector("video")) return node.querySelectorAll("h2").length === 1 ? group : null;
    }
    return null;
  }
  function overlayOf(heading, player, styleOf2) {
    for (let node = heading.parentElement; node && node !== player; node = node.parentElement) {
      if (styleOf2(node).position === "absolute") return node;
    }
    return null;
  }
  function followOf(heading, player) {
    const name = clean4(heading.querySelector("a")?.textContent);
    if (!name) return null;
    const isFollow = (candidate) => {
      const label = clean4(candidate.getAttribute("aria-label"));
      return label !== name && label.includes(name) && !candidate.closest("h2");
    };
    let button = null;
    for (let scope = heading.parentElement; scope && !button; scope = scope === player ? null : scope.parentElement) {
      button = [...scope.querySelectorAll('div[role="button"][aria-label]')].find(isFollow) ?? null;
    }
    if (!button) return null;
    const hasDot = (node2) => [...node2.querySelectorAll('span[aria-hidden="true"]')].some((span) => !button.contains(span));
    let node = button;
    while (node.parentElement && node.parentElement !== player && !node.parentElement.contains(heading)) {
      node = node.parentElement;
      if (hasDot(node)) return node;
    }
    return button;
  }
  function audioOf(heading, bound) {
    const isAudio = (box2) => {
      const buttons = box2.querySelectorAll('[role="button"]');
      return buttons.length === 1 && !buttons[0].hasAttribute("aria-label") && Boolean(buttons[0].querySelector("i")) && Boolean(buttons[0].querySelector("span"));
    };
    for (let node = heading; node && node !== bound; node = node.parentElement) {
      for (let next = node.nextElementSibling; next; next = next.nextElementSibling) {
        if (isAudio(next)) return next;
      }
    }
    return null;
  }
  function markReels(doc, styleOf2) {
    let marked = 0;
    const mark = (element, kind) => {
      if (!element || element.getAttribute(MARK4) === kind) return;
      element.setAttribute(MARK4, kind);
      marked++;
    };
    for (const heading of doc.querySelectorAll('[role="group"] h2')) {
      if (!heading.querySelector("a")) continue;
      const player = playerOf(heading);
      if (!player) continue;
      mark(player, "player");
      const overlay = overlayOf(heading, player, styleOf2);
      mark(overlay, "overlay");
      mark(followOf(heading, player), "follow");
      mark(audioOf(heading, overlay ?? player), "audio");
    }
    return marked;
  }
  function createReelCleaner({ doc, enabled, styleOf: styleOf2, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    let timer = null;
    let marked = 0;
    const sync = () => {
      timer = null;
      if (enabled()) marked += markReels(doc, styleOf2);
    };
    const schedule = () => {
      timer ??= setTimer(sync, DELAY4);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      marked: () => marked
    };
  }
  var clean_up_reels_default = {
    id: "cleanUpReels",
    section: "reels",
    android: "Clean up Reels",
    title: "Clean up Reels",
    description: "Takes the Follow button off reels, and keeps a reel's name and caption off the video until you point at it. It can also hide the line that names a reel's sound.",
    default: false,
    options: [
      { key: "follow", type: "toggle", label: "Hide the Follow button", default: true },
      { key: "caption", type: "toggle", label: "Show the name and caption only when you point at the reel", default: true },
      { key: "audio", type: "toggle", label: "Hide the audio line", default: false }
    ],
    css: CLEAN_REELS_CSS,
    setup({ doc, win, settings, diagnostics, enabled }) {
      const view2 = win ?? doc.defaultView;
      const styleOf2 = (element) => view2.getComputedStyle(element);
      const cleaner = createReelCleaner({ doc, enabled, styleOf: styleOf2 });
      const begin = () => cleaner.start();
      whenBodyReady(begin, doc);
      settings?.subscribe(() => cleaner.schedule());
      diagnostics?.add("Reel parts tidied", () => String(cleaner.marked()));
    }
  };

  // src/features/stories/anonymous-stories.js
  var SEEN_MUTATIONS = /* @__PURE__ */ new Set(["storiesUpdateSeenStateMutation"]);
  var anonymous_stories_default = {
    id: "anonymousStories",
    section: "stories",
    android: "View stories anonymously",
    title: "View stories anonymously",
    description: "Keeps you off the viewer list of stories you watch, because Facebook isn't told which ones you've seen. Replying or reacting still shows you.",
    default: false,
    needsPage: true,
    setup({ net, enabled }) {
      net.blockRequests({
        id: "anonymousStories",
        startupPrivacy: true,
        enabled,
        match: (ctx) => SEEN_MUTATIONS.has(ctx.friendlyName),
        fakeResponse: () => '{"data":{},"errors":[]}'
      });
    }
  };

  // src/features/stories/stop-advance.js
  var END_MARGIN = 0.5;
  var SHORTEST = 1;
  var INPUT_WINDOW = 1500;
  var isVideo = (node) => node?.tagName === "VIDEO";
  var sameCard = (video, mark) => mark && mark.src === video.currentSrc && mark.duration === video.duration;
  var WRITING = 'input, textarea, select, [contenteditable=""], [contenteditable="true"], [role="textbox"], [role="combobox"], [role="searchbox"]';
  var MENU = '[role="menu"], [role="menuitem"], [role="menuitemradio"], [role="listbox"], [role="option"]';
  var PLAY_KEYS = /* @__PURE__ */ new Set([" ", "k", "K", "Enter"]);
  var ROW_SLACK = 8;
  var inReplyBar = (button) => {
    const box2 = button.getBoundingClientRect?.();
    if (!box2?.height) return false;
    const middle = box2.top + box2.height / 2;
    for (const field of button.ownerDocument?.querySelectorAll(WRITING) ?? []) {
      const row = field.getBoundingClientRect();
      if (row.height && middle >= row.top - ROW_SLACK && middle <= row.bottom + ROW_SLACK) return true;
    }
    return false;
  };
  function asksToPlay(event) {
    const start = event.composedPath?.()[0] ?? event.target;
    const element = typeof start?.closest === "function" ? start : start?.parentElement ?? null;
    if (event.type === "keydown") {
      if (!PLAY_KEYS.has(event.key)) return false;
      return !element?.closest?.(WRITING) && !element?.closest?.(MENU);
    }
    if (!element || element.closest(WRITING) || element.closest(MENU)) return false;
    const button = element.closest('button, [role="button"]');
    return Boolean(button) && !inReplyBar(button);
  }
  function createStoryHold({ doc, win = doc.defaultView, enabled, mode, inViewer, onChange, trusted = (event) => event.isTrusted, now = () => Date.now() }) {
    const held = /* @__PURE__ */ new WeakMap();
    const released = /* @__PURE__ */ new WeakMap();
    let holds = 0;
    let replays = 0;
    let lastInput = Number.NEGATIVE_INFINITY;
    const cardOf = (video) => ({ src: video.currentSrc, duration: video.duration });
    function onTime(event) {
      const video = event.target;
      if (!isVideo(video) || !enabled() || !inViewer()) return;
      const { duration, currentTime } = video;
      if (!Number.isFinite(duration) || duration < SHORTEST || video.loop) return;
      if (currentTime < duration - END_MARGIN) return;
      if (mode() === "replay") {
        video.currentTime = 0;
        replays++;
        onChange?.();
        return;
      }
      if (video.paused || sameCard(video, released.get(video))) return;
      if (!sameCard(video, held.get(video))) holds++;
      held.set(video, cardOf(video));
      video.pause();
      onChange?.();
    }
    function onPlay(event) {
      const video = event.target;
      if (!isVideo(video)) return;
      const atEnd = Number.isFinite(video.duration) && video.currentTime >= video.duration - END_MARGIN;
      const goOn = sameCard(video, held.get(video)) || atEnd;
      if (!goOn) released.delete(video);
      else if (now() - lastInput < INPUT_WINDOW) {
        held.delete(video);
        released.set(video, cardOf(video));
      }
    }
    const onInput = (event) => {
      if (!trusted(event) || !enabled() || !inViewer()) return;
      lastInput = asksToPlay(event) ? now() : Number.NEGATIVE_INFINITY;
    };
    const listen = { capture: true, passive: true };
    return {
      start() {
        doc.addEventListener("timeupdate", onTime, true);
        doc.addEventListener("play", onPlay, true);
        win?.addEventListener("pointerdown", onInput, listen);
        win?.addEventListener("keydown", onInput, listen);
      },
      stop() {
        doc.removeEventListener("timeupdate", onTime, true);
        doc.removeEventListener("play", onPlay, true);
        win?.removeEventListener("pointerdown", onInput, listen);
        win?.removeEventListener("keydown", onInput, listen);
      },
      state: () => ({ holds, replays })
    };
  }
  var inStoryViewer = (doc) => /^\/stories\//.test(doc.location?.pathname ?? "");
  var stop_advance_default = {
    id: "stopStoryAdvance",
    section: "stories",
    android: "Stop Story auto-advance",
    title: "Stop stories moving on",
    description: "A video story stays on screen when it ends instead of moving to the next one, so you go on when you're ready with the arrow. You can have it play again instead. Photo stories still move on by themselves for now.",
    default: false,
    options: [
      {
        key: "atEnd",
        type: "select",
        label: "When a story ends",
        default: "hold",
        choices: [
          { value: "hold", label: "Stay on its last moment" },
          { value: "replay", label: "Play it again" }
        ]
      }
    ],
    setup({ doc, win, enabled, option, diagnostics }) {
      const hold = createStoryHold({
        doc,
        win: win ?? doc.defaultView,
        enabled,
        mode: () => option("atEnd"),
        inViewer: () => inStoryViewer(doc),
        onChange: () => diagnostics?.changed()
      });
      hold.start();
      diagnostics?.add("Stories held at the end", () => String(hold.state().holds));
      diagnostics?.add("Stories played again", () => String(hold.state().replays));
    }
  };

  // src/features/search/hide-sponsored-search.js
  var hide_sponsored_search_default = {
    id: "hideSponsoredSearch",
    section: "search",
    android: "Hide sponsored search results",
    title: "Hide sponsored search results",
    description: "Takes the ads out of search results before Facebook draws them.",
    default: true,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      net.transformResponses(adRule("hideSponsoredSearch", enabled, void 0, { diagnostics, reason: "Sponsored result" }));
    }
  };

  // src/features/search/no-search-history.js
  var SEARCH_HISTORY_MUTATIONS = /* @__PURE__ */ new Set(["CometAddTypeaheadRecentSearchMutation"]);
  var no_search_history_default = {
    id: "noSearchHistory",
    section: "search",
    android: "Don't save search history",
    title: "Don't save search history",
    description: "Searches you make aren't added to your recent searches on Facebook. Search itself works the same.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let held = 0;
      net.blockRequests({
        id: "noSearchHistory",
        startupPrivacy: true,
        enabled,
        match: (ctx) => SEARCH_HISTORY_MUTATIONS.has(ctx.friendlyName),
        fakeResponse: () => {
          held++;
          diagnostics?.changed();
          return EMPTY_SUCCESS;
        }
      });
      diagnostics?.add("Searches held back", () => String(held));
    }
  };

  // src/features/marketplace/hide-sponsored-marketplace.js
  var hide_sponsored_marketplace_default = {
    id: "hideSponsoredMarketplace",
    section: "marketplace",
    android: "Hide sponsored Marketplace listings",
    title: "Hide sponsored Marketplace listings",
    description: "Takes ad cards out of Marketplace before Facebook draws them. The listings around them stay where they are.",
    default: true,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      net.transformResponses(adRule("hideSponsoredMarketplace", enabled, void 0, { diagnostics, reason: "Sponsored listing" }));
    }
  };

  // src/features/marketplace/seller-profile.js
  var MARK5 = "data-hfw-seller-profile";
  var LABEL = "View profile";
  var PROFILE_LINKS = 'a[href*="/marketplace/profile/"]';
  var DELAY5 = 100;
  var SELLER_PROFILE_CSS = `
a[${MARK5}] {
  display: inline-block !important;
  margin-inline-start: 8px !important;
  color: var(--blue-link, #0866ff) !important;
  font-size: .9375rem !important;
  font-weight: 400 !important;
  white-space: nowrap !important;
  text-decoration: none !important;
}
a[${MARK5}]:hover, a[${MARK5}]:focus-visible { text-decoration: underline !important; }`;
  function sellerId(href, base) {
    try {
      const url2 = new URL(href, base);
      if (!/(^|\.)facebook\.com$/.test(url2.hostname)) return null;
      return url2.pathname.match(/^\/marketplace\/profile\/(\d+)\/?$/)?.[1] ?? null;
    } catch {
      return null;
    }
  }
  function isListing(href) {
    try {
      return /^\/marketplace\/item\/\d+/.test(new URL(href).pathname);
    } catch {
      return false;
    }
  }
  var profileUrl = (id) => `/profile.php?id=${id}`;
  function nameLinks(root, base) {
    const byId = /* @__PURE__ */ new Map();
    for (const link of root.querySelectorAll(PROFILE_LINKS)) {
      const id = sellerId(link.getAttribute("href"), base);
      if (!id) continue;
      if (!byId.has(id)) byId.set(id, []);
      byId.get(id).push(link);
    }
    const found = [];
    for (const [id, links] of byId) {
      const labels = links.map((link) => normalizeText(link.getAttribute("aria-label") ?? ""));
      const name = links.find((link, index) => {
        if (labels[index]) return false;
        const text = normalizeText(link.textContent);
        return text && labels.some((label, other) => other !== index && label === text);
      });
      if (name) found.push({ id, link: name });
    }
    return found;
  }
  function addProfileLink(doc, { id, link }) {
    const next = link.nextElementSibling;
    if (next?.hasAttribute(MARK5)) {
      if (next.getAttribute(MARK5) !== id) {
        next.setAttribute(MARK5, id);
        next.setAttribute("href", profileUrl(id));
      }
      return false;
    }
    const view2 = doc.createElement("a");
    view2.setAttribute(MARK5, id);
    view2.setAttribute("href", profileUrl(id));
    view2.setAttribute("role", "link");
    view2.textContent = LABEL;
    link.after(view2);
    return true;
  }
  var MAX_ADDS = 20;
  function createSellerLinks({ doc, enabled, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    let added = 0;
    let timer = null;
    let shown4 = false;
    let listing = "";
    let addsFor = /* @__PURE__ */ new Map();
    const href = () => doc.location?.href ?? "";
    const wanted = () => enabled() && isListing(href());
    function sync() {
      timer = null;
      if (!wanted()) {
        for (const link of doc.querySelectorAll(`a[${MARK5}]`)) link.remove();
        shown4 = false;
        return;
      }
      if (href() !== listing) {
        listing = href();
        addsFor = /* @__PURE__ */ new Map();
      }
      for (const found of nameLinks(doc, listing)) {
        const adds = addsFor.get(found.id) ?? 0;
        if (adds >= MAX_ADDS) continue;
        if (addProfileLink(doc, found)) {
          added++;
          addsFor.set(found.id, adds + 1);
        }
      }
      shown4 = Boolean(doc.querySelector(`a[${MARK5}]`));
    }
    const schedule = () => {
      timer ??= setTimer(sync, DELAY5);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (shown4 || wanted()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      added: () => added
    };
  }
  var seller_profile_default = {
    id: "sellerProfileLink",
    section: "marketplace",
    android: "Show View profile on Marketplace sellers",
    title: "View profile on Marketplace sellers",
    description: "Adds a View profile link after the seller's name on a listing, so you can see their full Facebook profile before you message them, not just their Marketplace page.",
    default: true,
    css: SELLER_PROFILE_CSS,
    setup({ doc, router, settings, diagnostics, enabled }) {
      const links = createSellerLinks({ doc, enabled });
      diagnostics?.add("Seller profile links added", () => String(links.added()));
      const begin = () => links.start();
      whenBodyReady(begin, doc);
      router?.subscribe(() => links.schedule());
      settings?.subscribe(() => links.schedule());
    }
  };

  // src/features/chats/shared.js
  var shown3 = /* @__PURE__ */ new WeakSet();
  function chatSocketRow({ net, diagnostics }) {
    if (!net || !diagnostics || shown3.has(net)) return;
    shown3.add(net);
    diagnostics.add("Chat socket", () => {
      const { messages, unreadable } = net.chatStats;
      if (!messages) return "Facebook hasn't sent anything over chat in this tab yet";
      const sent = `${messages} ${messages === 1 ? "message" : "messages"} sent`;
      return unreadable ? `${sent}, ${unreadable} the script couldn't read` : sent;
    });
  }

  // src/features/chats/hide-read-receipts.js
  var MARK_READ = "21";
  var hide_read_receipts_default = {
    id: "hideReadReceipts",
    section: "chats",
    android: "Hide read receipts",
    title: "Hide read receipts",
    description: "People you chat with don't see that you've read their messages, and the chat stays unread in your other apps. When you reply they'll know anyway. End-to-end encrypted chats, which most one-to-one chats are now, aren't covered, because their receipts are encrypted before the script can see them.",
    default: false,
    needsPage: true,
    setup(ctx) {
      const { net, diagnostics, enabled } = ctx;
      let held = 0;
      if (net) {
        net.editChatRequests({
          id: "hideReadReceipts",
          startupPrivacy: true,
          enabled,
          edit(request) {
            const tasks = request.type === 3 ? request.payload.tasks : null;
            if (!Array.isArray(tasks)) return false;
            const kept = tasks.filter((task) => String(task?.label) !== MARK_READ);
            if (kept.length === tasks.length) return false;
            held += tasks.length - kept.length;
            request.payload.tasks = kept;
            diagnostics?.changed();
            return true;
          }
        });
      }
      diagnostics?.add("Read receipts held back", () => net ? String(held) : "Off: the script can't reach the page's chat");
      chatSocketRow(ctx);
    }
  };

  // src/features/chats/hide-typing.js
  var PRESENCE = "3";
  var hide_typing_default = {
    id: "hideTyping",
    section: "chats",
    android: "Hide typing indicator",
    title: "Hide typing indicator",
    description: "People you chat with don't see the dots while you type. End-to-end encrypted chats aren't covered.",
    default: false,
    needsPage: true,
    setup(ctx) {
      const { net, diagnostics, enabled } = ctx;
      let quieted = 0;
      const quiet = (task) => {
        if (String(task?.label) !== PRESENCE || typeof task.payload !== "string") return false;
        const presence = readJson(task.payload);
        if (!presence || presence.is_typing !== 1) return false;
        presence.is_typing = 0;
        task.payload = writeJson(presence);
        quieted++;
        return true;
      };
      if (net) {
        net.editChatRequests({
          id: "hideTyping",
          startupPrivacy: true,
          enabled,
          edit(request) {
            const tasks = request.type === 4 ? [request.payload] : request.type === 3 ? request.payload.tasks : null;
            if (!Array.isArray(tasks)) return false;
            const changed = tasks.map(quiet).some(Boolean);
            if (changed) diagnostics?.changed();
            return changed;
          }
        });
      }
      diagnostics?.add("Typing signals turned off", () => net ? String(quieted) : "Off: the script can't reach the page's chat");
      chatSocketRow(ctx);
    }
  };

  // src/features/notifications/hide-kinds.js
  var LINKS = 'a[href*="notif_t="]';
  var KIND_MARK = "data-hfw-notif-kind";
  var ROW = '[role="listitem"]';
  var POST = '[role="article"], [aria-posinset], [role="feed"]';
  var HEADING2 = 'h1, h2, h3, h4, h5, h6, [role="heading"]';
  var DELAY6 = 150;
  var MAX_SEEN = 40;
  var GROUPS = [
    { option: "birthdays", label: "Birthdays", test: /birthday/, default: true },
    { option: "memories", label: "Memories", test: /memor|onthisday|on_this_day|goodwill|throwback|friendversary/, default: true },
    { option: "suggestions", label: "People you may know", test: /pymk|people_you_may_know|friend_suggest/, default: true },
    { option: "follow", label: "Pages and creators to follow", test: /to_follow|follow_suggest|page_suggest|creator_suggest/, default: true },
    { option: "activity", label: "Friends' new posts and photos", test: /friend_activity|close_friend/, default: false },
    { option: "groups", label: "Group join approvals", test: /^group_r2j/, default: false },
    { option: "reactions", label: "Reactions to your posts and comments", test: /^feedback_reaction/, default: false }
  ];
  var CUSTOM = "custom";
  function notifType(href) {
    try {
      const type = new URL(href, "https://www.facebook.com").searchParams.get("notif_t");
      return type && /^[a-z0-9_]{1,80}$/.test(type) ? type : null;
    } catch {
      return null;
    }
  }
  function parseKinds(text) {
    return new Set(String(text ?? "").split(/[\s,]+/).map((line) => line.trim().toLowerCase()).filter((line) => /^[a-z0-9_]+$/.test(line)));
  }
  function groupOf(type, custom = /* @__PURE__ */ new Set()) {
    if (custom.has(type)) return CUSTOM;
    return GROUPS.find((group) => group.test.test(type))?.option ?? "other";
  }
  var notifKey = (link) => {
    try {
      const url2 = new URL(link.getAttribute("href"), "https://www.facebook.com");
      return url2.searchParams.get("notif_id") ?? url2.href;
    } catch {
      return link.getAttribute("href");
    }
  };
  var notifCount = (node) => new Set([...node.querySelectorAll(LINKS)].map(notifKey)).size;
  function rowOf(link) {
    const row = link.closest(ROW);
    if (!row || link.closest(POST) || row.querySelector(HEADING2) || notifCount(row) > 1) return null;
    return row;
  }
  function hideKindsCss(get) {
    const groups2 = GROUPS.filter(({ option }) => get(`hideNotificationKinds.${option}`)).map(({ option }) => option);
    if (parseKinds(get("hideNotificationKinds.custom")).size) groups2.push(CUSTOM);
    if (!groups2.length) return "";
    return `${groups2.map((group) => `[${KIND_MARK}="${group}"]`).join(",\n")} { display: none !important; }`;
  }
  function createKindMarker({ doc, enabled, custom, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    const done = /* @__PURE__ */ new WeakMap();
    const seen = /* @__PURE__ */ new Set();
    let timer = null;
    let version2 = 0;
    function sync() {
      timer = null;
      if (!enabled()) {
        for (const row of doc.querySelectorAll(`[${KIND_MARK}]`)) row.removeAttribute(KIND_MARK);
        return;
      }
      const list = custom();
      for (const link of doc.querySelectorAll(LINKS)) {
        const href = link.getAttribute("href");
        const stamp2 = `${version2}|${href}`;
        if (done.get(link) === stamp2) continue;
        done.set(link, stamp2);
        const type = notifType(href);
        if (!type) continue;
        const row = rowOf(link);
        if (!row) continue;
        if (seen.size < MAX_SEEN) seen.add(type);
        row.setAttribute(KIND_MARK, groupOf(type, list));
      }
    }
    const schedule = () => {
      timer ??= setTimer(sync, DELAY6);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["href"] });
        sync();
      },
      // Settings changed: every row is looked at again, since a hand-listed kind may have changed.
      refresh() {
        version2++;
        schedule();
      },
      sync,
      seen: () => [...seen]
    };
  }
  var hide_kinds_default = {
    id: "hideNotificationKinds",
    section: "notifications",
    android: "Block promotional notifications",
    title: "Hide kinds of notifications",
    description: "Takes the kinds of notification you pick out of the Notifications list and page, like birthdays, memories and suggestions. The red count on the bell still counts them.",
    default: false,
    options: [
      ...GROUPS.map(({ option, label, default: on }) => ({ key: option, type: "toggle", label: `Hide ${label.charAt(0).toLowerCase()}${label.slice(1)}`, default: on })),
      { key: "custom", type: "text", lines: 1, label: "Other kinds to hide, by the names Diagnostics shows", default: "", maxLength: 2e3 }
    ],
    css: hideKindsCss,
    setup({ doc, enabled, option, settings, diagnostics }) {
      const marker = createKindMarker({ doc, enabled, custom: () => parseKinds(option("custom")) });
      const begin = () => marker.start();
      whenBodyReady(begin, doc);
      settings?.subscribe(() => marker.refresh());
      diagnostics?.add("Notification kinds seen", () => marker.seen().join(", ") || "None yet");
    }
  };

  // src/features/comments/orders.js
  var ORDERS = [
    { value: "relevant", token: "RANKED_FILTERED_INTENT_V1", english: "Most relevant" },
    { value: "newest", token: "REVERSE_CHRONOLOGICAL_UNFILTERED_INTENT_V1", english: "Newest" },
    { value: "all", token: "RANKED_UNFILTERED_CHRONOLOGICAL_REPLIES_INTENT_V1", english: "All comments" }
  ];
  var DEFAULT_ORDER = ORDERS[0];
  var ORDER_MARKERS = ['"selectable_intents"'];
  function createOrderTitles() {
    const learned = /* @__PURE__ */ new Map();
    return {
      learn(doc) {
        walk(doc, (value) => {
          if (Array.isArray(value) || !Array.isArray(value.selectable_intents)) return;
          for (const intent of value.selectable_intents) {
            const title = normalizeText(intent?.title);
            if (title && typeof intent.intent_token === "string") learned.set(intent.intent_token, title);
          }
        });
      },
      title: (order) => learned.get(order.token) ?? order.english,
      size: () => learned.size
    };
  }

  // src/features/comments/post-dialog.js
  function dialogOpen(doc) {
    return Boolean(doc.querySelector('[role="dialog"] [role="button"], [role="dialog"] [role="article"]'));
  }

  // src/features/comments/comment-order.js
  var MENU_WAIT = 2e3;
  var STEP = 100;
  var SCAN_DELAY = 300;
  var TRIES = 2;
  function createOrderDriver({ doc, win = globalThis, titles, wanted, pageKey, log, onDone, menuWait = MENU_WAIT }) {
    const dialogs = /* @__PURE__ */ new WeakMap();
    const pages = /* @__PURE__ */ new Map();
    let busy = false;
    let generation = 0;
    const sleep = (ms) => new Promise((resolve) => win.setTimeout(resolve, ms));
    const here = () => doc.location?.href ?? "";
    function stateOf(section2) {
      if (section2.page) return pages.get(section2.page) ?? pages.set(section2.page, { done: false, failed: 0 }).get(section2.page);
      const address = here();
      let state = dialogs.get(section2.dialog);
      if (state?.address !== address) dialogs.set(section2.dialog, state = { address, done: false, failed: 0 });
      return state;
    }
    const finished = (section2) => stateOf(section2).done || stateOf(section2).failed >= TRIES;
    function sectionOf2(button) {
      const dialog = button.closest('[role="dialog"]');
      if (dialog) return finished({ dialog }) ? null : { dialog };
      const page = pageKey();
      return page && !dialogOpen(doc) && !finished({ page }) ? { page } : null;
    }
    async function menuAfter(before, current) {
      for (let waited = 0; waited <= menuWait; waited += STEP) {
        if (!current()) return void 0;
        const menu = [...doc.querySelectorAll('[role="menu"]')].find((m) => !before.has(m) && m.querySelector('[role="menuitem"]'));
        if (menu) return menu;
        await sleep(STEP);
      }
      return current() ? null : void 0;
    }
    async function drive(button, section2, order) {
      busy = true;
      const state = stateOf(section2);
      const address = here();
      const started = generation;
      const current = () => started === generation && wanted()?.value === order.value && here() === address && button.isConnected && (section2.dialog ? section2.dialog.contains(button) : pageKey() === section2.page);
      try {
        const before = new Set(doc.querySelectorAll('[role="menu"]'));
        button.click();
        const menu = await menuAfter(before, current);
        if (menu === void 0) return null;
        const items = menu ? [...menu.querySelectorAll('[role="menuitem"]')] : [];
        const title = titles.title(order);
        const item = items.find((entry) => normalizeText(entry.textContent).startsWith(title)) ?? (items.length === ORDERS.length ? items[ORDERS.indexOf(order)] : null);
        if (!item) {
          state.failed++;
          if (menu?.isConnected) button.click();
          log?.warn(`Couldn't find "${order.english}" in Facebook's comment order menu`, title);
          return false;
        }
        item.click();
        state.done = true;
        onDone?.();
        return true;
      } finally {
        busy = false;
      }
    }
    function scan() {
      if (busy) return null;
      const order = wanted();
      if (!order || order === DEFAULT_ORDER) return null;
      const current = titles.title(DEFAULT_ORDER);
      for (const button of doc.querySelectorAll('[role="button"]')) {
        if (normalizeText(button.textContent) !== current) continue;
        const section2 = sectionOf2(button);
        if (section2) return drive(button, section2, order);
      }
      return null;
    }
    function cancel() {
      generation++;
    }
    return { scan, cancel };
  }
  var comment_order_default = {
    id: "commentOrder",
    section: "comments",
    android: "Default comment order",
    title: "Default comment order",
    description: "Opens comments in the order you pick instead of Most relevant, on a post's own page and when you open a post's comments from the feed. You can still change the order on any post.",
    default: false,
    options: [
      {
        key: "order",
        type: "select",
        label: "Order",
        default: "newest",
        choices: [{ value: "newest", label: "Newest first" }, { value: "all", label: "All comments, including ones Facebook filters" }]
      }
    ],
    setup({ doc, win, net, router, settings, diagnostics, enabled, option, log }) {
      const titles = createOrderTitles();
      let changed = 0;
      net?.transformResponses({
        id: "commentOrderTitles",
        enabled,
        markers: ORDER_MARKERS,
        match: (ctx) => ctx.transport === "json-parse",
        observe: true,
        transform(data) {
          titles.learn(data);
          return false;
        }
      });
      const driver = createOrderDriver({
        doc,
        win,
        titles,
        log,
        wanted: () => enabled() ? ORDERS.find((order) => order.value === option("order")) ?? null : null,
        pageKey: () => {
          const route = router?.current();
          return route && (route.permalink || route.type === "photo") ? route.href : null;
        },
        onDone: () => {
          changed++;
          diagnostics?.changed();
        }
      });
      diagnostics?.add("Comment sections put in your order", () => String(changed));
      settings?.subscribe?.(({ keys = [] } = {}) => {
        if (keys.some((key) => key === "paused" || key === "commentOrder" || key.startsWith("commentOrder."))) driver.cancel();
      });
      let queued = false;
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      const observer = new Observer(() => {
        if (queued || !enabled()) return;
        queued = true;
        (win ?? globalThis).setTimeout(() => {
          queued = false;
          driver.scan();
        }, SCAN_DELAY);
      });
      const begin = () => observer.observe(doc.body, { childList: true, subtree: true });
      whenBodyReady(begin, doc);
    }
  };

  // src/features/comments/show-all-replies.js
  var REPLY_BUTTON = /^(?:view (?:all )?[\d.,]+k? (?:more )?repl(?:y|ies)|view more repl(?:y|ies)|[\d.,]+k? repl(?:y|ies))$/i;
  var REPLY_ICON = "M6.94 10.354";
  var PER_ROUND = 3;
  var PER_BUTTON = 5;
  var RETRY_ROUNDS = 3;
  var morePages = (text) => !new RegExp("\\p{Nd}", "u").test(text);
  function isReplyButton(button, text) {
    if (REPLY_BUTTON.test(text)) return true;
    if (!text || button.closest('[role="article"]')) return false;
    return Boolean(button.querySelector("svg path")?.getAttribute("d")?.startsWith(REPLY_ICON));
  }
  function createReplyExpander({ doc, win = globalThis, inPage, enabled, onClick, idleLimit = 5, delay = 800, maxClicks = 300 }) {
    const clicked = /* @__PURE__ */ new WeakMap();
    const spentIn = /* @__PURE__ */ new WeakMap();
    let idle = 0;
    let timer = null;
    let rounds = 0;
    let total = 0;
    const address = () => doc.location?.href ?? "";
    const under = (map, key) => map.get(key) ?? map.set(key, /* @__PURE__ */ new Map()).get(key);
    const spent = (scope) => spentIn.get(scope)?.get(address()) ?? 0;
    const spend = (scope) => under(spentIn, scope).set(address(), spent(scope) + 1);
    const record = (button) => clicked.get(button)?.get(address());
    const note = (button) => under(clicked, button).set(address(), { text: normalizeText(button.textContent), times: (record(button)?.times ?? 0) + 1, round: rounds });
    function ready(button, text) {
      const before = record(button);
      if (!before) return true;
      if (before.times >= PER_BUTTON) return false;
      return before.text !== text || morePages(text) && rounds - before.round >= RETRY_ROUNDS;
    }
    function candidates() {
      const scopes = [...doc.querySelectorAll('[role="dialog"]')];
      if (inPage() && doc.body && !dialogOpen(doc)) scopes.push(doc.body);
      const found = /* @__PURE__ */ new Map();
      for (const scope of scopes) {
        if (spent(scope) >= maxClicks) continue;
        for (const button of scope.querySelectorAll('[role="button"]')) {
          if (found.has(button)) continue;
          const text = normalizeText(button.textContent);
          if (isReplyButton(button, text) && ready(button, text)) found.set(button, scope);
        }
      }
      return [...found];
    }
    function schedule() {
      if (!timer) timer = win.setTimeout(round, delay);
    }
    function round() {
      timer = null;
      if (!enabled()) return;
      rounds++;
      const buttons = candidates();
      if (!buttons.length) {
        idle++;
        if (idle < idleLimit) schedule();
        return;
      }
      idle = 0;
      let now = 0;
      for (const [button, scope] of buttons) {
        if (now >= PER_ROUND) break;
        if (spent(scope) >= maxClicks) continue;
        note(button);
        spend(scope);
        button.click();
        now++;
        total++;
        onClick?.();
      }
      schedule();
    }
    return {
      // The page changed: start the rounds again if they were resting.
      wake() {
        if (timer || !enabled()) return;
        idle = 0;
        schedule();
      },
      state: () => ({ idle, total, rounds, running: Boolean(timer) }),
      stop() {
        win.clearTimeout(timer);
        timer = null;
      }
    };
  }
  var show_all_replies_default = {
    id: "showAllReplies",
    section: "comments",
    android: "Comment sheet options",
    title: "Show every reply",
    description: "Opens every folded reply under comments on a post's own page and when you open a post's comments from the feed, so you don't have to click View replies.",
    default: false,
    setup({ doc, win, router, diagnostics, enabled }) {
      let opened = 0;
      const expander = createReplyExpander({
        doc,
        win: win ?? globalThis,
        enabled,
        inPage: () => {
          const route = router?.current();
          return Boolean(route && (route.permalink || route.type === "photo"));
        },
        onClick: () => {
          opened++;
          diagnostics?.changed();
        }
      });
      diagnostics?.add("Reply threads opened", () => String(opened));
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      const observer = new Observer(() => expander.wake());
      const begin = () => observer.observe(doc.body, { childList: true, subtree: true });
      whenBodyReady(begin, doc);
    }
  };

  // src/features/comments/hide-comment-stickers.js
  var MARK6 = "data-hfw-comment-sticker";
  var FORMS = 'form[role="presentation"]';
  var BUTTONS2 = '[role="button"][aria-haspopup]';
  var DELAY7 = 200;
  var HIDE_STICKERS_CSS = `[${MARK6}] { display: none !important; }`;
  function isCommentForm(form) {
    if (!form.querySelector('[role="textbox"][contenteditable="true"]')) return false;
    if (form.closest('[role="main"], [aria-posinset], [role="article"]')) return true;
    return Boolean(form.closest('[role="dialog"]')?.querySelector('[role="article"]'));
  }
  var isStickerButton = (button) => Boolean(button.querySelector("i")) && !button.querySelector("svg");
  function markStickerButtons(doc) {
    let marked = 0;
    for (const form of doc.querySelectorAll(FORMS)) {
      if (!isCommentForm(form)) continue;
      for (const button of form.querySelectorAll(BUTTONS2)) {
        if (button.hasAttribute(MARK6) || !isStickerButton(button)) continue;
        button.setAttribute(MARK6, "");
        marked++;
      }
    }
    return marked;
  }
  function createStickerHider({ doc, enabled, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    let timer = null;
    let hidden = 0;
    function sync() {
      timer = null;
      if (!enabled()) {
        for (const button of doc.querySelectorAll(`[${MARK6}]`)) button.removeAttribute(MARK6);
        return;
      }
      hidden += markStickerButtons(doc);
    }
    const schedule = () => {
      timer ??= setTimer(sync, DELAY7);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      hidden: () => hidden
    };
  }
  var hide_comment_stickers_default = {
    id: "hideCommentStickers",
    section: "comments",
    android: "Comment sheet options",
    title: "Hide GIF and sticker buttons",
    description: "Takes the GIF, sticker and avatar sticker buttons out of the comment box under posts. The emoji button stays, and only comment boxes on posts are touched.",
    default: false,
    css: HIDE_STICKERS_CSS,
    setup({ doc, settings, diagnostics, enabled }) {
      const hider = createStickerHider({ doc, enabled });
      const begin = () => hider.start();
      whenBodyReady(begin, doc);
      settings?.subscribe(() => hider.schedule());
      diagnostics?.add("Comment box buttons hidden", () => String(hider.hidden()));
    }
  };

  // src/features/comments/hide-video-comment-box.js
  var MARK7 = "data-hfw-video-comment-box";
  var VIDEO2 = '[data-pagelet="WatchPermalinkVideo"]';
  var FORMS2 = 'form[role="presentation"]';
  var LEVELS2 = 4;
  var DELAY8 = 200;
  var HIDE_VIDEO_COMMENT_BOX_CSS = `[${MARK7}] { display: none !important; }`;
  var OUTSIDE = '[role="main"], [aria-posinset]';
  var isBox = (form) => Boolean(form.querySelector('[role="textbox"][contenteditable="true"]'));
  var boxesIn = (root) => [...root.querySelectorAll(FORMS2)].filter(isBox);
  var outside = (el) => el.matches(OUTSIDE) || Boolean(el.querySelector(OUTSIDE));
  function commentColumns(doc) {
    const columns = [];
    for (const video of doc.querySelectorAll(VIDEO2)) {
      let node = video;
      let column = null;
      for (let level = 0; !column && node.parentElement && level < LEVELS2; level++, node = node.parentElement) {
        const siblings = [...node.parentElement.children].filter((sibling) => sibling !== node);
        if (siblings.some(outside)) break;
        column = siblings.find((sibling) => sibling.querySelector('[role="article"]') || boxesIn(sibling).length) ?? null;
      }
      if (column) columns.push(column);
    }
    return columns;
  }
  function markVideoCommentBoxes(doc) {
    const columns = commentColumns(doc);
    for (const form of doc.querySelectorAll(`[${MARK7}]`)) {
      if (!columns.some((column) => column.contains(form))) form.removeAttribute(MARK7);
    }
    let marked = 0;
    for (const column of columns) {
      for (const form of boxesIn(column)) {
        if (form.hasAttribute(MARK7)) continue;
        form.setAttribute(MARK7, "");
        marked++;
      }
    }
    return marked;
  }
  function createVideoCommentBoxHider({ doc, enabled, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    let timer = null;
    let hidden = 0;
    function sync() {
      timer = null;
      if (!enabled()) {
        for (const form of doc.querySelectorAll(`[${MARK7}]`)) form.removeAttribute(MARK7);
        return;
      }
      hidden += markVideoCommentBoxes(doc);
    }
    const schedule = () => {
      timer ??= setTimer(sync, DELAY8);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      hidden: () => hidden
    };
  }
  var hide_video_comment_box_default = {
    id: "hideVideoCommentBox",
    section: "comments",
    android: "Hide the video comment box",
    title: "Hide the video comment box",
    description: "When a video opens on its own page, with its comments beside it, the box for writing a comment there goes away. Comment boxes under posts stay.",
    default: false,
    css: HIDE_VIDEO_COMMENT_BOX_CSS,
    setup({ doc, settings, diagnostics, enabled }) {
      const hider = createVideoCommentBoxHider({ doc, enabled });
      whenBodyReady(() => hider.start(), doc);
      settings?.subscribe(() => hider.schedule());
      diagnostics?.add("Video comment boxes hidden", () => String(hider.hidden()));
    }
  };

  // src/features/comments/hide-comment-typing.js
  var COMMENT_TYPING = /^CometUFILiveTypingBroadcastMutation_(?:Start|Stop)Mutation$/;
  var hide_comment_typing_default = {
    id: "hideCommentTyping",
    section: "comments",
    android: "Hide typing indicator",
    title: "Hide that you're writing a comment",
    description: "Others looking at the same post don't see that you're writing a comment while you type one.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let held = 0;
      net.blockRequests({
        id: "hideCommentTyping",
        startupPrivacy: true,
        enabled,
        match: (ctx) => COMMENT_TYPING.test(ctx.friendlyName),
        fakeResponse: () => {
          held++;
          diagnostics?.changed();
          return EMPTY_SUCCESS;
        }
      });
      diagnostics?.add("Comment typing signals held back", () => String(held));
    }
  };

  // src/features/comments/hide-incoming-typing.js
  var MARKERS2 = ['"typing_indicator_renderer":{'];
  function dropTypingLines(doc) {
    let dropped = 0;
    walk(doc, (value) => {
      if (Array.isArray(value)) return void 0;
      const renderer = value.typing_indicator_renderer;
      if (renderer && typeof renderer === "object") {
        value.typing_indicator_renderer = null;
        dropped++;
      }
      return void 0;
    });
    return dropped;
  }
  var hide_incoming_typing_default = {
    id: "hideIncomingCommentTyping",
    section: "comments",
    android: "Hide who is typing in comments",
    title: "Hide when others are writing a comment",
    description: "Takes away the line under a post's comments that says someone is writing one. New comments still show up as they're posted.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let dropped = 0;
      net.transformResponses({
        id: "hideIncomingCommentTyping",
        enabled,
        markers: MARKERS2,
        // Facebook parses every answer and the page's inline data with JSON.parse.
        match: (ctx) => ctx.transport === "json-parse",
        transform(data, ctx, stage) {
          const count = dropTypingLines(data);
          if (!count) return false;
          later(stage, () => {
            dropped += count;
            diagnostics?.changed();
          });
          return true;
        }
      });
      diagnostics?.add("Comment typing lines kept out", () => String(dropped));
    }
  };

  // src/features/comments/tags-after-at.js
  var BOOTLOAD = /^useFeedComposerCometMentionsBootloadDataSource(?:WithTaggingTransparency)?Query$/;
  var MARKERS3 = ['"comet_composer_typeahead_bootload"', '"xfb_tag_suggestion_search"'];
  function emptyTagLists(doc) {
    const data = doc?.data;
    if (!data || typeof data !== "object") return 0;
    let removed = 0;
    if (Array.isArray(data.comet_composer_typeahead_bootload)) {
      removed += data.comet_composer_typeahead_bootload.length;
      data.comet_composer_typeahead_bootload = [];
    }
    const search = data.xfb_tag_suggestion_search;
    if (search && typeof search === "object" && Array.isArray(search.suggestions)) {
      removed += search.suggestions.length;
      search.suggestions = [];
    }
    return removed;
  }
  var tags_after_at_default = {
    id: "tagsAfterAt",
    section: "comments",
    android: "Tag suggestions only after @",
    title: "Tag suggestions only after @",
    description: "Typing a friend's name in a post or comment no longer offers to tag them. Type @ first when you do want to tag someone.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let held = 0;
      net.transformResponses({
        id: "tagsAfterAt",
        enabled,
        markers: MARKERS3,
        // By name, so the Nullstate and search answers an @ asks for are never touched.
        match: (ctx) => ctx.transport !== "json-parse" && BOOTLOAD.test(ctx.friendlyName),
        transform(doc, ctx, stage) {
          const removed = emptyTagLists(doc);
          if (!removed) return false;
          later(stage, () => {
            held += 1;
            diagnostics?.changed();
          });
          return true;
        }
      });
      diagnostics?.add("Tag lists held back", () => String(held));
    }
  };

  // src/features/comments/comments-as-written.js
  var MARKERS4 = ['"MACHINE_TRANSLATION"'];
  var OTHER_RANGES = ["delight_ranges", "image_ranges", "inline_style_ranges", "aggregated_ranges", "color_ranges"];
  var entityId = (range) => range?.entity?.id ?? null;
  function originalRanges(shown4, own) {
    if (!Array.isArray(own) || !own.length) return [];
    const rich = /* @__PURE__ */ new Map();
    for (const range of Array.isArray(shown4) ? shown4 : []) {
      const id = entityId(range);
      if (id === null) continue;
      if (!rich.has(id)) rich.set(id, []);
      rich.get(id).push(range);
    }
    const out = [];
    for (const range of own) {
      const match = rich.get(entityId(range))?.shift();
      if (match && Number.isFinite(range?.offset) && Number.isFinite(range?.length)) out.push({ ...match, offset: range.offset, length: range.length });
    }
    return out;
  }
  function putBack(block2, own) {
    block2.text = own.text;
    block2.ranges = originalRanges(block2.ranges, own.ranges);
    for (const key of OTHER_RANGES) {
      if (Array.isArray(block2[key]) && block2[key].length) block2[key] = [];
    }
  }
  function restoreComment(comment) {
    const shown4 = comment?.preferred_body;
    const own = comment?.body;
    if (!shown4 || typeof shown4 !== "object" || shown4.translation_type !== "MACHINE_TRANSLATION") return false;
    if (!own || typeof own.text !== "string" || typeof shown4.text !== "string") return false;
    putBack(shown4, own);
    shown4.translation_type = "ORIGINAL";
    const drawn2 = comment.body_renderer;
    if (drawn2 && typeof drawn2 === "object" && typeof drawn2.text === "string" && drawn2.text !== own.text) putBack(drawn2, own);
    return true;
  }
  var MAX_REMEMBERED2 = 5e3;
  var RESTORED = "restored";
  var ASKED = "asked";
  function remember(seen, id, kind) {
    seen.delete(id);
    if (seen.size >= MAX_REMEMBERED2) seen.delete(seen.keys().next().value);
    seen.set(id, kind);
  }
  var CommentBook = class extends Map {
    asked = 0;
    set(id, kind) {
      if (super.get(id) === ASKED) this.asked--;
      if (kind === ASKED) this.asked++;
      return super.set(id, kind);
    }
    delete(id) {
      if (super.get(id) === ASKED) this.asked--;
      return super.delete(id);
    }
    // The book as it is now, order included, put back by the function this returns, for an
    // answer the page never got.
    checkpoint() {
      const saved = [...super.entries()];
      const { asked } = this;
      return () => {
        super.clear();
        for (const [id, kind] of saved) super.set(id, kind);
        this.asked = asked;
      };
    }
  };
  var ORIGINAL_MARKERS = ['"ORIGINAL"'];
  function forgetAsked(data, seen) {
    let forgotten = 0;
    walk(data, (value) => {
      if (Array.isArray(value)) return;
      const shown4 = value.preferred_body;
      if (!shown4 || typeof shown4 !== "object" || typeof shown4.text !== "string" || shown4.translation_type !== "ORIGINAL") return;
      if (typeof value.id === "string" && seen.get(value.id) === ASKED) {
        seen.delete(value.id);
        forgotten++;
      }
    });
    return forgotten;
  }
  function untranslate(data, seen = /* @__PURE__ */ new Map()) {
    const count = { comments: 0, copies: 0 };
    const partial = [];
    walk(data, (value) => {
      if (Array.isArray(value)) return;
      const shown4 = value.preferred_body;
      if (!shown4 || typeof shown4 !== "object") return;
      const id = typeof value.id === "string" ? value.id : null;
      if (typeof shown4.text === "string" && !("body" in value)) {
        if (id && shown4.translation_type === "MACHINE_TRANSLATION") remember(seen, id, ASKED);
        else if (id && seen.get(id) === ASKED) seen.delete(id);
        return;
      }
      if (id && seen.get(id) === ASKED) return;
      if (restoreComment(value)) {
        count.comments++;
        if (id) remember(seen, id, RESTORED);
      } else if (shown4.translation_type === "MACHINE_TRANSLATION" && typeof shown4.text !== "string") {
        partial.push(value);
      }
    });
    for (const copy of partial) {
      if (seen.get(copy.id) !== RESTORED) continue;
      copy.preferred_body.translation_type = "ORIGINAL";
      count.copies++;
    }
    return count;
  }
  var AUTO_TRANSLATED = "CometFeedStoryAutoTranslatedMessageContainerRenderingStrategy";
  var POST_MARKERS = [`"${AUTO_TRANSLATED}"`];
  function restorePost(sections) {
    const container = sections?.message_container;
    if (!container || container.__typename !== AUTO_TRANSLATED) return false;
    const shown4 = container.story?.translation?.message;
    const plain = sections.message?.story;
    const own = plain?.message;
    if (!shown4 || typeof shown4.text !== "string" || !own || typeof own.text !== "string") return false;
    if (!plain.id || plain.id !== container.story.id || shown4.text === own.text) return false;
    putBack(shown4, own);
    return true;
  }
  function untranslatePosts(data) {
    let posts = 0;
    walk(data, (value) => {
      if (!Array.isArray(value) && value.message_container && restorePost(value)) posts++;
    });
    return posts;
  }
  var comments_as_written_default = {
    id: "noAutoTranslate",
    section: "comments",
    android: "Turn off auto-translation",
    title: "Show comments as written",
    description: "Comments and posts in other languages show the words people wrote instead of Facebook's automatic translation. See translation under a comment still works when you want it.",
    default: false,
    needsPage: true,
    setup({ net, enabled, diagnostics }) {
      let shown4 = 0;
      const seen = new CommentBook();
      net.transformResponses({
        id: "noAutoTranslate",
        enabled,
        markers: MARKERS4,
        // Facebook parses every answer and the page's inline data with JSON.parse.
        match: (ctx) => ctx.transport === "json-parse",
        transform(data, ctx, stage) {
          if (stage) stage.undo(seen.checkpoint());
          const { comments, copies } = untranslate(data, seen);
          if (comments) {
            later(stage, () => {
              shown4 += comments;
              diagnostics?.changed();
            });
          }
          return comments + copies > 0;
        }
      });
      net.transformResponses({
        id: "noAutoTranslate-original",
        enabled: () => enabled() && seen.asked > 0,
        markers: ORIGINAL_MARKERS,
        match: (ctx) => ctx.transport === "json-parse",
        observe: true,
        transform(data) {
          forgetAsked(data, seen);
          return false;
        }
      });
      let posts = 0;
      net.transformResponses({
        id: "noAutoTranslate-posts",
        enabled,
        markers: POST_MARKERS,
        match: (ctx) => ctx.transport === "json-parse",
        transform(data, ctx, stage) {
          const changed = untranslatePosts(data);
          if (!changed) return false;
          later(stage, () => {
            posts += changed;
            diagnostics?.changed();
          });
          return true;
        }
      });
      diagnostics?.add("Comments shown as written", () => String(shown4));
      diagnostics?.add("Posts shown as written", () => String(posts));
    }
  };

  // src/features/links/link-events.js
  var EVENTS = ["pointerdown", "mousedown", "mouseup", "click", "auxclick", "contextmenu", "focusin", "dragstart"];
  var STOPPABLE = /* @__PURE__ */ new Set(["mousedown", "mouseup", "click", "auxclick"]);
  var registries = /* @__PURE__ */ new WeakMap();
  function onLinkActivation(win, handler) {
    let handlers = registries.get(win);
    if (!handlers) {
      handlers = [];
      registries.set(win, handlers);
      const listener = (event) => {
        const path2 = typeof event.composedPath === "function" ? event.composedPath() : [];
        const anchor = path2.find((node) => node?.tagName === "A" && node.hasAttribute?.("href"));
        if (!anchor) return;
        let stop = false;
        for (const run of handlers) if (run(anchor, event) === "stop") stop = true;
        if (stop && STOPPABLE.has(event.type)) event.stopImmediatePropagation();
      };
      for (const type of EVENTS) win.addEventListener(type, listener, { capture: true, passive: true });
    }
    handlers.push(handler);
  }

  // src/features/links/sanitize-links.js
  var SHARE_LINK_MUTATIONS = /* @__PURE__ */ new Set(["useLinkSharingCreateWrappedUrlMutation"]);
  var sanitize_links_default = {
    id: "sanitizeLinks",
    section: "links",
    android: "Sanitize sharing links",
    title: "Sanitize sharing links",
    description: "Takes Facebook's tracking tags off links you open or copy. Copy link gives the post's own address instead of a share link that leads back to you.",
    default: true,
    setup({ win, net, enabled }) {
      net?.blockRequests({
        id: "sanitizeLinks",
        startupPrivacy: true,
        enabled,
        match: (ctx) => SHARE_LINK_MUTATIONS.has(ctx.friendlyName),
        fakeResponse: () => '{"data":{},"errors":[]}'
      });
      onLinkActivation(win, (anchor) => {
        if (!enabled()) return;
        const href = anchor.getAttribute("href");
        if (!href) return;
        const cleaned = cleanUrl(href, { unwrap: false, base: win.location.href });
        if (cleaned !== href && cleaned !== anchor.href) anchor.setAttribute("href", cleaned);
      });
      const clipboard = win.navigator.clipboard;
      const writeText = clipboard?.writeText;
      if (typeof writeText !== "function") return;
      clipboard.writeText = function(text) {
        return writeText.call(this, enabled() ? cleanCopiedText(text) : text);
      };
    }
  };

  // src/features/links/direct-links.js
  var direct_links_default = {
    id: "directLinks",
    section: "links",
    android: "Open links in external browser",
    title: "Skip Facebook's link redirect",
    description: "Opens outside links directly instead of through l.facebook.com, so Facebook doesn't record the click.",
    default: true,
    setup({ win, enabled }) {
      onLinkActivation(win, (anchor) => {
        if (!enabled()) return void 0;
        const href = anchor.getAttribute("href");
        const target2 = href && unshim(href, win.location.href);
        if (target2) anchor.setAttribute("href", cleanUrl(target2));
        return isOutbound(anchor.href) ? "stop" : void 0;
      });
    }
  };

  // src/features/links/share-sheet.js
  var MARK8 = "data-hfw-share";
  var DELAY9 = 150;
  var TARGETS = [
    { option: "contacts", label: "the row of Messenger contacts", default: false },
    { option: "messenger", label: "Messenger", words: ["Messenger", "Send in Messenger"], default: false },
    { option: "whatsapp", label: "WhatsApp", hosts: ["wa.me", "whatsapp.com"], words: ["WhatsApp", "Send in WhatsApp"], default: true },
    { option: "story", label: "Your story", words: ["Your story", "Share to your story"], default: true },
    { option: "group", label: "Group", words: ["Group", "Share to a group"], default: false },
    { option: "friend", label: "Friend's profile", words: ["Friend's profile", "Share to a friend's profile"], default: false },
    { option: "x", label: "X", hosts: ["twitter.com", "x.com"], words: ["X"], default: true }
  ];
  var hostMatches = (host2, wanted) => host2 === wanted || host2.endsWith(`.${wanted}`);
  var clean5 = (text) => (text ?? "").replace(/’/g, "'").replace(/\s+/g, " ").trim();
  function linkHost(href, base = "https://www.facebook.com/") {
    try {
      const url2 = new URL(href, base);
      const inner = /(^|\.)facebook\.com$/.test(url2.hostname) && url2.pathname === "/l.php" ? url2.searchParams.get("u") : null;
      return new URL(inner ?? url2.href).hostname;
    } catch {
      return "";
    }
  }
  function targetOf(item) {
    const link = item.querySelector("a[href]");
    const host2 = link ? linkHost(link.getAttribute("href")) : "";
    if (host2) {
      const byHost = TARGETS.find((target2) => target2.hosts?.some((wanted) => hostMatches(host2, wanted)));
      if (byHost) return byHost.option;
    }
    const control = item.querySelector('[role="button"], a, [role="link"]') ?? item;
    const words = [clean5(control.getAttribute("aria-label")), clean5(item.textContent)];
    return TARGETS.find((target2) => target2.words?.some((word) => words.includes(word)))?.option ?? null;
  }
  function sectionOf(element, targets) {
    let node = element;
    while (node.parentElement && !node.parentElement.contains(targets)) node = node.parentElement;
    return node;
  }
  var HEADING3 = 'h1, h2, h3, h4, h5, h6, [role="heading"]';
  var CONTENT = '[role="list"], [role="textbox"], [contenteditable="true"]';
  var isHeading = (node) => node.matches(HEADING3) || !!node.querySelector(HEADING3);
  var CONTROL = '[role="button"], [role="link"], a[href]';
  function headingOf(section2) {
    const heading = section2.previousElementSibling;
    if (!heading || !isHeading(heading) || heading.querySelector(CONTENT) || heading.querySelector(CONTROL)) return [];
    const before = heading.previousElementSibling;
    const oneButton = before && !clean5(before.textContent) && before.querySelectorAll(CONTROL).length === 1 && !before.querySelector(CONTENT);
    return oneButton ? [heading, before] : [heading];
  }
  var MAX_TARGET_TEXT = 40;
  var MIN_TARGETS = 2;
  var MAX_ITEMS = 16;
  var isShortItem = (item) => !item.querySelector('[role="article"]') && clean5(item.textContent).length <= MAX_TARGET_TEXT;
  function targetsIn(list) {
    const items = list.querySelectorAll('[role="listitem"]');
    if (items.length > MAX_ITEMS) return [];
    return [...items].filter(isShortItem).map((item) => [item, targetOf(item)]).filter(([, target2]) => target2);
  }
  function contactsOf(dialog, targets) {
    return [...dialog.querySelectorAll('[role="list"][aria-label]')].find((list) => !list.contains(targets) && !targets.contains(list) && !list.querySelector('[role="article"]') && list.querySelector('[role="listitem"] [role="button"]') && Boolean(list.compareDocumentPosition(targets) & 4)) ?? null;
  }
  function markShareSheets(doc) {
    let marked = 0;
    for (const dialog of doc.querySelectorAll('[role="dialog"]')) {
      for (const list of dialog.querySelectorAll('[role="list"]:not([aria-label])')) {
        const found = targetsIn(list);
        if (found.length < MIN_TARGETS) continue;
        for (const [item, target2] of found) {
          if (item.getAttribute(MARK8) === target2) continue;
          item.setAttribute(MARK8, target2);
          marked++;
        }
        const contacts = contactsOf(dialog, list);
        if (!contacts) continue;
        const section2 = sectionOf(contacts, list);
        for (const part of [section2, ...headingOf(section2)]) {
          if (part.getAttribute(MARK8) === "contacts") continue;
          part.setAttribute(MARK8, "contacts");
          marked++;
        }
      }
    }
    return marked;
  }
  function shareSheetCss(get) {
    const hidden = TARGETS.filter(({ option }) => get(`shareSheet.${option}`)).map(({ option }) => `[role="dialog"] [${MARK8}="${option}"]`);
    return hidden.length ? `${hidden.join(",\n")} { display: none !important; }` : "";
  }
  function createShareSheetMarker({ doc, enabled, setTimer = (fn, ms) => setTimeout(fn, ms) }) {
    let timer = null;
    let marked = 0;
    const sync = () => {
      timer = null;
      if (enabled()) marked += markShareSheets(doc);
    };
    const schedule = () => {
      timer ??= setTimer(sync, DELAY9);
    };
    return {
      start() {
        const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
        new Observer(() => {
          if (enabled()) schedule();
        }).observe(doc.body, { childList: true, subtree: true });
        sync();
      },
      sync,
      schedule,
      marked: () => marked
    };
  }
  var share_sheet_default = {
    id: "shareSheet",
    section: "links",
    android: "Share sheet items",
    title: "Trim the share menu",
    description: "Takes the share targets you pick out of Facebook's share menu. Copy link always stays. WhatsApp and X are found in any language, the rest by their English names for now.",
    default: false,
    options: TARGETS.map(({ option, label, default: on }) => ({ key: option, type: "toggle", label: `Hide ${label}`, default: on })),
    css: shareSheetCss,
    setup({ doc, settings, diagnostics, enabled }) {
      const marker = createShareSheetMarker({ doc, enabled });
      const begin = () => marker.start();
      whenBodyReady(begin, doc);
      settings?.subscribe(() => marker.schedule());
      diagnostics?.add("Share menu targets found", () => String(marker.marked()));
    }
  };

  // src/features/playback/tap-to-play.js
  var NEARBY_LEVELS = 4;
  var VIEWER_INPUT_MS = 5e3;
  var VIEWER_OPEN_MS = 15e3;
  var isViewer = (route) => route?.type === "reel" || route?.type === "stories";
  function shouldAllowPlay({ activationActive, aimedAtMedia, userStarted, inViewer = false, sinceInput = Infinity, openedHere = false }) {
    if (userStarted === true || activationActive === true && aimedAtMedia === true) return true;
    return inViewer === true && (sinceInput <= VIEWER_INPUT_MS || openedHere === true);
  }
  function pointInside(rect, point) {
    return point.x >= rect.left && point.x <= rect.right && point.y >= rect.top && point.y <= rect.bottom;
  }
  function resourceOf(media) {
    const sources = [...media.children ?? []].filter((child2) => child2.tagName === "SOURCE").map((child2) => child2.getAttribute("src"));
    return { src: media.getAttribute("src"), sources: JSON.stringify(sources), object: media.srcObject ?? null };
  }
  var sameResource = (a, b) => Boolean(a && b) && a.src === b.src && a.sources === b.sources && a.object === b.object;
  function isNear(media, target2) {
    for (let node = media, level = 0; node && level < NEARBY_LEVELS; node = node.parentElement, level++) {
      if (node.contains(target2)) return true;
    }
    return false;
  }
  var tap_to_play_default = {
    id: "tapToPlay",
    section: "playback",
    android: "Tap to play",
    title: "Tap to play",
    description: "Videos and music wait for your tap instead of starting by themselves. In Reels and stories, the one you open or skip to plays, and nothing starts on its own.",
    default: false,
    setup({ win, router, enabled, log, now = Date.now }) {
      const proto = win.HTMLMediaElement?.prototype;
      const play = proto?.play;
      if (typeof play !== "function") return;
      const started = /* @__PURE__ */ new WeakMap();
      let lastPress = null;
      let lastInput = -Infinity;
      let opened = null;
      const route = () => router?.current();
      const open = (current) => {
        opened = isViewer(current) ? { type: current.type, at: now(), played: false } : null;
      };
      open(route());
      router?.subscribe((current) => {
        if (!isViewer(current) || opened?.type !== current.type) open(current);
      });
      const listen = { capture: true, passive: true };
      win.addEventListener("pointerdown", (event) => {
        if (!event.isTrusted) return;
        lastPress = { point: { x: event.clientX, y: event.clientY } };
        lastInput = now();
      }, listen);
      win.addEventListener("keydown", (event) => {
        if (!event.isTrusted) return;
        lastPress = { target: event.target };
        lastInput = now();
      }, listen);
      win.addEventListener("wheel", (event) => {
        if (event.isTrusted) lastInput = now();
      }, listen);
      const aimedAt = (media) => {
        if (!lastPress) return false;
        if (lastPress.point) return pointInside(media.getBoundingClientRect(), lastPress.point);
        return isNear(media, lastPress.target);
      };
      proto.play = function() {
        if (!enabled()) return play.apply(this, arguments);
        const activationActive = win.navigator.userActivation?.isActive === true;
        const inViewer = isViewer(route());
        const first = inViewer && opened && !opened.played && now() - opened.at <= VIEWER_OPEN_MS ? opened : null;
        const resource = resourceOf(this);
        const allowed = shouldAllowPlay({
          activationActive,
          aimedAtMedia: aimedAt(this),
          userStarted: sameResource(started.get(this), resource),
          inViewer,
          sinceInput: now() - lastInput,
          openedHere: Boolean(first)
        });
        if (!allowed) {
          log.debug("Held back autoplay");
          return win.Promise.reject(new win.DOMException("Waiting for a tap (HushFacebook Web)", "NotAllowedError"));
        }
        started.set(this, resource);
        const result = play.apply(this, arguments);
        const viewer = inViewer ? opened : null;
        if (viewer && !viewer.played) result?.then?.(() => {
          viewer.played = true;
        }, () => {
        });
        return result;
      };
    }
  };

  // src/features/playback/hdr-brightness.js
  var hdr_brightness_default = {
    id: "limitHdr",
    section: "playback",
    android: "Turn off HDR brightness",
    title: "Turn off HDR brightness",
    description: "Stops HDR videos and photos from turning your screen up to full brightness. They keep their resolution.",
    default: false,
    css: "video, img, canvas { dynamic-range-limit: standard !important; }"
  };

  // src/core/dash.js
  var SET = /<AdaptationSet\b[^>]*?(?:\/>|>[\s\S]*?<\/AdaptationSet>)/g;
  var REPRESENTATION = /<Representation\b[^>]*?(?:\/>|>[\s\S]*?<\/Representation>)/g;
  var ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'" };
  var attribute = (tag, name) => tag.match(new RegExp(`^<[A-Za-z]+\\b[^>]*?\\s${name}="([^"]*)"`))?.[1] ?? null;
  var unescape = (text) => text.replace(/&(amp|lt|gt|quot|apos);/g, (_, name) => ENTITIES[name]);
  function durationOf(text) {
    const found = String(text ?? "").match(/^PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?$/);
    if (!found || found[0] === "PT") return null;
    return Number(found[1] ?? 0) * 3600 + Number(found[2] ?? 0) * 60 + Number(found[3] ?? 0);
  }
  function kindOf(set, representation) {
    const mime = attribute(representation, "mimeType") ?? attribute(set, "mimeType") ?? "";
    const content = attribute(set, "contentType") ?? mime.split("/")[0];
    return content === "video" || content === "audio" ? content : null;
  }
  function fileOf(representation) {
    if (!/<SegmentBase\b/.test(representation) || /<SegmentTemplate\b|<SegmentList\b/.test(representation)) return null;
    const bases = [...representation.matchAll(/<BaseURL\b[^>]*>([^<]*)<\/BaseURL>/g)];
    if (bases.length !== 1) return null;
    const url2 = unescape(bases[0][1].trim());
    return /^https:\/\//.test(url2) ? url2 : null;
  }
  function readManifest(xml) {
    if (typeof xml !== "string") return null;
    const mpd = xml.match(/<MPD\b[^>]*>/)?.[0];
    if (!mpd) return null;
    const live = attribute(mpd, "type") === "dynamic";
    const video = [];
    const audio = [];
    for (const [set] of xml.matchAll(SET)) {
      if (/<ContentProtection\b/.test(set)) continue;
      const head = set.match(/^<AdaptationSet\b[^>]*>/)[0];
      for (const [representation] of set.matchAll(REPRESENTATION)) {
        const tag = representation.match(/^<Representation\b[^>]*>/)[0];
        const kind = kindOf(head, tag);
        const url2 = live ? null : fileOf(representation);
        if (!kind || !url2) continue;
        const width = Number(attribute(tag, "width")) || null;
        const height = Number(attribute(tag, "height")) || null;
        const label = Number(attribute(tag, "FBQualityLabel")?.match(/^(\d+)p/)?.[1]);
        const copy = { url: url2, codecs: attribute(tag, "codecs"), bandwidth: Number(attribute(tag, "bandwidth")) || 0 };
        if (kind === "video") video.push({ ...copy, width, height, quality: label || (width && height ? Math.min(width, height) : 0) });
        else audio.push(copy);
      }
    }
    video.sort((a, b) => b.quality - a.quality || b.bandwidth - a.bandwidth);
    audio.sort((a, b) => b.bandwidth - a.bandwidth);
    const period = xml.match(/<Period\b[^>]*>/)?.[0];
    const duration = durationOf(attribute(mpd, "mediaPresentationDuration")) ?? (period ? durationOf(attribute(period, "duration")) : null);
    return { live, duration, video, audio: audio[0] ?? null };
  }
  function pickCopies(manifest, { quality = "best", limit = Infinity } = {}) {
    const known = manifest.duration > 0 && manifest.video.every((copy) => copy.bandwidth > 0);
    const sizeOf = (copy) => Math.ceil((copy.bandwidth + (manifest.audio?.bandwidth ?? 0)) / 8 * manifest.duration);
    let choices = manifest.video;
    if (!choices.length) return null;
    if (quality === "sd" || !known) {
      const small = choices.filter((copy) => copy.quality <= 480);
      choices = small.length ? small : choices.slice(-1);
    }
    if (!known) return { video: choices[0], audio: manifest.audio, bytes: null };
    const fits = choices.find((copy) => sizeOf(copy) <= limit);
    if (!fits) return { tooBig: sizeOf(choices[choices.length - 1]) };
    return { video: fits, audio: manifest.audio, bytes: sizeOf(fits) };
  }

  // src/core/mp4-merge.js
  var fault = () => new Error("not one fragmented track with its moof and mdat pairs");
  function boxesIn2(bytes, start, end) {
    const view2 = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    const found = [];
    let at = start;
    while (at + 8 <= end) {
      let size = view2.getUint32(at);
      let header = 8;
      if (size === 1) {
        if (at + 16 > end) throw fault();
        size = Number(view2.getBigUint64(at + 8));
        header = 16;
      } else if (size === 0) {
        size = end - at;
        if (size > 4294967295) throw fault();
        view2.setUint32(at, size);
      }
      if (size < header || at + size > end) throw fault();
      found.push({ type: String.fromCharCode(...bytes.subarray(at + 4, at + 8)), start: at, end: at + size, header });
      at += size;
    }
    return found;
  }
  var children = (bytes, box2) => boxesIn2(bytes, box2.start + box2.header, box2.end);
  var child = (bytes, box2, type) => box2 ? children(bytes, box2).find((b) => b.type === type) ?? null : null;
  var path = (bytes, box2, ...types) => types.reduce((inside2, type) => child(bytes, inside2, type), box2);
  var view = (bytes) => new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  var versionOf = (bytes, box2) => bytes[box2.start + box2.header];
  var fields = (box2) => box2.start + box2.header + 4;
  function within2(box2, at, length) {
    if (at + length > box2.end) throw fault();
    return at;
  }
  function readTime(bytes, box2, at, wide) {
    within2(box2, at, wide ? 8 : 4);
    return wide ? Number(view(bytes).getBigUint64(at)) : view(bytes).getUint32(at);
  }
  function timescaleOf(bytes, box2) {
    const wide = versionOf(bytes, box2) === 1;
    return view(bytes).getUint32(within2(box2, fields(box2) + (wide ? 16 : 8), 4));
  }
  function parse3(bytes) {
    const top = boxesIn2(bytes, 0, bytes.length);
    const ftyp = top.find((b) => b.type === "ftyp");
    const moov = top.find((b) => b.type === "moov");
    const traks = moov ? children(bytes, moov).filter((b) => b.type === "trak") : [];
    const mvhd = child(bytes, moov, "mvhd");
    const mvex = child(bytes, moov, "mvex");
    if (!ftyp || traks.length !== 1 || !mvhd || !mvex) throw fault();
    const trak = traks[0];
    const tkhd = child(bytes, trak, "tkhd");
    const mdhd = path(bytes, trak, "mdia", "mdhd");
    if (!tkhd || !mdhd) throw fault();
    const idAt = within2(tkhd, fields(tkhd) + (versionOf(bytes, tkhd) === 1 ? 16 : 8), 4);
    const trackId = view(bytes).getUint32(idAt);
    const trex = children(bytes, mvex).find((b) => b.type === "trex" && view(bytes).getUint32(within2(b, fields(b), 4)) === trackId);
    if (!trex) throw fault();
    const timescale = timescaleOf(bytes, mdhd);
    const fragments = [];
    top.forEach((box2, index) => {
      if (box2.type !== "moof") return;
      const mdat = top[index + 1];
      const trafs = children(bytes, box2).filter((b) => b.type === "traf");
      const tfdt = child(bytes, trafs[0], "tfdt");
      if (mdat?.type !== "mdat" || !trafs.length || !tfdt || !timescale) throw fault();
      const time = readTime(bytes, tfdt, fields(tfdt), versionOf(bytes, tfdt) === 1);
      fragments.push({ moof: box2, mdat, trafs, seconds: time / timescale });
    });
    if (!fragments.length) throw fault();
    return { bytes, ftyp, moov, mvhd, mvex, trak, tkhd, idAt, trackId, trex, movieScale: timescaleOf(bytes, mvhd), fragments };
  }
  function box(type, pieces) {
    const size = 8 + pieces.reduce((sum, piece) => sum + piece.length, 0);
    const out = new Uint8Array(size);
    view(out).setUint32(0, size);
    for (let i = 0; i < 4; i++) out[4 + i] = type.charCodeAt(i);
    let at = 8;
    for (const piece of pieces) {
      out.set(piece, at);
      at += piece.length;
    }
    return out;
  }
  var slice = (bytes, b) => bytes.subarray(b.start, b.end);
  function rescaleTime(bytes, box2, at, wide, from, to) {
    const v = view(bytes);
    within2(box2, at, wide ? 8 : 4);
    if (wide) {
      const value = v.getBigUint64(at);
      if (value !== 0xffffffffffffffffn) v.setBigUint64(at, BigInt(Math.min(Math.round(Number(value) * to / from), Number.MAX_SAFE_INTEGER)));
    } else {
      const value = v.getUint32(at);
      if (value !== 4294967295) v.setUint32(at, Math.min(Math.round(value * to / from), 4294967295));
    }
  }
  function rescale(file, scale) {
    const { bytes, tkhd } = file;
    if (scale === file.movieScale) return;
    if (!file.movieScale) throw fault();
    const wide = versionOf(bytes, tkhd) === 1;
    rescaleTime(bytes, tkhd, fields(tkhd) + (wide ? 24 : 16), wide, file.movieScale, scale);
    const elst = path(bytes, file.trak, "edts", "elst");
    if (!elst) return;
    const elstWide = versionOf(bytes, elst) === 1;
    const size = elstWide ? 20 : 12;
    const count = view(bytes).getUint32(within2(elst, fields(elst), 4));
    for (let entry = 0, at = fields(elst) + 4; entry < count; entry++, at += size) {
      rescaleTime(bytes, elst, at, elstWide, file.movieScale, scale);
    }
  }
  function mergeTracks(pictureBytes, soundBytes) {
    const picture = parse3(pictureBytes);
    if (!soundBytes) return [pictureBytes];
    const sound = parse3(soundBytes);
    const soundId = picture.trackId + 1;
    const sv = view(sound.bytes);
    sv.setUint32(sound.idAt, soundId);
    sv.setUint32(fields(sound.trex), soundId);
    rescale(sound, picture.movieScale);
    for (const fragment of sound.fragments) {
      for (const traf of fragment.trafs) {
        const tfhd = child(sound.bytes, traf, "tfhd");
        if (!tfhd) throw fault();
        sv.setUint32(within2(tfhd, fields(tfhd), 4), soundId);
      }
    }
    const pb = picture.bytes;
    const moovPieces = children(pb, picture.moov).flatMap((b) => {
      if (b.type === "mvhd") {
        const mvhd = slice(pb, b).slice();
        const at = within2({ end: mvhd.length }, b.header + 4 + (versionOf(pb, b) === 1 ? 104 : 92), 4);
        view(mvhd).setUint32(at, soundId + 1);
        return [mvhd];
      }
      if (b.type === "trak") return [slice(pb, b), slice(sound.bytes, sound.trak)];
      if (b.type === "mvex") return [box("mvex", [...children(pb, b).map((c) => slice(pb, c)), slice(sound.bytes, sound.trex)])];
      return [slice(pb, b)];
    });
    const head = [slice(pb, picture.ftyp), box("moov", moovPieces)];
    const order = [...picture.fragments.map((f) => ({ ...f, file: picture })), ...sound.fragments.map((f) => ({ ...f, file: sound }))].sort((a, b) => a.seconds - b.seconds);
    let position = head.reduce((sum, piece) => sum + piece.length, 0);
    const pieces = [...head];
    order.forEach((fragment, index) => {
      const { bytes } = fragment.file;
      const v = view(bytes);
      const mfhd = child(bytes, fragment.moof, "mfhd");
      if (!mfhd) throw fault();
      v.setUint32(within2(mfhd, fields(mfhd), 4), index + 1);
      for (const traf of fragment.trafs) {
        const tfhd = child(bytes, traf, "tfhd");
        if (!tfhd) throw fault();
        if (v.getUint32(within2(tfhd, tfhd.start + tfhd.header, 4)) & 1) {
          const at = within2(tfhd, fields(tfhd) + 4, 8);
          v.setBigUint64(at, v.getBigUint64(at) - BigInt(fragment.moof.start) + BigInt(position));
        }
      }
      pieces.push(slice(bytes, fragment.moof), slice(bytes, fragment.mdat));
      position += fragment.mdat.end - fragment.moof.start;
    });
    return pieces;
  }

  // src/core/download.js
  var TIMEOUT2 = 6e5;
  var RESERVED = /* @__PURE__ */ new Set(["<", ">", ":", '"', "/", "\\", "|", "?", "*"]);
  function invisible(code) {
    return code < 32 || code >= 127 && code <= 159 || code === 173 || code === 1564 || code === 6158 || code >= 8203 && code <= 8207 || code >= 8234 && code <= 8238 || code >= 8288 && code <= 8303 || code === 65279 || code >= 65529 && code <= 65531 || code >= 917504 && code <= 917631;
  }
  function fileName(parts, extension) {
    const joined = parts.filter(Boolean).join(" ").normalize("NFC");
    let clean6 = "";
    for (const char of joined) clean6 += RESERVED.has(char) || invisible(char.codePointAt(0)) ? " " : char;
    const base = clean6.replace(/\s+/g, " ").trim().replace(/^[.~ ]+/, "");
    const cut = [...base].slice(0, 100).join("").trim().replace(/[. ]+$/, "");
    const safe = /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(cut) ? `Facebook ${cut}` : cut;
    return `${safe || "Facebook"}.${extension}`;
  }
  function extensionOf(url2, fallback) {
    try {
      const parsed = new URL(url2);
      const found = parsed.searchParams.get("stp")?.match(/(?:^|_)dst-(jpe?g|png|webp|gif)/i) ?? parsed.pathname.match(/\.(mp4|m4v|webm|jpe?g|png|gif|webp|heic)$/i);
      return found ? found[1].toLowerCase().replace("jpeg", "jpg") : fallback;
    } catch {
      return fallback;
    }
  }
  var describe2 = (value) => value && typeof value === "object" ? JSON.stringify(value) : String(value ?? "");
  var cancelledError = (cause) => Object.assign(new Error("you cancelled it", cause ? { cause } : void 0), { cancelled: true });
  function viaManager(download, url2, name, timeout) {
    let handle = null;
    const done = new Promise((resolve, reject) => {
      handle = download({
        url: url2,
        name,
        saveAs: false,
        timeout,
        onload: () => resolve(),
        onerror: (error) => reject(Object.assign(new Error(describe2(error?.error) || describe2(error?.details) || "the manager could not save it"), {
          cancelled: /cancel/i.test(`${describe2(error?.error)} ${describe2(error?.details)}`),
          // The extension's downloads: the browser took the file and then stopped, so another
          // try would only hide why.
          final: error?.final === true
        })),
        ontimeout: () => reject(new Error("it took too long"))
      });
    });
    return { done, abort: () => handle?.abort?.() };
  }
  function fetchBlob(url2, { request, win, timeout, type = "blob" }) {
    if (request) {
      let handle = null;
      const done2 = new Promise((resolve, reject) => {
        handle = request({
          method: "GET",
          url: url2,
          responseType: type,
          timeout,
          anonymous: true,
          onload: (response) => response.status >= 200 && response.status < 300 && response.response ? resolve(response.response) : reject(new Error(`the server answered ${response.status}`)),
          onerror: () => reject(new Error("the file couldn't be fetched")),
          ontimeout: () => reject(new Error("it took too long"))
        });
      });
      return { done: done2, abort: () => handle?.abort?.() };
    }
    const controller = new (win.AbortController ?? AbortController)();
    const done = win.fetch(url2, { credentials: "omit", signal: controller.signal }).then((response) => {
      if (!response.ok) throw new Error(`the server answered ${response.status}`);
      return type === "arraybuffer" ? response.arrayBuffer() : response.blob();
    });
    return { done, abort: () => controller.abort() };
  }
  function fetchParts(parts, options) {
    const tries = parts.map((part) => fetchBlob(part, { ...options, type: "arraybuffer" }));
    const abort = () => tries.forEach((step2) => step2.abort());
    const done = Promise.all(tries.map((step2) => step2.done));
    done.catch(abort);
    return { done, abort };
  }
  function joinParts(picture, sound) {
    try {
      return mergeTracks(new Uint8Array(picture), sound ? new Uint8Array(sound) : null);
    } catch (error) {
      throw new Error("the video and its sound didn't fit together", { cause: error });
    }
  }
  function saveThroughLink(blob, name, doc, container) {
    const href = URL.createObjectURL(blob);
    const link = doc.createElement("a");
    link.href = href;
    link.download = name;
    link.rel = "noopener";
    link.style.display = "none";
    (container ?? doc.body ?? doc.documentElement).append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(href), 6e4).unref?.();
  }
  function startSave({ url: url2, parts = null, name, api = {}, doc = globalThis.document, win = globalThis, container = null, deadline = TIMEOUT2 }) {
    let over2 = false;
    let running = null;
    let settle2;
    const done = new Promise((resolve, reject) => {
      settle2 = (error, how) => {
        if (over2) return false;
        over2 = true;
        clearTimeout(timer);
        const stop = running;
        running = null;
        if (error) {
          reject(error);
          try {
            stop?.abort();
          } catch {
          }
        } else resolve(how);
        return true;
      };
    });
    const timer = setTimeout(() => settle2(new Error("it took too long")), deadline);
    const attempt2 = async (step2) => {
      running = step2;
      try {
        return await step2.done;
      } finally {
        if (running === step2) running = null;
      }
    };
    const run = async () => {
      if (parts) {
        const [picture, sound] = await attempt2(fetchParts(parts, { request: api.request, win, timeout: deadline }));
        if (over2) return void 0;
        const pieces = joinParts(picture, sound);
        saveThroughLink(new (win.Blob ?? Blob)(pieces, { type: "video/mp4" }), name, doc, container);
        return "link";
      }
      if (api.download) {
        try {
          await attempt2(viaManager(api.download, url2, name, deadline));
          return "manager";
        } catch (error) {
          if (over2) return void 0;
          if (error.cancelled) throw cancelledError(error);
          if (error.final) throw error;
        }
      }
      const blob = await attempt2(fetchBlob(url2, { request: api.request, win, timeout: deadline }));
      if (over2) return void 0;
      saveThroughLink(blob, name, doc, container);
      return "link";
    };
    run().then((how) => settle2(null, how), (error) => settle2(error));
    return { done, cancel: () => settle2(cancelledError()) };
  }

  // src/features/downloads/find.js
  var POST2 = '[aria-posinset], [role="article"]';
  var COMMENT_LINK = /[?&](?:reply_comment_id|comment_id)=/;
  var MAX_LEVELS = 14;
  var LABELS = { downloadVideos: "video", downloadReels: "reel", downloadStories: "story", downloadPhotos: "photo" };
  var STREAM_LIMIT = 75e7;
  function linkTarget(href) {
    const text = String(href ?? "");
    let found = text.match(/\/reels?\/(\d{6,})/);
    if (found) return { kind: "reel", id: found[1] };
    found = text.match(/\/videos\/(?:[^/?#]+\/)?(\d{6,})/) ?? text.match(/\/(?:watch(?:\/live)?|video\.php)\/?\?(?:[^#]*&)?v=(\d{6,})/);
    if (found) return { kind: "video", id: found[1] };
    found = text.match(/\/photo(?:\.php)?\/?\?(?:[^#]*&)?fbid=(\d{6,})/) ?? text.match(/\/photos\/[^/?#]+\/(\d{6,})/);
    if (found) return { kind: "photo", id: found[1] };
    return null;
  }
  function pageTarget(href) {
    let url2;
    try {
      url2 = new URL(href);
    } catch {
      return null;
    }
    const story = url2.pathname.match(/^\/stories\/[^/]+\/([^/?#]+)/);
    if (story) {
      try {
        return { kind: "story", card: decodeURIComponent(story[1]) };
      } catch {
        return { kind: "story", card: story[1] };
      }
    }
    return linkTarget(url2.pathname + url2.search);
  }
  function nearestVideoLink(element) {
    const home = element.closest(POST2);
    let node = element.parentElement;
    for (let level = 0; node && level < MAX_LEVELS; level++, node = node.parentElement) {
      const ids = /* @__PURE__ */ new Map();
      for (const link of node.querySelectorAll("a[href]")) {
        const href = link.getAttribute("href");
        if (COMMENT_LINK.test(href) || link.closest(POST2) !== home) continue;
        const target2 = linkTarget(href);
        if (target2 && target2.kind !== "photo" && !ids.has(target2.id)) ids.set(target2.id, target2);
      }
      if (ids.size === 1) return [...ids.values()][0];
      if (ids.size > 1) return null;
      if (node.matches(POST2)) return null;
    }
    return null;
  }
  function pagePlayer(element) {
    if (element.closest("[aria-posinset]")) return false;
    const article = element.closest('[role="article"]');
    return !article || !isComment(article) && !article.parentElement?.closest('[role="article"]');
  }
  function videoTarget(element, page) {
    const near = nearestVideoLink(element);
    if (near) return near;
    return (page?.kind === "video" || page?.kind === "reel") && pagePlayer(element) ? page : null;
  }
  var wordsOf = (el) => [...el.childNodes].map((node) => node.nodeType === 3 ? node.textContent : node.nodeType === 1 && node.localName !== "svg" ? wordsOf(node) : "").join("");
  function authorOf(element) {
    const post = element.closest(POST2);
    if (!post) return null;
    const heading = [...post.querySelectorAll("h2, h3, h4")].find((h2) => h2.closest(POST2) === post);
    const name = heading?.querySelector("a, strong, span") ?? heading;
    const text = normalizeText(name ? wordsOf(name) : "");
    return text && text.length <= 80 ? text : null;
  }
  function imageSource(img) {
    let best = null;
    for (const part of (img.getAttribute("srcset") ?? "").split(",")) {
      const [url2, size] = part.trim().split(/\s+/);
      const width = Number.parseFloat(size) || 0;
      if (url2 && (!best || width > best.width)) best = { url: url2, width };
    }
    return best?.url ?? img.currentSrc ?? img.getAttribute("src") ?? null;
  }
  var asKind = (item, kind) => item?.kind === kind ? item : null;
  function findMedia(element, { href, index }) {
    const tag = element?.tagName;
    if (tag !== "VIDEO" && tag !== "IMG") return null;
    const page = pageTarget(href);
    const fallback = tag === "IMG" ? imageSource(element) : null;
    if (page?.kind === "story") {
      const item = index?.card(page.card) ?? null;
      const kind = item?.kind ?? (tag === "VIDEO" ? "video" : "photo");
      return { feature: "downloadStories", kind, id: item?.id ?? null, item, author: item?.author ?? null, fallback };
    }
    if (tag === "VIDEO") {
      const target3 = videoTarget(element, page);
      const feature = (target3?.kind ?? page?.kind) === "reel" ? "downloadReels" : "downloadVideos";
      const id = target3?.id ?? null;
      const author = authorOf(element) ?? index?.ownerName(id) ?? null;
      return { feature, kind: "video", id, item: asKind(index?.get(id), "video"), author, fallback: null };
    }
    const link = element.closest("a[href]");
    const target2 = linkTarget(link?.getAttribute("href")) ?? (page?.kind === "photo" && !element.closest(POST2) ? page : null);
    if (target2?.kind !== "photo") return null;
    return { feature: "downloadPhotos", kind: "photo", id: target2.id, item: asKind(index?.get(target2.id), "photo"), author: authorOf(element), fallback };
  }
  function joinedPlan(found, label, item, pick) {
    const name = fileName([found.author, label, item.id, `${pick.video.quality}p`], "mp4");
    const plan = { name, quality: `${pick.video.quality}p` };
    return pick.audio ? { ...plan, parts: [pick.video.url, pick.audio.url] } : { ...plan, url: pick.video.url };
  }
  function planSave(found, { quality = "best", limit = STREAM_LIMIT } = {}) {
    const label = LABELS[found.feature] ?? "media";
    if (found.kind === "video") {
      const { item } = found;
      if (!item && !found.id) return { error: "Couldn't tell which video this is. Open it from its post and try again." };
      if (!item) return { error: "Facebook hasn't sent this video's file yet. Let it play for a moment, or open it, and try again." };
      if (quality === "sharpest" && item.sharper) {
        const pick = pickCopies(item.sharper, { limit });
        if (pick?.video) return joinedPlan(found, label, item, pick);
      }
      const file = (quality === "sd" ? item.files.find((f) => f.quality === "SD") : null) ?? item.files[0];
      if (!file) {
        const { stream } = item;
        if (stream?.live) return { error: "This video is live. Facebook has a file to save once it ends." };
        const pick = stream ? pickCopies(stream, { quality, limit }) : null;
        if (pick?.tooBig) return { error: "This video is too long to put together in the browser (about {size} MB at its smallest).", params: { size: Math.round(pick.tooBig / 1e6) } };
        if (pick) return joinedPlan(found, label, item, pick);
        return { error: item.dash ? "Facebook only streams this video in small pieces, so there is no single file to save." : "Facebook didn't send a file for this video." };
      }
      const name = fileName([found.author, label, item.id, file.quality === "HD" ? "HD" : null], extensionOf(file.url, "mp4"));
      return { url: file.url, name, quality: file.quality };
    }
    const url2 = found.item?.url ?? found.fallback;
    if (!url2) return { error: "Couldn't find this photo's file." };
    return { url: url2, name: fileName([found.author, label, found.id ?? found.item?.id], extensionOf(url2, "jpg")) };
  }

  // src/features/playback/resume-videos.js
  var POSITIONS_KEY2 = "resumeVideos.positions";
  var LENGTHS = [2, 5, 10, 20];
  var MAX_KEPT = 200;
  var SAVE_EVERY = 5;
  var START_AFTER = 30;
  var DONE_WITHIN = 20;
  var STEP_BACK = 3;
  var SAME_LENGTH = 2;
  var JOIN_WITHIN = 5;
  var isVideo2 = (node) => node?.tagName === "VIDEO";
  function videoId(video, href) {
    const page = pageTarget(href);
    if (page?.kind === "story" || page?.kind === "reel") return null;
    const target2 = videoTarget(video, page);
    return target2?.kind === "video" ? target2.id : null;
  }
  function clock(seconds) {
    const whole = Math.floor(seconds);
    const h2 = Math.floor(whole / 3600);
    const m = Math.floor(whole % 3600 / 60);
    const s = String(whole % 60).padStart(2, "0");
    return h2 ? `${h2}:${String(m).padStart(2, "0")}:${s}` : `${m}:${s}`;
  }
  function createResumer({ doc, storage, enabled, minSeconds, href = () => doc.location.href, now = () => Date.now(), onResume }) {
    const tracked = /* @__PURE__ */ new WeakMap();
    let resumes = 0;
    const kept = () => storage.get(POSITIONS_KEY2, {}) ?? {};
    function write(id, seconds, duration) {
      const all = kept();
      if (seconds === null) {
        if (!(id in all)) return;
        delete all[id];
      } else {
        all[id] = { t: Math.floor(seconds), d: Math.round(duration), at: now() };
        const ids = Object.keys(all);
        if (ids.length > MAX_KEPT) {
          for (const old of ids.sort((a, b) => all[a].at - all[b].at).slice(0, ids.length - MAX_KEPT)) delete all[old];
        }
      }
      storage.set(POSITIONS_KEY2, all);
    }
    function entry(video) {
      const id = videoId(video, href());
      let found = tracked.get(video);
      if (!found || found.id !== id) {
        found = { id, joined: false, heard: false, saved: Number.NEGATIVE_INFINITY, done: false, cleared: false };
        tracked.set(video, found);
      }
      return found;
    }
    const long = (video) => Number.isFinite(video.duration) && video.duration >= minSeconds();
    const watching = (event) => isVideo2(event.target) && enabled() && long(event.target);
    const audible = (video) => !video.muted && video.volume > 0;
    function join(video, found) {
      found.joined = true;
      if (video.currentTime > JOIN_WITHIN) return;
      const spot = kept()[found.id];
      if (!spot || Math.abs(spot.d - video.duration) > SAME_LENGTH) return;
      if (spot.t < START_AFTER || spot.t > video.duration - DONE_WITHIN) return;
      video.currentTime = Math.max(START_AFTER, spot.t - STEP_BACK);
      resumes++;
      onResume?.(spot.t);
    }
    function onPlaying(event) {
      if (!watching(event)) return;
      const found = entry(event.target);
      if (found.id && !found.joined) join(event.target, found);
    }
    function remember2(video, force) {
      const found = entry(video);
      if (!found.id) return;
      if (!found.joined) {
        if (video.paused) return;
        join(video, found);
      }
      if (!found.heard) {
        if (!audible(video)) return;
        found.heard = true;
      }
      const at = video.currentTime;
      if (at > video.duration - DONE_WITHIN) {
        if (!found.done) write(found.id, null);
        found.done = true;
        return;
      }
      found.done = false;
      if (at < START_AFTER) {
        if (!found.cleared) write(found.id, null);
        found.cleared = true;
        found.saved = Number.NEGATIVE_INFINITY;
        return;
      }
      found.cleared = false;
      if (!force && Math.abs(at - found.saved) < SAVE_EVERY) return;
      found.saved = at;
      write(found.id, at, video.duration);
    }
    const onTime = (event) => watching(event) && remember2(event.target, false);
    const onPause = (event) => watching(event) && remember2(event.target, true);
    return {
      start() {
        doc.addEventListener("playing", onPlaying, true);
        doc.addEventListener("timeupdate", onTime, true);
        doc.addEventListener("pause", onPause, true);
      },
      forget: () => storage.remove(POSITIONS_KEY2),
      count: () => Object.keys(kept()).length,
      resumes: () => resumes
    };
  }
  var resume_videos_default = {
    id: "resumeVideos",
    section: "playback",
    android: "Resume long videos",
    title: "Resume long videos",
    description: "A long video you stopped partway through starts where you left it the next time you play it, a few seconds early so you can find your place. Reels and stories aren't kept.",
    default: false,
    options: [
      {
        key: "minutes",
        type: "select",
        label: "Count videos longer than",
        default: 5,
        choices: LENGTHS.map((n) => ({ value: n, label: `${n} minutes` }))
      }
    ],
    setup({ doc, storage, enabled, option, toast, diagnostics, actions }) {
      const resumer = createResumer({
        doc,
        storage,
        enabled,
        minSeconds: () => Number(option("minutes") ?? 5) * 60,
        onResume: (seconds) => toast?.(t("Picked up where you left off, at {time}", { time: clock(seconds) }))
      });
      resumer.start();
      diagnostics?.add("Video spots kept", () => String(resumer.count()));
      diagnostics?.add("Videos picked up", () => String(resumer.resumes()));
      actions?.add("Forget every spot", () => {
        resumer.forget();
        toast?.(t("Forgot every video spot"));
      });
    }
  };

  // src/features/playback/keep-speed.js
  var SPEED_KEY2 = "keepSpeed.rate";
  var HOLDING = /* @__PURE__ */ Symbol.for("hushfacebook-web.holding-speed");
  var INPUT_WINDOW2 = 2e3;
  var SETTLED = 1;
  var MAX_REAPPLY = 3;
  var MIN_RATE = 0.25;
  var MAX_RATE = 4;
  var isVideo3 = (node) => node?.tagName === "VIDEO";
  function createSpeedKeeper({ doc, win, storage, enabled, now = () => Date.now(), trusted = (event) => event.isTrusted, inStories = () => /^\/stories\//.test(doc.location?.pathname ?? "") }) {
    const ours = /* @__PURE__ */ new WeakMap();
    const reapplied = /* @__PURE__ */ new WeakMap();
    let lastInput = Number.NEGATIVE_INFINITY;
    const kept = () => {
      const rate = Number(storage.get(SPEED_KEY2, 1));
      return rate >= MIN_RATE && rate <= MAX_RATE ? rate : 1;
    };
    function give(video) {
      const rate = kept();
      if (video.playbackRate === rate) return;
      ours.set(video, rate);
      video.playbackRate = rate;
    }
    const wasLive = /* @__PURE__ */ new WeakMap();
    const isLive = (video) => video.duration === Number.POSITIVE_INFINITY || wasLive.has(video) && wasLive.get(video) === video.currentSrc;
    const skip = (video) => !isVideo3(video) || !enabled() || inStories() || video[HOLDING] || isLive(video);
    function onStart(event) {
      if (skip(event.target)) return;
      give(event.target);
    }
    function onLength(event) {
      const video = event.target;
      if (!isVideo3(video) || video.duration !== Number.POSITIVE_INFINITY) return;
      wasLive.set(video, video.currentSrc);
      if (!ours.has(video)) return;
      if (video.playbackRate === ours.get(video)) video.playbackRate = 1;
      ours.delete(video);
    }
    function onRate(event) {
      const video = event.target;
      if (skip(video)) return;
      const rate = video.playbackRate;
      if (ours.get(video) === rate) return;
      ours.delete(video);
      const picked = now() - lastInput < INPUT_WINDOW2 && video.currentTime >= SETTLED;
      if (picked) {
        if (rate >= MIN_RATE && rate <= MAX_RATE && rate !== kept()) storage.set(SPEED_KEY2, rate);
        return;
      }
      const times = reapplied.get(video) ?? 0;
      if (times >= MAX_REAPPLY) return;
      reapplied.set(video, times + 1);
      give(video);
    }
    const onInput = (event) => {
      if (trusted(event)) lastInput = now();
    };
    return {
      start() {
        const listen = { capture: true, passive: true };
        win.addEventListener("pointerdown", onInput, listen);
        win.addEventListener("keydown", onInput, listen);
        doc.addEventListener("play", onStart, true);
        doc.addEventListener("loadedmetadata", onLength, true);
        doc.addEventListener("loadedmetadata", onStart, true);
        doc.addEventListener("durationchange", onLength, true);
        doc.addEventListener("ratechange", onRate, true);
      },
      kept,
      reset: () => storage.remove(SPEED_KEY2)
    };
  }
  var speedLabel = (rate) => rate === 1 ? "Normal" : `${rate}x`;
  var keep_speed_default = {
    id: "keepSpeed",
    section: "playback",
    android: "Keep the reel speed",
    title: "Keep your video speed",
    description: "The speed you pick in a video's Settings menu stays for every video and reel after it, even after a reload, instead of going back to normal each time. Stories keep their own pace.",
    default: false,
    setup({ doc, win, storage, enabled, diagnostics, actions, toast }) {
      const keeper = createSpeedKeeper({ doc, win: win ?? doc.defaultView, storage, enabled });
      keeper.start();
      diagnostics?.add("Video speed kept", () => speedLabel(keeper.kept()));
      actions?.add("Back to normal speed", () => {
        keeper.reset();
        toast?.(t("New videos play at normal speed again"));
      });
    }
  };

  // src/features/playback/keep-volume.js
  var VOLUME_KEY2 = "keepVolume.state";
  var INPUT_WINDOW3 = 2e3;
  var SETTLED2 = 0.5;
  var MAX_REAPPLY2 = 3;
  var FIGHT_WINDOW = 2e3;
  var WAKE_DELAY = 300;
  var PLAYER_LEVELS = 8;
  var WRITES_PER_SECOND = 10;
  var TOGGLE = /^(mute|unmute)$/i;
  var SAYS_MUTED = /^unmute$/i;
  var isVideo4 = (node) => node?.tagName === "VIDEO";
  var clamp = (value) => Math.min(1, Math.max(0, value));
  var labelOf = (node) => (node.getAttribute("aria-label") ?? "").trim();
  function readVolume(value) {
    if (!value || typeof value !== "object" || !Number.isFinite(value.volume)) return null;
    return { volume: clamp(value.volume), muted: value.muted === true };
  }
  function playerOf2(video, levels = PLAYER_LEVELS) {
    let box2 = video;
    for (let i = 0; i < levels && box2.parentElement; i++) box2 = box2.parentElement;
    return box2;
  }
  function inPlayer(video, target2, levels = PLAYER_LEVELS) {
    if (!target2 || typeof target2.nodeType !== "number") return false;
    return playerOf2(video, levels).contains(target2);
  }
  function volumeSlider(node) {
    const slider = node?.closest?.('[role="slider"], input[type="range"]');
    if (!slider) return null;
    const max = Number(slider.getAttribute("aria-valuemax") ?? slider.getAttribute("max"));
    return max > 0 && max <= 1 ? slider : null;
  }
  function muteToggle(video) {
    let box2 = video;
    for (let i = 0; i < PLAYER_LEVELS && box2.parentElement; i++) {
      box2 = box2.parentElement;
      for (const button of box2.querySelectorAll('[role="button"][aria-label], button[aria-label]')) {
        if (TOGGLE.test(labelOf(button))) return button;
      }
    }
    return null;
  }
  function createVolumeKeeper({
    doc,
    win,
    storage,
    enabled,
    page = false,
    startMuted = () => false,
    now = () => Date.now(),
    trusted = (event) => event.isTrusted,
    defer = (run) => win.setTimeout(run, WAKE_DELAY),
    later: later2 = (run, ms) => win.setTimeout(run, ms)
  }) {
    const ours = /* @__PURE__ */ new WeakMap();
    const putBacks = /* @__PURE__ */ new WeakMap();
    const resynced = /* @__PURE__ */ new WeakMap();
    const settled = /* @__PURE__ */ new WeakSet();
    const heard = /* @__PURE__ */ new WeakSet();
    let lastInput = Number.NEGATIVE_INFINITY;
    let lastPath = [];
    let lastKey = "";
    let inputSeen = false;
    let woken = false;
    let applying = false;
    let unsaved = null;
    let writeQueued = false;
    const writes = [];
    const kept = () => {
      const saved = readVolume(storage.get(VOLUME_KEY2, null));
      return unsaved ?? saved;
    };
    storage.onAccountChange?.(() => {
      unsaved = null;
    });
    function writeUnsaved() {
      writeQueued = false;
      if (!unsaved) return;
      const next = unsaved;
      unsaved = null;
      writes.push(now());
      storage.set(VOLUME_KEY2, next);
    }
    function save(next) {
      while (writes.length && now() - writes[0] >= 1e3) writes.shift();
      unsaved = next;
      if (writes.length < WRITES_PER_SECOND) writeUnsaved();
      else if (!writeQueued) {
        writeQueued = true;
        later2(writeUnsaved, Math.max(0, writes[0] + 1e3 - now()));
      }
    }
    const activated = () => win.navigator?.userActivation?.hasBeenActive ?? inputSeen;
    const mutedFor = (state, current) => state.muted ? true : activated() ? false : current;
    function wanted(video, current) {
      const state = kept();
      const hush = startMuted() && !heard.has(video);
      if (!state && !hush) return null;
      return { volume: state ? state.volume : null, muted: hush || mutedFor(state, current) };
    }
    function give(video) {
      const want = wanted(video, video.muted);
      if (!want) return;
      const volume = want.volume ?? video.volume;
      const { muted } = want;
      const toggle = muteToggle(video);
      const resync = !!toggle && (muted || activated()) && SAYS_MUTED.test(labelOf(toggle)) !== muted && !(now() - (resynced.get(video) ?? Number.NEGATIVE_INFINITY) < FIGHT_WINDOW);
      if (!resync && video.volume === volume && video.muted === muted) return;
      ours.set(video, { volume, muted });
      applying = true;
      try {
        if (resync) {
          resynced.set(video, now());
          toggle.click();
        }
        video.volume = volume;
        video.muted = muted;
      } finally {
        applying = false;
      }
    }
    const skip = (video) => applying || !isVideo4(video) || !enabled();
    const pressed = () => lastPath.find((node) => node.isConnected) ?? null;
    function yours(video) {
      const none = { volume: false, muted: false };
      if (now() - lastInput >= INPUT_WINDOW3) return none;
      const target2 = lastKey ? doc.activeElement : pressed();
      if (!inPlayer(video, target2)) return none;
      if (volumeSlider(target2)) return { volume: true, muted: true };
      const toggle = muteToggle(video);
      if (toggle) return { volume: false, muted: toggle.contains(target2) };
      return { volume: false, muted: !lastKey && video.currentTime >= SETTLED2 };
    }
    function steer(video, name, value) {
      if (skip(video)) return value;
      const want = wanted(video, value === true);
      if (!want) return value;
      const pick = yours(video);
      if (name === "volume") return pick.volume || want.volume === null ? value : want.volume;
      return pick.muted ? value : want.muted;
    }
    function guard() {
      const proto = win.HTMLMediaElement?.prototype;
      if (!proto) return;
      for (const name of ["volume", "muted"]) {
        const own = Object.getOwnPropertyDescriptor(proto, name);
        if (!own?.set || !own.configurable) continue;
        Object.defineProperty(proto, name, {
          ...own,
          set(value) {
            own.set.call(this, steer(this, name, value));
          }
        });
      }
    }
    function putBack2(video) {
      const recent = (putBacks.get(video) ?? []).filter((at) => now() - at < FIGHT_WINDOW);
      putBacks.set(video, recent);
      if (recent.length >= MAX_REAPPLY2) return;
      recent.push(now());
      give(video);
    }
    function onVolume(event) {
      const video = event.target;
      if (skip(video)) return;
      const mine = ours.get(video);
      if (mine && mine.volume === video.volume && mine.muted === video.muted) return;
      ours.delete(video);
      const before = kept();
      const pick = yours(video);
      if (!pick.volume && !pick.muted) {
        if (wanted(video, video.muted)) putBack2(video);
        return;
      }
      if (pick.muted) heard[video.muted ? "delete" : "add"](video);
      const next = {
        volume: pick.volume || !before ? clamp(video.volume) : before.volume,
        muted: pick.muted ? video.muted : before?.muted ?? video.muted
      };
      if (!before || before.volume !== next.volume || before.muted !== next.muted) save(next);
      lastInput = now();
      if (video.volume !== next.volume) give(video);
    }
    function onStart(event) {
      if (skip(event.target)) return;
      give(event.target);
    }
    function onLoad(event) {
      heard.delete(event.target);
      settled.delete(event.target);
    }
    function onTime(event) {
      const video = event.target;
      if (skip(video) || settled.has(video) || video.currentTime < SETTLED2) return;
      settled.add(video);
      give(video);
    }
    function wake() {
      if (!enabled()) return;
      for (const video of doc.querySelectorAll("video")) if (!video.paused) give(video);
    }
    const onInput = (event) => {
      if (!trusted(event)) return;
      lastInput = now();
      lastPath = event.type === "keydown" ? [] : (event.composedPath?.() ?? [event.target]).filter((node) => node?.nodeType === 1);
      lastKey = event.type === "keydown" ? String(event.key ?? "") : "";
      inputSeen = true;
      if (!woken) {
        woken = true;
        defer(wake);
      }
    };
    return {
      start() {
        if (page) guard();
        const listen = { capture: true, passive: true };
        win.addEventListener("pointerdown", onInput, listen);
        win.addEventListener("keydown", onInput, listen);
        doc.addEventListener("loadstart", onLoad, true);
        for (const type of ["loadedmetadata", "play", "playing"]) doc.addEventListener(type, onStart, true);
        doc.addEventListener("timeupdate", onTime, true);
        doc.addEventListener("volumechange", onVolume, true);
        win.addEventListener("pagehide", writeUnsaved);
      },
      kept,
      reset: () => {
        unsaved = null;
        storage.remove(VOLUME_KEY2);
      }
    };
  }
  var volumeLabel = (state) => !state ? "Not set yet" : state.muted ? `Muted (${Math.round(state.volume * 100)}%)` : `${Math.round(state.volume * 100)}%`;
  var keep_volume_default = {
    id: "keepVolume",
    section: "playback",
    android: "Remember your volume",
    title: "Remember your volume",
    description: "The volume you set with a video's slider, and whether the sound is on, carries over to every video and reel after it, even after a reload. Sound starts once you've clicked or typed on the page, as browsers require, and a mute you chose stays. With Start every video muted, each new video starts silent and its speaker button turns the sound on for that one.",
    default: false,
    options: [{ key: "startMuted", type: "toggle", label: "Start every video muted", default: false }],
    setup({ doc, win, net, storage, enabled, option, diagnostics, actions, toast }) {
      const keeper = createVolumeKeeper({
        doc,
        win: win ?? doc.defaultView,
        storage,
        enabled,
        page: !!net,
        startMuted: () => option?.("startMuted") === true
      });
      keeper.start();
      diagnostics?.add("Volume kept", () => volumeLabel(keeper.kept()));
      actions?.add("Forget my volume", () => {
        keeper.reset();
        toast?.(t("New videos start the way Facebook sets them again"));
      });
    }
  };

  // src/features/playback/remember-watched.js
  var WATCHED_KEY2 = "rememberWatched.list";
  var MAX_WATCHED = 50;
  var COUNTS_AFTER = 3;
  var STEP_LIMIT = 1.5;
  var KINDS4 = ["reel", "video", "story"];
  var STORY_PATH = /^\/stories\/([^/?#]+)\/([^/?#]+)/;
  var STORY_PART = /^[\w.%=:-]{1,200}$/;
  var isRecord2 = (value) => Boolean(value) && typeof value === "object" && !Array.isArray(value);
  function entryOf(value) {
    if (!isRecord2(value) || !KINDS4.includes(value.kind) || typeof value.id !== "string" || !Number.isFinite(value.at) || value.at <= 0) return null;
    const story = value.kind === "story";
    if (story ? !(STORY_PART.test(value.id) && typeof value.bucket === "string" && STORY_PART.test(value.bucket)) : !/^\d{6,30}$/.test(value.id)) return null;
    const entry = { kind: value.kind, id: value.id, at: value.at };
    if (story) entry.bucket = value.bucket;
    if (typeof value.owner === "string" && value.owner.trim() && value.owner.length <= 80) entry.owner = value.owner;
    const length = Number.isFinite(value.length) ? Math.round(value.length) : 0;
    if (length >= 1) entry.length = length;
    return entry;
  }
  var entriesOf = (value) => Array.isArray(value) ? value.map(entryOf).filter(Boolean) : [];
  function linkOf(entry) {
    if (entry.kind === "reel") return `/reel/${entry.id}/`;
    if (entry.kind === "video") return `/watch/?v=${entry.id}`;
    return `/stories/${entry.bucket}/${entry.id}/`;
  }
  function addWatched(list, entry) {
    const same = (other) => other.kind === entry.kind && other.id === entry.id;
    return [entry, ...entriesOf(list).filter((other) => !same(other))].slice(0, MAX_WATCHED);
  }
  function storyOf2(href) {
    let url2;
    try {
      url2 = new URL(href);
    } catch {
      return null;
    }
    const found = url2.pathname.match(STORY_PATH);
    return found && STORY_PART.test(found[1]) && STORY_PART.test(found[2]) ? { kind: "story", bucket: found[1], id: found[2] } : null;
  }
  function createWatchList({ doc, storage, enabled, href = () => doc.location.href, now = () => Date.now(), setTimer = setTimeout, clearTimer = clearTimeout }) {
    const tracked = /* @__PURE__ */ new WeakMap();
    let storyTimer = null;
    function keep(target2, extra = {}) {
      const entry = entryOf({ ...extra, ...target2, at: now() });
      if (entry) storage.set(WATCHED_KEY2, addWatched(storage.get(WATCHED_KEY2, []), entry));
    }
    function targetOf2(video) {
      const page = pageTarget(href());
      if (page?.kind === "story") return null;
      const target2 = videoTarget(video, page);
      if (target2?.kind !== "reel" && target2?.kind !== "video") return null;
      const own = (page?.kind === "reel" || page?.kind === "video") && page.id === target2.id;
      return { target: { kind: target2.kind, id: target2.id }, own };
    }
    function onTime(event) {
      const video = event.target;
      if (video?.tagName !== "VIDEO" || !enabled()) return;
      const found = targetOf2(video);
      if (!found) return;
      const key = `${found.target.kind}:${found.target.id}`;
      let state = tracked.get(video);
      if (!state || state.key !== key) {
        state = { key, played: 0, last: video.currentTime, kept: false };
        tracked.set(video, state);
        return;
      }
      const step2 = video.currentTime - state.last;
      state.last = video.currentTime;
      if (state.kept || video.paused || !(step2 > 0 && step2 <= STEP_LIMIT)) return;
      if (!found.own && (video.muted || !(video.volume > 0))) return;
      state.played += step2;
      if (state.played < COUNTS_AFTER) return;
      state.kept = true;
      const length = Number.isFinite(video.duration) ? video.duration : void 0;
      keep(found.target, { owner: authorOf(video) ?? void 0, length });
    }
    function onPage() {
      const story = storyOf2(href());
      if (storyTimer !== null) clearTimer(storyTimer);
      storyTimer = null;
      if (!story) return;
      const at = href();
      storyTimer = setTimer(() => {
        storyTimer = null;
        if (!enabled() || href() !== at || doc.visibilityState === "hidden") return;
        keep(story);
      }, COUNTS_AFTER * 1e3);
    }
    return {
      start(router) {
        doc.addEventListener("timeupdate", onTime, true);
        router?.subscribe?.(onPage);
        onPage();
      },
      entries: () => entriesOf(storage.get(WATCHED_KEY2, [])),
      clear: () => storage.remove(WATCHED_KEY2)
    };
  }
  var kindLabel = (kind) => kind === "reel" ? t("Reel") : kind === "video" ? t("Video") : t("Story");
  function clock2(seconds) {
    const h2 = Math.floor(seconds / 3600);
    const m = Math.floor(seconds % 3600 / 60);
    const s = String(seconds % 60).padStart(2, "0");
    return h2 ? `${h2}:${String(m).padStart(2, "0")}:${s}` : `${m}:${s}`;
  }
  function ago(at, now, lang = "en") {
    const seconds = Math.max(0, Math.round((now - at) / 1e3));
    const steps = [[60, "second", 1], [3600, "minute", 60], [86400, "hour", 3600], [604800, "day", 86400], [Infinity, "week", 604800]];
    const [, unit, size] = steps.find(([limit]) => seconds < limit);
    try {
      return new Intl.RelativeTimeFormat(lang, { numeric: "auto" }).format(-Math.floor(seconds / size), unit);
    } catch {
      return new Date(at).toLocaleString();
    }
  }
  function describe3(entry, now, lang) {
    const kind = kindLabel(entry.kind);
    const parts = [entry.owner ? kind : null, entry.length ? clock2(entry.length) : null, ago(entry.at, now, lang)].filter(Boolean);
    return { label: entry.owner ?? kind, detail: parts.join(" · "), href: linkOf(entry) };
  }
  var remember_watched_default = {
    id: "rememberWatched",
    section: "playback",
    android: "Remember what you watch",
    title: "Remember what you watch",
    description: "Lists the last 50 reels, videos and stories you watched, so one the feed took away is easy to open again. A video in the feed counts once it's played with sound. The list stays in this browser for each Facebook account, and Copy report leaves it out.",
    default: false,
    setup({ doc, router, storage, enabled, toast, diagnostics, actions }) {
      const list = createWatchList({ doc, storage, enabled });
      list.start(router);
      diagnostics?.add("Watched list", () => String(list.entries().length));
      actions?.links(() => {
        const now = Date.now();
        return list.entries().map((entry) => describe3(entry, now, language().lang));
      }, "Nothing watched yet.");
      actions?.add(() => list.entries().length ? "Clear the list" : "", () => {
        list.clear();
        toast?.(t("Cleared the watched list"));
      });
    }
  };

  // src/features/playback/hold-for-speed.js
  var HOLD_MS = 350;
  var FAST = 2;
  var CONTROLS = 'a, button, input, [role="button"], [role="slider"], [role="link"], [role="menu"], [role="dialog"], [data-hushfacebook-web]:not(html)';
  var CLICK_GRACE = 600;
  var inReels = (doc) => /^\/reels?\//.test(doc.location?.pathname ?? "");
  function reelAt(doc, target2, x, y) {
    if (!target2 || target2.closest?.(CONTROLS)) return null;
    for (const video of doc.querySelectorAll("video")) {
      const rect = video.getBoundingClientRect();
      if (rect.width > 0 && x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) return video;
    }
    return null;
  }
  function createHold({ doc, win, enabled, trusted = (event) => event.isTrusted, setTimer = (fn, ms) => win.setTimeout(fn, ms), clearTimer = (id) => win.clearTimeout(id), now = () => Date.now() }) {
    let pending = null;
    let held = null;
    let swallowUntil = null;
    let holds = 0;
    const sourceOf = (video) => video.currentSrc || video.getAttribute("src") || "";
    const counts = ({ video, source }) => enabled() && inReels(doc) && video.isConnected && sourceOf(video) === source;
    function begin() {
      const press = pending;
      pending = null;
      if (!counts(press) || press.video.paused) return;
      const { video, source } = press;
      held = { video, source, rate: video.playbackRate };
      video[HOLDING] = true;
      video.playbackRate = FAST;
      video.addEventListener("loadstart", recheck);
      video.addEventListener("emptied", recheck);
      holds++;
    }
    function release(letGo) {
      if (pending) {
        clearTimer(pending.timer);
        pending = null;
      }
      if (!held) return;
      const { video, rate } = held;
      held = null;
      video.removeEventListener("loadstart", recheck);
      video.removeEventListener("emptied", recheck);
      if (video.playbackRate === FAST) video.playbackRate = rate;
      delete video[HOLDING];
      swallowUntil = letGo ? now() + CLICK_GRACE : null;
    }
    function recheck() {
      if (pending && !counts(pending) || held && !counts(held)) release(false);
    }
    function onDown(event) {
      if (!trusted(event) || event.button !== 0 || !enabled() || !inReels(doc)) return;
      const video = reelAt(doc, event.target, event.clientX, event.clientY);
      if (!video) return;
      release(false);
      pending = { video, source: sourceOf(video), timer: setTimer(begin, HOLD_MS) };
    }
    function onClick(event) {
      if (swallowUntil === null || now() > swallowUntil) return;
      swallowUntil = null;
      event.preventDefault();
      event.stopImmediatePropagation();
    }
    return {
      start() {
        win.addEventListener("pointerdown", onDown, { capture: true, passive: true });
        win.addEventListener("pointerup", () => release(true), { capture: true, passive: true });
        win.addEventListener("pointercancel", () => release(false), { capture: true, passive: true });
        win.addEventListener("blur", () => release(false));
        win.addEventListener("click", onClick, { capture: true });
      },
      recheck,
      state: () => ({ holding: Boolean(held), holds })
    };
  }
  var hold_for_speed_default = {
    id: "holdForSpeed",
    section: "reels",
    android: "Hold a reel for 2x",
    title: "Hold a reel for 2x",
    description: "Press and hold the mouse on a reel and it plays at double speed until you let go. A quick click still works as before.",
    default: false,
    setup({ doc, win, router, settings, enabled, diagnostics }) {
      const hold = createHold({ doc, win: win ?? doc.defaultView, enabled });
      hold.start();
      settings?.subscribe?.(() => hold.recheck());
      router?.subscribe?.(() => hold.recheck());
      diagnostics?.add("Reels held for 2x", () => String(hold.state().holds));
    }
  };

  // src/ui/styles.js
  var uiTokens = `
  --base: #15191f; --mantle: #101419; --crust: #0d1117;
  --surface0: #1a2029; --surface1: #303b4b;
  --text: #edf2f8; --subtext: #a6afbd; --accent: #8abfff; --accent-ink: #12263e;
  --border: #2b333f; --selected: #1c3048; --control: #768599;
  --green: #a6e3a1; --red: #f38ba8; --peach: #fab387;
`;
  var panelCss = `
:host { all: initial; }
*, *::before, *::after { box-sizing: border-box; }
.root {
  ${uiTokens}
  color-scheme: dark;
  font: 14px/1.5 system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  color: var(--text);
  --flip: 1;
}
/* Right to left: start and end swap sides, and a switch's knob slides the other way. The
   launcher stays in Facebook's bottom-left corner. */
.root[dir="rtl"] { --flip: -1; }
button, input, select, textarea { font: inherit; color: inherit; -webkit-tap-highlight-color: transparent; }
button { cursor: pointer; }
:focus-visible { outline: 2px solid var(--accent); outline-offset: 3px; }
svg { flex: none; }
/* Small and faded until pointed at: it sits over the corner of Facebook's left column, where
   the footer links are. */
.launcher {
  position: fixed; left: 12px; bottom: 12px; z-index: 2147483000;
  width: 40px; height: 40px; border-radius: 10px; border: 1px solid var(--surface1);
  background: var(--base); display: grid; place-items: center; box-shadow: 0 4px 14px #0004;
  opacity: 0.8; transition: background 0.15s ease, transform 0.15s ease, opacity 0.15s ease;
}
.launcher:hover, .launcher:focus-visible { opacity: 1; background: var(--selected); transform: translateY(-2px); }
.launcher svg { width: 20px; height: 20px; fill: var(--accent); }
.launcher[hidden] { display: none; }
.dialog {
  width: min(1224px, calc(100vw - 48px)); height: min(960px, calc(100dvh - 64px));
  max-width: none; max-height: none; padding: 0; margin: auto; overflow: hidden;
  display: grid; grid-template-rows: 76px minmax(0, 1fr) 44px;
  font: inherit; color: inherit; color-scheme: dark;
  background: var(--base); border: 1px solid var(--border); border-radius: 10px;
  box-shadow: 0 24px 80px #0006;
}
.dialog:not([open]) { display: none; }
.dialog::backdrop { background: #0b0e13cc; backdrop-filter: blur(6px); }
header { display: flex; align-items: center; justify-content: space-between; gap: 28px; padding: 12px 22px; border-bottom: 1px solid var(--border); background: var(--mantle); }
.brand { min-width: 0; display: flex; align-items: center; gap: 14px; }
.brand-icon { width: 48px; height: 48px; flex: none; display: grid; place-items: center; border-radius: 8px; background: var(--selected); }
.brand-icon svg { width: 26px; height: 26px; fill: var(--accent); }
.brand-copy { min-width: 0; }
header h2 { margin: 0; font-size: 26px; line-height: 32px; font-weight: 650; letter-spacing: -0.4px; }
.brand-subtitle { display: none; }
.chip { flex: none; font-size: 13px; color: var(--subtext); margin-inline-end: 12px; }
.header-actions { flex: none; display: flex; align-items: center; gap: 14px; }
.power-state { font-size: 14px; min-width: 18px; }
.icon-button { border: 1px solid var(--surface1); background: transparent; width: 38px; height: 38px; margin-inline-start: 8px; border-radius: 8px; display: grid; place-items: center; }
.icon-button:hover { background: var(--surface0); }
.icon-button svg { width: 20px; height: 20px; color: var(--subtext); }
.body { display: grid; grid-template-columns: 280px minmax(0, 1fr); min-height: 0; }
nav { padding: 20px 8px 16px; background: var(--mantle); border-inline-end: 1px solid var(--border); overflow: auto; overscroll-behavior: contain; }
.nav-label { margin: 6px 14px 10px; color: var(--subtext); font-size: 11px; font-weight: 650; letter-spacing: 1.6px; text-transform: uppercase; }
.nav-icon { width: 22px; height: 22px; }
nav button {
  position: relative; display: flex; align-items: center; gap: 14px; width: 100%; min-height: 38px; text-align: start;
  border: 0; background: transparent; padding: 8px 14px; margin-block: 2px;
  border-radius: 6px; color: var(--subtext); font-size: 16px; line-height: 22px;
  transition: background 0.15s ease, color 0.15s ease;
}
nav button:hover { background: var(--surface0); color: var(--text); }
nav button[aria-current="page"] { background: var(--selected); color: var(--text); font-weight: 600; }
nav button[aria-current="page"] .nav-icon { color: var(--accent); }
nav button[aria-current="page"]::before { content: ""; position: absolute; inset-block: 0; inset-inline: -8px auto; width: 3px; border-radius: 2px; background: var(--accent); }
nav button:focus-visible { outline-offset: -3px; }
nav hr { border: 0; border-top: 1px solid var(--border); margin: 16px 14px 12px; }
.search-field { position: relative; flex: 1 1 300px; max-width: 404px; min-width: 120px; }
.search-field .nav-icon { position: absolute; inset-inline-start: 12px; top: 12px; pointer-events: none; color: var(--subtext); width: 20px; height: 20px; }
.search {
  display: block; box-sizing: border-box; width: 100%; margin: 0; padding-block: 11px; padding-inline: 44px 12px;
  background: var(--mantle); border: 1px solid var(--control); border-radius: 6px; font-size: 14px; line-height: 20px;
  text-overflow: ellipsis;
}
.search::placeholder { color: var(--subtext); opacity: 0.85; text-overflow: ellipsis; }
.result { padding: 18px 0; border-top: 1px solid var(--border); }
.result:first-child { border-top: 0; }
.result > .card { border: 0; padding: 12px 0 0; }
.result-section {
  display: block; margin: 0; padding: 0; min-height: 24px; border: 0; background: none; cursor: pointer;
  color: var(--accent); font-size: 12px; font-weight: 600; letter-spacing: 0.6px; text-transform: uppercase;
}
.result-section:hover { text-decoration: underline; }
main { min-width: 0; overflow: auto; overscroll-behavior: contain; padding: 28px 32px 32px; scrollbar-gutter: stable; overflow-wrap: anywhere; }
.page-heading { display: flex; align-items: center; gap: 20px; margin: 0; padding-bottom: 20px; border-bottom: 1px solid var(--border); }
.page-icon { display: grid; place-items: center; flex: none; width: 80px; height: 80px; border-radius: 10px; color: var(--accent); background: var(--selected); border: 1px solid #29415c; }
.page-icon .nav-icon { width: 44px; height: 44px; stroke-width: 1.6; }
.page-copy { min-width: 0; flex: 1; }
.page-heading h3 { margin: 0; font-size: 36px; line-height: 44px; font-weight: 650; letter-spacing: -0.7px; }
.page-heading p { margin: 4px 0 0; color: var(--subtext); font-size: 18px; line-height: 26px; }
.setting-count { flex: none; color: var(--subtext); font-size: 13px; }
.reload-card { display: flex; align-items: center; justify-content: space-between; gap: 20px; margin: 20px 0 0; padding: 14px 16px; background: var(--selected); border: 1px solid var(--accent); border-radius: 8px; }
.reload-card .text { min-width: 0; }
.reload-card .button { flex: none; }
.settings-group { padding: 0; }
.card { padding: 20px 2px; border-top: 1px solid var(--border); }
.card:first-child { border-top: 0; }
.card:last-child { border-bottom: 0; }
a.card { display: block; color: inherit; text-decoration: none; }
.link-card:hover .title { color: var(--accent); text-decoration: underline; }
.row { display: flex; align-items: flex-start; gap: 24px; }
.row .text { flex: 1; min-width: 0; }
.title { font-size: 19px; line-height: 26px; font-weight: 600; }
.desc { color: var(--subtext); font-size: 16px; line-height: 24px; margin-top: 5px; }
.note { color: var(--peach); font-size: 13px; line-height: 20px; margin-top: 8px; }
.unavailable .title { color: var(--subtext); }
.options { margin: 16px 0 0; padding-block: 2px; padding-inline: 16px 0; border-inline-start: 2px solid #365675; display: grid; gap: 14px; }
.options label { display: flex; flex-wrap: wrap; align-items: center; gap: 10px 16px; min-width: 0; color: var(--subtext); font-size: 14px; line-height: 22px; }
.options .option-toggle { flex-wrap: nowrap; justify-content: space-between; gap: 14px; }
.option-toggle .switch { order: 1; }
.option-toggle span { min-width: 0; }
.field { min-width: 0; }
.field-error { color: var(--red); font-size: 14px; margin: 8px 0 0; }
.options [aria-invalid="true"] { border-color: var(--red); }
.button[aria-busy="true"] { cursor: progress; }
.options select, .options input[type="text"], .options input[type="number"], .options textarea {
  min-width: 0; max-width: 100%; background: var(--crust); border: 1px solid var(--control); border-radius: 6px; padding: 9px 12px;
}
.options select { flex: 0 1 auto; width: auto; min-width: min(180px, 100%); max-width: min(360px, 100%); text-overflow: ellipsis; }
.options input[type="text"] { width: min(100%, 260px); }
.options input[type="text"][maxlength="7"] { width: min(100%, 128px); }
.options input[type="number"] { width: 110px; }
.options label:has(> textarea) { flex-direction: column; align-items: stretch; gap: 8px; }
.options textarea { display: block; width: 100%; resize: vertical; min-height: 88px; line-height: 1.5; }
.options textarea.code { font-family: ui-monospace, Consolas, Menlo, monospace; font-size: 13px; white-space: pre; tab-size: 2; }
/* The knob's dark outline keeps a 3:1 boundary against the blue track. */
.switch { appearance: none; flex: none; width: 60px; height: 34px; margin: 5px 0 0; border: 1px solid var(--control); border-radius: 5px; background: var(--surface1); position: relative; cursor: pointer; transition: background 0.15s ease; }
.switch::after { content: ""; position: absolute; top: 4px; inset-inline-start: 4px; width: 24px; height: 24px; border-radius: 3px; background: var(--subtext); border: 1px solid transparent; transition: transform 0.15s ease; }
.switch:checked { background: var(--accent); border-color: var(--accent); }
.switch:checked::after { transform: translateX(calc(var(--flip) * 26px)); background: #edf5ff; border-color: #264e7f; }
.switch:disabled, .switch[aria-disabled="true"] { opacity: 0.55; cursor: not-allowed; }
.visually-hidden { position: absolute; width: 1px; height: 1px; margin: -1px; padding: 0; border: 0; overflow: hidden; clip-path: inset(50%); white-space: nowrap; }
.new-dot { position: relative; display: inline-block; flex: none; width: 8px; height: 8px; margin-inline-start: 8px; border-radius: 50%; background: var(--accent); vertical-align: middle; }
nav button .new-dot { margin-inline-start: auto; }
.actions { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 16px; }
.links { list-style: none; margin: 16px 0 0; padding: 0 4px 0 0; max-height: 320px; overflow-y: auto; border-top: 1px solid var(--border); }
.links li { display: flex; flex-direction: column; padding: 8px 0; border-bottom: 1px solid var(--border); min-width: 0; }
.links a { color: var(--accent); text-decoration: none; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.links a:hover { text-decoration: underline; }
.links .detail { color: var(--subtext); font-size: 13px; line-height: 20px; }
.links-empty { color: var(--subtext); font-size: 13px; line-height: 20px; margin-top: 12px; }
.button { min-height: 44px; min-width: min(104px, 100%); max-width: 100%; border: 1px solid var(--control); background: transparent; padding: 10px 18px; border-radius: 6px; font-size: 15px; transition: background 0.15s ease; }
.button:hover { background: var(--surface1); }
a.button { display: inline-flex; align-items: center; text-decoration: none; color: inherit; }
.button.primary { background: var(--accent); color: var(--accent-ink); border-color: var(--accent); font-weight: 600; }
.button.primary:hover { filter: brightness(1.08); }
footer { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 10px 22px; border-top: 1px solid var(--border); color: var(--subtext); background: var(--mantle); font-size: 12px; }
.save-state[data-state="saving"] { color: var(--peach); }
.save-state[data-state="error"] { color: var(--red); font-weight: 600; }
.save-recovery .title { color: var(--red); }
.reset-undo { border-color: var(--accent); }
.diagnostic-summary { padding: 24px 2px; border-bottom: 1px solid var(--border); }
.summary-title { margin: 0 0 14px; font-size: 20px; line-height: 28px; font-weight: 600; }
dl { display: grid; grid-template-columns: minmax(160px, 0.8fr) minmax(0, 1.2fr); gap: 8px 24px; margin: 0; font-size: 16px; line-height: 24px; }
dt:not(:first-of-type), dd:not(:first-of-type) { border-top: 1px solid var(--border); padding-top: 8px; }
dt { color: var(--subtext); }
dd { margin: 0; overflow-wrap: anywhere; }
.subheading { margin: 26px 0 10px; font-size: 20px; line-height: 28px; font-weight: 600; }
.diagnostic-group { padding: 24px 2px; border-bottom: 1px solid var(--border); }
.diagnostic-group .subheading { margin: 0 0 10px; }
.diagnostic-group .empty { margin-top: 20px; padding: 0; border: 0; background: transparent; font-size: 16px; }
.diagnostic-group:last-child { border-bottom: 0; }
.log { font: 12px/1.6 ui-monospace, "Cascadia Code", Consolas, monospace; background: var(--crust); border: 1px solid var(--border); border-radius: 10px; padding: 14px 16px; max-height: 300px; overflow: auto; white-space: pre-wrap; overflow-wrap: anywhere; }
.log .warn { color: var(--peach); }
.log .error { color: var(--red); }
.empty { margin: 12px 0 0; padding: 20px 22px; border: 1px solid var(--border); border-radius: 8px; color: var(--subtext); background: var(--surface0); font-size: 14px; }
.toasts { position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%); width: max-content; max-width: calc(100vw - 32px); z-index: 2147483002; display: grid; gap: 8px; justify-items: center; }
.toast { display: flex; align-items: center; gap: 8px 16px; max-width: 100%; padding: 14px 18px; border-radius: 8px; background: var(--surface0); border: 1px solid var(--surface1); box-shadow: 0 10px 30px #0005; font-size: 14px; overflow-wrap: anywhere; flex-wrap: wrap; animation: rise 0.18s ease-out; }
.toast span { min-width: 0; flex: 1 1 12em; }
.toast .actions { display: flex; flex-wrap: wrap; gap: 4px 12px; margin: 0; margin-inline-start: auto; }
.toast.error { border-color: var(--red); }
.toast button { flex: none; min-height: 32px; border: 0; background: transparent; color: var(--accent); font-weight: 600; padding: 4px; }
@keyframes rise { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
nav, main, .log, textarea { scrollbar-width: thin; scrollbar-color: var(--surface1) transparent; }
@media (max-width: 1100px) {
  header { gap: 18px; }
  header h2 { font-size: 20px; line-height: 26px; }
  .brand { gap: 12px; }
  .brand-icon { width: 40px; height: 40px; }
  .chip { margin-inline-end: 0; }
}
@media (max-width: 900px) {
  .dialog { grid-template-rows: auto minmax(0, 1fr) 44px; }
  header { display: grid; grid-template-columns: minmax(0, 1fr) auto; gap: 12px 18px; }
  header .search-field { grid-column: 1 / -1; grid-row: 2; width: 100%; max-width: none; }
  .header-actions { grid-column: 2; grid-row: 1; }
  .body { grid-template-columns: 210px minmax(0, 1fr); }
  main { padding-inline: 24px; }
  header h2 { font-size: 18px; }
  .brand { gap: 12px; }
  .brand-icon { width: 40px; height: 40px; }
  .page-icon { width: 56px; height: 56px; }
  .page-icon .nav-icon { width: 32px; height: 32px; }
  .page-heading { gap: 14px; flex-wrap: wrap; }
  .page-heading h3 { font-size: 30px; line-height: 36px; }
  .setting-count { margin-inline-start: 70px; }
}
@media (max-width: 640px) {
  .dialog { width: calc(100vw - 16px); height: calc(100dvh - 16px); grid-template-rows: auto minmax(0, 1fr) auto; border-radius: 12px; }
  header { padding: 12px; gap: 12px; }
  header h2 { font-size: 17px; line-height: 22px; letter-spacing: -0.3px; }
  .brand { gap: 10px; }
  .brand-icon { width: 36px; height: 36px; border-radius: 10px; }
  .brand-icon svg { width: 22px; height: 22px; }
  .chip { display: none; }
  .header-actions { gap: 10px; }
  .power-state { display: none; }
  .icon-button { width: 36px; height: 36px; margin-inline-start: 0; }
  .header-actions .switch { width: 40px; height: 24px; }
  .header-actions .switch::after { top: 3px; inset-inline-start: 3px; width: 16px; height: 16px; }
  .header-actions .switch:checked::after { transform: translateX(calc(var(--flip) * 16px)); }
  .body { grid-template-columns: minmax(0, 1fr); grid-template-rows: auto minmax(0, 1fr); }
  nav { display: flex; align-items: center; gap: 4px; padding: 8px; overflow-x: auto; border-inline-end: 0; border-bottom: 1px solid var(--border); }
  .nav-label { display: none; }
  .search-field { min-width: 0; }
  .search-field .nav-icon { top: 10px; width: 18px; height: 18px; }
  .search { width: 100%; padding-block: 9px; padding-inline: 38px 10px; font-size: 13px; }
  nav button { flex: none; gap: 8px; white-space: nowrap; width: auto; min-height: 38px; padding: 7px 12px; border-radius: 6px; font-size: 13px; }
  nav button[aria-current="page"]::before { inset: auto 10px 0; width: auto; height: 2px; }
  nav hr { display: none; }
  main { padding: 20px 14px 24px; }
  .page-heading { display: grid; grid-template-columns: 48px minmax(0, 1fr); gap: 8px 12px; padding-bottom: 20px; }
  .page-icon { width: 48px; height: 48px; grid-row: 1 / span 2; align-self: start; border-radius: 8px; }
  .page-icon .nav-icon { width: 28px; height: 28px; }
  .page-copy { grid-column: 2; }
  .setting-count { grid-column: 2; margin: 0; font-size: 12px; }
  .reload-card { gap: 12px; flex-wrap: wrap; }
  .settings-group { padding: 0; }
  .card { padding-block: 18px; }
  .result { padding-block: 14px; }
  .page-heading h3 { font-size: 26px; line-height: 32px; }
  .page-heading p { font-size: 14px; line-height: 21px; }
  .row { gap: 14px; }
  .title { font-size: 15px; line-height: 22px; }
  .desc { font-size: 13px; line-height: 20px; }
  .options { margin-inline-start: 0; padding-inline-start: 12px; }
  .switch { width: 44px; height: 28px; }
  .switch::after { top: 3px; inset-inline-start: 3px; width: 20px; height: 20px; }
  .switch:checked::after { transform: translateX(calc(var(--flip) * 16px)); }
  .options label { font-size: 13px; }
  .options select, .options input[type="text"] { width: 100%; }
  .actions { gap: 8px; }
  .button { font-size: 13px; }
  dl { grid-template-columns: minmax(0, 1fr); gap: 4px; }
  dd { margin-bottom: 12px; }
  dd:not(:first-of-type) { border-top: 0; padding-top: 0; }
  footer { padding: 10px 18px; font-size: 12px; }
  .footer-brand { display: none; }
}
@media (max-width: 380px) { .brand-icon { display: none; } }
@media (prefers-reduced-motion: reduce) { * { transition: none !important; animation: none !important; } }
@media (forced-colors: active) {
  .switch { appearance: auto; }
  .switch::after { display: none; }
  nav button[aria-current="page"] { border: 1px solid Highlight; }
  .new-dot { forced-color-adjust: none; background: Highlight; }
}
`;

  // src/features/downloads/button.js
  var MIN_SIZE = 160;
  var HIDE_AFTER = 450;
  var LOOK_UP = 6;
  var OWN_LAYER = 12;
  var ROW_HEIGHT = 44;
  var EDGE = 10;
  var CORNER_BAND = 80;
  var CORNER_WIDTH = 200;
  var CORNER_LEVELS = 9;
  var DOWNLOAD_ICON = "M12 4v11m0 0l-4.5-4.5M12 15l4.5-4.5M5 19h14";
  var CSS2 = `
:host { all: initial; ${uiTokens} color-scheme: dark; }
button {
  position: fixed; z-index: 2147483000; display: inline-flex; align-items: center; gap: 6px;
  min-height: 36px; padding: 9px 12px; border: 1px solid var(--surface1); border-radius: 6px;
  background: var(--base); color: var(--text); font: 600 13px/1.2 system-ui, sans-serif;
  cursor: pointer; backdrop-filter: blur(8px); box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
  transition: transform 0.12s ease, background 0.12s ease;
}
button:hover { background: var(--selected); transform: translateY(-1px); }
button:focus-visible { outline: 2px solid var(--accent); outline-offset: 3px; }
button[hidden] { display: none; }
button[aria-busy="true"] { cursor: progress; opacity: 0.8; }
svg { width: 14px; height: 14px; fill: none; stroke: currentColor; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
@media (prefers-reduced-motion: reduce) { button { transition: none; } }
`;
  var FLOATING = "data-hfw-floating";
  var floating = (node) => Boolean(node?.hasAttribute?.(FLOATING) || node?.getRootNode?.()?.host?.hasAttribute?.(FLOATING));
  var big = (rect) => rect.width >= MIN_SIZE && rect.height >= MIN_SIZE;
  var inside = (rect, x, y) => x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
  function ownLayer(media, element) {
    let node = media.parentElement;
    for (let level = 0; node && level < OWN_LAYER; level++, node = node.parentElement) {
      if (node.contains(element)) return true;
    }
    return false;
  }
  function mediaAt(doc, host2, x, y, { through = false } = {}) {
    const stack = typeof doc.elementsFromPoint === "function" ? doc.elementsFromPoint(x, y) : [];
    const above = [];
    for (const element of stack) {
      if (host2 && element === host2) {
        if (through) continue;
        return "button";
      }
      if (element.hasAttribute?.(FLOATING)) continue;
      if ((element.tagName === "VIDEO" || element.tagName === "IMG") && big(element.getBoundingClientRect())) {
        return above.every((layer) => ownLayer(element, layer)) ? element : null;
      }
      above.push(element);
    }
    let node = stack[0] ?? null;
    for (let level = 0; node && level < LOOK_UP; level++, node = node.parentElement) {
      for (const video of node.querySelectorAll("video")) {
        const rect = video.getBoundingClientRect();
        if (big(rect) && inside(rect, x, y)) return video;
      }
    }
    return null;
  }
  function cornerControls(media, rect = media.getBoundingClientRect()) {
    let box2 = media;
    for (let level = 0; level < CORNER_LEVELS && box2.parentElement; level++) box2 = box2.parentElement;
    let lowest = 0;
    for (const control of box2.querySelectorAll('[role="button"], button')) {
      const r = control.getBoundingClientRect();
      if (!r.width || !r.height || r.top < rect.top || r.top >= rect.top + CORNER_BAND || r.right > rect.right || r.right <= rect.right - CORNER_WIDTH) continue;
      lowest = Math.max(lowest, r.bottom - rect.top);
    }
    return lowest;
  }
  var isMedia = (element) => (element.tagName === "VIDEO" || element.tagName === "IMG") && big(element.getBoundingClientRect());
  function covers(media, box2) {
    const area = box2.width * box2.height;
    if (area < 1) return true;
    const width = Math.min(media.right, box2.right) - Math.max(media.left, box2.left);
    const height = Math.min(media.bottom, box2.bottom) - Math.max(media.top, box2.top);
    return width > 0 && height > 0 && width * height >= area / 2;
  }
  function mediaFor(element) {
    if (element?.nodeType !== 1) return null;
    if (isMedia(element)) return element;
    const box2 = element.getBoundingClientRect();
    for (const media of element.querySelectorAll("video, img")) {
      if (isMedia(media) && covers(media.getBoundingClientRect(), box2)) return media;
    }
    const x = (box2.left + box2.right) / 2;
    const y = (box2.top + box2.bottom) / 2;
    let node = element.parentElement;
    for (let level = 0; node && level < LOOK_UP; level++, node = node.parentElement) {
      for (const media of node.querySelectorAll("video, img")) {
        if (isMedia(media) && !element.contains(media) && inside(media.getBoundingClientRect(), x, y)) return media;
      }
    }
    return null;
  }
  var groups = /* @__PURE__ */ new WeakMap();
  function groupFor(doc) {
    let group = groups.get(doc);
    if (group) return group;
    group = {
      members: /* @__PURE__ */ new Set(),
      keyboard: false,
      // The last key was Shift+Tab, so focus that just arrived came up from below.
      backward: false,
      // Focus is being moved by step(), not by the browser.
      moving: false,
      // A button came up or went: the others on the same media close up or make room.
      relayout(except) {
        for (const member of group.members) if (member !== except) member.place();
      },
      onKey(event) {
        group.keyboard = true;
        group.backward = event.key === "Tab" && event.shiftKey;
        if (event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey && !event.defaultPrevented) step(doc, group, event);
      },
      onPointer() {
        group.keyboard = false;
      },
      // After every button has had its say about the element focus reached. Coming up from below
      // with Shift+Tab, focus goes to the last button first, so going back visits them in reverse.
      // Only the focus that Shift+Tab gave: one the page moves later isn't coming up from below.
      onFocusIn(event) {
        if (group.moving) return;
        const backward = group.backward;
        group.backward = false;
        if (!backward) return;
        const row = shownRow(group, event.target);
        if (row.length && doc.activeElement === event.target) move(group, () => row.at(-1).focus());
      }
    };
    doc.addEventListener("keydown", group.onKey, true);
    doc.addEventListener("pointerdown", group.onPointer, true);
    doc.addEventListener("focusin", group.onFocusIn);
    groups.set(doc, group);
    return group;
  }
  function leaveGroup(doc, group, member) {
    group.members.delete(member);
    if (group.members.size || groups.get(doc) !== group) return;
    doc.removeEventListener("keydown", group.onKey, true);
    doc.removeEventListener("pointerdown", group.onPointer, true);
    doc.removeEventListener("focusin", group.onFocusIn);
    groups.delete(doc);
  }
  var shownRow = (group, anchor) => [...group.members].filter((member) => member.shown() && member.anchor() === anchor).sort((a, b) => a.row - b.row);
  function move(group, focus) {
    group.moving = true;
    try {
      focus();
    } finally {
      group.moving = false;
    }
  }
  function step(doc, group, event) {
    const focused = doc.activeElement;
    const on = [...group.members].find((member) => member.shown() && member.host() === focused);
    if (!on) {
      const first = event.shiftKey ? null : shownRow(group, focused)[0];
      if (!first) return;
      event.preventDefault();
      move(group, () => first.focus());
      return;
    }
    const anchor = on.anchor();
    const row = shownRow(group, anchor);
    const next = row[row.indexOf(on) + (event.shiftKey ? -1 : 1)];
    if (next) {
      event.preventDefault();
      move(group, () => next.focus());
      return;
    }
    if (!anchor.isConnected) return;
    move(group, () => anchor.focus({ preventScroll: true }));
    if (event.shiftKey) event.preventDefault();
  }
  function createDownloadButton({ doc, win, find, run, active: active2, log, onMissing, name = "download", text = "Download", busyText = "Saving", icon: icon2 = DOWNLOAD_ICON, row = 0, failText = "The download failed" }) {
    let host2 = null;
    let shadow = null;
    let button = null;
    let current = null;
    let found = null;
    const saving = /* @__PURE__ */ new Set();
    const busy = () => Boolean(current && saving.has(current));
    let hideTimer = null;
    let frame = 0;
    let point = null;
    let anchor = null;
    let stale = false;
    const group = groupFor(doc);
    const member = {
      row,
      host: () => host2,
      anchor: () => anchor,
      // A button left up when the script paused or its switch went off goes as Tab comes by.
      shown() {
        if (!anchor || !button || button.hidden || !host2?.isConnected) return false;
        if (active2()) return true;
        hide2();
        return false;
      },
      focus: () => button.focus({ preventScroll: true }),
      // The media this button is up on, or null.
      over: () => button && !button.hidden && host2?.isConnected ? current : null,
      place: () => place2()
    };
    group.members.add(member);
    function mount() {
      if (host2?.isConnected) return;
      host2 = doc.createElement("div");
      host2.setAttribute("data-hushfacebook-web", name);
      host2.setAttribute(FLOATING, "");
      shadow = host2.attachShadow({ mode: "closed" });
      const style = doc.createElement("style");
      style.textContent = CSS2;
      button = doc.createElement("button");
      button.type = "button";
      button.hidden = true;
      button.addEventListener("click", onClick);
      button.addEventListener("pointerenter", () => clearTimeout(hideTimer));
      button.addEventListener("pointerleave", hideSoon);
      shadow.append(style, button);
      (doc.body ?? doc.documentElement).append(host2);
    }
    function label(words) {
      button.replaceChildren();
      const svg = doc.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("viewBox", "0 0 24 24");
      svg.setAttribute("aria-hidden", "true");
      const path2 = doc.createElementNS("http://www.w3.org/2000/svg", "path");
      path2.setAttribute("d", icon2);
      svg.append(path2);
      button.append(svg, doc.createTextNode(t(words)));
    }
    function hide2() {
      clearTimeout(hideTimer);
      const was = Boolean(button && !button.hidden);
      current = null;
      found = null;
      anchor = null;
      if (button) button.hidden = true;
      if (was) group.relayout(member);
    }
    function held() {
      if (!anchor) return false;
      const focused = doc.activeElement;
      if (!focused || focused === doc.body) return false;
      if (focused === anchor || floating(focused)) return true;
      return Boolean(current) && mediaFor(focused) === current;
    }
    function lookUp(media) {
      try {
        return find(media);
      } catch (error) {
        log?.error("Couldn't work out what to download", error);
        return null;
      }
    }
    function showState() {
      if (busy()) {
        button.setAttribute("aria-busy", "true");
        label(busyText);
      } else {
        button.removeAttribute("aria-busy");
        label(typeof text === "function" ? text(current) : text);
      }
    }
    function hideSoon() {
      clearTimeout(hideTimer);
      hideTimer = setTimeout(() => {
        if (!held()) hide2();
      }, HIDE_AFTER);
    }
    function place2() {
      if (!current || !button) return;
      if (!active2()) {
        hide2();
        return;
      }
      const keep = held();
      if (keep && !current.isConnected && anchor.isConnected) {
        const media = mediaFor(anchor);
        const next = media ? lookUp(media) : null;
        if (next) {
          current = media;
          found = next;
        }
      }
      const rect = current.getBoundingClientRect();
      if (!keep && (!current.isConnected || rect.bottom <= 0 || rect.top >= win.innerHeight || !big(rect))) {
        hide2();
        return;
      }
      const others = [...group.members].filter((other) => other !== member && other.over() === current);
      const slot = others.filter((other) => other.row < row).length;
      const clear = Math.max(EDGE, cornerControls(current, rect) + EDGE / 2);
      const top = Math.max(rect.top, 0) + clear + slot * ROW_HEIGHT;
      const lowest = keep ? win.innerHeight - (others.filter((other) => other.row > row).length + 1) * ROW_HEIGHT : top;
      button.style.top = `${Math.max(Math.min(top, lowest), 0)}px`;
      button.style.right = `${Math.max(win.innerWidth - rect.right, 0) + EDGE}px`;
    }
    function focusOn(element) {
      if (!active2()) return;
      const media = mediaFor(element);
      if (media && media === current && anchor?.isConnected && !stale) return;
      stale = false;
      const next = media ? lookUp(media) : null;
      if (!next) {
        if (anchor) hide2();
        return;
      }
      mount();
      clearTimeout(hideTimer);
      anchor = element;
      current = media;
      found = next;
      showState();
      button.hidden = false;
      place2();
      group.relayout(member);
    }
    function check() {
      frame = 0;
      if (!point) return;
      if (!active2()) {
        hide2();
        return;
      }
      if (anchor) {
        if (held()) return;
        anchor = null;
      }
      mount();
      const target2 = mediaAt(doc, host2, point.x, point.y);
      if (target2 === "button") {
        clearTimeout(hideTimer);
        if (stale && current) {
          stale = false;
          const next = lookUp(current);
          if (!next) {
            hideSoon();
            return;
          }
          found = next;
          showState();
        }
        return;
      }
      if (!target2) {
        if (current) hideSoon();
        return;
      }
      clearTimeout(hideTimer);
      if (target2 !== current || stale) {
        stale = false;
        const next = lookUp(target2);
        if (!next) {
          hideSoon();
          return;
        }
        current = target2;
        found = next;
        showState();
      }
      const was = !button.hidden;
      button.hidden = false;
      place2();
      if (!was) group.relayout(member);
    }
    function fresh() {
      if (!active2()) return null;
      if (!current?.isConnected) {
        if (anchor) current = anchor.isConnected ? mediaFor(anchor) : null;
        else if (point) {
          const below = mediaAt(doc, host2, point.x, point.y, { through: true });
          current = below && below !== "button" ? below : null;
        }
      }
      if (!current) return null;
      return lookUp(current);
    }
    async function onClick(event) {
      event.preventDefault();
      event.stopPropagation();
      if (busy()) return;
      found = fresh();
      if (!found) {
        if (active2()) onMissing?.();
        hide2();
        return;
      }
      const media = current;
      saving.add(media);
      showState();
      try {
        await run(found, shadow);
      } catch (error) {
        log?.error(failText, error);
      } finally {
        saving.delete(media);
        if (current === media) showState();
        if (!current) button.hidden = true;
      }
    }
    const onMove = (event) => {
      point = { x: event.clientX, y: event.clientY };
      if (!frame) frame = win.requestAnimationFrame(check);
    };
    const onScroll = () => {
      if (current) win.requestAnimationFrame(place2);
    };
    const onFocusIn = (event) => {
      const target2 = event.target;
      if (floating(target2)) return;
      if (group.keyboard) focusOn(target2);
      else if (anchor) {
        anchor = null;
        hideSoon();
      }
    };
    doc.addEventListener("pointermove", onMove, { capture: true, passive: true });
    doc.addEventListener("focusin", onFocusIn, true);
    win.addEventListener("scroll", onScroll, { capture: true, passive: true });
    win.addEventListener("resize", onScroll, { passive: true });
    return {
      hide: hide2,
      // For tests: the button's text and whether it shows.
      state: () => ({ shown: Boolean(button && !button.hidden), text: button?.textContent ?? "", top: button?.style.top, right: button?.style.right }),
      click: () => button?.click(),
      // The words may have changed for the media it's on, like Pop out after its window closed.
      refresh() {
        if (current && button && !busy()) showState();
      },
      // Whether the button belongs on its media may have changed, like Frame step's when the
      // video under the pointer or focus pauses or plays: find() is asked again.
      // media: the one that changed. A button up on other media has nothing to look at again.
      recheck(media) {
        if (busy() || media && button && !button.hidden && media !== current) return;
        stale = true;
        const focused = doc.activeElement;
        if (anchor?.isConnected) focusOn(anchor);
        else if (group.keyboard && focused && focused !== doc.body && !floating(focused)) focusOn(focused);
        else if (point && !frame) frame = win.requestAnimationFrame(check);
      },
      stop() {
        if (frame) win.cancelAnimationFrame(frame);
        frame = 0;
        clearTimeout(hideTimer);
        doc.removeEventListener("pointermove", onMove, { capture: true });
        doc.removeEventListener("focusin", onFocusIn, true);
        win.removeEventListener("scroll", onScroll, { capture: true });
        win.removeEventListener("resize", onScroll);
        leaveGroup(doc, group, member);
        anchor = null;
        host2?.remove();
      }
    };
  }

  // src/features/playback/picture-in-picture.js
  var POP_OUT_ICON = "M4 5h16v14H4zM12 12h6v5h-6z";
  function createPopOut({ doc, win, enabled, log, onPopOut }) {
    const button = createDownloadButton({
      doc,
      win,
      log,
      name: "picture-in-picture",
      row: 1,
      icon: POP_OUT_ICON,
      text: (video) => video && doc.pictureInPictureElement === video ? "Back to the page" : "Pop out",
      busyText: "Opening",
      failText: "The video couldn't pop out",
      active: enabled,
      find: (media) => media?.tagName === "VIDEO" && !media.disablePictureInPicture ? { video: media } : null,
      async run({ video }) {
        if (doc.pictureInPictureElement === video) {
          await doc.exitPictureInPicture();
          return;
        }
        await video.requestPictureInPicture();
        onPopOut?.();
      }
    });
    doc.addEventListener("enterpictureinpicture", () => button.refresh(), true);
    doc.addEventListener("leavepictureinpicture", () => button.refresh(), true);
    return button;
  }
  var picture_in_picture_default = {
    id: "pictureInPicture",
    section: "playback",
    android: "Picture-in-picture",
    title: "Picture-in-picture button",
    description: "Point at a video or reel, or Tab to it, and a Pop out button shows in its corner. Click it and the video keeps playing in a small window that stays on top while you use other tabs and apps.",
    default: false,
    setup({ doc, win, enabled, log, diagnostics, markUnavailable }) {
      if (!doc.pictureInPictureEnabled || typeof doc.exitPictureInPicture !== "function") {
        markUnavailable?.("api");
        return;
      }
      let popped = 0;
      createPopOut({ doc, win: win ?? doc.defaultView, enabled, log, onPopOut: () => {
        popped++;
      } });
      diagnostics?.add("Videos popped out", () => String(popped));
    }
  };

  // src/features/playback/frame-step.js
  var FRAME = 1 / 30;
  var BACK_ICON = "M17 6l-8 6 8 6zM7 6v12";
  var NEXT_ICON = "M7 6l8 6-8 6zM17 6v12";
  function stepTime(time, duration, direction) {
    const end = duration > 0 ? duration : Number.POSITIVE_INFINITY;
    return Math.min(Math.max(time + direction * FRAME, 0), end);
  }
  var stoppedVideo = (media) => media?.paused && media.readyState >= 1 ? { video: media } : null;
  function createFrameStep({ doc, win, enabled, log, onStep }) {
    const make = (direction) => {
      const words = direction < 0 ? "Back a frame" : "Next frame";
      return createDownloadButton({
        doc,
        win,
        log,
        name: direction < 0 ? "frame-back" : "frame-next",
        row: direction < 0 ? 2 : 3,
        icon: direction < 0 ? BACK_ICON : NEXT_ICON,
        text: words,
        busyText: words,
        failText: "The video couldn't move a frame",
        active: enabled,
        find: stoppedVideo,
        async run({ video }) {
          const to = stepTime(video.currentTime, video.duration, direction);
          if (to === video.currentTime) return;
          video.currentTime = to;
          onStep?.(direction);
        }
      });
    };
    const buttons = [make(-1), make(1)];
    const recheck = (event) => {
      for (const button of buttons) button.recheck(event.target);
    };
    doc.addEventListener("pause", recheck, true);
    doc.addEventListener("play", recheck, true);
    return {
      buttons,
      stop() {
        doc.removeEventListener("pause", recheck, true);
        doc.removeEventListener("play", recheck, true);
        for (const button of buttons) button.stop();
      }
    };
  }
  var frame_step_default = {
    id: "frameStep",
    section: "playback",
    android: "Frame step",
    title: "Frame step buttons",
    description: "Pause a video or reel, then point at it or Tab to it, and Back a frame and Next frame show in its corner. Each click moves the picture one frame and leaves it paused.",
    default: false,
    setup({ doc, win, enabled, log, diagnostics }) {
      let back = 0;
      let forward = 0;
      createFrameStep({
        doc,
        win: win ?? doc.defaultView,
        enabled,
        log,
        onStep: (direction) => {
          if (direction < 0) back++;
          else forward++;
        }
      });
      diagnostics?.add("Frames stepped", () => `${back} back, ${forward} forward`);
    }
  };

  // src/features/playback/keep-controls.js
  var KEEP = "data-hfw-keep-controls";
  var CHECK_EVERY = 1e3;
  var MAX_LEVELS2 = 12;
  var KEEP_CONTROLS_CSS = `[${KEEP}] { opacity: 1 !important; visibility: visible !important; }`;
  var isVideo5 = (node) => node?.tagName === "VIDEO";
  var TRACKS = 2;
  function positionSlider(video, seen = /* @__PURE__ */ new WeakMap()) {
    const length = Math.round(video.duration);
    if (!Number.isFinite(length) || length <= 0) return null;
    let node = video.parentElement;
    for (let level = 0; node && level < MAX_LEVELS2; level++, node = node.parentElement) {
      const sliders2 = [...node.querySelectorAll('[role="slider"]')];
      if (!sliders2.length) continue;
      const fits = sliders2.filter((slider) => Math.abs(Number(slider.getAttribute("aria-valuemax")) - length) <= 1);
      const moved = /* @__PURE__ */ new Set();
      for (const slider of fits) {
        const value = slider.getAttribute("aria-valuenow");
        const before = seen.get(slider);
        seen.set(slider, value);
        if (before !== void 0 && before !== value) moved.add(slider);
      }
      if (fits.length <= 1) return fits[0] ?? null;
      const tracking = fits.filter((slider) => Math.abs(Number(slider.getAttribute("aria-valuenow") ?? Number.NaN) - video.currentTime) <= TRACKS);
      if (tracking.length <= 1) return tracking[0] ?? null;
      if (video.currentTime <= TRACKS) return null;
      return tracking.find((slider) => moved.has(slider)) ?? null;
    }
    return null;
  }
  function keepShown(video, slider, styleOf2) {
    let marked = false;
    for (let node = slider; node && !node.contains(video); node = node.parentElement) {
      if (node.hasAttribute(KEEP)) continue;
      const style = styleOf2(node);
      if (Number(style.opacity) < 1 || style.visibility === "hidden") {
        node.setAttribute(KEEP, "");
        marked = true;
      }
    }
    return marked;
  }
  function createControlsKeeper({ doc, enabled, now = () => Date.now(), styleOf: styleOf2 = (node) => doc.defaultView.getComputedStyle(node), inReelsOrStories = () => /^\/(?:reels?|stories)\//.test(doc.location?.pathname ?? "") }) {
    const checked = /* @__PURE__ */ new WeakMap();
    const values = /* @__PURE__ */ new WeakMap();
    let kept = 0;
    function check(video) {
      if (!isVideo5(video) || !enabled() || inReelsOrStories()) return;
      const time = now();
      if (time - (checked.get(video) ?? Number.NEGATIVE_INFINITY) < CHECK_EVERY) return;
      checked.set(video, time);
      const slider = positionSlider(video, values);
      if (slider && keepShown(video, slider, styleOf2)) kept++;
    }
    return {
      start() {
        doc.addEventListener("timeupdate", (event) => check(event.target), true);
        doc.addEventListener("pause", (event) => check(event.target), true);
      },
      check,
      // Switched off: the CSS stops applying, and the marks go too so nothing is left behind.
      clear() {
        for (const node of doc.querySelectorAll(`[${KEEP}]`)) node.removeAttribute(KEEP);
      },
      kept: () => kept
    };
  }
  var keep_controls_default = {
    id: "keepControls",
    section: "playback",
    android: "Keep the progress bar",
    title: "Keep video controls on screen",
    description: "A video's progress bar and buttons stay on screen instead of fading out when you move the mouse away. Reels already keep theirs.",
    default: false,
    css: KEEP_CONTROLS_CSS,
    setup({ doc, enabled, settings, diagnostics }) {
      const keeper = createControlsKeeper({ doc, enabled });
      keeper.start();
      settings?.subscribe(() => {
        if (!enabled()) keeper.clear();
      });
      diagnostics?.add("Video controls kept on screen", () => String(keeper.kept()));
    }
  };

  // src/features/playback/video-quality.js
  var CHOICES = [
    { value: "highest", label: "The best it has" },
    { value: "1080", label: "Up to 1080p" },
    { value: "720", label: "Up to 720p" },
    { value: "480", label: "Up to 480p, to save data" },
    { value: "360", label: "Up to 360p, to save the most data" }
  ];
  var MARKERS5 = ['"manifest_xml"', '"dash_manifest"', '"all_video_dash_prefetch_representations"', '"dash_prefetch_experimental"'];
  var MAX_REMEMBERED3 = 5e3;
  var SET2 = /<AdaptationSet\b[^>]*?(?:\/>|>[\s\S]*?<\/AdaptationSet>)/g;
  var REPRESENTATION2 = /<Representation\b[^>]*?(?:\/>|>[\s\S]*?<\/Representation>)/g;
  var isVideoSet = (set) => /^<AdaptationSet\b[^>]*\bcontentType="video"/.test(set) || /^<AdaptationSet\b[^>]*\bmimeType="video\//.test(set) || !/^<AdaptationSet\b[^>]*\bcontentType=/.test(set) && /<Representation\b[^>]*\bmimeType="video\//.test(set);
  function qualityOf(representation) {
    const label = representation.match(/\bFBQualityLabel="(\d+)p/);
    if (label) return Number(label[1]);
    const width = Number(representation.match(/\bwidth="(\d+)"/)?.[1]);
    const height = Number(representation.match(/\bheight="(\d+)"/)?.[1]);
    return width && height ? Math.min(width, height) : null;
  }
  function keepQualities(qualities, choice) {
    const known = qualities.filter((quality) => quality !== null);
    if (!known.length) return qualities.map(() => true);
    if (choice === "highest") {
      const best = Math.max(...known);
      return qualities.map((quality) => quality === best);
    }
    const cap = Number(choice);
    if (!Number.isFinite(cap)) return qualities.map(() => true);
    const under = known.filter((quality) => quality <= cap);
    const allowed = under.length ? (quality) => quality !== null && quality <= cap : (quality) => quality === Math.min(...known);
    return qualities.map(allowed);
  }
  var copyId = (representation) => representation.match(/^<Representation\b[^>]*?\bid="([^"]+)"/)?.[1] ?? null;
  function createCopyBook() {
    const copies = /* @__PURE__ */ new Map();
    let answer = 0;
    let set = 0;
    let last = null;
    const changing = () => {
      if (last && !last.copies) last.copies = new Map(copies);
    };
    const put = (id, entry) => {
      changing();
      copies.delete(id);
      copies.set(id, entry);
    };
    return {
      // The book as it is now, order included, put back by the function this returns, for an
      // answer the page never got. Entries are replaced, never changed, so a shallow copy holds.
      checkpoint() {
        const at = { answer, set, copies: null };
        last = at;
        return () => {
          if (at.copies) {
            copies.clear();
            for (const [id, entry] of at.copies) copies.set(id, entry);
          }
          ({ answer, set } = at);
        };
      },
      nextAnswer() {
        answer++;
      },
      instead: (id) => copies.get(id)?.best ?? null,
      kept: (id) => copies.has(id) && copies.get(id).best === null,
      quality: (id) => copies.get(id)?.best === null ? copies.get(id).quality : null,
      makeRoom(count) {
        set++;
        let forgetting = null;
        for (const [id, entry] of copies) {
          if (entry.set !== forgetting) {
            if (copies.size + count <= MAX_REMEMBERED3 || entry.answer >= answer) return;
            forgetting = entry.set;
          }
          changing();
          copies.delete(id);
        }
      },
      keep(id, quality = null) {
        if (id) put(id, { quality, best: null, answer, set });
      },
      replace(id, best) {
        if (id && best) put(id, { quality: null, best, answer, set });
      }
    };
  }
  function capManifest(xml, choice, book = createCopyBook()) {
    if (typeof xml !== "string" || !xml.includes("<Representation")) return xml;
    return xml.replace(SET2, (set) => {
      if (!isVideoSet(set)) return set;
      const copies = set.match(REPRESENTATION2) ?? [];
      if (!copies.length) return set;
      const qualities = copies.map(qualityOf);
      const keep = copies.length < 2 ? [true] : keepQualities(qualities, choice);
      let best = null;
      copies.forEach((copy, i) => {
        if (keep[i] && (best === null || (qualities[i] ?? -1) >= (qualities[best] ?? -1))) best = i;
      });
      book.makeRoom(copies.length);
      copies.forEach((copy, i) => {
        if (keep[i]) book.keep(copyId(copy), qualities[i]);
        else book.replace(copyId(copy), copyId(copies[best]));
      });
      if (keep.every(Boolean)) return set;
      let index = 0;
      return set.replace(REPRESENTATION2, (copy) => keep[index++] ? copy : "");
    });
  }
  var isVideoCopy = (copy) => /^video\//.test(copy?.mime_type ?? "");
  function capPrefetch(entry, book) {
    const copies = entry?.representations;
    if (!Array.isArray(copies) || !copies.some(isVideoCopy)) return { entry, changed: false };
    const keeps = (copy) => !isVideoCopy(copy) || book.kept(copy?.representation_id);
    if (!copies.some((copy) => isVideoCopy(copy) && keeps(copy))) return null;
    const left = copies.filter(keeps);
    let changed = left.length !== copies.length;
    if (changed) entry.representations = left;
    if (Array.isArray(entry.initial_representation_ids)) {
      const ids = new Set(left.map((copy) => copy?.representation_id));
      const videos = new Set(copies.filter(isVideoCopy).map((copy) => copy.representation_id));
      const bestLeft = left.filter(isVideoCopy).map((copy) => copy.representation_id).reduce((best, id) => best === null || (book.quality(id) ?? -1) > (book.quality(best) ?? -1) ? id : best, null);
      const swap = (id) => {
        const best = book.instead(id);
        if (best === null) return videos.has(id) && !ids.has(id) ? bestLeft ?? id : id;
        return ids.has(best) ? best : bestLeft ?? best;
      };
      const initial = [...new Set(entry.initial_representation_ids.map(swap))].filter((id) => ids.has(id));
      if (initial.length !== entry.initial_representation_ids.length || initial.some((id, i) => id !== entry.initial_representation_ids[i])) {
        entry.initial_representation_ids = initial;
        changed = true;
      }
    }
    return { entry, changed };
  }
  function capAnswer(data, choice, book = createCopyBook()) {
    book.nextAnswer();
    let videos = 0;
    let changed = false;
    const cap = (holder, key) => {
      const before = holder[key];
      const after = capManifest(before, choice, book);
      if (after !== before) {
        holder[key] = after;
        videos++;
        changed = true;
      }
    };
    walk(data, (value) => {
      if (Array.isArray(value.dash_manifests)) {
        for (const entry of value.dash_manifests) if (entry && typeof entry.manifest_xml === "string") cap(entry, "manifest_xml");
      }
      if (typeof value.dash_manifest === "string") cap(value, "dash_manifest");
    });
    walk(data, (value) => {
      const list = value.all_video_dash_prefetch_representations;
      if (Array.isArray(list)) {
        const results = list.map((entry) => capPrefetch(entry, book));
        const ready = results.filter(Boolean).map((result) => result.entry);
        if (ready.length !== list.length) {
          value.all_video_dash_prefetch_representations = ready;
          changed = true;
        }
        if (results.some((result) => result?.changed)) changed = true;
      }
      const picks = value.dash_prefetch_experimental;
      if (Array.isArray(picks) && picks.some((id) => book.instead(id) !== null)) {
        value.dash_prefetch_experimental = picks.map((id) => book.instead(id) ?? id);
        changed = true;
      }
    });
    return { videos, changed };
  }
  var video_quality_default = {
    id: "videoQuality",
    section: "playback",
    android: "Default playback quality",
    title: "Default video quality",
    description: "Videos and reels play at the quality you pick instead of the one Facebook picks for your connection. A video with nothing under your cap plays its smallest copy. It applies to videos Facebook loads after you change it.",
    default: false,
    needsPage: true,
    options: [{ key: "quality", type: "select", label: "Play videos at", default: "highest", choices: CHOICES }],
    setup({ net, enabled, option, diagnostics }) {
      let videos = 0;
      let book = createCopyBook();
      let bookFor = null;
      net.transformResponses({
        id: "videoQuality",
        enabled,
        markers: MARKERS5,
        // Facebook's own JSON.parse sees every answer and the page's inline data, so one place
        // covers them all.
        match: (ctx) => ctx.transport === "json-parse",
        transform(data, ctx, stage) {
          const choice = option("quality") ?? "highest";
          if (choice !== bookFor) {
            book = createCopyBook();
            bookFor = choice;
          }
          if (stage) stage.undo(book.checkpoint());
          const result = capAnswer(data, choice, book);
          if (result.videos) {
            later(stage, () => {
              videos += result.videos;
              diagnostics?.changed();
            });
          }
          return result.changed;
        }
      });
      diagnostics?.add("Videos set to your quality", () => String(videos));
    }
  };

  // src/features/appearance/declutter-table.js
  var HOSTS = ["https://www.facebook.com", "https://web.facebook.com"];
  var absolute = (path2) => HOSTS.map((host2) => `a[href^="${host2}${path2}"]`).join(", ");
  var LEFT = `[role="navigation"]:not([role="banner"] *):has(${absolute("/friends/")}):has(${absolute("/groups/")})`;
  var MENU2 = '[role="dialog"]:has(a[href*="/pages/creation/"]):has(a[href*="/events/create/"])';
  function section(path2) {
    return [`a[href="${path2}"]`, `a[href^="${path2}?"]`, ...HOSTS.flatMap((host2) => [`a[href="${host2}${path2}"]`, `a[href^="${host2}${path2}?"]`])].join(", ");
  }
  var OFFSITE = 'a[href*="l.facebook.com/l.php"], a[href^="http"]:not([href*="facebook.com"]):not([href*="fbcdn.net"])';
  var TAB_ROWS = [
    { option: "video", label: "Video", link: [section("/watch/"), section("/reel/"), section("/video/")].join(", ") },
    { option: "marketplace", label: "Marketplace", link: section("/marketplace/") },
    { option: "gaming", label: "Gaming", link: section("/gaming/") },
    { option: "groups", label: "Groups", link: section("/groups/") },
    { option: "friends", label: "Friends", link: section("/friends/") }
  ];
  var PROMOTION_ROWS = [
    { option: "ads", label: "Ads Manager, Your Ad Activity and Create an ad", link: [section("/ad_campaign/landing.php"), section("/adsmanager/"), section("/ads/activity/"), 'a[href^="/ads/create_ad/"]', absolute("/ads/create_ad/")].join(", ") },
    { option: "gaming", label: "Gaming Video and Play games", link: [section("/gaming/"), section("/gaming/play/")].join(", ") }
  ];
  var UPSELL_LINK = [OFFSITE, section("/messenger_kids/")].join(", ");
  var each = (link, wrap) => link.split(/,\s*(?![^()]*\))/).map(wrap).join(",\n");
  var place = {
    tab: (link) => each(link, (a) => `[role="banner"] li:has(${a})`),
    left: (link) => each(link, (a) => `${LEFT} li:has(${a})`),
    menu: (link) => each(link, (a) => `${MENU2} [role="listitem"]:has(${a})`)
  };
  var FIND_FRIENDS = '[role="banner"] [role="navigation"] div:has(> a[href^="/friends/"]:not([aria-label]))';
  var NEW_MESSAGE = '[role="button"]:has(path[d^="M17.99.93a1.75"]):not([role="banner"] *):not([role="main"] *):not([role="navigation"] *):not([role="dialog"] *)';
  var hide = (selectors) => `${selectors} { display: none !important; }`;

  // src/features/opening/start.js
  var CLAIM = /* @__PURE__ */ Symbol.for("hushfacebook-web.home-redirect");
  var START = /* @__PURE__ */ Symbol.for("hushfacebook-web.visit-start");
  var STARTED_KEY = "hfw:started";
  function isPlainHome(href) {
    const url2 = new URL(href);
    return /^(www|web)\.facebook\.com$/.test(url2.hostname) && parseRoute(href).type === "home" && url2.search === "";
  }
  var onceLoaded = (settings, run) => settings?.whenLoaded ? settings.whenLoaded(run) : run();
  function claimHomeRedirect(win, id) {
    if (win[CLAIM] && win[CLAIM] !== id) return false;
    win[CLAIM] = id;
    return true;
  }
  function sameTabLink(event) {
    if (event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return null;
    const anchor = event.composedPath().find((node) => node?.tagName === "A" && node.hasAttribute?.("href"));
    if (!anchor || anchor.hasAttribute("download")) return null;
    const target2 = anchor.getAttribute("target")?.trim().toLowerCase();
    return !target2 || target2 === "_self" ? anchor : null;
  }
  function isVisitStart(win) {
    if (win[START] !== void 0) return win[START];
    let start;
    try {
      start = !win.sessionStorage.getItem(STARTED_KEY);
      win.sessionStorage.setItem(STARTED_KEY, "1");
    } catch {
      start = false;
    }
    const entry = win.performance?.getEntriesByType?.("navigation")?.[0];
    if (entry && entry.type !== "navigate") start = false;
    win[START] = start;
    return start;
  }

  // src/features/opening/marketplace-only.js
  var MARKETPLACE = "/marketplace/";
  var MARKETPLACE_LINKS = ['[role="banner"] a[href="/marketplace/"]', ...HOSTS.map((host2) => `[role="navigation"] a[href^="${host2}/marketplace/"]`)].join(", ");
  var LOOP_MARK = "data-hfw-marketplace-loop";
  var GUARD_KEY = "hfw:marketplaceOnlyGuard";
  var BOUNCE_MS = 6e4;
  var MAX_BOUNCES = 4;
  var STOP_MS = 10 * 6e4;
  var OTHER_TABS = ['a[href="/"]', ...TAB_ROWS.filter((row) => row.option !== "marketplace").map((row) => row.link)].join(", ");
  var MARKETPLACE_ONLY_CSS = [
    hide([place.tab(OTHER_TABS), FIND_FRIENDS].join(",\n")),
    `html[data-hfw-route="home"]:not([${LOOP_MARK}]) [role="main"] { visibility: hidden !important; }`
  ].join("\n");
  function readGuard(storage) {
    try {
      const guard = JSON.parse(storage.getItem(GUARD_KEY) ?? "{}");
      return guard && typeof guard === "object" ? guard : {};
    } catch {
      return {};
    }
  }
  function mayRedirect(win, now = Date.now()) {
    try {
      const storage = win.sessionStorage;
      const guard = readGuard(storage);
      if (Number.isFinite(guard.stopped) && now - guard.stopped >= 0 && now - guard.stopped < STOP_MS) return false;
      const bounced = Number.isFinite(guard.sent) && now - guard.sent >= 0 && now - guard.sent < BOUNCE_MS;
      const bounces = bounced ? (Number(guard.bounces) || 0) + 1 : 0;
      if (bounces >= MAX_BOUNCES) {
        storage.setItem(GUARD_KEY, JSON.stringify({ stopped: now }));
        return false;
      }
      storage.setItem(GUARD_KEY, JSON.stringify({ sent: now, bounces }));
      return true;
    } catch {
      return true;
    }
  }
  function noteInput(win) {
    try {
      const guard = readGuard(win.sessionStorage);
      if (Number.isFinite(guard.sent)) win.sessionStorage.removeItem(GUARD_KEY);
    } catch {
    }
  }
  var isHome = (href) => {
    try {
      const url2 = new URL(href);
      return /^(www|web)\.facebook\.com$/.test(url2.hostname) && parseRoute(href).type === "home";
    } catch {
      return false;
    }
  };
  function goToMarketplace(win) {
    const link = win.document.querySelector(MARKETPLACE_LINKS);
    if (link) link.click();
    else win.location.assign(MARKETPLACE);
  }
  var marketplace_only_default = {
    id: "marketplaceOnly",
    section: "opening",
    android: "Marketplace only",
    title: "Marketplace only",
    description: "Turns Facebook into Marketplace for buying and selling, without the feed. Facebook opens on Marketplace, Home takes you there too, and the top bar keeps only Marketplace and its buttons. Profiles, chats and notifications still open. While this is on, Open on a chosen tab waits.",
    default: false,
    css: MARKETPLACE_ONLY_CSS,
    setup({ win, router, settings, enabled, log }) {
      let warned = false;
      const leaveHome = () => {
        if (mayRedirect(win)) {
          win.location.replace(MARKETPLACE);
          return;
        }
        win.document?.documentElement?.setAttribute(LOOP_MARK, "");
        if (warned) return;
        warned = true;
        log?.warn("Marketplace only stopped sending Home to Marketplace for a while, because Marketplace keeps sending this tab back. It may not be open to this account.");
      };
      let wasOn = null;
      onceLoaded(settings, () => {
        wasOn = enabled();
        if (wasOn && isHome(win.location.href) && claimHomeRedirect(win, "marketplaceOnly")) leaveHome();
      });
      settings?.subscribe?.(() => {
        if (wasOn === null) return;
        const on = enabled();
        const turnedOn = on && !wasOn;
        wasOn = on;
        if (turnedOn && isHome(win.location.href)) leaveHome();
      });
      let counting = true;
      const onInput = (event) => {
        if (!counting || !event.isTrusted || !enabled() || isHome(win.location.href)) return;
        counting = false;
        noteInput(win);
      };
      win.addEventListener("pointerdown", onInput, { capture: true, passive: true });
      win.addEventListener("keydown", onInput, { capture: true, passive: true });
      win.addEventListener("click", (event) => {
        if (!enabled()) return;
        const anchor = sameTabLink(event);
        if (!anchor || !isHome(anchor.href)) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        goToMarketplace(win);
      }, { capture: true });
      router?.subscribe((route) => {
        if (route.type !== "home") win.document?.documentElement?.removeAttribute(LOOP_MARK);
        else if (enabled()) leaveHome();
      });
    }
  };

  // src/features/opening/following-feed.js
  var GUARD_KEY2 = "hfw:followingFeedRedirect";
  var GUARD_MS = 15e3;
  function followingFeedUrl(filter) {
    return `/?filter=${encodeURIComponent(filter)}&sk=h_chr`;
  }
  var following_feed_default = {
    id: "followingFeed",
    section: "opening",
    android: "Following feed on Home",
    title: "Following feed on Home",
    description: "Home shows the newest posts from the friends, groups and Pages you follow instead of Facebook's ranked feed.",
    default: false,
    options: [
      {
        key: "filter",
        type: "select",
        label: "Show posts from",
        default: "all",
        choices: [
          { value: "all", label: "Everyone you follow" },
          { value: "friends", label: "Friends" },
          { value: "favorites", label: "Favorites" },
          { value: "groups", label: "Groups" },
          { value: "pages", label: "Pages" }
        ]
      }
    ],
    setup({ win, settings, enabled, option, log }) {
      const target2 = () => followingFeedUrl(option("filter"));
      onceLoaded(settings, () => {
        if (!enabled() || !isPlainHome(win.location.href) || !claimHomeRedirect(win, "followingFeed")) return;
        let recent;
        try {
          recent = Date.now() - Number(win.sessionStorage.getItem(GUARD_KEY2) ?? 0) < GUARD_MS;
          win.sessionStorage.setItem(GUARD_KEY2, String(Date.now()));
        } catch {
          recent = false;
        }
        if (recent) log.warn("Facebook sent Home back to its ranked feed, so the Following feed redirect stopped to avoid a loop");
        else win.location.replace(target2());
      });
      win.addEventListener(
        "click",
        (event) => {
          if (!enabled()) return;
          const anchor = sameTabLink(event);
          if (!anchor || !isPlainHome(anchor.href)) return;
          event.preventDefault();
          event.stopImmediatePropagation();
          win.location.assign(target2());
        },
        { capture: true }
      );
    }
  };

  // src/features/opening/open-on-tab.js
  var TABS = [
    { value: "marketplace", label: "Marketplace", path: "/marketplace/" },
    { value: "feeds", label: "Feeds, newest posts first", path: followingFeedUrl("all") },
    { value: "video", label: "Video", path: "/watch/" },
    { value: "friends", label: "Friends", path: "/friends/" },
    { value: "groups", label: "Your groups feed", path: "/groups/feed/" },
    { value: "notifications", label: "Notifications", path: "/notifications/" },
    { value: "menu", label: "Menu", path: "/bookmarks/" }
  ];
  function startPath(tab, settings) {
    if (tab === "feeds" && settings?.enabled("followingFeed")) return followingFeedUrl(settings.get("followingFeed.filter") ?? "all");
    return (TABS.find((entry) => entry.value === tab) ?? TABS[0]).path;
  }
  var open_on_tab_default = {
    id: "openOnTab",
    section: "opening",
    android: "Open on a chosen tab",
    title: "Open on a chosen tab",
    description: "Facebook opens on the page you pick instead of Home when you start it in a new tab, so you can skip the feed. Links into Facebook still open where they lead, and Home is still there when you click it.",
    default: false,
    options: [
      { key: "tab", type: "select", label: "Open on", default: "marketplace", choices: TABS.map(({ value, label }) => ({ value, label })) }
    ],
    setup({ win, settings, enabled, option, log }) {
      const start = isVisitStart(win);
      onceLoaded(settings, () => {
        if (!start || !enabled() || !isPlainHome(win.location.href) || !claimHomeRedirect(win, "openOnTab")) return;
        const path2 = startPath(option("tab"), settings);
        log?.info("Open on a chosen tab: this visit starts on", path2);
        win.location.replace(path2);
      });
    }
  };

  // src/features/opening/messenger-page.js
  var MESSAGES_PATH = "/messages/";
  var BUTTON2 = '[role="banner"] [role="button"][aria-label="Messenger"]';
  var PRESSES = ["pointerdown", "mousedown", "pointerup", "mouseup", "touchstart"];
  var messengerButton = (target2) => typeof target2?.closest === "function" ? target2.closest(BUTTON2) : null;
  function messengerTarget(event) {
    if (event.type === "keydown") return event.key === "Enter" || event.key === " " ? "here" : null;
    if (event.type === "auxclick") return event.button === 1 ? "tab" : null;
    if (event.type !== "click" || event.button !== 0) return null;
    return event.ctrlKey || event.metaKey || event.shiftKey ? "tab" : "here";
  }
  var messenger_page_default = {
    id: "messengerPage",
    section: "opening",
    android: "Open Messenger from the top bar",
    title: "Open Messenger as a full page",
    description: "The Messenger button in the top bar goes straight to the Messages page instead of opening the list of chats over Facebook.",
    default: false,
    needsPage: false,
    setup({ doc, win, enabled, log, diagnostics }) {
      let sent = 0;
      const stop = (event) => {
        event.preventDefault();
        event.stopImmediatePropagation();
      };
      const go = (where) => {
        sent++;
        diagnostics?.changed();
        try {
          if (where === "tab") win.open(MESSAGES_PATH, "_blank", "noopener");
          else win.location.assign(MESSAGES_PATH);
        } catch (error) {
          log?.error("Couldn't open the Messages page", error);
        }
      };
      const onPress = (event) => {
        if (enabled() && messengerButton(event.target)) stop(event);
      };
      const onActivate = (event) => {
        if (!enabled() || !messengerButton(event.target)) return;
        const where = messengerTarget(event);
        if (event.type === "keydown" && !where) return;
        stop(event);
        if (where) go(where);
      };
      for (const type of PRESSES) doc.addEventListener(type, onPress, { capture: true, passive: false });
      for (const type of ["click", "auxclick", "keydown"]) doc.addEventListener(type, onActivate, true);
      diagnostics?.add("Messenger button presses sent to Messages", () => String(sent));
    }
  };

  // src/core/media-index.js
  var MAX_ITEMS2 = 4e3;
  var PHOTO_IMAGES = ["viewer_image", "image", "photo_image", "previewImage", "large_image"];
  var LEGACY_VIDEO = [
    ["playable_url_quality_hd", "HD"],
    ["browser_native_hd_url", "HD"],
    ["playable_url", "SD"],
    ["browser_native_sd_url", "SD"]
  ];
  var MEDIA_MARKERS = ['"progressive_url"', '"playable_url', '"browser_native_', '"viewer_image"', '"photo_image"', '"image":{"uri"', '"story_card_info"'];
  var isObject3 = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
  var isUrl = (value) => typeof value === "string" && /^https:\/\//.test(value);
  function fileSide(file, width, height) {
    const cap = file.quality === "HD" ? 720 : 360;
    const coded = codedWidth(file.url);
    if (coded && width && height) return Math.min(coded, Math.round(coded * height / width));
    if (coded) return Math.min(coded, cap);
    return cap;
  }
  function codedWidth(url2) {
    try {
      const efg = new URL(url2).searchParams.get("efg").replace(/ /g, "+");
      return Number(JSON.parse(atob(efg)).vencode_tag.match(/\.C\d+\.(\d+)\./)[1]) || null;
    } catch {
      return null;
    }
  }
  var SHARPER = 1.05;
  function sharperCopies(manifest, file, width, height, length) {
    if (!manifest || !file) return null;
    const side = fileSide(file, width, height);
    const source = width && height ? Math.min(width, height) : Infinity;
    const sideOf = (copy) => copy.width && copy.height ? Math.min(copy.width, copy.height) : copy.quality;
    const video = manifest.video.filter((copy) => sideOf(copy) > side * SHARPER && sideOf(copy) <= source);
    const duration = manifest.duration ?? length;
    if (!video.length || !(duration > 0) || !video.every((copy) => copy.bandwidth > 0)) return null;
    return { live: false, duration, video, audio: manifest.audio };
  }
  function videoFiles(video) {
    const result = video?.videoDeliveryResponseFragment?.videoDeliveryResponseResult;
    const files = [];
    const seen = /* @__PURE__ */ new Set();
    const add = (url2, quality) => {
      if (!isUrl(url2) || seen.has(url2)) return;
      seen.add(url2);
      files.push({ url: url2, quality });
    };
    for (const entry of Array.isArray(result?.progressive_urls) ? result.progressive_urls : []) {
      if (entry?.failure_reason) continue;
      add(entry?.progressive_url, entry?.metadata?.quality === "HD" ? "HD" : "SD");
    }
    for (const source of [video, video?.videoDeliveryLegacyFields]) {
      for (const [key, quality] of LEGACY_VIDEO) add(source?.[key], quality);
    }
    files.sort((a, b) => a.quality === b.quality ? 0 : a.quality === "HD" ? -1 : 1);
    const dash = Boolean(result?.dash_manifests?.length || result?.dash_manifest_urls?.length || result?.hls_playlist_urls?.length || video?.dash_manifest || video?.playlist);
    const xml = (Array.isArray(result?.dash_manifests) ? result.dash_manifests : []).find((m) => typeof m?.manifest_xml === "string")?.manifest_xml ?? video?.dash_manifest;
    const manifest = readManifest(xml);
    const length = Number(video?.playable_duration_in_ms) / 1e3 || Number(video?.length_in_second) || null;
    let stream = null;
    if (!files.length) {
      const live = Array.isArray(result?.progressive_urls) && result.progressive_urls.some((entry) => /Live/.test(entry?.failure_reason?.type ?? ""));
      if (manifest || live) stream = { video: [], audio: null, ...manifest, duration: manifest?.duration ?? length, live: live || Boolean(manifest?.live) };
    }
    const { width, height } = videoSize(video);
    return { files, dash, stream, sharper: sharperCopies(manifest, files[0], width, height, length) };
  }
  function videoSize(video) {
    return { width: Number(video?.original_width ?? video?.width) || null, height: Number(video?.original_height ?? video?.height) || null };
  }
  function photoFile(photo) {
    let best = null;
    for (const key of PHOTO_IMAGES) {
      const image = photo?.[key];
      if (!isObject3(image) || !isUrl(image.uri)) continue;
      const width = Number(image.width) || 0;
      const height = Number(image.height) || 0;
      if (!best || width * height > best.width * best.height) best = { url: image.uri, width, height };
    }
    return best;
  }
  function createMediaIndex({ max = MAX_ITEMS2 } = {}) {
    const items = /* @__PURE__ */ new Map();
    const cards = /* @__PURE__ */ new Map();
    const owners = /* @__PURE__ */ new Map();
    const videoOwners = /* @__PURE__ */ new Map();
    const names = /* @__PURE__ */ new Map();
    const put = (map, key, value) => {
      map.delete(key);
      map.set(key, value);
      if (map.size > max) map.delete(map.keys().next().value);
    };
    function record(value) {
      const id = typeof value.id === "string" ? value.id : null;
      if (id && (value.__typename === "Video" || value.__typename === void 0 && isObject3(value.videoDeliveryResponseFragment))) {
        if (typeof value.owner?.id === "string") put(videoOwners, id, value.owner.id);
        const { files, dash, stream, sharper } = videoFiles(value);
        const old = items.get(id);
        const usable = (entry) => Boolean(entry && (entry.live || entry.video.length));
        if (files.length || dash || stream) {
          if (!(old?.kind === "video" && (old.files.length > files.length || !files.length && usable(old.stream) && !usable(stream)))) {
            put(items, id, { kind: "video", id, files, dash, stream, sharper: sharper ?? (old?.kind === "video" ? old.sharper : null), ...videoSize(value) });
          }
        }
      } else if (id && value.__typename === "Photo") {
        const file = photoFile(value);
        const old = items.get(id);
        if (file && old?.kind !== "video" && !(old?.kind === "photo" && old.width * old.height >= file.width * file.height)) {
          put(items, id, { kind: "photo", id, ...file });
        }
      }
      if (id && "story_card_info" in value && Array.isArray(value.attachments)) {
        const media = value.attachments.map((attachment) => attachment?.media).find((m) => typeof m?.id === "string");
        if (media) put(cards, id, media.id);
      }
      if (typeof value.owner?.id === "string" && typeof value.owner.name === "string" && value.owner.name.trim()) {
        put(names, value.owner.id, value.owner.name);
      }
      const owner = value.story_bucket_owner?.name;
      if (typeof owner === "string" && Array.isArray(value.unified_stories_with_notes?.edges)) {
        for (const edge of value.unified_stories_with_notes.edges) {
          if (typeof edge?.node?.id === "string") put(owners, edge.node.id, owner);
        }
      }
    }
    return {
      // Reads every photo, video and story card in a parsed answer.
      scan(doc) {
        walk(doc, (value) => {
          if (!Array.isArray(value)) record(value);
        });
      },
      get: (id) => id === null || id === void 0 ? null : items.get(String(id)) ?? null,
      // What a story card shows, by the id in the story viewer's address, and whose it is.
      card: (cardId) => {
        const item = items.get(cards.get(cardId));
        return item ? { ...item, author: owners.get(cardId) ?? null } : null;
      },
      // The name of whoever posted a video, when Facebook's data has said it.
      ownerName: (id) => names.get(videoOwners.get(String(id))) ?? null,
      size: () => items.size
    };
  }

  // src/features/downloads/shared.js
  var instances = /* @__PURE__ */ new WeakMap();
  var NOTICE_AFTER = 1500;
  var QUALITY_OPTION = {
    key: "quality",
    type: "select",
    label: "Video quality",
    default: "best",
    choices: [
      { value: "best", label: "Best (HD when there is one)" },
      { value: "sd", label: "Smaller file (SD)" },
      // Facebook's sharpest copy is mostly AV1 (2026-10-22), which older players can't open.
      { value: "sharpest", label: "Sharpest (often AV1, which some players can't open)" }
    ]
  };
  function create({ win, doc, net, router, diagnostics, log, toast, api = gmApi() }) {
    const index = createMediaIndex();
    const switches = /* @__PURE__ */ new Map();
    const anyOn = () => [...switches.values()].some((s) => s.enabled());
    let saved = 0;
    let failed = 0;
    net?.transformResponses({
      id: "mediaIndex",
      enabled: anyOn,
      markers: MEDIA_MARKERS,
      match: (ctx) => ctx.transport === "json-parse",
      observe: true,
      transform(data) {
        index.scan(data);
        return false;
      }
    });
    diagnostics?.add("Downloads", () => {
      const known = net ? `${index.size()} photos and videos known` : "Photos only: the script can't reach the page's data";
      return `${known}, ${saved} saved, ${failed} failed this visit`;
    });
    async function run(found, container) {
      const settings = switches.get(found.feature);
      const plan = planSave(found, { quality: settings?.quality?.() });
      if (plan.error) {
        toast?.(t(plan.error, plan.params), { tone: "error" });
        return;
      }
      const save = startSave({ url: plan.url, parts: plan.parts, name: plan.name, api, doc, win, container });
      let notice = null;
      const later2 = setTimeout(() => {
        notice = toast?.(t("Saving {name}", { name: plan.name }), { action: { label: "Cancel", run: () => save.cancel() }, duration: Infinity });
      }, NOTICE_AFTER);
      try {
        await save.done;
        saved++;
        toast?.(t("Saved {name}", { name: plan.name }));
      } catch (error) {
        if (error.cancelled) {
          toast?.(t("Cancelled {name}", { name: plan.name }));
          return;
        }
        failed++;
        log?.warn("Couldn't save a photo or video", error);
        toast?.(t("Couldn't save it: {reason}.", { reason: t(error.message) }), { tone: "error" });
      } finally {
        clearTimeout(later2);
        notice?.dismiss?.();
        diagnostics?.changed();
      }
    }
    function find(element) {
      const found = findMedia(element, { href: router?.current()?.href ?? win.location.href, index });
      return found && switches.get(found.feature)?.enabled() ? found : null;
    }
    const missing = () => toast?.(t("There's nothing to save there now. Go back to the photo or video and try again."));
    const button = createDownloadButton({ doc, win, log, run, active: anyOn, onMissing: missing, find });
    return {
      index,
      button,
      run,
      find,
      missing,
      add(featureId, { enabled, quality = null }) {
        switches.set(featureId, { enabled, quality });
      }
    };
  }
  function downloads(ctx) {
    const key = ctx.doc ?? globalThis.document;
    let shared = instances.get(key);
    if (!shared) {
      shared = create(ctx);
      instances.set(key, shared);
    }
    return shared;
  }

  // src/features/downloads/download-photos.js
  var download_photos_default = {
    id: "downloadPhotos",
    section: "downloads",
    android: "Download any photo",
    title: "Download any photo",
    description: "Shows a Download button on photos in posts and in the photo viewer when you point at them or Tab to them. It saves the largest copy Facebook sent.",
    default: true,
    setup(ctx) {
      downloads(ctx).add("downloadPhotos", { enabled: ctx.enabled });
    }
  };

  // src/features/downloads/download-videos.js
  var download_videos_default = {
    id: "downloadVideos",
    section: "downloads",
    android: "Download any video",
    title: "Download any video",
    description: "Shows a Download button on videos in the feed and in Watch when you point at them or Tab to them. Videos save in HD when Facebook has it, or you can pick smaller files or the sharpest copy Facebook streams.",
    default: false,
    needsPage: true,
    options: [QUALITY_OPTION],
    setup(ctx) {
      downloads(ctx).add("downloadVideos", { enabled: ctx.enabled, quality: () => ctx.option("quality") });
    }
  };

  // src/features/downloads/download-reels.js
  var download_reels_default = {
    id: "downloadReels",
    section: "downloads",
    android: "Download any reel",
    title: "Download any reel",
    description: "Shows a Download button on reels when you point at them or Tab to them. Reels save in HD when Facebook has it, or you can pick smaller files or the sharpest copy Facebook streams.",
    default: true,
    needsPage: true,
    options: [QUALITY_OPTION],
    setup(ctx) {
      downloads(ctx).add("downloadReels", { enabled: ctx.enabled, quality: () => ctx.option("quality") });
    }
  };

  // src/features/downloads/download-stories.js
  var download_stories_default = {
    id: "downloadStories",
    section: "downloads",
    android: "Download any story",
    title: "Download any story",
    description: "Shows a Download button on the story you're watching when you point at it or Tab to it. Videos save in HD when Facebook has it, or you can pick smaller files or the sharpest copy Facebook streams.",
    default: true,
    needsPage: true,
    options: [QUALITY_OPTION],
    setup(ctx) {
      downloads(ctx).add("downloadStories", { enabled: ctx.enabled, quality: () => ctx.option("quality") });
    }
  };

  // src/features/downloads/download-menu.js
  var ROW_MARK = "data-hfw-menu-download";
  var POST3 = '[aria-posinset], [role="article"]';
  var OPENER = '[aria-haspopup="menu"][aria-expanded="true"]';
  var ROWS = '[role="menuitem"], [role="button"]';
  var SVG_NS = "http://www.w3.org/2000/svg";
  var RETRIES_MS = [0, 50, 150, 400, 1e3];
  function mediaOf(post, find) {
    for (const media of post.querySelectorAll("video, img")) {
      if (media.closest(POST3) !== post) continue;
      const found = find(media);
      if (found) return { media, found };
    }
    return null;
  }
  function openPost(doc, find) {
    const following = (doc.defaultView?.Node ?? globalThis.Node).DOCUMENT_POSITION_FOLLOWING;
    for (const button of doc.querySelectorAll(OPENER)) {
      const post = button.closest(POST3);
      if (!post || isComment(post)) continue;
      const pick = mediaOf(post, find);
      if (pick && button.compareDocumentPosition(pick.media) & following) return post;
    }
    return null;
  }
  function downloadIcon(doc, size) {
    const svg = doc.createElementNS(SVG_NS, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", size);
    svg.setAttribute("height", size);
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("style", "display: block; fill: none; stroke: var(--primary-icon, currentColor); stroke-width: 2; stroke-linecap: round; stroke-linejoin: round");
    const path2 = doc.createElementNS(SVG_NS, "path");
    path2.setAttribute("d", DOWNLOAD_ICON);
    svg.append(path2);
    return svg;
  }
  var ownText2 = (el) => [...el.childNodes].some((node) => node.nodeType === 3 && node.textContent.trim());
  function buildRow(template, doc) {
    const row = template.cloneNode(true);
    for (const el of [row, ...row.querySelectorAll("*")]) {
      for (const name of ["id", "aria-label", "aria-labelledby", "aria-describedby"]) el.removeAttribute(name);
    }
    const [label, ...rest] = [...row.querySelectorAll("*")].filter(ownText2);
    if (!label) return null;
    label.textContent = t("Download");
    for (const extra of rest) extra.textContent = "";
    const picture = row.querySelector("i, svg, img");
    picture?.replaceWith(downloadIcon(doc, picture.getAttribute("width") || "20"));
    row.setAttribute("tabindex", "0");
    row.setAttribute(ROW_MARK, "");
    return row;
  }
  function closeMenu(doc, menu) {
    const opener = doc.querySelector(OPENER);
    if (opener) {
      opener.click();
      return;
    }
    const Keyboard = doc.defaultView?.KeyboardEvent ?? globalThis.KeyboardEvent;
    menu.dispatchEvent(new Keyboard("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true, cancelable: true }));
  }
  function createMenuDownload({ doc, enabled, find, run, missing, log, setTimer = (fn, ms) => (doc.defaultView ?? globalThis).setTimeout(fn, ms) }) {
    let shown4 = null;
    let added = 0;
    let clicked = 0;
    let opener = null;
    let watched = null;
    const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
    function remove() {
      watched?.observer.disconnect();
      watched = null;
      shown4 = null;
      for (const row of doc.querySelectorAll(`[${ROW_MARK}]`)) row.remove();
    }
    function save(post, menu) {
      closeMenu(doc, menu);
      const pick = post.isConnected ? mediaOf(post, find) : null;
      if (!pick) {
        missing?.();
        return;
      }
      clicked++;
      Promise.resolve(run(pick.found, null)).catch((error) => log?.error("The download failed", error));
    }
    function addRow2(menu, post) {
      if (shown4 && menu.contains(shown4.row)) {
        if (shown4.post === post) return;
        shown4.row.remove();
      }
      shown4 = null;
      const first = menu.querySelector(ROWS);
      const row = first && buildRow(first, doc);
      if (!row) return;
      const go = (event) => {
        event.preventDefault();
        event.stopPropagation();
        save(post, menu);
      };
      row.addEventListener("click", go);
      row.addEventListener("keydown", (event) => {
        if (event.key === "Enter" || event.key === " ") go(event);
      });
      first.before(row);
      shown4 = { row, post };
      added++;
    }
    function sync() {
      if (!enabled()) {
        remove();
        return;
      }
      const post = openPost(doc, find);
      const menu = post && [...doc.querySelectorAll('[role="menu"]')].at(-1);
      if (!menu) return;
      try {
        addRow2(menu, post);
      } catch (error) {
        log?.error("Couldn't add Download to the post menu", error);
      }
      watch(menu);
    }
    function watch(menu) {
      if (watched?.menu === menu) return;
      watched?.observer.disconnect();
      const observer = new Observer(() => {
        if (!menu.isConnected) {
          observer.disconnect();
          if (watched?.menu === menu) watched = null;
          return;
        }
        if (!shown4 || !menu.contains(shown4.row)) sync();
      });
      observer.observe(menu, { childList: true, subtree: true });
      watched = { menu, observer };
    }
    function start() {
      if (opener || !doc.body) return;
      opener = new Observer((records) => {
        if (!enabled()) return;
        const opened = records.some((record) => record.target.matches?.(OPENER) && record.target.closest(POST3));
        if (opened) for (const wait of RETRIES_MS) setTimer(sync, wait);
      });
      opener.observe(doc.body, { subtree: true, attributes: true, attributeFilter: ["aria-expanded"] });
    }
    return {
      apply() {
        start();
        sync();
      },
      sync,
      state: () => ({ added, clicked })
    };
  }
  var download_menu_default = {
    id: "downloadMenu",
    section: "downloads",
    android: "Download first in post menus",
    title: "Download in post menus",
    description: "Puts Download at the top of a post's three-dot menu when the post has a photo or video to save. It saves the same file as the Download button, so it follows the switches above.",
    default: false,
    setup(ctx) {
      const { doc, settings, enabled, log, diagnostics } = ctx;
      if (!doc) return;
      const shared = downloads(ctx);
      const entry = createMenuDownload({ doc, enabled, find: shared.find, run: shared.run, missing: shared.missing, log });
      whenBodyReady(() => entry.apply(), doc);
      settings?.subscribe(() => entry.apply());
      diagnostics?.add("Post menu downloads", () => {
        const { added, clicked } = entry.state();
        return `Added to ${added} ${added === 1 ? "menu" : "menus"}, clicked ${clicked}`;
      });
    }
  };

  // src/features/appearance/force-dark.js
  var LIGHT = "__fb-light-mode";
  var DARK = "__fb-dark-mode";
  var MAX_SWAPS = 20;
  var MAX_LAYER_SWAPS = 200;
  var SWAP_WINDOW = 5e3;
  var WATCHERS = /* @__PURE__ */ Symbol.for("hushfacebook-web.theme-watchers");
  var METHODS = ["add", "replace", "toggle"];
  function themeWritten(method, args, result) {
    if (method === "add") return args.includes(DARK) ? DARK : args.includes(LIGHT) ? LIGHT : null;
    if (method === "replace") return result && (args[1] === DARK || args[1] === LIGHT) ? args[1] : null;
    return result === true && (args[0] === DARK || args[0] === LIGHT) ? args[0] : null;
  }
  function watchThemeWrites(doc, watcher) {
    const list = doc.documentElement?.classList;
    const proto = list ? Object.getPrototypeOf(list) : null;
    if (!proto || typeof proto.add !== "function") return;
    if (!Object.hasOwn(proto, WATCHERS)) {
      const watchers = /* @__PURE__ */ new Set();
      Object.defineProperty(proto, WATCHERS, { value: watchers });
      for (const method of METHODS) {
        const original = proto[method];
        if (typeof original !== "function") continue;
        proto[method] = function(...args) {
          const result = original.apply(this, args);
          if (watchers.size) {
            const theme = themeWritten(method, args, result);
            if (theme) {
              for (const watch of watchers) {
                try {
                  watch(this, theme);
                } catch {
                }
              }
            }
          }
          return result;
        };
      }
    }
    proto[WATCHERS].add(watcher);
    return () => proto[WATCHERS].delete(watcher);
  }
  function createDarkKeeper({ doc, enabled, log, now = () => Date.now(), isRootList = (list) => list === doc.documentElement?.classList }) {
    let swapped = false;
    let writing = false;
    let unwatch = null;
    let observer = null;
    const swaps = [];
    const layerSwaps = [];
    const layers = /* @__PURE__ */ new WeakSet();
    let layerCount = 0;
    let gaveUp = false;
    const tooMany = (list, max) => {
      const time = now();
      while (list.length && time - list[0] > SWAP_WINDOW) list.shift();
      list.push(time);
      return list.length > max;
    };
    const giveUp = () => {
      gaveUp = true;
      log?.warn("Force dark mode stopped: something on the page keeps switching Facebook back to light");
    };
    function changedLights(records) {
      const found = /* @__PURE__ */ new Set();
      for (const record of records) {
        if (record.type === "attributes") {
          if (record.target.classList?.contains(LIGHT)) found.add(record.target);
          continue;
        }
        for (const node of record.addedNodes) {
          if (node.nodeType !== 1) continue;
          if (node.classList.contains(LIGHT)) found.add(node);
          for (const inner of node.getElementsByClassName(LIGHT)) found.add(inner);
        }
      }
      return found;
    }
    const followsPage = (element, root) => {
      for (let node = element.parentElement; node && node !== root; node = node.parentElement) {
        if (node.classList.contains(DARK)) return layers.has(node);
      }
      return true;
    };
    const swapRoot = (root, from, to) => {
      writing = true;
      try {
        root.classList.replace(from, to);
      } finally {
        writing = false;
      }
    };
    const facebookWrote = (list, theme) => {
      if (writing || theme !== DARK || !isRootList(list)) return;
      swapped = false;
    };
    function apply(records) {
      const root = doc.documentElement;
      if (!root) return;
      const want = enabled() && !gaveUp;
      if (want) {
        unwatch ??= watchThemeWrites(doc, facebookWrote) ?? (() => {
        });
        if (root.classList.contains(LIGHT)) {
          if (tooMany(swaps, MAX_SWAPS)) return giveUp();
          swapRoot(root, LIGHT, DARK);
          swapped = true;
        }
        const lights = records ? changedLights(records) : [...doc.getElementsByClassName(LIGHT)];
        for (const layer of lights) {
          if (layer === root || !layer.classList.contains(LIGHT) || !followsPage(layer, root)) continue;
          if (layers.has(layer)) {
            if (tooMany(layerSwaps, MAX_LAYER_SWAPS)) return giveUp();
          } else {
            layerCount += 1;
            layers.add(layer);
          }
          layer.classList.replace(LIGHT, DARK);
        }
        return void 0;
      }
      if (swapped && root.classList.contains(DARK)) {
        swapRoot(root, DARK, LIGHT);
        swapped = false;
      }
      if (layerCount) {
        for (const layer of [...doc.getElementsByClassName(DARK)]) {
          if (!layers.has(layer)) continue;
          layer.classList.replace(DARK, LIGHT);
          layers.delete(layer);
        }
        layerCount = 0;
      }
      return void 0;
    }
    function start() {
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      observer = new Observer((records) => apply(records));
      observer.observe(doc.documentElement, { attributes: true, attributeFilter: ["class"], childList: true, subtree: true });
      apply();
    }
    return {
      start: () => whenRootReady(start, doc),
      apply: () => apply(),
      state: () => ({ swapped, gaveUp, layers: layerCount }),
      stop: () => {
        observer?.disconnect();
        unwatch?.();
        unwatch = null;
      }
    };
  }
  var force_dark_default = {
    id: "forceDarkMode",
    section: "appearance",
    android: "Force dark mode",
    title: "Force dark mode",
    description: "Keeps Facebook in its dark theme, whatever Facebook's own setting says. Switch it off and Facebook's choice comes back.",
    default: false,
    setup({ doc, settings, enabled, log }) {
      const keeper = createDarkKeeper({ doc, enabled, log });
      keeper.start();
      settings?.subscribe(() => keeper.apply());
    }
  };

  // src/features/appearance/amoled.js
  var BLACK = "#000000";
  var RAISED = "#121212";
  var POPOVER = "#1A1A1A";
  var LINE = "#1D1E23";
  var FEED_POST = ".__fb-dark-mode [aria-posinset]:not([role])";
  var AMOLED_VARS = {
    "--web-wash": BLACK,
    "--wash": BLACK,
    "--surface-background": BLACK,
    "--card-background": BLACK,
    "--nav-bar-background": BLACK,
    "--messenger-card-background": BLACK,
    "--card-background-flat": RAISED,
    "--comment-background": RAISED,
    "--input-background": RAISED,
    "--input-background-disabled": RAISED,
    "--messenger-reply-background": RAISED,
    "--toast-background": RAISED,
    "--popover-background": POPOVER
  };
  function amoledCss(get = () => false) {
    const lines2 = Object.entries(AMOLED_VARS).map(([name, value]) => `  ${name}: ${value} !important;`);
    const theme = `.__fb-dark-mode {
${lines2.join("\n")}
}`;
    if (get("amoledTheme.lines") !== true) return theme;
    return `${theme}
${FEED_POST} { position: relative; }
${FEED_POST}::after { content: ""; position: absolute; inset-inline: 0; bottom: -7px; height: 1px; background: ${LINE}; pointer-events: none; }`;
  }
  var amoled_default = {
    id: "amoledTheme",
    section: "appearance",
    android: "AMOLED black theme",
    title: "AMOLED black theme",
    description: "Pure black in place of Facebook's dark gray. It changes dark mode only, so turn on Facebook's dark mode or Force dark mode with it.",
    default: false,
    options: [
      { key: "lines", type: "toggle", label: "Lines between posts", default: false }
    ],
    css: amoledCss
  };

  // src/features/appearance/accent.js
  var ACCENTS2 = [
    { value: "purple", label: "Purple", hex: "#7B3FE4" },
    { value: "pink", label: "Pink", hex: "#D6246E" },
    { value: "red", label: "Red", hex: "#D93025" },
    { value: "orange", label: "Orange", hex: "#E8590C" },
    { value: "green", label: "Green", hex: "#1E8E3E" },
    { value: "teal", label: "Teal", hex: "#00897B" },
    { value: "graphite", label: "Graphite", hex: "#5F6368" }
  ];
  function parseHex(value) {
    const match = /^#?([0-9a-f]{6})$/i.exec(String(value ?? "").trim());
    if (!match) return null;
    const n = Number.parseInt(match[1], 16);
    return [n >> 16 & 255, n >> 8 & 255, n & 255];
  }
  function toHsl([r, g, b]) {
    const [rr, gg, bb] = [r / 255, g / 255, b / 255];
    const max = Math.max(rr, gg, bb);
    const min = Math.min(rr, gg, bb);
    const l = (max + min) / 2;
    if (max === min) return [0, 0, l * 100];
    const d = max - min;
    const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    const h2 = max === rr ? (gg - bb) / d + (gg < bb ? 6 : 0) : max === gg ? (bb - rr) / d + 2 : (rr - gg) / d + 4;
    return [h2 * 60, s * 100, l * 100];
  }
  function toHex([h2, s, l]) {
    const ss = s / 100;
    const ll = l / 100;
    const a = ss * Math.min(ll, 1 - ll);
    const channel = (n) => {
      const k = (n + h2 / 30) % 12;
      return ll - a * Math.max(-1, Math.min(k - 3, 9 - k, 1));
    };
    return `#${[channel(0), channel(8), channel(4)].map((x) => Math.round(x * 255).toString(16).padStart(2, "0")).join("").toUpperCase()}`;
  }
  function luminance(rgb) {
    const [r, g, b] = rgb.map((c) => {
      const x = c / 255;
      return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
  }
  function contrast(a, b) {
    const [x, y] = [luminance(parseHex(a)), luminance(parseHex(b))].sort((p, q) => q - p);
    return (x + 0.05) / (y + 0.05);
  }
  var TEXT2 = 4.5;
  var INDICATOR = 3;
  var SURFACES = { white: "#FFFFFF", wash: "#F0F2F5", bubble: "#3A3B3C", card: "#252728", box: "#242526" };
  function over(rgb, surface, a) {
    const under = parseHex(surface);
    return `#${rgb.map((c, i) => Math.round(c * a + under[i] * (1 - a)).toString(16).padStart(2, "0")).join("").toUpperCase()}`;
  }
  function readable([h2, s], from, by, surfaces, ratio) {
    for (let l = from; l >= 0 && l <= 100; l += by) {
      const hex = toHex([h2, s, l]);
      if (surfaces.every((surface) => contrast(hex, surface) >= ratio)) return hex;
    }
    return by < 0 ? "#000000" : "#FFFFFF";
  }
  function palette(hex) {
    const rgb = parseHex(hex);
    if (!rgb) return null;
    const hsl = toHsl(rgb);
    const l = hsl[2];
    const base = toHex(hsl);
    const at = (lightness) => toHex([hsl[0], hsl[1], lightness]);
    const darker = (from, surfaces, ratio = TEXT2) => readable(hsl, from, -1, surfaces, ratio);
    const lighter = (from, surfaces, ratio = TEXT2) => readable(hsl, from, 1, surfaces, ratio);
    const alpha = (a) => `rgba(${rgb.join(", ")}, ${a})`;
    const button = at(93);
    return {
      base,
      onBase: contrast(base, "#FFFFFF") >= contrast(base, "#000000") ? "#FFFFFF" : "#000000",
      alpha,
      light: {
        focus: darker(l, [SURFACES.white, SURFACES.wash], INDICATOR),
        link: darker(Math.min(l, 41), [SURFACES.white, SURFACES.wash, button]),
        toastLink: darker(Math.min(l, 49), [SURFACES.white]),
        pressed: at(Math.max(l, 73)),
        button,
        highlight: at(95),
        selected: at(96)
      },
      dark: {
        focus: lighter(Math.max(l, 55), [SURFACES.card, SURFACES.bubble], INDICATOR),
        label: lighter(Math.max(l, 61), [SURFACES.box]),
        toastLink: lighter(Math.max(l, 64), [SURFACES.box]),
        link: lighter(Math.max(l, 68), [SURFACES.card, SURFACES.bubble]),
        deemphasized: lighter(Math.max(l, 73), [over(rgb, SURFACES.card, 0.2)])
      }
    };
  }
  function chosenColor(get) {
    const custom = String(get("accentColor.custom") ?? "").trim();
    if (parseHex(custom)) return custom.startsWith("#") ? custom : `#${custom}`;
    return (ACCENTS2.find((accent2) => accent2.value === get("accentColor.color")) ?? ACCENTS2[0]).hex;
  }
  var FILTER_IDS = {
    base: "hfw-accent-base",
    lightLink: "hfw-accent-link",
    darkLink: "hfw-accent-link-dark",
    darkDeemphasized: "hfw-accent-deemphasized-dark"
  };
  function filterColors(colors) {
    return {
      [FILTER_IDS.base]: colors.base,
      [FILTER_IDS.lightLink]: colors.light.link,
      [FILTER_IDS.darkLink]: colors.dark.link,
      [FILTER_IDS.darkDeemphasized]: colors.dark.deemphasized
    };
  }
  var url = (id) => `url("#${id}")`;
  var block = (selector, vars) => `${selector} {
${Object.entries(vars).map(([name, value]) => `  ${name}: ${value} !important;`).join("\n")}
}`;
  function accentCss(hex) {
    const colors = palette(hex);
    if (!colors) return "";
    const { base, onBase, alpha, light, dark } = colors;
    const shared = {
      "--accent": base,
      "--primary-button-background": base,
      "--primary-button-text": onBase,
      "--primary-button-icon": onBase,
      "--cursor": base,
      "--progress-ring-blue-foreground": base,
      "--progress-ring-blue-background": alpha(0.2),
      "--primary-deemphasized-button-pressed-overlay": alpha(0.15),
      "--filter-primary-accent": url(FILTER_IDS.base)
    };
    return [
      block(":root, .__fb-light-mode", {
        ...shared,
        "--focus-ring-blue": light.focus,
        "--primary-button-pressed": light.pressed,
        "--blue-link": light.link,
        "--primary-deemphasized-button-text": light.link,
        "--primary-deemphasized-button-icon": light.link,
        "--toggle-active-icon": light.link,
        "--toggle-active-text": light.link,
        "--input-label-color-highlighted": light.link,
        "--toast-text-link": light.toastLink,
        "--primary-deemphasized-button-background": light.button,
        "--highlight-bg": light.highlight,
        "--toggle-active-background": light.selected,
        "--hosted-view-selected-state": light.selected,
        "--text-highlight": alpha(0.2),
        "--filter-accent": url(FILTER_IDS.base),
        "--filter-blue-link-icon": url(FILTER_IDS.lightLink),
        "--filter-primary-deemphasized-button-icon": url(FILTER_IDS.lightLink)
      }),
      block(".__fb-dark-mode", {
        ...shared,
        "--focus-ring-blue": dark.focus,
        "--toggle-active-background": dark.focus,
        "--primary-button-pressed": dark.deemphasized,
        "--blue-link": dark.link,
        "--primary-deemphasized-button-text": dark.deemphasized,
        "--primary-deemphasized-button-icon": dark.deemphasized,
        "--input-label-color-highlighted": dark.label,
        "--toast-text-link": dark.toastLink,
        "--primary-deemphasized-button-background": alpha(0.2),
        "--highlight-bg": alpha(0.31),
        "--text-highlight": alpha(0.45),
        "--hosted-view-selected-state": alpha(0.1),
        "--filter-accent": url(FILTER_IDS.darkLink),
        "--filter-blue-link-icon": url(FILTER_IDS.darkLink),
        "--filter-primary-deemphasized-button-icon": url(FILTER_IDS.darkDeemphasized)
      })
    ].join("\n");
  }
  var SVG_NS2 = "http://www.w3.org/2000/svg";
  var FILTERS_MARK = "data-hfw-accent-filters";
  function writeFilters(doc, colors) {
    let svg = doc.querySelector(`svg[${FILTERS_MARK}]`);
    if (!svg) {
      svg = doc.createElementNS(SVG_NS2, "svg");
      svg.setAttribute(FILTERS_MARK, "");
      svg.setAttribute("aria-hidden", "true");
      svg.setAttribute("width", "0");
      svg.setAttribute("height", "0");
      svg.setAttribute("style", "position:absolute;width:0;height:0;overflow:hidden;pointer-events:none");
      (doc.body ?? doc.documentElement).append(svg);
    }
    const defs = doc.createElementNS(SVG_NS2, "defs");
    for (const [id, color] of Object.entries(colors)) {
      const filter = doc.createElementNS(SVG_NS2, "filter");
      filter.setAttribute("id", id);
      filter.setAttribute("color-interpolation-filters", "sRGB");
      const flood = doc.createElementNS(SVG_NS2, "feFlood");
      flood.setAttribute("flood-color", color);
      const composite = doc.createElementNS(SVG_NS2, "feComposite");
      composite.setAttribute("in2", "SourceAlpha");
      composite.setAttribute("operator", "in");
      filter.append(flood, composite);
      defs.append(filter);
    }
    svg.replaceChildren(defs);
    return svg;
  }
  var accent_default = {
    id: "accentColor",
    section: "appearance",
    android: "Accent color",
    title: "Accent color",
    description: "Your own color in place of Facebook's blue, for buttons, links, switches and highlights, in both light and dark mode.",
    default: false,
    options: [
      { key: "color", type: "select", label: "Color", default: ACCENTS2[0].value, choices: ACCENTS2.map(({ value, label }) => ({ value, label })) },
      { key: "custom", type: "text", lines: 1, label: "Or your own color, like #7B3FE4", default: "", maxLength: 7 }
    ],
    css: (get) => accentCss(chosenColor(get)),
    setup({ doc, settings, enabled, log }) {
      if (!doc) return;
      const sync = () => {
        try {
          const existing = doc.querySelector(`svg[${FILTERS_MARK}]`);
          if (!enabled()) {
            existing?.remove();
            return;
          }
          writeFilters(doc, filterColors(palette(chosenColor(settings.get))));
        } catch (error) {
          log?.error("Accent color: the icon colors couldn't be set", error);
        }
      };
      whenBodyReady(sync, doc);
      settings?.subscribe(() => whenBodyReady(sync, doc));
    }
  };

  // src/features/appearance/system-font.js
  var SYSTEM_STACK = 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans", "Helvetica Neue", Arial, sans-serif';
  var FONT_VARS = ["--font-family-default", "--font-family-segoe", "--font-family-apple", "--font-family-system-fds"];
  function fontName(value) {
    const name = String(value ?? "").trim().replace(/\s+/g, " ");
    return /^[\p{L}\p{N}][\p{L}\p{N} ._&+-]{0,63}$/u.test(name) ? name : "";
  }
  function fontStack(get) {
    const name = fontName(get("systemFont.font"));
    return name ? `"${name}", ${SYSTEM_STACK}` : SYSTEM_STACK;
  }
  function fontCss(get) {
    const stack = fontStack(get);
    const vars = FONT_VARS.map((name) => `  ${name}: ${stack} !important;`).join("\n");
    return `:root, .__fb-light-mode, .__fb-dark-mode {
${vars}
}
body { font-family: ${stack} !important; }`;
  }
  var system_font_default = {
    id: "systemFont",
    section: "appearance",
    android: "Use the system font",
    title: "Use the system font",
    description: "Draws Facebook's text in your computer's own interface font, or in a font you have installed.",
    default: false,
    options: [
      { key: "font", type: "text", lines: 1, label: "Or a font you have installed, by name", default: "", maxLength: 64 }
    ],
    css: fontCss
  };

  // src/features/appearance/system-emoji.js
  var EMOJI_IMG = 'img[src*="/images/emoji.php/"]';
  var ORIGINAL = "data-hfw-emoji";
  var EMOJI_FONTS = "'Apple Color Emoji','Segoe UI Emoji','Noto Color Emoji','Twemoji Mozilla',sans-serif";
  function emojiText(img, src = img.getAttribute("src") ?? "") {
    const alt = img.getAttribute("alt") ?? "";
    if ([...alt].some((char) => char.codePointAt(0) > 255)) return alt;
    const match = /\/([0-9a-f]{2,6}(?:_[0-9a-f]{2,6})*)\.png(?:$|[?#])/i.exec(src);
    if (!match) return null;
    try {
      return String.fromCodePoint(...match[1].split("_").map((hex) => Number.parseInt(hex, 16)));
    } catch {
      return null;
    }
  }
  var escapeXml = (text) => text.replace(/[&<>"']/g, (char) => `&#${char.codePointAt(0)};`);
  function emojiPicture(text) {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><text x="10" y="10.5" font-size="16" text-anchor="middle" dominant-baseline="central" font-family="${EMOJI_FONTS}">${escapeXml(text)}</text></svg>`;
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
  }
  function swapEmoji(img) {
    const src = img.getAttribute("src") ?? "";
    if (!src.includes("/images/emoji.php/")) return false;
    const text = emojiText(img, src);
    if (!text) return false;
    img.setAttribute(ORIGINAL, src);
    img.setAttribute("src", emojiPicture(text));
    return true;
  }
  function restoreEmoji(img) {
    const original = img.getAttribute(ORIGINAL);
    img.removeAttribute(ORIGINAL);
    if (original) img.setAttribute("src", original);
  }
  function createEmojiSwapper({ doc, enabled, log }) {
    let observer = null;
    let swapped = 0;
    const swapIn = (root) => {
      if (root.nodeType !== 1) return;
      if (root.matches(EMOJI_IMG) && swapEmoji(root)) swapped += 1;
      for (const img of root.querySelectorAll(EMOJI_IMG)) if (swapEmoji(img)) swapped += 1;
    };
    const release = (img) => {
      const original = img.getAttribute(ORIGINAL);
      if (!original) return;
      const text = emojiText(img, original);
      if (img.getAttribute("src") !== (text && emojiPicture(text))) img.removeAttribute(ORIGINAL);
    };
    const onMutations = (records) => {
      try {
        for (const record of records) {
          if (record.type === "attributes") {
            release(record.target);
            swapIn(record.target);
          } else for (const node of record.addedNodes) swapIn(node);
        }
      } catch (error) {
        log?.error("Use system emoji: swapping an emoji failed", error);
      }
    };
    function start() {
      if (observer) return;
      const root = doc.documentElement;
      if (!root) return;
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      observer = new Observer(onMutations);
      observer.observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ["src"] });
      swapIn(root);
    }
    function stop() {
      observer?.disconnect();
      observer = null;
      for (const img of doc.querySelectorAll(`img[${ORIGINAL}]`)) restoreEmoji(img);
    }
    return {
      apply: () => enabled() ? start() : stop(),
      state: () => ({ running: Boolean(observer), swapped })
    };
  }
  var system_emoji_default = {
    id: "systemEmoji",
    section: "appearance",
    android: "Use the phone's emoji",
    title: "Use your computer's emoji",
    description: "Shows emoji in posts, comments and chats with your own system's emoji instead of Facebook's pictures of them.",
    default: false,
    setup({ doc, settings, enabled, log, diagnostics }) {
      if (!doc) return;
      const swapper = createEmojiSwapper({ doc, enabled, log });
      const apply = () => {
        if (doc.documentElement) swapper.apply();
      };
      if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", apply, { once: true });
      else apply();
      settings?.subscribe(apply);
      diagnostics?.add("Emoji swapped for your own", () => enabled() ? String(swapper.state().swapped) : "off");
    }
  };

  // src/features/appearance/no-transitions.js
  var ANIMATED = '*:not([role="progressbar"], [role="progressbar"] *)';
  var NO_TRANSITIONS_CSS = `${ANIMATED}, ${ANIMATED}::before, ${ANIMATED}::after {
  transition-duration: 0.001ms !important;
  transition-delay: 0s !important;
  animation-duration: 0.001ms !important;
  animation-delay: 0s !important;
  animation-iteration-count: 1 !important;
}
html { scroll-behavior: auto !important; }`;
  var no_transitions_default = {
    id: "noTransitions",
    section: "appearance",
    android: "Turn off screen transitions",
    title: "Turn off screen transitions",
    description: "Menus, dialogs and pages appear at once, without Facebook's fades and slides. Loading spinners keep turning.",
    default: false,
    css: NO_TRANSITIONS_CSS
  };

  // src/features/appearance/hide-tabs.js
  var ON_BY_DEFAULT = /* @__PURE__ */ new Set(["video", "marketplace", "gaming"]);
  function tabsCss(get) {
    const links = TAB_ROWS.filter(({ option }) => get(`hideTabs.${option}`)).map(({ link }) => place.tab(link));
    if (get("hideTabs.findFriends")) links.push(FIND_FRIENDS);
    return links.length ? hide(links.join(",\n")) : "";
  }
  var hide_tabs_default = {
    id: "hideTabs",
    section: "appearance",
    android: "Hide tabs",
    title: "Hide tabs",
    description: "Takes the top bar tabs you pick off Facebook, and the Find friends button. Home always stays, and the tabs' pages still open from the left column.",
    default: false,
    options: [
      ...TAB_ROWS.map(({ option, label }) => ({ key: option, type: "toggle", label: `Hide ${label}`, default: ON_BY_DEFAULT.has(option) })),
      { key: "findFriends", type: "toggle", label: "Hide the Find friends button", default: true }
    ],
    css: tabsCss
  };

  // src/features/appearance/hide-tab-badges.js
  var BADGE_MARK = "data-hfw-badge";
  var COUNT2 = /^\d{1,3}\+?$/;
  var SCOPES = '[role="banner"], [role="navigation"]';
  var INTERACTIVE = 'a, button, [role="button"], [role="link"], [role="tab"], [role="menuitem"]';
  var TITLE_COUNT = /^\(\d{1,3}\+?\)\s*/;
  var cleanTitle = (title) => String(title ?? "").replace(TITLE_COUNT, "");
  var transparent = (color) => !color || color === "transparent" || /^rgba\(\s*0,\s*0,\s*0,\s*0\s*\)$/.test(color);
  function drawnAsBadge(element, view2) {
    const style = view2.getComputedStyle(element);
    return style.position === "absolute" || style.position === "fixed" || !transparent(style.backgroundColor);
  }
  function screenReaderOnly(element, view2 = element.ownerDocument.defaultView) {
    const style = view2.getComputedStyle(element);
    if (/^rect\(\s*0(px)?[\s,]+0(px)?[\s,]+0(px)?[\s,]+0(px)?\s*\)$/.test(style.clip ?? "") || style.clipPath === "inset(50%)") return true;
    const tiny = (value) => parseFloat(value) <= 1;
    return style.position === "absolute" && style.overflow === "hidden" && tiny(style.width) && tiny(style.height);
  }
  function drawnText(element, view2 = element.ownerDocument.defaultView) {
    let text = "";
    for (const node of element.childNodes) {
      if (node.nodeType === 3) text += node.data;
      else if (node.nodeType === 1 && !screenReaderOnly(node, view2)) text += drawnText(node, view2);
    }
    return text;
  }
  function badgeBox(leaf, view2 = leaf.ownerDocument.defaultView) {
    const count = leaf.textContent.trim();
    if (!COUNT2.test(count) || leaf.closest(INTERACTIVE) === leaf) return null;
    let box2 = leaf;
    let badge = drawnAsBadge(leaf, view2);
    for (let el = leaf.parentElement; el; el = el.parentElement) {
      if (el.matches(SCOPES) || el.matches(INTERACTIVE) || el.querySelector(INTERACTIVE)) break;
      const text = el.textContent.trim();
      if (text !== count && (!text.includes(count) || drawnText(el, view2).trim() !== count)) break;
      box2 = el;
      badge ||= drawnAsBadge(el, view2);
    }
    return badge ? box2 : null;
  }
  function markBadges(doc) {
    const view2 = doc.defaultView;
    let marked = 0;
    for (const scope of doc.querySelectorAll(SCOPES)) {
      for (const leaf of scope.querySelectorAll("span, div")) {
        if (leaf.childElementCount || !COUNT2.test(leaf.textContent.trim())) continue;
        const box2 = badgeBox(leaf, view2);
        if (box2 && !box2.hasAttribute(BADGE_MARK)) {
          box2.setAttribute(BADGE_MARK, "");
          marked += 1;
        }
      }
    }
    return marked;
  }
  function createBadgeHider({ doc, enabled, log, delay = 150 }) {
    let observer = null;
    let timer = null;
    let hidden = 0;
    const fixTitle = () => {
      const clean6 = cleanTitle(doc.title);
      if (clean6 !== doc.title) doc.title = clean6;
    };
    const scan = () => {
      timer = null;
      try {
        hidden += markBadges(doc);
        fixTitle();
      } catch (error) {
        log?.error("Hide tab badges: looking for counts failed", error);
      }
    };
    const later2 = () => {
      if (!timer) timer = setTimeout(scan, delay);
    };
    function start() {
      if (observer || !doc.documentElement) return;
      const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
      observer = new Observer((records) => {
        let title = false;
        let scope = false;
        for (const record of records) {
          const element = record.target.nodeType === 1 ? record.target : record.target.parentElement;
          if (element?.closest("title")) title = true;
          else if (!scope && (element?.closest(SCOPES) || [...record.addedNodes].some((node) => node.nodeType === 1 && (node.matches(SCOPES) || node.querySelector(SCOPES))))) scope = true;
        }
        if (title) fixTitle();
        if (scope) later2();
      });
      observer.observe(doc.documentElement, { subtree: true, childList: true, characterData: true });
      scan();
    }
    function stop() {
      observer?.disconnect();
      observer = null;
      if (timer) clearTimeout(timer);
      timer = null;
      for (const box2 of doc.querySelectorAll(`[${BADGE_MARK}]`)) box2.removeAttribute(BADGE_MARK);
    }
    return {
      apply: () => enabled() ? start() : stop(),
      scan,
      state: () => ({ running: Boolean(observer), hidden })
    };
  }
  var hide_tab_badges_default = {
    id: "hideTabBadges",
    section: "appearance",
    android: "Hide tab badges",
    title: "Hide tab badges",
    description: "Hides the red counts on the top bar and left column, and the count in front of the browser tab's title. The notifications are still there when you open them.",
    default: false,
    css: `[${BADGE_MARK}] { display: none !important; }`,
    setup({ doc, settings, enabled, log, diagnostics }) {
      if (!doc) return;
      const hider = createBadgeHider({ doc, enabled, log });
      if (doc.readyState === "loading") doc.addEventListener("DOMContentLoaded", () => hider.apply(), { once: true });
      else hider.apply();
      settings?.subscribe(() => hider.apply());
      diagnostics?.add("Counts hidden", () => enabled() ? String(hider.state().hidden) : "off");
    }
  };

  // src/features/appearance/hide-new-message.js
  var NEW_MESSAGE_CSS = hide(NEW_MESSAGE);
  var hide_new_message_default = {
    id: "hideNewMessageButton",
    section: "appearance",
    android: "Hide the New message button",
    title: "Hide the New message button",
    description: "Takes the round New message button out of the bottom corner of Facebook. Chats you have open stay where they are.",
    default: false,
    css: NEW_MESSAGE_CSS
  };

  // src/features/appearance/screenshot-mode.js
  var FACEBOOK_LINK2 = 'a[href*="facebook.com/"]:not([href*="l.facebook.com"], [href*="/hashtag/"])';
  var COMMENT = '[role="article"][aria-label]';
  var PICTURES = [
    "svg:has(image)",
    'img[data-imgperflogname="profileCoverPhoto"]'
  ];
  var NAMES2 = [
    '[data-ad-rendering-role="profile_name"]',
    `${COMMENT} div > span:first-of-type:has(span[dir="auto"]:not([lang]))`,
    `[data-ad-rendering-role="story_message"] ${FACEBOOK_LINK2}`,
    `${COMMENT} span[lang] ${FACEBOOK_LINK2}`,
    'a[href*="/user/"]',
    'a[href*="profile.php"]',
    'a[href*="/people/"]',
    '[role="main"] h1',
    'h2[dir="auto"] > span[dir="auto"] [role="button"]',
    '[data-type="hscroll-child"] [role="button"] [aria-label]',
    `${LEFT} a:has(svg image)`,
    '[role="complementary"] :is(a, [role="button"]):has(svg image)',
    '[aria-posinset] :is(h2, h3, h4) a[href*="/groups/"]'
  ];
  var SCREENSHOT_CSS = `${PICTURES.join(",\n")} { filter: blur(8px) !important; }
${NAMES2.join(",\n")} { filter: blur(5px) !important; }`;
  var screenshot_mode_default = {
    id: "screenshotMode",
    section: "appearance",
    android: "Screenshot mode",
    title: "Screenshot mode",
    description: "Blurs people's names, profile pictures and group names while it's on, so you can share a screenshot without them. Posts, photos and comments stay readable, and nothing leaves your browser.",
    default: false,
    css: SCREENSHOT_CSS
  };

  // src/features/menu/hide-menu-promotions.js
  function promotionsCss(get) {
    const rows = PROMOTION_ROWS.filter(({ option }) => get(`hideMenuPromotions.${option}`));
    if (!rows.length) return "";
    return hide(rows.flatMap(({ link }) => [place.left(link), place.menu(link)]).join(",\n"));
  }
  var hide_menu_promotions_default = {
    id: "hideMenuPromotions",
    section: "menu",
    android: "Hide Menu promotions",
    title: "Hide Menu promotions",
    description: "Takes Facebook's ad tools and gaming pitches out of the left column and Facebook's menu.",
    default: false,
    options: PROMOTION_ROWS.map(({ option, label }) => ({ key: option, type: "toggle", label, default: true })),
    css: promotionsCss
  };

  // src/ui/icons.js
  var SLIDERS_ICON = [
    "M3 5h10v2H3z",
    "M17 5h4v2h-4z",
    "M13 3h4v6h-4z",
    "M3 11h4v2H3z",
    "M11 11h10v2H11z",
    "M7 9h4v6H7z",
    "M3 17h12v2H3z",
    "M19 17h2v2h-2z",
    "M15 15h4v6h-4z"
  ];

  // src/features/menu/menu-entry.js
  var ROW_MARK2 = "data-hfw-menu-entry";
  var LABEL2 = "HushFacebook Web";
  var SVG_NS3 = "http://www.w3.org/2000/svg";
  var PROFILE_LINK = 'a[href="/me/"], a[href="/me"]';
  var RETRIES_MS2 = [0, 50, 150, 400, 1e3, 2500];
  function accountMenuList(doc) {
    for (const dialog of doc.querySelectorAll('[role="dialog"]')) {
      if (!dialog.querySelector(PROFILE_LINK)) continue;
      const list = dialog.querySelector('[role="list"]');
      if (list) return list;
    }
    return null;
  }
  function sliders(doc) {
    const svg = doc.createElementNS(SVG_NS3, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", "20");
    svg.setAttribute("height", "20");
    svg.setAttribute("aria-hidden", "true");
    svg.setAttribute("style", "display: block; fill: var(--primary-icon, currentColor)");
    for (const d of SLIDERS_ICON) {
      const path2 = doc.createElementNS(SVG_NS3, "path");
      path2.setAttribute("d", d);
      svg.append(path2);
    }
    return svg;
  }
  var ownText3 = (el) => [...el.childNodes].some((node) => node.nodeType === 3 && node.textContent.trim());
  function buildRow2(template, doc) {
    const row = template.cloneNode(true);
    for (const el of [row, ...row.querySelectorAll("*")]) {
      for (const name of ["id", "aria-label", "aria-labelledby", "aria-describedby"]) el.removeAttribute(name);
    }
    const [label, ...rest] = [...row.querySelectorAll("*")].filter(ownText3);
    if (!label) return null;
    label.textContent = LABEL2;
    for (const extra of rest) extra.textContent = "";
    row.querySelector("i, svg, img")?.replaceWith(sliders(doc));
    row.setAttribute(ROW_MARK2, "");
    return row;
  }
  function addRow(list, doc, onOpen) {
    if (list.querySelector(`[${ROW_MARK2}]`)) return "present";
    const rows = [...list.children].filter((el) => el.getAttribute("role") === "listitem");
    const last = rows.at(-1);
    const row = last && buildRow2(last, doc);
    if (!row) return "no-row";
    const run = (event) => {
      event.preventDefault();
      event.stopPropagation();
      onOpen(row);
    };
    row.addEventListener("click", run);
    row.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") run(event);
    });
    list.insertBefore(row, last);
    return "added";
  }
  function closeMenu2(doc, row) {
    const dialog = row.closest('[role="dialog"]');
    if (!dialog) return;
    const label = dialog.getAttribute("aria-label");
    const opener = label && [...doc.querySelectorAll('[role="banner"] [aria-expanded="true"]')].find((el) => el.getAttribute("aria-label") === label);
    if (opener) {
      opener.click();
      return;
    }
    const Keyboard = doc.defaultView?.KeyboardEvent ?? globalThis.KeyboardEvent;
    dialog.dispatchEvent(new Keyboard("keydown", { key: "Escape", code: "Escape", keyCode: 27, bubbles: true, cancelable: true }));
  }
  function createMenuEntry({ doc, enabled, openSettings, log, onFail, setTimer = setTimeout }) {
    let added = 0;
    let failed = false;
    let opener = null;
    let watched = null;
    const Observer = doc.defaultView?.MutationObserver ?? globalThis.MutationObserver;
    const open = (row) => {
      closeMenu2(doc, row);
      setTimer(() => openSettings(), 0);
    };
    function sync() {
      if (!enabled()) {
        remove();
        return;
      }
      const list = accountMenuList(doc);
      if (!list) return;
      const result = addRow(list, doc, open);
      if (result === "added") added += 1;
      if (result === "no-row" && !failed) {
        failed = true;
        log?.warn("Settings in your account menu: Facebook's account menu has no row to copy, so the HushFacebook Web row isn't there.");
        onFail?.();
      }
      watch(list.closest('[role="dialog"]'));
    }
    function watch(dialog) {
      if (!dialog || watched?.dialog === dialog) return;
      watched?.observer.disconnect();
      const observer = new Observer(() => {
        if (!dialog.isConnected) {
          observer.disconnect();
          if (watched?.dialog === dialog) watched = null;
          return;
        }
        sync();
      });
      observer.observe(dialog, { childList: true, subtree: true });
      watched = { dialog, observer };
    }
    function remove() {
      watched?.observer.disconnect();
      watched = null;
      for (const row of doc.querySelectorAll(`[${ROW_MARK2}]`)) row.remove();
    }
    function start() {
      if (opener || !doc.body) return;
      opener = new Observer((records) => {
        if (!enabled()) return;
        const opened = records.some((record) => record.target.getAttribute?.("aria-expanded") === "true" && record.target.closest?.('[role="banner"]'));
        if (opened) for (const wait of RETRIES_MS2) setTimer(sync, wait);
      });
      opener.observe(doc.body, { subtree: true, attributes: true, attributeFilter: ["aria-expanded"] });
    }
    return {
      apply() {
        start();
        sync();
      },
      sync,
      state: () => ({ added, failed })
    };
  }
  var menu_entry_default = {
    id: "menuEntry",
    section: "menu",
    android: "Hushfacebook in the Menu",
    title: "Settings in your account menu",
    description: "Adds a HushFacebook Web row to the menu that opens from your picture at the right end of the top bar. Click it to open these settings.",
    default: true,
    options: [
      { key: "hideButton", type: "toggle", label: "Hide the round settings button in the corner", default: false }
    ],
    setup({ doc, settings, enabled, log, diagnostics, openSettings, markUnavailable }) {
      if (!doc) return;
      const entry = createMenuEntry({ doc, enabled, openSettings: () => openSettings?.(), log, onFail: () => markUnavailable?.() });
      whenBodyReady(() => entry.apply(), doc);
      settings?.subscribe(() => entry.apply());
      diagnostics?.add("Account menu row", () => {
        if (!enabled()) return "off";
        const { added, failed } = entry.state();
        if (failed) return "Facebook's menu had no row to copy";
        return added ? `Added ${added} ${added === 1 ? "time" : "times"}` : "Menu not opened yet";
      });
    }
  };

  // src/features/meta/hide-meta-upsells.js
  var UPSELLS_CSS = hide([place.left(UPSELL_LINK), place.menu(UPSELL_LINK)].join(",\n"));
  var hide_meta_upsells_default = {
    id: "hideMetaUpsells",
    section: "meta",
    android: "Hide Meta upsells",
    title: "Hide Meta upsells",
    description: "Takes Meta AI, Meta Quest, Ray-Ban Meta, WhatsApp, Instagram and Messenger Kids out of the left column and Facebook's menu.",
    default: false,
    css: UPSELLS_CSS
  };

  // src/features/meta/hide-promotions.js
  var MARKERS6 = ['"eligible_promotions"', '"jewel_qp"'];
  var LISTS = ["eligible_promotions", "jewel_qp"];
  function emptyPromotions(data) {
    let removed = 0;
    (function visit(value, depth) {
      if (!value || typeof value !== "object" || depth > 60) return;
      if (Array.isArray(value)) {
        for (const item of value) visit(item, depth + 1);
        return;
      }
      for (const key of LISTS) {
        const nodes = value[key]?.nodes;
        if (Array.isArray(nodes) && nodes.length) {
          removed += nodes.length;
          value[key].nodes = [];
        }
      }
      for (const child2 of Object.values(value)) visit(child2, depth + 1);
    })(data, 0);
    return removed;
  }
  var hide_promotions_default = {
    id: "hidePromotions",
    section: "meta",
    android: "Hide the Get Messenger card",
    title: "Hide Facebook's own cards and tips",
    description: "Takes out the cards Facebook puts up for its own things, like Get the Messenger app over your chats or in the Messenger menu, the tips in stories and the promotions it puts between posts on Home. Reminders Facebook sends the same way go too.",
    default: false,
    needsPage: true,
    setup({ net, router, enabled, diagnostics }) {
      let removed = 0;
      net.transformResponses({
        // Its own id: the hooks log a rule's first failure only, by id, and the Home rule below
        // takes the switch's.
        id: "hidePromotions:lists",
        enabled,
        markers: MARKERS6,
        // Facebook parses every answer with JSON.parse, so one place covers them all.
        match: (ctx) => ctx.transport === "json-parse",
        transform(data, ctx, stage) {
          const count = emptyPromotions(data);
          if (!count) return false;
          later(stage, () => {
            removed += count;
            diagnostics?.changed();
          });
          return true;
        }
      });
      net.transformResponses(adRule("hidePromotions", enabled, (fired) => {
        removed += fired.length;
        diagnostics?.changed();
      }, { route: () => router?.current(), diagnostics, reason: "Promotion" }));
      diagnostics?.add("Cards and tips held back", () => String(removed));
    }
  };

  // src/features/appearance/custom-css.js
  var custom_css_default = {
    id: "customCss",
    section: "appearance",
    android: "Custom CSS",
    title: "Custom CSS",
    description: "Your own CSS rules for Facebook, applied after everything else the script does. Handy when Facebook moves something before a switch catches up.",
    default: false,
    options: [
      { key: "css", type: "text", rows: 8, code: true, label: "CSS rules", default: "", maxLength: 5e4 }
    ],
    css: (get) => String(get("customCss.css") ?? "")
  };

  // src/features/games/sdk.js
  var INSTANT_AD_METHODS = Object.freeze([
    "getInterstitialAdAsync",
    "getRewardedVideoAsync",
    "getRewardedInterstitialAsync",
    "loadBannerAdAsync"
  ]);
  var installations = /* @__PURE__ */ new WeakMap();
  var POLL_MS = 250;
  var isObject4 = (value) => value !== null && (typeof value === "object" || typeof value === "function");
  function watchProperty(target2, key, transform) {
    const original = Object.getOwnPropertyDescriptor(target2, key);
    if (original && !original.configurable) return null;
    const accessor = original && !("value" in original);
    let value = accessor ? void 0 : Reflect.get(target2, key);
    let assigned = false;
    const get = function() {
      const current = accessor ? original.get?.call(this) : value;
      return transform(current);
    };
    const writable = accessor ? typeof original.set === "function" : original?.writable !== false;
    const set = writable ? function(next) {
      if (accessor) original.set.call(this, next);
      else value = next;
      assigned = true;
      transform(next);
    } : void 0;
    Object.defineProperty(target2, key, {
      get,
      set,
      configurable: true,
      enumerable: original?.enumerable ?? true
    });
    const owns = () => {
      const current = Object.getOwnPropertyDescriptor(target2, key);
      return current?.get === get && current?.set === set;
    };
    return {
      owns,
      restore() {
        if (!owns()) return;
        if (accessor) Object.defineProperty(target2, key, original);
        else if (original) Object.defineProperty(target2, key, { ...original, value });
        else if (assigned) Object.defineProperty(target2, key, { value, writable: true, configurable: true, enumerable: true });
        else Reflect.deleteProperty(target2, key);
      }
    };
  }
  function installInstantGamesHooks({ win, enabled = () => false, onBlocked, log } = {}) {
    if (installations.has(win)) return installations.get(win);
    const reject = win.Promise.reject.bind(win.Promise);
    const RealmObject = win.Object ?? Object;
    const sdks = /* @__PURE__ */ new Map();
    const warned = /* @__PURE__ */ new Set();
    let running = true;
    let globalWatch = null;
    let timer = null;
    const warn = (key, message, error) => {
      if (warned.has(key)) return;
      warned.add(key);
      try {
        log?.warn?.(message, error);
      } catch {
      }
    };
    const active2 = () => {
      if (!running) return false;
      try {
        return enabled() === true;
      } catch (error) {
        warn("enabled", "Could not read the Instant Games ad setting; the SDK call was left alone", error);
        return false;
      }
    };
    const wrap = (original, method) => function(...args) {
      if (!active2()) return Reflect.apply(original, this, args);
      const error = new RealmObject();
      error.code = "ADS_NO_FILL";
      error.message = "No ad is available.";
      try {
        onBlocked?.(method);
      } catch (failure) {
        warn("onBlocked", "Could not count a held-back Instant Games ad", failure);
      }
      return reject(error);
    };
    const patchSdk = (sdk) => {
      if (!running || !isObject4(sdk)) return sdk;
      let methods = sdks.get(sdk);
      if (!methods) sdks.set(sdk, methods = /* @__PURE__ */ new Map());
      for (const method of INSTANT_AD_METHODS) {
        try {
          if (methods.get(method)?.owns()) continue;
          if (typeof Reflect.get(sdk, method) !== "function") continue;
          const wrappers = /* @__PURE__ */ new WeakMap();
          const transform = (value) => {
            if (!running || typeof value !== "function") return value;
            if (!wrappers.has(value)) wrappers.set(value, wrap(value, method));
            return wrappers.get(value);
          };
          const watcher = watchProperty(sdk, method, transform);
          if (watcher) methods.set(method, watcher);
          else warn(method, `Instant Games ${method} is protected and unsupported; its ads are not blocked`);
        } catch (error) {
          warn(method, `Could not wrap Instant Games ${method}; the SDK property was left alone`, error);
        }
      }
      return sdk;
    };
    const refresh = () => {
      if (!running) return;
      try {
        if (!globalWatch?.owns()) {
          globalWatch = watchProperty(win, "FBInstant", patchSdk);
          if (!globalWatch && Object.getOwnPropertyDescriptor(win, "FBInstant")?.writable) {
            warn("protected-global", "The Instant Games SDK global is protected; replacement SDKs may request ads before the next check");
          }
        }
        patchSdk(Reflect.get(win, "FBInstant"));
      } catch (error) {
        warn("global", "Could not watch the Instant Games SDK global", error);
      }
    };
    const onLoad = (event) => {
      if (event.target?.tagName === "SCRIPT") refresh();
    };
    const api = {
      refresh,
      stop() {
        if (!running) return;
        running = false;
        if (timer !== null) win.clearInterval(timer);
        win.removeEventListener?.("load", onLoad, true);
        for (const methods of sdks.values()) {
          for (const [method, watcher] of methods) {
            try {
              watcher.restore();
            } catch (error) {
              warn(`restore:${method}`, `Could not restore Instant Games ${method}; retained wrappers now pass through`, error);
            }
          }
        }
        try {
          globalWatch?.restore();
        } catch (error) {
          warn("restore:global", "Could not restore the Instant Games global; the SDK remains available", error);
        }
        sdks.clear();
        installations.delete(win);
      }
    };
    installations.set(win, api);
    refresh();
    if (typeof win.setInterval === "function") timer = win.setInterval(refresh, POLL_MS);
    win.addEventListener?.("load", onLoad, true);
    return api;
  }

  // src/features/games/frame.js
  var GAME_ADS_KEY = "instantGamesAds.enabled";
  var GAME_ADS_FEATURE = "blockInstantGamesAds";
  var RUNNING = /* @__PURE__ */ Symbol.for("hushfacebook-web.games");
  function executionTarget(win) {
    const { protocol, hostname } = win.location;
    if (protocol !== "https:") return "skip";
    if (hostname === "apps.fbsbx.com" || hostname.endsWith(".apps.fbsbx.com")) return "game";
    if ((hostname === "www.facebook.com" || hostname === "web.facebook.com") && win.top === win) return "facebook";
    return "skip";
  }
  function mirrorGameSetting({ storage, settings, enabled, log }) {
    if (!keepsSettings(storage)) return null;
    const sync = () => {
      const next = enabled() === true;
      try {
        if (storage.get(GAME_ADS_KEY, void 0) === next) return;
        storage.set(GAME_ADS_KEY, next);
      } catch (error) {
        log?.error("Could not update the Instant Games ad setting", error);
      }
    };
    if (settings.whenLoaded) settings.whenLoaded(sync);
    else sync();
    const unsubscribe = settings.subscribe(({ keys }) => {
      if (keys.includes(GAME_ADS_FEATURE) || keys.includes("paused")) sync();
    });
    return { sync, stop: () => unsubscribe() };
  }
  function startGameFrame({ win, storage, log, onBlocked }) {
    if (!keepsSettings(storage)) {
      log?.warn("Instant Games ad blocking needs storage from your userscript manager.");
      return null;
    }
    if (win[RUNNING]) return win[RUNNING];
    let stopped = false;
    let block2 = false;
    try {
      block2 = storage.get(GAME_ADS_KEY, false) === true;
    } catch (error) {
      log?.error("Could not read the Instant Games ad setting", error);
    }
    const hooks2 = installInstantGamesHooks({ win, enabled: () => !stopped && block2, log, onBlocked });
    let unsubscribe;
    try {
      unsubscribe = storage.onChange?.(GAME_ADS_KEY, (value) => {
        if (stopped) return;
        block2 = value === true;
        hooks2.refresh();
      });
    } catch (error) {
      block2 = false;
      log?.error("Could not follow the Instant Games ad setting; ads were left under game control", error);
    }
    const controller = {
      stop() {
        if (stopped) return;
        stopped = true;
        try {
          unsubscribe?.();
        } catch (error) {
          log?.error("Could not stop following the Instant Games ad setting", error);
        }
        hooks2.stop();
        if (win[RUNNING] === controller) delete win[RUNNING];
      }
    };
    win[RUNNING] = controller;
    return controller;
  }

  // src/features/games/block-ads.js
  var block_ads_default = {
    id: "blockInstantGamesAds",
    section: "meta",
    android: "Block Instant Games ads",
    title: "Block Instant Games ads",
    description: "Makes supported game ad requests answer that no ad is available. Some games protect their ad system and can't be filtered. Rewards that need an ad won't be earned. Games use the setting from the Facebook account you last opened or changed it in. Reload an open game after changing this. Not yet checked in a live game.",
    default: false,
    reload: true,
    setup({ storage, settings, enabled, log, markUnavailable }) {
      if (!mirrorGameSetting({ storage, settings, enabled, log })) {
        markUnavailable?.("api");
        log?.warn("Instant Games ad blocking needs storage from your userscript manager.");
      }
    }
  };

  // src/features/index.js
  var features = [
    hide_sponsored_posts_default,
    hide_suggested_posts_default,
    hide_reels_in_feed_default,
    hide_stories_tray_default,
    filters_default,
    hide_seen_posts_default,
    hide_ai_posts_default,
    post_dates_default,
    keep_feed_place_default,
    hide_follow_buttons_default,
    hide_counts_default,
    expand_long_posts_default,
    hide_sponsored_reels_default,
    no_watch_history_default,
    clean_up_reels_default,
    anonymous_stories_default,
    stop_advance_default,
    hide_sponsored_search_default,
    no_search_history_default,
    hide_sponsored_marketplace_default,
    seller_profile_default,
    hide_read_receipts_default,
    hide_typing_default,
    hide_kinds_default,
    usage_logs_default,
    comment_order_default,
    show_all_replies_default,
    hide_comment_stickers_default,
    hide_video_comment_box_default,
    hide_comment_typing_default,
    hide_incoming_typing_default,
    tags_after_at_default,
    comments_as_written_default,
    sanitize_links_default,
    direct_links_default,
    share_sheet_default,
    download_photos_default,
    download_videos_default,
    download_reels_default,
    download_stories_default,
    download_menu_default,
    tap_to_play_default,
    hdr_brightness_default,
    resume_videos_default,
    keep_speed_default,
    keep_volume_default,
    hold_for_speed_default,
    picture_in_picture_default,
    frame_step_default,
    keep_controls_default,
    video_quality_default,
    remember_watched_default,
    force_dark_default,
    amoled_default,
    accent_default,
    system_font_default,
    system_emoji_default,
    no_transitions_default,
    hide_tabs_default,
    hide_tab_badges_default,
    hide_new_message_default,
    screenshot_mode_default,
    menu_entry_default,
    hide_menu_promotions_default,
    hide_meta_upsells_default,
    hide_promotions_default,
    block_ads_default,
    // In this order: the first to claim a Home load redirects it (opening/start.js).
    marketplace_only_default,
    open_on_tab_default,
    following_feed_default,
    messenger_page_default,
    // Last, so its rules come after every built-in style.
    custom_css_default
  ];

  // src/ui/keys.js
  var PANEL_ATTRIBUTE = "data-hushfacebook-web";
  var KEY_EVENTS = ["keydown", "keypress", "keyup"];
  var fromPanel = (event) => (event.composedPath?.() ?? [event.target]).some((node) => node?.getAttribute?.(PANEL_ATTRIBUTE) === "ui");
  function keepKeysInPanel(win) {
    const stop = (event) => {
      if (fromPanel(event)) event.stopImmediatePropagation();
    };
    for (const type of KEY_EVENTS) win.addEventListener(type, stop, true);
  }

  // src/ui/logo-long-press.js
  var LOGO_SELECTOR = '[role="banner"] a[aria-label="Facebook"]';
  var HOLD_MS2 = 500;
  var logoFor = (target2) => target2?.closest?.(LOGO_SELECTOR) ?? null;
  function installLogoLongPress({
    doc = globalThis.document,
    openSettings,
    setTimer = setTimeout,
    clearTimer = clearTimeout
  }) {
    let press = null;
    let completion = null;
    function cancelPress() {
      if (press?.timer != null) clearTimer(press.timer);
      press = null;
    }
    function pointerdown(event) {
      cancelPress();
      if (completion && (completion.released || completion.pointerId === event.pointerId)) completion = null;
      const logo = logoFor(event.target);
      if (!logo || !["mouse", "touch"].includes(event.pointerType) || event.isPrimary === false || event.pointerType === "mouse" && event.button !== 0) return;
      const started = {
        logo,
        pointerId: event.pointerId,
        pointerType: event.pointerType,
        x: event.clientX,
        y: event.clientY,
        timer: null
      };
      started.timer = setTimer(() => {
        if (press !== started) return;
        press = null;
        completion = {
          pointerId: started.pointerId,
          pointerType: started.pointerType,
          clickHandled: false,
          contextMenuHandled: false,
          released: false
        };
        openSettings();
      }, HOLD_MS2);
      press = started;
    }
    function pointermove(event) {
      if (!press || event.pointerId !== press.pointerId) return;
      if (event.clientX !== press.x || event.clientY !== press.y) cancelPress();
    }
    function pointerend(event) {
      if (press && event.pointerId === press.pointerId) cancelPress();
      if (completion?.pointerId === event.pointerId) completion.released = true;
    }
    function pointerleave(event) {
      if (press && event.pointerId === press.pointerId && event.target === press.logo) cancelPress();
    }
    function click(event) {
      if (!completion || completion.clickHandled || event.pointerId !== completion.pointerId || event.pointerType !== completion.pointerType) return;
      completion.clickHandled = true;
      event.preventDefault();
      event.stopImmediatePropagation();
    }
    function contextmenu(event) {
      if (!completion || completion.pointerType !== "touch" || completion.contextMenuHandled || event.pointerId !== completion.pointerId || event.pointerType !== "touch") return;
      completion.contextMenuHandled = true;
      event.preventDefault();
      event.stopImmediatePropagation();
    }
    const listeners = [
      ["pointerdown", pointerdown],
      ["pointermove", pointermove],
      ["pointerup", pointerend],
      ["pointercancel", pointerend],
      ["pointerleave", pointerleave],
      ["click", click],
      ["contextmenu", contextmenu]
    ];
    for (const [type, listener] of listeners) doc.addEventListener(type, listener, true);
    return () => {
      cancelPress();
      for (const [type, listener] of listeners) doc.removeEventListener(type, listener, true);
    };
  }

  // src/features/sections.js
  var SECTIONS = [
    { id: "feed", title: "News feed" },
    { id: "reels", title: "Reels and Watch" },
    { id: "stories", title: "Stories" },
    { id: "comments", title: "Comments" },
    { id: "search", title: "Search" },
    { id: "marketplace", title: "Marketplace" },
    { id: "chats", title: "Chats" },
    { id: "notifications", title: "Notifications" },
    { id: "privacy", title: "Privacy" },
    { id: "links", title: "Links" },
    { id: "downloads", title: "Downloads" },
    { id: "playback", title: "Playback" },
    { id: "appearance", title: "Appearance" },
    { id: "menu", title: "Menu" },
    { id: "meta", title: "Meta's other products" },
    { id: "opening", title: "Opening Facebook" },
    { id: "writing", title: "Writing" }
  ];

  // src/ui/h.js
  function h(tag, props, ...children2) {
    const el = document.createElement(tag);
    for (const [key, value] of Object.entries(props ?? {})) {
      if (value === void 0 || value === null || value === false) continue;
      if (key === "class") el.className = value;
      else if (key === "text") el.textContent = value;
      else if (key === "dataset") Object.assign(el.dataset, value);
      else if (key.startsWith("on") && typeof value === "function") el.addEventListener(key.slice(2), value);
      else if (typeof value === "boolean" || typeof value === "number") el[key] = value;
      else el.setAttribute(key, value);
    }
    for (const child2 of children2.flat(Infinity)) {
      if (child2 === null || child2 === void 0 || child2 === false) continue;
      el.append(child2 instanceof Node ? child2 : String(child2));
    }
    return el;
  }
  var SVG_NS4 = "http://www.w3.org/2000/svg";
  function icon(paths, label) {
    const svg = document.createElementNS(SVG_NS4, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("aria-hidden", label ? "false" : "true");
    if (label) svg.setAttribute("aria-label", label);
    for (const d of paths) {
      const path2 = document.createElementNS(SVG_NS4, "path");
      path2.setAttribute("d", d);
      svg.append(path2);
    }
    return svg;
  }

  // src/ui/navigation-icons.js
  var shapes = {
    feed: [{ "tag": "path", "attrs": { "d": "M16 6h3a1 1 0 0 1 1 1v11a2 2 0 0 1 -4 0v-13a1 1 0 0 0 -1 -1h-10a1 1 0 0 0 -1 1v12a3 3 0 0 0 3 3h11" } }, { "tag": "path", "attrs": { "d": "M8 8l4 0" } }, { "tag": "path", "attrs": { "d": "M8 12l4 0" } }, { "tag": "path", "attrs": { "d": "M8 16l4 0" } }],
    reels: [{ "tag": "path", "attrs": { "d": "M7 4v16l13 -8l-13 -8" } }],
    stories: [{ "tag": "path", "attrs": { "d": "M8.56 3.69a9 9 0 0 0 -2.92 1.95" } }, { "tag": "path", "attrs": { "d": "M3.69 8.56a9 9 0 0 0 -.69 3.44" } }, { "tag": "path", "attrs": { "d": "M3.69 15.44a9 9 0 0 0 1.95 2.92" } }, { "tag": "path", "attrs": { "d": "M8.56 20.31a9 9 0 0 0 3.44 .69" } }, { "tag": "path", "attrs": { "d": "M15.44 20.31a9 9 0 0 0 2.92 -1.95" } }, { "tag": "path", "attrs": { "d": "M20.31 15.44a9 9 0 0 0 .69 -3.44" } }, { "tag": "path", "attrs": { "d": "M20.31 8.56a9 9 0 0 0 -1.95 -2.92" } }, { "tag": "path", "attrs": { "d": "M15.44 3.69a9 9 0 0 0 -3.44 -.69" } }],
    comments: [{ "tag": "path", "attrs": { "d": "M8 9h8" } }, { "tag": "path", "attrs": { "d": "M8 13h6" } }, { "tag": "path", "attrs": { "d": "M18 4a3 3 0 0 1 3 3v8a3 3 0 0 1 -3 3h-5l-5 3v-3h-2a3 3 0 0 1 -3 -3v-8a3 3 0 0 1 3 -3h12" } }],
    search: [{ "tag": "path", "attrs": { "d": "M3 10a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" } }, { "tag": "path", "attrs": { "d": "M21 21l-6 -6" } }],
    marketplace: [{ "tag": "path", "attrs": { "d": "M3 21l18 0" } }, { "tag": "path", "attrs": { "d": "M3 7v1a3 3 0 0 0 6 0v-1m0 1a3 3 0 0 0 6 0v-1m0 1a3 3 0 0 0 6 0v-1h-18l2 -4h14l2 4" } }, { "tag": "path", "attrs": { "d": "M5 21l0 -10.15" } }, { "tag": "path", "attrs": { "d": "M19 21l0 -10.15" } }, { "tag": "path", "attrs": { "d": "M9 21v-4a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v4" } }],
    chats: [{ "tag": "path", "attrs": { "d": "M21 14l-3 -3h-7a1 1 0 0 1 -1 -1v-6a1 1 0 0 1 1 -1h9a1 1 0 0 1 1 1v10" } }, { "tag": "path", "attrs": { "d": "M14 15v2a1 1 0 0 1 -1 1h-7l-3 3v-10a1 1 0 0 1 1 -1h2" } }],
    notifications: [{ "tag": "path", "attrs": { "d": "M10 5a2 2 0 1 1 4 0a7 7 0 0 1 4 6v3a4 4 0 0 0 2 3h-16a4 4 0 0 0 2 -3v-3a7 7 0 0 1 4 -6" } }, { "tag": "path", "attrs": { "d": "M9 17v1a3 3 0 0 0 6 0v-1" } }],
    privacy: [{ "tag": "path", "attrs": { "d": "M12 3a12 12 0 0 0 8.5 3a12 12 0 0 1 -8.5 15a12 12 0 0 1 -8.5 -15a12 12 0 0 0 8.5 -3" } }, { "tag": "path", "attrs": { "d": "M11 11a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" } }, { "tag": "path", "attrs": { "d": "M12 12l0 2.5" } }],
    links: [{ "tag": "path", "attrs": { "d": "M9 15l6 -6" } }, { "tag": "path", "attrs": { "d": "M11 6l.463 -.536a5 5 0 0 1 7.071 7.072l-.534 .464" } }, { "tag": "path", "attrs": { "d": "M13 18l-.397 .534a5.068 5.068 0 0 1 -7.127 0a4.972 4.972 0 0 1 0 -7.071l.524 -.463" } }],
    downloads: [{ "tag": "path", "attrs": { "d": "M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2" } }, { "tag": "path", "attrs": { "d": "M7 11l5 5l5 -5" } }, { "tag": "path", "attrs": { "d": "M12 4l0 12" } }],
    playback: [{ "tag": "path", "attrs": { "d": "M7 4v16l13 -8l-13 -8" } }],
    appearance: [{ "tag": "path", "attrs": { "d": "M12 21a9 9 0 0 1 0 -18c4.97 0 9 3.582 9 8c0 1.06 -.474 2.078 -1.318 2.828c-.844 .75 -1.989 1.172 -3.182 1.172h-2.5a2 2 0 0 0 -1 3.75a1.3 1.3 0 0 1 -1 2.25" } }, { "tag": "path", "attrs": { "d": "M7.5 10.5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" } }, { "tag": "path", "attrs": { "d": "M11.5 7.5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" } }, { "tag": "path", "attrs": { "d": "M15.5 10.5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" } }],
    menu: [{ "tag": "path", "attrs": { "d": "M4 6l16 0" } }, { "tag": "path", "attrs": { "d": "M4 12l16 0" } }, { "tag": "path", "attrs": { "d": "M4 18l16 0" } }],
    meta: [{ "tag": "path", "attrs": { "d": "M4 5a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4" } }, { "tag": "path", "attrs": { "d": "M14 5a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4" } }, { "tag": "path", "attrs": { "d": "M4 15a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4" } }, { "tag": "path", "attrs": { "d": "M14 15a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4" } }],
    opening: [{ "tag": "path", "attrs": { "d": "M12 6h-6a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-6" } }, { "tag": "path", "attrs": { "d": "M11 13l9 -9" } }, { "tag": "path", "attrs": { "d": "M15 4h5v5" } }],
    general: [{ "tag": "path", "attrs": { "d": "M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065" } }, { "tag": "path", "attrs": { "d": "M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" } }],
    diagnostics: [{ "tag": "path", "attrs": { "d": "M3 12h4l3 8l4 -16l3 8h4" } }],
    close: [{ "tag": "path", "attrs": { "d": "M18 6l-12 12" } }, { "tag": "path", "attrs": { "d": "M6 6l12 12" } }]
  };
  function navigationIcon(id) {
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    for (const [key, value] of Object.entries({ viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.75", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", class: "nav-icon" })) svg.setAttribute(key, value);
    for (const shape of shapes[id] ?? shapes.general) {
      const child2 = document.createElementNS(ns, shape.tag);
      for (const [key, value] of Object.entries(shape.attrs)) child2.setAttribute(key, value);
      svg.append(child2);
    }
    return svg;
  }

  // src/ui/new-dots.js
  var SEEN_SETTINGS_KEY = "panel.seenSettings";
  var SEEN_SETTINGS_MAX = 4e3;
  var featureKeys = (feature) => [feature.id, ...(feature.options ?? []).map((option) => `${feature.id}.${option.key}`)];
  function createNewDots({ storage, features: features2, log }) {
    let fresh = /* @__PURE__ */ new Set();
    const visited = /* @__PURE__ */ new Set();
    const ready = () => Boolean(storage) && (typeof storage.status !== "function" || storage.status().state === "ready");
    const saved = () => {
      const list = storage.get(SEEN_SETTINGS_KEY, null);
      return Array.isArray(list) ? list.filter((key) => typeof key === "string") : null;
    };
    const save = (keys) => {
      const list = [.../* @__PURE__ */ new Set([...saved() ?? [], ...keys])].slice(-SEEN_SETTINGS_MAX);
      Promise.resolve(storage.set(SEEN_SETTINGS_KEY, list)).catch((error) => log?.warn("Couldn't save which settings are new", error));
    };
    return {
      // When the panel opens from closed.
      start() {
        fresh = /* @__PURE__ */ new Set();
        visited.clear();
        try {
          if (!ready()) return;
          const all = features2.flatMap(featureKeys);
          const seen = saved();
          if (seen === null) {
            save(all);
            return;
          }
          const known = new Set(seen);
          fresh = new Set(all.filter((key) => !known.has(key)));
        } catch (error) {
          fresh = /* @__PURE__ */ new Set();
          log?.warn("Couldn't read which settings are new", error);
        }
      },
      visit(sectionId) {
        visited.add(sectionId);
      },
      // When the panel closes: what was on screen stops being new.
      finish() {
        const done = features2.filter((feature) => visited.has(feature.section)).flatMap(featureKeys).filter((key) => fresh.has(key));
        visited.clear();
        if (!done.length) return;
        try {
          save(done);
        } catch (error) {
          log?.warn("Couldn't save which settings are new", error);
        }
      },
      isNew: (key) => fresh.has(key),
      // A feature that's off hides its options, so its card carries their dots too.
      featureIsNew: (feature) => featureKeys(feature).some((key) => fresh.has(key)),
      sectionIsNew: (sectionId) => features2.some((feature) => feature.section === sectionId && featureKeys(feature).some((key) => fresh.has(key)))
    };
  }

  // src/ui/diagnostic-report.js
  var REPORT_LOG_LINES = 150;
  var COUNT3 = /^\d{1,6}$/;
  var NAME = /^[A-Za-z][\w .-]{0,59}$/;
  var KEY = /^[\w.-]{1,80}$/;
  var oneLine = (value) => String(value ?? "").replace(/\s+/g, " ").trim();
  var shorten = (text, max) => text.length <= max ? text : `${text.slice(0, max - 12).trimEnd()} [shortened]`;
  var named = (value) => NAME.test(String(value ?? "")) ? String(value) : "other";
  function scrubText(value, max = 300) {
    const text = oneLine(value).replace(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g, "[email]").replace(/\b[a-z][a-z\d+.-]*:\/\/\S+/gi, "[link]").replace(/\b(?:[\w-]+\.)*(?:facebook|fbcdn|fb|messenger|instagram)\.(?:com|net)\b\S*/gi, "[link]").replace(/\b(?:fb\.me|fb\.watch|m\.me)\/\S*/gi, "[link]").replace(/\bpfbid\w+/gi, "[id]").replace(/\d{5,}/g, "[number]");
    return shorten(text, max);
  }
  var BROWSERS = [
    ["EdgA", "Edge"],
    ["EdgiOS", "Edge"],
    ["Edg", "Edge"],
    ["OPR", "Opera"],
    ["FxiOS", "Firefox"],
    ["Firefox", "Firefox"],
    ["CriOS", "Chrome"],
    ["Chrome", "Chrome"],
    ["Version", "Safari"]
  ];
  var SYSTEMS = [["Windows", "Windows"], ["CrOS", "ChromeOS"], ["Android", "Android"], ["iPhone", "iOS"], ["iPad", "iOS"], ["Macintosh", "macOS"], ["Linux", "Linux"]];
  function browserOf(agent) {
    const text = String(agent ?? "");
    let browser = "Unknown browser";
    for (const [token, name] of BROWSERS) {
      const major = text.match(new RegExp(`\\b${token}/(\\d+)`))?.[1];
      if (major) {
        browser = `${name} ${major}`;
        break;
      }
    }
    const system = SYSTEMS.find(([token]) => text.includes(token))?.[1];
    return system ? `${browser} on ${system}` : browser;
  }
  function settingLines(settings) {
    const on = [];
    const picked = [];
    const filled = [];
    for (const [key, spec] of settings?.schema ?? []) {
      if (!KEY.test(key)) continue;
      const value = settings.get(key);
      if (spec.type === "toggle") {
        if (value === true) on.push(key);
      } else if (spec.type === "select") {
        if (value !== spec.default && KEY.test(String(value)) && spec.choices?.some((choice) => choice.value === value)) picked.push(`${key}=${value}`);
      } else if (spec.type === "number") {
        if (Number.isFinite(value) && value !== spec.default) picked.push(`${key}=${value}`);
      } else if (spec.type === "text") {
        if (typeof value === "string" && value.trim()) filled.push(key);
      }
    }
    return [
      `Switches on: ${on.join(", ") || "none"}`,
      `Choices changed: ${picked.join(", ") || "none"}`,
      `Text settings filled in, text left out: ${filled.join(", ") || "none"}`
    ];
  }
  var freshSalt = () => {
    const words = new Uint32Array(2);
    try {
      globalThis.crypto.getRandomValues(words);
    } catch {
      words[0] = Math.random() * 2 ** 32;
      words[1] = Math.random() * 2 ** 32;
    }
    return `${words[0].toString(36)}.${words[1].toString(36)}`;
  };
  function buildDiagnosticReport({
    version: version2,
    manager,
    managerVersion,
    mode,
    pageAccess: pageAccess2,
    browser,
    settings,
    unavailable = [],
    hidden = {},
    rows = [],
    decisions = [],
    log = [],
    salt = freshSalt()
  }) {
    const labels = /* @__PURE__ */ new Map();
    const label = (id) => {
      if (id === null || id === void 0 || id === "") return "no id yet";
      if (!labels.has(id)) labels.set(id, postTag(id, salt));
      return labels.get(id);
    };
    const hiddenParts = Object.entries(hidden).filter(([, count]) => COUNT3.test(String(count))).map(([reason, count]) => `${named(reason)} ${count}`);
    const blocked = [...unavailable].map((entry) => Array.isArray(entry) ? `${named(entry[0])} (${named(entry[1])})` : named(entry));
    return [
      `HushFacebook Web ${scrubText(version2, 40)}`,
      `Manager: ${scrubText(`${manager ?? ""} ${managerVersion ?? ""}`, 80) || "none"}, mode ${named(mode)}, page access ${named(pageAccess2)}`,
      `Browser: ${browserOf(browser)}`,
      ...settingLines(settings),
      `Unavailable: ${blocked.join(", ") || "none"}`,
      `Hidden since the page loaded: ${hiddenParts.join(", ") || "None yet"}`,
      ...rows.map(({ label: name, value, shareable }) => {
        const text = String(value ?? "");
        return `${scrubText(name, 80)}: ${shareable || COUNT3.test(text) ? scrubText(text, 200) : "left out"}`;
      }),
      "",
      "Why posts were hidden, oldest first:",
      ...decisions.length ? decisions.map(({ time, layer, id, rule, signal }) => `${String(time ?? "").slice(0, 8)} ${layer === "data" ? "data" : "page"} ${label(id)} ${named(rule)}${signal ? `: ${named(signal)}` : ""}`) : ["nothing yet"],
      "",
      "Log, details left out:",
      ...log.length ? log.slice(-REPORT_LOG_LINES).map(({ time, level, message, code }) => `${String(time ?? "").slice(0, 24)} ${named(level)} ${scrubText(message)}${code ? ` [${named(code)}]` : ""}`) : ["nothing yet"]
    ].join("\n");
  }

  // src/ui/problem-report.js
  var PROBLEM_REPORT_URL = "https://github.com/SysAdminDoc/HushFacebookWeb/issues/new";
  var MAX_PROBLEM_BODY_LENGTH = 6e3;
  var oneLine2 = (value) => String(value ?? "").replace(/[\r\n\t]+/g, " ").replace(/\s+/g, " ").trim();
  var withoutAccountIds = (value) => value.replace(/\d{6,}/g, "[private number]");
  var shorten2 = (value, maxLength) => {
    const text = oneLine2(value);
    if (text.length <= maxLength) return text;
    const marker = " [shortened]";
    return `${text.slice(0, Math.max(0, maxLength - marker.length)).trimEnd()}${marker}`;
  };
  function cappedBody(details, footer, maxLength) {
    const safeDetails = withoutAccountIds(details);
    const safeFooter = withoutAccountIds(footer);
    if (safeDetails.length + safeFooter.length <= maxLength) return safeDetails + safeFooter;
    const marker = "\n[details shortened]";
    const available = Math.max(0, maxLength - safeFooter.length - marker.length);
    return `${safeDetails.slice(0, available).trimEnd()}${marker}${safeFooter}`;
  }
  function buildProblemReport({ version: version2, browser, manager, managerVersion, features: features2, settings, maxBodyLength = MAX_PROBLEM_BODY_LENGTH }) {
    const switches = settings.schema?.[Symbol.iterator] ? [...settings.schema] : features2.map((feature) => [feature.id, { type: "toggle", label: feature.title, featureId: feature.id }]);
    const enabled = switches.filter(([key, spec]) => spec.type === "toggle" && settings.get(key) === true).map(([, spec]) => `- ${oneLine2(spec.label)}`);
    const details = [
      `HushFacebook Web: ${shorten2(version2, 80)}`,
      `Browser: ${shorten2(browser, 500)}`,
      `Userscript manager: ${shorten2(manager, 120)} ${shorten2(managerVersion, 80)}`.trimEnd(),
      "",
      "Enabled switches:",
      ...enabled.length ? enabled : ["- None"]
    ].join("\n");
    const footer = "\n\nWhat happened:\n\n\nWhat I expected:\n";
    const body = cappedBody(details, footer, maxBodyLength);
    const title = `HushFacebook Web ${oneLine2(version2)} problem`;
    const url2 = new URL(PROBLEM_REPORT_URL);
    url2.searchParams.set("title", title);
    url2.searchParams.set("body", body);
    return { title, body, url: url2.toString() };
  }

  // src/ui/quick-setups.js
  var QUICK_SETUPS = Object.freeze([
    Object.freeze({
      id: "quiet",
      label: "Quiet",
      keys: Object.freeze([
        "hideSponsoredPosts",
        "hideSuggestedPosts",
        "hideReelsInFeed",
        "hideStoriesTray",
        "hideAiPosts",
        "hideFollowButtons",
        "hideSponsoredReels",
        "cleanUpReels",
        "hideSponsoredSearch",
        "hideSponsoredMarketplace",
        "hideNotificationKinds",
        "hideCommentStickers",
        "hideTabs",
        "hideTabBadges",
        "hideMenuPromotions",
        "hideMetaUpsells",
        "hidePromotions"
      ])
    }),
    Object.freeze({
      id: "privacy",
      label: "Privacy",
      keys: Object.freeze([
        "noWatchHistory",
        "noSearchHistory",
        "anonymousStories",
        "hideReadReceipts",
        "hideTyping",
        "hideCommentTyping",
        "tagsAfterAt",
        "holdBackLogs",
        "sanitizeLinks",
        "directLinks"
      ])
    }),
    Object.freeze({ id: "defaults", label: "Back to defaults", reset: true })
  ]);
  function applyQuickSetup(settings, id) {
    const setup = QUICK_SETUPS.find((entry) => entry.id === id);
    if (!setup) throw new Error(`Unknown Quick setup: ${id}`);
    const afterSave = (saved, changed2) => saved && typeof saved.then === "function" ? saved.then(() => changed2) : changed2;
    if (setup.reset) {
      const changed2 = [...settings.schema].filter(([key, spec]) => !KEPT_ON_RESET.includes(key) && (settings.get(key) !== spec.default || (settings.display?.(key) ?? settings.get(key)) !== spec.default)).length;
      const pending = settings.saveStatus?.().pending.length ?? 0;
      return changed2 || pending ? afterSave(settings.reset(), changed2) : 0;
    }
    for (const key of setup.keys) {
      if (settings.schema.get(key)?.type !== "toggle") throw new Error(`Quick setup has an unknown switch: ${key}`);
    }
    const changed = setup.keys.filter((key) => settings.get(key) !== true || (settings.display?.(key) ?? settings.get(key)) !== true);
    if (!changed.length) return 0;
    return afterSave(settings.setMany(Object.fromEntries(changed.map((key) => [key, true]))), changed.length);
  }

  // src/ui/search.js
  var fold2 = (text) => String(text ?? "").toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g, "").replace(/[-‐‑‒–—'’]/g, "").replace(/[^\p{L}\p{N}]+/gu, " ").replace(/\s+/g, " ").trim();
  var wordsOf2 = (query) => fold2(query).split(" ").filter(Boolean);
  var both = (text, vars) => {
    if (typeof text !== "string" || !text) return [];
    const plain = english(text, vars);
    const shown4 = t(text, vars);
    return shown4 === plain ? [plain] : [shown4, plain];
  };
  var optionText = (option) => [option.label, ...option.keywords ?? []].flatMap((text) => both(text));
  function searchText(feature, sections) {
    const section2 = sections.find((entry) => entry.id === feature.section)?.title ?? "";
    const options = (feature.options ?? []).flatMap((option) => [...optionText(option), ...(option.choices ?? []).flatMap((choice) => both(choice.label))]);
    const own = [feature.title, feature.description].flatMap((text) => both(text, feature.vars));
    return fold2([...own, ...both(section2), ...(feature.keywords ?? []).flatMap((text) => both(text)), ...options].join(" "));
  }
  function findFeatures(features2, sections, query) {
    const words = wordsOf2(query);
    if (!words.length) return [];
    return features2.filter((feature) => {
      const text = searchText(feature, sections);
      return words.every((word) => text.includes(word));
    });
  }
  function matchingAction(setting, query) {
    const words = wordsOf2(query);
    if (!words.length) return null;
    const option = (setting.options ?? []).find((entry) => {
      if (!entry.focusKey) return false;
      const text = fold2(optionText(entry).join(" "));
      return words.every((word) => text.includes(word));
    });
    return option?.focusKey ?? null;
  }

  // src/ui/panel.js
  var ALWAYS_OPENS = TARGET === "extension" ? "The extension's toolbar button" : "Your userscript manager's menu";
  var ERROR_TOAST_GAP_MS = 15e3;
  var KOFI_URL = "https://ko-fi.com/X8K126YVER";
  var RELOAD_MARKER_KEY = "hfw:settings-reload";
  var RELOAD_MARKER_MAX_AGE_MS = 9e4;
  var SECTION_DESCRIPTIONS = {
    feed: "Choose what makes it into your feed.",
    reels: "Make video time your own.",
    stories: "Watch stories at your own pace.",
    comments: "Read the conversation your way.",
    search: "Keep the results you came for.",
    marketplace: "A clearer place to buy and sell.",
    chats: "Choose what your conversations share.",
    notifications: "Keep the updates that matter to you.",
    privacy: "Choose what Facebook gets to know.",
    links: "Cleaner links, fewer detours.",
    downloads: "Save the moments you want to keep.",
    playback: "More control over every video.",
    appearance: "Make Facebook feel like yours.",
    menu: "Keep your menu focused.",
    meta: "Less promotion, more room for you.",
    opening: "Start where you want to be.",
    general: "Settings for HushFacebook Web.",
    diagnostics: "See how HushFacebook Web is running."
  };
  var UNAVAILABLE_NOTES = {
    page: "This one has to run in Facebook's page, and your userscript manager runs the script outside it. Diagnostics says how to change that.",
    api: "Your browser or userscript manager doesn't offer what this one needs.",
    failed: "This one couldn't start on this page, or stopped working. The log in Diagnostics says why."
  };
  var UNAVAILABLE_SHORT = { page: "needs page access", api: "missing from this browser or manager", failed: "see the log" };
  var searchCount = (count) => count === 0 ? t("No setting matches.") : plural(count, "{count} setting matches.", "{count} settings match.");
  var LANGUAGE_NOTE = "The language for these settings and the script's notices. Facebook's own language doesn't change it, and Reset to defaults keeps it. The two tests stretch every phrase or mirror the panel, to show how a translation will fit.";
  var SEARCH_SETTLE_MS = 600;
  function mountPanel({ settings, features: features2, log, hider, diagnostics, actions, unavailable, environment }) {
    const host2 = h("div", { dataset: { hushfacebookWeb: "ui" }, style: "all: initial !important" });
    const shadow = host2.attachShadow({ mode: "closed" });
    const root = h("div", { class: "root" });
    shadow.append(h("style", { text: panelCss }), root);
    const sections = [
      ...SECTIONS.filter((section2) => features2.some((feature) => feature.section === section2.id)),
      { id: "general", title: "General", divider: true },
      { id: "diagnostics", title: "Diagnostics" }
    ];
    let current = sections[0].id;
    let query = "";
    let renderedDirection = null;
    let opener = null;
    const newDots = createNewDots({ storage: environment.storage, features: features2, log });
    const newDot = () => h("span", { class: "new-dot" }, h("span", { class: "visually-hidden", text: t("New") }));
    const drafts = /* @__PURE__ */ new Map();
    const fieldErrors = /* @__PURE__ */ new Map();
    const pending = /* @__PURE__ */ new Set();
    let preferenceSave = settings.saveStatus?.() ?? { state: "idle", error: null, pending: [] };
    const quickSetupPending = () => [...pending].some((key) => key.startsWith("quick:"));
    const settingValue = (key) => settings.display?.(key) ?? settings.get(key);
    const hasMenuEntry = features2.some((feature) => feature.id === "menuEntry");
    const reloadFeatureIds = new Set(features2.filter((feature) => feature.reload).map((feature) => feature.id));
    const reloadKeys = [...settings.schema].filter(([, spec]) => reloadFeatureIds.has(spec.featureId)).map(([key]) => key);
    let reloadStorage = null;
    try {
      reloadStorage = environment.sessionStorage ?? globalThis.sessionStorage;
    } catch (error) {
      log.warn("Couldn't access reload recovery storage", error);
    }
    const now = environment.now ?? Date.now;
    const reloadPage = environment.reload ?? (() => globalThis.location.reload());
    const reloadValueAtLoad = (key) => settings.pageLoadValue?.(key) ?? settings.get(key);
    let reloadBaseline = new Map(reloadKeys.map((key) => [key, reloadValueAtLoad(key)]));
    let reloadPending = reloadKeys.some((key) => settings.get(key) !== reloadBaseline.get(key));
    let resetUndo = null;
    const accountMatches = () => environment.accountMatches?.() ?? true;
    const recordValue = (record, key) => Object.hasOwn(record, key) ? record[key] : settings.schema.get(key).default;
    const sameAs = (read2, record) => [...settings.schema.keys()].every((key) => JSON.stringify(read2(key)) === JSON.stringify(recordValue(record, key)));
    const currentUndo = () => {
      if (resetUndo && !resetUndo.restoring && !accountMatches()) resetUndo = null;
      return resetUndo;
    };
    const supersedeUndo = () => {
      if (!resetUndo || resetUndo.restoring) return;
      const { previous, after } = resetUndo;
      if (sameAs(settings.get, previous) || !sameAs(settingValue, after) && !sameAs(settingValue, previous)) resetUndo = null;
    };
    const toasts = h("div", { class: "toasts", "aria-live": "polite" });
    const launcher = h("button", { class: "launcher", type: "button", onclick: () => open() }, icon(SLIDERS_ICON));
    const nav = h("nav");
    const main = h("main", { "aria-labelledby": "hfw-section-title" });
    const search = h("input", {
      class: "search",
      type: "search",
      autocomplete: "off",
      spellcheck: "false",
      dataset: { key: "search" },
      oninput: (event) => {
        query = event.target.value;
        main.scrollTop = 0;
        render();
      }
    });
    const searchField = h("div", { class: "search-field" }, navigationIcon("search"), search);
    const pauseState = h("span", { class: "power-state" });
    const saveState = h("span", { class: "save-state", role: "status", dataset: { key: "save-state", state: preferenceSave.state } });
    const searchStatus = h("p", { class: "visually-hidden", role: "status", dataset: { key: "search-status" } });
    let searchStatusTimer = null;
    const power = h("input", {
      class: "switch",
      type: "checkbox",
      role: "switch",
      dataset: { key: "power" },
      // A pause for this tab ends with a reload, since the page started without the script's hooks.
      onchange: (event) => settings.tabPaused && event.target.checked ? environment.resumeTab?.() : apply("paused", !event.target.checked)
    });
    const closeButton = h("button", { class: "icon-button", type: "button", dataset: { key: "close" }, onclick: () => close() }, navigationIcon("close"));
    const subtitle = h("span", { class: "brand-subtitle" });
    const dialog = h(
      "dialog",
      { class: "dialog", "aria-labelledby": "hfw-title" },
      h(
        "header",
        null,
        h(
          "div",
          { class: "brand" },
          h("span", { class: "brand-icon" }, icon(SLIDERS_ICON)),
          h(
            "div",
            { class: "brand-copy" },
            h("h2", { id: "hfw-title", text: "HushFacebook Web" }),
            subtitle
          )
        ),
        searchField,
        h(
          "div",
          { class: "header-actions" },
          h("span", { class: "chip", text: `v${environment.version}` }),
          pauseState,
          power,
          closeButton
        )
      ),
      h("div", { class: "body" }, nav, main),
      h(
        "footer",
        null,
        saveState,
        h("span", { class: "footer-brand", text: "HushFacebook Web" })
      ),
      searchStatus
    );
    dialog.addEventListener("click", (event) => {
      if (event.target !== dialog) return;
      const box2 = dialog.getBoundingClientRect();
      if (event.clientX < box2.left || event.clientX > box2.right || event.clientY < box2.top || event.clientY > box2.bottom) close();
    });
    dialog.addEventListener("close", () => {
      newDots.finish();
      announceSearch("");
      root.append(toasts);
      if (opener?.isConnected && !opener.hidden && opener !== document.body && opener !== document.documentElement) opener.focus({ preventScroll: true });
      else if (!launcher.hidden) launcher.focus({ preventScroll: true });
      opener = null;
    });
    const fileInput = h("input", { type: "file", accept: "application/json,.json", hidden: true, onchange: importSettings });
    dialog.append(fileInput);
    root.append(launcher, dialog, toasts);
    document.body.append(host2);
    function syncLanguage() {
      setLanguage(settingValue("ui.language"));
      const shown4 = language();
      root.setAttribute("lang", shown4.lang);
      root.setAttribute("dir", shown4.dir);
      launcher.setAttribute("aria-label", t("Open HushFacebook Web settings"));
      launcher.title = t("HushFacebook Web settings");
      nav.setAttribute("aria-label", t("Settings sections"));
      search.placeholder = t("Find a setting");
      search.setAttribute("aria-label", t("Find a setting"));
      power.setAttribute("aria-label", t("HushFacebook Web on"));
      closeButton.setAttribute("aria-label", t("Close settings"));
      subtitle.textContent = t("Settings");
    }
    syncLanguage();
    async function apply(key, value, control) {
      if (quickSetupPending()) return;
      const draft = control?.value;
      try {
        if (control && !control.validity.valid) {
          const spec = settings.schema.get(key);
          throw new TypeError(spec.type === "number" ? t("Enter a number from {min} to {max}.", { min: spec.min, max: spec.max }) : t("Check this value and try again."));
        }
        drafts.delete(key);
        fieldErrors.delete(key);
        await settings.set(key, value);
      } catch (error) {
        if (control && error instanceof TypeError) {
          drafts.set(key, draft);
          fieldErrors.set(key, error.message);
        }
        if (!(control && error instanceof TypeError)) log.error("Couldn't save your change. Try again", error);
        refreshChrome();
        if (dialog.open) render();
      }
    }
    function toast(message, { tone = "info", action, actions: actions2 = action ? [action] : [], duration } = {}) {
      const el = h(
        "div",
        { class: `toast ${tone}`, role: tone === "error" ? "alert" : null },
        h("span", { text: typeof message === "function" ? message() : message }),
        actions2.length ? h(
          "div",
          { class: "actions" },
          ...actions2.map((entry) => h("button", { type: "button", text: t(entry.label), onclick: () => {
            if (!entry.keep) el.remove();
            entry.run();
          } }))
        ) : null
      );
      toasts.append(el);
      let hovered = false;
      let focused = false;
      let timer = null;
      const wait = duration ?? (actions2.length ? 7e3 : 4e3);
      const schedule = () => {
        clearTimeout(timer);
        if (Number.isFinite(wait)) timer = setTimeout(() => {
          if (!hovered && !focused) el.remove();
        }, wait);
      };
      el.addEventListener("pointerenter", () => {
        hovered = true;
      });
      el.addEventListener("pointerleave", () => {
        hovered = false;
        schedule();
      });
      el.addEventListener("focusin", () => {
        focused = true;
      });
      el.addEventListener("focusout", (event) => {
        if (el.contains(event.relatedTarget)) return;
        focused = false;
        schedule();
      });
      schedule();
      return {
        dismiss() {
          clearTimeout(timer);
          el.remove();
        }
      };
    }
    function toggle(key, label, { locked = false, describedBy } = {}) {
      const on = settingValue(key) === true;
      const stuck = locked && !on;
      return h("input", {
        class: "switch",
        type: "checkbox",
        role: "switch",
        "aria-label": t(label),
        "aria-describedby": describedBy,
        "aria-disabled": stuck ? "true" : null,
        checked: on,
        disabled: quickSetupPending(),
        dataset: { key },
        onclick: stuck ? (event) => event.preventDefault() : void 0,
        onchange: (event) => apply(key, event.target.checked)
      });
    }
    function optionControl(feature, option, dots) {
      const key = `${feature.id}.${option.key}`;
      const value = drafts.get(key) ?? settingValue(key);
      const errorId = `hfw-error-${key}`;
      const dot = dots && newDots.isNew(key) ? newDot() : null;
      const props = {
        dataset: { key },
        "aria-invalid": fieldErrors.has(key) ? "true" : null,
        "aria-describedby": fieldErrors.has(key) ? errorId : null,
        disabled: quickSetupPending(),
        oninput: (event) => drafts.set(key, event.target.value)
      };
      const field = (control) => h(
        "div",
        { class: "field" },
        h("label", null, dot ? h("span", null, t(option.label), dot) : t(option.label), control),
        fieldErrors.has(key) ? h("p", { class: "field-error", id: errorId, role: "alert", text: fieldErrors.get(key) }) : null
      );
      switch (option.type) {
        case "toggle":
          return h("label", { class: "option-toggle" }, toggle(key, option.label), h("span", null, t(option.label), dot));
        case "select":
          return field(h(
            "select",
            { ...props, onchange: (event) => apply(key, option.choices.find((choice) => String(choice.value) === event.target.value)?.value, event.target) },
            option.choices.map((choice) => h("option", { value: String(choice.value), selected: choice.value === value, text: t(choice.label) }))
          ));
        case "number":
          return field(h("input", { ...props, type: "number", value: String(value), required: true, min: option.min, max: option.max, onchange: (event) => apply(key, Number(event.target.value), event.target) }));
        default:
          if (option.lines === 1) {
            return field(h("input", { ...props, type: "text", value, maxLength: option.maxLength, spellcheck: "false", onchange: (event) => apply(key, event.target.value.trim(), event.target) }));
          }
          return field(
            h("textarea", {
              ...props,
              // Code reads left to right in every language.
              rows: option.rows ?? 3,
              class: option.code ? "code" : void 0,
              spellcheck: option.code ? "false" : void 0,
              dir: option.code ? "ltr" : void 0,
              // The browser stops a paste at the setting's limit, rather than the save failing
              // and the text being lost on the next redraw.
              maxLength: option.maxLength,
              onchange: (event) => apply(key, event.target.value, event.target)
            }, value)
          );
      }
    }
    function featureLinks(feature) {
      const found = actions?.links?.(feature.id);
      if (!found) return null;
      if (!found.items.length) return h("div", { class: "links-empty", dataset: { linksFor: feature.id }, text: t(found.empty) });
      return h("ol", { class: "links", dataset: { linksFor: feature.id } }, found.items.map(({ label, detail, href }) => h(
        "li",
        {},
        h("a", { href, text: label, dir: "auto" }),
        detail ? h("span", { class: "detail", text: detail }) : null
      )));
    }
    function featureActions(feature) {
      const list = actions?.list(feature.id) ?? [];
      if (!list.length) return null;
      return h("div", { class: "actions" }, list.map(({ label, run, index }) => actionButton(`action:${feature.id}:${index}`, label, run)));
    }
    function actionButton(key, label, run, { primary = false, busyLabel = "Working..." } = {}) {
      const locked = quickSetupPending() && !pending.has(key) && key !== "storage:retry";
      return h("button", {
        class: `button${primary ? " primary" : ""}`,
        type: "button",
        text: t(pending.has(key) ? busyLabel : label),
        dataset: { key },
        disabled: locked,
        "aria-disabled": pending.has(key) ? "true" : null,
        "aria-busy": pending.has(key) ? "true" : null,
        onclick: async () => {
          if (pending.has(key)) return;
          pending.add(key);
          render();
          try {
            await run();
          } catch (error) {
            log.error(`${label} failed. Try again`, error);
          } finally {
            pending.delete(key);
            if (dialog.open) render();
          }
        }
      });
    }
    function featureCard(feature, { showOptions = false, dots = false } = {}) {
      const reason = unavailable.get(feature.id);
      const blocked = reason !== void 0;
      const on = settingValue(feature.id) === true;
      const ids = { desc: `hfw-${feature.id}-desc`, note: `hfw-${feature.id}-note`, reload: `hfw-${feature.id}-reload` };
      const describedBy = [ids.desc, blocked ? ids.note : null, feature.reload ? ids.reload : null].filter(Boolean).join(" ");
      const status = on && diagnostics?.hasStatus?.(feature.id) ? diagnostics.statusOf(feature.id) : void 0;
      return h(
        "div",
        { class: `card${blocked ? " unavailable" : ""}` },
        h(
          "div",
          { class: "row" },
          h(
            "div",
            { class: "text" },
            h("div", { class: "title" }, t(feature.title), dots && newDots.featureIsNew(feature) ? newDot() : null),
            h("div", { class: "desc", id: ids.desc, text: t(feature.description) }),
            blocked ? h("div", { class: "note", id: ids.note, text: `${t(UNAVAILABLE_NOTES[reason] ?? UNAVAILABLE_NOTES.failed)}${on ? ` ${t("You can still turn it off.")}` : ""}` }) : null,
            feature.reload ? h("div", { class: "note", id: ids.reload, text: t("Applies after Facebook reloads.") }) : null,
            status === void 0 ? null : h("div", { class: "note", "data-status-for": feature.id, role: "status", hidden: status === null, text: t(status ?? "") })
          ),
          toggle(feature.id, feature.title, { locked: blocked, describedBy })
        ),
        (on || showOptions) && feature.options?.length ? h("div", { class: "options" }, feature.options.map((option) => optionControl(feature, option, dots))) : null,
        on ? featureLinks(feature) : null,
        on ? featureActions(feature) : null
      );
    }
    function sectionView(section2) {
      return features2.filter((feature) => feature.section === section2.id).map((feature) => featureCard(feature, { dots: true }));
    }
    function clearSearch() {
      query = "";
      search.value = "";
    }
    function showSetting(setting) {
      const focusKey = matchingAction(setting, query) ?? setting.focusKey ?? setting.id;
      clearSearch();
      current = setting.section;
      main.scrollTop = 0;
      render();
      const control = main.querySelector(`[data-key="${CSS.escape(focusKey)}"]`);
      control?.scrollIntoView?.({ block: "center" });
      control?.focus({ preventScroll: true });
    }
    function resultsView(found) {
      if (!found.length) return [h("p", { class: "empty", text: t('No setting matches "{query}". Try a shorter word, or pick a section.', { query: query.trim() }) })];
      return [h("div", { class: "settings-group results" }, found.map((setting) => {
        const section2 = sections.find((entry) => entry.id === setting.section);
        return h(
          "div",
          { class: "result" },
          h("button", { class: "result-section", type: "button", text: t("In {section}", { section: t(section2.title) }), dataset: { key: `show:${setting.id}` }, onclick: () => showSetting(setting) }),
          setting.render ? setting.render() : featureCard(setting, { showOptions: true })
        );
      }))];
    }
    const dateLocale = () => language().value === "en" || language().test ? void 0 : language().lang;
    const when = (time) => new Date(time).toLocaleString(dateLocale(), { dateStyle: "medium", timeStyle: "short" });
    function updateLine(status) {
      if (status.checking) return t("Checking GitHub now.");
      const checked = status.checkedAt === null ? "" : t("Checked {time}.", { time: when(status.checkedAt) });
      const lastWorked = status.checkedAt === null ? t("No check has worked yet.") : t("The last one that worked was {time}.", { time: when(status.checkedAt) });
      const tried = status.triedAt === null ? null : { time: when(status.triedAt) };
      const again = t("It tries again on its own.");
      if (status.state === "current") return `${t("You have the newest release.")} ${checked}`.trim();
      if (status.state === "newer") return checked;
      if (status.state === "offline") return `${tried ? t("The check on {time} couldn't reach GitHub.", tried) : t("The last check couldn't reach GitHub.")} ${lastWorked} ${again}`;
      if (status.state === "failed") return `${tried ? t("GitHub's answer to the check on {time} didn't make sense.", tried) : t("GitHub's answer to the last check didn't make sense.")} ${lastWorked} ${again}`;
      if (status.state === "rate-limited") {
        const until = status.nextAt === null ? t("GitHub asked for a pause before the next check.") : t("GitHub asked for a pause, so the next check waits until {time}.", { time: when(status.nextAt) });
        return `${until} ${lastWorked}`;
      }
      return t("No check has finished for this version yet. It checks GitHub once a day.");
    }
    async function checkForUpdateNow() {
      const answer = await environment.checkForUpdate();
      if (answer?.asked !== false) return;
      const status = environment.update?.();
      toast(status?.state === "rate-limited" && status.nextAt > Date.now() ? t("GitHub asked for a pause. The next check is after {time}.", { time: when(status.nextAt) }) : t("It checked a moment ago. Try again in a couple of minutes."));
    }
    function updateCard(status = environment.update?.()) {
      if (!status) return null;
      const { update } = status;
      const line = updateLine(status);
      return h(
        "div",
        { class: "card", dataset: { key: "update" } },
        h("div", { class: "title", text: update ? t("HushFacebook Web {version} is out", { version: update.version }) : t("Updates") }),
        update ? h("div", { class: "desc", text: t("You have {version}. Download hushfacebook-web-extension.zip from the release and unzip it over the folder you loaded. Then click Reload on HushFacebook Web in your browser's extensions page. Your settings stay.", { version: environment.version }) }) : null,
        line ? h("div", { class: "desc", text: line, dataset: { key: "update:status" } }) : null,
        h(
          "div",
          { class: "actions" },
          update ? h("a", { class: "button primary", href: update.url, target: "_blank", rel: "noopener noreferrer", text: t("Open the release") }) : null,
          environment.checkForUpdate ? actionButton("update:check", "Check now", checkForUpdateNow, { primary: !update, busyLabel: "Checking..." }) : null
        )
      );
    }
    function updateRow(status) {
      const check = environment.checkForUpdate ? [{ label: "Check now", focusKey: "update:check" }] : [];
      if (status.update) {
        return {
          id: "update",
          section: "general",
          title: "HushFacebook Web {version} is out",
          description: "You have {current}. Download the new extension files, then reload HushFacebook Web in your browser.",
          vars: { version: status.update.version, current: environment.version },
          options: [{ label: "Open the release" }, ...check],
          focusKey: "update",
          render: () => updateCard(status)
        };
      }
      return {
        id: "update",
        section: "general",
        title: "Updates",
        description: "The extension checks GitHub for a newer release once a day. Check now asks right away.",
        options: check,
        focusKey: check.length ? "update:check" : "update",
        render: () => updateCard(status)
      };
    }
    function reloadCard() {
      return h(
        "div",
        { class: "reload-card", dataset: { key: "reload-facebook" } },
        h(
          "div",
          { class: "text" },
          h("div", { class: "title", text: t("Reload Facebook to apply this change") })
        ),
        h("button", { class: "button primary", type: "button", text: t("Reload"), onclick: reloadFacebook })
      );
    }
    function applySetup(id) {
      const key = `quick:${id}`;
      if (quickSetupPending()) return;
      pending.add(key);
      render();
      settings.whenLoaded(() => {
        const finish = () => {
          pending.delete(key);
          if (dialog.open) render();
        };
        const succeeded = (changed) => {
          if (id === "defaults") {
            drafts.clear();
            fieldErrors.clear();
            render();
          }
          toast(plural(changed, "Changed {count} setting", "Changed {count} settings"));
        };
        const failed = (error) => log.error("Couldn't apply the Quick setup. Try again", error);
        try {
          const result = applyQuickSetup(settings, id);
          if (result && typeof result.then === "function") {
            result.then(succeeded, failed).finally(finish);
          } else {
            succeeded(result);
            finish();
          }
        } catch (error) {
          failed(error);
          finish();
        }
      });
    }
    function quickSetupsCard() {
      return h(
        "div",
        { class: "card", dataset: { key: "quick-setups" } },
        h("div", { class: "title", text: t("Quick setups") }),
        h("div", { class: "desc", text: t("Turn on a tested group of cleanup or privacy switches, or put every setting back to its default.") }),
        h("div", { class: "actions" }, QUICK_SETUPS.map((setup) => {
          const key = `quick:${setup.id}`;
          return h("button", {
            class: "button",
            type: "button",
            text: t(pending.has(key) ? "Waiting..." : setup.label),
            dataset: { key },
            disabled: quickSetupPending(),
            "aria-busy": pending.has(key) ? "true" : null,
            onclick: () => applySetup(setup.id)
          });
        }))
      );
    }
    function launcherCard() {
      return h(
        "div",
        { class: "card" },
        h(
          "div",
          { class: "row" },
          h(
            "div",
            { class: "text" },
            h("div", { class: "title", text: t("Show the settings button") }),
            h("div", { class: "desc", id: "hfw-ui.launcher-desc", text: t("The sliders button in Facebook's bottom-left corner. {opener} always opens settings too, and so does the row in your account menu while Settings in your account menu is on.", { opener: t(ALWAYS_OPENS) }) })
          ),
          toggle("ui.launcher", "Show the settings button", { describedBy: "hfw-ui.launcher-desc" })
        )
      );
    }
    function hiddenNoteCard() {
      return h(
        "div",
        { class: "card" },
        h(
          "div",
          { class: "row" },
          h(
            "div",
            { class: "text" },
            h("div", { class: "title", text: t("Leave a note where a post was hidden") }),
            h("div", { class: "desc", id: "hfw-ui.hiddenNote-desc", text: t("A short line that says why a post was hidden. Click it to see the post.") })
          ),
          toggle("ui.hiddenNote", "Leave a note where a post was hidden", { describedBy: "hfw-ui.hiddenNote-desc" })
        )
      );
    }
    function languageCard() {
      const value = settingValue("ui.language");
      const title = t("Language");
      return h(
        "div",
        { class: "card", dataset: { key: "language" } },
        h("div", { class: "title", text: title === "Language" ? title : `${title} (Language)` }),
        h("div", { class: "desc", id: "hfw-ui.language-desc", text: t(LANGUAGE_NOTE) }),
        h(
          "div",
          { class: "options" },
          h(
            "div",
            { class: "field" },
            h(
              "label",
              null,
              title,
              h("select", {
                dataset: { key: "ui.language" },
                "aria-describedby": "hfw-ui.language-desc",
                disabled: quickSetupPending(),
                onchange: (event) => apply("ui.language", event.target.value, event.target)
              }, LANGUAGES.map((entry) => h("option", { value: entry.value, lang: entry.lang, selected: entry.value === value, text: entry.label })))
            )
          )
        )
      );
    }
    function backupCard() {
      return h(
        "div",
        { class: "card", dataset: { key: "backup-restore" } },
        h("div", { class: "title", text: t("Back up and restore") }),
        h("div", { class: "desc", text: t("Save your choices to a file and load them in another browser, or move them between the userscript and the extension. Seen posts, video spots, speed and volume stay behind.") }),
        h(
          "div",
          { class: "actions" },
          h("button", { class: "button primary", type: "button", text: t("Back up settings"), dataset: { key: "backup" }, disabled: quickSetupPending(), onclick: exportSettings }),
          actionButton("restore", "Restore from a file", () => fileInput.click(), { busyLabel: "Restoring..." }),
          actionButton("reset", "Reset to defaults", resetSettings, { busyLabel: "Resetting..." })
        )
      );
    }
    function reportProblemCard() {
      const report = buildProblemReport({
        version: environment.version,
        browser: document.defaultView?.navigator?.userAgent ?? navigator.userAgent,
        manager: environment.manager,
        managerVersion: environment.managerVersion,
        features: features2,
        settings
      });
      return h(
        "a",
        { class: "card link-card", href: report.url, target: "_blank", rel: "noopener noreferrer", dataset: { key: "report-problem" } },
        h("div", { class: "title", text: t("Report a problem") }),
        h("div", { class: "desc", text: t("Opens a GitHub report with your versions and settings filled in. Add what happened.") })
      );
    }
    function kofiCard() {
      return h(
        "a",
        { class: "card link-card", href: KOFI_URL, target: "_blank", rel: "noopener", dataset: { key: "kofi" } },
        h("div", { class: "title", text: t("Buy me a coffee") }),
        h("div", { class: "desc", text: t("Hush is free. A coffee on Ko-fi helps me keep testing patches.") })
      );
    }
    function storageRecoveryCard(state) {
      const loading = state === "loading";
      return h(
        "div",
        { class: "card", dataset: { key: "storage-recovery" } },
        h("div", { class: "title", text: t(loading ? "Loading saved settings" : "Saved settings aren't available") }),
        h("div", { class: "desc", text: t(loading ? "Recognized privacy requests wait while the extension confirms your saved choices." : "Privacy choices aren't confirmed. Recognized requests are held back until you retry the connection.") }),
        loading ? null : h("div", { class: "actions" }, actionButton("storage:retry", "Retry", async () => {
          const loaded = await environment.storage.retry();
          if (!loaded) throw environment.storage.status().error ?? new Error("Saved settings still aren't available");
          toast(t("Saved settings loaded."));
        }, { primary: true, busyLabel: "Retrying..." }))
      );
    }
    function saveRecoveryCard() {
      return h(
        "div",
        { class: "card save-recovery", dataset: { key: "save-recovery" } },
        h("div", { class: "title", text: t("Changes couldn't be saved") }),
        h("div", { class: "desc", text: t("Your latest choices are still shown here. Retry to save them without losing the draft.") }),
        h("div", { class: "actions" }, actionButton("settings:retry", "Retry", async () => {
          await settings.retry();
          toast(t("Changes saved."));
        }, { primary: true, busyLabel: "Retrying..." }))
      );
    }
    function resetUndoCard() {
      return h(
        "div",
        { class: "card reset-undo", dataset: { key: "reset-undo" } },
        h("div", { class: "title", text: t("Settings were reset") }),
        h("div", { class: "desc", text: t("Undo puts back the choices you had before the reset. It stays here until you dismiss it or change a setting, and it's gone once you leave or reload this page.") }),
        h(
          "div",
          { class: "actions" },
          actionButton("reset:undo", "Undo reset", undoReset, { primary: true, busyLabel: "Undoing..." }),
          h("button", { class: "button", type: "button", text: t("Dismiss"), dataset: { key: "reset:dismiss" }, disabled: pending.has("reset:undo"), onclick: dismissUndo })
        )
      );
    }
    function legacyActivityCard(found) {
      const activity = environment.activity;
      const parts = [
        found.seen ? plural(found.seen, "{count} seen post", "{count} seen posts") : null,
        found.spots ? plural(found.spots, "{count} video spot", "{count} video spots") : null,
        found.speed ? t("a kept video speed") : null,
        found.volume ? t("a kept volume") : null
      ].filter(Boolean);
      const list = parts.length > 1 ? t("{list} and {last}", { list: parts.slice(0, -1).join(", "), last: parts.at(-1) }) : parts[0];
      return h(
        "div",
        { class: "card", dataset: { key: "legacy-activity" } },
        h("div", { class: "title", text: t("Activity from before accounts were kept apart") }),
        h("div", { class: "desc", text: activity.perAccount ? t("This browser still has {list} from before each Facebook account kept its own. They aren't tied to any account. Add them to the account you're signed in to, or delete them.", { list }) : t("This browser still has {list} from before each Facebook account kept its own. They aren't tied to any account. Add them to signed-out browsing, or delete them.", { list }) }),
        h(
          "div",
          { class: "actions" },
          actionButton("legacy:add", activity.perAccount ? "Add to this account" : "Use while signed out", () => {
            activity.addLegacy();
            toast(activity.perAccount ? t("Added to the account you're signed in to. The shared copy stays until you delete it.") : t("Added to signed-out browsing. The shared copy stays until you delete it."));
          }, { primary: true, busyLabel: "Adding..." }),
          actionButton("legacy:delete", "Delete them", () => {
            const undo = activity.clearLegacy();
            toast(t("Deleted the activity from before accounts were kept apart."), { action: { label: "Undo", run: () => {
              undo();
              if (dialog.open) render();
            } } });
          }, { busyLabel: "Deleting..." })
        )
      );
    }
    function generalRows() {
      const update = environment.update?.();
      const storageState = environment.storage?.status?.().state;
      const legacy = environment.activity?.check() ? environment.activity.legacy() : null;
      return [
        // Titles, descriptions and labels in English, as in a feature (see updateRow).
        ...storageState && storageState !== "ready" ? [{
          id: "storage-recovery",
          section: "general",
          title: storageState === "loading" ? "Loading saved settings" : "Saved settings aren't available",
          description: "Retry extension storage without treating defaults as loaded choices.",
          options: [{ label: "Retry" }],
          focusKey: "storage:retry",
          render: () => storageRecoveryCard(environment.storage.status().state)
        }] : [],
        ...preferenceSave.state === "error" ? [{
          id: "save-recovery",
          section: "general",
          title: "Changes couldn't be saved",
          description: "Retry unsaved choices without losing the draft.",
          options: [{ label: "Retry" }],
          focusKey: "settings:retry",
          render: saveRecoveryCard
        }] : [],
        ...currentUndo() ? [{
          id: "reset-undo",
          section: "general",
          title: "Undo the settings reset",
          description: "Put back the choices you had before the reset, until you change a setting or leave this page.",
          options: [{ label: "Undo reset", focusKey: "reset:undo" }, { label: "Dismiss", focusKey: "reset:dismiss" }],
          focusKey: "reset:undo",
          render: resetUndoCard
        }] : [],
        ...update?.update ? [updateRow(update)] : [],
        ...legacy ? [{
          id: "legacy-activity",
          section: "general",
          title: "Activity from before accounts were kept apart",
          description: environment.activity.perAccount ? "Seen posts and video spots shared by everyone on this browser. Add them to this account or delete them." : "Seen posts and video spots shared by everyone on this browser. Use them while signed out or delete them.",
          options: [{ label: environment.activity.perAccount ? "Add to this account" : "Use while signed out", focusKey: "legacy:add" }, { label: "Delete them", focusKey: "legacy:delete" }],
          focusKey: "legacy:add",
          render: () => legacyActivityCard(legacy)
        }] : [],
        { id: "quick-setups", section: "general", title: "Quick setups", description: "Turn on a tested group of cleanup or privacy switches, or put every setting back to its default.", options: QUICK_SETUPS.map((setup) => ({ label: setup.label, focusKey: `quick:${setup.id}`, keywords: setup.reset ? ["reset"] : [] })), focusKey: "quick:quiet", render: quickSetupsCard },
        { id: "ui.launcher", section: "general", title: "Show the settings button", description: "The sliders button in Facebook's bottom-left corner. {opener} always opens settings too.", vars: { opener: t(ALWAYS_OPENS) }, render: launcherCard },
        { id: "ui.hiddenNote", section: "general", title: "Leave a note where a post was hidden", description: "A short line that says why a post was hidden. Click it to see the post.", render: hiddenNoteCard },
        { id: "ui.language", section: "general", title: "Language", description: LANGUAGE_NOTE, options: LANGUAGES.map((entry) => ({ label: entry.label })), keywords: ["translation", "locale", "right to left"], focusKey: "ui.language", render: languageCard },
        {
          id: "backup-restore",
          section: "general",
          title: "Back up and restore",
          description: "Save your choices to a file, restore them, or reset every setting.",
          options: [
            { label: "Back up settings", focusKey: "backup", keywords: ["backup", "export"] },
            { label: "Restore from a file", focusKey: "restore", keywords: ["import", "load"] },
            { label: "Reset to defaults", focusKey: "reset" }
          ],
          focusKey: "backup",
          render: backupCard
        },
        ...update && !update.update ? [updateRow(update)] : [],
        { id: "report-problem", section: "general", title: "Report a problem", description: "Opens a GitHub report with your versions and settings filled in. Add what happened.", keywords: ["bug", "issue"], render: reportProblemCard },
        { id: "kofi", section: "general", title: "Buy me a coffee", description: "Hush is free. A coffee on Ko-fi helps me keep testing patches.", keywords: ["donate"], render: kofiCard }
      ];
    }
    function generalView() {
      return generalRows().map((row) => row.render());
    }
    function hiddenSummary() {
      const counts = Object.entries(hider?.counts() ?? {});
      return counts.length ? counts.map(([reason, count]) => `${reason} ${count}`).join(", ") : t("None yet");
    }
    const featureRows = () => diagnostics?.rows() ?? [];
    const decisions = () => diagnostics?.decisions?.() ?? [];
    function diagnosticsView() {
      const entries = log.entries().slice(-150);
      const blocked = features2.filter((feature) => unavailable.has(feature.id)).map((feature) => `${t(feature.title)} (${t(UNAVAILABLE_SHORT[unavailable.get(feature.id)] ?? UNAVAILABLE_SHORT.failed)})`);
      return [
        h(
          "div",
          { class: "diagnostic-summary" },
          h("h3", { class: "summary-title", text: t("Environment") }),
          h(
            "dl",
            null,
            h("dt", { text: t("Version") }),
            h("dd", { text: environment.version }),
            h("dt", { text: t("Userscript manager") }),
            h("dd", { text: `${environment.manager} ${environment.managerVersion}` }),
            h("dt", { text: t("Injection mode") }),
            h("dd", { text: environment.mode }),
            h("dt", { text: t("Page access") }),
            h("dd", { text: t(environment.pageAccess === "page" ? "Yes" : "No. Network and playback features are off. In Violentmonkey, set this script to inject into the page.") }),
            h("dt", { text: t("Features that didn't start") }),
            h("dd", { text: blocked.length ? blocked.join(", ") : t("None") }),
            h("dt", { text: t("Posts hidden since the page loaded") }),
            h("dd", { text: hiddenSummary() }),
            ...featureRows().flatMap(({ label, value }) => [h("dt", { text: t(label) }), h("dd", { text: value })])
          ),
          h("div", { class: "actions" }, actionButton("copy-report", "Copy report", copyReport, { primary: true, busyLabel: "Copying..." }))
        ),
        h(
          "section",
          { class: "diagnostic-group" },
          h("h3", { class: "subheading", text: t("Why posts were hidden") }),
          h("p", { class: "desc", text: t("The last 50, newest first. data means it came out of Facebook's data before it was drawn, page means it was hidden on the page. Each post has a short tag instead of its id.") }),
          decisions().length ? h("div", { class: "log", dir: "ltr" }, decisions().slice().reverse().map((decision) => h("div", { text: decisionLine(decision) }))) : h("p", { class: "empty", text: t("Nothing hidden yet.") })
        ),
        h(
          "section",
          { class: "diagnostic-group" },
          h("h3", { class: "subheading", text: t("Recent log") }),
          entries.length ? h("div", { class: "log", dir: "ltr" }, entries.map((entry) => h("div", { class: entry.level, text: `${entry.time.slice(11, 19)} ${entry.level.padEnd(5)} ${entry.message}${entry.detail ? `
    ${entry.detail}` : ""}` }))) : h("p", { class: "empty", text: t("Nothing logged yet.") })
        )
      ];
    }
    function pageHeading(id, title, description, count = 0) {
      return h(
        "div",
        { class: "page-heading" },
        h("span", { class: "page-icon", "aria-hidden": "true" }, navigationIcon(id)),
        h(
          "div",
          { class: "page-copy" },
          h("h3", { id: "hfw-section-title", text: title }),
          h("p", { text: description })
        ),
        count ? h("span", { class: "setting-count", text: plural(count, "{count} setting", "{count} settings") }) : null
      );
    }
    function render() {
      const direction = root.getAttribute("dir");
      const directionChanged = renderedDirection !== null && renderedDirection !== direction;
      renderedDirection = direction;
      const focused = shadow.activeElement;
      const focusedKey = focused?.dataset?.key;
      const selection = typeof focused?.selectionStart === "number" ? [focused.selectionStart, focused.selectionEnd] : null;
      const scrollTop = main.scrollTop;
      const navScroll = [nav.scrollLeft, nav.scrollTop];
      const searching = query.trim() !== "";
      power.disabled = quickSetupPending();
      nav.replaceChildren(h("div", { class: "nav-label", text: t("Settings") }), ...sections.flatMap((section2) => [
        section2.divider ? h("hr") : null,
        h("button", {
          type: "button",
          dataset: { key: `nav:${section2.id}` },
          "aria-current": !searching && section2.id === current ? "page" : null,
          onclick: () => {
            clearSearch();
            current = section2.id;
            main.scrollTop = 0;
            render();
          }
        }, navigationIcon(section2.id), h("span", { text: t(section2.title) }), newDots.sectionIsNew(section2.id) ? newDot() : null)
      ]).filter(Boolean));
      if (searching) {
        const found = findFeatures([...features2, ...generalRows()], sections, query);
        main.replaceChildren(
          pageHeading("search", t("Search"), searchCount(found.length)),
          ...reloadPending ? [reloadCard()] : [],
          ...resultsView(found)
        );
        announceSearch(searchCount(found.length));
      } else {
        announceSearch("");
        newDots.visit(current);
        const section2 = sections.find((entry) => entry.id === current);
        const count = current === "general" ? generalRows().length : features2.filter((feature) => feature.section === current).length;
        main.replaceChildren(
          pageHeading(current, t(section2.title), t(SECTION_DESCRIPTIONS[current] ?? ""), count),
          ...reloadPending ? [reloadCard()] : [],
          ...current === "diagnostics" ? diagnosticsView() : [h("div", { class: "settings-group" }, ...current === "general" ? generalView() : sectionView(section2))]
        );
      }
      main.scrollTop = scrollTop;
      nav.scrollLeft = navScroll[0];
      nav.scrollTop = navScroll[1];
      if (directionChanged) nav.querySelector('[aria-current="page"]')?.scrollIntoView?.({ block: "nearest", inline: "nearest" });
      if (focusedKey) {
        const replacement = root.querySelector(`[data-key="${CSS.escape(focusedKey)}"]`);
        replacement?.focus({ preventScroll: true });
        if (selection && replacement?.setSelectionRange) replacement.setSelectionRange(...selection);
      }
    }
    function announceSearch(text) {
      clearTimeout(searchStatusTimer);
      if (!text) {
        searchStatus.textContent = "";
        return;
      }
      searchStatusTimer = setTimeout(() => {
        if (dialog.open && searchStatus.textContent !== text) searchStatus.textContent = text;
      }, SEARCH_SETTLE_MS);
    }
    function refreshChrome() {
      const paused = settingValue("paused") === true;
      power.checked = !paused;
      pauseState.textContent = t(settings.tabPaused ? "Paused in this tab" : paused ? "Paused" : "On");
      const inMenu = hasMenuEntry && settings.enabled("menuEntry") && settings.get("menuEntry.hideButton") === true && !unavailable.has("menuEntry");
      launcher.hidden = settings.get("ui.launcher") !== true || inMenu;
    }
    function refreshSaveState() {
      saveState.dataset.state = preferenceSave.state;
      saveState.textContent = t(preferenceSave.state === "saving" ? "Saving changes..." : preferenceSave.state === "error" ? "Changes couldn't be saved. Open General to retry." : "Changes apply as you go.");
    }
    function exportSettings() {
      const url2 = URL.createObjectURL(new Blob([settings.exportJson()], { type: "application/json" }));
      const link = h("a", { href: url2, download: `hushfacebook-web-settings-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json` });
      root.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url2), 1e4);
      toast(t("Settings saved to a file."));
    }
    async function importSettings() {
      const file = fileInput.files?.[0];
      fileInput.value = "";
      if (!file) return;
      if (pending.has("import")) return;
      pending.add("import");
      pending.add("restore");
      render();
      try {
        if (file.size > MAX_BACKUP_BYTES) throw new TypeError("Choose a settings file smaller than 1 MB");
        const { applied, skipped } = await settings.importJson(await file.text());
        drafts.clear();
        fieldErrors.clear();
        toast(skipped.length ? plural(applied.length, "Restored {count} setting, and skipped {skipped} this version can't use.", "Restored {count} settings, and skipped {skipped} this version can't use.", { skipped: skipped.length }) : plural(applied.length, "Restored {count} setting.", "Restored {count} settings."));
      } catch (error) {
        log.error(error instanceof TypeError ? error.message : "Couldn't restore settings. Choose a valid backup and try again", error);
      } finally {
        pending.delete("import");
        pending.delete("restore");
        if (dialog.open) render();
      }
    }
    function resetSettings() {
      const succeeded = (previous) => {
        drafts.clear();
        fieldErrors.clear();
        const after = settings.snapshot();
        if (!sameAs((key) => recordValue(previous, key), after)) resetUndo = { previous, after, restoring: false };
        render();
        if (resetUndo) {
          toast(t("Settings are back to their defaults. Undo stays in General until you change a setting or leave this page."), { action: { label: "Undo", run: startUndo } });
        } else toast(t("Settings are back to their defaults."));
      };
      const saved = settings.reset();
      return saved && typeof saved.then === "function" ? saved.then(succeeded) : succeeded(saved);
    }
    function undoReset() {
      const undo = currentUndo();
      if (!undo) {
        toast(t("Undo isn't available any more. A setting changed, or another Facebook account signed in."));
        if (dialog.open) render();
        return void 0;
      }
      undo.restoring = true;
      return Promise.resolve().then(() => settings.restore(undo.previous)).then(
        () => {
          undo.restoring = false;
          if (resetUndo === undo) resetUndo = null;
          toast(t("Your settings from before the reset are back."));
          if (dialog.open) {
            render();
            root.querySelector('[data-key="reset"]')?.focus({ preventScroll: true });
          }
        },
        (error) => {
          undo.restoring = false;
          log.error("Couldn't undo the settings reset. Undo is still in General", error);
        }
      );
    }
    function startUndo() {
      if (pending.has("reset:undo")) return;
      pending.add("reset:undo");
      if (dialog.open) render();
      Promise.resolve(undoReset()).finally(() => {
        pending.delete("reset:undo");
        if (dialog.open) render();
      });
    }
    function dismissUndo() {
      resetUndo = null;
      render();
      root.querySelector('[data-key="reset"]')?.focus({ preventScroll: true });
      toast(t("Undo dismissed."));
    }
    function reloadFacebook() {
      const timestamp = now();
      const searchQuery = query.trim();
      const marker = searchQuery ? { page: "find", section: current, query, timestamp } : { page: current, timestamp };
      try {
        reloadStorage?.setItem(RELOAD_MARKER_KEY, JSON.stringify(marker));
      } catch (error) {
        log.warn("Couldn't remember which settings page to reopen", error);
      }
      reloadPage();
    }
    function reopenAfterReload() {
      if (!reloadStorage) return;
      let marker;
      try {
        const saved = reloadStorage.getItem(RELOAD_MARKER_KEY);
        if (saved === null) return;
        reloadStorage.removeItem(RELOAD_MARKER_KEY);
        marker = JSON.parse(saved);
      } catch (error) {
        log.warn("Couldn't reopen settings after the reload", error);
        return;
      }
      if (typeof marker?.timestamp !== "number" || !Number.isFinite(marker.timestamp)) return;
      const age = now() - marker.timestamp;
      if (age < 0 || age >= RELOAD_MARKER_MAX_AGE_MS) return;
      if (marker.page === "find") {
        const validSection = sections.some((section2) => section2.id === marker.section);
        if (validSection && typeof marker.query === "string" && marker.query.trim()) open(marker.section, marker.query);
        return;
      }
      if (sections.some((section2) => section2.id === marker.page)) open(marker.page);
    }
    async function copyReport() {
      const report = buildDiagnosticReport({
        version: environment.version,
        manager: environment.manager,
        managerVersion: environment.managerVersion,
        mode: environment.mode,
        pageAccess: environment.pageAccess,
        browser: navigator.userAgent,
        settings,
        unavailable,
        hidden: hider?.counts() ?? {},
        rows: featureRows(),
        decisions: decisions(),
        log: log.entries()
      });
      try {
        await navigator.clipboard.writeText(report);
        toast(t("Report copied. Paste it into a GitHub issue."));
      } catch (error) {
        log.error("Couldn't copy the report", error);
      }
    }
    function open(sectionId, searchQuery) {
      if (sectionId && sections.some((section2) => section2.id === sectionId)) {
        if (sectionId !== current || query) main.scrollTop = 0;
        current = sectionId;
        if (typeof searchQuery === "string" && searchQuery.trim()) {
          query = searchQuery;
          search.value = searchQuery;
        } else {
          clearSearch();
        }
      }
      if (!dialog.open) {
        opener = shadow.activeElement ?? document.activeElement;
        newDots.start();
      }
      render();
      dialog.append(toasts);
      if (!dialog.open) dialog.showModal();
      closeButton.focus({ preventScroll: true });
    }
    function close() {
      dialog.close();
    }
    settings.subscribe(() => {
      supersedeUndo();
      syncLanguage();
      refreshSaveState();
      refreshChrome();
      reloadPending = reloadKeys.some((key) => settings.get(key) !== reloadBaseline.get(key));
      if (dialog.open) render();
    });
    settings.whenLoaded(() => {
      syncLanguage();
      refreshSaveState();
      refreshChrome();
      reloadBaseline = new Map(reloadKeys.map((key) => [key, reloadValueAtLoad(key)]));
      reloadPending = reloadKeys.some((key) => settings.get(key) !== reloadBaseline.get(key));
      if (dialog.open) render();
    });
    settings.onSaveStatus?.((status) => {
      preferenceSave = status;
      supersedeUndo();
      refreshSaveState();
      refreshChrome();
      if (dialog.open) render();
    });
    let lastErrorToast = 0;
    const announceError = (entry) => {
      if (Date.now() - lastErrorToast < ERROR_TOAST_GAP_MS) return;
      lastErrorToast = Date.now();
      toast(t("{message}. Details are in Diagnostics.", { message: t(entry.message) }), { tone: "error", action: { label: "Open", run: () => open("diagnostics") } });
    };
    let renderQueued = false;
    let statusQueued = false;
    const refreshStatuses = () => {
      if (!dialog.open || statusQueued || !root.querySelector("[data-status-for]")) return;
      statusQueued = true;
      requestAnimationFrame(() => {
        statusQueued = false;
        for (const node of root.querySelectorAll("[data-status-for]")) {
          const text = t(diagnostics.statusOf(node.getAttribute("data-status-for")) ?? "");
          node.hidden = text === "";
          if (node.textContent !== text) node.textContent = text;
        }
      });
    };
    const refreshDiagnostics = () => {
      refreshStatuses();
      if (!dialog.open || current !== "diagnostics" || renderQueued) return;
      renderQueued = true;
      requestAnimationFrame(() => {
        renderQueued = false;
        if (dialog.open && current === "diagnostics") render();
      });
    };
    log.subscribe((entry) => {
      if (entry.level === "error") announceError(entry);
      refreshDiagnostics();
    });
    hider?.subscribe(refreshDiagnostics);
    diagnostics?.subscribe(refreshDiagnostics);
    environment.storage?.onStatus?.(() => {
      if (dialog.open) render();
    });
    const earlier = log.entries().findLast((entry) => entry.level === "error");
    if (earlier) announceError(earlier);
    refreshSaveState();
    refreshChrome();
    const refresh = () => {
      refreshChrome();
      if (dialog.open) render();
    };
    reopenAfterReload();
    return { open, close, toast, refresh, copyReport };
  }

  // src/boot.js
  var DUPLICATE = "data-hushfacebook-web-duplicate";
  function signedInAccount(doc) {
    try {
      return accountFromCookie(doc.cookie);
    } catch {
      return null;
    }
  }
  function boot({ win, doc, access, own = globalThis, features: features2 = features }) {
    keepKeysInPanel(win);
    const log = createLog();
    const storage = createGmStorage({ log });
    const account = signedInAccount(doc);
    const tabPaused = readTabPause(win);
    const settings = createSettings({ storage, features: features2, log, version, account, tabPaused });
    const followLanguage = () => setLanguage(settings.get("ui.language"));
    settings.whenLoaded(followLanguage);
    settings.subscribe(followLanguage);
    const net = access === "page" && !tabPaused ? installNetworkHooks({
      win,
      log,
      startup: {
        status: settings.startup.status,
        onStatus: settings.startup.onStatus,
        accountMatches: () => settings.startup.matchesAccount(signedInAccount(doc))
      }
    }) : null;
    const router = tabPaused ? null : createRouter({ win, pageAccess: access, log });
    const posts = createPostTracker({ doc, log });
    const diagnostics = createDiagnostics();
    const hider = tabPaused ? null : createHider({
      doc,
      posts,
      log,
      notesShown: () => settings.get("paused") !== true && settings.get("ui.hiddenNote") === true,
      onHide: hideListener(diagnostics, postIdOf)
    });
    if (hider) settings.subscribe(() => hider.refresh());
    const shareable = { shareable: true };
    diagnostics.add("Settings kept for", () => settings.perAccount ? "This Facebook account" : "Everyone on this browser (signed out)", shareable);
    diagnostics.add("Settings kept in", () => ({ gm: "Your userscript manager", extension: "The extension's own storage" })[storage.kind] ?? "Facebook's page, which clears them", shareable);
    if (storage.status) {
      diagnostics.add("Saved settings", () => ({ loading: "Loading", ready: "Loaded", error: "Unavailable. Open General to retry." })[storage.status().state] ?? "Unavailable", shareable);
      diagnostics.add("Startup privacy protection", () => tabPaused ? "Paused in this tab" : {
        loading: "Waiting for saved choices",
        ready: "Confirmed",
        error: "Unconfirmed. Recognized requests are held back. Open General to retry."
      }[net?.startupState?.() ?? settings.startup.status()] ?? "Unconfirmed", shareable);
      storage.onStatus(() => diagnostics.changed());
    }
    if (net) {
      diagnostics.add("Answers too long to filter", () => {
        const count = net.lineStats.oversized;
        return count ? `${count} passed through as Facebook sent ${count === 1 ? "it" : "them"}` : "None in this tab";
      }, shareable);
    }
    const actions = createActions();
    const unavailable = /* @__PURE__ */ new Map();
    let panel = null;
    let pendingSettingsOpen = false;
    let pendingSettingsSection;
    const waiting = [];
    const toast = (message, options) => {
      if (panel) return panel.toast(message, options);
      const entry = { message, options, shown: null, gone: false };
      waiting.push(entry);
      return {
        dismiss() {
          entry.gone = true;
          entry.shown?.dismiss();
        }
      };
    };
    const openSettings = (section2) => whenBodyReady(() => {
      if (panel) panel.open(section2);
      else {
        pendingSettingsOpen = true;
        pendingSettingsSection = section2;
      }
    }, doc);
    installLogoLongPress({ doc, openSettings });
    const activity = createActivityStorage({
      storage,
      account,
      currentAccount: () => signedInAccount(doc),
      log,
      onSwitch: () => {
        panel?.refresh();
        toast(() => `${t(ACCOUNT_CHANGED)}.`, { action: { label: "Reload", run: () => win.location.reload() }, duration: 2e4 });
      }
    });
    activity.watch({ router, doc });
    diagnostics.add("Activity kept for", () => activity.switched() ? "Nobody until you reload, since the account changed" : activity.perAccount ? "This Facebook account" : "This browser while signed out", shareable);
    if (access !== "page") {
      log.warn("Your userscript manager is running HushFacebook Web as a content script, so features that need the page are off. Diagnostics has the details.");
    }
    if (access === "page") keepOutOfStorageReport({ win, log, diagnostics });
    if (!keepsSettings(storage)) {
      log.warn(UNKEPT_SETTINGS);
      toast(() => t(UNKEPT_SETTINGS), { tone: "error" });
    }
    const resumeTab = () => {
      try {
        setTabPause(win, false);
      } catch (error) {
        log.error("Couldn't clear this tab's pause", error);
        toast(() => t("Couldn't turn it back on in this tab. Facebook opened in a new tab runs it as usual."), { tone: "error" });
        return;
      }
      win.location.reload();
    };
    const pauseTab = () => {
      try {
        setTabPause(win, true);
      } catch (error) {
        log.error("Couldn't pause HushFacebook Web for this tab", error);
        toast(() => t("Couldn't pause for this tab. The switch at the top of the settings pauses it everywhere."), { tone: "error" });
        return;
      }
      win.location.reload();
    };
    if (tabPaused) {
      log.info("Paused in this tab, so only the settings panel is running");
      toast(() => t("HushFacebook Web is paused in this tab."), { action: { label: "Turn back on", run: resumeTab }, duration: 1e4 });
      diagnostics.add("Feed load check", () => "Paused in this tab", shareable);
    } else {
      const loads = watchFeedLoads({
        win,
        doc,
        router,
        log,
        signedIn: () => signedInAccount(doc) !== null,
        paused: () => settings.get("paused") === true,
        onStuck: () => {
          diagnostics.changed();
          toast(() => t("Facebook's feed is still loading after {seconds} seconds. If HushFacebook Web is getting in the way, pause it for this tab.", { seconds: LOAD_WAIT_MS / 1e3 }), {
            duration: 6e4,
            actions: [
              { label: "Pause for this tab", run: pauseTab },
              { label: "Copy report", run: () => panel?.copyReport(), keep: true }
            ]
          });
        }
      });
      diagnostics.add("Feed load check", loads.status, shareable);
    }
    if (!tabPaused) {
      startFeatures({
        features: features2,
        net,
        settings,
        log,
        unavailable,
        context: (feature) => ({
          win,
          doc,
          diagnostics,
          actions: actions.for(feature.id),
          storage: activity.storage,
          router,
          posts,
          hider,
          log,
          toast,
          openSettings
        }),
        changed: () => panel?.refresh()
      });
    }
    if (!tabPaused) mountFeatureStyles({ features: features2, settings, log, doc, base: [{ id: "hidden posts", css: (get) => hideCss({ notes: get("ui.hiddenNote") === true }) }] });
    const tasks = createDailyTasks({ storage, log });
    const mirror = pageMirror(own);
    scheduleStorageCheck({ tasks, storage, mirror, log, toast, diagnostics });
    setTimeout(() => whenMirrorReady(mirror, () => tasks.runDue()), 8e3);
    const host2 = storage.kind === "extension" ? extensionHost() : null;
    const update = host2 ? () => updateStatus(storage, version) : null;
    if (update) {
      storage.onChange(UPDATE_KEY, () => panel?.refresh());
      storage.whenReady(() => {
        const found = availableUpdate(storage, version);
        if (!found || storage.get(UPDATE_TOLD_KEY, null) === found.version) return;
        storage.set(UPDATE_TOLD_KEY, found.version);
        toast(() => t("HushFacebook Web {version} is out.", { version: found.version }), { action: { label: "How to update", run: () => whenBodyReady(() => panel?.open("general"), doc) } });
      });
    }
    whenBodyReady(() => {
      panel = mountPanel({
        settings,
        features: features2,
        log,
        hider,
        diagnostics,
        actions,
        unavailable,
        environment: { version, ...managerInfo(), update, resumeTab, checkForUpdate: host2?.checkForUpdate ?? null, storage, activity, accountMatches: () => settings.startup.matchesAccount(signedInAccount(doc)) }
      });
      for (const entry of waiting.splice(0)) {
        if (!entry.gone) entry.shown = panel.toast(entry.message, entry.options);
      }
      if (pendingSettingsOpen) {
        panel.open(pendingSettingsSection);
        pendingSettingsOpen = false;
      }
      const other = doc.documentElement.getAttribute(DUPLICATE);
      const otherVersion = /^\d+(?:\.\d+){0,3}$/.test(other ?? "") ? ` (v${other})` : "";
      if (other) log.warn(`A second copy of HushFacebook Web${otherVersion} is installed. Turn one off in your userscript manager or on the browser's extensions page.`);
    }, doc);
    registerMenuCommand("HushFacebook Web settings", () => openSettings());
    log.info(`v${version} started (${access} mode)`);
    return { net, router, hider, settings, pauseTab, resumeTab };
  }

  // src/main.js
  var RUNNING2 = "data-hushfacebook-web";
  var RUNNING_KEY = /* @__PURE__ */ Symbol.for("hushfacebook-web.running");
  var target = executionTarget(pageWindow);
  if (target === "game") {
    if (pageAccess === "page") {
      const log = createLog();
      startGameFrame({ win: pageWindow, storage: createGmStorage({ log }), log });
    } else console.warn("[HushFacebook Web] Instant Games ad blocking needs the userscript to run in the page.");
  } else if (target === "facebook") {
    const running = pageWindow[RUNNING_KEY] ?? document.documentElement?.getAttribute(RUNNING2);
    if (running) {
      whenRootReady(() => document.documentElement.setAttribute(DUPLICATE, version));
      console.warn(`[HushFacebook Web] v${version} didn't start because v${running} is already running.`);
    } else {
      pageWindow[RUNNING_KEY] = version;
      whenRootReady(() => document.documentElement.setAttribute(RUNNING2, version));
      boot({ win: pageWindow, doc: document, access: pageAccess });
    }
  }
})();
/*! HushFacebook Web: the page-side ad check below follows FB Feed Filter 0.1.0.17
 * (core.js AD_LABEL_KINDS, groupGlyphRecords, candidateGlyphStrings, decodeExactAdLabel,
 * matchesAdDisclosureUrl, isFacebookGroupStoryHref; content.js HEADER_EXCLUSIONS,
 * isHeaderGeometry, glyphRecordsFor, hasScrambledLabelStructure, labelledReferenceLabel,
 * referencedSvgLabel, hasGroupOrigin, hiddenByAncestors).
 *
 * MIT License
 *
 * Copyright (c) 2026 Facebook Feed Filter Companion contributors
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify, merge,
 * publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons
 * to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
 * FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
/*!
RE2JS 2.9.0, https://github.com/le0pard/re2js, bundled unchanged.

MIT License

Copyright (c) 2023 Oleksii Vasyliev

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
/*!
MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
/*! Bundled license information:

re2js/build/index.js:
  (*!
  * re2js
  * RE2JS is the JavaScript port of RE2, a regular expression engine that provides linear time matching
  *
  * @version v2.9.0
  * @author Oleksii Vasyliev
  * @homepage https://github.com/le0pard/re2js#readme
  * @repository [object Object]
  * @license MIT
  *)
*/
