// ==UserScript==
// @name         Vplink Arolink Get Link Clicker
// @namespace    https://github.com/BlazeFTL
// @description  Clicks #get-link after .countdown ends and Cloudflare verification completes on upfilesgo.com
// @version      1.2
// @author       BlazeFTL
// @match        *://arolinks.com/*
// @match        *://*.vplink.*/*
// @license      MIT
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    const retryMs = 2500;
    let lastClicked = 0;

    const isActuallyVisible = (el) => {
        if (!el) return false;
        const style = window.getComputedStyle(el);
        return (
            el.offsetWidth > 0 &&
            el.offsetHeight > 0 &&
            style.visibility !== 'hidden' &&
            style.display !== 'none' &&
            style.opacity !== '0'
        );
    };

    const isClickable = (el) => {
        return el && isActuallyVisible(el) && !el.hasAttribute('disabled') && !el.disabled;
    };

    const forceClick = (el) => {
        ['pointerdown', 'mousedown', 'pointerup', 'mouseup'].forEach(type => {
            el.dispatchEvent(new MouseEvent(type, {
                view: window,
                bubbles: true,
                cancelable: true,
                buttons: 1
            }));
        });
        el.click();

        if (el.tagName === 'A' && el.href && !el.href.includes('#')) {
            window.location.href = el.href;
        }
    };

    const countdownFinished = () => {
        const timers = [...document.querySelectorAll('.countdown')].filter(isActuallyVisible);
        return timers.every(el => {
            const nums = (el.innerText || el.textContent || '').match(/\d+/g);
            return !nums || nums.every(n => parseInt(n, 10) === 0);
        });
    };

    const verified = () => {
        try {
            const input = [...document.querySelectorAll('input[name="cf-turnstile-response"], input[name="h-captcha-response"], textarea[name="g-recaptcha-response"]')]
                .some(i => i.value);
            if (input) return true;

            let api = '';
            try {
                api = (window.turnstile || window.hcaptcha || window.grecaptcha)?.getResponse?.() || '';
            } catch (e) {}
            if (api) return true;

            const xpath = "//div[contains(@class, 'iconcaptcha-modal__body-title') and contains(., 'Verification complete.')] | //*[@id='captcha-result' and contains(., 'Verified!')]";
            const dom = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            return isActuallyVisible(dom);
        } catch (e) {
            return false;
        }
    };

    const findBtn = () => {
        const direct = document.querySelector('#get-link, .get-link.btn');
        if (isClickable(direct)) return direct;
        return [...document.querySelectorAll('a, button')].find(el =>
            /^\s*get\s*link\s*$/i.test(el.textContent) && isClickable(el)
        );
    };

    const logic = () => {
        if (!countdownFinished() || !verified()) return;
        const btn = findBtn();
        if (!btn) return;

        const now = Date.now();
        if (now - lastClicked < retryMs) return;
        lastClicked = now;
        forceClick(btn);
    };

    const wake = () => {
        if (document.hidden) return;
        lastClicked = 0;
        setTimeout(logic, 300);
    };

    setInterval(logic, 500);
    new MutationObserver(logic).observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true
    });
    document.addEventListener('visibilitychange', wake);
    window.addEventListener('focus', wake);

    logic();
})();
