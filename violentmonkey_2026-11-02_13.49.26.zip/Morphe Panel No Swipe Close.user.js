// ==UserScript==
// @name         Morphe Panel No Swipe Close
// @namespace    ftl.morphe-panel-noswipe
// @version      1.0.0
// @description  Stops swipe-down-to-close on the What's New and app detail panels.
// @author       Hyperion
// @match        https://morphe-patches.software/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(() => {
  const types = [
    'touchstart', 'touchmove', 'touchend', 'touchcancel',
    'pointerdown', 'pointermove', 'pointerup', 'pointercancel',
    'mousedown', 'mousemove', 'mouseup'
  ];
  const block = e => {
    const t = e.target;
    if (t && t.closest && t.closest('#app-panel')) e.stopImmediatePropagation();
  };
  for (const type of types) {
    window.addEventListener(type, block, { capture: true, passive: true });
  }
})();
