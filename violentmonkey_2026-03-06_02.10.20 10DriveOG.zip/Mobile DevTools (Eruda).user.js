// ==UserScript==
// @name         Mobile DevTools (Eruda)
// @namespace    https://github.com/BlazeFTL
// @description  Injects Eruda DevTools on every page for mobile debugging.
// @version      1.1
// @author       BlazeFTL
// @match        *://*/*
// @license      MIT
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';
    var script = document.createElement('script');
    script.src = "https://cdn.jsdelivr.net/npm/eruda";
    script.onload = function () {
        eruda.init();
    };
    document.head.appendChild(script);
})();

