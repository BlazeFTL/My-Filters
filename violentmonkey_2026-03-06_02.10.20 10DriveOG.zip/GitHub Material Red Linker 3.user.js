// ==UserScript==
// @name         GitHub Material Red Linker 3
// @namespace    http://tampermonkey.net/
// @version      1.7
// @description  Material design red links. Now ignores code blocks to prevent breaking syntax highlighting.
// @author       BlazeFTL
// @match        https://github.com/uBlockOrigin/uAssets/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const style = document.createElement('style');
    style.innerHTML = `
        .custom-github-link {
            background-color: rgba(207, 34, 46, 0.1);
            color: #cf222e !important;
            padding: 1px 4px;
            margin: 0 1px;
            border-radius: 3px;
            font-weight: 560;
            text-decoration: none !important;
            transition: all 0.1s ease-in-out;
            display: inline-block;
            line-height: 1.2;
            font-family: var(--fontStack-monospace, ui-monospace, SFMono-Regular, SF Mono, Menlo, Consolas, Liberation Mono, monospace);
            font-size: 0.9em;
        }

        .custom-github-link:hover {
            background-color: #cf222e;
            color: #ffffff !important;
            box-shadow: 0 2px 4px rgba(207, 34, 46, 0.2);
        }
    `;
    document.head.appendChild(style);

    // Regex: Matches full URLs or strings that look like domains (e.g., example.com)
    // but requires a "." and a standard TLD to avoid matching variable names like "fetch"
    const urlRegex = /((https?:\/\/[^\s<]+)|([a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/[^\s<]*)?))/gi;

    function linkify() {
        // 1. Target paragraphs (p)
        // 2. Target inline code (code)
        // 3. EXCLUDE anything inside a <pre> block (multi-line code blocks)
        const elements = document.querySelectorAll('.markdown-body p:not([data-linked]), .markdown-body :not(pre) > code.notranslate:not([data-linked])');

        elements.forEach(el => {
            // Safety check: skip if it's inside a code block or already has a link
            if (el.closest('pre') || el.querySelector('a')) return;

            const content = el.textContent.trim();

            // If it's an inline code tag, check if the content IS a URL/Domain
            if (el.tagName === 'CODE') {
                if (urlRegex.test(content) && (content.includes('.') || content.startsWith('http'))) {
                    el.setAttribute('data-linked', 'true');
                    const url = content.startsWith('http') ? content : `https://${content}`;
                    el.innerHTML = `<a href="${url}" target="_blank" class="custom-github-link">${content}</a>`;
                }
            }
            // Handle standard paragraphs
            else if (el.tagName === 'P') {
                el.setAttribute('data-linked', 'true');
                const originalHTML = el.innerHTML;
                const newHTML = originalHTML.replace(urlRegex, (match) => {
                    // Extra validation for plain strings in paragraphs: must have a dot to be a domain
                    if (!match.includes('.') && !match.startsWith('http')) return match;

                    const prefix = match.startsWith('http') ? '' : 'https://';
                    return `<a href="${prefix}${match}" target="_blank" class="custom-github-link">${match}</a>`;
                });

                if (originalHTML !== newHTML) el.innerHTML = newHTML;
            }
        });
    }

    let timeout;
    const debouncedLinkify = () => {
        clearTimeout(timeout);
        timeout = setTimeout(linkify, 300);
    };

    linkify();

    const observer = new MutationObserver(debouncedLinkify);
    observer.observe(document.body, { childList: true, subtree: true });
})();
