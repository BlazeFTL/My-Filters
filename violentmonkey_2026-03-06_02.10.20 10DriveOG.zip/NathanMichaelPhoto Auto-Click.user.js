// ==UserScript==
// @name         NathanMichaelPhoto Auto-Click
// @namespace    https://github.com/BlazeFTL
// @description  Automates the download process by monitoring the xd value, timer, and captcha.
// @version      1.0
// @author       BlazeFTL
// @match        https://nathanmichaelphoto.com/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const checkInterval = setInterval(() => {
        const xdInput = document.getElementById('xd');
        const downloadBtn = document.getElementById('downloadbtn');
        const captchaInput = document.querySelector('.captcha_code');
        const secondsSpan = document.getElementById('seconds');

        // 1. Check if the hidden input "xd" has a value
        const hasToken = xdInput && xdInput.value.trim() !== "";

        // 2. Check if the timer is at 1 second or less
        const timerReady = secondsSpan && parseInt(secondsSpan.innerText) <= 1;

        // 3. Check if user has entered the 4-digit captcha
        const captchaReady = captchaInput && captchaInput.value.length === 4;

        if (hasToken && timerReady && captchaReady && downloadBtn) {
            // Remove disabled attribute if present
            if (downloadBtn.disabled) {
                downloadBtn.disabled = false;
            }

            // Click the button and clear the interval
            downloadBtn.click();
            clearInterval(checkInterval);
        }
    }, 500); // Checks every 500ms
})();

