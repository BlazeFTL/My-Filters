// ==UserScript==
// @name         Mobile DevTools (Eruda Pro)
// @namespace    https://github.com/BlazeFTL
// @description  The most powerful mobile console. Force-injected for Firefox Android.
// @version      1.4
// @author       BlazeFTL
// @match        *://*/*
// @license      MIT
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    function initEruda() {
        const script = document.createElement('script');
        script.src = "https://cdn.jsdelivr.net/npm/eruda";
        script.onload = function () {
            eruda.init();
            // Optional: Auto-open the console for testing
            // eruda.show();
        };
        (document.head || document.documentElement).appendChild(script);
    }

    // Initialize even if the page is still loading
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        initEruda();
    } else {
        window.addEventListener('DOMContentLoaded', initEruda);
    }
})();

