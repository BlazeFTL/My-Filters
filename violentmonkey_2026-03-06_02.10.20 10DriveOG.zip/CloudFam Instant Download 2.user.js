// ==UserScript==
// @name         CloudFam Instant Download 2
// @namespace    https://github.com/BlazeFTL
// @version      1.4
// @description  Redirects from redirection pages to download handler with cookie-settling delay
// @author       BlazeFTL
// @match        https://cloudfam.io/*
// @license      MIT
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    const urlParams = new URLSearchParams(window.location.search);
    const slug = urlParams.get('slug');
    const currentPath = window.location.pathname;

    /**
     * 1. Detect redirection page.
     * Added a 2-second timeout to ensure the page has time to set
     * necessary session cookies before we jump to the handler.
     */
    if (currentPath.includes('redirection') && slug) {
        console.log("Redirection detected. Waiting for cookies to settle...");
        setTimeout(() => {
            const handlerUrl = `https://cloudfam.io/download_handler.php?slug=${slug}`;
            window.location.replace(handlerUrl);
        }, 2000); // 2 second delay for cookie/header validation
        return;
    }

    /**
     * 2. Final Step: Click the download button on step=2.
     * We wait for the button to appear and ensure it's clickable.
     */
    if (window.location.search.includes('step=2')) {
        const attemptClick = () => {
            const btn = document.querySelector('#final-download-btn');
            if (btn) {
                // Optional: Ensure button is visible/enabled before clicking
                if (!btn.disabled) {
                    console.log("Final download button ready. Clicking...");
                    btn.click();
                    clearInterval(autoClicker);
                }
            }
        };

        // Check for the button every 500ms
        const autoClicker = setInterval(attemptClick, 500);

        // Safety timeout: stop looking after 10 seconds
        setTimeout(() => clearInterval(autoClicker), 10000);
    }
})();

