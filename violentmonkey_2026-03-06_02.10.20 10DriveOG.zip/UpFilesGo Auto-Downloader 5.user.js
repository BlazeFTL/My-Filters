// ==UserScript==
// @name         UpFilesGo Auto-Downloader 5
// @namespace    https://github.com/BlazeFTL
// @description  Automates upfilesgo.com - Bypasses "User Gesture" download blocks
// @version      2.0
// @author       BlazeFTL
// @match        *://upfilesgo.com/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let lastClicked = 0;
    const cooldown = 2000;
    let userHasInteracted = false;

    // Listen for the first real click to "unlock" the browser's permission to download
    window.addEventListener('click', () => {
        userHasInteracted = true;
        logic();
    }, { once: true });

    const isActuallyVisible = (el) => {
        if (!el) return false;
        const style = window.getComputedStyle(el);
        return (
            el.offsetWidth > 0 &&
            el.offsetHeight > 0 &&
            style.visibility !== 'hidden' &&
            style.display !== 'none' &&
            style.opacity !== '0'
        );
    };

    const isClickable = (el) => {
        return el && isActuallyVisible(el) && !el.hasAttribute('disabled') && !el.disabled;
    };

    const forceClick = (el) => {
        if (!el) return;
        // Simulating a full mouse sequence
        ['mousedown', 'mouseup', 'click'].forEach(eventType => {
            el.dispatchEvent(new MouseEvent(eventType, {
                view: window,
                bubbles: true,
                cancelable: true,
                buttons: 1,
                isTrusted: true // Note: Browser sets this, but dispatching helps trigger listeners
            }));
        });

        // Final fallback for direct links
        if (el.tagName === 'A' && el.href && !el.href.includes('#')) {
            window.location.href = el.href;
        }
    };

    const safeClick = (el) => {
        const now = Date.now();
        if (isClickable(el) && (now - lastClicked > cooldown)) {
            lastClicked = now;
            forceClick(el);
            return true;
        }
        return false;
    };

    function captchaSolved(callback) {
        let isResolved = false;
        const check = () => {
            if (isResolved) return;
            try {
                const xpath = "//div[contains(@class, 'iconcaptcha-modal__body-title') and contains(., 'Verification complete.')] | //*[@id='captcha-result' and contains(., 'Verified!')]";
                const domCheck = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                const apiCheck = (window.turnstile || window.hcaptcha || window.grecaptcha)?.getResponse?.()?.length > 0;

                if (isActuallyVisible(domCheck) || apiCheck) {
                    isResolved = true;
                    clearInterval(int);
                    callback();
                }
            } catch (e) {}
        };
        const int = setInterval(check, 1000);
    }

    const logic = () => {
        const waitBtn = document.querySelector("#link-button");
        const btn3 = document.querySelector(".my-2.get-link.btn-download.btn-primary.btn");
        const btn2 = document.querySelector(".btn-captcha.btn-primary.btn");
        const btn1 = document.querySelector("#link-button-free");

        // INHIBITOR
        if (waitBtn && isActuallyVisible(waitBtn)) {
            if (waitBtn.innerText.toLowerCase().includes("wait") || waitBtn.hasAttribute('disabled')) {
                return;
            }
        }

        // STEP 3 & 4: Final Link + Forced Countdown Click
        if (isClickable(btn3)) {
            if (safeClick(btn3)) {
                setTimeout(() => {
                    const btn4 = document.querySelector("div");
                    if (btn4) forceClick(btn4);
                }, 1000);
            }
            return;
        }

        // STEP 2: Captcha
        if (isClickable(btn2)) {
            captchaSolved(() => safeClick(btn2));
            return;
        }

        // STEP 1: Initial Button
        if (isClickable(btn1) && !isActuallyVisible(btn2) && !isActuallyVisible(btn3)) {
            safeClick(btn1);
        }
    };

    const observer = new MutationObserver(logic);
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true
    });

    logic();
})();

