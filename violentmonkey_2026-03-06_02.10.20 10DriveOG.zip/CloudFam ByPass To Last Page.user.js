// ==UserScript==
// @name         CloudFam ByPass To Last Page
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Detects any redirect stage and jumps to the final step with auto-click
// @author       BlazeFTL
// @match        https://cloudfam.io/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // 1. Extract parameters from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const slug = urlParams.get('slug');
    const token = urlParams.get('token');
    const currentPath = window.location.pathname;

    // 2. Logic: If we are on ANY redirect page, jump to the final step
    if (currentPath.includes('redirection') && slug && token) {
        const finalUrl = `https://cloudfam.io/${slug}?step=2&token=${token}`;
        window.location.replace(finalUrl);
        return; // Stop execution on this page
    }

    // 3. Final Page Logic: Auto-click the button
    // We use document-idle or an interval to ensure the button exists
    if (window.location.search.includes('step=2')) {
        const clickButton = () => {
            const btn = document.querySelector('#final-download-btn');
            if (btn) {
                btn.click();
                clearInterval(clickInterval);
            }
        };

        // Check every 500ms for the button (in case of slow loading)
        const clickInterval = setInterval(clickButton, 500);

        // Stop checking after 10 seconds to save resources
        setTimeout(() => clearInterval(clickInterval), 10000);
    }
})();

