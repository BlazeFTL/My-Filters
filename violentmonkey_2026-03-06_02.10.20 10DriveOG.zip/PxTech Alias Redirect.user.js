// ==UserScript==
// @name         PxTech Alias Redirect
// @namespace    https://github.com/BlazeFTL
// @description  Capture alias from pxtech.site and redirect to nitro-link.com
// @version      1.2
// @author       BlazeFTL
// @match        https://pxtech.site/*
// @run-at       document-start
// @license      MIT
// @grant        none
// ==/UserScript==

/*
  Copyright (c) 2026 BlazeFTL
  Licensed under the MIT License.
*/

(function(){const u=new URLSearchParams(location.search),a=u.get('alias'),s=sessionStorage;if(a){s.setItem('px_alias',a);window.stop();location.replace('https://nitro-link.com/'+a);}else{const c=s.getItem('px_alias');if(c){s.removeItem('px_alias');location.replace('https://nitro-link.com/'+c);}}})();
