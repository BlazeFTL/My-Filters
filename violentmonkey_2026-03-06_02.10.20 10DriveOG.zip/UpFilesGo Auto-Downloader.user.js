// ==UserScript==
// @name         UpFilesGo Auto-Downloader
// @namespace    https://github.com/BlazeFTL
// @description  Automates upfilesgo.com with strict Please Wait inhibitor
// @version      1.6
// @author       BlazeFTL
// @match        *://upfilesgo.com/*
// @license      MIT
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let lastClicked = 0;
    const cooldown = 2000;

    const isActuallyVisible = (el) => {
        if (!el) return false;
        const style = window.getComputedStyle(el);
        return (
            el.offsetWidth > 0 &&
            el.offsetHeight > 0 &&
            style.visibility !== 'hidden' &&
            style.display !== 'none' &&
            style.opacity !== '0'
        );
    };

    const isClickable = (el) => {
        return el && isActuallyVisible(el) && !el.hasAttribute('disabled') && !el.disabled;
    };

    const safeClick = (el) => {
        const now = Date.now();
        if (isClickable(el) && (now - lastClicked > cooldown)) {
            lastClicked = now;
            el.click();
            return true;
        }
        return false;
    };

    function captchaSolved(callback) {
        let isResolved = false;
        const check = () => {
            if (isResolved) return;
            try {
                const xpath = "//div[contains(@class, 'iconcaptcha-modal__body-title') and contains(., 'Verification complete.')] | //*[@id='captcha-result' and contains(., 'Verified!')]";
                const domCheck = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                const apiCheck = (window.turnstile || window.hcaptcha || window.grecaptcha)?.getResponse?.()?.length > 0;

                if (isActuallyVisible(domCheck) || apiCheck) {
                    isResolved = true;
                    clearInterval(int);
                    callback();
                }
            } catch (e) {}
        };
        const int = setInterval(check, 1000);
    }

    const logic = () => {
        const waitBtn = document.querySelector("#link-button");
        const btn3 = document.querySelector(".my-2.get-link.btn-download.btn-primary.btn");
        const btn2 = document.querySelector(".btn-captcha.btn-primary.btn");
        const btn1 = document.querySelector("#free-download-form > #link-button-free");

        // INHIBITOR: If "Please wait" button is visible and active, stop all other logic
        if (waitBtn && isActuallyVisible(waitBtn)) {
            if (waitBtn.innerText.toLowerCase().includes("wait") || waitBtn.hasAttribute('disabled')) {
                return; // Exit completely while waiting
            }
        }

        // STEP 3: Final Link (Check for visibility and disabled state)
        if (btn3 && isActuallyVisible(btn3)) {
            if (isClickable(btn3)) {
                safeClick(btn3);
            }
            return;
        }

        // STEP 2: Captcha
        if (isClickable(btn2)) {
            captchaSolved(() => safeClick(btn2));
            return;
        }

        // STEP 1: Initial Button
        if (isClickable(btn1) && !isActuallyVisible(btn2) && !isActuallyVisible(btn3)) {
            safeClick(btn1);
        }
    };

    const observer = new MutationObserver(logic);
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true
    });

    // Initial run
    logic();
})();

