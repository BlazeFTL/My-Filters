// ==UserScript==
// @name         GitHub Material Red Linker 4
// @namespace    http://tampermonkey.net/
// @version      1.8
// @description  Material design red links. Now ignores code blocks to prevent breaking syntax highlighting. Supports SPA navigation.
// @author       BlazeFTL
// @match        https://github.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Only run the logic if we are within the target repository path
    const targetPath = "/uBlockOrigin/uAssets/";

    const style = document.createElement('style');
    style.innerHTML = `
        .custom-github-link {
            background-color: rgba(207, 34, 46, 0.1);
            color: #cf222e !important;
            padding: 1px 4px;
            margin: 0 1px;
            border-radius: 3px;
            font-weight: 560;
            text-decoration: none !important;
            transition: all 0.1s ease-in-out;
            display: inline-block;
            line-height: 1.2;
            font-family: var(--fontStack-monospace, ui-monospace, SFMono-Regular, SF Mono, Menlo, Consolas, Liberation Mono, monospace);
            font-size: 0.9em;
        }

        .custom-github-link:hover {
            background-color: #cf222e;
            color: #ffffff !important;
            box-shadow: 0 2px 4px rgba(207, 34, 46, 0.2);
        }
    `;
    document.head.appendChild(style);

    const urlRegex = /((https?:\/\/[^\s<]+)|([a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/[^\s<]*)?))/gi;

    function linkify() {
        if (!window.location.pathname.includes(targetPath)) return;

        const elements = document.querySelectorAll('.markdown-body p:not([data-linked]), .markdown-body :not(pre) > code.notranslate:not([data-linked])');

        elements.forEach(el => {
            if (el.closest('pre') || el.querySelector('a')) return;

            const content = el.textContent.trim();

            if (el.tagName === 'CODE') {
                if (urlRegex.test(content) && (content.includes('.') || content.startsWith('http'))) {
                    el.setAttribute('data-linked', 'true');
                    const url = content.startsWith('http') ? content : `https://${content}`;
                    el.innerHTML = `<a href="${url}" target="_blank" class="custom-github-link">${content}</a>`;
                }
            } else if (el.tagName === 'P') {
                el.setAttribute('data-linked', 'true');
                const originalHTML = el.innerHTML;
                const newHTML = originalHTML.replace(urlRegex, (match) => {
                    if (!match.includes('.') && !match.startsWith('http')) return match;
                    const prefix = match.startsWith('http') ? '' : 'https://';
                    return `<a href="${prefix}${match}" target="_blank" class="custom-github-link">${match}</a>`;
                });

                if (originalHTML !== newHTML) el.innerHTML = newHTML;
            }
        });
    }

    // Debounce to prevent performance lag
    let timeout;
    const debouncedLinkify = () => {
        clearTimeout(timeout);
        timeout = setTimeout(linkify, 300);
    };

    // Initial run
    linkify();

    // Listen for GitHub's SPA page transitions (Turbo is the modern one)
    window.addEventListener('turbo:render', linkify);
    window.addEventListener('pjax:end', linkify); // Legacy support

    // Standard observer for dynamic content within a page
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            if (mutation.addedNodes.length) {
                debouncedLinkify();
                break;
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
})();

