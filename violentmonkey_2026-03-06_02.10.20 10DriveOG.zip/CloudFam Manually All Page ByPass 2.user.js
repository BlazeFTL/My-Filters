// ==UserScript==
// @name         CloudFam Manually All Page ByPass 2
// @namespace    https://github.com/BlazeFTL
// @version      1.2
// @description  Handles dynamic slug/token redirects and ensures final download click
// @author       BlazeFTL
// @match        https://cloudfam.io/redirection0.php?*
// @match        https://cloudfam.io/redirection.php?*
// @match        https://cloudfam.io/redirection2.php?*
// @match        https://cloudfam.io/*step=2*
// @license      MIT
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    const params = new URLSearchParams(window.location.search);
    const slug = params.get('slug');
    const token = params.get('token');
    const currentUrl = window.location.href;

    // 1. Redirection Logic
    if (currentUrl.includes("redirection0.php") && slug && token) {
        window.location.replace(`https://cloudfam.io/redirection.php?slug=${slug}&token=${token}`);
        return;
    }
    if (currentUrl.includes("redirection.php") && slug && token) {
        window.location.replace(`https://cloudfam.io/redirection2.php?slug=${slug}&token=${token}`);
        return;
    }
    if (currentUrl.includes("redirection2.php") && slug && token) {
        window.location.replace(`https://cloudfam.io/${slug}?step=2&token=${token}`);
        return;
    }

    // 2. Final Click Logic (Handles step=2)
    if (currentUrl.includes("step=2")) {
        const tryClick = () => {
            const btn = document.querySelector('#final-download-btn');
            // Ensure button exists and is not disabled (common for countdowns)
            if (btn && !btn.disabled) {
                console.log("Button found! Clicking...");
                btn.click();
                clearInterval(clickPoller);
            }
        };

        // Poll every 500ms to catch the button as soon as it's ready
        const clickPoller = setInterval(tryClick, 500);

        // Safety: Stop polling after 15 seconds to save resources
        setTimeout(() => clearInterval(clickPoller), 15000);
    }
})();

