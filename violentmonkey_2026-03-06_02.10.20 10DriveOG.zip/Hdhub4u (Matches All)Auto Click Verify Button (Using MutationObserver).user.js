// ==UserScript==
// @name         Hdhub4u (Matches All)Auto Click Verify Button (Using MutationObserver)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Automatically clicks the verify button based on text content, preventing spamming using MutationObserver.
// @author       You
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to check and click the button
    function checkAndClickButton(button) {
        const buttonText = button.textContent.trim().toLowerCase();

        // Check if the button text matches "click to continue" or "get links"
        if ((buttonText.includes('click to continue') || buttonText.includes('get links'))) {
            button.click();
            console.log('Clicked button:', buttonText); // For debugging

            // Disconnect the MutationObserver after clicking to prevent spamming
            observer.disconnect();
        }
    }

    // Setup MutationObserver to watch for text changes in #verify_btn
    const observer = new MutationObserver((mutationsList, observer) => {
        const button = document.querySelector('#verify_btn');
        if (button) {
            checkAndClickButton(button);
        }
    });

    // Observe the #verify_btn for text content changes
    const button = document.querySelector('#verify_btn');
    if (button) {
        observer.observe(button, { childList: true, subtree: true });
    }

})();
