// ==UserScript==
// @name         Vplink 2 Page
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Force redirect from Apnahirework to DailyHindiAdda with 20s UI
// @author       BlazeFTL
// @match        https://apnahirework.com/*
// @match        https://dailyhindiadda.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const url = window.location.href;
    const params = new URLSearchParams(window.location.search);

    // --- STAGE 1: APNAHIREWORK (The Interception) ---
    if (url.includes('apnahirework.com') && params.has('studyeducate')) {
        const id = params.get('studyeducate');

        // Stop the site's own redirect script immediately
        window.stop();

        // Force the jump to the new intermediate domain
        window.location.replace(`https://dailyhindiadda.com/educationhub/jobsstudy/?studyedu=${id}`);
        return;
    }

    // --- STAGE 2: DAILYHINDIADDA (The Capture) ---
    if (url.includes('dailyhindiadda.com')) {

        // Capture the ID if we are on the redirect trigger page
        if (params.has('studyedu')) {
            localStorage.setItem("blaze_final_id", params.get('studyedu'));
            return; // Let the site redirect to the article page naturally
        }

        // --- STAGE 3: THE ARTICLE PAGE (The UI) ---
        const savedId = localStorage.getItem("blaze_final_id");

        // Only show UI if we have an ID and we aren't on the capture page
        if (savedId && !params.has('studyedu')) {

            const startUI = () => {
                if (document.getElementById('blaze-guard')) return;

                const shield = document.createElement('div');
                shield.id = 'blaze-guard';
                shield.style.cssText = `
                    position: fixed !important; top: 0; left: 0; width: 100%; height: 100%;
                    background: #000 !important; z-index: 2147483647 !important;
                    display: flex; align-items: center; justify-content: center;
                    font-family: sans-serif; color: white; text-align: center;
                `;

                shield.innerHTML = `
                    <div style="border: 2px solid #e74c3c; padding: 40px; border-radius: 20px; background: #111;">
                        <h2 style="color: #e74c3c; margin: 0;">LINK VERIFICATION</h2>
                        <div id="big-timer" style="font-size: 100px; font-weight: bold; margin: 10px 0;">20</div>
                        <p style="color: #666;">Stay on this page to maintain referer status.</p>
                    </div>
                `;

                (document.body || document.documentElement).appendChild(shield);

                let timeLeft = 20;
                const ticker = setInterval(() => {
                    timeLeft--;
                    const display = document.getElementById('big-timer');
                    if (display) display.innerText = timeLeft;

                    if (timeLeft <= 0) {
                        clearInterval(ticker);
                        localStorage.removeItem("blaze_final_id");
                        // Redirect to the final destination
                        window.location.href = "https://vplink.in/" + savedId;
                    }
                }, 1000);
            };

            // Persistence: Ensure UI isn't removed by site scripts
            if (document.documentElement) startUI();
            const obs = new MutationObserver(() => {
                if (!document.getElementById('blaze-guard')) startUI();
            });
            obs.observe(document.documentElement, { childList: true, subtree: true });
        }
    }
})();

