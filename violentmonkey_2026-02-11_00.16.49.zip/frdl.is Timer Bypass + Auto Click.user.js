// ==UserScript==
// @name         frdl.is Timer Bypass + Auto Click
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Bypass 60s timer and auto-clicks on frdl.is download buttons
// @match        https://*.frdl.*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ----------- Timer Bypass Section -----------
    const waitForFreeDownload = setInterval(() => {
        if (typeof freeDownload === 'function') {
            clearInterval(waitForFreeDownload);

            const realFreeDownload = freeDownload;

            freeDownload = function() {
                const val = $("#download_free").val();
                if (val == '1') {
                    document.F1.submit();
                    return true;
                }

                const dlbtn = $(".downloadbtnfree");
                dlbtn.attr("disabled", true);

                $("#countdown").show().find(".seconds").html("60");
                $("#free-captcha").show();
                $("#download_free").val("1");
                $(".downloadbtnfree").html("Almost Ready to Download");

                setTimeout(() => {
                    $("#countdown").hide();
                    dlbtn.attr("disabled", false);
                    $(".downloadbtnfree").html("Start Download NOW");
                }, 100); // Fast-forward countdown

                return true;
            };

            console.log("[Bypass] Timer flow override applied.");
        }
    }, 300);

    // ----------- Auto Click Section -----------
    function clickButton(selector) {
        const button = document.querySelector(selector);
        if (button) {
            button.click();
            console.log('[AutoClick] Clicked:', selector);
        }
    }

    function clickLink(selector) {
        const link = document.querySelector(selector);
        if (link) {
            link.click();
            console.log('[AutoClick] Clicked:', selector);
        }
    }

    const observer = new MutationObserver(() => {
        clickButton('#downloadbtnfree'); // For timer/start buttons
        clickLink('.btn-primary.btn-block.mb-4'); // For final download button
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Initial attempts
    clickButton('#downloadbtnfree');
    clickLink('.btn-primary.btn-block.mb-4');
})();
