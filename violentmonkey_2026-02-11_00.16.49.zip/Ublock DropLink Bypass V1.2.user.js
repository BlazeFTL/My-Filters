// ==UserScript==
// @name         Ublock DropLink Bypass V1.2
// @namespace    http://tampermonkey.net/
// @version      3.1
// @description  Universal bypass for all listed stages
// @author       BlazeFTL
// @match        *://tech8s.net/safe2.php*
// @match        *://drop.carbikenation.com/safe2.php*
// @match        *://linkss.rcccn.in/safe2.php*
// @match        *://link.djbassking.live/safe2.php*
// @match        *://tech5s.co/safe2.php*
// @match        *://game5s.com/safe2.php*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const urlParams = new URLSearchParams(window.location.search);
    const linkID = urlParams.get('link');
    if (!linkID) return;

    const host = window.location.hostname;

    // logic: tech8s -> game5s -> final destination
    if (host.includes('tech8s.net')) {
        window.location.replace(`https://game5s.com/safe2.php?link=${linkID}`);
    } else {
        // For game5s.com and all other secondary domains, jump to the end
        window.location.replace(`https://droplink.co/${linkID}`);
    }
})();

