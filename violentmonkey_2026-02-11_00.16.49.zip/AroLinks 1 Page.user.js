// ==UserScript==
// @name         AroLinks 1 Page
// @namespace    http://tampermonkey.net/
// @version      1.6
// @description  Capture ID and show UI without freezing the browser
// @author       BlazeFTL
// @match        https://apnahirework.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1. QUICK CAPTURE
    const params = new URLSearchParams(window.location.search);
    const targetId = params.get('edustudy') || params.get('coursestudy');

    if (targetId) {
        localStorage.setItem("blaze_id", targetId);
        console.log("ID Saved: " + targetId);
        // We let the natural redirect happen now so it doesn't get stuck
    }

    // 2. UI LOGIC
    const savedId = localStorage.getItem("blaze_id");
    const isCapturePage = window.location.href.includes('study=');

    if (savedId && !isCapturePage) {

        const injectUI = () => {
            if (document.getElementById('blaze-timer-overlay')) return;

            const overlay = document.createElement('div');
            overlay.id = 'blaze-timer-overlay';
            overlay.style.cssText = `
                position: fixed !important; top: 0; left: 0; width: 100%; height: 100%;
                background: #111 !important; z-index: 2147483647 !important;
                display: flex; align-items: center; justify-content: center;
                flex-direction: column; color: white; font-family: sans-serif;
            `;

            overlay.innerHTML = `
                <div style="padding: 40px; border-radius: 20px; background: #222; border: 1px solid #444; text-align: center;">
                    <h2 style="margin: 0; color: #00d4ff;">Link Processing</h2>
                    <div id="blaze-num" style="font-size: 80px; font-weight: bold; margin: 20px 0;">20</div>
                    <p style="color: #aaa;">Redirecting to Arolinks in <span id="sec">20</span>s</p>
                </div>
            `;

            (document.body || document.documentElement).appendChild(overlay);

            let seconds = 20;
            const timerInterval = setInterval(() => {
                seconds--;
                const numEl = document.getElementById('blaze-num');
                const secEl = document.getElementById('sec');
                if(numEl) numEl.innerText = seconds;
                if(secEl) secEl.innerText = seconds;

                if (seconds <= 0) {
                    clearInterval(timerInterval);
                    localStorage.removeItem("blaze_id");
                    window.location.replace("https://arolinks.com/" + savedId);
                }
            }, 1000);
        };

        // Aggressive Persistence: If the site clears our UI, we put it back
        const observer = new MutationObserver(() => {
            if (!document.getElementById('blaze-timer-overlay')) {
                injectUI();
            }
        });

        observer.observe(document.documentElement, { childList: true, subtree: true });

        // Initial attempt
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', injectUI);
        } else {
            injectUI();
        }
    }
})();

