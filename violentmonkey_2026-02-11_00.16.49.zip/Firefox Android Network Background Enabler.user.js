// ==UserScript==
// @name         Firefox Android Network Background Enabler
// @namespace    http://tampermonkey.net/
// @version      6.0
// @description  Moves Fetch/XHR to a Worker thread to bypass background suspension
// @author       BlazeFTL
// @match        *://*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // 1. WEB WORKER NETWORK ENGINE
    const workerCode = `
        self.onmessage = async function(e) {
            const { type, id, url, options } = e.data;
            if (type === 'FETCH') {
                try {
                    const response = await fetch(url, options);
                    const data = await response.text();
                    self.postMessage({ id, status: response.status, data });
                } catch (err) {
                    self.postMessage({ id, error: err.message });
                }
            }
        };
    `;

    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const worker = new Worker(URL.createObjectURL(blob));
    const pendingRequests = new Map();

    worker.onmessage = (e) => {
        const { id, status, data, error } = e.data;
        const resolve = pendingRequests.get(id);
        if (resolve) {
            resolve(new Response(data, { status }));
            pendingRequests.delete(id);
        }
    };

    // 2. HIJACK NATIVE FETCH
    const originalFetch = window.fetch;
    window.fetch = function(url, options) {
        // If we are in the background, use the worker to bypass thread suspension
        if (document.visibilityState === 'hidden' || document.hidden) {
            const id = Math.random().toString(36).substr(2, 9);
            return new Promise((resolve) => {
                pendingRequests.set(id, resolve);
                worker.postMessage({ type: 'FETCH', id, url, options });
            });
        }
        return originalFetch(url, options);
    };

    // 3. VISIBILITY SPOOFING (Keep this so the site *tries* to send the call)
   // Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
  //  Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });

    // 4. AUDIO WAKE-LOCK
    const startAudio = () => {
        const ctx = new AudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        gain.gain.value = 0.0001;
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        console.log("Network Guard: Audio Active");
        window.removeEventListener('click', startAudio);
    };
    window.addEventListener('click', startAudio);

})();

