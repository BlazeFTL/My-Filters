// ==UserScript==
// @name         FB: See All Messenger inside Account Controls (robust)
// @namespace    fb-seeall-robust
// @version      6.0
// @match        https://www.facebook.com/*
// @match        https://web.facebook.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function getAccountControls() {
        // exact selector first, then fallback to nav or any element with that aria-label
        return document.querySelector('div[aria-label="Account Controls and Settings"][role="navigation"]')
            || document.querySelector('nav[aria-label="Account Controls and Settings"]')
            || document.querySelector('[aria-label="Account Controls and Settings"][role="navigation"]')
            || document.querySelector('[aria-label="Account Controls and Settings"]');
    }

    function createMessengerButtonFrom(menuBtn) {
        // clone the Menu button to preserve exact styling
        const clone = menuBtn.cloneNode(true);
        clone.id = 'fbSeeAllMessengerInjected';
        clone.setAttribute('aria-label', 'See all in Messenger');

        // remove attributes that would interfere
        clone.removeAttribute('aria-expanded');
        clone.removeAttribute('data-owner'); // any random attrs
        clone.style.zIndex = '9999'; // ensure visibility

        // replace inner icon with Messenger icon (keeps size/layout)
        // try to find an <svg> or <i> inside clone and replace it
        const svg = clone.querySelector('svg');
        const iconHolder = svg || clone.querySelector('i') || clone;

        // create <i> sprite like FB uses
        const iEl = document.createElement('i');
        iEl.setAttribute('aria-hidden', 'true');
        iEl.style.cssText = `
            background-image: url('https://static.xx.fbcdn.net/rsrc.php/v4/y9/r/vY5zuKRS8hV.png');
            background-position: 0px -482px;
            background-repeat: no-repeat;
            width: 22px;
            height: 22px;
            display: inline-block;
        `;

        // replace iconHolder content
        iconHolder.innerHTML = '';
        iconHolder.appendChild(iEl);

        // make click navigate to messenger full page
        clone.addEventListener('click', (e) => {
            e.stopPropagation();
            // open in same tab (change if you want new tab)
            window.location.href = '/messages/t/';
        });

        // ensure accessible tabindex/cursor
        clone.setAttribute('role', 'button');
        clone.tabIndex = 0;
        clone.style.cursor = 'pointer';

        return clone;
    }

    function insertOnce() {
        try {
            const account = getAccountControls();
            if (!account) return;

            // avoid creating multiple buttons
            if (document.getElementById('fbSeeAllMessengerInjected')) return;

            // find the Menu button inside account controls
            const menuBtn = Array.from(account.querySelectorAll('[role="button"]'))
                .find(el => el.getAttribute('aria-label') === 'Menu');

            if (!menuBtn) return;

            const messengerBtn = createMessengerButtonFrom(menuBtn);

            // Insert the messenger button immediately BEFORE the Menu button
            menuBtn.parentNode.insertBefore(messengerBtn, menuBtn);
        } catch (err) {
            // silent fail (FB heavy DOM can throw)
            console.error('fb-seeall error', err);
        }
    }

    // observe body for dynamic changes and try to insert repeatedly
    const obs = new MutationObserver(insertOnce);
    obs.observe(document.body, { childList: true, subtree: true });

    // initial attempt
    insertOnce();

    // also try again after short delays (helps for some load timings)
    setTimeout(insertOnce, 1000);
    setTimeout(insertOnce, 2500);
    setTimeout(insertOnce, 5000);
})();

