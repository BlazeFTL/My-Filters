// ==UserScript==
// @name         Fake Ad Complete vercel-bypass
// @match        https://vercel-bypass.vercel.app/*
// @run-at       document-start
// ==/UserScript==

(function() {
    "use strict";

    // Wait until page defines show_9788260, then override
    Object.defineProperty(window, "show_9788260", {
        configurable: true,
        get() {
            return () => {
                console.log("⚠️ Fake show_9788260 called (testing mode).");
                return Promise.resolve(); // pretend ad finished successfully
            };
        },
        set(fn) {
            console.log("show_9788260 hooked");
            // Keep reference if needed
        }
    });
})();