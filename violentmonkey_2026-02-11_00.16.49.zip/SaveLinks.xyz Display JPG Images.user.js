// ==UserScript==
// @name         SaveLinks.xyz Display JPG Images
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Replace .jpg links with actual images on openlinks.xyz
// @author       BlazeFTL
// @match        https://openlinks.xyz/view/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function convertLinks(container) {
        const links = container.querySelectorAll('a[href$=".jpg"]');
        links.forEach(link => {
            const img = document.createElement('img');
            img.src = link.href;
            img.style.maxWidth = '100%';
            img.style.display = 'block';
            img.style.margin = '10px 0';
            link.parentNode.insertBefore(img, link.nextSibling);
            link.remove();
        });
    }

    const target = document.querySelector('.view-well');

    if (target) {
        convertLinks(target); // Run once if already loaded

        // Watch for future changes
        const observer = new MutationObserver(() => convertLinks(target));
        observer.observe(target, { childList: true, subtree: true });
    }
})();
