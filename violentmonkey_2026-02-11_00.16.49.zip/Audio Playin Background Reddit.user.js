// ==UserScript==
// @name        Audio Playin Background Reddit
// @namespace   Violentmonkey Scripts
// @match       *://*/*
// @grant       none
// @version     1.0
// @author      -
// @description 1/22/2026, 11:03:55 PM
// ==/UserScript==

// Play some sound to prevent firefox from unloading scripts if this tab is backgrounded.
window.AudioContext = window.AudioContext || window.webkitAudioContext;
context = new AudioContext();
var o = context.createOscillator();
var volume = context.createGain();
o.connect(volume);
volume.connect(context.destination);
o.type = 'sine';
o.frequency.value = 100;
// Set volume almost to 0 so we can't hear it, but tab still registers as playing sound
volume.gain.value = 0.0001;
o.start(0);