// ==UserScript==
// @name         Tab Visibility And Blur SpooF
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Patches visibilityState, hasFocus, and event listeners to keep sites "active" in background
// @author       YourName
// @match        *://*/*
// @exclude      *://*.gemini.google.*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // 1. Force Property Overrides
    const trueFunc = () => true;

    Object.defineProperties(document, {
        'hidden': { value: false, writable: false },
        'visibilityState': { value: 'visible', writable: false },
        'webkitVisibilityState': { value: 'visible', writable: false },
        'hasFocus': { value: trueFunc, writable: false }
    });

    // 2. Block Visibility/Focus Events
    // This stops the site from ever hearing that you "left" the tab
    const blockedEvents = [
        'visibilitychange',
        'webkitvisibilitychange',
        'blur',
        'focusout',
        'focus',
        'pagehide',
        'mouseleave'
    ];

    const originalAEL = EventTarget.prototype.addEventListener;
    EventTarget.prototype.addEventListener = function(type, listener, options) {
        if (blockedEvents.includes(type.toLowerCase())) {
            console.log(`[Anti-Detection] Blocked listener for: ${type}`);
            return; // Do nothing, don't add the listener
        }
        return originalAEL.apply(this, arguments);
    };

    // 3. Prevent "blurred" or "isPaused" variable hijacks
    // Many sites use "var blurred = true;" internally.
    window.blurred = false;
    Object.defineProperty(window, 'blurred', {
        get: () => false,
        set: () => {}, // Ignore attempts to set it to true
        configurable: false
    });

    // 4. Periodic "Keep-Alive" Pulse
    // Some sites check the timestamp of the last mouse move.
    setInterval(() => {
        window.dispatchEvent(new MouseEvent('mousemove', {
            view: window,
            bubbles: true,
            cancelable: true
        }));
    }, 5000);

    console.log("Anti-Detection Patch Active: Visibility locked to 'visible'.");
})();

