// ==UserScript==
// @name         Gtlinks Token Redirector
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Watches for the token in SessionStorage and redirects automatically
// @author       Gemini
// @match        *://*.scriptgrowagarden.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    function checkAndRedirect() {
        // 1. Check SessionStorage
        const userToken = sessionStorage.getItem('token');

        if (userToken) {
            console.log("Token found:", userToken);

            // 2. Clear the interval so it stops checking
            clearInterval(tokenWatcher);

            // 3. Perform the redirect
            const destination = "https://golink.bloggerishyt.in/" + encodeURIComponent(userToken);
            window.location.replace(destination);
        }
    }

    // Check every 500ms (twice a second) until the token is found
    const tokenWatcher = setInterval(checkAndRedirect, 500);

    // Also run immediately on load
    checkAndRedirect();
})();

