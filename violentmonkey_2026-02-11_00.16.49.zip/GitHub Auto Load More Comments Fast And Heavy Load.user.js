// ==UserScript==
// @name         GitHub Auto Load More Comments Fast And Heavy Load
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Automatically clicks the "Load more" button in GitHub discussions and issues.
// @author       Gemini
// @match        https://github.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The specific selector provided for the button
    const BUTTON_SELECTOR = '.border-0.color-bg-default.mb-1.mt-0.px-4.pt-0.pb-1.no-underline.ajax-pagination-btn';

    const clickLoadMore = () => {
        const loadMoreButton = document.querySelector(BUTTON_SELECTOR);

        // If the button exists and is visible/active
        if (loadMoreButton) {
            console.log('GitHub Auto-Loader: Clicking "Load more" button...');
            loadMoreButton.click();
        }
    };

    // Use MutationObserver to watch for new content being added to the DOM
    const observer = new MutationObserver((mutations) => {
        clickLoadMore();
    });

    // Start observing the document body for changes
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Initial check on page load
    clickLoadMore();
})();

