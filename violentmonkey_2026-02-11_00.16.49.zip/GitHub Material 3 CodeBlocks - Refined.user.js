// ==UserScript==
// @name        GitHub Material 3 CodeBlocks - Refined
// @namespace   BlazeFTL.Scripts
// @match       https://github.com/uBlockOrigin/uAssets/*
// @grant       none
// @version     2.0
// @author      BlazeFTL
// @description High-end Material 3 styling for uBlock Origin discussion code blocks.
// ==/UserScript==

(function() {
    'use strict';

    const css = `
        /* Main Container Styling */
        .markdown-body .highlight pre,
        .markdown-body pre {
            background-color: #f7f2fa !important; /* M3 Surface Container Low */
            border-radius: 16px !important;       /* Refined M3 Medium Shape */
            padding: 20px !important;
            border: 1px solid #e7e0ec !important; /* Subtle M3 Outline Variant */
            box-shadow: none !important;
            position: relative;
            transition: background-color 0.2s ease;
        }

        /* Dark Mode Adjustments */
        [data-color-mode="dark"] .markdown-body .highlight pre,
        [data-color-mode="dark"] .markdown-body pre {
            background-color: #1d1b20 !important; /* M3 Surface Container */
            border-color: #49454f !important;
            color: #e6e1e5 !important;
        }

        /* Typography & Code Polish */
        .markdown-body pre code {
            font-family: "JetBrains Mono", "Roboto Mono", monospace !important;
            font-size: 13.5px !important;
            line-height: 1.6 !important;
            tab-size: 4;
        }

        /* Styling the GitHub Copy Button to match M3 */
        .zeroclipboard-container {
            top: 12px !important;
            right: 12px !important;
        }

        .btn-octicon.js-clipboard-copy {
            background-color: #ece6f0 !important; /* M3 Surface Container High */
            border-radius: 10px !important;
            border: none !important;
            padding: 8px !important;
            transition: transform 0.1s ease;
        }

        .btn-octicon.js-clipboard-copy:hover {
            background-color: #e8def8 !important; /* M3 Primary Container */
            transform: scale(1.05);
        }

        /* Remove the bulky outer borders often found in GitHub discussions */
        .highlight {
            border: none !important;
            background: transparent !important;
        }
    `;

    const style = document.createElement('style');
    style.textContent = css;
    document.head.append(style);
})();

