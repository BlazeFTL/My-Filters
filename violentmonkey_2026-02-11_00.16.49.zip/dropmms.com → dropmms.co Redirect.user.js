// ==UserScript==
// @name         dropmms.com → dropmms.co Redirect
// @namespace    redirect.dropmms
// @version      1.0
// @description Redirect dropmms.com to dropmms.co instantly
// @match        *://dropmms.com/*
// @match        *://www.dropmms.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    if (location.hostname === 'dropmms.com' || location.hostname === 'www.dropmms.com') {
        location.replace(
            location.href.replace('dropmms.com', 'dropmms.co')
        );
    }
})();
