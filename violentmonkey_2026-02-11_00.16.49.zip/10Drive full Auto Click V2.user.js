// ==UserScript==
// @name         10Drive full Auto Click V2
// @namespace    http://tampermonkey.net/
// @version      1.9
// @description  Sequential clicks; prevents final button spam using state tracking
// @author       BlazeFTL
// @match        *://gamesmain.xyz/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // Tracking states for the current session
    let secureClickSent = false;
    let linkReadyClicked = false;

    const forceClick = (el) => {
        const opts = { bubbles: true, cancelable: true, view: window };
        el.dispatchEvent(new MouseEvent('mousedown', opts));
        el.dispatchEvent(new MouseEvent('mouseup', opts));
        el.click();
    };

    const handleSequence = () => {
        // 1. Initial Signal (Iframe)
        if (!secureClickSent) {
            const frame = document.querySelector('iframe[srcdoc*="hss"]');
            if (frame) {
                window.postMessage("secure-click", "*");
                secureClickSent = true;
            }
        }

        // 2. Click #create-link
        const createLink = document.querySelector('#create-link');
        if (createLink && !createLink.classList.contains('d-none') && createLink.offsetParent !== null) {
            forceClick(createLink);
        }

        // 3. Click #link-ready (Wait for 10s timer/spinner)
        const linkReady = document.querySelector('#link-ready');
        const spinner = document.querySelector('.spinner-border');

        if (linkReady && (!spinner || spinner.classList.contains('d-none')) &&
            !linkReady.classList.contains('d-none') && !linkReadyClicked) {

            linkReadyClicked = true;
            setTimeout(() => {
                forceClick(linkReady);
                if (linkReady.href && linkReady.href.includes('http')) {
                    window.location.href = linkReady.href;
                }
            }, 400); // 400ms buffer
        }

        // 4. Final Page Button - CLICK ONLY ONCE
        const finalBtn = document.querySelector('#dwform > .btn-primary.btn');

        // We use a custom attribute to mark that we've already clicked this specific element
        if (finalBtn && !finalBtn.dataset.clickedOnce) {
            // Check if page is fully loaded
            if (document.readyState === 'complete') {
                console.log("Page load complete. Clicking final button once...");
                finalBtn.dataset.clickedOnce = "true"; // Mark it
                forceClick(finalBtn);
            }
        }
    };

    // Use MutationObserver to catch elements as they appear
    const observer = new MutationObserver(handleSequence);
    observer.observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true
    });

    // Also trigger on full window load for Step 4 safety
    window.addEventListener('load', handleSequence);

    // Backup check every second
    setInterval(handleSequence, 1000);
})();

