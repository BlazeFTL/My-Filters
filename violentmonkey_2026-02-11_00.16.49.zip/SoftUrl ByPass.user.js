// ==UserScript==
// @name         SoftUrl ByPass
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Detects kdsafe variables and window.open calls to redirect to the true destination.
// @author       BlazeFTL
// @match        *://*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    function attemptRedirect() {
        const scripts = document.querySelectorAll('script');

        scripts.forEach(script => {
            const code = script.innerHTML;

            // --- DETECTOR 1: kdsafe Variables ---
            if (code.includes('aUrl') && code.includes('alias')) {
                const aUrlMatch = code.match(/const aUrl\s*=\s*"(.*?)";/);
                const aliasMatch = code.match(/const alias\s*=\s*"(.*?)";/);

                if (aUrlMatch && aliasMatch) {
                    const finalUrl = aUrlMatch[1].replace(/\/$/, '') + '/' + aliasMatch[1].replace(/^\//, '');
                    console.log("Detected kdsafe redirect:", finalUrl);
                    window.location.replace(finalUrl);
                }
            }

            // --- DETECTOR 2: window.open with Base64 Safelink ---
            if (code.includes('safelink_redirect=')) {
                const b64Match = code.match(/safelink_redirect=([^'"]+)/);
                if (b64Match) {
                    try {
                        const decoded = JSON.parse(atob(b64Match[1]));
                        // Prioritize the inner 'safelink' or 'second_safelink_url'
                        const target = decoded.safelink || decoded.second_safelink_url;
                        if (target) {
                            console.log("Detected Base64 safelink:", target);
                            window.location.replace(target);
                        }
                    } catch (e) {
                        console.error("Failed to decode safelink payload", e);
                    }
                }
            }
        });
    }

    // Run immediately and again when DOM is loaded to catch dynamic scripts
    attemptRedirect();
    window.addEventListener('DOMContentLoaded', attemptRedirect);

})();

