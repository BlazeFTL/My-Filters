// ==UserScript==
// @name         GitHub Auto-Linker (CPU Optimized)
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Lightweight URL linker for GitHub that won't kill your CPU.
// @author       BlazeFTL
// @match        https://github.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const urlRegex = /(https?:\/\/[^\s<]+)/g;

    function linkify() {
        // Only target paragraphs and code blocks inside markdown that haven't been processed yet
        const elements = document.querySelectorAll('.markdown-body p:not([data-linked]), .markdown-body code.notranslate:not([data-linked])');

        elements.forEach(el => {
            // Mark it immediately so we don't process it twice
            el.setAttribute('data-linked', 'true');

            // Skip if it already contains an actual link
            if (el.querySelector('a')) return;

            const originalHTML = el.innerHTML;
            const newHTML = originalHTML.replace(urlRegex, (url) => {
                return `<a href="${url}" target="_blank" style="color: #0969da; text-decoration: underline;">${url}</a>`;
            });

            if (originalHTML !== newHTML) {
                el.innerHTML = newHTML;
            }
        });
    }

    // DEBOUNCE: This prevents the script from running constantly.
    // It waits for the DOM to "settle" for 200ms before executing.
    let timeout;
    const debouncedLinkify = () => {
        clearTimeout(timeout);
        timeout = setTimeout(linkify, 200);
    };

    // Initialize
    linkify();

    // Observe changes but only trigger the debounced function
    const observer = new MutationObserver(debouncedLinkify);
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();


