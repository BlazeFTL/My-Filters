// ==UserScript==
// @name         10Drive All AutoClick Till Download V1(Spam)
// @namespace    http://tampermonkey.net/
// @version      1.8
// @description  Waits for the 10s timer before clicking #link-ready
// @author       BlazeFTL
// @match        *://gamesmain.xyz/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    let secureClickSent = false;
    let linkReadyClicked = false;

    const forceClick = (el) => {
        const opts = { bubbles: true, cancelable: true, view: window };
        el.dispatchEvent(new MouseEvent('mousedown', opts));
        el.dispatchEvent(new MouseEvent('mouseup', opts));
        el.click();
    };

    const handleSequence = () => {
        // Step 1: Secure-click signal (from the iframe)
        if (!secureClickSent) {
            const frame = document.querySelector('iframe[srcdoc*="hss"]');
            if (frame) {
                window.postMessage("secure-click", "*");
                secureClickSent = true;
            }
        }

        // Step 2: Click #create-link
        const createLink = document.querySelector('#create-link');
        // Only click if it's visible and NOT hidden by d-none
        if (createLink && !createLink.classList.contains('d-none') && createLink.offsetParent !== null) {
            forceClick(createLink);
        }

        // Step 3: Click #link-ready (Wait for the 10s timer)
        const linkReady = document.querySelector('#link-ready');
        const spinner = document.querySelector('.spinner-border');

        // Only click if: link exists, spinner is gone (d-none), and button is visible
        if (linkReady && (!spinner || spinner.classList.contains('d-none')) &&
            !linkReady.classList.contains('d-none') && !linkReadyClicked) {

            console.log("Timer finished. Clicking #link-ready...");
            linkReadyClicked = true;

            // Short 500ms buffer to ensure site scripts are ready
            setTimeout(() => {
                forceClick(linkReady);
                // Backup: Redirect if click is intercepted
                if (linkReady.href && linkReady.href.includes('http')) {
                    window.location.href = linkReady.href;
                }
            }, 500);
        }

        // Step 4: Final Page Button
        const finalBtn = document.querySelector('#dwform > .btn-primary.btn');
        if (finalBtn) {
            forceClick(finalBtn);
        }
    };

    // Fast observation
    const observer = new MutationObserver(handleSequence);
    observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true });

    // Fallback interval
    setInterval(handleSequence, 3000);
})();

