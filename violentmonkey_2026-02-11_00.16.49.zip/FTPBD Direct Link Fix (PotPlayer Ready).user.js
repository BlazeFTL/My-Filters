// ==UserScript==
// @name         FTPBD Direct Link Fix (PotPlayer Ready)
// @namespace    blazeftl.ftpbd
// @version      1.2
// @description  Replace useless # hrefs with real data-url so right-click works (PotPlayer, VLC, IDM, etc.)
// @author       BlazeFTL
// @match        https://ftpbd.net/*
// @match        https://www.ftpbd.net/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function fixLinks() {
        document.querySelectorAll('a[href="#"][data-url]').forEach(a => {
            if (a.dataset.fixed) return;
            a.dataset.fixed = "true";

            const fileUrl = a.getAttribute("data-url");
            if (!fileUrl) return;

            // Replace "#" with the real file URL
            a.setAttribute("href", fileUrl);

            // Let right-click / middle-click work properly
            a.setAttribute("target", "_blank");

            // Small indicator so you know it’s patched
            const badge = document.createElement("span");
            badge.textContent = " ⬇";
            badge.style.color = "green";
            badge.style.fontSize = "12px";
            badge.style.fontWeight = "bold";
            a.appendChild(badge);
        });
    }

    // Initial run
    fixLinks();

    // Watch dynamically added content
    const observer = new MutationObserver(fixLinks);
    observer.observe(document.body, { childList: true, subtree: true });
})();
