// ==UserScript==
// @name         Ublock LiteShort SetUrl ByPass 3
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Redirects based on current URL parameters without hardcoded domains
// @author       BlazeFTL
// @match        https://houseloanoffers.com/*
// @match        https://proseware.in/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const params = new URLSearchParams(window.location.search);
    const webValue = params.get('web');
    if (!webValue) return;

    // STEP 1: If we are on the first site (determined by the 'web' query param)
    // and we want to go to the second site in your list:
    if (window.location.hostname === "houseloanoffers.com") {
        setTimeout(() => {
            window.location.replace(`https://proseware.in/?web=${webValue}`);
        }, 100);
    }

    // STEP 2: If we are on the second site:
    else {
        window.stop();
        setTimeout(() => {
            window.location.replace(`https://set.seturl.in/${webValue}`);
        }, 100);
    }
})();

