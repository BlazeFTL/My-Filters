// ==UserScript==
// @name         DropGalaxy Auto Skip
// @namespace    http://tampermonkey.net/
// @version      1.4.1
// @description  Auto skip ads and auto download on DropGalaxy
// @author       kleptomaniac14
// @match        https://dropgalaxy.com/*
// @match        https://dropgalaxy.co/*
// @match        https://financemonk.net/*
// @icon         https://www.google.com/s2/favicons?domain=dropgalaxy.com
// @grant        none
// @license      GNU GPLv2
// @downloadURL https://update.greasyfork.org/scripts/492017/DropGalaxy%20Auto%20Skip.user.js
// @updateURL https://update.greasyfork.org/scripts/492017/DropGalaxy%20Auto%20Skip.meta.js
// ==/UserScript==

// Setting esversion to 11 to use optional chaining.
/* jshint esversion: 11 */

(function () {
    "use strict";

    // Constants
    const MAX_IDENTIFICATION_RETRIES = 100;
    const CAPTCHA_CONTAINER_ID = "cfcaptcha";
    const ENABLE_EXPT_CODE = false;

    // Global Variables
    let identificationRetries = 0;

    // Utils
    const log = (message) => console.log(`[DropGalaxy Auto Skip] ${message}`);

    // This code is used by the site to trigger the CAPTCHA
    const siteCaptchaCode = () => {
        turnstile.ready(function () {
            turnstile.render(`#${CAPTCHA_CONTAINER_ID}`, {
                sitekey: '0x4AAAAAAAYwfzxMEjmxM8RT',
                callback: function (token) {
                    $('#tokennstatus').html('<small>being verified pls wait..</small>');
                    bangbang(token);
                    console.log(`Challenge Success ${token}`);
                },
            });
        });
    }

    // One Time Setup
    log("DropGalaxy Script Loaded");

    // Page Handlers
    const handlePage1 = () => {
        log("Handling Page 1");

        // Click on Download Button
        const downloadBtn = document.getElementById("method_free");
        downloadBtn.click();
    };

    const handlePage3 = () => {
        log("Handling Page 3");

        // Click on Download Button
        const downloadForm = document.getElementById("dllink");
        const url = downloadForm.action;
        
        // Add element to show the DDL
        const ddlElement = document.createElement("a");
        ddlElement.href = url;
        ddlElement.innerText = "Direct Download Link";
        ddlElement.className = "btn btn-block btn-lg btn-primary";
        ddlElement.style = "background: #22a76d; color: white; margin-bottom: 20px; padding-inline: 0; border: none;";
        
        const loader = document.getElementById("load");
        loader.parentElement.insertBefore(ddlElement, loader)

        // Auto download by opening the link
        window.location.assign(url);
    };

    const handlePage2 = () => {
        log("Handling Page 2");

        const falseDownloadBtn = document.getElementById("downloadbtn");
        const tokenStatus = document.getElementById("tokennstatus");
        const countdown = document.getElementById("countdown");

        // Keep clicking until enabled
        const downloadIntervalId = setInterval(() => {
            if (tokenStatus.innerText === "click on- verify you are human..." &&
                countdown.style.display === 'none') {
                // In case CAPTCHA was not triggered by site, trigger it 
                // manually.
                // This is required when site does not trigger the CAPTCHA if
                // it is triggered too many times or a download is going on.
                if (ENABLE_EXPT_CODE) {
                    siteCaptchaCode();
                }
            } else if (
                // If download button is enabled and CAPTCHA is solved, submit the form
                tokenStatus.innerText === "ready! click on create download link" &&
                falseDownloadBtn.disabled === false
            ) {
                log("Download Button Enabled, submitting form");
                // downloadBtn.click();
                document.getElementById("ff1").submit();
                clearInterval(downloadIntervalId);
            }
        }, 500);
    };

    const handlePage = (pageWatcherIntervalId) => {
        const page1Identifier = document.getElementById("method_free");
        const page2Identifier = document.getElementById("countdown");
        const page3Identifier = document.getElementById("dllink");

        const adblockPageIdentifier = document.querySelector(
            "body > div.container.pt-5.page.message > div > div > div"
        );
        const isAdblockPage =
            adblockPageIdentifier?.innerText === "\nAdblock Detected!";

        // If page is recognized, clear the interval to stop checking
        if (
            pageWatcherIntervalId &&
            (page1Identifier ||
                page2Identifier ||
                page3Identifier ||
                isAdblockPage)
        ) {
            log("Page Identified, stopping page watcher");
            clearInterval(pageWatcherIntervalId);
            // identificationRetries = 0;
            // no need to reset retries, as it will be reset on next page load
        }

        if (page1Identifier) {
            handlePage1();
        } else if (page2Identifier) {
            handlePage2();
        } else if (page3Identifier) {
            handlePage3();
        } else if (isAdblockPage) {
            // handleAdblockPage();
            // Not implemented
        } else if (MAX_IDENTIFICATION_RETRIES > identificationRetries) {
            log("Unknown Page or Waiting for identification");
            identificationRetries++;
        } else {
            log("Max Identification Retries Reached, Stopping Page Watcher");
            clearInterval(pageWatcherIntervalId);
        }
    };

    // Keep checking the page as soon as it loads
    let intervalId = setInterval(() => {
        handlePage(intervalId);
    }, 500);
})();