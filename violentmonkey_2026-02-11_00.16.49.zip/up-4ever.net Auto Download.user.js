// ==UserScript==
// @name         up-4ever.net Auto Download
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Automate download process on up-4ever.net
// @author       BlazeFTL
// @match        https://*.up-4ever.net/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function waitForElement(selector, callback, retries = 10) {
        const interval = setInterval(() => {
            const element = document.querySelector(selector);
            if (element) {
                clearInterval(interval);
                callback(element);
            }
            // Retry for a certain number of times in case the element is not immediately available
            if (retries-- <= 0) {
                clearInterval(interval);
                console.error(`Element ${selector} not found`);
            }
        }, 500);  // Check every 500ms
    }

    // Step 1: Click the first button on the first page
    waitForElement(".btn-dark.btn", (button) => {
        console.log("First page button found, clicking...");
        button.click();
    });

    // Step 2: Handle Google CAPTCHA and wait for the download button
    waitForElement(".g-recaptcha", (captcha) => {
    });

    function checkAndClickDownloadButton() {
        const downloadButton = document.querySelector("#downloadbtn");
        if (downloadButton && !downloadButton.disabled) {
            console.log("Download button is enabled, clicking...");
            downloadButton.click();
        } else {
            console.log("Waiting for download button to become enabled...");
            setTimeout(checkAndClickDownloadButton, 1000);
        }
    }

    checkAndClickDownloadButton();

    // Step 3: Final download button on the third page - bypass delay
    waitForElement("#downLoadLinkButton", (downBtn) => {
        console.log("Bypassing the delay and enabling the download button...");
        const finalUrl = downBtn.getAttribute('data-target');
        downBtn.setAttribute('href', finalUrl);
        downBtn.setAttribute('onclick', '');
        downBtn.querySelector('.firstOne').style.display = 'none';
        downBtn.querySelector('.notFirstOne').style.display = 'inline';
        downBtn.classList.remove('btn-secondary');
        downBtn.classList.add('btn-primary');
        downBtn.click();
    });

})();