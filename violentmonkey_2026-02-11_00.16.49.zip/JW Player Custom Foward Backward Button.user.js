// ==UserScript==
// @name         JW Player Custom Foward Backward Button
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Add forward/backward 10s buttons to control bar and edges of display area (transparent background), and fullscreen button to top-right of JW Player with toggle
// @match        https://*.mat6tube.com/*
// @match        https://*.noodlemagazine.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    // --- Helper to inject CSS ---
    function addStyle(css) {
        const style = document.createElement('style');
        style.type = 'text/css';
        style.appendChild(document.createTextNode(css));
        document.head.appendChild(style);
    }

    // --- Inject CSS for button positions and appearance ---
    addStyle(`
        /* Ensure JW Player container is positioned for absolute positioning of top-right button */
        .jwplayer {
             position: relative;
        }

        /* Style for the top-right controls container */
        .jw-top-right-controls {
            position: absolute;
            top: 10px; /* Adjust vertical position as needed */
            right: 10px; /* Adjust horizontal position as needed */
            z-index: 20; /* Increased z-index */
            display: flex;
            gap: 8px; /* Space between potential multiple buttons */
            pointer-events: auto; /* Make container clickable */
        }

        /* Style for the buttons inside the top-right container */
        .jw-top-right-controls button {
            background: rgba(0,0,0,0.5);
            border: none;
            color: white;
            padding: 4px 8px; /* Adjust padding as needed */
            cursor: pointer;
            border-radius: 4px;
            font-size: 16px; /* Adjust size as needed */
            line-height: 1;
            transition: background-color 0.2s ease; /* Smooth hover effect */
        }

         .jw-top-right-controls button:hover {
             background-color: rgba(0,0,0,0.7);
         }

        /* --- Styles for Control Bar Buttons --- */
        /* Find the container holding playback controls (play/pause, volume) */
        .jw-controlbar .jw-button-container {
             /* Ensure flex display if not already - JW player often uses flex */
             display: flex;
             align-items: center;
        }

        /* Style for the custom control bar buttons */
         .jw-controlbar .custom-control-button {
             background: none; /* No background */
             border: none; /* No border */
             color: white; /* White text */
             padding: 0 4px; /* Adjust padding to fit control bar */
             cursor: pointer; /* Indicate it's clickable */
             font-size: 12px; /* Adjust font size to match control bar icons */
             line-height: 1;
             margin-right: 8px; /* Space after the button */
             display: flex; /* Use flex to center text vertically if needed */
             align-items: center; /* Center text vertically */
             transition: color 0.2s ease; /* Smooth hover effect */
         }

         .jw-controlbar .custom-control-button:hover {
             color: #aaaaaa; /* Dim color on hover */
         }

          /* Ensure playback icon has margin if adding buttons next to it */
         .jw-controlbar .jw-icon-playback {
              margin-right: 8px; /* Add margin to separate from new buttons */
         }

         /* --- Styles for Central Display Buttons (positioned at edges) --- */
         /* Ensure the display controls container is positioned for its children */
         .jw-display-controls {
             position: relative; /* Set positioning context for absolute children */
             /* JW Player already handles its children layout,
                we're just using this as the parent for our absolutely positioned buttons */
         }

         /* Common styles for custom buttons in the display area */
         .jw-display-controls .custom-display-button {
            position: absolute; /* Position relative to .jw-display-controls */
            top: 50%; /* Align top edge to the vertical center */
            transform: translateY(-50%); /* Shift button up by half its height to truly center */
            background: transparent; /* Made background transparent */
            border: none;
            color: white;
            padding: 12px 24px; /* Larger padding for bigger buttons */
            cursor: pointer;
            border-radius: 4px;
            font-size: 30px; /* Larger font size */
            z-index: 10; /* Increased z-index to be above common elements */
            transition: background-color 0.2s ease, color 0.2s ease; /* Added color to transition */
            pointer-events: auto !important; /* Ensure clicks are not blocked */
         }

          .jw-display-controls .custom-display-button:hover {
              background-color: rgba(255,255,255,0.1); /* Subtle white background on hover */
              color: #cccccc; /* Dim color on hover */
          }

         /* Specific position for the left display button (further towards edge) */
         .jw-display-controls .custom-display-button-left {
             left: -120%; /* Adjusted distance from the left edge */
         }

         /* Specific position for the right display button (further towards edge) */
         .jw-display-controls .custom-display-button-right {
             right: -120%; /* Adjusted distance from the right edge */
         }
    `);


    function waitForJWPlayer() {
        const check = setInterval(() => {
            // Check for jwplayer function and an instance
            if (typeof jwplayer === 'function') {
                 // Try to get the default player instance or find one by element
                 let playerInstance = jwplayer();
                 if (!playerInstance || typeof playerInstance.getState !== 'function') {
                     // If default instance is not active, look for a specific player element
                     const playerElement = document.querySelector('.jwplayer');
                      if (playerElement && playerElement.id) {
                         playerInstance = jwplayer(playerElement.id);
                      }
                 }

                 if (playerInstance && typeof playerInstance.getState === 'function') {
                    clearInterval(check);
                    enhanceJWPlayer(playerInstance);
                 }
            }
        }, 500);
    }

    function enhanceJWPlayer(player) {
         // Use a MutationObserver to wait for the control bar and display elements to be added
         // The getContainer() method is reliable for finding the player's main div.
        const playerContainer = player.getContainer();

        if (!playerContainer) {
            console.error("JW Player container not found for enhancement.");
            return; // Cannot proceed without the container
        }

        // Observe the player container for changes in its children
        const observer = new MutationObserver((mutations, obs) => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const displayControls = playerContainer.querySelector('.jw-display-controls');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');


            // Check if required elements are present and buttons haven't been added yet
            if (controlBar && displayControls && playButtonContainer && !playerContainer.querySelector('.jw-top-right-controls')) {
                obs.disconnect(); // Stop observing once elements are found and processed
                addButtons(player, playButtonContainer, playerContainer, displayControls); // Pass displayControls container
            }
        });

        // Start observing the player container for child list changes
        observer.observe(playerContainer, { childList: true, subtree: true });

        // Also include a fallback interval check
         const fallbackCheck = setInterval(() => {
            const controlBar = playerContainer.querySelector('.jw-controlbar');
            const displayControls = playerContainer.querySelector('.jw-display-controls');
            const playButtonContainer = playerContainer.querySelector('.jw-controlbar .jw-button-container');

            if (controlBar && displayControls && playButtonContainer && !playerContainer.querySelector('.jw-top-right-controls')) {
                clearInterval(fallbackCheck);
                 // Disconnect observer if the interval check finds elements first
                if(observer) observer.disconnect();
                addButtons(player, playButtonContainer, playerContainer, displayControls); // Pass displayControls container
            }
         }, 1000); // Check less frequently than the observer

    }

    function addButtons(player, playButtonContainer, playerContainer, displayControlsContainer) {
        // Avoid adding buttons multiple times
        if (document.getElementById('jw-custom-controls-controlbar') ||
            document.getElementById('jw-custom-controls-topright') ||
            document.getElementById('jw-custom-controls-display-left') || // Check for specific display buttons
            document.getElementById('jw-custom-controls-display-right')
            ) {
            return;
        }

        // --- Create Control Bar Buttons (Forward/Backward) ---
        const createControlButton = (label, onClick) => {
            const btn = document.createElement('button');
            btn.textContent = label;
            btn.className = 'custom-control-button'; // Use custom class for styling
            btn.addEventListener('click', onClick);
            return btn;
        };

        const rewindBtnControlBar = createControlButton('« 10s', () => {
            const pos = player.getPosition();
            player.seek(Math.max(pos - 10, 0));
        });

        const forwardBtnControlBar = createControlButton('10s »', () => {
            const pos = player.getPosition();
            player.seek(Math.min(pos + 10, player.getDuration()));
        });

        // Find the play/pause icon container in the control bar
        const playPauseButtonControlBar = playButtonContainer.querySelector('.jw-icon-playback');

        if (playPauseButtonControlBar) {
             // Insert the new buttons after the play/pause button within its parent
             playPauseButtonControlBar.parentNode.insertBefore(rewindBtnControlBar, playPauseButtonControlBar.nextSibling);
             playPauseButtonControlBar.parentNode.insertBefore(forwardBtnControlBar, rewindBtnControlBar.nextSibling);
             // Add an ID to the container to mark as processed
             playButtonContainer.parentNode.id = playButtonContainer.parentNode.id || 'jw-custom-controls-controlbar';

        } else {
             // Fallback: just prepend to the control bar button container
             console.warn("Could not find .jw-icon-playback in control bar, prepending buttons to .jw-button-container.");
             playButtonContainer.prepend(forwardBtnControlBar);
             playButtonContainer.prepend(rewindBtnControlBar);
             playButtonContainer.id = playButtonContainer.id || 'jw-custom-controls-controlbar';
        }

        // --- Create Central Display Buttons (positioned at edges) ---
         const createDisplayButton = (label, onClick, className, id) => {
            const btn = document.createElement('button');
            btn.textContent = label;
            btn.className = 'custom-display-button ' + className; // Add common and specific class
             btn.id = id; // Add a unique ID
            btn.addEventListener('click', onClick);
            return btn;
        };

        const rewindBtnDisplay = createDisplayButton(
            '« 10s',
            () => {
                const pos = player.getPosition();
                player.seek(Math.max(pos - 10, 0));
            },
            'custom-display-button-left', // Specific class for left positioning
            'jw-custom-controls-display-left' // Specific ID
        );


        const forwardBtnDisplay = createDisplayButton(
            '10s »',
            () => {
                const pos = player.getPosition();
                player.seek(Math.min(pos + 10, player.getDuration()));
            },
            'custom-display-button-right', // Specific class for right positioning
            'jw-custom-controls-display-right' // Specific ID
        );


        // Append the central buttons directly to the display controls container
         if (displayControlsContainer) {
             displayControlsContainer.appendChild(rewindBtnDisplay);
             displayControlsContainer.appendChild(forwardBtnDisplay);

             // Add an ID to the container itself to indicate processing (optional)
             displayControlsContainer.id = displayControlsContainer.id || 'jw-custom-controls-display-parent';

         } else {
             console.error("Could not find central display controls container (.jw-display-controls).");
         }


        // --- Create Top-Right Fullscreen Button ---
        const topRightControlsContainer = document.createElement('div');
        topRightControlsContainer.id = 'jw-custom-controls-topright';
        topRightControlsContainer.className = 'jw-top-right-controls'; // Use the class defined in CSS

        const fullscreenBtn = document.createElement('button');
        fullscreenBtn.textContent = '⛶'; // Fullscreen icon (can update)
        // Styling handled by .jw-top-right-controls button in CSS

        // Toggle fullscreen state
        fullscreenBtn.addEventListener('click', () => {
            const isFullscreen = player.getFullscreen();
            player.setFullscreen(!isFullscreen);
        });

        // OPTIONAL: Update button icon based on fullscreen state
        player.on('fullscreen', (event) => {
            if (event.fullscreen) {
                fullscreenBtn.textContent = ' minimise'; // Or another exit fullscreen icon
            } else {
                fullscreenBtn.textContent = '⛶'; // Original fullscreen icon '⛶'
            }
        });
        // Also set initial state on load
        if (player.getFullscreen()) {
             fullscreenBtn.textContent = ' minimise';
        }

        topRightControlsContainer.appendChild(fullscreenBtn);

        // Append the top-right container to the main player container
        playerContainer.appendChild(topRightControlsContainer);

        console.log("Custom JW Player buttons added.");
    }

    waitForJWPlayer();
})();
