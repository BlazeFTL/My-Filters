// ==UserScript==
// @name        Audio Playin Background Reddit UserScript
// @namespace   Violentmonkey Scripts
// @match       *://*/*
// @grant       none
// @version     1.0
// @author      -
// @description 1/22/2026, 11:17:12 PM
// ==/UserScript==

function keepAlive() {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = ctx.createOscillator();
    const dst = ctx.createMediaStreamDestination();
    oscillator.connect(dst);
    oscillator.start();
    // This creates a "silent" stream that keeps the context 'running'
}
