// ==UserScript==
// @name         Firefox Background Fix - Heartbeat Method
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Prevents freezing without breaking native XHR/Fetch
// @author       BlazeFTL
// @match        *://*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // --- 1. SILENT AUDIO HEARTBEAT ---
    function startSilentAudio() {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

        // Create a very short buffer to minimize memory
        const frameCount = audioCtx.sampleRate * 0.1;
        const silentBuffer = audioCtx.createBuffer(1, frameCount, audioCtx.sampleRate);

        const playSignal = () => {
            const source = audioCtx.createBufferSource();
            source.buffer = silentBuffer;
            const gainNode = audioCtx.createGain();
            gainNode.gain.value = 0.001; // Nearly silent but active
            source.connect(gainNode);
            gainNode.connect(audioCtx.destination);
            source.start();
            // Loop this every 5 seconds to keep the process priority high
            setTimeout(playSignal, 5000);
        };

        const init = () => {
            audioCtx.resume().then(() => {
                playSignal();
                console.log("Audio Heartbeat Active");
                window.removeEventListener('click', init);
                window.removeEventListener('touchstart', init);
            });
        };

        window.addEventListener('click', init);
        window.addEventListener('touchstart', init);
    }

    // --- 2. WORKER-BASED "KEEPALIVE" (Non-Invasive) ---
    // Instead of overriding setTimeout, we just run a loop in a worker
    // that sends a message to the main thread. This forces the browser
    // to keep the main thread's event loop "warm".
    const workerCode = `
        setInterval(() => {
            self.postMessage('ping');
        }, 1000);
    `;

    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const worker = new Worker(URL.createObjectURL(blob));

    worker.onmessage = function() {
        // This empty pulse keeps the tab from being "idled"
        // by the browser's aggressive power management.
        // We don't need to do anything here.
    };

    // Initialize
    startSilentAudio();

    // Optional: Log to confirm it's running
    console.log("Background Keep-Alive Active (Heartbeat Mode)");
})();
