// ==UserScript==
// @name        Force Native Video Controls (Firefox Android)
// @namespace   your-namespace
// @description Forces native video controls on HTML5 video players in Firefox Android.
// @match       *://*/*
// @grant       none
// @run-at      document-end
// ==/UserScript==

(function() {
    'use strict';

    function forceNativeControls() {
        const videos = document.querySelectorAll('video');
        videos.forEach(video => {
            // Ensure the controls attribute is present
            if (!video.hasAttribute('controls')) {
                video.setAttribute('controls', '');
            }

            // Try to remove attributes or styles that might hide native controls
            // This is a basic attempt and might not work for all websites.
            video.classList.remove('vjs-control-bar'); // Example for Video.js
            video.style.display = '';
            video.style.opacity = '';
            video.style.pointerEvents = '';

            // You might need to add more specific selectors or logic
            // based on the websites you frequently visit.
            // For example, some players might have a specific class on a container element
            // that hides the native controls.
        });
    }

    // Run the function once the document is loaded
    forceNativeControls();

    // Observe for dynamically added video elements (optional but recommended)
    const observer = new MutationObserver(mutationsList => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeName === 'VIDEO') {
                        forceNativeControls();
                    } else if (node.querySelectorAll) {
                        const addedVideos = node.querySelectorAll('video');
                        if (addedVideos.length > 0) {
                            forceNativeControls();
                        }
                    }
                });
            }
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });

})();