// ==UserScript==
// @name         SetUrl Redirector
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically bypasses the intent button on SetUrl.com
// @author       Gemini
// @match        *://seturl.in/*
// @grant        none
// @run-at       document-start
// @icon         https://www.google.com/s2/favicons?sz=64&domain=seturl.com
// ==/UserScript==

(function() {
    'use strict';

    const redirect = () => {
        // Look for the specific anchor tag with the "btn" class and an intent href
        const btn = document.querySelector('a.btn[href^="intent://"]');

        if (btn) {
            const intentUrl = btn.getAttribute('href');

            // Logic: Take everything after intent:// and before #Intent
            // Then prepend https:// to reconstruct the direct URL
            const cleanPath = intentUrl.split('#')[0].replace('intent://', 'https://');

            if (cleanPath) {
                window.location.replace(cleanPath);
            }
        }
    };

    // Run immediately
    redirect();

    // Also run when the DOM is fully loaded in case the button renders late
    window.addEventListener('DOMContentLoaded', redirect);

    // Watch for dynamic changes (optional, for SPA behavior)
    const observer = new MutationObserver(redirect);
    observer.observe(document.body, { childList: true, subtree: true });
})();

