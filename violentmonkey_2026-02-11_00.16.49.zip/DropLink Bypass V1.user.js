// ==UserScript==
// @name         DropLink Bypass V1
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Bypasses article pages by jumping directly between verification stages
// @author       BlazeFTL
// @match        *://tech8s.net/safe2.php*
// @match        *://game5s.com/safe2.php*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const urlParams = new URLSearchParams(window.location.search);
    const linkID = urlParams.get('link');

    if (!linkID) return;

    const hostname = window.location.hostname;

    // STAGE 1: If on tech8s, jump straight to game5s
    if (hostname.includes('tech8s.net')) {
        console.log('Skipping tech8s articles...');
        window.location.replace(`https://game5s.com/safe2.php?link=${linkID}`);
    }

    // STAGE 2: If on game5s, jump straight to the final destination
    else if (hostname.includes('game5s.com')) {
        console.log('Skipping game5s articles...');
        window.location.replace(`https://droplink.co/${linkID}`);
    }
})();

