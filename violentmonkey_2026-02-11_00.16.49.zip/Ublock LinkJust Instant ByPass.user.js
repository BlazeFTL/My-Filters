// ==UserScript==
// @name         Ublock LinkJust Instant ByPass
// @namespace    http://tampermonkey.net/
// @version      1.8
// @description  Instant jumps for early stages, 500ms for final stage, aggressive ID capture
// @author       BlazeFTL
// @match        https://*.to-travel.net/*
// @match        https://*.gold-24.net/*
// @match        https://gold-24.net/*
// @match        https://*.yjiur.xyz/*
// @match        https://yjiur.xyz/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The function that does the work
    function attemptRedirect() {
        const url = window.location.href;
        const match = url.match(/[?&]ViewArticle=([a-zA-Z0-9]+)/);
        const articleId = match ? match[1] : null;

        if (!articleId) return false;

        const host = window.location.hostname;

        // Stage 1 & 2: Instant
        if (host.includes('quest.to-travel.net')) {
            window.stop();
            window.location.replace(`https://journey.to-travel.net/?ViewArticle=${articleId}`);
            return true;
        }
        else if (host.includes('journey.to-travel.net')) {
            window.stop();
            window.location.replace(`https://gold-24.net/?ViewArticle=${articleId}`);
            return true;
        }
        // Stage 3: Instant jump TO yjiur
        else if (host.includes('gold-24.net')) {
            window.stop();
            window.location.replace(`https://yjiur.xyz/?ViewArticle=${articleId}`);
            return true;
        }
        // Stage 4: Final jump with 500ms delay
        else if (host.includes('yjiur.xyz')) {
          window.stop();
            // We do NOT use window.stop() here immediately to allow the timer to run
            setTimeout(() => {
                window.location.replace(`https://linkjust.com/${articleId}`);
            }, 500);
            return true;
        }
        return false;
    }

    // 1. Run immediately
    attemptRedirect();

    // 2. Continuous Monitoring (The "Secret Sauce")
    // This catches the ID if it flickers for even a millisecond
    const monitor = setInterval(() => {
        if (attemptRedirect()) {
            clearInterval(monitor);
        }
    }, 5);

    // Stop checking after 3 seconds to prevent battery drain
    setTimeout(() => clearInterval(monitor), 3000);

})();

