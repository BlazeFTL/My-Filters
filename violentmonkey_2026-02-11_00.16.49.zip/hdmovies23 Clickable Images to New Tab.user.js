// ==UserScript==
// @name         hdmovies23 Clickable Images to New Tab
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Open all images in new tab on click (delayed init)
// @match        *://*.hdmovies23.*/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=hdmovies23.auction
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    setTimeout(() => {
        document.querySelectorAll('p > img').forEach(img => {
            img.style.cursor = 'pointer';
            img.addEventListener('click', () => {
                const a = document.createElement('a');
                a.href = img.src;
                a.target = '_blank';
                a.rel = 'noopener';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            });
        });
    }, 1500);
})();
