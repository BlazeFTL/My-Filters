// ==UserScript==
// @name         KatFile One-Click Download (With Captcha Check)
// @namespace    http://tampermonkey.net/
// @version      3.2
// @description  Handles all KatFile steps with auto-click and captcha detection on 2nd page
// @author       Farhan
// @match        *://katfile.*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    // === Block ad/redirect logic ===
    Object.defineProperty(window, 'download_click', {
        get: () => true,
        set: () => {},
        configurable: true
    });

    Object.defineProperty(window, 'captcha_click', {
        get: () => true,
        set: () => {},
        configurable: true
    });

    window.open = () => null;

    const delayClick = (btn) => {
        if (!btn) return;
        setTimeout(() => btn.click(), 2000);
    };

    const waitForEl = (selector, cb) => {
        const el = document.querySelector(selector);
        if (el) return cb(el);
        const obs = new MutationObserver(() => {
            const el = document.querySelector(selector);
            if (el) {
                obs.disconnect();
                cb(el);
            }
        });
        obs.observe(document.body, { childList: true, subtree: true });
    };

    // Page 1 - Start countdown immediately
    const handlePage1 = () => {
        waitForEl('#m_fbtn1', (btn) => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();

                if (typeof $ === 'function') {
                    let estimated_time = 31;
                    const countdown = () => {
                        if (estimated_time <= 1) {
                            clearTimeout(window._tick);
                            $("#freebtn").click();
                        } else {
                            estimated_time -= 1;
                            $("#txt, #m_txt").slideDown();
                            $(".tt").html("<b>" + estimated_time + "</b>");
                            $(".tt2").html("<b> " + estimated_time + " </b>");
                            window._tick = setTimeout(countdown, 1000);
                        }
                    };
                    countdown();
                }
            }, { once: true });

            delayClick(btn);
        });
    };

    // Page 2 - Submit form after captcha solved
    const handlePage2 = () => {
        const isCaptchaSolved = () => {
            const token = document.querySelector('textarea[name="g-recaptcha-response"]');
            return token && token.value.trim().length > 0;
        };

        const autoClickIfSolved = (btn) => {
            const form = btn.closest('form');
            if (!form) return;

            const clone = btn.cloneNode(true);
            btn.replaceWith(clone);

            clone.addEventListener('click', (e) => {
                e.preventDefault();
                clone.innerText = 'Submitting...';
                form.submit();
            });

            const checkAndClick = () => {
                if (isCaptchaSolved()) {
                    setTimeout(() => clone.click(), 2000);
                } else {
                    setTimeout(checkAndClick, 1000); // re-check every second
                }
            };

            checkAndClick();
        };

        waitForEl('.downloadbtn, #downloadbtn', autoClickIfSolved);
    };

    // Page 3 - Final download form submit
    const handlePage3 = () => {
        waitForEl('#dlink', (btn) => {
            const form = btn.closest('form');
            const clone = btn.cloneNode(true);
            btn.replaceWith(clone);

            clone.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();

                if (form) {
                    form.submit();
                } else {
                    const realLink = document.querySelector('a[href*="/d/"]');
                    if (realLink) {
                        window.location.href = realLink.href;
                    } else {
                        alert('Download link not found.');
                    }
                }
            });

            delayClick(clone);
        });
    };

    const onReady = (cb) => {
        if (document.readyState === 'complete' || document.readyState === 'interactive') cb();
        else document.addEventListener('DOMContentLoaded', cb);
    };

    onReady(() => {
        handlePage1();
        handlePage2();
        handlePage3();
    });

})();
