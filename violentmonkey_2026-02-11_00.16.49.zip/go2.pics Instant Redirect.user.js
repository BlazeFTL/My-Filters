// ==UserScript==
// @name         go2.pics Instant Redirect
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  Decodes the ID and redirects immediately with error handling
// @author       Gemini
// @match        *://go2.pics/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const urlParams = new URLSearchParams(window.location.search);
    let encodedId = urlParams.get('id');

    if (encodedId) {
        try {
            // 1. Fix URL-safe Base64 characters if they exist
            // Replaces '-' with '+' and '_' with '/'
            let base64 = encodedId.replace(/-/g, '+').replace(/_/g, '/');

            // 2. Fix missing padding (atob requires strings to be multiples of 4)
            while (base64.length % 4) {
                base64 += '=';
            }

            // 3. Decode
            const decodedUrl = atob(base64);

            // 4. Validate if it's a real URL before redirecting
            if (decodedUrl.startsWith('http')) {
                window.location.replace(decodedUrl);
            } else {
                console.error("Decoded string is not a valid URL:", decodedUrl);
            }
        } catch (e) {
            console.error("Base64 decoding failed:", e);
        }
    }
})();

