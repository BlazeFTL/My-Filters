// ==UserScript==
// @name         GitHub Load More Comments Normal Slow Use
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  Simple auto-clicker for GitHub "Load more" with a fixed safety delay.
// @author       Gemini
// @match        https://github.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const BUTTON_SELECTOR = '.border-0.color-bg-default.mb-1.mt-0.px-4.pt-0.pb-1.no-underline.ajax-pagination-btn';
    let isWaiting = false;

    const clickLoadMore = () => {
        // If we are already in a cooldown period, do nothing
        if (isWaiting) return;

        const btn = document.querySelector(BUTTON_SELECTOR);

        if (btn) {
            isWaiting = true;

            // Fixed 3-second delay to prevent browser "lock-up"
            setTimeout(() => {
                const targetBtn = document.querySelector(BUTTON_SELECTOR);
                if (targetBtn) {
                    console.log('GitHub Auto-Loader: Loading next batch...');
                    targetBtn.click();
                }
                isWaiting = false;
            }, 3000);
        }
    };

    // Watch for when the button is added back to the page after a fetch
    const observer = new MutationObserver(() => {
        clickLoadMore();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Initial check
    clickLoadMore();
})();

