// ==UserScript==
// @name         DropGalaxy Click On Captcha ByPass
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Stealth bypass of 20s timer with minimal wait and no adblock trigger on financemonk.net intermediate pages before DropGalaxy download button appears.
// @author       BlazeFTL
// @match        *://financemonk.net/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const log = (...args) => console.log('[Bypass]', ...args);

    function simulateFlow() {
        log('Simulating legit behavior...');

        // Fix values expected to be non-adblock
        const setVal = (id, val) => {
            let el = document.getElementById(id);
            if (el) el.value = val;
        };

        // Simulate expected values
        setVal("adblock_check", "0");
        setVal("adblock_detected", "0");
        setVal("adb", "0");
        setVal("dropgalaxyisbest", "1");
        setVal("adsns", "1");
        setVal("admaven_popup", "1");

        // Fake what AJAX would populate
        fetch('https://dg.a2zupload.com/dlhash.php')
            .then(resp => resp.text())
            .then(data => {
                document.getElementById("ipp").value = data;
                log("Set ipp:", data);

                // Simulate what happens after 13s (turnstile & button enable)
                setTimeout(() => {
                    // Trigger CAPTCHA manually
                    if (typeof turnstile !== 'undefined' && turnstile.render) {
                        log("Rendering Turnstile CAPTCHA...");
                        turnstile.render('#cfcaptcha', {
                            sitekey: '0x4AAAAAAAYwfzxMEjmxM8RT',
                            callback: function (token) {
                                document.getElementById("tokennstatus").innerHTML = '<small>being verified, please wait..</small>';
                                if (typeof bangbang === 'function') bangbang(token);
                                log("Captcha token:", token);
                            }
                        });
                    }

                    // Enable button
                    document.querySelectorAll('.downloadbtn').forEach(btn => {
                        btn.disabled = false;
                        btn.removeAttribute("disabled");
                    });

                    // Hide timer
                    const sec = document.querySelector('.seconds');
                    if (sec) sec.style.display = "none";

                    log("Download button unlocked.");
                }, 4000); // 4 seconds instead of 13–20
            });
    }

    window.addEventListener('load', () => {
        setTimeout(simulateFlow, 500); // short delay to allow page JS to finish
    });
})();
