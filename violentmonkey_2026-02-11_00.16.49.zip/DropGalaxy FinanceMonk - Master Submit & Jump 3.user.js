// ==UserScript==
// @name         DropGalaxy FinanceMonk - Master Submit & Jump 3
// @namespace    BlazeFTL.Scripts
// @version      1.5
// @description  Submits forms and jumps to DropGalaxy using fileid cookie
// @author       BlazeFTL
// @match        https://financemonk.net/*
// @run-at       document-end
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1. Extract the fileid cookie immediately
    const getFileId = () => {
        const name = "fileid=";
        const decodedCookie = decodeURIComponent(document.cookie);
        const ca = decodedCookie.split(';');
        for(let i = 0; i < ca.length; i++) {
            let c = ca[i].trim();
            if (c.indexOf(name) === 0) {
                return c.substring(name.length, c.length);
            }
        }
        return null;
    };

    // 2. Create the button
    const btn = document.createElement("button");
    btn.innerHTML = "🚀 SUBMIT ALL & JUMP";

    // Style
    Object.assign(btn.style, {
        position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)',
        zIndex: '999999', padding: '15px 30px', backgroundColor: '#28a745',
        color: 'white', border: 'none', borderRadius: '5px', fontSize: '20px',
        fontWeight: 'bold', cursor: 'pointer', boxShadow: '0 4px 15px rgba(0,0,0,0.4)'
    });

    btn.onclick = function() {
        const fileId = getFileId();

        if (!fileId) {
            console.error("Cookie 'fileid' not found.");
            alert("Cookie 'fileid' not found! Check if you are logged in or if the link generated correctly.");
            return;
        }

        const targetURL = "https://dropgalaxy.com/disk/" + fileId;
        console.log("BlazeFTL: Target detected -> " + targetURL);

        // Submit forms
        const forms = document.querySelectorAll('form');
        forms.forEach(f => {
            try { f.submit(); } catch(e) { console.error("Form submit failed", e); }
        });

        // Click submit buttons
        const submitters = document.querySelectorAll('input[type="submit"]');
        submitters.forEach(s => {
            try { s.click(); } catch(e) { console.error("Button click failed", e); }
        });

        // Redirect
        setTimeout(() => {
            window.location.href = targetURL;
        }, 1000);
    };

    document.body.appendChild(btn);

})();

