// ==UserScript==
// @name         Domain Checker (Order Safe + Wildcard + Dual Output)
// @namespace    vm-domain-checker-pro
// @version      1.6
// @description  DNS checker that preserves original order, skips wildcards, and outputs cleaned lists
// @match        *://example.com/*
// @grant        GM_addStyle
// ==/UserScript==

(function () {
  'use strict';

  GM_addStyle(`
    #vmBox {
      position: fixed;
      top: 20px;
      right: 20px;
      width: 380px;
      background: #111;
      color: #eee;
      border-radius: 8px;
      padding: 10px;
      z-index: 999999;
      font-family: monospace;
      box-shadow: 0 0 12px rgba(0,0,0,.6);
    }
    #vmBox textarea {
      width: 100%;
      background: #000;
      color: #0f0;
      border: 1px solid #333;
      resize: vertical;
      margin-top: 4px;
    }
    #vmBox button {
      margin-top: 6px;
      margin-right: 4px;
      padding: 4px 8px;
      background: #333;
      color: #fff;
      border: 1px solid #555;
      cursor: pointer;
    }
    #vmBox button:disabled {
      opacity: 0.4;
      cursor: not-allowed;
    }
    #vmOut {
      margin-top: 6px;
      max-height: 160px;
      overflow: auto;
      white-space: pre-wrap;
    }
    .dead { color: #f55; }
    .live { color: #5f5; }
    .skip { color: #ffb347; }
    .note { color: #aaa; }
  `);

  const box = document.createElement('div');
  box.id = 'vmBox';
  box.innerHTML = `
    <b>Domain Checker</b>
    <textarea id="vmInput" rows="3" placeholder="abc.com,acb.com | 0123movie.*"></textarea>
    <div>
      <button id="vmCheck">Check</button>
      <button id="vmClear">Clear</button>
    </div>

    <div id="vmOut" class="note">Idle.</div>

    <b>Working domains (comma):</b>
    <textarea id="vmComma" rows="2" readonly></textarea>
    <button id="copyComma" disabled>Copy ,</button>

    <b>Working domains (pipe):</b>
    <textarea id="vmPipe" rows="2" readonly></textarea>
    <button id="copyPipe" disabled>Copy |</button>
  `;
  document.body.appendChild(box);

  const input = box.querySelector('#vmInput');
  const out = box.querySelector('#vmOut');
  const commaBox = box.querySelector('#vmComma');
  const pipeBox = box.querySelector('#vmPipe');
  const copyComma = box.querySelector('#copyComma');
  const copyPipe = box.querySelector('#copyPipe');
  const checkBtn = box.querySelector('#vmCheck');
  const clearBtn = box.querySelector('#vmClear');

  copyComma.onclick = () => navigator.clipboard.writeText(commaBox.value);
  copyPipe.onclick = () => navigator.clipboard.writeText(pipeBox.value);

  clearBtn.onclick = () => {
    input.value = '';
    out.textContent = 'Idle.';
    commaBox.value = '';
    pipeBox.value = '';
    copyComma.disabled = true;
    copyPipe.disabled = true;
  };

  checkBtn.onclick = async () => {
    out.textContent = 'Checking...';
    commaBox.value = '';
    pipeBox.value = '';
    copyComma.disabled = true;
    copyPipe.disabled = true;

    const original = input.value
      .split(/[,\|\s]+/)
      .map(d => d.trim())
      .filter(Boolean);

    if (!original.length) {
      out.innerHTML = `<span class="note">No domains provided.</span>`;
      return;
    }

    // Prepare DNS checks only for non-wildcards
    const dnsMap = new Map();

    const checks = original
      .filter(d => !d.includes('.*'))
      .map(d =>
        fetch(`https://dns.google/resolve?name=${d}&type=A`)
          .then(r => r.json())
          .then(j => dnsMap.set(d, !!j.Answer))
          .catch(() => dnsMap.set(d, false))
      );

    await Promise.all(checks);

    const finalDomains = [];
    out.textContent = '';

    // 🔥 ORDER PRESERVATION LOGIC
    for (const d of original) {
      if (d.includes('.*')) {
        out.innerHTML += `<span class="skip">⏭ SKIPPED (wildcard)  ${d}</span>\n`;
        finalDomains.push(d);
      } else if (dnsMap.get(d)) {
        out.innerHTML += `<span class="live">✅ LIVE  ${d}</span>\n`;
        finalDomains.push(d);
      } else {
        out.innerHTML += `<span class="dead">❌ DEAD  ${d}</span>\n`;
      }
    }

    if (finalDomains.length === 0) {
      commaBox.value = '# none (all domains are dead)';
      pipeBox.value = '# none (all domains are dead)';
    } else {
      commaBox.value = finalDomains.join(',');
      pipeBox.value = finalDomains.join('|');
      copyComma.disabled = false;
      copyPipe.disabled = false;
    }
  };
})();
