// ==UserScript==
// @name         Upfion Auto-Downloader (Enhanced)
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Automates steps on upfion.com with improved Page 1 reliability
// @author       BlazeFTL
// @match        *://upfion.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // --- Helper Functions ---

    const clickSel = (selector) => {
        const el = document.querySelector(selector);
        if (el && typeof el.click === 'function') {
            el.click();
            return true;
        }
        return false;
    };

    const waitForElement = (xpath) => {
        return new Promise((resolve) => {
            const check = () => {
                const result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                if (result) {
                    resolve(result);
                } else {
                    setTimeout(check, 500);
                }
            };
            check();
        });
    };

    function captchaSolved(callback, onWait = () => {}) {
        let intervalId;
        let isResolved = false;

        const stopChecking = () => {
            isResolved = true;
            clearInterval(intervalId);
        };

        const handleSuccess = () => {
            if (isResolved) return;
            stopChecking();
            callback();
        };

        waitForElement("//div[contains(@class, 'iconcaptcha-modal__body-title') and contains(., 'Verification complete.')] | //*[@id='captcha-result' and contains(., 'Verified!')]")
            .then(handleSuccess);

        const checkCaptcha = () => {
            if (isResolved) return;
            try {
                const captcha = window.turnstile || window.hcaptcha || window.grecaptcha;
                if (captcha && typeof captcha.getResponse === 'function') {
                    if (captcha.getResponse()?.length > 0) {
                        handleSuccess();
                    }
                }
            } catch (error) {}
            onWait(stopChecking);
        };

        checkCaptcha();
        intervalId = setInterval(checkCaptcha, 1000);
    }

    const clickAfterCaptcha = (selector) => captchaSolved(() => clickSel(selector));

    // --- Main Logic ---

    // Page 1: Initial Free Download Button (With Retry Logic)
    const page1Btn = "#free-download-form > .btn-primary";
    const retryClick = setInterval(() => {
        if (clickSel(page1Btn)) {
            // We don't clear the interval here because the page should navigate away.
            // If it doesn't navigate, it keeps trying to click.
        }
    }, 1000); // Tries every 1 second

    // Page 2: Captcha Page
    const page2Btn = ".btn-captcha.btn-primary.btn";
    if (document.querySelector(page2Btn)) {
        clearInterval(retryClick); // Stop page 1 retries if we are on page 2
        clickAfterCaptcha(page2Btn);
    }

    // Page 3: Final Link Page
    const page3Btn = ".my-2.get-link.btn-download.btn-primary.btn";
    const finalBtn = document.querySelector(page3Btn);
    if (finalBtn) {
        clearInterval(retryClick);
        const observer = new MutationObserver(() => {
            if (!finalBtn.hasAttribute('disabled')) {
                finalBtn.click();
                observer.disconnect();
            }
        });
        observer.observe(finalBtn, { attributes: true });
        if (!finalBtn.hasAttribute('disabled')) {
            finalBtn.click();
        }
    }

})();

