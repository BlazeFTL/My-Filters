// ==UserScript==
// @name         Background Timer + Audio Keep-Alive (CF Safe)
// @namespace    http://tampermonkey.net/
// @version      2.1
// @description  Prevents background freezing using Worker timers + silent audio, but fully disables itself during Cloudflare verification
// @author       BlazeFTL
// @match        *://*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    /*****************************************************************
     *  PART 0 — CLOUDFLARE DETECTION (HARD BLOCK)
     *****************************************************************/
    function isCloudflareActive() {
        return (
            location.hostname === 'cloudflare.com' ||
            document.documentElement.innerHTML.includes('/cdn-cgi/challenge') ||
            document.querySelector('iframe[src*="cloudflare"]')
        );
    }

    if (isCloudflareActive()) {
        console.warn('[BG-FIX] Cloudflare detected → script dormant');

        // Wait until CF disappears, then activate
        const cfWait = setInterval(() => {
            if (!isCloudflareActive()) {
                clearInterval(cfWait);
                console.log('[BG-FIX] Cloudflare passed → activating script');
                init();
            }
        }, 500);

        return; // 🔒 ABSOLUTE STOP during CF
    }

    /*****************************************************************
     *  MAIN INITIALIZER
     *****************************************************************/
    function init() {
        startSilentAudio();
        installWorkerTimers();
        console.log('[BG-FIX] Background Fix Active (Worker + Audio)');
    }

    /*****************************************************************
     *  PART 1 — SILENT AUDIO KEEP-ALIVE
     *****************************************************************/
    function startSilentAudio() {
        let audioCtx;
        let started = false;

        function unlock() {
            if (started) return;
            started = true;

            audioCtx = new (window.AudioContext || window.webkitAudioContext)();

            const source = audioCtx.createBufferSource();
            const buffer = audioCtx.createBuffer(1, 44100, 44100);
            source.buffer = buffer;
            source.loop = true;

            const gain = audioCtx.createGain();
            gain.gain.value = 0;

            source.connect(gain);
            gain.connect(audioCtx.destination);

            audioCtx.resume().then(() => {
                source.start();
                console.log('[BG-FIX] Silent audio heartbeat started');
            });

            window.removeEventListener('click', unlock);
            window.removeEventListener('touchstart', unlock);
        }

        window.addEventListener('click', unlock, { once: true });
        window.addEventListener('touchstart', unlock, { once: true });
    }

    /*****************************************************************
     *  PART 2 — WEB WORKER TIMER ENGINE
     *****************************************************************/
    function installWorkerTimers() {
        const workerCode = `
            const timers = {};
            self.onmessage = e => {
                const { type, id, delay } = e.data;
                if (type === 'timeout') {
                    setTimeout(() => postMessage(id), delay);
                } else if (type === 'interval') {
                    timers[id] = setInterval(() => postMessage(id), delay);
                } else if (type === 'clear') {
                    clearInterval(timers[id]);
                    delete timers[id];
                }
            };
        `;

        const blob = new Blob([workerCode], { type: 'application/javascript' });
        const worker = new Worker(URL.createObjectURL(blob));

        const callbacks = {};
        let uid = 0;

        worker.onmessage = e => {
            callbacks[e.data]?.();
        };

        // Store native refs (important)
        const nativeSetTimeout = window.setTimeout;
        const nativeSetInterval = window.setInterval;
        const nativeClearTimeout = window.clearTimeout;
        const nativeClearInterval = window.clearInterval;

        window.setTimeout = function (fn, delay = 0) {
            const id = ++uid;
            callbacks[id] = () => {
                fn();
                delete callbacks[id];
            };
            worker.postMessage({ type: 'timeout', id, delay });
            return id;
        };

        window.setInterval = function (fn, delay = 0) {
            const id = ++uid;
            callbacks[id] = fn;
            worker.postMessage({ type: 'interval', id, delay });
            return id;
        };

        window.clearTimeout = window.clearInterval = function (id) {
            worker.postMessage({ type: 'clear', id });
            delete callbacks[id];
        };

        // Safety: restore native timers on unload
        window.addEventListener('beforeunload', () => {
            window.setTimeout = nativeSetTimeout;
            window.setInterval = nativeSetInterval;
            window.clearTimeout = nativeClearTimeout;
            window.clearInterval = nativeClearInterval;
        });
    }

    // Immediate init if no CF
    init();

})();