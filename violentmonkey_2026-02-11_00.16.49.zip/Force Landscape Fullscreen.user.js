// ==UserScript==
// @name         Force Landscape Fullscreen
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically rotates screen to landscape when a video goes fullscreen
// @author       BlazeFTL
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.addEventListener('fullscreenchange', function() {
        if (document.fullscreenElement) {
            // Attempt to lock orientation to landscape
            if (screen.orientation && screen.orientation.lock) {
                screen.orientation.lock('landscape').catch(function(error) {
                    console.log("Orientation lock failed: " + error);
                });
            }
        } else {
            // Unlock orientation when exiting fullscreen
            if (screen.orientation && screen.orientation.unlock) {
                screen.orientation.unlock();
            }
        }
    });
})();

