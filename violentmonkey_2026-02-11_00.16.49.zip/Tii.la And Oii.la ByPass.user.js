// ==UserScript==
// @name         Tii.la And Oii.la ByPass
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically decode base64 URL from token input and redirect (supports = and safe domains only)
// @author       Farhan
// @match        *://tii.la/*
// @match        *://oko.sh/*
// @match        *://ckk.ai/*
// @match        *://oei.la/*
// @match        *://lnbz.la/*
// @match        *://iir.la/*
// @match        *://tvi.la/*
// @match        *://oii.la/*
// @match        *://tpi.li/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function findBase64Url(token) {
        // Looks for a Base64 string starting with 'aHR0' (i.e., https)
        const match = token.match(/(aHR0c[a-zA-Z0-9+/=]+)/);
        return match ? match[1] : null;
    }

    function tryRedirect() {
        const input = document.querySelector('input[name="token"]');
        if (!input) return;

        const token = input.value;
        const base64 = findBase64Url(token);

        if (base64) {
            try {
                const decodedUrl = atob(base64);
                if (decodedUrl.startsWith('http')) {
                    console.log("Redirecting to:", decodedUrl);
                    window.location.href = decodedUrl;
                } else {
                    console.warn("Decoded string is not a valid URL:", decodedUrl);
                }
            } catch (err) {
                console.error("Base64 decoding error:", err);
            }
        } else {
            console.warn("No Base64 URL found.");
        }
    }

    window.addEventListener('load', () => {
        setTimeout(tryRedirect, 300); // Wait for the DOM to fully render
    });
})();
