// ==UserScript==
// @name         Mega.nz Tab Title Setter
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Sets tab title based on <h1 class="heading"> content on Mega.nz
// @author       BlazeFTL
// @match        https://mega.nz/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const setTitleFromHeading = () => {
        const heading = document.querySelector('h1.heading');
        if (heading && heading.textContent.trim()) {
            document.title = heading.textContent.trim();
        }
    };

    // Try setting title once DOM is loaded
    document.addEventListener('DOMContentLoaded', setTitleFromHeading);

    // In case Mega loads it later with JS
    const observer = new MutationObserver(setTitleFromHeading);
    observer.observe(document.body, { childList: true, subtree: true });
})();
