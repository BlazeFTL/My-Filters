// ==UserScript==
// @name         StreamA2z Downloader
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Auto-detect HLS source and add download buttons
// @match        https://smartkhabrinews.com/*
// @grant        GM_xmlhttpRequest
// @connect      *
// ==/UserScript==

(function () {
    'use strict';

    let hlsUrl = null;

    const interceptHls = () => {
        const originalLoadSource = Hls.prototype.loadSource;
        Hls.prototype.loadSource = function (url) {
            hlsUrl = url;
            console.log('[HLS Intercept] Detected:', url);
            if (!document.getElementById('hls-dl-ui')) {
                parseM3U8(url).then(variants => showButtons(variants));
            }
            return originalLoadSource.call(this, url);
        };
    };

    const parseM3U8 = (url) => {
        return new Promise((resolve) => {
            GM_xmlhttpRequest({
                method: "GET",
                url,
                onload: (res) => {
                    const base = url.substring(0, url.lastIndexOf('/') + 1);
                    const matches = [...res.responseText.matchAll(/#EXT-X-STREAM-INF:.*RESOLUTION=\d+x(\d+).*?\n(.*)/g)];
                    const variants = matches.map(([, res, path]) => ({
                        resolution: res + 'p',
                        url: path.startsWith('http') ? path : base + path.trim()
                    }));
                    resolve(variants);
                }
            });
        });
    };

    const showButtons = (streams) => {
        const panel = document.createElement('div');
        panel.id = 'hls-dl-ui';
        Object.assign(panel.style, {
            position: 'fixed',
            top: '10px',
            right: '10px',
            zIndex: 9999,
            background: '#111',
            padding: '12px',
            borderRadius: '8px',
            color: '#fff',
            fontFamily: 'sans-serif',
            fontSize: '14px',
            boxShadow: '0 0 10px rgba(0,0,0,0.5)'
        });

        const title = document.createElement('div');
        title.textContent = 'Download Video';
        title.style.marginBottom = '8px';
        panel.appendChild(title);

        streams.forEach(({ resolution, url }) => {
            const a = document.createElement('a');
            a.textContent = resolution;
            a.href = url;
            a.download = '';
            a.style.display = 'block';
            a.style.color = '#0ff';
            a.style.marginBottom = '6px';
            a.style.textDecoration = 'underline';
            a.target = '_blank';
            panel.appendChild(a);
        });

        document.body.appendChild(panel);
    };

    const waitForHls = () => {
        const interval = setInterval(() => {
            if (typeof Hls !== 'undefined') {
                clearInterval(interval);
                interceptHls();
            }
        }, 300);
    };

    waitForHls();
})();
