// ==UserScript==
// @name         Lksfy.com & Anyshorturl Cookie Redirect
// @namespace    https://tampermonkey.net/
// @version      1.2
// @description  Read site-specific cookie and redirect using host.includes
// @match        https://*/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function getCookie(name) {
        const cookies = document.cookie.split('; ');
        for (const c of cookies) {
            if (c.startsWith(name + '=')) {
                return c.substring(name.length + 1);
            }
        }
        return null;
    }

    const host = location.hostname;

    // wblaxmibhandar → alias → lksfy.com
    if (host.includes('wblaxmibhandar')) {
        const value = getCookie('alias');
        if (value) {
            location.href = 'https://lksfy.com/' + value;
        }
    }

    // hamaariyojana → sgutech → anyshorturl.com
    if (host.includes('hamaariyojana')) {
        const value = getCookie('mycoding-tools-made');
        if (value) {
            location.href = 'https://anyshorturl.com/' + value;
        }
    }
})();