// ==UserScript==
// @name         Ublock XTGLinks Instant ByPass
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Chain redirect from 7vibelife -> mealcold -> xtglinks
// @author       BlazeFTL
// @match        https://7vibelife.com/*
// @match        https://mealcold.com/prolink.php?id=*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    const currentUrl = window.location.href;
    const urlParams = new URLSearchParams(window.location.search);

    // --- STEP 1: If on 7vibelife ---
    if (currentUrl.includes("7vibelife.com")) {
        const token = urlParams.get('token');
        if (token) {
            window.stop();
            console.log("Stage 1: Redirecting to mealcold...");
            setTimeout(() => {
                window.location.replace(`https://mealcold.com/prolink.php?id=${token}`);
            }, 100);
        }
    }

    // --- STEP 2: If on mealcold ---
    else if (currentUrl.includes("mealcold.com")) {
        const id = urlParams.get('id');
        if (id) {
            window.stop();
            console.log("Stage 2: Redirecting to xtglinks...");
            setTimeout(() => {
                window.location.replace(`https://xtglinks.com/${id}`);
            }, 100);
        }
    }

})();

