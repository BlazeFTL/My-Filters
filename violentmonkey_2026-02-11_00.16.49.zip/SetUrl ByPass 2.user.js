// ==UserScript==
// @name         SetUrl ByPass 2
// @namespace    http://tampermonkey.net/
// @version      1.4
// @description  Automatically detects domains from @match lines
// @author       BlazeFTL
// @match        https://houseloanoffers.com/*
// @match        https://proseware.in/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // 1. Get domains directly from the @match lines above
    // This creates an array: ["houseloanoffers.com", "proseware.in"]
    const matches = GM_info.script.matches.map(m => new URL(m).hostname);

    const firstDomain  = matches[0]; // houseloanoffers.com
    const middleDomain = matches[1]; // proseware.in
    const finalTarget  = "set.seturl.in"; // The hardcoded final destination

    // 2. Capture the 'web' parameter
    const params = new URLSearchParams(window.location.search);
    const webValue = params.get('web');
    if (!webValue) return;

    const host = window.location.hostname;

    // Logic Flow
    // Step 1: If on the first domain in @match -> go to the second domain
    if (host.includes(firstDomain)) {
        setTimeout(() => {
            window.location.replace(`https://${middleDomain}/?web=${webValue}`);
        }, 100);
    }

    // Step 2: If on the second domain in @match -> go to finalTarget
    else if (host.includes(middleDomain)) {
        window.stop();
        setTimeout(() => {
            window.location.replace(`https://${finalTarget}/${webValue}`);
        }, 100);
    }
})();

