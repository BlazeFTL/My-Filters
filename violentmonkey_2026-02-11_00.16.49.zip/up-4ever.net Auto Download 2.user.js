// ==UserScript==
// @name         up-4ever.net Auto Download 2
// @namespace    http://tampermonkey.net/
// @version      1.6
// @description  Automate download process on up-4ever.net
// @author       BlazeFTL
// @match        https://*.up-4ever.net/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    function waitForElement(selector, callback, retries = 20) {
        const interval = setInterval(() => {
            let element;
            // Check if it's an Xpath or a CSS selector
            if (selector.startsWith('//') || selector.startsWith('(')) {
                element = document.evaluate(selector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
            } else {
                element = document.querySelector(selector);
            }

            if (element) {
                clearInterval(interval);
                callback(element);
            }
            if (retries-- <= 0) {
                clearInterval(interval);
                console.log(`Searching for ${selector}...`);
            }
        }, 1000);
    }

    // --- Captcha Detection Logic ---
    function captchaSolved(callback) {
        let isResolved = false;

        const handleSuccess = () => {
            if (isResolved) return;
            isResolved = true;
            console.log("Captcha solved detected!");
            callback();
        };

        // 1. DOM/Xpath detection
        waitForElement("//div[contains(@class, 'iconcaptcha-modal__body-title') and contains(., 'Verification complete.')] | //*[@id='captcha-result' and contains(., 'Verified!')]", handleSuccess);

        // 2. API-based detection (Interval)
        const checkInterval = setInterval(() => {
            if (isResolved) return clearInterval(checkInterval);
            try {
                const captcha = window.turnstile || window.hcaptcha || window.grecaptcha;
                if (captcha && typeof captcha.getResponse === 'function') {
                    if (captcha.getResponse()?.length > 0) {
                        handleSuccess();
                    }
                }
            } catch (e) {}
        }, 1000);
    }

    // --- Execution Steps ---

    // Step 1: Click the "Free Download" button
    waitForElement(".btn-dark.btn", (button) => {
        console.log("First page button found, clicking...");
        button.click();
    });

    // Step 2: Detect Captcha and then Click Download
    const downloadBtnSelector = "#downloadbtn";

    // Check if we are on the page with the download button
    if (document.querySelector('.g-recaptcha') || document.querySelector('#downloadbtn')) {
        console.log("Monitoring captcha status...");
        captchaSolved(() => {
            waitForElement(downloadBtnSelector, (btn) => {
                if (!btn.disabled) {
                    btn.click();
                } else {
                    // If button is still disabled by a timer, wait for it
                    const timerCheck = setInterval(() => {
                        if (!btn.disabled) {
                            btn.click();
                            clearInterval(timerCheck);
                        }
                    }, 500);
                }
            });
        });
    }

    // Step 3: Final download button bypass
    waitForElement("#downLoadLinkButton", (downBtn) => {
        console.log("Bypassing final delay...");
        const finalUrl = downBtn.getAttribute('data-target');
        if (finalUrl) {
            downBtn.setAttribute('href', finalUrl);
            downBtn.setAttribute('onclick', '');

            const first = downBtn.querySelector('.firstOne');
            const second = downBtn.querySelector('.notFirstOne');
            if (first) first.style.display = 'none';
            if (second) second.style.display = 'inline';

            downBtn.classList.remove('btn-secondary');
            downBtn.classList.add('btn-primary');
            downBtn.click();
        }
    });

})();

