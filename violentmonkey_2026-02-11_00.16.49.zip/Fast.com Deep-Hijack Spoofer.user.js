// ==UserScript==
// @name         Fast.com Deep-Hijack Spoofer
// @namespace    http://tampermonkey.net/
// @version      1.9
// @description  Intercepts and overwrites the site's own text nodes to prevent original speeds from showing.
// @author       BlazeFTL
// @match        https://fast.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const STAGES = [
        { time: 0.0, speed: 1.0 },
        { time: 0.2, speed: 1.4 },
        { time: 0.4, speed: 1.9 },
        { time: 0.6, speed: 2.5 },
        { time: 0.8, speed: 3.1 },
        { time: 1.0, speed: 3.4 }
    ];

    const DURATION = 7000;
    let startTime = null;
    let spoofActive = false;
    let currentSpoofValue = "1.0";

    function startAnimation() {
        if (spoofActive) return;
        spoofActive = true;
        startTime = Date.now();

        function update() {
            const elapsed = Date.now() - startTime;
            const progress = Math.min(elapsed / DURATION, 1);

            let start = STAGES[0];
            let end = STAGES[STAGES.length - 1];

            for (let i = 0; i < STAGES.length - 1; i++) {
                if (progress >= STAGES[i].time && progress <= STAGES[i+1].time) {
                    start = STAGES[i];
                    end = STAGES[i+1];
                    break;
                }
            }

            const segProgress = (progress - start.time) / (end.time - start.time);
            currentSpoofValue = (start.speed + (end.speed - start.speed) * segProgress).toFixed(1);

            // Directly find the real elements and force the text
            const valElem = document.getElementById('speed-value');
            const unitElem = document.getElementById('speed-units');

            if (valElem) {
                valElem.textContent = currentSpoofValue;
                valElem.style.opacity = "1"; // Ensure it stays visible
            }
            if (unitElem) {
                unitElem.textContent = "Gbps";
                unitElem.style.opacity = "1";
            }

            if (progress < 1) {
                requestAnimationFrame(update);
            } else {
                currentSpoofValue = "3.4";
                if (valElem) valElem.classList.add('succeeded');
            }
        }
        requestAnimationFrame(update);
    }

    // This observer watches for ANY change to the speed text and immediately resets it
    const observer = new MutationObserver(() => {
        const valElem = document.getElementById('speed-value');
        const unitElem = document.getElementById('speed-units');

        if (valElem) {
            if (!spoofActive) startAnimation();

            // If the site tried to change the text to your real speed, change it back
            if (valElem.textContent !== currentSpoofValue) {
                valElem.textContent = currentSpoofValue;
            }
        }
        if (unitElem && unitElem.textContent !== "Gbps") {
            unitElem.textContent = "Gbps";
        }
    });

    // Start observing the whole document for changes
    observer.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true
    });

    // Final fallback: A high-speed heartbeat to prevent the real speed from flickering in
    setInterval(() => {
        const valElem = document.getElementById('speed-value');
        if (valElem && spoofActive) {
            valElem.textContent = currentSpoofValue;
            document.getElementById('speed-units').textContent = "Gbps";
        }
    }, 50);

})();
