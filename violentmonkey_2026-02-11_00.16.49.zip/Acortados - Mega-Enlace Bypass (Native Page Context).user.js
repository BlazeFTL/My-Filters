// ==UserScript==
// @name         Acortados / Mega-Enlace Bypass (Native Page Context)
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Bypass interstitials and auto-submit forms on acortados.com, desbloquea.me, mega-enlace.com like AdGuard rules do
// @author       BlazeFTL
// @match        *://acortados.com/*
// @match        *://desbloquea.me/*
// @match        *://mega-enlace.com/*
// @match        *://tulink.org/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    const script = document.createElement('script');
    script.textContent = '(' + (function () {
        'use strict';

        function bypass(formHtml) {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "/check.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhr.send("a");

            const decoded = atob(window.ext_site).replace(/[a-z]/gi, c =>
                String.fromCharCode(c.charCodeAt(0) + (c.toLowerCase() <= "m" ? 13 : -13))
            );

            let cleanedHtml = formHtml.replaceAll('\\"', '"');
            cleanedHtml = cleanedHtml.replace("'+ api_key+ '", window.api_key);
            cleanedHtml = cleanedHtml.replace("'+ link_out+ \"", window.link_out);
            cleanedHtml = cleanedHtml.replace(/action="'\+ .*?\+ '"/, `action="${decoded}"`);

            const parser = new DOMParser();
            const form = parser.parseFromString(cleanedHtml, "text/html").querySelector("form");
            const formData = new FormData(form);

            const submitXhr = new XMLHttpRequest();
            submitXhr.open("POST", decoded, true);
            submitXhr.send(formData);

            window.tab2 = window;
            postMessage("_clicked_b", location.origin);
        }

        const handler = {
            apply(target, thisArg, argumentsList) {
                let arg = argumentsList[1]; // CHANGED from const to let

                if (arg && arg.includes("api_key")) {
                    try {
                        const apiKey = window.api_key;
                        const linkOut = window.link_out;

                        const matches = arg.match(/window\.open\(.*?\(atob\(main_site\)\).*?("\/.*\.php\?.*=").*?("&.*?=").*?(api_key),"view"/);
                        if (!matches) return Reflect.apply(target, thisArg, argumentsList);

                        const phpPath = matches[1];
                        const params = matches[2];
                        const formHtml = arg.match(/<form target=[\s\S]*?<\/form>/)[0];

                        arg = arg.replace("window.location.href", "var nulled");
                        arg = arg.replace("window.open(f", "location.assign(f)");
                        arg = arg.replace(/(parseInt\(c\.split\("-"\)\[0\]\)<= 0).*?(\)\{)/,"$1$2");

                        if (linkOut && apiKey && phpPath && params && formHtml) {
                            if (document.readyState === "loading") {
                                window.addEventListener("load", () => bypass(formHtml), { once: true });
                            } else {
                                bypass(formHtml);
                            }
                        }
                    } catch (e) {
                        console.debug(e);
                    }
                }

                return Reflect.apply(target, thisArg, argumentsList);
            }
        };

        window.Function.prototype.constructor = new Proxy(window.Function.prototype.constructor, handler);
    }).toString() + ')();';

    document.documentElement.appendChild(script);
})();
