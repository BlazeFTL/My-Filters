// ==UserScript==
// @name         Ublock Lksfy ByPass
// @namespace    https://tampermonkey.net/
// @version      1.4
// @description  Prevent site redirect and send id directly to Lksfy Last Page
// @match        https://*.sharclub.in/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    'use strict';
    window.stop();
    const url = new URL(location.href);
    const id = url.searchParams.get("id");

    if (id) {
        setTimeout(() => {
            location.replace("https://lksfy.com/" + id);
        }, 100);
    }
})();
