// ==UserScript==
// @name        NsaneForums Link Merger
// @namespace   BlazeFTL.Scripts
// @match       https://nsaneforums.com/topic/*
// @grant       none
// @version     1.0
// @author      BlazeFTL
// @description Merges Site + Sharecode which is annoying to do manually
// ==/UserScript==

(function() {
    'use strict';

    function combineLinks() {
        const containers = document.querySelectorAll('.ipsType_richText, .ipsSpoiler_contents');

        containers.forEach(container => {
            const blocks = container.querySelectorAll('p, div');

            blocks.forEach(block => {
                if (block.getAttribute('data-link-merged')) return;

                // Requirement: Must contain the specific "Site:" label
                if (!block.innerHTML.includes('Site:')) return;

                // Pick the real site anchor (ignoring the help link)
                const siteAnchor = block.querySelector('a[href*="http"]:not([href*="how-to-work-with-sharecodes"])');

                // Flexible Regex: Skips tags like <b><a>[?]</a></b> to find the code starting with /
                const regex = /Sharecode.*?(?:<\/.*?>|[:\s])+\s*(\/[a-zA-Z0-9][^\s<]+)/i;
                const match = block.innerHTML.match(regex);

                if (siteAnchor && match && match[1]) {
                    const sharecode = match[1].trim();
                    const baseUrl = siteAnchor.href.replace(/\/$/, '');
                    const fullUrl = baseUrl + sharecode;

                    // Apply your requested red formatting
                    block.innerHTML = `<strong style="color: red; font-weight: bold;">Download Link (Merged) :</strong> <a href="${fullUrl}" target="_blank" rel="noopener noreferrer" style="color: #3498db; text-decoration: underline; font-weight: bold;">${fullUrl}</a>`;

                    block.setAttribute('data-link-merged', 'true');
                }
            });
        });
    }

    combineLinks();
    let timeout;
    const observer = new MutationObserver(() => {
        clearTimeout(timeout);
        timeout = setTimeout(combineLinks, 150);
    });
    observer.observe(document.body, { childList: true, subtree: true });
})();
