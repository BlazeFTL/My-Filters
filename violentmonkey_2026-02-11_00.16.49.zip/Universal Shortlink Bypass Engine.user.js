// ==UserScript==
// @name         Universal Shortlink Bypass Engine
// @namespace    https://tampermonkey.net/
// @version      3.5
// @description  Auto bypass shortlinks: timers, buttons, cookies, storage & redirects
// @match        https://*/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_deleteValue
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    const DEBUG = true;
    const LOOP_KEY = 'bypass_last';

    const log = (...a) => DEBUG && console.log('[Bypass]', ...a);

    /* ================== LOOP PROTECTION ================== */
    function alreadyRedirected(url) {
        return GM_getValue(LOOP_KEY) === url;
    }

    function markRedirect(url) {
        GM_setValue(LOOP_KEY, url);
    }

    /* ================== SAFE REDIRECT ================== */
    function redirect(url) {
        if (!url || !/^https?:/i.test(url)) return;
        if (alreadyRedirected(url)) return;

        log('🚀 Redirect →', url);
        markRedirect(url);
        window.location.replace(url);
    }

    /* ================== REDIRECT HIJACK ================== */
    ['assign', 'replace'].forEach(fn => {
        const orig = location[fn];
        location[fn] = function (url) {
            log('Intercept location.' + fn, url);
            redirect(url);
        };
    });

    Object.defineProperty(location, 'href', {
        set(url) {
            log('Intercept location.href', url);
            redirect(url);
        }
    });

    const open = window.open;
    window.open = function (url) {
        log('Intercept window.open', url);
        redirect(url);
        return null;
    };

    /* ================== TIMER SKIP ================== */
    const _setTimeout = window.setTimeout;
    window.setTimeout = function (fn, t, ...args) {
        if (t > 1000) t = 50;
        return _setTimeout(fn, t, ...args);
    };

    const _setInterval = window.setInterval;
    window.setInterval = function (fn, t, ...args) {
        if (t > 1000) t = 100;
        return _setInterval(fn, t, ...args);
    };

    /* ================== AUTO CLICK ================== */
    function autoClick() {
        const keys = [
            'get link', 'continue', 'skip',
            'go', 'verify', 'submit', 'proceed'
        ];

        document.querySelectorAll('a, button, input').forEach(el => {
            const txt = (el.innerText  el.value  '').toLowerCase();
            if (keys.some(k => txt.includes(k))) {
                log('Auto click →', txt);
                el.click();
            }
        });

        setTimeout(autoClick, 800);
    }

    document.addEventListener('DOMContentLoaded', autoClick);

    /* ================== STORAGE / COOKIE SCAN ================== */
    function scanStorage() {
        const scan = obj => {
            for (const k in obj) {
                try {
                    const v = obj[k];
                    if (typeof v === 'string' && v.startsWith('http')) {
                        log('Found URL →', v);
                        redirect(v);
                    }
                } catch {}
            }
        };

        scan(localStorage);
        scan(sessionStorage);

        document.cookie.split('; ').forEach(c => {
            const v = c.split('=').slice(1).join('=');
            if (v.startsWith('http')) redirect(v);
        });
    }

    setTimeout(scanStorage, 1500);

})();