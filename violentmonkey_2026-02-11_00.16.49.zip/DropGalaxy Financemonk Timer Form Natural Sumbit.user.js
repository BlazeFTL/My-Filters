// ==UserScript==
// @name         DropGalaxy Financemonk Timer Form Natural Sumbit
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Bypass timer, prevent adblock detection, auto-submit DropGalaxy form on Financemonk.net without hardcoded values.
// @author       BlazeFTL
// @match        *://financemonk.net/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const log = (...args) => console.log('[Bypass]', ...args);

    function fillAndSubmitFormAfterCaptcha() {
        const form = document.querySelector('form[name="F1"]');
        if (!form) return log('Form not found!');

        const spoofField = (id, val) => {
            const el = document.getElementById(id);
            if (el) el.value = val;
        };

        // Spoof fields to bypass adblock triggers
        spoofField("adblock_check", "0");
        spoofField("adblock_detected", "0");
        spoofField("adb", "0");
        spoofField("dropgalaxyisbest", "1");
        spoofField("adsns", "1");
        spoofField("admaven_popup", "1");

        // Populate "ipp" via fetch (mimicking the site's AJAX)
        fetch('https://dg.a2zupload.com/dlhash.php')
            .then(resp => resp.text())
            .then(data => {
                spoofField("ipp", data);

                // Simulate 4-second timer and render CAPTCHA
                setTimeout(() => {
                    if (typeof turnstile !== 'undefined' && turnstile.render) {
                        log("Rendering CAPTCHA...");

                        turnstile.render('#cfcaptcha', {
                            sitekey: '0x4AAAAAAAYwfzxMEjmxM8RT',
                            callback: function (token) {
                                log("Captcha complete. Token:", token);
                                if (typeof bangbang === 'function') bangbang(token);

                                // Add a short delay before submission to mimic natural flow
                                setTimeout(() => {
                                    log("Submitting form...");
                                    form.submit();
                                }, 4000);
                            }
                        });
                    }
                }, 7000);
            });
    }

    window.addEventListener('load', () => {
        setTimeout(fillAndSubmitFormAfterCaptcha, 500);
    });
})();
