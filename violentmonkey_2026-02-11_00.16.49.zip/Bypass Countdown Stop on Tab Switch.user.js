// ==UserScript==
// @name         Bypass Countdown Stop on Tab Switch
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Ensures countdown continues even if the user switches tabs or minimizes the browser
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    // Helper function to simulate mouse movement or activity
    function simulateMouseEvent() {
        const mouseEvent = new MouseEvent('mousemove', {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX: window.innerWidth / 2,
            clientY: window.innerHeight / 2
        });
        document.body.dispatchEvent(mouseEvent);
    }

    // Helper function to simulate a keypress event (e.g., any letter key)
    function simulateKeyPress() {
        const keyboardEvent = new KeyboardEvent('keydown', {
            key: 'a',  // Any key can be simulated
            bubbles: true,
            cancelable: true
        });
        document.body.dispatchEvent(keyboardEvent);
    }

    // Override the Page Visibility API to trick the site into thinking it's always in focus
    const originalVisibilityChange = document.hidden;
    Object.defineProperty(document, 'hidden', {
        get: () => false
    });
    document.addEventListener('visibilitychange', function () {
        document.hidden = false;
    });

    // Simulate user activity at regular intervals to keep the page "active"
    setInterval(() => {
        simulateMouseEvent();  // Simulate mouse movement
        simulateKeyPress();    // Simulate keypress (to keep focus)
    }, 10000); // Every 10 seconds (adjust as needed)

    // Handle focus/blur events to prevent detection
    window.addEventListener('blur', () => {
        // Pretend the page is still focused when the tab is switched
        document.dispatchEvent(new Event('focus'));
    });

    window.addEventListener('focus', () => {
        // Ensure the page always reports as focused
        document.dispatchEvent(new Event('focus'));
    });

    // Log for debugging
    console.log('[UserScript] Bypass for countdown pause when switching tabs initialized.');
})();
