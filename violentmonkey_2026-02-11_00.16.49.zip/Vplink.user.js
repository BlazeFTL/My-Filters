// ==UserScript==
// @name  Vplink
// @match *://famemingles.com/*studyuniversty=*
// @match *://dailyhindiadda.com/*studyeducate=*
// @match *://dailyhindiadda.com/*edustudy=*
// @run-at document-start
// ==/UserScript==
(function() {
    'use strict';

    const p = new URLSearchParams(location.search),
        s = p.get('studyeducate'),
        e = p.get('edustudy'),
        u = p.get('studyuniversty');

    // Handle 'studyuniversty' parameter
    if (u) {
        location.replace('https://dailyhindiadda.com/studyeducates/jobsstudy/?studyeducate=' + u);
    }

    // Handle 'studyeducate' parameter if 'edustudy' is missing
  //  if (s && !e) {
       // location.replace('https://crimejasoos.in/studyeducates/jobsstudy/?edustudy=' + s);
    }

    // Handle 'edustudy' parameter with a countdown timer
    if (e) {
        window.stop();
        let c = 20;

        document.documentElement.innerHTML = `
            <body style="background:#000;color:#fff;text-align:center;padding-top:20%;font-family:sans-serif">
                <h1>Redirecting: <span id="t">20</span>s</h1>
                <button onclick="location.href='https://vplink.in/${e}'">Skip</button>
            </body>`;

        const timer = setInterval(() => {
            if (--c <= 0) {
                clearInterval(timer); // Clean up the interval
                location.href = 'https://vplink.in/' + e;
            } else {
                document.getElementById('t').innerText = c;
            }
        }, 1000);
    }
})();


