// ==UserScript==
// @name         InshortUrl Redirect
// @namespace    https://tampermonkey.net/
// @version      1.4
// @description  Prevent site redirect and send id directly to inshorturl
// @match        https://tech4auto.in/*
// @match        https://mahitimanch.in/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    'use strict';
    window.stop();
    const url = new URL(location.href);
    const id = url.searchParams.get("link");

    if (id) {
        setTimeout(() => {
            location.replace("https://inshorturl.in/" + id);
        }, 100);
    }
})();
+