// ==UserScript==
// @name         Background Timer + Audio Keep-Alive (CF-SAFE FINAL)
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Worker timers + silent audio. HARD disabled on Cloudflare to prevent loops.
// @author       BlazeFTL
// @match        *://*/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    /*********************************************************
     * HARD BLOCK — DO NOT TOUCH CLOUDFLARE
     *********************************************************/
    if (
        window.top !== window ||
        location.hostname === 'challenges.cloudflare.com' ||
        document.querySelector('iframe[src*="challenges.cloudflare.com"]')
    ) {
        return; // absolute exit, no logic, no timers
    }

    /*********************************************************
     * INIT
     *********************************************************/
    startSilentAudio();
    installWorkerTimers();
    console.log('[BG-FIX] Active (Cloudflare-free)');

    /*********************************************************
     * SILENT AUDIO KEEP-ALIVE
     *********************************************************/
    function startSilentAudio() {
        let started = false;

        function unlock() {
            if (started) return;
            started = true;

            try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const src = ctx.createBufferSource();
                src.buffer = ctx.createBuffer(1, 44100, 44100);
                src.loop = true;

                const gain = ctx.createGain();
                gain.gain.value = 0;

                src.connect(gain);
                gain.connect(ctx.destination);

                ctx.resume().then(() => src.start());
            } catch (e) {}
        }

        window.addEventListener('click', unlock, { once: true });
        window.addEventListener('touchstart', unlock, { once: true });
    }

    /*********************************************************
     * WORKER TIMER ENGINE (NO PARTIAL OVERRIDES)
     *********************************************************/
    function installWorkerTimers() {
        const workerCode = `
            const timers = {};
            self.onmessage = e => {
                const { type, id, delay } = e.data;
                if (type === 'timeout') {
                    setTimeout(() => postMessage(id), delay);
                } else if (type === 'interval') {
                    timers[id] = setInterval(() => postMessage(id), delay);
                } else if (type === 'clear') {
                    clearInterval(timers[id]);
                    delete timers[id];
                }
            };
        `;

        const worker = new Worker(URL.createObjectURL(
            new Blob([workerCode], { type: 'application/javascript' })
        ));

        const callbacks = {};
        let uid = 0;

        worker.onmessage = e => {
            callbacks[e.data]?.();
        };

        window.setTimeout = function (fn, delay = 0) {
            const id = ++uid;
            callbacks[id] = () => {
                fn();
                delete callbacks[id];
            };
            worker.postMessage({ type: 'timeout', id, delay });
            return id;
        };

        window.setInterval = function (fn, delay = 0) {
            const id = ++uid;
            callbacks[id] = fn;
            worker.postMessage({ type: 'interval', id, delay });
            return id;
        };

        window.clearTimeout = window.clearInterval = function (id) {
            worker.postMessage({ type: 'clear', id });
            delete callbacks[id];
        };
    }

})();
