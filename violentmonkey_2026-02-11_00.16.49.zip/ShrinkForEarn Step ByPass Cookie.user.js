// ==UserScript==
// @name         ShrinkForEarn Step ByPass Cookie
// @match        https://drinkspartner.com/*
// @match        https://headlinerpost.com/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    function getCookie(name) {
        const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
        return match ? decodeURIComponent(match[2]) : null;
    }

    function setCookie(name, value, days = 7) {
        const date = new Date();
        date.setTime(date.getTime() + (days * 86400000));
        const expires = "; expires=" + date.toUTCString();
        document.cookie = `${name}=${encodeURIComponent(value)}${expires}; path=/`;
    }

    window.addEventListener('load', function () {
        setTimeout(() => {
            const planRaw = getCookie("plan");
            if (planRaw) {
                try {
                    const plan = JSON.parse(planRaw);
                    plan.page = "1"; // Set only the 'page' value
                    const updated = JSON.stringify(plan);
                    setCookie("plan", updated);
                    console.log("Modified 'plan' cookie after 2 seconds.");
                } catch (e) {
                    console.error("Failed to parse 'plan' cookie:", e);
                }
            }
        }, 2000); // 2 seconds delay
    });
})();
