// ==UserScript==
// @name        Visible Inputs
// @description Make Hidden Inputs Visible
// @namespace    http://tampermonkey.net/
// @match       *://*/*
// @grant       none
// @version     1.0
// @author      DaRealTrueBlue
// @description 15/10/2024, 10:12:09 am
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tampermonkey.net
// @grant        none
// @license MIT
// @downloadURL https://update.greasyfork.org/scripts/512655/Visible%20Inputs.user.js
// @updateURL https://update.greasyfork.org/scripts/512655/Visible%20Inputs.meta.js
// ==/UserScript==

const hiddenInputs = document.querySelectorAll('input[type="hidden"]');
hiddenInputs.forEach(input => {
  input.setAttribute("type", "text");
});
