// ==UserScript==
// @name         Ublock AdrinoLink Instant Bypass
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Syncs tp cookie to open cookie and redirects
// @author       BlazeFTL
// @match        https://invest.carrnissan.com/*
// @exclude      https://invest.carrnissan.com/includes/open.php*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const getCookie = (name) => {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
        return null;
    };

    const tpValue = getCookie('tp');

    if (tpValue) {
        // 1. Create/Update the 'open' cookie with the tp value
        // Path=/ ensures it is accessible across the whole domain
        document.cookie = `open=${tpValue}; path=/; max-age=3600; SameSite=Lax`;

        console.log(`Syncing cookies: open set to ${tpValue}. Redirecting...`);

        // 2. Perform the redirect
        window.location.replace(`https://invest.carrnissan.com/includes/open.php?id=${tpValue}`);
    } else {
        console.log("Waiting for tp cookie to be set...");
    }
})();

