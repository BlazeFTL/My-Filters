// ==UserScript==
// @name         Ublock Liteshort.com Intent Links to HTTPS
// @namespace    BlazeFTL.Fix
// @version      1.0
// @description  Converts intent:// links back to normal https:// links
// @author       BlazeFTL
// @match        *://liteshort.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    function fixLinks() {
        const links = document.querySelectorAll('a[href^="intent://"]');
        links.forEach(link => {
            const href = link.href;
            // Extract the domain and path (sssbiotic.com/new.php?link=...)
            const match = href.match(/intent:\/\/([^#]+)/);
            if (match && match[1]) {
                const cleanUrl = 'https://' + match[1];
                link.href = cleanUrl;
                // Optional: Remove any click listeners that might be hijacking the button
                link.onclick = (e) => e.stopPropagation();
            }
        });
    }

    // Run immediately
    fixLinks();

    // Run whenever the page content changes (for dynamic links)
    const observer = new MutationObserver(fixLinks);
    observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true
    });
})();
