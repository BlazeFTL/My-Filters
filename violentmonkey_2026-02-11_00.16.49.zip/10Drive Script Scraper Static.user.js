// ==UserScript==
// @name         10Drive Script Scraper Static
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  Finds the URL inside script text and redirects immediately
// @author       BlazeFTL
// @match        *://gamesmain.xyz/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // The unique part of the link we are looking for
    const linkPattern = "https://gamesmain.xyz/2023/08/the-importance-of-regular-software-updates.html";

    const findAndRedirect = () => {
        const scripts = document.getElementsByTagName('script');

        for (let script of scripts) {
            if (script.textContent.includes(linkPattern)) {
                console.log("Found the link in script text! Redirecting...");
                window.location.replace(linkPattern);
                return true;
            }
        }
        return false;
    };

    // 1. Try immediately
    if (findAndRedirect()) return;

    // 2. If scripts haven't loaded yet, watch the DOM as they appear
    const observer = new MutationObserver((mutations) => {
        for (let mutation of mutations) {
            for (let node of mutation.addedNodes) {
                if (node.tagName === 'SCRIPT' && node.textContent.includes(linkPattern)) {
                    window.location.replace(linkPattern);
                    observer.disconnect();
                }
            }
        }
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
})();

