// ==UserScript==
// @name         Ublock ShrinkMe ByPass
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Auto-redirects for both Themezone and NewWPSafeLink patterns.
// @author       BlazeFTL
// @match       *://themezon.net/*
// @match       https://shrinkme.*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // --- 1. MrProBlogger Redirect Logic (Mutation Observer) ---
    function checkSafeLink() {
        const input = document.querySelector('input[name="newwpsafelink"]');
        if (input && input.value) {
            const code = input.value.trim();
            if (code) {
                console.log("SafeLink detected. Redirecting...");
                window.location.replace("https://en.mrproblogger.com/" + code);
            }
        }
    }

    // --- 2. Themezone Redirect Logic (Interval) ---
    function checkThemezone() {
        // Ensure jQuery ($) is available for this specific check
        if (typeof $ !== 'undefined') {
            const targetDiv = $("#div-human-verification");
            const queryString = targetDiv.data("link");

            if (targetDiv.length > 0 && queryString) {
                clearInterval(themezoneInterval); // Stop searching
                const finalUrl = "https://themezon.net/link.php?link=" + queryString;

                console.log("Themezone bypass detected. Redirecting...");
                window.location.href = finalUrl;
            }
        }
    }

    // Initialize MrProBlogger Observer
    const observer = new MutationObserver(checkSafeLink);
    observer.observe(document.body, { childList: true, subtree: true });
    checkSafeLink(); // Run once immediately

    // Initialize Themezone Interval (checks every 500ms)
    const themezoneInterval = setInterval(checkThemezone, 500);

})();

