// ==UserScript==
// @name         IndDrive Redirect to AdvUpdates
// @namespace    BlazeFTL-IndDrive
// @version      1.0
// @description  Redirect inddrive.com/<code> to indian.advupdates.com/?adlinkfly=<code>
// @match        https://inddrive.com/*
// @match        http://inddrive.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const url = new URL(location.href);

  // pathname like "/d12307d0"
  const path = url.pathname.replace(/^\/+|\/+$/g, '');

  // must be like d12307d0 (starts with d then hex)
  const m = path.match(/^d[0-9a-f]{6,32}$/i);
  if (!m) return;

  const code = m[0];
  const target = `https://indian.advupdates.com/?adlinkfly=${encodeURIComponent(code)}`;

  location.replace(target);
})();
