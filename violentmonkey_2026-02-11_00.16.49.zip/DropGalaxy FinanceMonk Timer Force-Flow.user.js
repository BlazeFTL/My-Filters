// ==UserScript==
// @name         DropGalaxy FinanceMonk Timer Force-Flow
// @namespace    http://tampermonkey.net/
// @version      4.0
// @description  Bypasses visibility-based pausing in countd.js
// @author       YourName
// @match        *://*.financemonk.net/*
// @match        *://financemonk.net/*
// @exclude      *://cloudflare.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // 1. FORCE VISIBILITY (The "if" statement bypass)
    // This makes sure 'document.visibilityState === "hidden"' is ALWAYS false
    Object.defineProperty(document, 'visibilityState', {
        get: function() { return 'visible'; },
        configurable: true
    });
    Object.defineProperty(document, 'hidden', {
        get: function() { return false; },
        configurable: true
    });

    // 2. BLOCK THE SITE'S OWN VISIBILITY LISTENER
    // The site tries to clearTimeout(timeout) when you switch tabs.
    // This prevents the site from ever hearing the "tab switch" event.
    const originalAEL = EventTarget.prototype.addEventListener;
    EventTarget.prototype.addEventListener = function(type, listener, options) {
        if (type === 'visibilitychange' || type === 'blur') {
            console.log("[Fixed] Prevented site from pausing on tab switch.");
            return;
        }
        return originalAEL.apply(this, arguments);
    };

    // 3. THE WORKER ENGINE (Bypasses Android Throttling)
    const workerCode = `
        self.onmessage = function(e) {
            setTimeout(() => {
                self.postMessage(e.data.id);
            }, e.data.delay);
        };
    `;
    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const worker = new Worker(URL.createObjectURL(blob));
    const pendingCallbacks = new Map();

    worker.onmessage = function(e) {
        const callback = pendingCallbacks.get(e.data);
        if (callback) {
            pendingCallbacks.delete(e.data);
            callback();
        }
    };

    // 4. OVERRIDE SETTIMEOUT
    // When the site calls 'timeout = setTimeout(tick, 1000)', it now runs in the worker.
    const nativeST = window.setTimeout;
    window.setTimeout = function(callback, delay) {
        // If the delay is 1000 (like the tick function), move it to the Worker
        if (delay >= 1000) {
            const id = Math.random().toString(36).substr(2, 9);
            pendingCallbacks.set(id, callback);
            worker.postMessage({ id, delay });
            return id;
        }
        return nativeST(callback, delay);
    };

    console.log("FinanceMonk Logic Hijacked: Timer will run in background.");
})();

