// ==UserScript==
// @name         GitHub Auto-Linker
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Converts plain text URLs in GitHub markdown bodies into clickable links.
// @author       BlazeFTL
// @match        https://github.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Regex to identify URLs
    const urlRegex = /(https?:\/\/[^\s<]+)/g;

    function linkify(element) {
        // Skip if already a link or contains links
        if (element.tagName === 'A' || element.querySelector('a')) return;

        const originalHTML = element.innerHTML;
        const newHTML = originalHTML.replace(urlRegex, (url) => {
            return `<a href="${url}" target="_blank" style="color: #0969da; text-decoration: underline;">${url}</a>`;
        });

        if (originalHTML !== newHTML) {
            element.innerHTML = newHTML;
        }
    }

    // Function to find targets based on your screenshot (markdown-body p and code)
    function processPage() {
        const containers = document.querySelectorAll('.markdown-body p, .markdown-body code.notranslate');
        containers.forEach(linkify);
    }

    // Run on load
    processPage();

    // Observe for dynamic changes (GitHub uses AJAX to load content)
    const observer = new MutationObserver(() => {
        processPage();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();

