// ==UserScript==
// @name         GitHub Material Red Linker
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Material design red links with minimal footprint.
// @author       BlazeFTL
// @match        https://github.com/uBlockOrigin/uAssets/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const style = document.createElement('style');
    style.innerHTML = `
        .custom-github-link {
            background-color: rgba(207, 34, 46, 0.1);
            color: #cf222e !important;
            /* Minimal padding to keep it 'Material' without large gaps */
            padding: 1px 3px;
            margin: 0 -1px;
            border-radius: 3px;
            font-weight: 560;
            text-decoration: none !important;
            transition: all 0.1s ease-in-out;
            /* inline-block allows for the material shape/padding to render correctly */
            display: inline-block;
            line-height: 1;
        }

        .custom-github-link:hover {
            background-color: #cf222e;
            color: #ffffff !important;
            box-shadow: 0 2px 4px rgba(207, 34, 46, 0.2);
        }
    `;
    document.head.appendChild(style);

    const urlRegex = /(https?:\/\/[^\s<]+)/g;

    function linkify() {
        const elements = document.querySelectorAll('.markdown-body p:not([data-linked]), .markdown-body code.notranslate:not([data-linked])');

        elements.forEach(el => {
            el.setAttribute('data-linked', 'true');
            if (el.querySelector('a')) return;

            const originalHTML = el.innerHTML;
            const newHTML = originalHTML.replace(urlRegex, (url) => {
                return `<a href="${url}" target="_blank" class="custom-github-link">${url}</a>`;
            });

            if (originalHTML !== newHTML) {
                el.innerHTML = newHTML;
            }
        });
    }

    let timeout;
    const debouncedLinkify = () => {
        clearTimeout(timeout);
        timeout = setTimeout(linkify, 200);
    };

    linkify();

    const observer = new MutationObserver(debouncedLinkify);
    observer.observe(document.body, { childList: true, subtree: true });
})();
