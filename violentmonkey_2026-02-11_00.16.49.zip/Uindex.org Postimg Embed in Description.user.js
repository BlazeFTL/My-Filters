// ==UserScript==
// @name         Uindex.org Postimg Embed in Description
// @namespace    http://tampermonkey.net/
// @version      1.3
// @description  Replace postimg.cc links or plain text URLs in #description with actual images
// @author       BlazeFTL
// @match        https://uindex.org/details.php*
// @grant        GM_xmlhttpRequest
// @connect      postimg.cc
// ==/UserScript==

(function () {
    'use strict';

    const container = document.getElementById('description');
    if (!container) return;

    const postimgRegex = /https:\/\/postimg\.cc\/[^\s<)]+/g;

    // Convert plain text URLs into clickable <a> tags
    container.innerHTML = container.innerHTML.replace(postimgRegex, url => {
        return `<a href="${url}" class="postimg-link" target="_blank">${url}</a>`;
    });

    const links = container.querySelectorAll('a.postimg-link');

    links.forEach(link => {
        const url = link.href;
        GM_xmlhttpRequest({
            method: 'GET',
            url: url,
            onload: function (res) {
                const doc = new DOMParser().parseFromString(res.responseText, 'text/html');
                const imgMeta = doc.querySelector('meta[property="og:image"]');
                if (imgMeta && imgMeta.content) {
                    const img = document.createElement('img');
                    img.src = imgMeta.content;
                    img.style.maxWidth = '100%';
                    img.style.margin = '10px 0';
                    link.replaceWith(img);
                }
            },
            onerror: function () {
                console.warn("Couldn't load image for:", url);
            }
        });
    });
})();
