// ==UserScript==
// @name         10Drive Bypass Till GetLink 3rd Page No Download
// @namespace    http://tampermonkey.net/
// @version      4.0
// @description  Uses Regex to find dynamic URLs inside script tags
// @author       BlazeFTL
// @match        *://gamesmain.xyz/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // This Regex looks for: https://gamesmain.xyz/ + any characters + .html
    const urlRegex = /https:\/\/gamesmain\.xyz\/[\d/]+[a-zA-Z0-9-]+\.html/;

    const scanForLink = () => {
        const scripts = document.getElementsByTagName('script');
        for (let script of scripts) {
            // We search the text of the script for the pattern
            const match = script.textContent.match(urlRegex);
            if (match) {
                const dynamicURL = match[0];
                console.log("Dynamic Link Found: " + dynamicURL);
                window.location.replace(dynamicURL);
                return true;
            }
        }
        return false;
    };

    // 1. Check immediately
    if (scanForLink()) return;

    // 2. Watch for scripts being injected
    const observer = new MutationObserver(() => {
        if (scanForLink()) {
            observer.disconnect();
        }
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });
})();

