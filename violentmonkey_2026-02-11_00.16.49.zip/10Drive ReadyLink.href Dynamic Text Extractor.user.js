// ==UserScript==
// @name         10Drive ReadyLink.href Dynamic Text Extractor
// @match        *://gamesmain.xyz/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const extractAndRedirect = () => {
        const scripts = document.getElementsByTagName('script');

        for (let script of scripts) {
            const code = script.textContent;

            // We search for the exact text "readylink.href ="
            if (code.includes('readylink.href')) {
                // Regex breakdown:
                // readylink\.href\s*=\s* -> look for 'readylink.href =' (ignoring spaces)
                // ["'](.+?)["']           -> capture everything inside the " " or ' '
                const match = code.match(/readylink\.href\s*=\s*["'](.+?)["']/);

                if (match && match[1]) {
                    const extractedURL = match[1];
                    console.log("Found URL via text search: " + extractedURL);
                    window.location.replace(extractedURL);
                    return true;
                }
            }
        }
        return false;
    };

    // Run immediately and also watch for late-loading scripts
    if (!extractAndRedirect()) {
        const observer = new MutationObserver(() => {
            if (extractAndRedirect()) observer.disconnect();
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });
    }
})();
