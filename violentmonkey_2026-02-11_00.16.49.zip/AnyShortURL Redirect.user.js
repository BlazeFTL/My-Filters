// ==UserScript==
// @name         AnyShortURL Redirect
// @namespace    https://tampermonkey.net/
// @version      1.4
// @description  Prevent site redirect and send id directly to anyshorturl
// @match        https://fastloanglobal.in/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
    'use strict';
    window.stop();
    const url = new URL(location.href);
    const id = url.searchParams.get("id");

    if (id) {
        setTimeout(() => {
            location.replace("https://anyshorturl.com/" + id);
        }, 100);
    }
})();
