// ==UserScript==
// @name         PSA.wf Instant Redirect
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Finds the hidden 'id' input on psa.wf and redirects immediately
// @author       BlazeFTL
// @match        *://psa.wf/goto/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to extract value and redirect
    function attemptRedirect() {
        const input = document.querySelector('input#id[name="id"]');
        if (input && input.value) {
            try {
                // Fix URL-safe characters and padding
                let base64 = input.value.replace(/-/g, '+').replace(/_/g, '/');
                while (base64.length % 4) {
                    base64 += '=';
                }

                const decodedUrl = atob(base64);

                if (decodedUrl.startsWith('http')) {
                    window.location.replace(decodedUrl);
                }
            } catch (e) {
                console.error("Redirection failed:", e);
            }
        }
    }

    // Run immediately
    attemptRedirect();

    // Because the element might not exist the millisecond the script starts,
    // we use an observer to catch it the moment it's added to the page.
    const observer = new MutationObserver((mutations, obs) => {
        const input = document.querySelector('input#id[name="id"]');
        if (input) {
            attemptRedirect();
            obs.disconnect(); // Stop looking once we found it
        }
    });

    observer.observe(document.documentElement, {
        childList: true,
        subtree: true
    });
})();

